module.exports = {
    // publicPath: "./", // ./相对路径
    // productionSourceMap: false,// 打包时不生成.map文件
    devServer: {
        port: 8080, // 本机端口号
        host: 'localhost', // 本机主机名
        https: false, // 协议
        open: true,
        proxy: {
            '/attachs': {
                target: 'http://localhost:3001',
                changeOrigin: true
            },
            '/public': {
                target: 'http://localhost:3001',
                changeOrigin: true
            }
        }
    }
};
