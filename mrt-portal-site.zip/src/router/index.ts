import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import Home from '../views/Home.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    redirect: {name:'Index'},
    children:[
      {
        path: 'Index',
        name: 'Index',
        meta:{
          title: '首页'
        },
        component: () => import('../views/Index.vue')
      },
      {
        path: 'Management-system',
        name: 'Management-system',
        meta:{
          title: '管理系统'
        },
        component: () => import('../views/Management-system.vue')
      },
      {
        path: 'News',
        name: 'News',
        meta:{
          title: '新闻信息'
        },
        component: () => import('../views/News.vue'),
        redirect: {name:'News-list'},
        children:[
          {
            path: 'News-list',
            name: 'News-list',
            meta:{
              title: '新闻资讯'
            },
            component: () => import('../views/News-list.vue')
          },
          {
            path: 'News-detail',
            name: 'News-detail',
            meta:{
              title: '新闻资讯'
            },
            component: () => import('../views/News-detail.vue')
          }
        ]
      },
      {
        path: 'Teaching',
        name: 'Teaching',
        component: () => import('../views/Teaching.vue'),
        redirect: {name:'Teaching-list'},
        children:[
          {
            path: 'Teaching-list',
            name: 'Teaching-list',
            component: () => import('../views/Teaching-list.vue')
          },
          {
            path: 'Teaching-list-commonweal',
            name: 'Teaching-list-commonweal',
            component: () => import('../views/Teaching-list-commonweal.vue')
          },
          {
            path: 'Teaching-detail',
            name: 'Teaching-detail',
            component: () => import('../views/Teaching-detail.vue')
          }
        ]
      },
      {
        path: 'Teacher',
        name: 'Teacher',
        component: () => import('../views/Teacher.vue'),
        redirect: {name:'Teacher-list'},
        children:[
          {
            path: 'Teacher-list',
            name: 'Teacher-list',
            component: () => import('../views/Teacher-list.vue')
          },
          {
            path: 'Teacher-detail',
            name: 'Teacher-detail',
            component: () => import('../views/Teacher-detail.vue')
          }
        ]
      },
      {
        path: 'Rules',
        name: 'Rules',
        component: () => import('../views/Rules.vue'),
        redirect: {name:'Rules-list'},
        children:[
          {
            path: 'Rules-list',
            name: 'Rules-list',
            component: () => import('../views/Rules-list.vue')
          },
          {
            path: 'Rules-list-policy',
            name: 'Rules-list-policy',
            component: () => import('../views/Rules-list-policy.vue')
          },
          {
            path: 'Rules-detail',
            name: 'Rules-detail',
            component: () => import('../views/Rules-detail.vue')
          }
        ]
      },
      {
        path: 'Recruit',
        name: 'Recruit',
        component: () => import('../views/Recruit.vue'),
        redirect: {name:'Recruit-list'},
        children:[
          {
            path: 'Recruit-list',
            name: 'Recruit-list',
            component: () => import('../views/Recruit-list.vue')
          },
          {
            path: 'Recruit-detail',
            name: 'Recruit-detail',
            component: () => import('../views/Recruit-detail.vue')
          }
        ]
      },
      {
        path: 'Download',
        name: 'Download',
        component: () => import('../views/Download.vue'),
        redirect: {name:'Download-list'},
        children:[
          {
            path: 'Download-list',
            name: 'Download-list',
            component: () => import('../views/Download-list.vue')
          },
          {
            path: 'Download-detail',
            name: 'Download-detail',
            component: () => import('../views/Download-detail.vue')
          }
        ]
      },
      {
        path: 'Curriculum',
        name: 'Curriculum',
        component: () => import('../views/Curriculum.vue'),
        redirect: {name:'Curriculum-list'},
        children:[
          {
            path: 'Curriculum-list',
            name: 'Curriculum-list',
            component: () => import('../views/Curriculum-list.vue')
          },
          {
            path: 'Curriculum-detail',
            name: 'Curriculum-detail',
            component: () => import('../views/Curriculum-detail.vue')
          },
          {
            path: 'Curriculum-play',
            name: 'Curriculum-play',
            component: () => import('../views/Curriculum-play.vue')
          }
        ]
      },
      {
        path: 'Template-list',
        name: 'Template-list',
        component: () => import('../views/Template-list.vue')
      }
    ]
  },
  {
    path: '/about',
    name: 'About',
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/Login',
    name: 'Login',
    component: () => import(/* webpackChunkName: "about" */ '../views/Login.vue')
  },
  {
    path: '/test',
    name: 'test',
    component: () => import(/* webpackChunkName: "about" */ '../views/test.vue')
  }
]


const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})
router.beforeEach((to,from,next)=>{
  next()
})
export default router
