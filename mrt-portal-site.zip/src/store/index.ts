import { createStore } from 'vuex'
import Cookies from "js-cookie"

export default createStore({
  state: {
    urlList: [
      {
        title: '在线课程11',
        path: '/Rules/Rules-list'
      },
      {
        title: '精品课程22',
        path: '/Rules/Rules-list'
      }
    ],
    manageToken: '',
    manageUserInfo: {
      name: null
    },
    tabIndex: sessionStorage.getItem('tabIndex') || 0,
    menus: []
  },
  mutations: {
    setUrlList(state,data){
      state.urlList = data
    },
    setMenus(state,data){
      state.menus = data
    },
    setManageToken (state, n) {
      state.manageToken = n
      Cookies.set('token', n)
    },
    setManageUserInfo (state, n) {
      state.manageUserInfo = n
      sessionStorage.setItem('manageUserInfo', JSON.stringify(n))
    },
    tabIndexSet(state,data){
      state.tabIndex = data
    }
  },
  actions: {
  },
  modules: {
  }
})
