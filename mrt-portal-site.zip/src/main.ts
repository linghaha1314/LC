import { createApp,createVNode } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import './assets/css/index.css'
import * as Icons from '@element-plus/icons-vue'
const app = createApp(App)
// app.config.globalProperties.$utils = utils
app.config.globalProperties.$store = store
const Icon = (props: { icon: string }) => { // 创建Icon组件
    const { icon } = props
    return createVNode(Icons[icon as keyof typeof Icons])
}
// 注册Icon组件,全局引入，便于自定义动态icon
app.component('Icon', Icon)
app.use(store).use(ElementPlus).use(router).mount('#app')
