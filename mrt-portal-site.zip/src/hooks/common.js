import {useRoute, useRouter} from 'vue-router'
import {useStore} from 'vuex';
import http from '@/http/axios'

export default function () {
    const route = useRoute();
    const router = useRouter();
    const store = useStore();
    // 路由跳转
    const go = (url, data, cb) => {
        router.push({
            name: url,
            params: {
                ...data,
                random: Date.parse(new Date())
            } || {}
        }).then(()=>{
            cb && cb()
        })
    }
    // 获取路由query
    const getQuery = () => {
        return route.query
    }
    // 获取路由param
    const getParams = () => {
        return route.params
    }
    // 设置vuex数据
    const setStore = (str,data) => {
        store.commit(str,data)
    }
    // 获取vuex数据
    const getStore = (str) => {
        return  store.state[str]
    }
    // 获取侧边菜单
    const getSubList = (code) => {
        return  http.post('/dictionaryData/getByTypeCode', {
            typeCode: code
        })
    }

    return {
        getQuery,
        go,
        getStore,
        getParams,
        setStore,
        getSubList
    }
}
