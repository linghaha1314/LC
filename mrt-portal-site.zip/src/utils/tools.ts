import {ElLoading, ElMessage, ElMessageBox} from 'element-plus'
// import { Observable } from 'rxjs'
import service from '@/http/axios'
import router from '@/router'

let loadingData: any

function post(url: string, data = {}, authFlag = true): Promise<any> {
    return new Promise((resolve, reject) => {
        service
            .post(url, data, {headers: {Authorization: String(authFlag)}})
            .then(
                // service.post(url, data).then(
                (response: any) => {
                    resolve(response)
                },
                (err) => {
                    ElMessage({
                        message: err,
                        type: 'error',
                        duration: 2 * 1000
                    })
                    reject(err)
                }
            )
    })
}

function get(url: string, params = {}, authFlag = true): Promise<any> {
    return new Promise((resolve, reject) => {
        service
            .get(url, {
                headers: {Authorization: String(authFlag)},
                params: params
            })
            .then((response: any) => {
                resolve(response)
            })
            .catch((err) => {
                reject(err)
            })
    })
}


/**
 * @name msg
 * @desc 成功弹窗显示;错误弹窗，需要传入type=error
 * */
function msg(msg: string, type: any = 'success'): void {
    ElMessage({
        message: msg,
        type,
        duration: 2 * 1000
    })
}

function msgError(msg: string): void {
    ElMessage.error({
        message: msg,
        duration: 2 * 1000
    })
}

function confirm(title = '温馨提示', msg = '确定删除？'): Promise<any> {
    return new Promise((resolve) => {
        ElMessageBox.confirm(msg, title, {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        })
            .then(() => {
                resolve(true)
            })
            .catch(() => {
                resolve(false)
            })
    })
}

/**
 * @name formatTime
 * @desc 时间格式函数
 * * @param {Date | string} date -不传，默认当前时间；
 * * @param {string} format -不传，默认YY-MM-DD格式,传入举例:YY-MM-DD hh:mm:ss;YY年MM月DD日等等
 * */
function formatTime(date?: string | Date, format = 'YY-MM-DD'): string {
    if (typeof date === 'string') {
        date = date.replace(/\s+/, 'T')
    }
    date = date ? new Date(date) : new Date()
    const dateObj: any = {}
    dateObj.YY = date.getFullYear()
    dateObj.MM = date.getMonth() + 1
    dateObj.DD = date.getDate()
    dateObj.hh = date.getHours()
    dateObj.mm = date.getMinutes()
    dateObj.ss = date.getSeconds()
    const arr = aryJoinAry(
        format.match(/[a-zA-Z]{2}/g),
        format.match(/[^a-zA-Z]/g) || []
    )
    let result: any = ''
    arr.forEach((res: any) => {
        result += /[a-zA-Z]/g.test(res) ? addZero(dateObj[res]) : res
    })
    return result
}

function addZero(num: number) {
    if (num > 9) {
        return num
    } else {
        return `0${num}`
    }
}

function aryJoinAry(ary: any, ary2: any) {
    const itemAry: any = []
    let minLength
    if (ary.length > ary2.length) {
        minLength = ary2.length
    } else {
        minLength = ary.length
    }
    // eslint-disable-next-line prefer-rest-params
    const longAry =
        // eslint-disable-next-line prefer-rest-params
        arguments[0].length > arguments[1].length ? arguments[0] : arguments[1]
    for (let i = 0; i < minLength; i++) {
        itemAry.push(ary[i])
        itemAry.push(ary2[i])
    }
    return itemAry.concat(longAry.slice(minLength))
}

// export const loadScript = (js: string): Observable<boolean> => {
//     return new Observable((subscriber) => {
//         const id = 'js' + js.replace(/\./g, '').replace(/\//g, '_')
//         if (document.getElementById(id) != null) {
//             subscriber.next(true)
//             return
//         }
//         const node = document.createElement('script')
//         node.id = id
//         node.src = js
//         node.type = 'text/javascript'
//         document.getElementsByTagName('head')[0].appendChild(node).onload = () => {
//             subscriber.next(true)
//         }
//     })
// }

/**
 * @name deleteById
 * @desc 默认删除接口，传入删除得表名和id
 * */
function deleteById(
    tableName: string,
    id: string,
    pageParams: any,
    url?: any
): Promise<boolean> {
    return new Promise((resolve) => {
        confirm().then((r) => {
            if (r) {
                post(url || `/${tableName}/deleteById`, {id: id}).then((res) => {
                    if (res.success) {
                        msg(res.msg)
                        pageParams.refresh = true
                        resolve(true)
                    } else {
                        msgError(res.msg)
                        resolve(false)
                    }
                })
            }
        })
    })
}

/**
 * @name delMultiple
 * @desc 根据id批量删除，传入section
 * */
function delMultiple(
    tableName: string,
    selection: any,
    pageParams: any,
    message = '请至少选择一条数据'
): Promise<boolean> {
    return new Promise((resolve) => {
        confirm().then((r) => {
            if (r) {
                let str = ''
                if (typeof selection !== 'string') {
                    if (selection.length === 0) {
                        tools.msgError(message)
                        return
                    }
                    selection.forEach((res: any, index: number) => {
                        str += index === selection.length - 1 ? res.id : res.id + ','
                    })
                } else {
                    str = selection
                }
                tools.post(`/${tableName}/deleteMultiple`, {id: str}).then((res) => {
                    if (res.success) {
                        msg(res.msg)
                        pageParams.refresh = true
                        resolve(true)
                    } else {
                        msgError(res.msg)
                        resolve(false)
                    }
                })
            }
        })
    })
}

/**
 * @name openDrawer
 * @desc 抽屉新增或者修改执行;
 * */
function openDrawer(drawer: any, isEdit?: boolean, formList?: any, val?: any) {
    drawer.isDrawer = true
    if (isEdit) {
        drawer.isEdit = true
        formList.forEach((res: any) => {
            res.value = val[res.key]
        })
    } else {
        drawer.isEdit = false
    }
}

// function imgError(src: string, val?: any) {
//     if (!src) {
//         return
//     }
//     if (process.env.NODE_ENV === 'development') {
//         return `javascript:this.src='http://localhost:3001${src}'`
//     }
//     if (val) {
//         return `javascript:this.src='${val}'`
//     }
// }

function numberToLetter(value: any) {
    return String.fromCharCode(64 + parseInt(String(value), 10))
}

function loading(is = true, text = '请稍等...') {
    if (!is) {
        loadingData.close()
        return
    }
    loadingData = ElLoading.service({
        lock: true,
        text: text,
        background: 'rgba(0, 0, 0, 0.7)'
    })
}

function go(url, data?, cb?) {
    router.push({
        name: url,
        params: data || {}
    }).then(() => {
        cb && cb()
    })
}

const day = ((i) => {
    const d = new Date(i).getDate()
    return d > 9 ? d : '0' + d
})
const yearMouth = ((i) => {
    const y = new Date(i).getFullYear()
    const m = (new Date(i).getMonth() + 1) > 9 ? new Date(i).getMonth() + 1 : '0' + (new Date(i).getMonth() + 1)
    return `${y}-${m}`
})
const sortFn = (arr, flag) => {
    arr.sort((a, b) => {
        if (flag) {
            return b.sequence - a.sequence
        }else{
            return a.sequence - b.sequence
        }
    })
    return arr
}

const ellipsis = (value, len?) => {
    value = value.replace(/<\/?.+?>/g, "").replace(/ /g, "").replace(/&nbsp;/ig, "")      //把v-html的格式标签替换掉
    if (value.length > len) {
        return value.slice(0, len) + "...";
    } else {
        return value
    }
}

const showIsLogin = () => {
    ElMessageBox.confirm(
        '请先登录!',
        '温馨提示:',
        {
            confirmButtonText: '去登陆',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
        .then(() => {
            go('Login')
        })
        .catch(() => {
            return
        })
}
const showPdf = (data,target='path') => {
    if(data[target]){
        const file = data[target].split(',')
        if(file.length === 1 && file[0].search('.pdf')>-1){
            return true
        }else{
            return false
        }
    }
}
const returnMenu = (data, str) => {
    let arr = []
    data.forEach(item => {
        if (item.name === str) {
            arr = item
        }
    })
    return arr
}
const returnIndex = (data, str) => {
    let ind = 0
    data.forEach((item,index) => {
        if (item.name === str) {
            ind = index
        }
    })
    return ind
}
const tools = {
    post,
    get,
    msg,
    msgError,
    confirm,
    formatTime,
    // loadScript,
    loading,
    deleteById,
    delMultiple,
    go,
    showIsLogin,
    // imgError,
    openDrawer,
    numberToLetter,
    day,
    yearMouth,
    sortFn,
    ellipsis,
    showPdf,
    returnMenu,
    returnIndex,
    limit: 20,
    props: {
        checkStrictly: true,
        label: 'name',
        value: 'id'
    }
}

export default tools
