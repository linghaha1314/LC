import axios, { AxiosResponse } from 'axios'
import { ElMessage, ElLoading } from 'element-plus'
import Cookies from "js-cookie";
type TAxiosOption = {
    baseURL: string;
    timeout: number;
}

let config
if(process.env.NODE_ENV === 'production'){
    config = {
        timeout: 120000
    }
}else{
    config = {
        baseURL: 'http://localhost:3001',
        timeout: 120000
    }
}
// let loading: any

class Http {
    // service: AxiosInstance;
    service;
    constructor(config: TAxiosOption) {
        this.service = axios.create(config)
        // const token = localStorage.getItem('token')
        /* 请求拦截  this.service.interceptors.request.use(config => config, error => Promise.reject(error))*/
        this.service.interceptors.request.use(
            // (config: any) => {
            // if(token && config.url !== 'login') {
            //     config['headers']['Authorization'] = `Bearer ${token}`
            // }
            // loading = ElLoading.service({
            //     lock: true,
            //     text: '正在加载...',
            //     spinner: 'el-icon-loading',
            //     background: 'rgba(255, 255, 255, 1)',
            // })

            // if (localStorage.getItem('token')) {
            //     (config.headers as AxiosRequestHeaders).authorization = localStorage.getItem('token') as string
            // }
            (config) => {
                const token = localStorage.getItem('token') || ''
                if(token){
                    config.headers.Authorization = `Bearer ${token}`
                }
            return config
        }, error => {
            /* 请求错误
            1. 关闭全屏loading动画
            2. 重定向到错误页
            */
            // loading.close()
            return Promise.reject(error) // 为了可以在代码中catch到错误信息
        })


        /* 响应拦截   this.service.interceptors.response.use(response => response.data, error => Promise.reject(error))*/
        this.service.interceptors.response.use((response: AxiosResponse) => {
            /*
            1. 关闭全屏loading动画
            2. 数据解密
            3. 根据 response.data.code 做不同的错误处理
            4. ……
            */
            // loading.close()
            // const data = response.data
            // const { code } = data

            // if (code !== '000000') {
            //     ElMessage.error(data.message)
            //     return Promise.reject(data)
            // }
            return response.data
        }, error => {
            // loading.close()
            ElMessage.error('请求失败',)
            return Promise.reject(error)
        })
    }
    get(url: string, params: any){
        return this.service.get(url,{
            params
        })
    }
    post(url: string, params: any, config?: any){
        return this.service.post(url, params, config)
    }
    // put<T>(url: string, params?: object, _object = {}): Promise<IResponseData<T>> {
    //     return this.service.put(url, params, _object)
    // }
    // delete<T>(url: string, params?: any, _object = {}): Promise<IResponseData<T>> {
    //     return this.service.delete(url, { params, ..._object })
    // }
}

export default new Http(config)
