<template>
  <div class="hello">
    <div class="menuTitle" style="margin-bottom: 24px">
      {{name}}
    </div>
    <div>
<!--      <div :class="[{'ac':acIndex===index},'menuItem']" v-for="(item,index) of listData" :key="item.name" @click="clickFn(item,index)">-->
<!--        {{item.name||item.title}}-->
<!--      </div>-->
      <el-tree class="tree" :data="listData" :props="defaultProps" @node-click="clickFn">
        <template #default="{ node }">
        <span class="custom-tree-node elp">
          <span class="elp" style="width: 200px;" :title="node.label">{{ node.label}}</span>
        </span>
        </template>
      </el-tree>
    </div>
  </div>
</template>

<script lang="ts">
import { toRefs, reactive } from 'vue'
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'leftMenu',
  props: {
    name: String,
    listData: Array
  },
  setup(props, context){
    const state = reactive({
      acIndex: 0,
      defaultProps: {
        children: 'children',
        label: 'name',
      }
    })
    const clickFn = (data) => {
      // state.acIndex = index
      context.emit('change',data)
    }
    return {
      ...toRefs(state),
      clickFn
    }
  }
});
</script>

<style scoped lang="less">
  .hello{
    width: 200px;
    .el-tree-node__content:hover{
      background-color: rgba(151, 75, 105, 1) !important;
    }
  }
  .menuTitle{
    height: 45px;
    line-height: 45px;
    text-align: center;
    background-color: rgba(151, 75, 105, 1);
    color: #fff;
  }
  .menuItem{
    height: 40px;
    line-height: 40px;
    text-align: center;
    &:hover{
      background-color: rgba(151, 75, 105, 1);
      color: #fff;
    }
  }
  .ac{
    border-bottom: 2px solid rgb(151, 75, 105);
    color: rgb(151, 75, 105);
  }
  .tree{
    --el-tree-node-hover-bg-color: rgba(151, 75, 105, 0.3);
    --el-font-size-base: 16px;
  }
  .custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 16px;
    padding-right: 8px;
    color: #000000;
  }
</style>
