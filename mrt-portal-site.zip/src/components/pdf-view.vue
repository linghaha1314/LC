<template>
  <div class="preview" style="width: 100%;height: 100vh">
    <iframe id="pdf" :src="source.src+'#toolbar=0'" frameborder="0" width="100%" height="650px">
    </iframe>
  </div>
</template>

<script setup lang="ts">
import {reactive, defineProps, ref} from "vue";
import { Buffer } from 'buffer'

const props = defineProps({
  pdfUrl: {
    type: String,
    default: '/attach/c77e18b0-1ffa-11e7-b036-00163e0603fa/20220730121421下肢开放性损伤-病历讨论.pptx'
  }
})
const initData = () => {
  const url = (window.location.protocol + '//' + window.location.host) || 'http://117.159.24.46:3001'
  // const url = window.location.protocol + '//' + window.location.host
  return 'http://116.63.185.184:8012/onlinePreview?url=' + encodeURIComponent(Buffer.from(url + props.pdfUrl).toString('base64'))
}

const source: any = reactive({ src: initData() })
const previewShow: any = ref(false)

const previewFn = () => {
  previewShow.value = true
}
</script>

<style lang="css" scoped>

</style>
