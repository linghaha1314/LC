<template>
  <el-form
    ref="formRef"
    :model="state.form"
    :rules="rules"
    label-position="right"
    label-width="auto"
    style="padding: 16px"
  >
    <li v-for="(dd, index) in list" :key="dd.key">
      <el-form-item
        v-if="dd.type === 'input' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key">
        <el-input
          v-model="state.form[dd.key]"
          :placeholder="'请输入' + dd.label"
          :disabled="dd.disabled"
          class="form-input"
        ></el-input>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'textarea' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <el-input
          v-model="state.form[dd.key]"
          :autosize="{ minRows: 2 }"
          :placeholder="'请输入' + dd.label"
          class="form-input"
          :style="`width: ${dd.width || '100%'};`"
          type="textarea"
        ></el-input>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'number'  && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <el-input
          v-model="state.form[dd.key]"
          :min="0"
          :placeholder="'请输入' + dd.label"
          class="form-input"
          type="number"
        ></el-input>
      </el-form-item>
      <div
        v-if="dd.type === 'slot' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))">
        <slot :name="dd.name"></slot>
      </div>
      <el-form-item
        v-if="dd.type === 'switch' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <el-switch
          v-model="state.form[dd.key]"
          :active-value="dd.activeValue || 1"
          :inactive-value="dd.inactiveValue || 0"
          active-color="#13ce66"
          class="ml-2"
        />
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'select' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <el-select
          v-model="state.form[dd.key]"
          :loading="loading"
          :multiple="dd.multiple"
          :placeholder="'请输入' + dd.label"
          class="m-2"
          filterable
          reserve-keyword
          :disabled="dd.disabled"
          @change="dd.change"
        >
          <el-option
            v-for="item in dd.options"
            :key="item.value"
            :label="item[dd.optionsLabel] || item.label || item.name"
            :value="item[dd.optionsValue] || item.value || item.id"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'cascade' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <el-cascader
          v-model="state.form[dd.key]"
          :options="dd.list"
          :placeholder="'选择' + dd.label"
          :props="dd.props || defaultProps"
          :show-all-levels="false"
          clearable
        />
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'datePiker' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >

        <el-date-picker
          v-model="state.form[dd.key]"
          type="date"
          placeholder="选择时间"
          :shortcuts="shortcuts"
        />
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'richText' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <rich-text-editor
          ref="richText"
          v-model:value="state.form[dd.key]"
        ></rich-text-editor>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'uploadImg' && (!dd.if || (dd['ifValue'] &&state.form[dd.if]===dd['ifValue']) ||(!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label"
        :prop="dd.key"
      >
        <el-upload
          :drag="true"
          :on-success="
            (...event) => {
              handleAvatarSuccess(event, dd, index)
            }
          "
          :show-file-list="false"
          action="/public/upload"
          class="avatar-uploader img-upload"
        >
          <img
            v-if="state.form[dd.key]"
            :onerror="tools.imgError(state.form[dd.key])"
            :src="state.form[dd.key]"
            alt=""
            style="height: 100%; width: inherit"
          />
          <div class="el-upload__tip">
            只能上传jpg/png文件，且不超过1M{{ state.form[dd.key] }}
          </div>
        </el-upload>
      </el-form-item>
    </li>
    <div class="btn">
      <el-button plain type="primary" @click="submit(formRef)">保存
      </el-button>
    </div>
  </el-form>
</template>

<script lang="ts" setup>
import { computed, defineEmits, defineProps, reactive, ref } from 'vue'
import { ElForm } from 'element-plus'
import tools from '@/utils/tools'
import http from '@/http/axios.ts'
import RichTextEditor from '@/components/RichTextEditor.vue'

const props: any = defineProps({
  list: {
    type: Array
  },
  isEdit: {
    type: Boolean,
    default: false
  }
})
const defaultProps = reactive({
  checkStrictly: true,
  label: 'name',
  value: 'id'
})
const loading = ref(false)
const emit = defineEmits(['submit', 'update'])
const formRef = ref(ElForm)
const rules = computed(() => {
  const ruleObj: any = {}
  props.list.forEach((res) => {
    if (res.required) {
      ruleObj[res.key] = [
        {
          required: true,
          message: '请输入' + res.label,
          trigger: 'blur'
        }
      ]
    }
  })
  return ruleObj
})
const shortcuts = [
  {
    text: '今天',
    value: new Date()
  },
  {
    text: '昨天',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24)
      return date
    }
  },
  {
    text: '一个星期前',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
      return date
    }
  }
]
const initData = () => {
  const obj: any = {}
  props.list.forEach((res) => {
    obj[res.key] = !props.isEdit
      ? res.defaultValue
      : res.value
    if (res.type === 'cascade' && res.url) {
      http[res.httpType || 'get'](res.url, res.queryParams).then((r) => {
        res.list = r.list
      })
    } else if (res.type === 'select' && res.url) {
      http[res.httpType || 'get'](res.url, res.queryParams).then((r) => {
        res.options = r.list
      })
    }
  })
  return obj
}
const state: any = reactive({ form: initData() })
const remoteMethod = (query: string, res) => {
  debugger
  if (query && res.url) {
    loading.value = true
    const search: any = {}
    search[res.searchKey || 'search'] = query
    http[res.httpType || 'get'](res.url, { ...res.queryParams, ...search } || {}).then((r) => {
      loading.value = false
      res.options = r.list
    })
  } else {
    res.options = []
  }
}
const submit = (formRef) => {
  if (!formRef) return
  formRef.validate((valid: any, fields: any) => {
    if (valid) {
      emit('submit', state.form)
    } else {
      const data: any = Object.values(fields)[0]
      tools.msg(data[0].message, 'warning')
      // 定位到找个位置的输入
    }
  })
}
const handleAvatarSuccess = (event, dd, index) => {
  // eslint-disable-next-line vue/no-mutating-props
  props.list[index].cover = URL.createObjectURL(event[1].raw)
  state.form[dd.key] = event[0].data.path
}
</script>

<style scoped>
li{
  list-style: none;
}

.form-input {
  width: 240px;
}

.btn {
  margin: 16px;
}
</style>
