<template>
  <div class="flexC" style="align-items: center;padding: 6px 8px;">
    <img style="margin-right: 18px;" src="../assets/images/u45.png" alt="image">
    <el-breadcrumb :separator-icon="ArrowRight">
      <el-breadcrumb-item v-for="(item, index) in getStore('urlList')" :key="item['path']">
        <span class="cur" @click="menuChange(item, index)">
          {{item['title']}}
        </span>
      </el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>

<script>
import { toRefs, reactive} from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
export default {
  name: "breadcrumb",
  emits: [
    'change'
  ],
  setup: function (props, ctx) {
    const {getStore, setStore} = Common()
    const state = reactive({
      urlArr: getStore('urlList')
    })

    const menuChange = (item, index) => {
      if(index!==0){
        let data = getStore('urlList')
        setStore('setUrlList',data.splice(0,index+1))
        ctx.emit('clicks', index)
      }
    }

    return {
      ...toRefs(state),
      ArrowRight,
      menuChange,
      getStore
    }
  }
}
</script>

<style scoped>

</style>
