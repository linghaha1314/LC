<template>
  <div ref='editor'></div>
</template>

<script>
import { onMounted, onBeforeUnmount, ref } from 'vue'
import WangEditor from 'wangeditor'

export default {
  name: 'app',
  props: ['value'],
  emits: ['update:value'],

  setup (props, { emit }) {
    const editor = ref()
    let instance
    onMounted(() => {
      instance = new WangEditor(editor.value)
      Object.assign(instance.config, {
        onchange () {
          emit('update:value', instance.txt.html())
        }
      })
      instance.create()
      if (props.value) {
        instance.txt.html(props.value)
      }
    })

    onBeforeUnmount(() => {
      instance.destroy()
      instance = null
    })

    return {
      editor
    }
  }
}
</script>
