<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'

export default {
  name: "News",
  components:{
  },
  setup() {
    const state = reactive({

    })

    return {
      ...toRefs(state),
    }
  }
}
</script>

<style scoped lang="less">

</style>
