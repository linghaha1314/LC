<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>

    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive,onBeforeMount } from 'vue'

import Common from '../hooks/common.js'
export default {
  name: "Curriculum-list",
  components:{},
  setup() {
    const state = reactive({
      listName: '在线课程',
      listArr: [
        {
          title: '精品课程',
          name: '精品课程',
          path: 'Curriculum-list'
        }
        // ,
        // {
        //   title: '直播课程',
        //   name: '直播课程',
        //   path: 'Curriculum-list'
        // }
      ],
      urlArr:[
        {
          name: '在线课程',
          title: '在线课程',
          path: 'Curriculum-list'
        },
        {
          name: '精品课程',
          title: '精品课程',
          path: 'Curriculum-list'
        },
      ]
    })

    const {setStore, go} = Common()

    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '在线课程',
          path: 'Curriculum-list'
        },
        {
          title: item.name,
          path: 'Curriculum-list'
        }
      ])
      go('Curriculum-list')
    }
    onBeforeMount(() => {
      setStore('setUrlList',state.urlArr)
    })

    return {
      ...toRefs(state),
      menuChange,
    }
  }
}
</script>

<style scoped lang="less">

</style>
