<template>
  <div style="padding: 30px 18px;">
    <video style="width: 100%" src="../assets/images/test.mp4" controls="controls">
    </video>
  </div>
</template>

<script>
export default {
  name: "Curriculum-play"
}
</script>

<style scoped>

</style>
