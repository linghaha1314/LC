<template>
  <div style="width: 100vw;height: 100vh; background: url('../assets/images/b1.jpg');">
    <img style="width: 100vw;height: 100vh;position: absolute;z-index: -1" src="../assets/images/b1.jpg" alt="image">
    <div class="mbox"
         style="height: 640px;position: fixed;left: 0;right: 0;bottom: 0;top: 0;margin: auto;">
      <div style="position: absolute; right: 130px;top: 0px;">
        <h2 style="color:#fff;padding: 0;margin: 0;">
          欢迎登录
        </h2>
        <h2 style="color:#fff;padding: 0;margin: 0 0 36px 0;">
          郑州人民医院三知教育一体化平台！
        </h2>
        <div style="background:#fff;padding: 36px; border-radius: 12px">
          <el-form
              ref="ruleFormRef"
              :model="formLabelAlign"
              class="demo-ruleForm"
              :rules="rules"
              :size="formSize"
              style="max-width: 344px; padding: 28px;box-sizing: border-box;"
          >
            <el-form-item prop="username" style="border: 1px solid #cccccc; padding: 12px;border-radius: 4px">
              <template #label style="vertical-align: middle">
                <div style="width: 26px;display: flex;justify-content: center;align-items: center;height: 100%">
                  <img style="width: 26px;height: 26px;" src="../assets/images/u5.png" alt="image">
                </div>
              </template>
              <el-input v-model="formLabelAlign.username"></el-input>
            </el-form-item>
            <el-form-item prop="password" style="border: 1px solid #cccccc; padding: 12px;border-radius: 4px">
              <template #label style="vertical-align: middle">
                <div style="width: 26px;display: flex;justify-content: center;align-items: center;height: 100%">
                  <img style="" src="../assets/images/u6.png" alt="image">
                </div>
              </template>
              <el-input v-model="formLabelAlign.password" type="password"></el-input>
            </el-form-item>
            <el-form-item prop="code">
              <div style="display: flex;align-items: center;">
                <el-input
                    v-model="formLabelAlign.code"
                    autocomplete="off"
                    placeholder="验证码"
                    style="width:115px"
                ></el-input>
                <span style="margin-left: 20px" @click="getVerify" v-html="svg"></span>
              </div>
            </el-form-item>
          </el-form>
          <div style="text-align: right;margin-bottom: 24px; font-size: 12px">
            <span @click="forgot">
              忘记密码?
            </span>
          </div>
          <div>
            <el-button style="width: 344px;background:rgb(151,75,105);" size="large" type="primary" @click="submitForm(ruleFormRef)">登录</el-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import {onBeforeMount, reactive, ref} from 'vue'
import http from '@/http/axios.ts'
import Common from '@/hooks/common.js'
import Cookies from "js-cookie";
import tools from '@/utils/tools.ts'
import CryptoJS from 'crypto-js'

const formSize = ref('default')
const svg = ref('default')
const svgCode = ref('default')
const formLabelAlign = reactive({
  username: '',
  password: '',
  code: ''
})
const validatorFn = (rule: any, value: any, callback: any)=>{
  if (value === '') {
    callback(new Error('请输入账号'))
  } else {
    callback()
  }
}
const validatorFn1= (rule: any, value: any, callback: any)=>{
  if (value === '') {
    callback(new Error('请输入密码'))
  } else {
    callback()
  }
}

const validatorFn2= (rule: any, value: any, callback: any)=>{
  if (value === '') {
    callback(new Error('请输入验证码'))
  }else if (value.toLowerCase !== svgCode.value.toLowerCase) {
    callback(new Error('验证码有误!'))
    getVerify()
  }else {
    callback()
  }
}

const rules = reactive({
  username: [
    {validator: validatorFn, trigger: 'blur'}
  ],
  password: [
    {validator: validatorFn1, trigger: 'blur'}
  ],
  code: [
    {validator: validatorFn2, trigger: 'blur'}
  ]
})
const {go, setStore} = Common()


const ruleFormRef = ref()

const submitForm = async (formEl) => {
  if (!formEl) return
  await formEl.validate((valid: any, fields: any) => {
    if (valid) {
      const data = formLabelAlign
      data.password = CryptoJS.AES.encrypt(data.password, 'kb12315').toString()
      http.post('login', formLabelAlign).then((res: any) => {
        if(res.success){
          setStore('setManageToken', res.token)
          Cookies.set('manage-token', res.token)
          localStorage.setItem('token',res.token)
          sessionStorage.setItem('queryId',res.id)
          sessionStorage.setItem('tabIndex', '0')
          go('Index',res)
        }else {
          tools.msgError(res.msg)
        }
      })
    } else {
      console.log('登录失败!', fields)
    }
  })
}
const getVerify = () => {
  http.get('/public/getCode',{}).then(r => {
    svg.value = r.data
    svgCode.value = r.text
  })
}
const forgot = () => {
  tools.confirm('温馨提示:', '请联系管理员重置密码!')
}
onBeforeMount(()=>{
  getVerify()
})

</script>

<style scoped>
.mbox {
  background-size: 100% 100%;
}
</style>
