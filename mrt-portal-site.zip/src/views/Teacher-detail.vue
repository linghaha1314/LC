<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24" style="padding: 14px;margin-bottom: 20px;" class="flexC betCtr">

      <div style="border: 1px solid #cccccc">
        <img style="width: 198px;height: 268px;vertical-align: middle;" src="../assets/images/fc1.jpg" alt="image">
      </div>
      <div class="flex1" style="padding: 18px;line-height: 20px;margin-left: 12px; position: relative">
        <h3 class="fs18" style="font-weight: normal;">郑书鹏</h3>
        <p class="flexC" style="margin: 14px 0 14px;color: #333333;align-items: center">
          <span>
            感染科副主任医师
          </span>
          <span style="margin-left: 24px;">
            郑州人民医院
          </span>
        </p>
        <p style="color: #9B536F;font-size: 12px; margin-bottom: 20px">
          擅长：贫血、血液系统肿瘤、出血性疾病等常规病例及疑难重症的诊断与治疗
        </p>
        <p class="ind elp2 bg242" style="line-height: 20px;padding: 10px 12px;margin-bottom: 26px;">
          大外科副主任、骨科二病区主任、副主任医师。河南省骨科学会委员，河南省脊柱微创学组副组长兼秘书长，郑州市骨科专业副主任委员，

          郑州市中西医结合副主任委员，新乡医学院兼职教授。毕业于上海第二军医大学，曾到韩国、澳大利亚威廉王子医院，儿童矫形医院
        </p>
        <div style="font-size: 14px;color: #9B536F; position:absolute;top: 10px;right: 10px;">
          分享到:
          <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;" src="../assets/images/u34.png"
               alt="image">
          <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;" src="../assets/images/u35.png"
               alt="image">
          <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;" src="../assets/images/u36.png"
               alt="image">
        </div>
      </div>

    </el-col>
    <el-col :span="24" style="padding: 0 40px 36px;">
<!--      <div class="textCnr fs18">中国人民大学培训学院第十九期医院管理高级研修班第三期课程培训在都江堰开班</div>-->
      <div style="margin: 14px 0;font-size: 18px">
        【医术】
        <span style="font-size: 14px">
          奇迹！她们重新站起来了
        </span>
      </div>
      <p class="ind" style="padding: 0 12px;">
        42岁的陈女士，患有胸椎间盘突出，并伴有不全瘫症状。她在其他医院接受治疗时，那里为她按照脊髓前动脉栓塞治疗了一个多月，却没想到出现了双下肢瘫痪症状。后来经人介绍，她来到郑州人民骨二病区治疗。

        孔笙和科室医生经过慎重考虑，严密的论证，最终决定对陈女士实施路减压植骨内固定术。手术前，张陆与其家属进行了充分沟通，告知他们因为病情拖延时间过长，做完这个手术有可能不会恢复还可能加重。但陈女士和家属认为，有希望就要试试。

        手术做得很成功，术后陈女士的肌力恢复到二级，脊柱功能已经恢复了三分之一，在床上已经可以活动。前几天，陈女士主动与张陆联系，告知他还在接受康复锻炼，现在已经可以行走，基本恢复了自理能力。

        而38岁的王女士来骨二病区治疗时，胸椎黄韧带骨化并伴有椎管狭窄，已经截瘫，而且是氟骨症患者，她的双下肢不能活动，大小便也不能自理，情况已经非常严重了。面对如此严重的患者，张陆没有退缩，而是和科室医生一起严谨地讨论，并作出风险评估，经过和病人及家属的沟通，并上报医院批准，他们决定为病人实施手术。

        王女士的手术难度很大，手术一直从上午8点持续到下午6点。术后，王女士的截瘫平面一度上升，从原来的肚脐位置上升至乳房位置，但过了五天，截瘫平面开始下降，两周后进行拆线时，截瘫平面已经下降到膝关节位置。

        出院时，王女士左右下肢都恢复了活动能力，肌力已经达到二级。如今的王女士已经能够站起来了，张陆和其他医生都感到非常欣慰。

        奇迹！她们重新站起来了

        管理系统
      </p>
      <div style="margin: 14px 0;font-size: 18px">
        【医德】
        <span style="font-size: 14px">
          让患者利益最大化
        </span>
      </div>
      <p class="ind">
        目前科室开展的“内窥镜下有限减压结合经皮椎弓根钉内固定”技术，为众多腰椎疾患者带来了福音。

        孔笙介绍，这种手术方式是将内镜技术与经皮置钉技术相结合，通过后路椎间盘镜进行腰椎间盘摘除，椎管减压，并采用经皮椎弓根螺钉系统进行行复位和内固定，来达到微创腰椎管减压、复位和内固定的效果。

        “该技术最大优势是在保证手术效果的前提下，最大程度地减少创伤，患者术后恢复快，一周左右就可下床活动。”张陆说，正因为恢复快，不仅降低了卧床并发症的发生率，更最大限度减轻了患者的负担。手术适合腰椎间盘突出、腰椎管狭窄、腰椎滑脱的患者，尤其适合于身体条件欠佳、不宜长期卧床的老年患者。

        截止目前，骨二病区已经进行此类微创联合手术10余例，患者的术后效果都十分良好，后期，复查和电话随访的满意度也达到100%。

        让患者利益最大化
</p>
      <div style="margin: 14px 0;font-size: 18px">
        【医声】
      </div>
      <span style="font-size: 14px;color: #333333">
         问：骨二病区成立不久，却发展迅速，各项指标均名列全院前茅，你在管理上有什么经验与大家分享？
      </span>
      <p class="ind">

        孔笙：首先我注意提高大家积极性，加强团队意识，增强责任心，树立爱心，学会关心，提倡奉献精神，心往一处想，劲往一处使。其次，严格执行考勤制度，每位医生每天必须到岗，关注自己负责的病人，每个病人做手术当天，主管医生必须到手术室，及时与主刀医生沟通病人情况。其次，制定了比较科学和切合本科室实际的奖惩制度，有利于提高科室人员的积极性。
      </p>
      <span style="font-size: 14px;color: #333333">
         问：骨二病区成立不久，却发展迅速，各项指标均名列全院前茅，你在管理上有什么经验与大家分享？
      </span>
      <br>
      <p class="ind">
        孔笙：我个人对患者一直抱着一种负责的态度，也把这种思想传达给科室人员，对每一位患者都关心和呵护，了解他们的心理变化，给予他们最科学的治疗方案，争取让他们花最少的钱就把病看好。所以，这么多年来，我的患者后来与我都成为朋友，他们总是会主动与我联系，告知现状，并与我探讨将来的治疗方向。总之，我认为只有医生切实为患者利益考虑，让患者利益最大化，这才能成就个人的成长和科室的发展。
      </p>
    </el-col>
    <el-col :span="24" style="padding-top: 22px;font-size: 14px">
      <div style="color: #9B536F;font-size: 16px; border-bottom: 1px solid rgb(121,121,121); padding: 12px;margin-bottom: 14px">
        科室医生
      </div>
     <div class="flexC betCtr">
       <div class="flexC betCtr" style="width: 48%;border:1px solid rgb(121,121,121);margin: 16px 0;" v-for="item in 4" :key="item">
         <img style="width: 164px;height: 100%;vertical-align: middle;" src="../assets/images/fc1.jpg" alt="image">
         <div class="flex1" style=" padding: 0 12px;line-height: 20px;margin-left: 12px;">
           <h3 class="fs18" style="font-weight: normal;">郑书鹏</h3>
           <p class="flexC" style="margin: 14px 0 14px;color: #333333;align-items: center">
          <span>
            感染科副主任医师
          </span>
             <span style="margin-left: 24px;">
            郑州人民医院
          </span>
           </p>
           <p class="" style="margin-bottom: 26px;height: 100px;overflow: auto">
             大外科副主任、骨科二病区主任、副主任医师。河南省骨科学会委员，河南省脊柱微创学组副组长兼秘书长，郑州市骨科专业副主任委员，

             郑州市中西医结合副主任委员，新乡医学院兼职教授。毕业于上海第二军医大学，曾到韩国、澳大利亚威廉王子医院，儿童矫形医院
           </p>
           <div class="rightAlign">
             <el-button color="#974b69" plain @click="goDetail">查看详情</el-button>
           </div>
         </div>
       </div>
     </div>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'

export default {
  name: "Teacher-detail",
  components:{

  },
  setup() {
    const state = reactive({

    })
    const goDetail = ()=>{
      window.scroll(0,0)
    }

    return {
      ...toRefs(state),
      goDetail
    }
  }
}
</script>

<style scoped lang="less">

</style>
