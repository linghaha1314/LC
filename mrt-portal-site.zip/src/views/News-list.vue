<template>
  <div class="flexC">
    <left-menu :name="listName" :listData="listArr" @change="menuChange"></left-menu>
    <div class="flex1" style="margin-left: 22px;">
      <div class="flexC" style="align-items: center; border-bottom: 1px solid rgb(121,121,121);padding: 6px 8px;">
        <breadcrumb @clicks="changeFn"></breadcrumb>

        <div class="flex1" style="text-align: right">
          共
          <span style="font-size: 18px;color: #D9001B;">
                {{total}}
              </span>
          条
        </div>
      </div>
      <el-row v-if="!isDetail" :gutter="0" justify="space-between" style="padding: 10px;">
        <el-col v-if="list.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</el-col>
        <el-col :span="24" style="background:rgb(242,242,242);padding: 14px;margin-bottom: 20px;" class="flexC" v-for="item in list" :key="item.id">
          <div v-if="item.img&&item.img!==''" style="position: relative;width: 191px;height: 129px;">
            <img style="width: 191px;height: 129px;" :src="item.img||'../assets/images/u53.png'" alt="image">
            <img v-if="item<4" style="position: absolute;right: 0;top: 0;" src="../assets/images/u54.png" alt="new">
          </div>
          <div class="flex1" style="padding: 18px;line-height: 20px; width: 70%;" @click="goDetail(item)">
            <p style="margin-bottom: 12px;width: 99%" class="elp">
              {{ item.name }}
            </p>
            <p class="ind elp2" style="line-height: 20px" v-html="tools.ellipsis(item.content, 180)">
            </p>
          </div>
        </el-col>
        <el-col :span="24" class="rightAlign">
          <el-pagination background layout="prev, pager, next" :total="total" @current-change="changePage">
          </el-pagination>
        </el-col>
      </el-row>

      <NewsDetail v-else
                  :data="currentData"
                  :nextBefore="nextBefore"
                  @dataClick="nextBeforeClick"
      ></NewsDetail>
    </div>
  </div>
</template>

<script>
import {toRefs, reactive, onBeforeMount, watch} from 'vue'
import LeftMenu from '@/components/leftMenu.vue'
import Breadcrumb from '@/components/breadcrumb.vue'
import NewsDetail from './News-detail'
import Common from '../hooks/common.js'
import http from '../http/axios.ts'
import tools from '../utils/tools.ts'
import {useRoute} from 'vue-router'
export default {
  name: "News-list",
  components:{
    LeftMenu,
    Breadcrumb,
    NewsDetail
  },
  setup() {
    const state = reactive({
      listName: '新闻信息',
      listArr: [
        {
          title: '新闻资讯',
          path: 'news'
        },
        {
          title: '新闻资讯',
          path: 'news'
        },
        {
          title: '新闻资讯',
          path: 'news'
        },
        {
          title: '新闻资讯',
          path: 'news'
        }
      ],
      urlArr: [
        {
          title: '新闻信息',
          path: 'News-list'
        },
        {
          title: '新闻资讯',
          path: 'News-list'
        }
      ],
      isDetail: false,
      params: {
        limit: 10,
        offset: 0,
        status: 1,
        typeId: '',
        sort:'created desc'
      },
      currentData: {},
      list:[],
      total: 50,
      nextBefore: []
    })
    const {setStore,getStore,getParams} = Common()
    const goDetail = (item)=>{
      setStore('setUrlList',[
        ...getStore('urlList'),
        {
          title: '详情',
          path: item.id
        }
      ])
      state.currentData = item
      state.isDetail = true
      getNextBefore(item)
    }
    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '新闻信息',
          path: 'News-list'
        },
        {
          title: item.name,
          path: item.id
        }
      ])
      state.params.typeId = item.id
      getLinkList('/message/getListByPage', 'list')
    }
    const getLinkList = (url, target, cb) => {
      if (state.params.typeId === '') {
        delete state.params.typeId
      }
      http.get(url, state.params).then(res => {
        state[target] = res.list
        state.total = parseInt(res.total)
        if (cb) cb()
      })
    }
    // 点击通用函数
    const changeFn = (ind)=>{
      if (ind === 1){
        state.isDetail = false
      }else if(ind === 2){
        state.isDetail = true
      }
    }
    const getNextBefore = (data)=>{
      http.post('/message/getBeforeNext',{
        id: data.sequence,
        typeId: data.typeId
      }).then(res => {
        state.nextBefore = res.data
      })
    }
    const nextBeforeClick = (data)=>{
      state.currentData = data
      getNextBefore(data)
    }
    const changePage = (data)=>{
      state.params.offset = state.params.limit*(data-1)
      getLinkList('/message/getListByPage', 'list')
    }
    const route = useRoute()
    watch(()=> route.params,(val) => {
      state.currentData = val
    })
    onBeforeMount(() => {
      const data = getParams()
      if(data.id){
        let arr = tools.returnMenu(getStore('menus'),data.dataIndex)
        sessionStorage.setItem('leftList', JSON.stringify(arr))
        state.currentData = data
        getNextBefore(data)
        state.isDetail = true
        state.listArr.forEach(item => {
          if(item.id === data.typeId){
            state.urlArr[1].title = item.name
            state.params.typeId = item.id
            getLinkList('/message/getListByPage', 'list')
          }
        })
      }
      if(data.data){
        sessionStorage.setItem('leftList', data.data)
      }
      state.listArr = tools.sortFn(JSON.parse(sessionStorage.getItem('leftList')).children)
      if(state.currentData.id){
        state.listArr.forEach(item => {
          if(item.id === state.currentData.typeId){
            state.urlArr[1].title = item.name
            state.params.typeId = item.id
            getLinkList('/message/getListByPage', 'list')
          }
        })
      }else{
        const queryData = JSON.parse(sessionStorage.getItem('leftList'))
        state.params.typeId = state.listArr[0].id
        state.urlArr[1].title = state.listArr[0].name
        state.urlArr[0].title = queryData.name
        getLinkList('/message/getListByPage', 'list')
      }
      setStore('setUrlList', state.urlArr)
    })
    return {
      ...toRefs(state),
      goDetail,
      changeFn,
      nextBeforeClick,
      menuChange,
      changePage,
      tools
    }
  }
}
</script>

<style scoped lang="less">

</style>
