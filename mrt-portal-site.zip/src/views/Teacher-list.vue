<template>
  <div class="flexC">
    <el-dialog
        v-if="isSetRole"
        v-model="isSetRole"
        :append-to-body="false"
        :destroy-on-close="true"
        title="科室选择"
        width="60%"
    >
      <el-input
          v-model="sectionName"
          class="w-50 m-2"
          placeholder="搜索科室名"
          :prefix-icon="Search"
          @blur="searchSection"
      />
      <el-tree style="min-width: 170px" :data="optionList" :props="props" @node-click="clickFn"/>
    </el-dialog>
    <left-menu :name="listName" :listData="listArr" @change="menuChange"></left-menu>
    <div class="flex1" style="margin-left: 22px;">
      <div class="flexC" style="align-items: center; border-bottom: 1px solid rgb(121,121,121);padding: 6px 8px;">
        <breadcrumb @clicks="changeFn"></breadcrumb>
      </div>
      <el-row v-if="!isDetail" :gutter="0" justify="space-between" style="padding: 10px;">
        <el-col :span="24">
          <div style="padding: 14px;" class="flexC">
            <span class="el-dropdown-link flexC ardCtr"
                  style="border: 1px solid #797979;width: 167px;height: 44px;line-height: 44px;text-align: center;border-radius: 6px;margin-right: 28px;"
                  @click="showDrop">
          <span ref="sectionRef">
            {{ checkName }}
          </span>
          <svg class="icon" width="14" height="14" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"
               data-v-042ca774=""><path fill="currentColor"
                                        d="M104.704 338.752a64 64 0 0190.496 0l316.8 316.8 316.8-316.8a64 64 0 0190.496 90.496L557.248 791.296a64 64 0 01-90.496 0L104.704 429.248a64 64 0 010-90.496z"></path></svg>
        </span>
            <!--            <el-dropdown trigger="click">-->
            <!--        <span class="el-dropdown-link flexC ardCtr"-->
            <!--              style="border: 1px solid #797979;width: 167px;height: 44px;line-height: 44px;text-align: center;border-radius: 6px;margin-right: 28px;" @click="showDrop">-->
            <!--          <span ref="sectionRef">-->
            <!--            全部学科-->
            <!--          </span>-->
            <!--          <svg class="icon" width="14" height="14" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg"-->
            <!--               data-v-042ca774=""><path fill="currentColor"-->
            <!--                                        d="M104.704 338.752a64 64 0 0190.496 0l316.8 316.8 316.8-316.8a64 64 0 0190.496 90.496L557.248 791.296a64 64 0 01-90.496 0L104.704 429.248a64 64 0 010-90.496z"></path></svg>-->
            <!--        </span>-->

            <!--              <template #dropdown>-->
            <!--                <el-tree style="min-width: 170px" :data="optionList" :props="props" @node-click="clickFn"/>-->
            <!--              </template>-->
            <!--            </el-dropdown>-->
            <!--            <el-tree-select v-model="params.typeId" :data="optionList" :props="props" />-->
            <el-input
                v-model="input2"
                size="large"
                style="width: 430px"
                placeholder="请输入关键字搜索"
                :suffix-icon="Search"
                @blur="searchFn"
            />
          </div>
        </el-col>
        <div v-if="list.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
        <el-col :span="24" style="padding: 14px;margin-bottom: 20px;" class="flexC betCtr" v-for="item in list"
                :key="item.id">

          <div style="width: 164px;height: 216px;border: 1px solid #cccccc">
            <img style="width: 164px;height: 216px;vertical-align: middle;"
                 :src="item['photo']||'../assets/images/fc1.jpg'" alt="image">
          </div>
          <div class="flex1" style="padding: 18px;line-height: 20px;margin-left: 12px;">
            <h3 class="fs18" style="font-weight: normal;">{{ item.name }}</h3>
            <p class="flexC" style="margin: 14px 0 14px;color: #333333;align-items: center">
          <span>
            {{ item.title }}
          </span>
              <span style="margin-left: 24px;">
            {{ item['hospital'] }}
          </span>
            </p>
            <p class="ind elp2 bg242" style="line-height: 20px;padding: 0 12px;margin-bottom: 26px;">
              {{ item['content'] }}
            </p>
            <div class="rightAlign">
              <el-button color="#974b69" plain @click="goDetail(item)">进入主页</el-button>
            </div>
          </div>

        </el-col>
        <el-col :span="24" class="rightAlign">
          <el-pagination background layout="prev, pager, next" :total="total" @current-change="changePage">
          </el-pagination>
        </el-col>
      </el-row>
      <el-row v-else :gutter="0" justify="space-between" style="padding-top: 28px;">
        <el-col :span="24" style="padding: 14px;margin-bottom: 20px;" class="flexC betCtr">

          <div style="width: 198px;height: 268px;border: 1px solid #cccccc">
            <img style="width: 198px;height: 268px;vertical-align: middle;"
                 :src="currentData['photo']||'../assets/images/fc1.jpg'" alt="image">
          </div>
          <div class="flex1" style="padding: 18px;line-height: 20px;margin-left: 12px; position: relative">
            <h3 class="fs18" style="font-weight: normal;">{{ currentData.name }}</h3>
            <div v-if="sectionInfo" style="margin: 14px 0 14px;color: #333333;align-items: center">
              科室:
              {{ sectionInfo['name'] || '无' }}
            </div>
            <p class="flexC" style="margin: 14px 0 14px;color: #333333;align-items: center">
            <span>
            {{ currentData['title'] }}
          </span>

            <span style="margin-left: 24px;">
            {{ currentData['hospital'] }}
          </span>
            </p>
            <!--            <p style="color: #9B536F;font-size: 12px; margin-bottom: 20px">-->
            <!--              擅长：贫血、血液系统肿瘤、出血性疾病等常规病例及疑难重症的诊断与治疗-->
            <!--            </p>-->
            <p class="ind bg242" style="line-height: 20px;padding: 10px 12px;margin-bottom: 26px;">
              {{ currentData['content'] }}
            </p>
            <!--            <div style="font-size: 14px;color: #9B536F; position:absolute;top: 10px;right: 10px;">-->
            <!--              分享到:-->
            <!--              <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;"-->
            <!--                   src="../assets/images/u34.png"-->
            <!--                   alt="image">-->
            <!--              <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;"-->
            <!--                   src="../assets/images/u35.png"-->
            <!--                   alt="image">-->
            <!--              <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;"-->
            <!--                   src="../assets/images/u36.png"-->
            <!--                   alt="image">-->
            <!--            </div>-->
          </div>

        </el-col>
        <el-col :span="24" style="padding: 0 40px 36px;">
          <!--      <div class="textCnr fs18">中国人民大学培训学院第十九期医院管理高级研修班第三期课程培训在都江堰开班</div>-->
          <div v-html="currentData['detail']">
          </div>

        </el-col>
        <el-col :span="24" style="padding-top: 22px;font-size: 14px">
          <div
              style="color: #9B536F;font-size: 16px; border-bottom: 1px solid rgb(121,121,121); padding: 12px;margin-bottom: 14px">
            科室医生
          </div>
          <div class="flexC betCtr">
            <div v-if="listSection.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
            <div class="flexC betCtr" style="width: 48%;border:1px solid rgb(121,121,121);margin: 16px 0;"
                 v-for="item in listSection" :key="item">
              <div style="width: 164px;height: 242px;">
                <img style="width: 164px;height: 242px;vertical-align: middle;"
                     :src="item['photo']||'../assets/images/fc1.jpg'"
                     alt="image">
              </div>
              <div class="flex1" style=" padding: 0 12px;line-height: 20px;margin-left: 12px;">
                <h3 class="fs18" style="font-weight: normal;">{{ item.name }}</h3>
                <div class="flexC" style="margin: 14px 0 14px;color: #333333;align-items: center">
                  <div class="elp" style="width: 50%;" :title="item.title">
                    {{ item.title }}
                  </div>
                  <div class="elp" style="width: 50%" :title="item['hospital']">
                    {{ item['hospital'] }}
                  </div>
                </div>
                <p class="" style="margin-bottom: 26px;height: 100px;overflow: auto">
                  {{ item['content'] }}
                </p>
                <div class="rightAlign">
                  <el-button color="#974b69" plain @click="goDetail(item, true)">查看详情</el-button>
                </div>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>

    </div>
  </div>

</template>

<script>
import {toRefs, reactive, onBeforeMount, ref} from 'vue'
import LeftMenu from '@/components/leftMenu.vue'
import Breadcrumb from '@/components/breadcrumb.vue'
import http from '../http/axios.ts'
import Common from '../hooks/common.js'
import {Search} from '@element-plus/icons-vue'
import tools from '../utils/tools.ts'

export default {
  name: "Teacher-list",
  components: {
    LeftMenu,
    Breadcrumb
  },
  setup() {
    const sectionRef = ref()
    const state = reactive({
      isSetRole: false,
      listName: '院内风采',
      listArr: [
        {
          id: '',
          title: '教师风采',
          path: '/Teacher/Teacher-list'
        },
        {
          id: '',
          title: '导师风采',
          path: '/Teacher/Teacher-list'
        }
      ],
      urlArr: [
        {
          title: '院内风采',
          path: 'Teacher-list'
        },
        {
          title: '教师风采',
          path: 'Teacher-list'
        },
      ],
      params: {
        limit: 10,
        offset: 0,
        status: 1,
        typeId: '',
        sort:'created desc'
      },
      input2: '',
      list: [],
      optionList: [],
      dataList: [],
      listSection: [],
      total: 10,
      isDetail: false,
      currentData: {},
      props: {
        checkStrictly: true,
        label: 'name',
        value: 'id'
      },
      checkName: '全部科室',
      sectionInfo: {},
      sectionName: ''
    })
    const {setStore, getStore, getParams} = Common()
    const menuChange = (item) => {
      state.isDetail = false
      setStore('setUrlList', [
        {
          title: '院内风采',
          path: 'Teacher-list'
        },
        {
          title: item.name,
          path: item.id
        }
      ])
      state.params.typeId = item.id
      state.checkName = "全部科室"
      delete state.params.sectionId
      getLinkList('/teacher_style/getListByPage', 'list')
    }
    // 跳转详情页
    const goDetail = (item, section) => {
      if (!section) {
        setStore('setUrlList', [
          ...getStore('urlList'),
          {
            title: '详情',
            path: 'Teacher-detail'
          }
        ])
      }
      state.currentData = item
      state.isDetail = true
      getSection(item.sectionId)
      sectionTeacher()
      window.scroll(0, 0)
    }
    const getLinkList = (url, target, param, cb) => {
      if (state.params.typeId === '') {
        delete state.params.typeId
      }
      if (state.params.sectionId === '') {
        delete state.params.sectionId
      }
      http.get(url, param || state.params).then(res => {
        state[target] = res.list
        state.total = parseInt(res.total)
        cb && cb()
      })
    }
    const changePage = (data) => {
      state.params.offset = state.params.limit * (data - 1)
      getLinkList('/teacher_style/getListByPage', 'list')
    }
    const changeFn = (ind) => {
      if (ind === 1) {
        state.isDetail = false
      } else if (ind === 2) {
        state.isDetail = true
      }
    }
    const clickFn = (data) => {
      state.isSetRole = false
      state.params.sectionId = data.id
      state.checkName = data.name
      getLinkList('/teacher_style/getListByPage', 'list', state.params)
    }
    const showDrop = () => {
      // sectionRef.value.click()
      state.isSetRole = true
    }
    const searchFn = () => {
      state.params.name = state.input2
      getLinkList('/teacher_style/getListByPage', 'list')
    }
    const sectionTeacher = () => {
      http.get('/teacher_style/getListByPage', { // 获取科室老师
        limit: 4,
        sectionId: state.currentData.sectionId || null
      }).then(res => {
        state.listSection = res.list
      })
    }
    const getSection = (id) => {
      http.post('/section/getDataById', {
        id
      }).then(res => {
        state.sectionInfo = res.data || {}
      })
    }
    const searchSection = () => {
      let arr = []
      state.dataList.forEach(item => {
        if(item.name.search(state.sectionName)!==-1){
          arr.push(item)
        }
      })
      state.optionList = arr
    }
    onBeforeMount(() => {
      const data = getParams()
      if (data.id) {
        // let arr = tools.returnMenu(getStore('menus'),data.dataIndex)
        let arr = tools.returnMenu(getStore('menus'), data.dataIndex)
        sessionStorage.setItem('leftList', JSON.stringify(arr))
        state.currentData = data
        state.isDetail = true
        state.listArr.forEach(item => {
          if (item.id === data.typeId) {
            state.urlArr[1].title = item.name
            state.params.typeId = item.id
            getLinkList('/teacher_style/getListByPage', 'list')
          }
        })
        getSection(data.sectionId)
        sectionTeacher()
      }
      if (data.data) {
        sessionStorage.setItem('leftList', data.data)
      }
      state.listArr = tools.sortFn(JSON.parse(sessionStorage.getItem('leftList')).children)
      if (state.currentData.id) {
        state.listArr.forEach(item => {
          if (item.id === state.currentData.typeId) {
            state.urlArr[1].title = item.name
            state.params.typeId = item.id
            getLinkList('/teacher_style/getListByPage', 'list')
          }
        })
      } else {
        const queryData = JSON.parse(sessionStorage.getItem('leftList'))
        state.params.typeId = state.listArr[0].id
        state.urlArr[1].title = state.listArr[0].name
        state.urlArr[0].title = queryData.name
        getLinkList('/teacher_style/getListByPage', 'list')
      }
      setStore('setUrlList', state.urlArr)
      http.get('/section/getListByPage', {
        limit: 999
      }).then(res => {
        state.optionList = [
          {
            id: '',
            name: '全部科室'
          },
          ...res.list
        ]
        state.dataList = [
          {
            id: '',
            name: '全部科室'
          },
          ...res.list
        ]
      })

    })
    return {
      ...toRefs(state),
      Search,
      goDetail,
      changePage,
      menuChange,
      changeFn,
      showDrop,
      searchFn,
      clickFn,
      searchSection
    }
  }
}
</script>

<style scoped lang="less">

</style>
