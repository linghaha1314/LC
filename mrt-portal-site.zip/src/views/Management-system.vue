<template>
  <el-row :gutter="0" style="padding: 72px 0;">
    <div class="flexC betCtr" style="width: 100%">
      <div v-if="info.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
      <div class="item" style="width: 30%;border: 1px solid #cccccc" v-for="item in info" :key="item.name" @click="goLogin(item)">
        <img style="width: 100%;height: 218px;vertical-align: middle;" :src="item.src" alt="image">
        <div style="height: 52px; color: #974B69;line-height: 52px;padding: 0 16px;font-size: 18px" class="bg242">{{item.name}}</div>
      </div>

    </div>
  </el-row>
</template>

<script>
import {toRefs, reactive, onBeforeMount} from 'vue'
// import Common from '../hooks/common.js'
export default {
  name: "Index",
  setup() {
    const state = reactive({
      urlArr: {
        study: {
          out: 'http://117.159.24.46:3001/#/client/home',
          into: 'http://172.16.10.53:3001/#/client/home'
        },
        zhuPei: {
          out: 'http://117.159.24.46:64001/',
          into: 'http://172.16.10.53:64001'
        },
        exam: {
          out: 'http://117.159.24.46:8201',
          into: 'http://172.16.10.53:8201'
        }
      },
      currentNet: 'into',
      info:[
        {
          name: '住院医师规范化培训管理系统',
          url: 'zhuPei',
          src: '/images/i1.png'
        },
        {
          name: '在线考试管理系统',
          url: 'exam',
          src: '/images/i2.png'
        },
        {
          name: '在线学习',
          url: 'study',
          src: '/images/i3.png'
        }
      ]
    })
    // const {go} = Common()
    const goLogin = (data)=>{
      window.open(state.urlArr[data.url][state.currentNet])
    }
    onBeforeMount(() => {
      state.currentNet = window.location.hostname === '117.159.24.46' ? 'out' : 'into'
    })
    return {
      ...toRefs(state),
      goLogin
    }
  }
}
</script>

<style scoped lang="less">

.item:hover{
  box-shadow: 6px 6px 6px 0 rgba(68,66,66,0.75);
  -webkit-box-shadow: 6px 6px 6px 0 rgba(68,66,66,0.75);
  -moz-box-shadow: 6px 6px 6px 0 rgba(68,66,66,0.75);
}
</style>
