<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24" style="border-bottom: 1px dashed #ccc;padding: 0 40px 36px;">
      <div class="textCnr fs18">{{data.name}}</div>
      <div class="textCnr" style="margin: 14px 0;font-size: 13px">来源： {{`${data.source}  ${data.author}`}}   时间：{{tools.formatTime(data.time, 'YY-MM-DD')}}</div>
      <p class="ind" v-html="data.content">
      </p>
<!--      <pdf-view v-if="tools.showPdf(data)" :pdfUrl="data['path'].split(',')[0]"></pdf-view>-->
      <iframe v-if="tools.showPdf(data)" :src="data['path']+'#toolbar=0'" frameborder="0" width="100%" height="650px"></iframe>
      <div v-if="data['path']" style="font-size: 12px; margin-top: 30px;">
        <div v-for="item in data['path'].split(',')" :key="item">
          附件:
          <span style="font-size: 12px">
            {{item && item.split('/')[item.split('/').length-1] || '无'}}
          </span>
          <pdf-preview :pdfUrl="item" :isDownload="data.isDownload || 1"></pdf-preview>
        </div>
      </div>
    </el-col>
    <el-col :span="24" style="padding-top: 22px;font-size: 14px">
      <div style="margin: 8px;"  v-if="nextBefore[0]" @click="dataClick(nextBefore[0])">
        {{(nextBefore.length === 1 && data['sequence'] > nextBefore[0]['sequence']) ? '下一篇:' : '上一篇:'}}
        <span style="margin-left: 8px;" class="cur">
          {{nextBefore[0]['name'] || '无'}}
        </span>
      </div>
      <div style="margin: 8px;" v-if="nextBefore[1]" @click="dataClick(nextBefore[1])">
        下一篇:
        <span style="margin-left: 8px;" class="cur">
          {{nextBefore[1]['name'] || '无'}}
        </span>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'
import tools from '../utils/tools.ts'
import PdfPreview from "../components/pdf-preview";
// import PdfView from "../components/pdf-view";

export default {
  name: "News-detail",
  props:{
    data: {
      type: Object
    },
    nextBefore: {
      type: Object
    }
  },
  emits: [
    'dataClick'
  ],
  components:{
    // PdfView,
    PdfPreview
  },
  setup(prop, ctx) {
    const state = reactive({

    })
    const dataClick = (data)=>{
      ctx.emit('dataClick',data)
    }
    return {
      ...toRefs(state),
      dataClick,
      tools
    }
  }
}
</script>

<style scoped lang="less">

</style>
