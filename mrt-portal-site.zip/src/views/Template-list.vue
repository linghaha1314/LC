<template>
  <div class="flexC" style="margin-top: 28px;">
    <left-menu :name="queryData.name" :listData="listArr" @change="menuChange"></left-menu>
    <div class="flex1" style="margin-left: 22px;width: 82%">
      <div class="flexC" style="align-items: center; border-bottom: 1px solid rgb(121,121,121);padding: 6px 8px;">
        <breadcrumb @clicks="changeFn"></breadcrumb>
      </div>
      <el-row v-if="isDetail === false && isType!=='公益活动' && isType!=='继续教育'" :gutter="0" justify="space-between"
              style="padding: 10px;">
        <el-col :span="24" style="margin-bottom: 20px;">
          <div>
            <div v-if="list.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
            <div v-for="(item,index) in list" :key="index+item" class="callItem">
              <div class="flexC"
                   style=" height: 62px;padding: 0 12px;border-bottom: 1px dashed #cccccc;align-items: center">
                <div class="bg242 boxSing fs13"
                     style="position: relative;width: 108px;height: 40px;line-height: 40px;text-indent: 6px;">
                  <div class="flexC" style="color: #333333">
                    {{ tools.yearMouth(item.created) }}
                    <span class="colorC" style="font-size: 17px">
                  {{ tools.day(item.created) }}
                </span>
                  </div>
                  <img v-if="index<4" style="position: absolute;right: 0;top: 0;width: 24px;height: 24px"
                       src="../assets/images/u54.png" alt="new">
                </div>
                <div class="fs13" style="margin-left: 20px;" @click="goDetail(item)">
                  {{ item.name }}
                </div>
              </div>
            </div>
          </div>
        </el-col>
        <el-col :span="24" class="rightAlign">
          <el-pagination v-model="params.offset" background layout="prev, pager, next" :total="total"
                         @current-change="changePage">
          </el-pagination>
        </el-col>
      </el-row>
      <TeachingListCommonweal v-else-if="isDetail === false && isType==='公益活动'"
                              :data="list"
                              :total="total"
                              @goDetail="goDetail"
      ></TeachingListCommonweal>
      <el-row v-else-if="isDetail === false && isType==='继续教育'" :gutter="0" justify="space-between"
              style="padding-top: 28px;">
        <a v-for="item in aArr" :key="item.name" :href="item.path" target="_blank" class="flexCol ardCtr"
           style="width: 30%;text-align: center">
          <div>
            <img :src="item.src" :alt="item.name||'无'">
          </div>
          <div>
            {{ item.name }}
          </div>
        </a>
      </el-row>
      <el-row v-else :gutter="0" justify="space-between" style="padding-top: 28px;">
        <el-col :span="24" style="border-bottom: 1px dashed #ccc;padding: 0 40px 36px;">
          <div class="textCnr fs18" v-if="currentData.name">{{ currentData.name }}</div>
          <div class="textCnr" style="margin: 14px 0;font-size: 13px">来源：
            {{ `${currentData['source'] || '未知'}  ${currentData['author'] || ''}` }} &nbsp; &nbsp;&nbsp;
            时间：{{ tools.formatTime(currentData['time'], 'YY-MM-DD') }}
          </div>
          <p class="ind" v-html="currentData['content']">
          </p>
          <pdf-view v-if="false" :pdfUrl="currentData['path'].split(',')[0]"></pdf-view>
          <iframe v-if="tools.showPdf(currentData)" :src="currentData['path']+'#toolbar=0'" frameborder="0" width="100%" height="650px"></iframe>
          <div v-if="currentData['path']" style="font-size: 12px; margin-top: 30px;">
            <div v-for="item in currentData['path'].split(',')" :key="item">
              附件:
              <span style="font-size: 12px">
            {{ item && item.split('/')[item.split('/').length - 1] || '无' }}
          </span>
              <pdf-preview :pdfUrl="item" :isDownload="currentData && currentData.isDownload || 1"></pdf-preview>
            </div>
          </div>
        </el-col>
        <el-col :span="24" style="padding-top: 22px;font-size: 14px">
          <div style="margin: 8px;" v-if="nextBefore[0]" @click="nextBeforeClick(nextBefore[0])">
            {{ (nextBefore.length === 1 && currentData['sequence'] > nextBefore[0]['sequence']) ? '下一篇:' : '上一篇:' }}
            <span style="margin-left: 8px;" class="cur">
              {{ nextBefore[0]['name'] || '无' }}
            </span>
          </div>
          <div style="margin: 8px;" v-if="nextBefore[1]" @click="nextBeforeClick(nextBefore[1])">
            下一篇:
            <span style="margin-left: 8px;" class="cur">
              {{ nextBefore[1]['name'] || '无' }}
            </span>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>

</template>

<script>
import {toRefs, reactive, onBeforeMount} from 'vue'
import LeftMenu from '@/components/leftMenu.vue'
import Breadcrumb from '@/components/breadcrumb.vue'
import PdfPreview from "../components/pdf-preview";
import PdfView from "../components/pdf-view";
import http from '../http/axios.ts'
import TeachingListCommonweal from './Teaching-list-commonweal'
import Common from '../hooks/common.js'
import tools from '../utils/tools.ts'

export default {
  name: "Teaching-list",
  components: {
    LeftMenu,
    Breadcrumb,
    TeachingListCommonweal,
    PdfView,
    PdfPreview
  },
  setup() {
    const state = reactive({
      listName: '无',
      listArr: [],
      urlArr: [
        {
          title: '教学动态',
          path: 'message-list'
        },
        {
          title: '教学介绍',
          path: 'message-list'
        },
      ],
      showInd: 0,
      isDetail: false,
      params: {
        limit: 10,
        offset: 0,
        status: 1,
        typeId: '',
        sort:'created desc'
      },
      total: 10,
      list: [],
      currentData: {},
      isType: '',
      nextBefore: [],
      queryData: {},
      aArr: [
        {
          src: '/images/c_xx.png',
          name: '河南省继续教育学习平台',
          path: 'https://yuancheng.henanyixue.com/'
        },
        {
          src: '/images/c_gl.png',
          name: '河南省继续教育管理平台',
          path: 'https://cme.henanyixue.com/login'
        },
        {
          src: '/images/c_xx.png',
          name: '学分查询',
          path: 'https://cme.henanyixue.com/home/creditInquiry.html'
        }
      ]
    })
    const {setStore, getStore, getParams} = Common()
    const menuChange = (item) => {
      state.isDetail = false
      setStore('setUrlList', [
        {
          title: state.queryData.name,
          path: state.queryData.id
        },
        {
          title: item.name,
          path: item.id
        }
      ])
      state.params.typeId = item.id
      state.isType = item.name
      getLinkList('/message/getListByPage', 'list')
    }
    const goDetail = (item) => {
      setStore('setUrlList', [
        ...getStore('urlList'),
        {
          title: '详情',
          path: 'Teaching-detail'
        }
      ])
      state.currentData = item
      state.isDetail = true
      getNextBefore(item)
    }
    const changeFn = (ind) => {
      if (ind === 1) {
        state.isDetail = false
      } else if (ind === 2) {
        state.isDetail = true
      }
    }
    const getLinkList = (url, target, param) => {
      if (state.params.typeId === '') {
        delete state.params.typeId
      }
      http.get(url, param || state.params).then(res => {
        state[target] = res.list
        state.total = parseInt(res.total)
      })
    }
    const getNextBefore = (data) => {
      http.post('/message/getBeforeNext', {
        id: data.sequence,
        typeId: state.params.typeId
      }).then(res => {
        state.nextBefore = res.data
      })
    }
    const nextBeforeClick = (data) => {
      state.currentData = data
      getNextBefore(data)
    }
    const changePage = (data) => {
      state.params.offset = state.params.limit * (data - 1)
      getLinkList('/message/getListByPage', 'list')
    }
    onBeforeMount(() => {
      const data = getParams()
      if (data.data) {
        sessionStorage.setItem('leftList', data.data)
      }
      state.listArr = tools.sortFn(JSON.parse(sessionStorage.getItem('leftList')).children)
      state.queryData = JSON.parse(sessionStorage.getItem('leftList'))
      if (state.listArr.length === 0) {
        state.params.typeId = state.queryData.id
        state.urlArr[1].title = '无'
      } else {
        state.params.typeId = state.listArr[0].id
        state.urlArr[1].title = state.listArr[0].name
      }

      state.urlArr[0].title = state.queryData.name
      if (state.listArr.length === 0) {
        setStore('setUrlList', [
          {
            title: state.queryData.name,
            path: state.queryData.id
          }
        ])
      } else {
        setStore('setUrlList', state.urlArr)
      }

      getLinkList('/message/getListByPage', 'list')

    })
    return {
      ...toRefs(state),
      menuChange,
      changePage,
      goDetail,
      changeFn,
      nextBeforeClick,
      getParams,
      tools
    }
  }
}
</script>

<style scoped lang="less">
.iconS {

  width: 20px;
  height: 20px;
}

.callItem:not(:first-child) {
  margin-top: 28px;
}

.callItem:hover {
  background-color: rgba(151, 75, 105, 1);
  color: #fff;
}
</style>
