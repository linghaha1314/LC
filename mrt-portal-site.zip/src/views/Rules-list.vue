<template>
  <div class="flexC">
    <left-menu :name="listName" :listData="listArr" @change="menuChange"></left-menu>
    <div class="flex1" style="margin-left: 22px;width: 82%">
      <div class="flexC" style="align-items: center; border-bottom: 1px solid rgb(121,121,121);padding: 6px 8px;">
        <breadcrumb @clicks="changeFn"></breadcrumb>
      </div>
      <el-row v-if="!isDetail" :gutter="0" justify="space-between" style="padding: 10px;">

        <el-col v-if="isFirst" :span="24" style="margin-bottom: 20px;">
          <div style="margin-top: 20px;">
            <div v-if="list.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
            <div v-for="(item,index) in list" :key="index" class="callItem">
              <div v-if="showInd !== parseInt(index)" class="flexC betCtr"
                   style=" height: 62px;background:rgb(242,242,242);padding: 0 12px;" @click="showInd = index">
                <div>
                  {{ item.name }}
                </div>
                <Icon icon="Plus" class="iconS cur"></Icon>
              </div>
              <div v-else class="animate__fadeInUp" style="width: 100%;background:rgb(151,75,105); color: #ffffff">
                <div class="flexC betCtr" style="height: 62px;padding: 0 12px">
                  <div>
                    {{ item.name }}
                  </div>
                  <Icon icon="Close" class="iconS cur"></Icon>
                </div>
                <p class="ind" style="padding: 0 30px 14px;line-height: 34px;" v-html="item.content">
                </p>
              </div>
            </div>
          </div>
        </el-col>
        <el-col v-if="!isFirst" :span="24" style="margin-bottom: 20px;">
          <div>
            <div v-if="list.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
            <div v-for="(item,index) in list" :key="index" class="callItem" @click="goDetail(item)">
              <div class="flexC"
                   style=" height: 62px;padding: 0 12px;border-bottom: 1px dashed #cccccc;align-items: center">
                <div class="bg242 boxSing fs13"
                     style="position: relative;width: 108px;height: 40px;line-height: 40px;text-indent: 6px;">
                  <div class="flexC" style="color: #333333">
                    {{ tools.yearMouth(item.time) }}
                    <span class="colorC" style="font-size: 17px">
                  {{ tools.day(item.time) }}
                </span>
                  </div>
                  <img v-if="index<4" style="position: absolute;right: 0;top: 0;width: 24px;height: 24px"
                       src="../assets/images/u54.png" alt="new">
                </div>
                <div class="fs13" style="margin-left: 20px;">
                  {{ item.name }}
                </div>
              </div>
            </div>
          </div>
        </el-col>
        <el-col :span="24" class="rightAlign">
          <el-pagination background layout="prev, pager, next" :total="total" @current-change="changePage">
          </el-pagination>
        </el-col>
      </el-row>
      <RulesDetail v-else
                   :data="currentData"
                   :nextBefore="nextBefore"
                   @dataClick="nextBeforeClick"
      ></RulesDetail>
    </div>
  </div>
</template>

<script>
import {toRefs, reactive, onBeforeMount} from 'vue'
import LeftMenu from '@/components/leftMenu.vue'
import Breadcrumb from '@/components/breadcrumb.vue'
import http from '../http/axios.ts'
import RulesDetail from './Rules-detail'
import Common from '../hooks/common.js'
import tools from '../utils/tools.ts'

export default {
  name: "Rules-list",
  components: {
    LeftMenu,
    Breadcrumb,
    RulesDetail
  },
  setup() {
    const state = reactive({
      listName: '规范性文件',
      listArr: [
        {
          title: '院内制度',
          path: 'Rules'
        },
        {
          title: '政策制度',
          path: 'Rules'
        }
      ],
      urlArr: [
        {
          title: '规范性文件',
          path: '/Rules/Rules-list'
        },
        {
          title: '院内制度',
          path: '/Rules/Rules-list'
        },
      ],
      showInd: 0,
      list: [],
      params: {
        limit: 10,
        offset: 0,
        status: 1,
        typeId: '',
        sort:'created desc'
      },
      total: 10,
      currentData: {},
      isDetail: false,
      isFirst: false,
      nextBefore: []
    })
    const {setStore, getStore, getParams} = Common()
    const goDetail = (item) => {
      setStore('setUrlList', [
        ...getStore('urlList'),
        {
          title: '详情',
          path: item.id
        }
      ])
      state.currentData = item
      state.isDetail = true
      getNextBefore(item)
    }
    const menuChange = (item) => {
      state.isDetail = false
      setStore('setUrlList', [
        {
          title: '规范性文件',
          path: 'Rules-list'
        },
        {
          title: item.name,
          path: item.id
        }
      ])
      // if (item.name === '院内制度') {
      //   state.isFirst = true
      // } else {
      //   state.isFirst = false
      // }
      state.params.typeId = item.id
      getLinkList('/regulations/getListByPage', 'list')
    }
    const changePage = (data) => {
      state.params.offset = state.params.limit * (data - 1)
      getLinkList('/regulations/getListByPage', 'list')
    }
    const changeFn = (ind) => {
      if (ind === 1) {
        state.isDetail = false
      } else if (ind === 2) {
        state.isDetail = true
      }
    }
    const getLinkList = (url, target, param) => {
      if (state.params.typeId === '') {
        delete state.params.typeId
      }
      http.get(url, param || state.params).then(res => {
        state[target] = res.list
        state.total = parseInt(res.total)
      })
    }
    const getNextBefore = (data) => {
      http.post('/regulations/getBeforeNext', {
        id: data.sequence,
        typeId: data.typeId
      }).then(res => {
        state.nextBefore = res.data
      })
    }
    const nextBeforeClick = (data) => {
      state.currentData = data
      getNextBefore(data)
    }
    onBeforeMount(() => {
      const data = getParams()
      if (data.id) {
        let arr = tools.returnMenu(getStore('menus'),data.dataIndex)
        sessionStorage.setItem('leftList', JSON.stringify(arr))
        state.currentData = data
        getNextBefore(data)
        state.isDetail = true
        state.listArr.forEach(item => {
          if (item.id === data.typeId) {
            state.urlArr[1].title = item.name
            state.params.typeId = item.id
            getLinkList('/regulations/getListByPage', 'list')
          }
        })
      }
      if (data.data) {
        sessionStorage.setItem('leftList', data.data)
      }
      state.listArr = tools.sortFn(JSON.parse(sessionStorage.getItem('leftList')).children)
      if (state.currentData.id) {
        state.listArr.forEach(item => {
          if (item.id === state.currentData.typeId) {
            state.urlArr[1].title = item.name
            state.params.typeId = item.id
            getLinkList('/regulations/getListByPage', 'list')
          }
        })
      } else {
        const queryData = JSON.parse(sessionStorage.getItem('leftList'))
        state.params.typeId = state.listArr[0].id
        state.urlArr[1].title = state.listArr[0].name
        state.urlArr[0].title = queryData.name
        getLinkList('/regulations/getListByPage', 'list')
      }
      setStore('setUrlList', state.urlArr)
    })
    return {
      ...toRefs(state),
      goDetail,
      changePage,
      menuChange,
      changeFn,
      nextBeforeClick,
      tools
    }
  }
}
</script>

<style scoped lang="less">
.iconS {
  width: 20px;
  height: 20px;
}

.callItem:not(:first-child) {
  margin-top: 28px;
}
</style>
