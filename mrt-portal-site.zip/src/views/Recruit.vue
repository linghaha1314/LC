<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>


    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive, onBeforeMount } from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
export default {
  name: "Recruit",
  components:{},
  setup() {
    const {setStore, getSubList, go} = Common()
    const state = reactive({
      listName: '招生培训',
      listArr: [
        {
          title: '招生信息',
          path: 'Rules'
        },
        {
          title: '培训信息',
          path: 'Rules'
        }
      ],
      urlArr:[
        {
          title: '招生培训',
          path: 'Recruit-list'
        },
        {
          title: '招生信息',
          path: 'Recruit-list'
        },
      ]
    })

    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '招生培训',
          path: 'Recruit-list'
        },
        {
          title: item.name,
          path: 'Recruit-list'
        }
      ])
      go('Recruit-list')
    }
    getSubList('Enrollment-training').then(res=>{
      state.listArr = res.list
    })
    onBeforeMount(() => {
      setStore('setUrlList', state.urlArr)
    })

    return {
      ...toRefs(state),
      menuChange,
      ArrowRight
    }
  }
}
</script>

<style scoped lang="less">

</style>
