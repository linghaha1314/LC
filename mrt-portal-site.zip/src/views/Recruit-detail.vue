<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24" style="border-bottom: 1px dashed #ccc;padding: 0 40px 36px;">
      <div class="textCnr fs18">中国人民大学培训学院第十九期医院管理高级研修班第三期课程培训在都江堰开班</div>
      <div class="textCnr" style="margin: 14px 0;font-size: 13px">来源： 四川省医院协会 陈林    时间：2018-07-25 09:39:35</div>
      <p class="ind">
        7月20日至21日，由中国人民大学培训学院和四川省医院协会联合举办的第十九期医院管理高级研修班第三期课程培训在都江堰开班，中国人

        民大学培训学院高端培训班主任胡治峰、四川省医院协会副会长兼秘书长郎永康、济川药业集团总经理周其华等领导出席开班式并讲话。来自省内

        省、市、县（区）公立医院院长及医院管理人员共200余人参加学习。四川省医院协会县级医院工委会秘书长李春主持开班式。

        来源： 四川省医院协会 陈林    时间：2018-07-25 09:39:35

        首位讲者是来自美国爱荷华大学医院及健康管理博士、中国医药大学（台湾）医务管理学系暨硕士班教授马作镪作了“医院全面质量管理”专题

        讲授，从医院管理三部曲到全面质量管理和实施模式等方面，进行了深入浅出的讲解。他的讲授既有提升医疗质量的理论深度，又联系实际可学习

        借鉴，深受学员们的欢迎。

        北京大学汇丰商学院·公司培育决策顾问陈建忠教授以“认知革命与人生进化”为题作了讲授，从文化的内涵讲到科学管理和认知命运并把握命运

        的方法，分析了从古至今很多案例，他的讲解使在场学员学有所获，不仅启迪思维，还更新认知。

        这次高级研修班是以帮助会员单位医院管理者提升医院理论水平和实践能力为目的，着重学习台湾地区医院持续改进医疗质量，保障医疗安全

        等方面取得的成功做法和成熟经验，借助现代医院管理的新理念、新方法、新工具，促进我省公立医院高质量发展
      </p>
    </el-col>
    <el-col :span="24" style="padding-top: 22px;font-size: 14px">
      <div style="margin: 8px;">
        上一篇:
        <span style="margin-left: 8px;" class="cur">
          “两新联系村，党建助振兴” 行动 四川省医院协会吹响健康扶贫集结号
        </span>
      </div>
      <div style="margin: 8px;">
        下一篇:
        <span style="margin-left: 8px;" class="cur">
          医保经办•医院医保管理对话论坛在雅安成功举办
        </span>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'


export default {
  name: "News-detail",
  components:{
  },
  setup() {
    const state = reactive({

    })

    return {
      ...toRefs(state),
    }
  }
}
</script>

<style scoped lang="less">

</style>
