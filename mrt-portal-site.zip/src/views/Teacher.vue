<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>


    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive, onBeforeMount } from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
export default {
  name: "News",
  components:{},
  setup() {
    const state = reactive({
      listName: '院内风采',
      listArr: [
        {
          title: '教师风采',
          path: '/Teacher/Teacher-list'
        },
        {
          title: '导师风采',
          path: '/Teacher/Teacher-list'
        }
      ],
      urlArr:[
        {
          title: '院内风采',
          path: 'Teacher-list'
        },
        {
          title: '教师风采',
          path: 'Teacher-list'
        },
      ]
    })

    const {setStore, getSubList, go} = Common()

    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '院内风采',
          path: 'Teacher-list'
        },
        {
          title: item.name,
          path: 'Teacher-list'
        }
      ])
      go('Teacher-list')
    }

    getSubList('Teacher-style').then(res=>{
      state.listArr = res.list
    })

    onBeforeMount(() => {
      setStore('setUrlList', state.urlArr)
    })
    return {
      ...toRefs(state),
      menuChange,
      ArrowRight
    }
  }
}
</script>

<style scoped lang="less">

</style>
