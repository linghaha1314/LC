<template>
  <el-row :gutter="0" justify="space-between" style="padding: 10px;">
    <div v-if="data.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
    <el-col :span="24" style="padding: 14px;margin-bottom: 20px;" class="flexC betCtr" v-for="item in data" :key="item">
      <div style="color: #333333;text-align: right;margin-right: 14px;">
        <div class="fs24" style="font-weight: bold;">
          {{tools.day(item.created)}}
        </div>
        {{tools.yearMouth(item.created)}}
      </div>
      <div style="position: relative;border: 1px solid rgb(151,75,105);margin-top: 6px;">
        <div style="width: 196px;height: 163px;position: relative;right: -14px;top: -14px">
          <img style="width: 196px;height: 163px;vertical-align: middle;" :src="item['photo']||'../assets/images/u30.jpg'" alt="image">
        </div>
      </div>
      <div class="flex1" style="padding: 18px;line-height: 20px;margin-left: 12px;">
        <p style="margin-bottom: 12px;color: #333333;">
          {{item.name}}
        </p>
        <p class="ind elp2 bg242" style="line-height: 20px;margin: 10px 12px 26px;padding: 0 12px;" v-html="tools.ellipsis(item.content, 180)">

        </p>
        <div class="rightAlign">
          <span style="color: #974B69;" @click="goDetail(item)">
            详情 >>
          </span>
        </div>
      </div>

    </el-col>
    <el-col :span="24" class="rightAlign">
      <el-pagination background layout="prev, pager, next" :total="total">
      </el-pagination>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'
import tools from '../utils/tools.ts'

export default {
  name: "Teaching-list",
  props:{
    data:{
      type: String
    },
    total:{
      type: Number
    }
  },
  emits:[
    'goDetail'
  ],
  components:{
  },
  setup(props,ctx) {
    const state = reactive({

    })
    const goDetail = (item) => {
      ctx.emit('goDetail',item)
    }
    return {
      ...toRefs(state),
      goDetail,
      tools
    }
  }
}
</script>

<style scoped lang="less">

</style>
