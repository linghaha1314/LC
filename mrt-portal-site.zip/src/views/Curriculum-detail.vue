<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24" style="padding: 14px;margin-bottom: 20px;" class="flexC betCtr">

      <div style="border: 1px solid #cccccc">
        <img style="width: 307px;height: 276px;vertical-align: middle;" :src="data.path||'../assets/images/u15.png'" alt="image">
      </div>
      <div class="flex1" style="padding: 18px;line-height: 20px;margin-left: 12px;">
        <div class="flexC betCtr">
          <p class="flexC flexCol" style="margin: 14px 0 14px;color: #333333;">
            <span>
              {{data.name}}
            </span>
            <span style="font-size: 12px;color: #333333">
              直播时间：{{tools.formatTime(data.create, 'YY-MM-DD hh:mm:ss')}}
            </span>
          </p>
          <div style="font-size: 12px;color: #D9001B;">
            74人参加
          </div>
          <div style="font-size: 14px;color: #9B536F;">
            分享到:
            <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;" src="../assets/images/u34.png"
                 alt="image">
            <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;" src="../assets/images/u35.png"
                 alt="image">
            <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;" src="../assets/images/u36.png"
                 alt="image">
          </div>
        </div>
        <p class="ind bg242" style="line-height: 20px;padding: 10px 12px;margin-bottom: 14px;" v-html="data['content']">

        </p>
        <div class="rightAlign">
          <img v-if="true" style="width: 24px;height: 24px;vertical-align: middle;" src="../assets/images/u59.png"
               alt="image">
          <img v-else style="width: 24px;height: 24px;vertical-align: middle;" src="../assets/images/u60.png"
               alt="image">
        </div>
        <div class="flexC">
          <div class="btnStyle rl" @click="playV(data)">免费试看</div>
          <div class="btnStyle rr">立即报名</div>
        </div>
      </div>

    </el-col>
    <el-col :span="16" style="padding: 0 40px 36px;">
      <div>
        <div class="flexC" style="border-bottom: 1px solid #333333;width: 100%;">
          <div :class="['menu',{'ac':acIndex===0}]" @click="tabFn(0)">课程目录</div>
          <div :class="['menu',{'ac':acIndex===1}]" @click="tabFn(1)">课程评价</div>
        </div>
        <div style="padding: 20px 10px" v-if="acIndex===0">
          <div v-if="hour.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div :class="['flexC','betCtr','ke',{'ac':acInd===index}]" style="font-size: 12px;padding: 12px;margin-bottom: 10px;" v-for="(item, index) in hour" :key="index" @click="playV(item)">
            <div>
              课时{{index+1}}
            </div>
            <div>
              {{item.name}}
            </div>
            <div class="flexC betCtr">
              {{tools.formatTime(data.created, 'YY-MM-DD hh:mm:ss')}}
              <img style="width: 16px;height: 16px;vertical-align: middle;margin-left: 6px;" src="../assets/images/u44.png" alt="image">
            </div>
          </div>
        </div>
        <div style="padding: 20px 10px" v-else>
          <div class="content">
            <div class="title-box">
              评分:
              <div style="padding: 12px 0"><el-rate v-model="comment.score"></el-rate></div>
            </div>
            <div class="comment-box">
              评价:
              <el-input
                  v-model="comment.content"
                  :rows="2"
                  type="textarea"
                  placeholder="请输入评价..."
                  style="padding: 12px 0"
              />
            </div>
            <div class="btn-box rightAlign" style="margin: 12px 0;">
              <el-button type="primary" @click="sendComment">评价</el-button>
            </div>
          </div>
          <div v-if="hour.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div :class="['flexC','betCtr','ke',{'ac':acInd===index}]" style="font-size: 12px;padding: 12px;margin-bottom: 10px;" v-for="(item, index) in hour" :key="index" @click="playV(item)">
            <div>
              评价 {{index+1}}
            </div>
            <div class="flexC betCtr">
              {{tools.formatTime(data.created, 'YY-MM-DD hh:mm:ss')}}
              <!--              <img style="width: 16px;height: 16px;vertical-align: middle;margin-left: 6px;" src="../assets/images/u44.png" alt="image">-->
            </div>
            <div>
              {{item.name}}
            </div>

          </div>
        </div>
      </div>
    </el-col>
    <el-col :span="8" style="padding: 0 40px 36px;">
      <div>
        <div class="flexC" style="border-bottom: 1px solid #333333;width: 100%;">
          <div class="menu">
            <img style="width: 24px;height: 18px;vertical-align: middle;margin-left: 6px;" src="../assets/images/u58.png" alt="image">
            相关课程
          </div>
        </div>
        <div class="flexC flexCol ardCtr" style="margin-top: 20px;">
          <div v-if="hour.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div style="width: 256px;margin-bottom: 20px;" v-for="item in hour" :key="item" @click="goDetail(item)">
            <img style="width: 256px;height: 126px;vertical-align: middle;" :src="item.path||'../assets/images/u61.png'" alt="image">
            <div class="flexC betCtr bg242" style="width: 256px;box-sizing: border-box;padding: 10px;margin-right: 0;">
              <p class="flexC flexCol" style="width: 78%;line-height: 20px">
                <span style="width: 99%;color: #333333;font-size: 14px" class="elp" :title="item.name">
                  {{ item.name || '脊柱疼痛微创诊疗技术进展研讨会' }}
                </span>
                  <span style="font-size: 10px;color: #333333">
                  直播时间：2021-04-24 08:00:00
                </span>
              </p>
              <div style="font-size: 12px;color: #D9001B;">
                74人参加
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import {toRefs, reactive} from 'vue'

import tools from '../utils/tools.ts'
import Common from '../hooks/common.js'
import http from '../http/axios.ts'

export default {
  name: "News-detail",
  components: {},
  props:{
    data:{
      type: Object
    }
  },
  emits: [
      'goPlay'
  ],
  setup(props, ctx) {
    const state = reactive({
      acInd: 0,
      acIndex: 0,
      currentData: {},
      comment: {
        content: '',
        score: 0
      },
      hour: []
    })
    const {setStore, getStore} = Common()
    const playV = (item)=>{
      setStore('setUrlList',[
        ...getStore('urlList'),
        {
          title: '播放',
          path: 'Curriculum-play'
        }
      ])
      ctx.emit('goPlay',item)
    }
    const goDetail = ()=>{
      window.scroll(0,0)
    }
    const getHour = ()=>{
      http.get('/curriculum_hour/getListByPage',{
        limit: 10,
        status: 1,
        curriculumId: props.data['id']
      }).then(res => {
        state.hour = res.list
      })
    }
    const tabFn = (ind)=>{
      state.acIndex = ind
    }
    const sendComment = ()=>{
      // state.acIndex = ind
    }
    getHour()
    return {
      ...toRefs(state),
      playV,
      goDetail,
      tabFn,
      sendComment,
      tools
    }
  }
}
</script>

<style scoped lang="less">
.btnStyle {
  width: 150px;
  height: 44px;
  text-align: center;
  line-height: 44px;
  border: 1px solid #9B536F;
  color: #9B536F;
  &:hover{
    background: #9B536F;
    color: #ffffff;
  }
}
.rr{
  border-radius: 0 22px 22px 0;
}
.rl{
  border-radius: 22px 0 0 22px;
}
.menu{
  width: 110px;
  height: 40px;
  text-align: center;
  line-height: 40px;
  box-sizing: border-box;
  border: 1px solid #ffffff;
  &:hover{
    border: 1px solid #9B536F;
    color: #9B536F;
  }
  &.ac{
    background: #9B536F;
    color: #ffffff;
    border: 1px solid #9B536F;
  }
}
.ke{
  &:hover{
    background: #9B536F;
    color: #ffffff;
  }
  &.ac{
    background: #9B536F;
    color: #ffffff;
  }
}
</style>
