<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
export default {
  name: "Download",
  components:{},
  setup() {
    const state = reactive({
      listName: '资料下载',
      listArr: [
        {
          name: '文档资料',
          path: 'Download'
        },
        {
          name: '其他资料',
          path: 'Download'
        }
      ],
      urlArr:[
        {
          title: '资料下载',
          path: '/Download/Download-list'
        },
        {
          title: '文档资料',
          path: '/Download/Download-list'
        },
      ],
      code: 'Download-file'
    })
    const {setStore, go} = Common()

    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '资料下载',
          path: 'Download-list'
        },
        {
          title: item.name,
          path: 'Download-list'
        }
      ])
      go('Download-list')
    }
    return {
      ...toRefs(state),
      menuChange,
      ArrowRight
    }
  }
}
</script>

<style scoped lang="less">

</style>
