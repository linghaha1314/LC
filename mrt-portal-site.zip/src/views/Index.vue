<template>
  <el-row :gutter="0" justify="center">
    <el-col :span="13" style="margin-top: 20px;padding-right: 10px">
      <div style="margin-top: 40px;">
        <h3 class="textCnr title">
          教学安排
        </h3>
        <div class="textCnr fs24 m5">
          Teaching arrangement
        </div>
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
      <div style="margin-top: 20px;">
        <div v-if="training.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
        <div v-for="(item, index) in training" :key="item" class="callItem"
             @click="goList('Recruit-list','教学安排', {...item,dataIndex: '教学安排'})">
          <div class="flexC betCtr bg242" style="padding: 0 12px;">
            <div class="flexC" style="padding: 0 12px;align-items: center">
              <div class="bg242 boxSing fs13"
                   style="position: relative;width: 108px;height: 40px;line-height: 40px;text-indent: 6px;border-right: 1px solid #cccccc">
                <div class="flexC color3">
                  {{ tools.formatTime(item.created) }}
                </div>
                <img v-if="index<2" style="position: absolute;right: 0;top: 0;width: 24px;height: 24px"
                     src="../assets/images/u54.png" alt="new">
              </div>
              <div class="flex1" style="font-size: 12px;font-weight: bold;padding-left: 20px">
                {{ item.name }}
              </div>
            </div>
          </div>
          <!--          <div style="background:rgb(151,75,105); color: #ffffff">-->
          <!--            <div class="flexC betCtr" style="height: 62px;padding: 0 12px">-->
          <!--              <div>-->
          <!--                郑州人民医院博士后科研工作站招聘公告-->
          <!--              </div>-->
          <!--              <Icon icon="Close" class="iconS"></Icon>-->
          <!--            </div>-->
          <!--            <p class="ind" style="padding: 0 30px 14px;line-height: 34px;">-->
          <!--              医院科研教学实力强大。作为河南中医药大学人民医院，承担河南中医药大学、南方医科大学、郑州大学、新乡医学院等高校博士生、硕士生、本科生等的教学任务，是国家住院医师规范化培训基地。拥有省级院士专家工作站、省级博士后研发基地，有省市重点实验室7个，省市级临床研究所5个。医院拥有医学研究中心、医学教育中心，提升科研水平，培养医护人才。-->
          <!--            </p>-->
          <!--          </div>-->
        </div>
      </div>
    </el-col>
<!--    <el-col :span="13" style="margin-top: 20px;margin-right: 30px;">-->
<!--      <div style="margin-top: 40px;">-->
<!--        <h3 class="textCnr title">-->
<!--          教学动态-->
<!--        </h3>-->
<!--        <div class="textCnr fs24 m5">-->
<!--          Teaching trends-->
<!--        </div>-->
<!--        <div class="flexC betCtr w230 blcCnr">-->
<!--          <div class="line"></div>-->
<!--          <div class="box"></div>-->
<!--          <div class="line"></div>-->
<!--        </div>-->
<!--      </div>-->
<!--      <div style="margin-top: 20px;">-->
<!--        <div v-if="teaching.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>-->
<!--        <div v-for="(item, index) in teaching" :key="item" class="callItem"-->
<!--             @click="goList('Teaching-list',1, {...item,dataIndex: 1})">-->
<!--          <div class="flexC betCtr bg242" style="padding: 0 12px;">-->
<!--            <div class="flexC" style="padding: 0 12px;align-items: center">-->
<!--              <div class="bg242 boxSing fs13"-->
<!--                   style="position: relative;width: 108px;height: 40px;line-height: 40px;text-indent: 6px;border-right: 1px solid #cccccc">-->
<!--                <div class="flexC color3">-->
<!--                  {{ tools.formatTime(item.created) }}-->
<!--                </div>-->
<!--                <img v-if="index<2" style="position: absolute;right: 0;top: 0;width: 24px;height: 24px"-->
<!--                     src="../assets/images/u54.png" alt="new">-->
<!--              </div>-->
<!--              <div class="flex1" style="font-size: 12px;font-weight: bold;padding-left: 20px">-->
<!--                {{ item.name }}-->
<!--              </div>-->
<!--            </div>-->
<!--          </div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </el-col>-->
    <el-col :span="10" class="flexCol ardCtr" style="margin-top: 20px;padding-right: 10px">
      <div style="margin-top: 40px;width: 100%;">
        <h3 class="textCnr title">
          平台入口
        </h3>
        <div class="textCnr fs24 m5">
          platform entrance
        </div>
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
      <div style="width: 100%;margin: 16px 0;">
        <div style="border:1px solid rgba(215, 215, 215, 1);">
<!--          <img style="width:100%" src="../assets/images/u146.jpg" alt="image">-->
          <div class="flexC ardCtr colorW flexW g-box" style="height: 284px;padding: 10px;">
            <a style="width: 45%;color: #ffffff;" :href="urlArr.study[currentNet]" target="_blank">
              <el-button class="btn-shd"
                         style="width: 100%;min-height: 102px;border-radius:16px;font-size: 20px;margin: 0;color: #ffffff"
                         color="#852c4f" size="large">在线学习
              </el-button>
            </a>
            <a style="width: 45%;color: #ffffff;" :href="urlArr.exam[currentNet]" target="_blank">
              <el-button class="btn-shd"
                         style="width: 100%;min-height: 102px;border-radius:16px;font-size: 20px;margin: 0;color: #ffffff"
                         color="#d4b981" size="large" @click="goLogin">在线考试管理系统
              </el-button>
            </a>
            <el-button class="btn-shd"
                       style="width: 45%;
                       min-height: 102px;
                       border-radius:16px;
                       font-size: 20px;
                       margin: 0;"
                       type="primary"
                       size="large"
                       @click="linksInto"
            >科研管理系统
            </el-button>
<!--            <a style="width: 45%;color: #ffffff;" href="http://172.16.10.79/userAction!to_login.action" target="_blank">-->
<!--              -->
<!--            </a>-->
            <a style="width: 45%;color: #ffffff !important;" :href="urlArr.zhuPei[currentNet]" target="_blank">
              <el-button class="btn-shd"
                         style="width: 100%;color: #ffffff;min-height: 102px;border-radius:16px;font-size: 20px;margin: 0;text-wrap: normal" color="#00cc00" size="large">住院医师规范化
                <br>
                培训管理系统
              </el-button>
            </a>
          </div>
        </div>
      </div>
    </el-col>
    <el-col :span="24">
      <div style="margin-top: 40px;">
        <h3 class="textCnr title">
          新闻信息
        </h3>
        <div class="textCnr fs24 m5">
          hot news
        </div>
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
    </el-col>
    <el-col :span="24" style="border: 1px solid #cccccc;margin-top: 24px; padding-bottom: 20px">
      <div class="flexC betCtr">
        <div :class="['tab', 'textCnr', {'ac':index===tabIndex}]" v-for="(item, index) in messageType" :key="index"
             @click="clickTab(item,index)">
          {{ item.name }}
        </div>
      </div>
      <el-row justify="center" style="width: 100%;">
        <el-col :span="10"
                style="height: 552px; margin-top: 20px;border: 2px solid rgba(242, 242, 242, 1);margin-right: 30px; background: rgb(241,251,253);padding: 20px;"
                @click="goList('News-list','新闻信息',{...messageDetail, dataIndex: '新闻信息'})">
          <img v-if="messageDetail['img'] && messageDetail['img'] !== ''" style="width:100%;height: 360px;" :src="messageDetail['img']" alt="image">
          <div class="lineH40 p12" style="overflow: auto; height: calc(100% - 360px)">
            <div class="subtitle">
              {{ messageDetail.name || '一封温暖的信——致敬白衣天使' }}
            </div>
            <div>
              <p class="ind elp2" style="font-size: 14px">
                {{ messageDetail['content'] && tools.ellipsis(messageDetail['content']) }}
              </p>
            </div>
          </div>
        </el-col>
        <el-col :span="13" style="height: 552px;margin-top: 20px;overflow-y:hidden;overflow-x:hidden">
          <div v-if="message.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div class="flexC newItem" v-for="item in message" :key="item"
               @click="goList('News-list','新闻信息', {...item,dataIndex: '新闻信息'})">
            <div class="flexC flexCol wh96 ardCtr colorW" style="padding: 3px 0;">
              <img :src="'/images/'+tabImg[tabIndex%7]" alt="无图片">
            </div>
            <div class="flex1 bg242" style="width: calc(100% - 96px); height: 96px;position: relative">
              <div class="color3 p16">
                <div class="flexC betCtr">
                  <div class="elp" style="width: 60%;">
                    {{item.name || '郑医郑东院区承办郑州市第219期全民急救技能普及培训------------------------------------' }}
                  </div>
                  <div>
                    {{tools.formatTime(item.created)}}
                  </div>
                </div>
                <div class="elp">
                  {{ item['content'] && tools.ellipsis(item['content']) }}
                </div>
              </div>
              <div class="flexC pos">
                <div class="three">
                </div>
              </div>
              <!--            <img style="width: 23px;position: absolute;bottom: 2px;right: 2px;" src="../assets/images/u50.png" alt="image">-->
            </div>
          </div>
        </el-col>
      </el-row>
    </el-col>
    <el-col :span="12">
      <div style="margin-top: 40px;">
        <h3 class="textCnr title">
          第五临床医学院
        </h3>
        <div class="textCnr fs24 m5">
          medical college
        </div>
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
      <div style="margin-top: 20px; justify-content: space-between" class="flexC">
        <div style="width: 76px; height: 462px; margin-right: 12px;overflow-y: auto">
          <div style="width: 76px;height: 18%;margin-bottom: 4px;font-weight: bold;text-align: center"
               :class="['flexC', 'ardCtr', 'item-box', {'ac':index===fiveIndex}]" v-for="(item, index) in fiveType"
               :key="item" @click="clickItem(item,index, true)">
            {{ item.name }}
          </div>
        </div>
        <div class="flex1" style="height: 100%" v-if="messageF">
          <div v-if="messageF.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div v-for="item in messageF" :key="item" class="callItem"
               @click="goList('Template-list','第五临床医学院', {...item,dataIndex: '第五临床医学院'})">
            <div class="flexC betCtr" style="min-height: 40px;border:1px solid #cccccc;padding: 0 12px;">
              <div>
                {{ item.name }}
              </div>
              <!--              <Icon icon="Plus" class="iconS"></Icon>-->
            </div>
          </div>
        </div>
      </div>
<!--      <div style="height: 552px;margin-top: 20px;overflow-y:hidden;overflow-x:hidden">-->
<!--        <div v-if="messageF.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>-->
<!--        <div class="flexC newItem" v-for="item in messageF" :key="item"-->
<!--             @click="goList('News-list',8, {...item,dataIndex: 8})">-->
<!--          <div class="flexC flexCol wh96 ardCtr colorW" style="padding: 3px 0;">-->
<!--            <img src="/images/zpgl.png" alt="图片加载失败">-->
<!--          </div>-->
<!--          <div class="flex1 bg242" style="width: calc(100% - 96px); height: 96px;position: relative">-->
<!--            <div class="color3 p16">-->
<!--              <div class="flexC betCtr">-->
<!--                <div class="elp" style="width: 60%;">-->
<!--                  {{item.name || '郑医郑东院区承办郑州市第219期全民急救技能普及培训&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;' }}-->
<!--                </div>-->
<!--                <div>-->
<!--                  {{tools.formatTime(item.created)}}-->
<!--                </div>-->
<!--              </div>-->
<!--              <div class="elp">-->
<!--                {{ item['content'] && tools.ellipsis(item['content']) }}-->
<!--              </div>-->
<!--            </div>-->
<!--            <div class="flexC pos">-->
<!--              <div class="three">-->
<!--              </div>-->
<!--            </div>-->
<!--            &lt;!&ndash;            <img style="width: 23px;position: absolute;bottom: 2px;right: 2px;" src="../assets/images/u50.png" alt="image">&ndash;&gt;-->
<!--          </div>-->
<!--        </div>-->
<!--      </div>-->
    </el-col>
    <el-col :span="12" style="padding-left: 10px">
      <div style="margin-top: 40px;">
        <h3 class="textCnr title">
          规范性文件
        </h3>
        <div class="textCnr fs24 m5">
          regulatory framework
        </div>
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
      <div style="margin-top: 20px; justify-content: space-between" class="flexC">
        <div style="width: 76px; height: 462px; margin-right: 12px; overflow: auto">
          <div style="width: 76px;height: 110px;margin-bottom: 4px;font-weight: bold"
               :class="['flexC', 'ardCtr', 'item-box', {'ac':index===itemIndex}]" v-for="(item, index) in rulerType"
               :key="item" @click="clickItem(item,index)">
            {{ item.name }}
          </div>
        </div>
        <div class="flex1" style="height: 100%" v-if="regulations">
          <div v-if="regulations.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div v-for="(item, index) in regulations" :key="index" class="callItem"
               @click="goList('Rules-list','规范性文件', {...item,dataIndex: '规范性文件'})">
            <div v-if="index < 7" class="flexC betCtr" style="min-height: 40px;border:1px solid #cccccc;padding: 0 12px;">
              <div>
                {{ item.name }}
              </div>
              <!--              <Icon icon="Plus" class="iconS"></Icon>-->
            </div>
          </div>
        </div>
      </div>
    </el-col>

<!--    <el-col :span="12">-->
<!--      <div style="margin-top: 40px;">-->
<!--        <h3 class="textCnr title">-->
<!--          科研管理-->
<!--        </h3>-->
<!--        <div class="textCnr fs24 m5">-->
<!--          hot news-->
<!--        </div>-->
<!--        <div class="flexC betCtr w230 blcCnr">-->
<!--          <div class="line"></div>-->
<!--          <div class="box"></div>-->
<!--          <div class="line"></div>-->
<!--        </div>-->
<!--      </div>-->
<!--      <div style="height: 552px;margin-top: 20px;overflow-y:hidden;overflow-x:hidden">-->
<!--        <div v-if="messageK.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>-->
<!--        <div class="flexC newItem" v-for="item in messageK" :key="item"-->
<!--             @click="goList('News-list',4, {...item,dataIndex: 4})">-->
<!--          <div class="flexC flexCol wh96 ardCtr colorW" style="padding: 3px 0;">-->
<!--            <div class="fs32">{{ tools.day(item.created) }}</div>-->
<!--            <div class="bdrW">{{ tools.yearMouth(item.created) }}</div>-->
<!--          </div>-->
<!--          <div class="flex1 bg242" style="width: calc(100% - 96px); height: 96px;position: relative">-->
<!--            <div class="color3 p16">-->
<!--              <div class="elp" style="width: 90%;">-->
<!--                {{item.name || '郑医郑东院区承办郑州市第219期全民急救技能普及培训&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;' }}-->
<!--              </div>-->
<!--              <div class="elp2">-->
<!--                {{ item['content'] && tools.ellipsis(item['content']) }}-->
<!--              </div>-->
<!--            </div>-->
<!--            <div class="flexC pos">-->
<!--              <div class="three">-->
<!--              </div>-->
<!--            </div>-->
<!--            &lt;!&ndash;            <img style="width: 23px;position: absolute;bottom: 2px;right: 2px;" src="../assets/images/u50.png" alt="image">&ndash;&gt;-->
<!--          </div>-->
<!--        </div>-->
<!--      </div>-->
<!--    </el-col>-->

<!--    <el-col :span="24" style="border: 1px solid #cccccc;margin-top: 24px; padding-bottom: 20px">-->
<!--      <div class="flexC betCtr">-->
<!--        <div :class="['tab', 'textCnr', {'ac':index===tabIndex}]" v-for="(item, index) in messageType" :key="index"-->
<!--             @click="clickTab(item,index)">-->
<!--          {{ item.name }}-->
<!--        </div>-->
<!--      </div>-->
<!--      <el-row justify="center" style="width: 100%;">-->
<!--        <el-col :span="10"-->
<!--                style="height: 552px; margin-top: 20px;border: 2px solid rgba(242, 242, 242, 1);margin-right: 30px; background: rgb(241,251,253);padding: 20px;"-->
<!--                @click="goList('News-list',4,{...messageDetailK, dataIndex: 4})">-->
<!--          <img style="width:100%;height: 360px;" :src="messageDetailK['img']" alt="image">-->
<!--          <div class="lineH40 p12" style="overflow: auto; height: calc(100% - 360px)">-->
<!--            <div class="subtitle">-->
<!--              {{ messageDetailK.name || '一封温暖的信——致敬白衣天使' }}-->
<!--            </div>-->
<!--            <div>-->
<!--              <p class="ind elp2" style="font-size: 14px">-->
<!--                {{ messageDetailK['content'] && tools.ellipsis(messageDetailK['content']) }}-->
<!--              </p>-->
<!--            </div>-->
<!--          </div>-->
<!--        </el-col>-->
<!--        <el-col :span="13" style="height: 552px;margin-top: 20px;overflow-y:hidden;overflow-x:hidden">-->
<!--          <div v-if="messageK.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>-->
<!--          <div class="flexC newItem" v-for="item in messageK" :key="item"-->
<!--               @click="goList('News-list',4, {...item,dataIndex: 4})">-->
<!--            <div class="flexC flexCol wh96 ardCtr colorW" style="padding: 3px 0;">-->
<!--              <div class="fs32">{{ tools.day(item.created) }}</div>-->
<!--              <div class="bdrW">{{ tools.yearMouth(item.created) }}</div>-->
<!--            </div>-->
<!--            <div class="flex1 bg242" style="width: calc(100% - 96px); height: 96px;position: relative">-->
<!--              <div class="color3 p16">-->
<!--                <div class="elp" style="width: 90%;">-->
<!--                  {{item.name || '郑医郑东院区承办郑州市第219期全民急救技能普及培训&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;&#45;' }}-->
<!--                </div>-->
<!--                <div class="elp2">-->
<!--                  {{ item['content'] && tools.ellipsis(item['content']) }}-->
<!--                </div>-->
<!--              </div>-->
<!--              <div class="flexC pos">-->
<!--                <div class="three">-->
<!--                </div>-->
<!--              </div>-->
<!--              &lt;!&ndash;            <img style="width: 23px;position: absolute;bottom: 2px;right: 2px;" src="../assets/images/u50.png" alt="image">&ndash;&gt;-->
<!--            </div>-->
<!--          </div>-->
<!--        </el-col>-->
<!--      </el-row>-->
<!--    </el-col>-->

    <el-col :span="24">
      <div style="margin-top: 40px;">
        <h3 class="textCnr title">
          师资介绍
        </h3>
        <div class="textCnr fs24 m5">
          teachers elegant demeanour
        </div>
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
    </el-col>
    <el-row :gutter="14" class="flexC betCtr" style="height: 332px;margin-top: 34px; width: 100%">
      <!--      <div v-if="teacher_style.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>-->
      <div style="width: 100%;height: 332px;">
        <el-carousel style="--el-carousel-arrow-background: rgb(151,75,105)" indicator-position="none" :interval="5000"
                     arrow="always" height="332px">
          <el-carousel-item style="width: 100%; height: 332px; padding: 0 76px;">
            <div class="flexC betCtr" style="width: 90%;">
              <div class="teacher-item" v-for="item in teacher_style" :key="item"
                   @click="goList('Teacher-list','师资介绍', {...item,dataIndex: '师资介绍'})">
                <div style="width: 240px;height: 327px;border: 1px solid #cccccc">
                  <div style="height: calc(100% - 84px)" class="flexC ardCtr img-box">
                    <img class="w100" style="width: 154px;height: 220px"
                         :src="item['photo']||'../assets/images/fc1.jpg'" alt="fc">
                  </div>
                  <div class="text-box"
                       style="height: 84px;width: 100%;bottom: 0;left: 0;padding: 14px;box-sizing: border-box; overflow: auto">
                    <div style="font-size: 18px;margin-bottom: 10px;">
                      {{ item.name }}
                    </div>
                    <div class="flexC betCtr">
<!--                      <div class="elp" style="width: 50%" :title="item['hospital']">-->
<!--                        {{ item['hospital'] }}-->
<!--                      </div>-->
<!--                      class="elp" style="width: 50%"-->
                      <div style="font-size: 12px" :title="item['title']">
                        {{ item['title'] }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </el-carousel-item>
          <el-carousel-item style="width: 100%; height: 332px; padding: 0 76px;">
            <div class="flexC betCtr" style="width: 90%;">
              <div class="teacher-item" v-for="item in teacher_style2" :key="item"
                   @click="goList('Teacher-list','师资介绍', {...item,dataIndex: '师资介绍'})">
                <div style="width: 240px;height: 327px;border: 1px solid #cccccc">
                  <div style="height: calc(100% - 84px)" class="flexC ardCtr img-box">
                    <img class="w100" style="width: 154px;height: 220px"
                         :src="item['photo']||'../assets/images/fc1.jpg'" alt="fc">
                  </div>
                  <div class="text-box"
                       style="height: 84px;width: 100%;bottom: 0;left: 0;padding: 14px;box-sizing: border-box; overflow: auto">
                    <div style="font-size: 18px;margin-bottom: 10px;">
                      {{ item.name }}
                    </div>
                    <div class="flexC betCtr">
<!--                      <div class="elp" style="width: 50%;font-weight: bold" :title="item['hospital']">-->
<!--                        {{ item['hospital'] }}-->
<!--                      </div>-->
                      <div style="font-size: 12px" :title="item['title']">
                        {{ item['title'] }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </el-carousel-item>
        </el-carousel>
      </div>
    </el-row>
    <el-col :span="24">
      <div style="margin-top: 40px;">
<!--        <h3 class="textCnr title">-->
<!--          友情链接-->
<!--        </h3>-->
<!--        <div class="textCnr fs24 m5">-->
<!--          blogroll-->
<!--        </div>-->
        <div class="flexC betCtr w230 blcCnr">
          <div class="line"></div>
          <div class="box"></div>
          <div class="line"></div>
        </div>
      </div>
    </el-col>
    <el-row>
      <div class="flexC flexW" style="padding: 0 7px;flex-wrap: nowrap">
        <div v-if="links.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
        <h3 class="textCnr title"
            style="padding: 0 12px; height: 56px;line-height: 56px;text-align: center; margin-top: 34px;margin-right: 30px;box-sizing: border-box">
          友情链接:
        </h3>
        <div v-for="item in links" :key="item.name">
          <div class="aItem"
               style="padding: 0 12px; height: 56px;line-height: 56px;text-align: center; margin-top: 34px;margin-right: 30px;box-sizing: border-box">
            <a :href="item.path" target="_blank">
              {{ item.name || '国家卫生健康委员会' }}
            </a>
          </div>
        </div>
      </div>
    </el-row>
  </el-row>
</template>

<script>
import {toRefs, reactive, onBeforeMount} from 'vue'
import Common from '../hooks/common.js'
import http from '../http/axios.ts'
import tools from '../utils/tools.ts'

export default {
  name: "Index",
  setup() {
    const state = reactive({
      tabImg: ['yxjyzx.png','bkjy.png','kygl.png','yjspy.png','yxjyzx.png','yxqb.png','zpgl.png'],
      tabIndex: 0,
      itemIndex: 0,
      fiveIndex: 0,
      links: [],
      rulerType: [],
      fiveType: [],
      teaching: [],
      training: [],
      message: [],
      messageK: [],
      messageF: [],
      messageDetail: {},
      messageDetailK: {},
      messageType: [],
      regulations: [],
      teacher_style: [],
      teacher_style2: [],
      urlArr: {
        study: {
          out: 'http://117.159.24.46:3001/#/client/home',
          into: 'http://172.16.10.53:3001/#/client/home'
        },
        zhuPei: {
          out: 'http://117.159.24.46:64001/home',
          into: 'http://172.16.10.53:64001/home'
        },
        exam: {
          out: 'http://117.159.24.46:8201/home',
          into: 'http://172.16.10.53:8201/home'
        }
      },
      currentNet: 'into',
      params: {
        limit: 10,
        offset: null,
        sort:'created desc'
      }
    })
    const {go, setStore, getStore} = Common()
    const clickTab = (data, index) => {
      state.tabIndex = index
      state.message = []
      state.messageDetail = []
      getLinkList('/message/getListByPage', 'message', {
        limit: 7,
        status: 1,
        typeId: data.id,
        sort:'created desc'
      }, () => {
        state.messageDetail = state.message[0]
      }) // 消息tab
    }
    const clickItem = (data, index,flag) => {
      if(flag){
        state.fiveIndex = index
        state.messageF = []
        getLinkList('/message/getListByPage', 'messageF', {
          limit: 7,
          status: 1,
          typeId: data.id,
          sort:'created desc'
        }) // 第五临床学院
      }else{
        state.itemIndex = index
        state.regulations = []
        getChildList(data) // 规章制度
        // getLinkList('/regulations/getListByPage', 'regulations', {
        //   limit: 7,
        //   status: 1,
        //   typeId: data.id
        // }) // 点击政策制度
      }

    }
    //
    const goLogin = () => {
      tools.msg('敬请期待!')
    }
    // 跳转列表
    const goList = (url, str, data) => {
      window.scroll(0,0)
      let ind = tools.returnIndex(getStore('menus'),str)
      // const userInfo = getStore('manageUserInfo')
      // if (!userInfo.id) {
      //   // tools.showIsLogin()
      // } else {
      //   setStore('tabIndexSet', ind)
      //   sessionStorage.setItem('tabIndex', ind)
      //   go(url, data)
      // }
      setStore('tabIndexSet', ind)
      sessionStorage.setItem('tabIndex', ind)
      go(url, data)
    }

    const getLinkList = (url, target, param, cb) => {
      http.get(url, param || state.params).then(res => {
        state[target] = res.list
        if (cb) cb()
      })
    }

    const getChildList = (arr) => {
      if(arr.length === 0){
        state['regulations'] = []
      } else {
        state['regulations'] = []
        http.get('/regulations/getListByPage', {
          limit: 7,
          status: 1,
          typeId: arr.id || '',
          offset: null
        }).then(res => {
          if(res.list && res.list.length !== 0){
            state['regulations'] = [...state['regulations'],...res.list]
          }
        })
        arr.children.forEach(item => {
          http.get('/regulations/getListByPage', {
            limit: 7,
            status: 1,
            typeId: item.id || '',
            offset: null
          }).then(res => {
            if(res.list && res.list.length !== 0){
              state['regulations'] = [...state['regulations'],...res.list]
            }
          })
        })
      }
    }
    // 获取第一条信息
    const getFirstMessage = () => {
      http.get('/ps_menus/getListByPage', {
        limit: 111
      }).then(res => {
        res.list.forEach(item => {
          if (item.name === '新闻信息') {
            state.messageType = tools.sortFn(item.children)
            // state.messageType.forEach((ite, index) => {
            //   if (ite.name === '科研管理') {
            //     state.messageType.splice(index, 1)
            //     getLinkList('/message/getListByPage', 'messageK', {
            //       limit: 5,
            //       status: 1,
            //       typeId: ite.id
            //     }, () => {
            //       state.messageDetailK = state.messageK[0]
            //     }) // 消息
            //   }
            // })
            getLinkList('/message/getListByPage', 'message', {
              limit: 5,
              status: 1,
              typeId: state.messageType[0].id,
              sort:'created desc'
            }, () => {
              state.messageDetail = state.message[0]
            }) // 消息
          } else if (item.name === '第五临床医学院') {
            let arr = tools.sortFn(item.children)
            arr.forEach((ite) => {
              if (ite.name === '第五临床医学院') {
                getLinkList('/message/getListByPage', 'messageF', {
                  limit: 5,
                  status: 1,
                  typeId: ite.id,
                  sort:'created desc'
                }) // 消息
              }
            })
          }
        })
      })
    }
    // 获取规章制度类型
    const getRulerType = () => {
      http.get('/ps_menus/getListByPage', {
        // parentId: '644fda85-3b45-497b-9b76-8ea5bbec8801'
        limit: 111,
        sort: 'sequence asc'
      }).then(res => {
        res.list.forEach(item => {
          if (item.name === '规范性文件') {
            state.rulerType = tools.sortFn(item.children)
            getChildList(state.rulerType[0])
          }
        })

      })
    }

    // 获取第五临床类型
    const getFiveType = () => {
      http.post('/ps_menus/getDataByIdMore', {
        parentId: 'aaf71cce-d605-4cde-967b-492ea9494515'
      }).then(res => {
        state.fiveType = tools.sortFn(res.data)
        getLinkList('/message/getListByPage', 'messageF', {
          limit: 7,
          status: 1,
          typeId: res.data[0].id,
          offset: null,
          sort:'created desc'
        })
      })
    }

    const linksInto = () => {
      if(state.currentNet === 'into'){
        const url = 'http://172.16.10.53:8083/login?service=http%3A%2F%2F172.16.10.79%2FuserAction%21do_casLogin.action'
        window.open(url, '_blank')
      } else {
        tools.msgError('请使用医院内网才能访问科研管理系统。')
      }
    }

    getLinkList('/links/getListByPage', 'links', {
      limit: 99,
      offset: null
    }) // 友情链接

    getLinkList('/teacher_style/getListByPage', 'teacher_style', {
      limit: 5,
      status: 1,
      offset: null,
      sort:'created desc'
    }) // 教师风采
    getLinkList('/teacher_style/getListByPage', 'teacher_style2', {
      limit: 5,
      status: 1,
      offset: 5,
      sort:'created desc'
    }) // 教师风采
    // getLinkList('/teaching/getListByPage', 'teaching', {
    //   limit: 7,
    //   status: 1,
    //   offset: null
    // }) // 教学动态
    getLinkList('/training/getListByPage', 'training', {
      limit: 7,
      status: 1,
      offset: null,
      sort:'created desc'
    }) // 招生培训
    onBeforeMount(() => {
      state.currentNet = window.location.hostname === '117.159.24.46' ? 'out' : 'into'
      getFirstMessage()
      getRulerType()
      getFiveType()
    })
    return {
      ...toRefs(state),
      clickTab,
      linksInto,
      clickItem,
      goLogin,
      goList,
      tools
    }
  }
}
</script>

<style scoped lang="less">
.title {
  font-weight: 400;
  font-style: normal;
  font-size: 27px;
}

.line {
  width: 94px;
  height: 2px;
  background: rgb(121, 121, 121);
}

.box {
  width: 14px;
  height: 14px;
  background: rgb(151, 75, 105);
}

.subtitle {
  font-weight: 400;
  font-style: normal;
  font-size: 18px;
  color: #974B69;
}

.wh96 {
  width: 96px;
  height: 96px;
  background: rgb(170, 170, 170);
  box-sizing: border-box;
}

.bdrW {
  border-radius: 4px;
  border: 1px solid #ffffff;
  padding: 3px;
}

.bg242 {
  background: rgb(242, 242, 242);
}

.newItem:hover {
  .colorW {
    background: rgb(151, 75, 105);
  }

  .bg242 {
    background: rgb(170, 170, 170);

    .three {
      border-color: transparent transparent rgb(151, 75, 105);
    }
  }
}

.iconS {
  width: 15px;
  height: 15px;
}

.callItem:not(:first-child) {
  margin-top: 28px;
}

.aItem {
  background: rgb(242, 242, 242);

  &:hover {
    background: rgb(151, 75, 105);

    a {
      color: #ffffff;
    }
  }
}

.tab {
  flex: 1;
  font-size: 18px;
  height: 60px;
  line-height: 60px;
  background-color: rgba(242, 242, 242, 1);
  box-sizing: border-box;
  border-width: 1px;
  border-style: solid;
  border-color: rgba(215, 215, 215, 1);

  &:not(:last-child) {
    border-right: none;
  }

  &:hover {
    background: rgb(192, 192, 192);
  }

  &.ac {
    border-top: 3px solid rgb(151, 75, 105);
    background: #ffffff;
    border-bottom: none;
    font-size: 20px;
    color: rgb(151, 75, 105);
  }
}

.btn-shd {
  box-shadow: 4px 4px 5px 0 rgba(0, 0, 0, 0.75);
  -webkit-box-shadow: 4px 4px 5px 0 rgba(0, 0, 0, 0.75);
  -moz-box-shadow: 4px 4px 5px 0 rgba(0, 0, 0, 0.75);
}

.item-box {
  background: rgb(241, 241, 241);

  &.ac {
    background: rgb(151, 75, 105);
    color: #ffffff;
  }

  &:hover {
    background: rgb(151, 75, 105);
    color: #ffffff;
  }
}

.teacher-item {
  .text-box {
    background: rgb(241, 241, 241);
    color: #333333;
  }

  &:hover {
    .img-box {
      background: rgb(241, 241, 241);
    }

    .text-box {
      background: rgb(151, 75, 105);
      color: #ffffff;
    }
  }
}

.callItem {
  &:hover {
    color: #ffffff;
    background: rgb(151, 75, 105) !important;

    .bg242 {
      color: #ffffff;
      background: rgb(151, 75, 105) !important;

      .color3 {
        color: #ffffff;
      }
    }
  }
}
</style>
