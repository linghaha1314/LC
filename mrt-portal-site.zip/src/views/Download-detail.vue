<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24" style="border-bottom: 1px dashed #ccc;padding: 0 40px 36px; position: relative">
      <div class="textCnr fs18">{{ data.name }}</div>
      <div class="textCnr" style="margin: 14px 0;font-size: 13px">来源：
        {{ `${data['source'] || '未知'}  ${data['author'] || ''}` }} &nbsp; &nbsp;&nbsp;
        时间：{{ tools.formatTime(data['time'], 'YY-MM-DD') }}
      </div>
      <!--      <div class="flex1 rightAlign" style="position:absolute; top: 0; right: 30px">-->
      <!--        <a :download="data.path && data.path.split('/')[data.path.split('/').length-1]" :href="data.path" target="_blank">-->
      <!--          <img class="imgM cur" style="width: 50px" src="../assets/images/u40.png" alt="image">-->
      <!--        </a>-->
      <!--      </div>-->
      <div style="margin-bottom: 30px">
        {{ data['content'] }}
      </div>
<!--      <pdf-view v-if="tools.showPdf(data)" :pdfUrl="data['path'].split(',')[0]"></pdf-view>-->
      <iframe v-if="tools.showPdf(data)" :src="data['path']+'#toolbar=0'" frameborder="0" width="100%" height="650px"></iframe>
      <div v-if="data['path']" style="font-size: 12px">
        <div v-for="item in data['path'].split(',')" :key="item">
          附件:
          <span style="font-size: 12px">
            {{ item && item.split('/')[item.split('/').length - 1] || '无' }}
          </span>
          <pdf-preview :pdfUrl="item" :isDownload="data && data.isDownload || 1"></pdf-preview>
        </div>
      </div>
    </el-col>
    <el-col :span="24" style="padding-top: 22px;font-size: 14px">
      <div style="margin: 8px;" v-if="nextBefore[0]" @click="dataClick(nextBefore[0])">
        {{ (nextBefore.length === 1 && data['sequence'] > nextBefore[0]['sequence']) ? '下一篇:' : '上一篇:' }}
        <span style="margin-left: 8px;" class="cur">
          {{ nextBefore[0]['name'] || '无' }}
        </span>
      </div>
      <div style="margin: 8px;" v-if="nextBefore[1]" @click="dataClick(nextBefore[1])">
        下一篇:
        <span style="margin-left: 8px;" class="cur">
          {{ nextBefore[1]['name'] || '无' }}
        </span>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import {toRefs, reactive} from 'vue'
import tools from '../utils/tools.ts'
import PdfPreview from "../components/pdf-preview";
// import PdfView from "../components/pdf-view";

export default {
  name: "News-detail",
  props: {
    data: {
      type: Object
    },
    nextBefore: {
      type: Object
    }
  },
  components: {
    // PdfView,
    PdfPreview},
  emits: [
    'dataClick'
  ],
  setup(prop, ctx) {
    const state = reactive({
      urlArr: [
        {
          title: '资料下载',
          path: '/Download/Download-list'
        },
        {
          title: '文档资料',
          path: '/Download/Download-list'
        },
        {
          title: '详情',
          path: '/Download/Download-detail'
        }
      ]
    })
    const dataClick = (data) => {
      ctx.emit('dataClick', data)
    }
    return {
      ...toRefs(state),
      dataClick,
      tools
    }
  }
}
</script>

<style scoped lang="less">

</style>
