<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'
export default {
  name: "News",
  components:{},
  setup: function () {
    const state = reactive({
      listName: '新闻信息',
      listArr: [
        {
          title: '新闻资讯',
          path: 'news'
        },
        {
          title: '新闻资讯',
          path: 'news'
        },
        {
          title: '新闻资讯',
          path: 'news'
        },
        {
          title: '新闻资讯',
          path: 'news'
        }
      ],
      urlArr: [
        {
          title: '新闻信息',
          path: 'News-list'
        },
        {
          title: '新闻资讯',
          path: 'News-list'
        }
      ]
    })

    const menuChange = (item) => {
      console.log(item, 78)
    }


    return {
      ...toRefs(state),
      menuChange,
      ArrowRight
    }
  }
}
</script>

<style scoped lang="less">

</style>
