<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive } from 'vue'
import { ArrowRight } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
export default {
  name: "Teaching",
  components:{},
  setup() {
    const state = reactive({
      listName: '教学动态',
      listArr: [
        {
          title: '教学介绍',
          path: '/Teaching/Teaching-list'
        },
        {
          title: '医院教育信息',
          path: '/Teaching/Teaching-list'
        },
        {
          title: '住院医师规培信息',
          path: '/Teaching/Teaching-list'
        },
        {
          title: '公益活动',
          path: '/Teaching/Teaching-list-commonweal'
        }
      ],
      urlArr:[
        {
          title: '教学动态',
          path: 'Teaching-list'
        },
        {
          title: '教学介绍',
          path: 'Teaching-list'
        },
      ]
    })

    const {go, setStore} = Common()

    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '教学动态',
          path: 'Teaching-list'
        },
        {
          title: item.name,
          path: 'Teaching-list'
        }
      ])
      go('Teaching-list')
    }


    return {
      ...toRefs(state),
      menuChange,
      ArrowRight
    }
  }
}
</script>

<style scoped lang="less">

</style>
