<template>
  <el-row :gutter="0" justify="center">
    <el-drawer
        title="详细信息"
        v-model="pageParams.isDrawer"
        direction="rtl"
        :append-to-body="false"
        :destroy-on-close="true"
        :show-close="isClose"
        :close-on-press-escape="isClose"
        :close-on-click-modal="isClose"
        size="40%"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
    <el-drawer
        title="修改密码"
        v-model="pageParams.isPsw"
        direction="rtl"
        :append-to-body="false"
        :destroy-on-close="true"
        size="40%"
    >
      <div style="text-align: center; color: orangered">请填写8位以上包含大小写字母 数字 特殊符号任意三种规则的密码</div>
      <form-list :list="pswList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
    <el-dialog v-model="isDialog" :destroy-on-close="true" title="切换角色" width="40%">
      <el-radio-group v-model="currentRoleId" @change="changeCurrentRole">
        <el-radio v-for="i in roles" :key="i['roleId']" :label="i['roleId']">{{ i['roleData'].name }}</el-radio>
      </el-radio-group>
    </el-dialog>
    <el-dialog v-model="isLeaveMsg"
               destroy-on-close
               title="院长信箱"
               width="40%">
      <form-list :list="msgList" @submit="submit"></form-list>
    </el-dialog>
    <el-col :span="24">
      <div class="flexC">
        <img src="../assets/images/u11.jpg" alt="image">
        <div class="flexC ardCtr flex1">
          <div v-for="(item,index) in menuList" :key="index" @click="clickMenuItem(index,item)" v-show="item.isShow">
            <el-dropdown>
              <div :class="index===getStore('tabIndex')?'menuItem ac':'menuItem'"
                   :title="item.name">
                {{ item.name }}
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item v-for="ite in item.children" :key="ite.id" @click="clickMenuItem(index,item)">{{
                      ite.name
                    }}
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
          <div v-show="isMore">
            <el-dropdown>
              <div :class="getStore('tabIndex') === 9?'menuItem ac':'menuItem'">
                >>更多
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item v-for="ite in moreList" :key="ite.id" @click="clickMenuItem(9,ite)"
                                    v-show="ite.isShow">{{
                      ite.name
                    }}
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
        <div class="flexC ardCtr">
          <div v-show="isLogin" class="flexC ardCtr">
            <el-dropdown>
              <div class="el-dropdown-link flexC ardCtr" style="width: 80px;">
                <!--               <el-avatar-->
                <!--                   :size="42"-->
                <!--                   :src="userInfo && userInfo['avatar'] || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"-->
                <!--                   fit="cover"-->
                <!--                   icon="el-icon-user-solid"-->
                <!--               ></el-avatar>-->
                用户: &nbsp; {{ userInfo && userInfo['name'] || '无' }}
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item v-for="i in options"
                                    :key="i.id"
                                    @click="goUrl(i)">{{ i.value }}
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
<!--          <el-button v-show="!isLogin" type="warning" plain @click="goLoginBtn(false)">登录-->
<!--          </el-button>-->
          <el-button v-show="!isLogin" type="warning" plain @click="goLoginBtn(true)">登录
          </el-button>
        </div>
      </div>
    </el-col>
    <el-col :span="8" style="position: relative">
      <div style="border-top: 2px solid #9B536F;height: 300px; width: 100%;text-align: center" class="flexCol">
        <img style="width: 100%;height: 300px;object-fit:fill" src="../assets/images/banner_l.png"
             alt="image">
      </div>
    </el-col>
    <el-col :span="16" style="position: relative">
      <div style="position: absolute;left: 0;top: 0">
        <img v-if="banner.length>0" style="width:100%;height: 300px;object-fit:fill" :src="banner[1].path||''"
             alt="image">
      </div>
      <el-carousel height="300px" style="border-top: 2px solid #9B536F;margin-bottom: 10px">
        <el-carousel-item v-for="(item, index) in banner" :key="index">
          <div>
            <img v-if="item.path && item.path!==''" style="width:100%;height: 300px;object-fit:fill" :src="item.path"
                 alt="image">
          </div>
        </el-carousel-item>
      </el-carousel>
<!--      <div style="position: absolute;right: 30px;bottom: 30px;z-index: 99">-->
<!--        <a :href="urlArr.study[currentNet]" target="_blank">-->
<!--          <el-button style="height:42px;border-radius:8px;font-size: 12px;margin: 12px;color: #ffffff"-->
<!--                     color="#b91a98" size="large">在线学习-->
<!--          </el-button>-->
<!--        </a>-->
<!--        <a :href="urlArr.exam[currentNet]" target="_blank">-->
<!--          <el-button style="height:42px;border-radius:8px;font-size: 12px;margin: 12px;" type="warning"-->
<!--                     size="large" @click="goLogin">在线考试管理系统-->
<!--          </el-button>-->
<!--        </a>-->
<!--        <a href="http://172.16.10.79/userAction!to_login.action" target="_blank">-->
<!--          <el-button style="height:42px;border-radius:8px;font-size: 12px;margin: 12px;" type="primary"-->
<!--                     size="large">科研管理系统-->
<!--          </el-button>-->
<!--        </a>-->
<!--        <a :href="urlArr.zhuPei[currentNet]" target="_blank">-->
<!--          <el-button style="height:42px;border-radius:8px;font-size: 12px;margin: 12px;" type="success"-->
<!--                     size="large">住院医师规范化培训管理系统-->
<!--          </el-button>-->
<!--        </a>-->
<!--      </div>-->
    </el-col>
    <el-col :span="24">
      <el-row class="bg" justify="center">
        <el-col :span="16">
          <el-carousel indicator-position="none" height="48px">
            <el-carousel-item>
              <div class="flexC betCtr">
                <img height="48" src="../assets/images/u24.png" alt="image">
                <div class="flex1 flexC betCtr">
                  <div class="flexC ardCtr" style="width: 50%;" v-for="item in topMsg" :key="item.id"
                       @click="goList('News-list','新闻信息', {...item,dataIndex: '新闻信息'})">
                    <div class="iconC"></div>
                    <div class="colorW elp" style="width: 90%">
                      {{ item.name }}
                    </div>
                  </div>
                </div>
              </div>
            </el-carousel-item>
            <el-carousel-item>
              <div class="flexC betCtr">
                <img height="48" src="../assets/images/u24.png" alt="image">
                <div class="flex1 flexC betCtr">
                  <div class="flexC ardCtr" style="width: 50%;" v-for="item in topOtherMsg" :key="item.id"
                       @click="goList('News-list','新闻信息', {...item,dataIndex: '新闻信息'})">
                    <div class="iconC"></div>
                    <div class="colorW elp" style="width: 90%">
                      {{ item.name }}
                    </div>
                  </div>
                </div>
              </div>
            </el-carousel-item>
          </el-carousel>
        </el-col>
      </el-row>
    </el-col>
    <el-col :span="20">
      <router-view v-if="isReload"></router-view>
    </el-col>
    <el-col :span="24" class="bg h9" style="margin-top: 70px;">
    </el-col>
    <el-col :span="16">
      <el-row justify="center">
        <el-col :span="13" class="color3 lineH40">
          <div style="margin-top: 20px">
            地址：郑州市黄河路33号（黄河路与文化路交叉口）
          </div>
          <div>
            电话：0371-67077777 <br>
            急诊急救电话：0371-63945120 <br>
            24小时电话：400-111-6707
          </div>
          <div>
            Copyright © 郑州人民医院 版权所有 All Rights Reserved. 豫卫网审[2010]第0020号
          </div>
          <div>
            ICP备案号：豫ICP备20024137号
          </div>
        </el-col>
        <el-col :span="11">
          <div class="flexC betCtr" style="margin-top: 20px">
            <div style="width: 22%;" class="flexC flexCol ardCtr" v-for="item in wxList" :key="item.id">
              <img style="width:100%" :src="item.path||'../assets/images/u213.jpg'" alt="image">
              <span style="margin-top: 8px">{{ item.name }}</span>
            </div>
            <div style="width: 22%;" class="flexC flexCol ardCtr" @click="leaveMsg">
              <img style="width:100%" src="../assets/images/12.jpg" alt="image">
              <span style="margin-top: 8px">院长信箱</span>
            </div>
            <!--            <div class="flexC flexCol ardCtr">-->
            <!--              <img height="128" src="../assets/images/u213.jpg" alt="image">-->
            <!--              <span style="margin-top: 8px">微信公众号</span>-->
            <!--            </div>-->
            <!--            <div class="flexC flexCol ardCtr">-->
            <!--              <img height="128" src="../assets/images/u213.jpg" alt="image">-->
            <!--              <span style="margin-top: 8px">微信公众号</span>-->
            <!--            </div>-->
          </div>
        </el-col>
      </el-row>
    </el-col>

  </el-row>
</template>

<script>
import {toRefs, reactive, nextTick, onBeforeMount, onUnmounted} from 'vue'
import http from '@/http/axios'
import Common from '../hooks/common.js'
import Cookies from "js-cookie";
import tools from '../utils/tools.ts'
import FormList from '@/components/FormList.vue'
import CryptoJS from 'crypto-js'

export default {
  name: "home",
  components: {
    FormList
  },
  setup() {
    const {go, getStore, setStore} = Common()
    const state = reactive({
      isLogin: false,
      isClose: false,
      isMore: false,
      currentRoleId: '',
      isDialog: false,
      isLeaveMsg: false,
      isChangeRole: false,
      roles: [],
      menuList: [],
      moreList: [],
      acNum: parseInt(sessionStorage.getItem('acNum')) || 0,
      options: [
        {
          id: 0,
          value: '个人中心',
          path: '/client/personal'
        },
        {
          id: 2,
          value: '修改密码',
          path: '/'
        },
        {
          id: 3,
          value: '切换角色',
          path: '/'
        },
        {
          id: 4,
          value: '退出登录',
          path: 'Login'
        }
      ],
      userInfo: {},
      topMsg: [],
      topOtherMsg: [],
      banner: [],
      wxList: [],
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false,
        isPsw: false
      },
      formList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '工号',
          key: 'jobNum',
          width: '',
          value: null,
          defaultValue: '',
          required: true,
          disabled: true
        },
        {
          type: 'input',
          label: '姓名',
          key: 'name',
          width: '',
          value: null,
          defaultValue: '',
          required: true,
          disabled: true
        },
        // {
        //   type: 'input',
        //   label: '昵称',
        //   key: 'nickName',
        //   width: '',
        //   value: null,
        //   defaultValue: ''
        // },
        {
          type: 'select',
          multiple: true,
          label: '角色',
          key: 'roles',
          width: '',
          url: '/roles/getListByPage',
          value: null,
          queryParams: {
            limit: 999
          },
          defaultValue: '',
          required: true,
          disabled: true
        },
        // {
        //   type: 'input',
        //   label: '机构',
        //   key: 'organizationName',
        //   width: '',
        //   value: null,
        //   defaultValue: ''
        // },
        {
          type: 'select',
          url: '/section/getListByPage',
          label: '科室',
          key: 'sectionId',
          queryParams: {
            limit: 999
          },
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'select',
          label: '性别',
          key: 'sex',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'sex'
          },
          optionsValue: 'name',
          httpType: 'post',
          required: true,
          defaultValue: []
        },
        {
          type: 'select',
          label: '人员类别',
          key: 'personnelType',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'staffType'
          },
          optionsValue: 'name',
          httpType: 'post',
          required: true,
          defaultValue: []
        },
        {
          type: 'select',
          label: '职称',
          key: 'positionTitle',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'positionName'
          },
          optionsValue: 'name',
          httpType: 'post',
          required: true,
          defaultValue: []
        },
        // {
        //   type: 'select',
        //   label: '专业',
        //   key: 'majorId',
        //   url: '/major/getListByPage',
        //   width: '',
        //   value: null,
        //   defaultValue: null
        // },
        // {
        //   type: 'input',
        //   label: '岗位',
        //   key: 'post',
        //   width: '',
        //   value: null,
        //   defaultValue: ''
        // },
        {
          type: 'input',
          label: '职务',
          key: 'duties',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '院区',
          key: 'hospital',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '手机号码',
          key: 'mobile',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'datePiker',
          label: '生日',
          key: 'bornDate',
          width: '',
          value: null,
          defaultValue: '',
          pikerType: 'date'
        },
        {
          type: 'input',
          label: '邮箱',
          key: 'email',
          width: '',
          value: null,
          defaultValue: ''
        }],
      msgList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '姓名',
          key: 'name',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'input',
          label: '手机号码',
          key: 'mobile',
          width: '',
          value: '',
          defaultValue: null,
          required: true
        },
        {
          type: 'textarea',
          label: '留言',
          key: 'content',
          width: '',
          value: '',
          defaultValue: null,
          required: true
        },
        {
          type: 'input',
          label: '邮箱',
          key: 'email',
          width: '',
          value: null,
          defaultValue: ''
        }
      ],
      pswList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '旧密码',
          key: 'password',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'input',
          label: '新密码',
          key: 'passwordN',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'input',
          label: '新密码',
          key: 'passwordNR',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }
      ],
      isReload: true,
      urlArr: {
        study: {
          out: 'http://117.159.24.46:3001/#/client/home',
          into: 'http://172.16.10.53:3001/#/client/home'
        },
        zhuPei: {
          out: 'http://117.159.24.46:64001/',
          into: 'http://172.16.10.53:64001'
        },
        exam: {
          out: 'http://117.159.24.46:8201',
          into: 'http://172.16.10.53:8201'
        }
      },
      currentNet: 'into'
    })
    // 点击菜单
    const clickMenuItem = (index, item) => {
      // if (!state.userInfo.id) {
      //   tools.showIsLogin()
      // } else {
      //   setStore('tabIndexSet', index)
      //   sessionStorage.setItem('tabIndex', index)
      //   if (['Index', 'Management-system', 'Download-list', 'Recruit-list', 'Teacher-list', 'Teaching-list', 'Rules-list', 'News-list'].includes(item.path)) {
      //     go(item.path, {data: JSON.stringify(item)})
      //   } else if (item.path === 'Curriculum-list') {
      //     window.open(state.urlArr.study[state.currentNet])
      //   } else {
      //     go('Template-list', {data: JSON.stringify(item)}, () => {
      //       refreshFn()
      //     })
      //   }
      // }
      setStore('tabIndexSet', index)
      sessionStorage.setItem('tabIndex', index)
      if (['Index', 'Management-system', 'Download-list', 'Recruit-list', 'Teacher-list', 'Teaching-list', 'Rules-list', 'News-list'].includes(item.path)) {
        go(item.path, {data: JSON.stringify(item)})
      } else if (item.path === 'Curriculum-list') {
        window.open(state.urlArr.study[state.currentNet])
      } else {
        go('Template-list', {data: JSON.stringify(item)}, () => {
          refreshFn()
        })
      }
    }
    // 跳转
    const goUrl = (to) => {
      if (to.value === '退出登录') {
        setStore('setManageToken', '')
        setStore('setManageUserInfo', {})
        Cookies.remove('client-token')
        localStorage.setItem('token', '')
        sessionStorage.setItem('queryId', '')
        state.isLogin = false
        window.open(state.currentNet==='into'? 'http://172.16.10.53:8083/logout':'http://117.159.24.46:8083/logout','_blank')
        return
      } else if (to.value === '个人中心') {
        showCenter()
        return
      } else if (to.value === '修改密码') {
        state.pswList.forEach((res) => {
          if (res.key === 'id') {
            res.value = state.userInfo[res.key]
          }
        })
        state.pageParams.isEdit = true
        state.pageParams.isPsw = true
        state.pageParams.isDrawer = false
        return
      } else if (to.value === '切换角色') {
        state.isDialog = true
        state.isChangeRole = true
        return
      }
      go(to.path)
    }
    // 获取数据通用方法
    const goList = (url, str, data) => {
      window.scroll(0,0)
      // if (!state.userInfo.id) {
      //   tools.showIsLogin()
      // } else {
      //   setStore('tabIndexSet', ind)
      //   sessionStorage.setItem('tabIndex', ind)
      //   go(url, data)
      // }
      let ind = tools.returnIndex(getStore('menus'),str)
      setStore('tabIndexSet', ind)
      sessionStorage.setItem('tabIndex', ind)
      go(url, data)
    }
    // 敬请期待
    const goLogin = () => {
      tools.msg('敬请期待!')
    }
    // 跳转到登录
    const goLoginBtn = (flag) => {
      localStorage.setItem('token', '')
      Cookies.remove('client-token')
      if(flag === true){
        if(state.currentNet === 'into'){
          window.location.href = 'http://172.16.10.53:8083/login?service=http%3A%2F%2F172.16.10.53%3A3002'
        }else{
          window.location.href = 'http://117.159.24.46:8083/login?service=http%3A%2F%2F117.159.24.46%3A3002'
        }
      }else{
        go('Login')
      }
      // window.location.href = 'http://117.159.24.46:8083/login?service=http%3A%2F%2F117.159.24.46%3A3002'
    }
    // 刷新
    const refreshFn = () => {
      state.isReload = false
      nextTick(function () {
        state.isReload = true
      })
    }
    // 获取菜单
    const getMenus = () => {
      if (state.menuList.length === 0) {
        http.get('/ps_menus/getListByPage', {
          limit: 99,
          status: 1,
          offset: null,
          sort: 'sequence asc'
        }).then(res => {
          res.list.forEach(item => {
            item.isShow = true
          })
          setStore('setMenus', [...tools.sortFn(res.list)])
          if (res.list.length > 9) {
            state.moreList = [...tools.sortFn(res.list)].splice(9, res.list.length - 9)
          }
          state.menuList = [...tools.sortFn(res.list)].splice(0, 9)
          let id = ''
          state.menuList.forEach(ite => {
            if(ite.name === '新闻信息'){
              ite.children.forEach(item => {
                if (item.name === '科研管理') {
                  id = item.id
                }
              })
            }
          })
          getTwoMsg(id)
        }).catch(err => {
          console.log(err, 77)
        })
      }
    }
    // 获取头部两条信息
    const getTwoMsg = (id) => {
      if (state.topMsg.length === 0) {
        http.get('/message/getListByPage', {
          limit: 4,
          status: 1,
          typeId: id
        }).then(res => {
          let arr = tools.sortFn(res.list)
          state.topMsg = [...arr].splice(0, 2)
          state.topOtherMsg = [...arr].splice(2, 2)
        }).catch(err => {
          console.log(err, 77)
        })
      }
    }
    const choiceFn = (arr) => {
      let banner = []
      let wx = []
      arr.forEach(item => {
        if (item.typeId === '740dbfca-6505-41f2-b16c-124caf084994') {
          banner.push(item)
        } else {
          wx.push(item)
        }
      })
      state.banner = tools.sortFn(banner)
      state.wxList = tools.sortFn(wx)
    }
    const getImg = () => {
      if (state.banner.length === 0 || state.wxList.length === 0) {
        http.get('/image_set/getListByPage', {
          limit: 20,
        }).then(res => {
          choiceFn(res.list)
        }).catch(err => {
          console.log(err, 77)
        })
      }
    }
    // 提交参数
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        if (state.pageParams.isPsw) {
          // if (state.userInfo.password !== data.password) {
          //   tools.msgError('旧密码错误!')
          //   return;
          // } else
          if (data['passwordN'] !== data['passwordNR']) {
            tools.msgError('两次新密码不一致!')
            return;
          } else if (!validator(data['passwordN'])) {
            tools.msgError('新密码不符合规则!')
            return;
          } else {
            const arr = []
            state.userInfo.roles.forEach(item => {
              arr.push(item.roleId)
            })
            data.password = data['passwordN']
            data.roles = arr
            delete data['passwordN']
            delete data['passwordNR']
            data.password = CryptoJS.AES.encrypt(data.password, 'kb12315').toString()
          }
        } else {
          data.isComplete = 1
          delete data.password
        }
        state.pageParams.isDrawer = false
        http.post('/user/updateUserById', data).then(res => {
          if (res.success) {
            state.pageParams.isPsw = false
            state.pageParams.refresh = true
            tools.msg(res.msg)
            getUserInfo()
          }
        })
        return
      }
      delete data.id
      http.post('/leave_msg/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.isLeaveMsg = false
        }
      })
    }
    // 获取用户信息
    const getUserInfo = () => {
      const id = sessionStorage.getItem('queryId')
      if(id){
        http.get('getUserInfo', {
          id: id
        }).then(re => {
          getImg()
          getMenus()
          if (re && re.data) {
            setStore('setManageUserInfo', re.data)
            state.isLogin = true
            state.userInfo = re.data
            state.roles = re.data.roles
            state.currentRoleId = state.roles[0].roleId
            state.isClose = re.data.isComplete !== 0
            if (re.data.isComplete === 0) {
              showCenter()
            }
            if(re.token){
              setStore('setManageToken', re.token)
              Cookies.set('client-token', re.token)
              localStorage.setItem('token',re.token)
            }
            const roleId = sessionStorage.getItem('currentRoleId') || state.roles[0].roleId
            getRolesMenu(roleId)

            const roleIsChange = sessionStorage.getItem('roleIsChange') || 'false'
            if(roleIsChange !== 'true'){
              state.isDialog = true
              state.isChangeRole = true
              sessionStorage.setItem('roleIsChange', 'true')
            }
          }
        })
      }
    }
    // 选择角色
    const changeCurrentRole = () => {
      tools.msg('操作成功!')
      state.isDialog = false
      state.isChangeRole = false
      getRolesMenu(state.currentRoleId)
      sessionStorage.setItem('currentRoleId', state.currentRoleId)
    }
    // 留言点击
    const leaveMsg = () => {
      state.isLeaveMsg = true
      state.pageParams.isEdit = false
    }
    const getRolesMenu = (id) => {
      resetFn()
      http.post('/roleColumn/getColumnByRoleId', {
        roleId: id
      }).then(res => {
        // setStore('setMenus', [...tools.sortFn(res.list)])
        if (res.list.length > 9) {
          // state.moreList = [...tools.sortFn(res.list)].splice(9, res.list.length - 9) || []
          state.isMore = true
          let moreArr = [...tools.sortFn(res.list)].splice(9, res.list.length - 9)
          state.moreList.forEach(item => {
            moreArr.forEach(ite => {
              if (item.id === ite.id) {
                item.isShow = true
              }
            })
          })
        }
        // state.menuList = [...tools.sortFn(res.list)].splice(0, 9) || []
        let arr = [...tools.sortFn(res.list)].splice(0, 9)
        state.menuList.forEach(item => {
          arr.forEach(ite => {
            if (item.id === ite.id) {
              item.isShow = true
            }
          })
        })
      })
    }
    // 退出登录
    const resetFn = () => {
      state.isMore = false
      state.menuList.forEach(item => {
        item.isShow = false
      })
      state.moreList.forEach(item => {
        item.isShow = false
      })
    }
    // 验证密码强度
    const validator = (str) => {
      let modes = 0;
      let val = str
      if (val.length < 7) return false;
      if (/\d/.test(val)) modes++; //数字
      if (/[a-z]/.test(val)) modes++; //小写
      if (/[A-Z]/.test(val)) modes++; //大写
      if (/\W/.test(val)) modes++; //特殊字符
      return modes > 2;
    }
    // 修改个人信息
    const showCenter = () => {
      state.formList.forEach((res) => {
        if (res.key === 'roles') {
          let arr = []
          state.userInfo['roles'].forEach(item => {
            arr.push(item['roleId'])
          })
          res.value = arr
        } else {
          res.value = state.userInfo[res.key]
        }
      })
      state.pageParams.isEdit = true
      state.pageParams.isDrawer = true
      state.pageParams.isPsw = false
    }

    onBeforeMount(() => {
      state.currentNet = window.location.hostname === '117.159.24.46' ? 'out' : 'into'
      const id = sessionStorage.getItem('queryId') || null
      if(id){
        getUserInfo()

      }else{
        console.log(8898)
        http.get('getUserInfo', {}).then(re => {
          getImg()
          getMenus()
          if (re && re.data) {
            setStore('setManageUserInfo', re.data)
            state.isLogin = true
            state.userInfo = re.data
            state.roles = re.data.roles
            state.currentRoleId = state.roles[0].roleId
            state.isClose = re.data.isComplete !== 0
            if (re.data.isComplete === 0) {
              showCenter()
            }
            if(re.token){
              setStore('setManageToken', re.token)
              Cookies.set('client-token', re.token)
              localStorage.setItem('token',re.token)
            }
            const roleId = sessionStorage.getItem('currentRoleId') || state.roles[0].roleId
            getRolesMenu(roleId)

            const roleIsChange = sessionStorage.getItem('roleIsChange') || 'false'
            if(roleIsChange !== 'true'){
              state.isDialog = true
              state.isChangeRole = true
              sessionStorage.setItem('roleIsChange', 'true')
            }
          }else{
            state.isLogin = false
          }
        })

      }
      window.addEventListener('popstate',function (){
        go('Index')
      },false)
    })
    onUnmounted(()=>{
      window.removeEventListener('popstate',function (){
        console.log(55)
      })
    })
    return {
      ...toRefs(state),
      clickMenuItem,
      goLogin,
      goLoginBtn,
      getStore,
      goUrl,
      changeCurrentRole,
      goList,
      leaveMsg,
      submit
    }
  }
}
</script>

<style scoped lang="less">
.menuItem {
  text-align: center;
  height: 40px;
  color: #9B536F;
  line-height: 40px;
  padding: 0 12px;

  &:hover {
    background: #9B536F;
    color: #ffffff;
  }

  &.ac {
    background: #9B536F;
    color: #ffffff;
  }
}
</style>
