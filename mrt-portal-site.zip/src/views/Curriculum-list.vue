<template>

  <div class="flexC">
    <left-menu :name="listName" :listData="listArr" @change="menuChange"></left-menu>
    <div class="flex1" style="margin-left: 22px;">
      <div class="flexC" style="align-items: center; border-bottom: 1px solid rgb(121,121,121);padding: 6px 8px;">
        <breadcrumb @clicks="changeFn"></breadcrumb>
      </div>
      <el-row v-if="isDetail===1" :gutter="0" justify="space-between" style="padding: 10px;">
        <el-col :span="24">
          <div style="padding: 14px;">
            <el-dropdown trigger="click">
        <span class="el-dropdown-link flexC ardCtr" style="border: 1px solid #797979;width: 167px;height: 44px;line-height: 44px;text-align: center;border-radius: 6px;margin-right: 28px;">
          <span>
            全部学科
          </span>
          <svg class="icon" width="14" height="14" viewBox="0 0 1024 1024" xmlns="http://www.w3.org/2000/svg" data-v-042ca774=""><path fill="currentColor" d="M104.704 338.752a64 64 0 0190.496 0l316.8 316.8 316.8-316.8a64 64 0 0190.496 90.496L557.248 791.296a64 64 0 01-90.496 0L104.704 429.248a64 64 0 010-90.496z"></path></svg>
        </span>
              <template #dropdown>
                <el-dropdown-menu style="width: 167px">
                  <el-dropdown-item >Action 1</el-dropdown-item>
                  <el-dropdown-item >
                    Action 2
                  </el-dropdown-item>
                  <el-dropdown-item >Action 3</el-dropdown-item>
                  <el-dropdown-item >Action 4</el-dropdown-item>
                  <el-dropdown-item >Action 5</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
            <el-input
                v-model="input2"
                size="large"
                style="width: 430px"
                placeholder="请输入关键字搜索"
                :suffix-icon="Search"
            />
          </div>
        </el-col>
        <el-col :span="24" style="padding: 14px;margin-bottom: 20px;align-items: center" class="flexC">
          <div v-if="list.length === 0" class="textCnr color3" style="margin: 20px 0;">暂未添加该数据!!</div>
          <div style="width: 230px;margin-right: 14px;margin-bottom: 30px; border: 1px solid rgb(121,121,121);position: relative" v-for="item in list" :key="item">
            <div style="">
              <img style="width: 230px;height: 170px;vertical-align: middle;" src="../assets/images/u55.png" alt="image">
            </div>
            <div class="flex1" style="margin: 12px 12px 12px 12px;">
              <h3 class="fs18 elp" style="font-weight: normal;" :title="item.name">{{item.name}}</h3>
              <p class="flexC betCtr" style="margin: 14px 0 14px;color: #333333;align-items: center;font-size: 14px">
          <span>
            {{item['teacher']}}
          </span>
                <span style="margin-left: 24px;color: #D9001B;font-size: 12px">
            74人参加
          </span>
              </p>
              <p class="" style="color:#9B536F;font-weight: bold;">
                5节课
              </p>
            </div>
            <div class="rightAlign">
              <el-button style="width: 100%; border-radius: 0;height: 44px;color: #fff;background:#9B536F;" color="#974b69" plain @click="study(item)">学习</el-button>
            </div>
            <div style="position: absolute;top: 12px;right: 12px" class="cur">
              <img v-if="item['like']===true" style="width: 24px;height: 24px;vertical-align: middle;" src="../assets/images/u59.png" alt="image" @click="isLike(item,false)">
              <img v-else style="width: 24px;height: 24px;vertical-align: middle;" src="../assets/images/u60.png" alt="image" @click="isLike(item,true)">
            </div>
          </div>
        </el-col>
        <el-col :span="24" class="rightAlign">
          <el-pagination background layout="prev, pager, next" :total="total" @current-change="changePage">
          </el-pagination>
        </el-col>
      </el-row>
      <CurriculumDetail v-else-if="isDetail===2"
                        :data="currentData"
                        @goPlay="goPlay"></CurriculumDetail>
      <CurriculumPlay v-else-if="isDetail===3"></CurriculumPlay>
    </div>
  </div>

</template>

<script>
import { toRefs, reactive, onBeforeMount } from 'vue'
import LeftMenu from '@/components/leftMenu.vue'
import Breadcrumb from '@/components/breadcrumb.vue'
import http from '../http/axios.ts'

import { Search } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
import CurriculumDetail from './Curriculum-detail'
import CurriculumPlay from './Curriculum-play'
export default {
  name: "Teacher-list",
  components:{
    LeftMenu,
    Breadcrumb,
    CurriculumDetail,
    CurriculumPlay
  },
  setup() {
    const state = reactive({
      listName: '在线课程',
      listArr: [
        {
          title: '精品课程',
          name: '精品课程',
          path: 'Curriculum-list'
        }
        // ,
        // {
        //   title: '直播课程',
        //   name: '直播课程',
        //   path: 'Curriculum-list'
        // }
      ],
      urlArr:[
        {
          name: '在线课程',
          title: '在线课程',
          path: 'Curriculum-list'
        },
        {
          name: '精品课程',
          title: '精品课程',
          path: 'Curriculum-list'
        },
      ],
      input2: '',
      params: {
        limit: 10,
        offset: 0,
        status: 1,
        typeId: '',
        sort:'created desc'
      },
      list: [],
      currentData: [],
      isDetail: 1,
      total: 10
    })
    const {setStore, getStore} = Common()

    const menuChange = (item)=>{
      state.isDetail = 1
      setStore('setUrlList',[
        {
          title: '在线课程',
          path: 'Curriculum-list'
        },
        {
          title: item.name,
          path: item.id
        }
      ])
      state.params.typeId = item.id
    }
    const changeFn = (ind)=>{
      state.isDetail = ind
    }
    const isLike = (item, bol)=>{
      item.like = bol
    }
    const goPlay = ()=>{
      state.isDetail = 3
    }
    const study = (item)=>{
      setStore('setUrlList',[
        ...getStore('urlList'),
        {
          title: '详情',
          path: 'Curriculum-detail'
        }
      ])
      state.currentData = item
      state.isDetail = 2
    }
    const getLinkList = (url, target, param) => {
      if (state.params.typeId === '') {
        delete state.params.typeId
      }
      http.get(url, param || state.params).then(res => {
        state[target] = res.list
        state.total = parseInt(res.total)
      })
    }

    onBeforeMount(() => {
      getLinkList('/curriculum/getListByPage', 'list')
      setStore('setUrlList',state.urlArr)
    })
    return {
      ...toRefs(state),
      Search,
      study,
      menuChange,
      changeFn,
      goPlay,
      isLike
    }
  }
}
</script>

<style scoped lang="less">

</style>
