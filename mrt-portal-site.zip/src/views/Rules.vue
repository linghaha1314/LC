<template>
  <el-row :gutter="0" justify="space-between" style="padding-top: 28px;">
    <el-col :span="24">
      <router-view></router-view>
    </el-col>
  </el-row>
</template>

<script>
import { toRefs, reactive, } from 'vue'

import { ArrowRight } from '@element-plus/icons-vue'
import Common from '../hooks/common.js'
export default {
  name: "Rules",
  components:{},
  setup() {
    const {setStore, go} = Common()
    const state = reactive({
      listName: '规范性文件',
      listArr: [
        {
          title: '院内制度',
          path: 'Rules'
        },
        {
          title: '政策制度',
          path: 'Rules'
        }
      ],
      urlArr:[
        {
          title: '规范性文件',
          path: '/Rules/Rules-list'
        },
        {
          title: '院内制度',
          path: '/Rules/Rules-list'
        },
      ]
    })

    const menuChange = (item)=>{
      state.isDetail = false
      setStore('setUrlList',[
        {
          title: '规范性文件',
          path: 'Rules-list'
        },
        {
          title: item.name,
          path: item.id
        }
      ])
      go('Rules-list')
    }
    return {
      ...toRefs(state),
      menuChange,
      ArrowRight
    }
  }
}
</script>

<style scoped lang="less">

</style>
