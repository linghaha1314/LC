<template>
  <el-row :gutter="0" justify="space-between" style="padding: 10px;">
    <el-col :span="24" style="margin-bottom: 20px;">
      <div>
        <div v-for="(item,index) in 7" :key="index+item" class="callItem">
          <div v-if="showInd !== parseInt(index)" class="flexC" style=" height: 62px;padding: 0 12px;border-bottom: 1px dashed #cccccc;align-items: center">
            <div class="bg242 boxSing fs13" style="position: relative;width: 108px;height: 40px;line-height: 40px;text-indent: 6px;">
              <div class="flexC" style="color: #333333">
                2021-06
                <span class="colorC" style="font-size: 17px">
                  19
                </span>
              </div>
              <img v-if="index<4" style="position: absolute;right: 0;top: 0;width: 24px;height: 24px" src="../assets/images/u54.png" alt="new">
            </div>
            <div class="fs13" style="margin-left: 20px;">
              郑州人民医院博士后科研工作站招聘公告{{index}}
            </div>
          </div>
        </div>
      </div>
    </el-col>
    <el-col :span="24" class="rightAlign">
      <el-pagination background layout="prev, pager, next" :total="total">
      </el-pagination>
    </el-col>
  </el-row>
</template>

<script>
import {toRefs, reactive} from 'vue'


import Common from '../hooks/common.js'
export default {
  name: "Rules-list-policy",
  components: {},
  setup() {
    const state = reactive({
      showInd: 0,
      total: 10
    })
    const {go, setStore, getStore} = Common()
    const goDetail = ()=>{
      setStore('setUrlList',[
        ...getStore('urlList'),
        {
          title: '详情',
          path: 'Download-detail'
        }
      ])
      go('Rules-detail')
    }
    return {
      ...toRefs(state),
      goDetail
    }
  }
}
</script>

<style scoped lang="less">
.iconS {

  width: 20px;
  height: 20px;
}

.callItem:not(:first-child) {
  margin-top: 28px;
}
.callItem:hover{
  background-color: rgba(151, 75, 105, 1);
  color: #fff;
}
</style>
