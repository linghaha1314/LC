import {Component, OnInit} from '@angular/core';
import {Help} from './utils/Help';
// import VConsole from 'vconsole';
import {
  ActivatedRoute,
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router
} from '@angular/router';
import {Title} from '@angular/platform-browser';
import {of} from 'rxjs';
import {map} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {StorageService} from './storage.service';

// const vConsole = new VConsole();

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit {
  swipeGesture = true;

  constructor(private storage: StorageService, private route: ActivatedRoute, private nav: NavController, private http: HttpClient, private help: Help, private router: Router, private titleService: Title, private activatedRoute: ActivatedRoute) {
  }

  async ngOnInit() {
    /*暗夜模式*/
    this.changeTheme();
    const cookie = document.cookie;
    let history: any[] = [];
    if (cookie != null && cookie.trim().length > 0 && cookie.indexOf('jwt=') > -1) {
      localStorage.setItem('token', cookie.trim().split('jwt=')[1]);
    }
    if (!localStorage.getItem('token')) {
      this.router.navigate(['/login'], {replaceUrl: true}).then(r => {
        this.help.hideLoading().then();
      });
    } else if (window.location.href.indexOf('login') < 0) {
      try {
        await this.help.getUserInfo(false,false);
      } catch (e) {
        await this.router.navigate(['/login'], {replaceUrl: true});
        if (e.status !== 0) {
          this.help.toastError(e);
        }
        await this.help.hideLoading();
      }
    }
    // 路由监听
    this.router.events.subscribe(async event => {
      if (event instanceof NavigationStart) {
        //返回去掉loading
        if (event.url !== history[history.length - 2]) {
          history.push(event.url);
        } else {
          history = history.slice(0, history.length - 1);
        }
        if (history[history.length - 1].indexOf('tabs') > -1) {
          history = [event.url];
        }
        // 路由跳转的时候，统一销毁为关闭的弹窗
        const dismissArr = ['ion-modal', 'ion-alert', 'ion-picker', 'ion-popover'];
        dismissArr.forEach(res => {
          const dom: any = document.querySelector(res);
          if (dom) {
            dom.dismiss();
          }
        });
      }
      if (event instanceof NavigationEnd) {
        of(event).pipe(
          map(() => this.activatedRoute),
          map(route => {
            while (route.firstChild) {
              route = route.firstChild;
            }
            return route;
          }),
          map(route => route.data), map((route: any) => route.value)
        ).subscribe((e) => {
          // 设置title
          this.routerInit(e);
          this.help.hideLoading().then();
          if (event.url.indexOf('CommonExam') > -1) {
            this.swipeGesture = false;
          } else {
            this.swipeGesture = true;
          }
        });
      }
      if (event instanceof NavigationError) {
      }
      if (event instanceof NavigationCancel) {
        this.help.hideLoading().then();
      }
    });
  }

  changeTheme() {
    const theme = this.storage.get('theme');
    const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (theme == null) {
      this.storage.set('theme', 'light');
    }
    if (theme == 'system') {
      document.body.classList.toggle('dark', isDark);
    } else if (theme == 'dark') {
      document.body.classList.toggle('dark', true);
    } else {
      document.body.classList.toggle('dark', false);
    }
  }

  // 设置名称
  routerInit(e: any) {
    if (e.title) {
      this.titleService.setTitle(e.title.trim());
    } else {
      this.help.toastError(`路由[${e.url}]未配置[title]属性!`);
      this.help.hideLoading().then();
    }
  }
}
