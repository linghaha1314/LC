import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.page.html',
  styleUrls: ['./attendance.page.scss'],
})
export class AttendancePage implements OnInit {
  queryParams: any = {
    name: '',
    attendanceDate: null
  };

  filters: any = [{
    code: 'attendanceDate',
    label: '日期',
    type: 'date',
    dateType: 'day'
  }];

  constructor() {
  }

  ngOnInit() {
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  changeFilter(e: any) {
    console.log('---e', e);
    this.queryParams = {...this.queryParams, ...e};
  }
}
