import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AttendancePageRoutingModule } from './attendance-routing.module';

import { AttendancePage } from './attendance.page';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';
import {BaseListModule} from '../../components/base-list/base-list.module';
import {FormatTimeModule} from '../../pipe/format-time/format-time.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AttendancePageRoutingModule,
    FilterDropdownModule,
    BaseListModule,
    FormatTimeModule
  ],
  declarations: [AttendancePage]
})
export class AttendancePageModule {}
