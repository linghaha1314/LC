import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {AlertController} from '@ionic/angular';
import {EventService} from '../../event.service';
import {Help} from '../../utils/Help';

@Component({
  selector: 'app-evaluate-view',
  templateUrl: './evaluate-view.page.html',
  styleUrls: ['./evaluate-view.page.scss'],
})
export class EvaluateViewPage implements OnInit {
  list: any;
  queryParams: any = {
    evalTypeCode: 'EvalType_TeacherToStudent'
  };

  constructor(private eventService: EventService, private alertController: AlertController, private router: Router, private help: Help, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.eventService.event.on('update', () => {
      this.queryParams = {...this.queryParams};
    });
  }

  segmentChanged(e) {
    this.queryParams = {...this.queryParams};
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  async goEval(item: any) {
    //弹窗查看信息
    const alert = await this.alertController.create({
      header: '详情',
      message: `<ion-grid><ion-row class="ion-padding-bottom"><ion-label>评价类型：&nbsp;</ion-label><ion-text>${item.typeName}</ion-text></ion-row>
                 <ion-row class="ion-padding-bottom"><ion-label>评价人：&nbsp;</ion-label><ion-text>${item.fromStaffName}</ion-text></ion-row>
                 <ion-row class="ion-padding-bottom"><ion-label>轮转时间：</ion-label><ion-text>${item.startDate}至${item.endDate}</ion-text></ion-row>
                 <ion-row class="ion-padding-bottom"><ion-label>评价时间：&nbsp;</ion-label><ion-text>${item.evalDate}</ion-text></ion-row>
                 <ion-row class="ion-padding-bottom"><ion-label>总分：&nbsp;</ion-label><ion-text>${item.totalScore}分</ion-text></ion-row>
                 <ion-row class="ion-padding-bottom"><ion-label>得分：&nbsp;</ion-label><ion-text>${item.score}分</ion-text></ion-row></ion-grid>`,
      buttons: [
        {
          text: '关闭',
          role: 'cancel'
        }
      ]
    });
    await alert.present();
  }

}
