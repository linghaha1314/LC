import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EvaluateViewPageRoutingModule } from './evaluate-view-routing.module';

import { EvaluateViewPage } from './evaluate-view.page';
import {BaseListModule} from "../../components/base-list/base-list.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        EvaluateViewPageRoutingModule,
        BaseListModule
    ],
  declarations: [EvaluateViewPage]
})
export class EvaluateViewPageModule {}
