import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CompletionRatePageRoutingModule } from './completion-rate-routing.module';

import { CompletionRatePage } from './completion-rate.page';
import {NoticeModule} from '../../components/notice/notice.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CompletionRatePageRoutingModule,
    NoticeModule
  ],
  declarations: [CompletionRatePage]
})
export class CompletionRatePageModule {}
