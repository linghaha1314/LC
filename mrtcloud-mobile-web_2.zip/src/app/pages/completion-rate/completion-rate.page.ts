import {Component, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';

@Component({
  selector: 'app-completion-rate',
  templateUrl: './completion-rate.page.html',
  styleUrls: ['./completion-rate.page.scss'],
})
export class CompletionRatePage implements OnInit {

  list: any[] = [];

  title = '结业考核情况';

  total: any = {};

  constructor(private help: Help) {
  }

  ngOnInit() {
    this.help.post('/completionrate/listMajorByParams', {}).subscribe(res => {
      if (res.success) {
        this.list = res.list;
        if (this.list.length > 0) {
          this.title = `${this.list[0].annual}结业考核情况`;
          const t = {qualifiedNumber: 0, unqualifiedNumber: 0, totalNumber: 0};
          this.list.forEach(r => {
            t.qualifiedNumber = t.qualifiedNumber + r.qualifiedNumber;
            t.unqualifiedNumber = t.unqualifiedNumber + r.unqualifiedNumber;
            t.totalNumber = t.totalNumber + r.totalNumber;
          });
          this.total = t;
        }
      }
    });
  }
}
