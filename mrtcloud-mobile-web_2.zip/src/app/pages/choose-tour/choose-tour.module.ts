import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChooseTourPageRoutingModule } from './choose-tour-routing.module';

import { ChooseTourPage } from './choose-tour.page';
import {FormatTimeModule} from "../../pipe/format-time/format-time.module";
import {BaseListModule} from "../../components/base-list/base-list.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChooseTourPageRoutingModule,
    FormatTimeModule,
    BaseListModule
  ],
  declarations: [ChooseTourPage]
})
export class ChooseTourPageModule {}
