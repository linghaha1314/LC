import {Component, OnInit} from '@angular/core';
import {StorageService} from '../../storage.service';
import {Router} from '@angular/router';
import {Help} from '../../utils/Help';
import {EventService} from '../../event.service';

@Component({
  selector: 'app-choose-tour',
  templateUrl: './choose-tour.page.html',
  styleUrls: ['./choose-tour.page.scss'],
})
export class ChooseTourPage implements OnInit {
  queryParams: any = {
    studentId: this.storage.get('userInfo').staff.id
  };
  hasTour = true;

  constructor(private storage: StorageService, private router: Router, private help: Help, private eventService: EventService) {
  }

  changeList = (data) => ({
    list: data.rows,
    total: data.total
  });

  ngOnInit() {
    this.eventService.event.on('update', async () => {
      this.queryParams = {...this.queryParams};
    });
  }

  goAdd() {
    this.help.showSelect({
      title: '选择导师',
      url: '/teacher/studentChoiceTutorList',
      listKey: 'list',
      labelKey: 'teacherName',
      subTextKey: 'serialNo',
      valueKey: 'teacherId',
      queryParams: {
        activeStatus: 0,
        placeId: this.storage.get('userInfo').staff.majorId
      }
    }).then(result => {
        if (!result) {
          return;
        }
        this.help.confirm({title: '温馨提示', msg: `确认选择 "${result.teacherName}" 作为导师?`}).then(r => {
          if (r) {
            this.help.post('/tutorchoice/choiceTutor', {
              teacherId: result.id, placeId: result.majorId
            }).subscribe(rr => {
              if (rr.success) {
                this.help.toastSuccess(rr.message);
                this.queryParams = {...this.queryParams};
              } else {
                this.help.toastError(rr.message);
              }
            });
          }
        });
      }
    );
  }
}
