import {Component, OnDestroy, OnInit} from '@angular/core';
import {EventService} from '../../event.service';
import {AlertController} from '@ionic/angular';
import {Router} from '@angular/router';
import {Help} from '../../utils/Help';

@Component({
  selector: 'app-classroom-test',
  templateUrl: './classroom-test.page.html',
  styleUrls: ['./classroom-test.page.scss'],
})
export class ClassroomTestPage implements OnInit, OnDestroy {

  queryParams: any = {};

  constructor(private eventService: EventService, public alertController: AlertController, private router: Router, private help: Help) {
  }

  changeList = (data) => ({
    list: data.rows,
    total: data.total
  });

  ngOnInit() {
    this.eventService.event.on('update', async () => {
      this.queryParams = {...this.queryParams};
    });
    this.help.post('/teachactivity/getActivityMemberDetail', {id: '23563508-f856-11ec-8980-0242ac110002'}).subscribe(r => {

    });
  }

  ngOnDestroy() {
    this.eventService.event.off('update');
  }

  async startExam(item) {
    if (item.type === '2' && item.examAnswerId) {
      localStorage.setItem('pageParams', JSON.stringify(item));
      this.router.navigate(['/CommonExam', item.volumeId], {queryParams: {isOnlyView: true}});
      return;
    }
    let msg = item.type === '1' ? `请选择正在进行中的教学活动` : '确定开始测试？';
    const cancel = {
      text: item.type !== '1' ? '确定' : '取消',
      role: 'cancel',
      cssClass: 'secondary',
      handler: () => {
      }
    };
    const startExam = {
      text: '开始测试',
      handler: () => {
        localStorage.setItem('pageParams', JSON.stringify(item));
        this.router.navigate(['/CommonExam', item.volumeId]);
      }
    };
    let buttons = item.type !== '1' ? [cancel] : [cancel, startExam];

    if (item.type === '2' && !item.examAnswerId) {
      msg = '已结束未答题，不能查看';
      buttons = [cancel];
    }

    const alert = await this.alertController.create({
      header: '温馨提示',
      message: msg,
      buttons,
    });

    await alert.present();

  }

  changeIosDate(d) {
    return new Date(d.replace(/-/g, '/')).getTime();
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  goExam() {
    this.router.navigate(['/OnlineExam/view']);
  }
}
