import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ClassroomTestPageRoutingModule } from './classroom-test-routing.module';

import { ClassroomTestPage } from './classroom-test.page';
import {BaseListModule} from "../../components/base-list/base-list.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        ClassroomTestPageRoutingModule,
        BaseListModule
    ],
  declarations: [ClassroomTestPage]
})
export class ClassroomTestPageModule {}
