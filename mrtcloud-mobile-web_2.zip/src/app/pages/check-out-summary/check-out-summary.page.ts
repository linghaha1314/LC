import {Component, OnInit, ViewChild} from '@angular/core';
import {EventService} from '../../event.service';
import {BaseListComponent} from '../../components/base-list/base-list.component';
import {StorageService} from '../../storage.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-check-out-summary',
  templateUrl: './check-out-summary.page.html',
  styleUrls: ['./check-out-summary.page.scss'],
})
export class CheckOutSummaryPage implements OnInit {
  @ViewChild('listComponent')
  baseList: BaseListComponent;
  queryParams: any = this.storage.get('currentIdentity').code.indexOf('Student') > -1 ? {
    studentId: this.storage.get('userInfo').student?.id
  } : {};
  url: any = '/turnsummary/getListQueryByPage';

  constructor(private router: Router, private eventService: EventService, public storage: StorageService) {
  }

  ngOnInit() {
    this.eventService.on('update', () => {
      this.baseList.doRefresh().then();
    });
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  goDetail(item: any) {
    this.storage.set('pageParams', item);
    if (item.status === 0 && this.storage.get('currentIdentity').code.indexOf('Student') > -1) {
      this.router.navigate(['/CheckOutSummary/edit']).then();
    } else {
      this.router.navigate(['/CheckOutSummary/view']).then();
    }
  }
}
