import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewPageRoutingModule } from './view-routing.module';

import { ViewPage } from './view.page';
import {FormDateModule} from "../../../components/form-date/form-date.module";
import {FormSelectModule} from "../../../components/form-select/form-select.module";
import {FileSelectModule} from "../../../components/file-select/file-select.module";
import {FormSelectOptionsModule} from "../../../components/form-select-options/form-select-options.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ViewPageRoutingModule,
    FormDateModule,
    FormSelectModule,
    ReactiveFormsModule,
    FileSelectModule,
    FormSelectOptionsModule
  ],
  declarations: [ViewPage]
})
export class ViewPageModule {}
