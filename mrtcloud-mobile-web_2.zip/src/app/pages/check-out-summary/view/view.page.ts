import {Component, OnInit} from '@angular/core';
import {ActionSheetController, NavController} from '@ionic/angular';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {StorageService} from '../../../storage.service';
import {EventService} from '../../../event.service';
import {Help} from '../../../utils/Help';
import {Router} from '@angular/router';
import {Location} from '@angular/common';

@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
  form: FormGroup;

  pageParams: any = {};

  sectionList: any = [];

  isView = this.router.url.indexOf('view') > -1;

  constructor(public storage: StorageService, private navCtrl: NavController, private eventService: EventService, private actionSheetController: ActionSheetController, private fb: FormBuilder, private help: Help, public router: Router, private location: Location) {
  }

  async ngOnInit() {
    this.pageParams = this.router.url.indexOf('add') > -1 ? {} : this.storage.get('pageParams');
    this.form = this.fb.group({
      studentId: [this.storage.get('currentIdentity').code.indexOf('Student') > -1 ? this.storage.get('userInfo').student?.id : null || null],
      sectionId: [this.pageParams.sectionId || null],
      sectionName: [this.pageParams.sectionName || null],
      sectionStaffId: this.storage.baseUrl.indexOf('cxzrmgp.mrtcloud.com') < 0 ? [this.pageParams.sectionStaffId || null, [Validators.required]] : [this.pageParams.sectionStaffId || null],
      sectionStaffName: [this.pageParams.sectionStaffName || null],
      teacherStaffId: this.storage.baseUrl.indexOf('cxzrmgp.mrtcloud.com') > -1 ? [this.pageParams.teacherId || null, [Validators.required]] : [this.pageParams.teacherId || null],
      teacherName: [this.pageParams.teacherName || null,],
      summary: [this.pageParams.summary || null, [Validators.required]],
      remark: [this.pageParams.remark || null],
      checkinId: [this.pageParams.checkinId || null],
      comment: [this.pageParams.comment || null]
    });
    if (this.router.url.indexOf('add') > -1) {
      this.getSection().then();
    } else {
      const b = await this.help.post('/transferschedule/myschedule', {
        pageNum: 1,
        pageSize: 1000
      }).toPromise();
      if (b.success) {
        this.sectionList = b.list;
      }
    }
  }

  async onSubmit() {
    if (this.storage.get('currentIdentity').code.indexOf('Student') < 0) {
      this.teacherSubmit();
      return;
    }
    if (this.help.formValid(this.form)) {
      this.help.confirm({title: '温馨提示', msg: '确认提交？'}).then(async r => {
          this.help.showLoading('提交中...').then();
          let url = '/turnsummary/create';
          const data = this.form.value;
          data.status = 0;
          if (this.router.url.indexOf('edit') > -1) {
            url = '/turnsummary/update';
            data.id = this.pageParams.id;
          }
          delete data.comment;
          const res = await this.help.post(url, data).toPromise();
          if (res.status >= 0) {
            this.help.toastSuccess('提交成功！');
            this.navCtrl.pop().then();
            this.eventService.event.emit('update');
          } else {
            this.help.toastError(res.message);
          }
        }
      );
    }
  }


  changeSelect(e: any, label: string) {
    if (label === 'section') {
      this.form.patchValue({
        sectionId: e.sectionId,
        sectionName: e.sectionName,
        teacherId: e.teacherId,
        teacherName: e.teacherName,
        checkinId: e.id
      });
      return;
    }
    if (label === 'sectionStaff' && !this.form.get('sectionId').value) {
      this.help.toastTip('请先选择轮转科室');
      return;
    }
  }

  async getSection() {
    const b = await this.help.post('/transferschedule/myschedule', {
      pageNum: 1,
      pageSize: 1000
    }).toPromise();
    if (b.success) {
      this.sectionList = b.list;
      if (b.list.length > 0) {
        this.form.patchValue({
          sectionId: b.list[0].sectionId,
          sectionName: b.list[0].sectionName,
          teacherId: b.list[0].teacherId,
          teacherName: b.list[0].teacherName,
          checkinId: b.list[0].id,
        });
      } else {
        this.help.toastError('暂无科室！');
      }
    }
  }

  //老师提交评语
  teacherSubmit() {
    this.help.confirm({title: '温馨提示', msg: '确认提交？'}).then(async r => {
      this.help.showLoading('提交中...').then();
      const res = await this.help.post('/turnsummary/update', {
        comment: this.form.get('comment').value,
        status: 1,
        id: this.pageParams.id
      }).toPromise();
      if (res.status >= 0) {
        this.help.toastSuccess('提交成功！');
        this.navCtrl.pop().then();
        this.eventService.event.emit('update');
      } else {
        this.help.toastError(res.message);
      }
    });
  }
}
