import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {CheckOutSummaryPage} from './check-out-summary.page';

const routes: Routes = [
  {
    path: '',
    component: CheckOutSummaryPage
  },
  {
    path: 'add',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  }, {
    path: 'edit',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  }, {
    path: 'view',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckOutSummaryPageRoutingModule {
}
