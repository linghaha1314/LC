import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CheckOutSummaryPageRoutingModule } from './check-out-summary-routing.module';

import { CheckOutSummaryPage } from './check-out-summary.page';
import {BaseListModule} from "../../components/base-list/base-list.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        CheckOutSummaryPageRoutingModule,
        BaseListModule
    ],
  declarations: [CheckOutSummaryPage]
})
export class CheckOutSummaryPageModule {}
