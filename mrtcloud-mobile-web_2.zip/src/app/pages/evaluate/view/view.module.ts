import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewPageRoutingModule } from './view-routing.module';

import { ViewPage } from './view.page';
import {BaseListModule} from '../../../components/base-list/base-list.module';
import {NoticeModule} from '../../../components/notice/notice.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        ViewPageRoutingModule,
        BaseListModule,
        NoticeModule
    ],
  declarations: [ViewPage]
})
export class ViewPageModule {}
