import {Component, OnInit} from '@angular/core';
import {Help} from '../../../utils/Help';
import {ActivatedRoute, Router} from '@angular/router';
import {AlertController} from '@ionic/angular';
import {EventService} from '../../../event.service';
import {Location} from '@angular/common';

@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
  list: any;
  queryParams: any = {
    evalTypeCode: this.route.snapshot.params.type,
  };
  status = '0';

  title = '评价列表';

  constructor(private eventService: EventService, private alertController: AlertController, private router: Router, private help: Help, private location: Location, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.eventService.event.on('update', () => {
      this.queryParams = {...this.queryParams};
    });
    const state: any = this.location.getState();
    this.title = state.name ?? this.title;
  }

  segmentChanged(e) {
    //切换状态,未评价不要status,不然返回的参数toStaffId===null(接口问题)
    if (e.detail.value === '2') {
      this.queryParams.status = 2;
    } else {
      delete this.queryParams.status;
    }
    this.queryParams = {...this.queryParams};
  }

  async goEval(item: any) {
    if (item.code && item.status == '0') {
      return;  //code存在只能查看不能评分
    }
    if (this.status == '0') {
      if (item.pleasureFlag === false) {
        //限制不到规定时间不能评论
        const alert = await this.alertController.create({
          header: '温馨提示',
          message: `<div>暂时不能评价</div><div>请在出科前五天或出科后三天内评价</div>`,
          buttons: [
            {
              text: '关闭',
              role: 'cancel'
            }
          ]
        });
        await alert.present();
        return;
      }
      item.volumeName = item.volumeName ?? item.toStaffName;
      localStorage.setItem('pageParams', JSON.stringify(item));
      await this.router.navigate(['/CommonEval', this.queryParams.evalTypeCode]);
    } else {
      //弹窗查看信息
      const message = item.code ? `<ion-grid><ion-row><ion-label>评价类型：&nbsp;</ion-label><ion-text>${item.typeName}</ion-text></ion-row>
                 <ion-row><ion-label>轮转时间：&nbsp;</ion-label><ion-text>${item.startDate}至${item.endDate}</ion-text></ion-row>
                 <ion-row><ion-label>评价时间：&nbsp;</ion-label><ion-text>${item.evalDate}</ion-text></ion-row>` :
        `<ion-grid><ion-row><ion-label>评价类型：&nbsp;</ion-label><ion-text>${item.typeName}</ion-text></ion-row>
                 <ion-row><ion-label>轮转时间：&nbsp;</ion-label><ion-text>${item.startDate}至${item.endDate}</ion-text></ion-row>
                 <ion-row><ion-label>评价时间：&nbsp;</ion-label><ion-text>${item.evalDate}</ion-text></ion-row>
                 <ion-row><ion-label>总分：&nbsp;</ion-label><ion-text>${item.totalScore}分</ion-text></ion-row>
                 <ion-row><ion-label>得分：&nbsp;</ion-label><ion-text>${item.score}分</ion-text></ion-row></ion-grid>`;
      const alert = await this.alertController.create({
        header: '详情',
        message,
        buttons: [
          {
            text: '关闭',
            role: 'cancel'
          }
        ]
      });
      await alert.present();
    }
  }

  search() {
    this.queryParams = {...this.queryParams};
  }
}
