import {Component, OnInit} from '@angular/core';
import {Help} from '../../../utils/Help';
import {Location} from '@angular/common';

@Component({
  selector: 'app-exam',
  templateUrl: './exam.page.html',
  styleUrls: ['./exam.page.scss'],
})
export class ExamPage implements OnInit {
  list: any[] = [];
  currentIndex = 0;
  volumeId: any;
  section: any = {};  //试卷类型
  pageParams: any = {};

  constructor(private help: Help, private location: Location) {
  }

  ngOnInit() {
    //获取pageParams
    const getParams: any = this.location.getState();
    if (JSON.stringify(getParams.item)) {
      this.pageParams = getParams.item;
      localStorage.setItem('pageParams', JSON.stringify(this.pageParams));
    } else {
      this.pageParams = localStorage.getItem('pageParams') ? JSON.parse(localStorage.getItem('pageParams')) : {};
    }

    this.help.get('/studentevaluate/getEvalTeachVolumeByCode/EvalType_TeacherToStudent ').subscribe(b => {
      this.section.volumeId = b.data.id;

      this.help.get('/studentevaluate/getQuestionAndOptionByVolumeId/' + b.data.id).subscribe(res => {
        this.list = res.list;
      });
    });
  }

  up() {
    if (this.currentIndex != 0) {
      this.currentIndex--;
    }
  }

  next() {
    let flag = true;
    this.list[this.currentIndex].options.map(res => {
      if (!res.indexResult) {
        flag = false;
        this.help.toastError('请选择或者填写所有选项');
      }
    });
    if (!flag) {
      return;
    }
    if (this.currentIndex < this.list.length - 1) {
      this.currentIndex++;
    }
  }

  save() {
    const queryParams = {
      sectionId: this.pageParams.sectionId,
      id: this.pageParams.evalId,
      toStaffId: this.pageParams.toStaffId,
      volumeId: this.section.volumeId,
      evalTypeCode: this.section.code,
      studentEvalId: this.pageParams.id,
      volumeName: this.section.name,
      is360Flag: true,
      detailList: [],
      totalScore: this.section.totalScore,
      score: 0
    };
    this.list.map(res => {
      if (res.styleCode == 'vescore') {
        res.options.map(option => {
          const optionObj = {
            indexId: res.id,
            indexName: res.name,
            staffId: JSON.parse(localStorage.getItem('userInfo')).staff.id,
            volumeId: this.section.volumeId,
            indexResult: option.indexResult,
            indexValue: option.indexResult
          };
          queryParams.detailList.push(optionObj);
        });
      } else {
        const detailObj = {
          indexId: res.id,
          indexName: res.name,
          staffId: JSON.parse(localStorage.getItem('userInfo')).staff.id,
          volumeId: this.section.volumeId,
          indexResult: res.indexResult,
          indexValue: res.indexValue || 0
        };
        queryParams.detailList.push(detailObj);
      }
    });
    //得分
    queryParams.detailList.map(res => {
      queryParams.score += res.indexValue;
    });
    this.help.showLoading().then();
    this.help.post('studentevaluate/saveQuestionResult', queryParams).subscribe(b => {
      this.help.toastSuccess(b.msg);
      this.location.back();
    });
  }
}
