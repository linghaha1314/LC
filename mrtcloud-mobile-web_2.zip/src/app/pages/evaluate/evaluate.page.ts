import {Component, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';
import {EventService} from '../../event.service';

@Component({
  selector: 'app-evaluate',
  templateUrl: './evaluate.page.html',
  styleUrls: ['./evaluate.page.scss'],
})
export class EvaluatePage implements OnInit {

  list: any;

  constructor(private eventService: EventService, private help: Help) {
  }

  ngOnInit() {
    this.help.get('/studentevaluate/getMyEvaluateTypeList').subscribe(b => {
      this.list = b.data;
    });
  }

}
