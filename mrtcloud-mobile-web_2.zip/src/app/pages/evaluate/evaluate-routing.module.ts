import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {EvaluatePage} from './evaluate.page';

const routes: Routes = [
  {
    path: '',
    component: EvaluatePage
  },
  {
    path: 'exam',
    loadChildren: () => import('./exam/exam.module').then(m => m.ExamPageModule)
  },
  {
    path: 'view/:type',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EvaluatePageRoutingModule {
}
