import {Component, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';
import {AlertController, ModalController, NavController} from '@ionic/angular';
import {ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {EventService} from '../../event.service';
import {StorageService} from '../../storage.service';

@Component({
  selector: 'app-common-exam',
  templateUrl: './common-eval-page.page.html',
  styleUrls: ['./common-eval-page.page.scss'],
})
export class CommonEvalPagePage implements OnInit {
  list: any[] = [];
  currentIndex = 0;
  pageParams: any = {};
  section: any = {};
  title: string;
  evalTypeCode: any;

  constructor(private storage: StorageService, private eventService: EventService, private navCtrl: NavController, private alertController: AlertController, private help: Help, private modalController: ModalController, private location: Location, private route: ActivatedRoute) {
  }

  async ngOnInit() {
    this.evalTypeCode = this.route.snapshot.params.code;
    this.pageParams = this.storage.get('pageParams') || {};
    this.title = this.pageParams.volumeName ?? this.pageParams.typeName;
    this.list = this.evalTypeCode === 'survey' ? await this.getSurvey().then() : await this.getAllEval().then();
    if (!this.list || this.list.length === 0) {
      this.help.toastError('没有试题');
      this.navCtrl.pop().then();
    }
  }

//获取调查问卷的题目
  async getSurvey() {
    this.help.showLoading('获取问卷中...').then();
    const data = (await this.help.get(`/surveyanswer/getQuestionAndOptionByVolumeId/${this.pageParams.volumeId}`, {}).toPromise()).list;
    await this.help.hideLoading();
    return data;
  }

//获取评价的题目,综合评价，出科评价,月度评价
  async getAllEval() {
    this.help.showLoading('获取问卷中...').then();
    this.section = (await this.help.get('/studentevaluate/getEvalTeachVolumeByCode/' + this.route.snapshot.params.code).toPromise()).data;
    const result = (await this.help.get('/studentevaluate/getQuestionAndOptionByVolumeId/' + this.section.id).toPromise()).list;
    await this.help.hideLoading();
    return result;
  }

  next() {
    let flag = true;
    if (!this.list[this.currentIndex].indexResult && this.list[this.currentIndex].styleCode !== 'vescore') {
      flag = false;
      this.help.toastError('请选择或者填写所有选项');
    } else if (this.list[this.currentIndex].styleCode === 'vescore') {
      this.list[this.currentIndex].options.map(res => {
        if (!res.indexResult) {
          flag = false;
          this.help.toastError('请选择或者填写所有选项');
        }
      });
    }
    if (flag && (this.currentIndex < this.list.length - 1)) {
      this.currentIndex++;
    }
    return flag;
  }

  async saveBefore(queryParams) {
    const alert = await this.alertController.create({
      message: this.evalTypeCode === 'survey' ? `确定提交？` : `确认提交？当前打分为<span class="getScore font-bold">${queryParams.score}</span>分`,
      buttons: [
        {
          text: '取消',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
          }
        }, {
          text: '确认',
          role: 'save',
          handler: () => {
            this.submit(queryParams);
          }
        },
      ]
    });
    await alert.present();
  }

  save() {
    if (!this.next()) {
      return;
    }
    let queryParams: any = {     //360评价
      sectionId: this.pageParams.sectionId,
      id: this.pageParams.evalId,
      toStaffId: this.pageParams.toStaffId,
      volumeId: this.section.id,
      evalTypeCode: this.section.code,
      studentEvalId: this.pageParams.id,
      volumeName: this.section.name,
      is360Flag: true,
      detailList: [],
      totalScore: this.section.totalScore,
      score: 0,
      startDate: this.pageParams.startDate,
      endDate: this.pageParams.endDate,
      transferId: this.pageParams.transferId
    };
    queryParams.detailList = [];
    this.list.map(res => {
      let optionObj: any;
      switch (this.route.snapshot.params.code) {
        case 'survey':
          if (res.styleCode == 'vescore') {
            res.options.map(option => {
              optionObj = {
                answerId: this.pageParams.id,
                questionId: res.id,
                questionName: res.name,
                staffId: JSON.parse(localStorage.getItem('userInfo')).staff.id,
                volumeId: res.volumeId,
                questionResult: option.id,
                questionValue: option.indexResult
              };
              queryParams.detailList.push(optionObj);
            });
          } else {
            optionObj = {
              answerId: this.pageParams.id,
              questionId: res.id,
              questionName: res.name,
              staffId: JSON.parse(localStorage.getItem('userInfo')).staff.id,
              volumeId: res.volumeId,
              questionResult: res.indexResult
            };
            queryParams.detailList.push(optionObj);
          }
          break;
        default:
          if (res.styleCode == 'vescore') {
            const len = res.options.length;
            res.options.map(option => {
              optionObj = {
                indexId: res.id,
                indexName: res.name,
                staffId: JSON.parse(localStorage.getItem('userInfo')).staff.id,
                volumeId: this.pageParams.id,    //???volumeId取list每个选项的id
                indexResult: option.id,    //???出科评价的一个打分题多个打分小题，option.indexResult 表示分数;月度评价，教学活动评价，出科评价都是取option.id
                indexValue: option.indexResult
              };
              queryParams.detailList.push(optionObj);
            });
          } else {
            optionObj = {
              indexId: res.id,
              indexName: res.name,
              staffId: JSON.parse(localStorage.getItem('userInfo')).staff.id,
              volumeId: this.pageParams.id,
              indexResult: res.indexResult,
              indexValue: res.indexValue || 0
            };
            queryParams.detailList.push(optionObj);
          }
          break;
      }
    });

    //月度评价,出科评价
    if (this.evalTypeCode === 'EvalType_StudentMonth' || this.evalTypeCode === 'EvalType_StudentCheckOut') {
      queryParams = {detailList: queryParams.detailList};
      queryParams.totalScore = this.section.totalScore;
      queryParams.volumeId = this.section.id;
      queryParams.evalTypeCode = this.section.code;
      queryParams.id = this.pageParams.evalId;
      queryParams.score = this.pageParams.score;
      queryParams.sectionId = this.pageParams.sectionId;
      queryParams.studentEvalId = this.pageParams.id;
      queryParams.toStaffId = this.pageParams.toStaffId;
      queryParams.transferId = this.pageParams.transferId;
      queryParams.volumeName = this.section.name;
    }
    //教学活动评价
    if (this.evalTypeCode === 'EvalType_ActivityEvaluate') {
      queryParams.toStaffId = null;
      queryParams.volumeId = this.section.id;
      queryParams.activityId = this.pageParams.id;
      queryParams.is360Flag = false;
      queryParams.detailList = queryParams.detailList;
    }
    if (this.evalTypeCode !== 'survey') {
      queryParams.detailList.map(res => {
        queryParams.score += (res.indexValue || 0);
      });
      if (queryParams.score < 0) {  //负分时，直接为0分
        queryParams.score = 0;
      }
    }
    this.saveBefore(queryParams).then();
  }

  submit(queryParams) {
    this.help.showLoading('提交中...').then();
    const url = this.evalTypeCode === 'survey' ? '/surveyanswer/saveQuestionResult' : (this.evalTypeCode === 'EvalType_ActivityEvaluate' ? '/teachactivity/saveQuestionResult' : '/studentevaluate/saveQuestionResult');
    const param = this.evalTypeCode === 'survey' ? queryParams.detailList : queryParams;
    this.help.post(url, param).subscribe(async b => {
      if (b.success) {
        const code = this.evalTypeCode.toString().toLowerCase();
        if (code.indexOf('evaltype_teacher') > -1) {
          this.help.toastSuccess('感谢您的评价,已确认本次工作带教学时!');
        } else if (code.indexOf('evaltype_student') > -1) {
          this.help.toastSuccess('感谢您的评价,已确认完成本次工作!');
        } else {
          this.help.toastSuccess('提交成功,感谢您的评价!');
        }
        await this.help.hideLoading();
        this.eventService.event.emit('update');
        await this.navCtrl.pop();
      }
    });
  }
}
