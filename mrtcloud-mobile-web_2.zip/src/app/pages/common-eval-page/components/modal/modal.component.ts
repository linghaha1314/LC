import {Component, OnInit} from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';

@Component({
  selector: 'exam-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss'],
})
export class ModalComponent implements OnInit {
  list: any[] = [];

  constructor(public modalCtrl: ModalController, public navParams: NavParams) {
  }

  ngOnInit() {
    this.list = this.navParams.data.list;
  }

  close() {
    this.modalCtrl.dismiss().then();
  }

  goIndex(key) {
    if (this.modalCtrl) {
      this.navParams.data.modal.dismiss({
        result: {
          currentIndex: key,
        }
      });
    }
  }
}
