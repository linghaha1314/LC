import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CommonEvalPagePage } from './common-eval-page.page';

const routes: Routes = [
  {
    path: '',
    component: CommonEvalPagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommonEvalPageRoutingModule {}
