import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {IonicModule} from '@ionic/angular';

import {CommonEvalPageRoutingModule} from './common-eval-page-routing.module';

import {CommonEvalPagePage} from './common-eval-page.page';
import {ExamListModule} from '../../components/exam-list/exam-list.module';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CommonEvalPageRoutingModule,
    ExamListModule
  ],
  declarations: [CommonEvalPagePage]
})
export class CommonEvalPageModule {
}
