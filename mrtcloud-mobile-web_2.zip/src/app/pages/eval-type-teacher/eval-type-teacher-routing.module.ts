import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {EvalTypeTeacherPage} from './eval-type-teacher.page';

const routes: Routes = [
  {
    path: '',
    component: EvalTypeTeacherPage
  },
  {
    path: 'view/:id',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EvalTypeTeacherPageRoutingModule {
}
