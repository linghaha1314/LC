import {Component, OnInit} from '@angular/core';
import {Help} from '../../../utils/Help';
import {Location} from '@angular/common';
import {NavController} from '@ionic/angular';
import {EventService} from '../../../event.service';


@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
  list: any[] = [];
  pageParams: any = {};

  constructor(private navCtrl: NavController, private eventService: EventService, private help: Help, private location: Location) {
  }

  ngOnInit() {
    const getParams: any = this.location.getState();
    if (JSON.stringify(getParams.item)) {
      this.pageParams = getParams.item;
      this.pageParams.currentPath = getParams.currentPath;
      localStorage.setItem('pageParams', JSON.stringify(this.pageParams));
    } else {
      this.pageParams = localStorage.getItem('pageParams') ? JSON.parse(localStorage.getItem('pageParams')) : {};
    }
    this.getData();
  }

  getData() {
    const url = this.pageParams.currentPath == 'FormativeEval_DOPS' ? 'EvalType_TeacherDOPS' : 'EvalType_TeacherMiniCEX';
    this.help.get(`/formativeevaluate/viewModule/${url}`).subscribe(b => {
      this.list = b.data.data;
      this.list.map(res => {
        if (res.styleCode == 'vescore') {
          res.indexResult = res.options[0].optionValue;
          res.indexValue = res.options[0].optionValue;
        }
      });
      this.pageParams.volumeId = b.data.volumeId;
      this.pageParams.volumeName = b.data.volumeName;
    });
  }

  save() {
    const queryParams = {
      evalFlag: 1,   //???每次都传的1
      sectionId: this.pageParams.sectionId,
      transferId: this.pageParams.id,
      volumeId: this.pageParams.volumeId,
      formativeEvalCode: this.pageParams.currentPath,
      toStaffId: this.pageParams.staffId,
      volumeName: this.pageParams.volumeName,
      detailList: []
    };
    let flag = true;
    this.list.map(res => {
      if (!res.indexResult) {
        flag = false;
        this.help.toastError('请填写完整');
        return;
      }
      const detailObj = {
        indexId: res.id,
        indexName: res.name,
        staffId: this.pageParams.staffId,
        volumeId: res.evalId,
        indexResult: res.indexResult,
        indexValue: res.indexValue || 0,
      };
      queryParams.detailList.push(detailObj);
    });
    if (!flag) {
      return;
    }
    this.help.confirm({title: '温馨提示', msg: '确定提交？'}).then(r => {
      if (r) {
        this.help.showLoading().then();
        this.help.post('/formativeevaluate/saveQuestionResult', queryParams).subscribe(b => {
          this.help.toastSuccess(b.msg);
          this.navCtrl.pop().then();
          this.eventService.event.emit('update');
        });
      }
    });
  }

  subAnd(key, num, maxNum) {
    const value = this.list[key].indexResult;
    if ((value === 0 && num < 0) || (value == maxNum && num > 0)) {
      return;
    }
    this.list[key].indexResult = value + num;
    this.list[key].indexValue = value + num;
  }

}
