import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EvalTypeTeacherPageRoutingModule } from './eval-type-teacher-routing.module';

import { EvalTypeTeacherPage } from './eval-type-teacher.page';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';
import {BaseListModule} from '../../components/base-list/base-list.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EvalTypeTeacherPageRoutingModule,
    FilterDropdownModule,
    BaseListModule
  ],
  declarations: [EvalTypeTeacherPage]
})
export class EvalTypeTeacherPageModule {}
