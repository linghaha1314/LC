import {Component, OnInit, QueryList, ViewChildren} from '@angular/core';
import {Help} from '../../utils/Help';
import {IonDatetime} from '@ionic/angular';
import {FilterDropdownData} from '../../components/filter-dropdown/filter-dropdown.component';

@Component({
  selector: 'app-check-in-determine',
  templateUrl: './check-out-determine.page.html',
  styleUrls: ['./check-out-determine.page.scss'],
})
export class CheckOutDeterminePage implements OnInit {
  @ViewChildren('datetime')
  dates: QueryList<IonDatetime>;
  queryParams: any = {
    stustatus: 0,
    checkinFlag: 1,
    waitingCheckInFlag: 1,
    studentStatus: 0,
    isOut: 0
  };
  checkTime: string;
  filters: FilterDropdownData = [
    // {code: 'sectionId', label: '科室', type: 'page', url: '/section/listAuthQueryByPage', listKey: 'rows'},
    {code: 'majorId', label: '专业', type: 'page', url: '/major/listAuthQueryByPage', listKey: 'rows'},
    {code: 'endMonth', label: '日期', type: 'date', dateType: 'month'}
  ];
  currentItem: any = {};
  isShowDate = false;
  currentIdentity: any;

  constructor(private help: Help,) {
  }

  changeList = (data) => ({
    list: data.rows,
    total: data.total
  });

  ngOnInit() {
    this.currentIdentity = JSON.parse(localStorage.getItem('currentIdentity'));
  }

  async determined(item) {
    this.openDate('date');
    this.currentItem = item;
  }

  openDate(name) {
    this.dates.filter(d => d.name === name)[0].open().then();
    setTimeout(() => {
      const dom = document.querySelectorAll('.picker-toolbar-button')[1];
      if (dom) {
        dom.addEventListener('click', (b) => {
          if (this.checkTime) {
            this.submit(this.currentItem).then();
          }
        });
      }
    }, 100);

  }

  async submit(item) {
    await this.help.showLoading('提交中...');
    await this.help.post('/transfercheckout/create', {
      hospitalId: item.hospitalId,
      checkinId: item.checkinId,
      sectionId: item.sectionId,
      studentId: item.studentId,
      status: 2,
      auditTime: this.help.formatTime() + ' ' + '00:00:00',
      applyTime: this.help.formatTime(this.checkTime) + ' ' + '00:00:00',
    }).subscribe(b => {
      if (b.status === 0) {
        this.help.toastSuccess('成功出科');
        this.queryParams = {...this.queryParams};
      } else {
        this.help.toastError(b.message);
      }
    });
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  changeParams(data: any) {
    this.queryParams = {...this.queryParams, ...data};
  }
}
