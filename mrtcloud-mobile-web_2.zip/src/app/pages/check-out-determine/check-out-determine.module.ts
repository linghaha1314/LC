import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {IonicModule} from '@ionic/angular';

import {CheckOutDetermineRoutingModule} from './check-out-determine-routing.module';

import {CheckOutDeterminePage} from './check-out-determine.page';
import {BaseListModule} from '../../components/base-list/base-list.module';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CheckOutDetermineRoutingModule,
    BaseListModule,
    FilterDropdownModule
  ],
  declarations: [CheckOutDeterminePage]
})
export class checkOutDetermineModule {
}
