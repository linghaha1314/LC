import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {IonicModule} from '@ionic/angular';

import {CommonExamPagePageRoutingModule} from './common-exam-page-routing.module';

import {CommonExamPagePage} from './common-exam-page.page';
import {ExamListModule} from '../../components/exam-list/exam-list.module';
import {QuestionComponentModule} from './question-component/question-component.module';
import {ModalModule} from './modal/modal.module';
import {LoadingTextModule} from '../../components/loading-text/loading-text.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        CommonExamPagePageRoutingModule,
        ExamListModule,
        QuestionComponentModule,
        ModalModule,
        LoadingTextModule
    ],
  declarations: [CommonExamPagePage],
})
export class CommonExamPagePageModule {
}
