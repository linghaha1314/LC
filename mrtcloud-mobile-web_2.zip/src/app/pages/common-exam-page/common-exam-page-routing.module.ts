import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {CanDeactivateTeam} from './common-exam-page.service';
import {CommonExamPagePage} from './common-exam-page.page';

const routes: Routes = [
  {
    path: '',
    component: CommonExamPagePage,
    canDeactivate: [CanDeactivateTeam]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [CanDeactivateTeam]
})
export class CommonExamPagePageRoutingModule {
}
