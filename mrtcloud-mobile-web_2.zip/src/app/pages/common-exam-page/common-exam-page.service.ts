import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree} from '@angular/router';
import {CommonExamPagePage} from './common-exam-page.page';
import {Observable} from 'rxjs';

@Injectable()
export class CanDeactivateTeam implements CanDeactivate<CommonExamPagePage> {
  constructor() {
  }

  canDeactivate(
    component: CommonExamPagePage,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return component.backCheck();
  }
}
