import {
  Component,
  ContentChild,
  Input,
  OnInit,
  Output,
  TemplateRef,
  EventEmitter,
} from '@angular/core';
import {ModalController} from '@ionic/angular';
import {ShowImgComponent} from '../show-img/show-img.component';


@Component({
  selector: 'question-component',
  templateUrl: './question-component.component.html',
  styleUrls: ['./question-component.component.scss'],
})
export class QuestionComponentComponent implements OnInit {
  @Input() item: any = {};

  @Input() sequence: any = {};

  @ContentChild(TemplateRef)
  templateRef: TemplateRef<any>;

  @Output()
  radioChange = new EventEmitter();

  constructor(private modalController: ModalController) {
  }

  ngOnInit() {
  }

  radioChangeFn(data) {
    data.examOptions?.forEach((res, index) => {
      if (data.answerResultId === res.id) {
        const rightLetter = String.fromCharCode(64 + parseInt(String(index + 1), 10));
        if (data.examQuestion && data.examQuestion.refAnswer?.indexOf(rightLetter) > -1) {
          //回答正确
          data.isError = false;
        } else {
          //回答错误
          data.isError = true;
        }
      }
    });
    this.radioChange.emit('radioChange');
  }

  async openDialog(src) {
    const modal = await this.modalController.create({
      component: ShowImgComponent,
      swipeToClose: true,
      cssClass: 'show-img',
      componentProps: {
        src
      }
    });
    return await modal.present();
  }
}
