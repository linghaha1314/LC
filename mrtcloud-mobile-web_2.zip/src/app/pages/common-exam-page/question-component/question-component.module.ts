import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {QuestionComponentComponent} from './question-component.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';
import {StarScoreModule} from '../../../components/star-score/star-score.module';
import {NumberToLetterModule} from '../../../pipe/number-to-letter/number-to-letter.module';
import {ShowImgModule} from '../show-img/show-img.module';
import {CustomImgModule} from "../../../components/custom-img/custom-img.module";
import {SafeHtmlModule} from "../../../pipe/SafeHtml.module";


@NgModule({
  declarations: [QuestionComponentComponent],
    imports: [
        CommonModule,
        IonicModule,
        FormsModule,
        NumberToLetterModule,
        StarScoreModule,
        ShowImgModule,
        CustomImgModule,
        SafeHtmlModule
    ], exports: [QuestionComponentComponent]
})
export class QuestionComponentModule {
}
