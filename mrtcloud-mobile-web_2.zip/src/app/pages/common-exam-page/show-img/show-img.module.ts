import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ShowImgComponent} from './show-img.component';
import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [ShowImgComponent],
  imports: [
    CommonModule,
    IonicModule,
  ], exports: [ShowImgComponent]
})
export class ShowImgModule {
}
