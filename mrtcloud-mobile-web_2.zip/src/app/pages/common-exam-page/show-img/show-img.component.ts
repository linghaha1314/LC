import {Component, OnInit, Sanitizer} from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import {switchMap} from 'rxjs/operators';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {of} from 'rxjs';
import {Buffer} from 'buffer';
import {StorageService} from '../../../storage.service';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-show-img',
  templateUrl: './show-img.component.html',
  styleUrls: ['./show-img.component.scss'],
})
export class ShowImgComponent implements OnInit {
  src: any;


  constructor(private sanitizer: DomSanitizer, private route: ActivatedRoute, private storageService: StorageService, private modalCtrl: ModalController, private navParams: NavParams) {
  }

  ngOnInit() {
    const imgPath = this.navParams.data.src;
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => of(params.get('id')))
    ).subscribe(d => {
      let url = this.storageService.baseUrl ? this.storageService.baseUrl : (window.location.protocol + '//' + window.location.host);
      url = url + imgPath;
      this.src = this.sanitizer.bypassSecurityTrustResourceUrl(`http://116.63.185.184:8012/onlinePreview?url=` + encodeURIComponent(Buffer.from(url).toString('base64')));
    });
  }

  closed() {
    this.modalCtrl.dismiss({
      dismissed: true
    }).then();
  }
}
