import {Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Help} from '../../utils/Help';
import {
  AlertController,
  IonRouterOutlet, LoadingController,
  ModalController,
  NavController
} from '@ionic/angular';
import {ModalComponent} from './modal/modal.component';
import {EventService} from '../../event.service';
import {StorageService} from '../../storage.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-common-exam-page',
  templateUrl: './common-exam-page.page.html',
  styleUrls: ['./common-exam-page.page.scss'],
})
export class CommonExamPagePage implements OnInit, OnDestroy {
  @ViewChild('content')
  content: ElementRef;

  list: any[] = [];

  currentIndex = 0;

  pageParams: any = {
    allowEmpty: true
  };

  section: any = {};

  title: string;

  answerList: any[] = [];

  examObj: any = {};

  isShowPage = false;

  isSubmit = false;

  timer = null;

  examData: any = {};

  loading: HTMLIonLoadingElement;

  isOnlyView = false;

  isShowAnalysis = false;

  answerResultList = [];

  constructor(private route: ActivatedRoute, private loadingController: LoadingController, private storage: StorageService, private routerOutlet: IonRouterOutlet, private eventService: EventService, private navCtrl: NavController, private alertController: AlertController, private help: Help, private modalController: ModalController) {
  }

  @HostListener('document:visibilitychange', ['$event'])
  async visibilitychange() {  //监听切屏
    if (!document.hidden && this.pageParams.cheatFlag) {
      await this.checkContinueFlag();
    }
    if (document.hidden) {
      this.historyStorage();
    }
  }

  //作弊插入
  async insertContinueFlag() {
    const result = await this.help.post('/examaberrant/listByObj', {
      planId: this.pageParams.id, staffId: this.storage.get('userInfo').staff?.id
    }).toPromise();
    if (result.data[0].continueFlag === false && result.data[0].status === 0) {
      return;
    }
    this.help.post('/examaberrant/insert', {
      planId: this.pageParams.id,
      staffId: this.storage.get('userInfo').staff?.id
    }).subscribe(r => {
    });
  }

  //作弊loading
  async showLoading() {
    if (document.querySelector('ion-loading')) {
      return;
    }
    await this.loading?.dismiss();
    await this.insertContinueFlag();
    this.loading = await this.loadingController.create({
      message: '检测到你考试有非正常退出或切屏，请不要退出并联系老师解除考试限制',
      backdropDismiss: false,
    });
    await this.loading.present();
  }

  //检查作弊状态
  async checkContinueFlag() {
    if (this.timer != null) {
      return;
    }
    await this.showLoading();
    this.timer = setInterval(async () => {
      await this.showLoading();
      this.help.post('/examaberrant/listByObj', {
        planId: this.pageParams.id, staffId: this.storage.get('userInfo').staff?.id
      }).subscribe(r => {
        if (r.data[0].status === 1) {
          this.save(false);
          this.loading.dismiss().then();
          clearInterval(this.timer);
          this.timer = null;
        }
        if (r.data[0].continueFlag) {
          this.loading.dismiss().then();
          clearInterval(this.timer);
          this.timer = null;
        }
      });
    }, 2000);
  }

  //已经做过，获取每道题目的答案和选项，做题记录
  async getAnswer() {
    if (!this.pageParams.examAnswerId) {
      return;
    }
    await this.help.post('/examvolumequestion/getExamResult', {
      examId: this.pageParams.activityExamId,
      answerId: this.pageParams.examAnswerId,
      volumeId: this.pageParams.volumeId,
      uncontainsAnswerStatus: 1
    }).subscribe(r => {
      if (r.list.length === 0) {
        return;
      }
      this.isShowAnalysis = true;
      this.answerResultList = r.list;
      this.list.forEach((res, index) => {
        if (res.examQuestion.typeCode === 'radio') {
          res.isError = true;
          res.answerResultId = r.list[index]?.value || null;
        } else if (res.examQuestion.typeCode === 'checkbox') {
          //修改多选的项目
        } else {
          res.answerText = r.list[index]?.value;
        }
      });
    });
  }

  async ngOnInit() {
    //主要是找到封装手势滑动的方法，关闭它
    this.pageParams = localStorage.getItem('pageParams') ? JSON.parse(localStorage.getItem('pageParams')) : {};
    this.examData = this.storage.get('examData' + this.pageParams.volumeId) || {};
    this.isOnlyView = Boolean(this.route.snapshot.queryParams?.isOnlyView) || false;
    if (this.examData.list?.length > 0 && this.pageParams.cheatFlag) {
      await this.checkContinueFlag();
    }
    //获取试题卷信息
    await this.help.get(`/examvolume/getById/${this.pageParams.volumeId}`).toPromise().then(b => {
      if (b.success) {
        this.examObj = {
          volumeId: b.data.id,
          volumeName: b.data.title,
        };
      }
    });
    await this.help.post('/examanswer/saveExamStartInfo', {
      volumeId: this.examObj.volumeId,
      examId: this.pageParams.id,   //???planId 不确定
    }).toPromise().then((res) => {
      this.examObj.pId = res.data.id;
    });
    await this.getQuestions();
    this.historyStorage();
    await this.getAnswer();
  }

  ngOnDestroy() {
  }

  //存储历史题目
  historyStorage() {
    this.storage.set('examData' + this.pageParams.volumeId, {
      id: this.pageParams.volumeId,
      currentNo: this.storage.get('userInfo').staff?.serialNo,
      currentIndex: this.currentIndex,
      list: this.list
    });
  }

  //返回监听
  backCheck(): Promise<boolean> {
    return new Promise(resolve => {
      if (this.isSubmit) {
        resolve(true);
        return;
      }
      if (!this.isSubmit && document.querySelector('ion-loading')) {
        resolve(false);
        return;
      }
      if (!this.isSubmit) {
        this.help.confirm({title: '温馨提示', msg: '考试未完成，确认要退出吗？'}).then(r => {
          if (r) {
            this.storage.remove('examData' + this.pageParams.volumeId);
            resolve(true);
          } else {
            resolve(false);
          }
        });
      }
    });
  }

  next() {
    this.isAnsweredFn();
    if (this.currentIndex < this.list.length - 1) {
      this.currentIndex++;
    }
    this.historyStorage();
  }

  up() {
    this.isAnsweredFn();
    this.currentIndex += -1;
    this.historyStorage();
  }

  /*判断当前题目是否完成*/
  isAnsweredFn() {
    const data = this.list[this.currentIndex];
    data.flag = false;
    if (data.answerText || data.answerResultId) {
      data.flag = true;
    } else {
      data.examOptions.forEach(option => {
        if (option.isChecked || option.indexResult) {
          data.flag = true;
        }
      });
    }
  }

  async getQuestions() {
    if (this.pageParams.volumeId === this.examData.id && this.examData.list.length > 0 && this.examData.currentNo === this.storage.get('userInfo').staff?.serialNo) {
      this.list = this.examData.list;
      this.currentIndex = this.examData.currentIndex;
      this.isShowPage = true;
    } else {
      //获取试卷信息
      await this.help.post('/examvolumequestion/getVolumeQuestionPage', {
        volumeId: this.pageParams.volumeId,
        examId: '',
        examPlanId: this.pageParams?.id || null
      }).toPromise().then(b => {
        this.list = b.list;
        this.isShowPage = true;
      });
    }
  }

  async save(showAlert: boolean = true) {
    this.isAnsweredFn();
    this.answerList = [];
    let count = 0;  //未做的题
    this.list.forEach(res => {
      if (!res.flag) {
        count++;
      }
      const answer: any = {
        volumeId: this.examObj.volumeId,
        volumeName: this.examObj.volumeName,
        questionId: res.examQuestion.id,
        questionName: res.examQuestion.name,
        pId: this.examObj.pId,
      };
      switch (res.examQuestion.typeCode) {
        case 'shortblank':
          answer.answerText = res.answerText;
          this.answerList.push(answer);
          break;
        case 'checkbox':
          answer.optionId = '';//拼接选项ID
          res.examOptions.forEach(option => {
            if (option.isChecked) {
              answer.optionId += option.id + ',';
            }
          });
          answer.optionId = answer.optionId.slice(0, answer.optionId.length - 1);
          this.answerList.push(answer);
          break;
        case 'score':
          res.examOptions.forEach(option => {
            const optionObj: any = {
              volumeId: this.examObj.volumeId,
              volumeName: this.examObj.volumeName,
              questionId: res.examQuestion.id,
              questionName: res.examQuestion.name,
              pId: this.examObj.pId,
              optionId: option.id,
              gotScore: option.indexResult
            };
            if (res.pid) {
              optionObj.pId = res.pid;
            }
            this.answerList.push(optionObj);
          });
          break;
        case 'fillblank':
          answer.answerText = res.answerText;
          this.answerList.push(answer);
          break;
        case 'radio':
          answer.optionId = res.answerResultId;
          this.answerList.push(answer);
          break;
      }
    });
    if (showAlert) {
      const alert = await this.alertController.create({
        cssClass: 'my-custom-class',
        header: '提示',
        message: count !== 0 ? `还有${count}道题未做题，确定交卷？` : '确认交卷？',
        buttons: [
          {
            text: '取消',
            role: 'cancel',
            cssClass: 'secondary',
            handler: () => {
            }
          }, {
            text: '确认',
            role: 'save',
            handler: async () => {
              await this.submit(count);
            }
          },
        ]
      });
      await alert.present();
    } else {
      await this.submit(count);
    }
  }

  async submit(count) {
    await this.help.showLoading('交卷中...');
    const result = await this.help.post('/examanswer/completed', {
      completeNum: this.list.length - count,
      totalNum: this.list.length,
      id: this.examObj.pId,
    }, {}, true, true, false).toPromise();
    if (result) {
      this.help.post('/examanswerresult/saveAnswer', this.answerList).subscribe((res) => {
        if (res.success) {
          this.isSubmit = true;
          this.storage.remove('examData' + this.pageParams.volumeId);
          this.help.toastSuccess('试卷已提交');
          this.help.hideLoading();
          this.navCtrl.pop();
          this.eventService.event.emit('update');
        }
      });
    }
  }

  async showModal() {
    this.isAnsweredFn();
    if (!this.list.length) {
      return;
    }
    const modal = await this.modalController.create({
      component: ModalComponent,
      cssClass: '',
      componentProps: {list: this.list},
      swipeToClose: true
    });
    await modal.present();
    const {data} = await modal.onDidDismiss();
    if (data) {
      this.currentIndex = data.result.currentIndex;
    }
  }
}
