import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {StaffModalComponent} from './staff-modal.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';
import {BaseListModule} from '../../../components/base-list/base-list.module';


@NgModule({
  declarations: [StaffModalComponent],
  exports: [StaffModalComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    BaseListModule
  ],
})
export class StaffModalModule {
}
