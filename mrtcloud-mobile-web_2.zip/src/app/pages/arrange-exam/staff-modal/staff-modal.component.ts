import {Component, OnInit} from '@angular/core';
import {Help} from '../../../utils/Help';
import {ModalController, NavParams} from '@ionic/angular';

@Component({
  selector: 'app-staff-modal',
  templateUrl: './staff-modal.component.html',
  styleUrls: ['./staff-modal.component.scss'],
})
export class StaffModalComponent implements OnInit {
  queryParams: any = {
    name: null,
    pageNum: 1,
    pageSize: 1000,
  };
  currentObj: any;


  constructor(public help: Help, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ngOnInit() {
    this.currentObj = this.navParams.data.item;
    const date = this.help.formatTime(this.currentObj.checkoutDate, 'YY-MM');
    this.queryParams.planId = this.currentObj.id;
    this.queryParams.checkoutStartDate = date + '-01';  //这个月第一天？？
    this.queryParams.checkoutEndDate = date + '-' + new Date(this.help.formatTime(this.currentObj.checkoutDate, 'YY'), this.help.formatTime(this.currentObj.checkoutDate, 'MM'), 0).getDate();     //这个月最后一天？？
  }

  changeList = (data: any) => ({
    list: data.rows,
    total: data.total
  });

  close() {
    this.modalCtrl.dismiss().then();
  }

  async changeStatus(item: any) {
    if (item.status === 3) {
      this.help.toastTip('如需移除该人员，请到电脑端操作！');
      // this.help.confirm({title: '温馨提示', msg: '不建议此操作，您确定移除该人员？'}).then(async r => {
      //   if (r) {
      //     await this.help.post('/checkoutsectionstudent/removeAndExamPlanUser', {
      //       studentId: item.studentId,
      //       examPlanId: this.currentObj.examPlanId,
      //       volumeId: this.currentObj.volumeId,
      //       checkId: item.checkId
      //     }).toPromise().then(b => {
      //       this.help.toastSuccess('移除人员成功！');
      //       this.queryParams = {...this.queryParams}; //刷新数据
      //     });
      //   }
      // });
    } else {
      await this.help.post('/checkoutsectionstudent/createAndExamPlanUser', {
        planId: this.currentObj.id,
        studentId: item.studentId,
        status: 3,
        transferId: item.transferId,
        examPlanId: this.currentObj.examPlanId,
        volumeId: this.currentObj.theoryVolumeId
      }).toPromise().then(b => {
        if (b.status == -1) {
          this.help.toastError(b.message);
        } else {
          this.help.toastSuccess('加入人员成功！');
          this.queryParams = {...this.queryParams}; //刷新数据
        }
      });
    }
  }

  search() {
    this.queryParams = {...this.queryParams};
  }
}
