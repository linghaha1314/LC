import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FilesUpdatePageRoutingModule } from './files-update-routing.module';

import { FilesUpdatePage } from './files-update.page';
import {FileSelectModule} from "../../../components/file-select/file-select.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FilesUpdatePageRoutingModule,
    FileSelectModule,
    ReactiveFormsModule
  ],
  declarations: [FilesUpdatePage]
})
export class FilesUpdatePageModule {}
