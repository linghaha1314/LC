import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FilesUpdatePage } from './files-update.page';

const routes: Routes = [
  {
    path: '',
    component: FilesUpdatePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FilesUpdatePageRoutingModule {}
