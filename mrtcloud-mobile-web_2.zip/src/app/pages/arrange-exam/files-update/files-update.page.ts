import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {EventService} from '../../../event.service';
import {NavController} from '@ionic/angular';
import {StorageService} from '../../../storage.service';
import {Help} from '../../../utils/Help';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-files-update',
  templateUrl: './files-update.page.html',
  styleUrls: ['./files-update.page.scss'],
})
export class FilesUpdatePage implements OnInit {

  form: FormGroup;


  constructor(private route: ActivatedRoute, private eventService: EventService, private navCtrl: NavController, private storage: StorageService, private help: Help, private fb: FormBuilder) {
  }

  ngOnInit() {
    const arr: any = [];
    const list = (this.storage.get('pageParams')).attach.split(',');
    list.forEach(res => {
      const obj = {
        icon: res,
        name: this.help.getFileName(res),
        path: res
      };
      arr.push(obj);
    });
    this.form = this.fb.group({
      attachList: [arr]
    });
  }


  update() {
    const list = this.form.value.attachList || [];
    let attach = '';
    list.forEach((res, index) => {
      attach += (index === list.length - 1 ? res.path : res.path + ',');
    });
    this.help.post('/checkoutsectionplan/update', {id: this.route.snapshot.params.id, attach}).subscribe(r => {
      this.help.toastSuccess('提交成功！');
      this.navCtrl.pop().then();
      this.eventService.event.emit('update');
    });
  }
}
