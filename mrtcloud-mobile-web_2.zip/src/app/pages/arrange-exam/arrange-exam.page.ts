import {Component, OnDestroy, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';
import {ModalController} from '@ionic/angular';
import {Router} from '@angular/router';
import {EventService} from '../../event.service';
import {StaffModalComponent} from './staff-modal/staff-modal.component';
import {StorageService} from '../../storage.service';

@Component({
  selector: 'app-arrange-exam',
  templateUrl: './arrange-exam.page.html',
  styleUrls: ['./arrange-exam.page.scss'],
})
export class ArrangeExamPage implements OnInit, OnDestroy {
  queryParams: any = {};
  staffList: any = [];
  attachList: any = [];

  constructor(public storage: StorageService, private eventService: EventService, private router: Router, private modalController: ModalController, private help: Help) {
  }

  ngOnInit() {
    this.eventService.event.on('update', async () => {
      this.queryParams = {...this.queryParams};
    });
  }

  ngOnDestroy() {
    this.eventService.event.off('update');
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  changeParams(data: any) {
    this.queryParams = {...data, ...this.queryParams};
  }

  async addStaff(e, item) {
    e.preventDefault();
    e.stopPropagation();
    const modal = await this.modalController.create({
      component: StaffModalComponent,
      cssClass: '',
      componentProps: {item},
      swipeToClose: true,
    });
    await modal.present();
  }

  itemArr(str) {
    if (str) {
      return str.split(',');
    } else {
      return [];
    }
  }

  goView(item: any) {
    let msg: any = '';
    if (item.theoryVolumeName) {
      msg = '<h5>理论考核</h5>';
      this.itemArr(item.theory).forEach((res, index) => {
        if (index <= this.itemArr(item.theory).length - 3) {
          msg += `<p class="ion-text-left">${res}</p>`;
        }
      });
      msg += `<p class="ion-text-left ion-text-wrap">考核表:${item.theoryVolumeName}</p>`;
    }
    if (item.skillVolumeName) {
      msg += '<h5>技能考核</h5>';
      this.itemArr(item.skill).forEach((res, index) => {
        if (index <= this.itemArr(item.skill).length - 3) {
          msg += `<p class="ion-text-left">${res}</p>`;
        }
      });
      msg += `<p class="ion-text-left ion-text-wrap">考核表:${item.skillVolumeName || null}</p>`;
    } else {
      msg += '<h5>技能考核</h5>';
      this.itemArr(item.skill).forEach((res, index) => {
        if (index <= this.itemArr(item.skill).length - 3) {
          msg += `<p class="ion-text-left">${res}</p>`;
        }
      });
      msg += `<p class="ion-text-left ion-text-wrap">请前往pc端手动录入成绩</p>`;
    }
    this.help.confirm({
      msg, btn: [
        {
          text: '关闭',
          role: 'cancel'
        }
      ]
    }).then();
  }

  updateFile(e, item: any) {
    e.preventDefault();
    e.stopPropagation();
    this.storage.set('pageParams', {...item});
    this.router.navigate(['/ArrangeExam/updateFiles', item.id]).then();
  }
}
