import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {IonicModule} from '@ionic/angular';

import {EditPageRoutingModule} from './edit-routing.module';

import {EditPage} from './edit.page';
import {SubAddModule} from '../../../components/sub-add/sub-add.module';
import {FormDateModule} from '../../../components/form-date/form-date.module';
import {FormSelectModule} from '../../../components/form-select/form-select.module';
import {StaffModalModule} from '../staff-modal/staff-modal.module';
import {FileSelectModule} from "../../../components/file-select/file-select.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        EditPageRoutingModule,
        ReactiveFormsModule,
        SubAddModule,
        FormDateModule,
        FormSelectModule,
        StaffModalModule,
        FileSelectModule
    ],
  declarations: [EditPage]
})
export class EditPageModule {
}
