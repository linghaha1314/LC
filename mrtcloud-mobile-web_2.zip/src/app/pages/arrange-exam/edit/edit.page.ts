import {Component, OnInit} from '@angular/core';

import {Help} from '../../../utils/Help';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {StorageService} from '../../../storage.service';
import {NavController} from '@ionic/angular';
import {EventService} from '../../../event.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {
  isTheory = true;
  form: FormGroup;
  filesForm: FormGroup = this.fb.group({
    attachList: [[]]
  });
  isSkill = true;
  staff: any = {};
  typeIds: any = {};  //所有的考核类型id
  planId: any;  //出科计划安排id


  constructor(private eventService: EventService, private navCtrl: NavController, public storage: StorageService, private help: Help, private fb: FormBuilder) {
  }

  changeData = (data: any) => data.data.data;

  async ngOnInit() {
    this.changeStatus();
    this.staff = this.storage.get('userInfo').staff; //获取当前创建人员的信息
    await this.getTyId();
  }


  async onSubmit() {
    if (!this.isTheory && !this.isSkill) {
      this.help.toastTip('至少选择一个考试设置');
      return;
    }
    if (!this.help.formValid(this.form)) {
      return;
    }
    this.help.confirm({title: '温馨提示', msg: '确定安排考试？'}).then(async rr => {
      if (rr) {
        await this.help.showLoading('提交中...');
        //创建考试
        let examPlanId = null;
        if (this.isTheory) {
          await this.help.post('/examplan/createPlanAndUser', {
            id: null,
            startDate: this.form.get('checkDate').value + ' ' + this.form.get('startTime').value,
            endDate: this.form.get('checkDate').value + ' ' + this.form.get('endTime').value,
            name: this.form.get('planName').value,
            volumeId: this.form.get('volumeId').value,
            scoreLine: this.form.get('qualifiedScore').value,
            staffIds: [],
            endNum: 0,
            typeFlag: 0,
            effectiveIp: 0,
            refresh: 0,
            mixFlag: false,
            type: 'checkoutsection',
            sectionId: this.staff.sectionId,   //当前创建人员的科室id
          }).toPromise().then(r => {
            examPlanId = r.obj.reasons.data.id;
          });
        }
        //创建出科计划安排--必须请求
        let attach = '';
        if (this.filesForm.value.attachList.length > 0) {
          this.filesForm.value.attachList.forEach((res, index) => {
            attach += (index === this.filesForm.value.attachList.length - 1 ? res.path : (res.path + ','));
          });
        }
        await this.help.post('/checkoutsectionplan/create', {
          id: null,
          hospitalId: '',
          majorId: '',
          sectionId: this.staff.sectionId,
          checkoutDate: this.form.get('checkoutDate').value + ' ' + '00:00:00',
          userId: '',
          created: '',
          remark: this.form.get('remark').value,  //备注
          hospitalName: '',
          majorName: '',
          sectionName: '',
          userName: '',
          status: 1,
          attach: attach || null,
          examPlanId
        }).toPromise().then(r => {
          this.planId = r.data.reasons.data.id;
        });
        if (this.isTheory && !this.isSkill) {
          await this.submitTheory();
        } else if (!this.isTheory && this.isSkill) {
          await this.submitSkill();
        } else {
          await this.submitTheory();
          await this.submitSkill();
        }
        this.help.toastSuccess('提交成功...');
        await this.navCtrl.pop().then();
        this.eventService.event.emit('update');
      }
    });

  }

  async submitTheory() {
    const param = this.form.value;
    delete param.checkoutDate;
    delete param.remark;
    delete param.attachList;
    param.planId = this.planId;
    param.typeId = this.typeIds.theory;
    param.checkDate = param.checkDate + ' ' + '00:00:00';
    await this.help.post('/checkoutsectionplanrange/create', param).toPromise().then();
  }

  async submitSkill() {
    const param = this.form.value;
    delete param.checkoutDate;
    delete param.remark;
    Object.keys(param).forEach(key => {
      const newKey = key.split('Skill')[0];
      const value = param[key];
      param[newKey] = value;
      delete param[key];
    });
    //改变key的名字
    param.checkDate = param.checkDate + ' ' + '00:00:00';
    param.planId = this.planId;
    param.typeId = this.typeIds.skill;
    await this.help.post('/checkoutsectionplanrange/create', param).toPromise().then();
  }

  async getTyId() {
    await this.help.post('/dictionary/getByTypeCode/checkOutType', {}).toPromise().then(b => {
      b.data.forEach(res => {
        this.typeIds[res.code] = res.id;
      });
    });
  }

  selectVolume(e, label) {
    this.form.patchValue({['volumeId' + label]: e.id});
    this.form.patchValue({['volumeName' + label]: e.title || e.name});
  }

  switch() {
    this.isTheory = !this.isTheory;
  }

  changeVal(e, label) {
    this.form.patchValue({['qualifiedScore' + label]: e});
  }

  selectStaff(e, label) {
    this.form.patchValue({['contactPhone' + label]: e.mobile});
    this.form.patchValue({['contactName' + label]: e.name});
    this.form.patchValue({['contactId' + label]: e.id});
  }

  changeStatus() {
    if (this.isTheory && !this.isSkill) {
      this.form = this.fb.group({
        checkoutDate: [null, [Validators.required]],
        remark: [null],
        planName: [null, [Validators.required]],
        checkDate: [null, [Validators.required]],
        startTime: [null, [Validators.required]],
        endTime: [null, [Validators.required]],
        address: [null, [Validators.required]],
        contactId: [null, [Validators.required]],
        contactName: [null, [Validators.required]],
        contactPhone: [null, [Validators.required]],
        volumeId: [null, [Validators.required]],
        volumeName: [null, [Validators.required]],
        qualifiedScore: [null]
      });
    } else if (!this.isTheory && this.isSkill) {
      this.form = this.fb.group({
        checkoutDate: [null, [Validators.required]],
        remark: [null],
        checkDateSkill: [null, [Validators.required]],
        startTimeSkill: [null, [Validators.required]],
        endTimeSkill: [null, [Validators.required]],
        addressSkill: [null, [Validators.required]],
        contactIdSkill: [null, [Validators.required]],
        contactNameSkill: [null, [Validators.required]],
        contactPhoneSkill: [null, [Validators.required]],
        volumeIdSkill: [null],
        volumeNameSkill: [null],
        qualifiedScoreSkill: [null]
      });
    } else {
      this.form = this.fb.group({
        checkoutDate: [null, [Validators.required]],
        remark: [null],
        planName: [null, [Validators.required]],
        checkDate: [null, [Validators.required]],
        startTime: [null, [Validators.required]],
        endTime: [null, [Validators.required]],
        address: [null, [Validators.required]],
        contactId: [null, [Validators.required]],
        contactName: [null, [Validators.required]],
        contactPhone: [null, [Validators.required]],
        volumeId: [null, [Validators.required]],
        volumeName: [null, [Validators.required]],
        qualifiedScore: [null],
        checkDateSkill: [null, [Validators.required]],
        startTimeSkill: [null, [Validators.required]],
        endTimeSkill: [null, [Validators.required]],
        addressSkill: [null, [Validators.required]],
        contactIdSkill: [null, [Validators.required]],
        contactNameSkill: [null, [Validators.required]],
        contactPhoneSkill: [null, [Validators.required]],
        volumeIdSkill: [null],
        volumeNameSkill: [null],
        qualifiedScoreSkill: [null]
      });
    }
  }
}
