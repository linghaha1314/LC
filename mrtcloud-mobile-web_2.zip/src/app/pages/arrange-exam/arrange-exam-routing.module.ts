import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {ArrangeExamPage} from './arrange-exam.page';

const routes: Routes = [
  {
    path: '',
    component: ArrangeExamPage
  },
  {
    path: 'add',
    loadChildren: () => import('./edit/edit.module').then(m => m.EditPageModule)
  }, {
    path: 'edit',
    loadChildren: () => import('./edit/edit.module').then(m => m.EditPageModule)
  },
  {
    path: 'updateFiles/:id',
    loadChildren: () => import('./files-update/files-update.module').then( m => m.FilesUpdatePageModule)
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ArrangeExamPageRoutingModule {
}
