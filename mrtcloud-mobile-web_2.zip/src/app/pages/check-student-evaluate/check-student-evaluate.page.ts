import {Component, OnInit} from '@angular/core';
import {FilterDropdownData} from '../../components/filter-dropdown/filter-dropdown.component';

@Component({
  selector: 'app-check-student-evaluate',
  templateUrl: './check-student-evaluate.page.html',
  styleUrls: ['./check-student-evaluate.page.scss'],
})
export class CheckStudentEvaluatePage implements OnInit {
  queryParams: any = {};
  filters: FilterDropdownData = [
    {
      code: 'evaluateFlag',
      label: '状态',
      type: 'static',
      value: '2',
      selectText: '全部',
      isShowAllType: 0,
      data: [{id: '2', name: '全部'}, {id: '0', name: '未评价'}, {id: '1', name: '已评价'}]
    },
    {code: 'evalRange', label: '日期', type: 'date', dateType: 'month'}
  ];

  constructor() {
  }

  ngOnInit() {
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  changeParams(data: any) {
    if (data.evaluateFlag === '2') {
      delete data.evaluateFlag;
      delete this.queryParams.evaluateFlag;
    }
    this.queryParams = {...this.queryParams, ...data};
  }
}
