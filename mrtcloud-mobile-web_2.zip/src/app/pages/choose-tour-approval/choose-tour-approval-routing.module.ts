import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChooseTourApprovalPage } from './choose-tour-approval.page';

const routes: Routes = [
  {
    path: '',
    component: ChooseTourApprovalPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChooseTourApprovalPageRoutingModule {}
