import {Component, OnInit} from '@angular/core';
import {AlertController} from '@ionic/angular';
import {Help} from '../../utils/Help';

@Component({
  selector: 'app-choose-tour-approval',
  templateUrl: './choose-tour-approval.page.html',
  styleUrls: ['./choose-tour-approval.page.scss'],
})
export class ChooseTourApprovalPage implements OnInit {
  queryParams: any;

  constructor(private alertController: AlertController, private help: Help) {
  }

  ngOnInit() {
  }

  async disAgree(item) {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: '确定驳回',
      inputs: [
        {
          name: 'remark',
          type: 'textarea',
          attributes: {
            rows: 6
          },
          placeholder: '填写驳回备注',
        }],
      buttons: [
        {
          text: '取消',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
          },
        },
        {
          text: '确定',
          handler: (val) => {
            this.help.post('/tutorchoice/refuse', {
              agreeFlag: 2, status: 1, id: item.id,
              remark: val.remark
            }).subscribe(r => {
              if (r.success) {
                this.help.toastSuccess('驳回成功！');
                this.queryParams = {...this.queryParams};
              }
            });
          },
        },
      ],
    });
    await alert.present();
  }

  agree(item) {
    this.help.confirm({title: '温馨提示', msg: '确定同意成为该学生的导师？'}).then(r => {
      if (r) {
        this.help.post('/tutorchoice/agreeApply', {
          status: 2,
          agreeFlag: 1,
          id: item.id,
          studentId: item.studentId,
          teacherId: item.teacherId
        }).subscribe(rr => {
          if (rr.success) {
            this.help.toastSuccess('提交成功！');
            this.queryParams = {...this.queryParams};
          }
        });
      }
    });
  }
}
