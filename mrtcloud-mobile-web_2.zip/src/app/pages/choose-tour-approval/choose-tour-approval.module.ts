import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChooseTourApprovalPageRoutingModule } from './choose-tour-approval-routing.module';

import { ChooseTourApprovalPage } from './choose-tour-approval.page';
import {BaseListModule} from "../../components/base-list/base-list.module";
import {FormatTimeModule} from "../../pipe/format-time/format-time.module";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChooseTourApprovalPageRoutingModule,
    BaseListModule,
    FormatTimeModule
  ],
  declarations: [ChooseTourApprovalPage]
})
export class ChooseTourApprovalPageModule {}
