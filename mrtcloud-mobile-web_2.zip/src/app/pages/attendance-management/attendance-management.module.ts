import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {IonicModule} from '@ionic/angular';
import {AttendanceManagementPage} from './attendance-management.page';
import {CalendarComponentModule} from './calendar-component/calendar-component.module';
import {FormatTimeModule} from '../../pipe/format-time/format-time.module';
import {FormsModule} from '@angular/forms';
import {AttendanceManagementPageRoutingModule} from './attendance-management-routing.module';
import {FileSelectModule} from '../../components/file-select/file-select.module';
import {LoadingTextModule} from '../../components/loading-text/loading-text.module';
import {FormDateModule} from '../../components/form-date/form-date.module';
import {EditPageModule} from '../talk-note/edit/edit.module';
import {ShowEmptyModule} from "../../components/show-empty/show-empty.module";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        CalendarComponentModule,
        FormatTimeModule,
        FileSelectModule,
        AttendanceManagementPageRoutingModule,
        LoadingTextModule,
        FormDateModule,
        EditPageModule,
        ShowEmptyModule,
    ],
  declarations: [AttendanceManagementPage],
})
export class AttendanceManagementPageModule {
}
