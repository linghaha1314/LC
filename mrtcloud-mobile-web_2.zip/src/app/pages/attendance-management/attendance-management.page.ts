import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Help} from '../../utils/Help';
import {IonSelect} from '@ionic/angular';

declare let AMap;

@Component({
  selector: 'app-attendance-management',
  templateUrl: './attendance-management.page.html',
  styleUrls: ['./attendance-management.page.scss'],
})
export class AttendanceManagementPage implements OnInit, OnDestroy {
  @ViewChild('select')
  select: IonSelect;

  @ViewChild('selectShift')
  selectShift: IonSelect;

  isAttendance = true;
  maxDate: any = this.help.formatTime();
  currentShift: any = {};
  currentIpMsg: any = {};
  recordList: any[] = [];
  time: any;
  shiftList: any[] = [];
  studentInfo: any = localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')).student : {};
  today: string;
  outSideFlag = true;  //外勤
  inOutFlag = 0;  //上班
  signText = '签到';
  timeInterVal: any;
  isLoadingCircle = false;
  isLoadingRecord = false;
  amap: any;
  timer: any;

  constructor(private help: Help) {
  }

  ngOnInit() {
    //日历显示
    this.today = this.help.formatTime();
    // +
    if (this.studentInfo) {
      this.getAttendanceRecord(); //获取打卡记录
    }
    //时间显示
    this.showClock();
    this.timeInterVal = setInterval(() => {
      this.showClock();
    }, 1000);
    //所有班次
    this.help.post('/scheduleshift/getListAuthQueryByPage', {
      pageNum: 1,
      pageSize: 1000
    }).toPromise().then(res => {
      this.shiftList = res.list;
      this.currentShift = res.list[0];  //初始化班次
    });
    //加载定位
    this.help.loadScript('https://webapi.amap.com/maps?v=1.4.15&key=f6fed05849d9a306f4a109e5667a38b0').subscribe(b => {
      if (b) {
        this.getPosition().then();
        this.timer = setInterval(() => {
          this.getPosition().then();
        }, 8000);
      }
    });
  }

  ngOnDestroy() {
    clearInterval(this.timeInterVal);
    this.amap = null;
  }

  getWeek(date) {
    return '(星期' + '日一二三四五六'.charAt(new Date(date).getDay()) + ')';
  }

  showClock(): void {
    this.time = this.help.formatTime('', 'hh:mm');
  }

  async getShift(shiftId) {
    //主要获取班次的ip地址
    const b = await this.help.post('/attendconfig/selectByShiftId', {shiftId}).toPromise();
    this.currentShift.latitude = b.data.latitude;
    this.currentShift.longitude = b.data.longitude;
    this.currentShift.validRange = (!b.data.validRange || b.data.validRange === '0') ? 300 : Number(b.data.validRange);
    this.currentShift.name = b.data.sectionName + b.data.shiftName;
    this.currentShift.workPlace = b.data.workPlace;
    this.currentIpMsg.formattedAddress = '';  //重置
    await this.getPosition();
    this.getAttendanceRecord();
  }

  calculateDis() {
    if (!this.currentIpMsg) {
      this.refresh();
      return;
    }
    const currentPosition = [this.currentIpMsg.position.lng, this.currentIpMsg.position.lat];
    const position = [this.currentShift.longitude, this.currentShift.latitude];
    const dis = AMap.GeometryUtil.distance(currentPosition, position);
    if (dis < this.currentShift.validRange) {
      this.outSideFlag = false;
      //停止定位！换成当前的地址
      this.currentIpMsg.formattedAddress = this.currentShift.workPlace;  //在范围内就定点到当前的班次地点
      this.currentIpMsg.isWorkPlace = true;
    } else {
      this.currentIpMsg.isWorkPlace = false;
      this.outSideFlag = true;
    }
  }

  async getPosition() {
    let geolocation = null;
    this.amap = AMap;
    if (this.amap) {
      this.amap.plugin('AMap.Geolocation', () => {
        geolocation = new this.amap.Geolocation({
          enableHighAccuracy: true,
          timeout: 2000,
          useNative: true,  //sdk定位
          zoomToAccuracy: true,
        });
        geolocation.getCurrentPosition((result) => {
        }, err => {
          console.log(err);
        });
        this.amap.event.addListener(geolocation, 'complete', async (data) => {
          this.currentIpMsg = data;
          console.log(data);
          if (!this.currentShift.workPlace) {   //不存在workPlace,说明没有获取当前班次信息，首先获取班次信息，初始化的时候就首先执行一次匹配是否符合打卡范围内
            await this.getShift(this.currentShift.id);
          }
          this.calculateDis();
          this.help.hideLoading().then();
        });
        this.amap.event.addListener(geolocation, 'error', (data) => {
          console.log('失败', data);
          this.help.hideLoading().then();
        });
      });
    }
  }

  changePage(num) {
    this.isAttendance = num > 0;
    if (this.help.compatibleIosDate(this.today + ' 00:00:00').getTime() > this.help.compatibleIosDate(this.help.formatTime() + ' 00:00:00').getTime()) {
      this.today = this.help.formatTime();
    }
  }

  /*打卡*/
  clocked() {
    if (this.help.compatibleIosDate(this.help.formatTime(this.today)).getTime() > new Date().getTime()) {
      this.help.toastError('还没到时间，不能超前打卡！');
      return;
    }
    //如果当前时间小于当前打卡时间，表示不能打卡
    if (!this.currentShift.id) {
      this.help.toastError('请先选择班次');
      this.openSelect();
      return;
    }
    this.help.showLoading('打卡中...').then();
    this.isLoadingCircle = true;
    try {
      this.help.post('/attendancerecord/create', {
        address: this.currentIpMsg.formattedAddress,
        attendanceDate: this.help.formatTime(this.today, 'YY-MM-DD') + ' 00:00:00',
        checkDate: this.today,
        longitude: this.currentIpMsg.position.lng,
        latitude: this.currentIpMsg.position.lat,
        id: '',
        inoutFlag: this.inOutFlag,
        shiftId: this.currentShift.id,
        outSideFlag: this.outSideFlag  //外勤
      }).subscribe(b => {
        if (b.success) {
          this.help.toastSuccess(b.data.message);
          this.getAttendanceRecord();
        }
        this.isLoadingCircle = false;
      });
    } catch (e) {
      this.help.toastError('未获取到定位！请稍后...');
      this.help.hideLoading().then();
      this.isLoadingCircle = false;
    }
  }

  getAttendanceRecord() {
    this.isLoadingRecord = false;
    this.help.post('/attendancerecord/getAttendanceRecord', {
      studentId: this.studentInfo.id,
      checkDate: this.today
    }).subscribe(b => {
      this.recordList = b.data;
      this.isLoadingRecord = true;
      const len = b.data.length;
      this.inOutFlag = len === 0 ? 0 : 1;
      this.signText = len === 0 ? '签到' : (len === 1 ? '签退' : '重新签退');
      this.help.hideLoading().then();
    });
  }

  async refresh() {
    this.currentIpMsg.formattedAddress = '';  //重置
    await this.getPosition();
  }

  openSelect() {
    if (this.shiftList.length === 0) {
      this.help.toastTip('暂时没有班次,请联系工作人员');
      return;
    }
    this.selectShift.open().then();
  }

  changeSelect(e: any) {
    this.shiftList.forEach(res => {
      if (res.id === e.detail.value) {
        this.currentShift = res;
        this.getShift(res.id);  //获取当前定位的科室经纬度
      }
    });
  }

  changeDate() {
    this.getAttendanceRecord();
  }

  changeCurrentYMD(date) {
    if (!this.currentShift.id) {
      this.help.toastError('请先选择班次');
      this.openSelect();
      return;
    }
    this.getAttendanceRecord();
  }
}
