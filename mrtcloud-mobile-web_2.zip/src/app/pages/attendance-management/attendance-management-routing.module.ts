import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AttendanceManagementPage} from './attendance-management.page';

const routes: Routes = [
  {
    path: '',
    component: AttendanceManagementPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class AttendanceManagementPageRoutingModule {
}
