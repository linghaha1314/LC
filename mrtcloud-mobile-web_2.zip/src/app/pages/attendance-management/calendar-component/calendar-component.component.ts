import {Component, Input, OnInit, Output} from '@angular/core';
import {Help} from '../../../utils/Help';
import {EventEmitter} from '@angular/core';

@Component({
    selector: 'calendar-component',
    templateUrl: './calendar-component.component.html',
    styleUrls: ['./calendar-component.component.scss'],
})
export class CalendarComponentComponent implements OnInit {
    @Input()
    set currentYMD(data: string) {
        this._currentYMD = data;
        this.currentDate = {
            year: new Date(data).getFullYear(),
            month: new Date(data).getMonth() + 1,
            day: new Date(data).getDate()
        };
        this.getCurrentMonthDays(data);
    }

    get currentYMD(): string {
        return this._currentYMD;
    }

    @Output()
    currentYMDChange = new EventEmitter();

    // @Output()
    // changeDay = new EventEmitter();

    weekList = ['日', '一', '二', '三', '四', '五', '六'];
    monthDays: any[] = [];
    currentDate: any = {};
    isClicked: false;
    _currentYMD: any;

    constructor(private help: Help) {
    }

    ngOnInit() {
        this.currentDate = {
            year: new Date(this.currentYMD).getFullYear(),
            month: new Date(this.currentYMD).getMonth() + 1,
            day: new Date(this.currentYMD).getDate()
        };
        this.getCurrentMonthDays(this.currentYMD);
    }

    getCurrentMonthDays(currentDate: string, month?: number, year?: number) {
        const date = new Date(currentDate);
        const YY = year ? year : date.getFullYear();
        const MM = month ? month : date.getMonth() + 1;
        const d = new Date(YY, MM, 0);
        const dayCounts = d.getDate();

        const arr = [];
        for (let i = 0; i <= dayCounts - 1; i++) {
            const obj: any = {};
            obj.day = i + 1;
            obj.date = YY + '-' + this.help.addZero(MM) + '-' + this.help.addZero(obj.day);
            obj.week = this.getWeek(obj.date);
            obj.weekNumber = this.getWeek(obj.date, 'number');
            arr.push(obj);
        }
        this.monthDays = JSON.parse(JSON.stringify(arr));
        for (let i = this.monthDays[0].weekNumber; i > 0; i--) {
            arr.unshift(i);
        }
        this.monthDays = arr;
    }


    getWeek(date?: string | Date, type?: number | string) {
        if (type == 'number') {
            return date ? (typeof date === 'string' ? new Date(date).getDay() : date.getDay()) : new Date().getDay();
        }
        return date ? ('日一二三四五六'.charAt(typeof date === 'string' ? new Date(date).getDay() : date.getDay())) : '日一二三四五六'.charAt(new Date().getDay());
    }

    subAddMonth(num: number, limit: number) {
        if (this.currentDate.month == limit) {
            this.currentDate.year += num;
            this.currentDate.month = num < 0 ? 12 : 1;
        } else {
            this.currentDate.month += num;
        }
        const date = this.currentDate.year + '-' + this.help.addZero(this.currentDate.month) + '-' + this.help.addZero(this.currentDate.day);
        this.currentYMDChange.emit(date);
        this.getCurrentMonthDays(date, this.currentDate.month, this.currentDate.year);
    }

    clickActive(item: any) {
        if (item.day) {
            this.currentDate.day = item.day;
            this.currentYMDChange.emit(item.date);
        }
    }
}
