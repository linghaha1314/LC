import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CalendarComponentComponent} from './calendar-component.component';
import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [CalendarComponentComponent],
  imports: [
    CommonModule,
    IonicModule
  ], exports: [CalendarComponentComponent]
})
export class CalendarComponentModule {
}
