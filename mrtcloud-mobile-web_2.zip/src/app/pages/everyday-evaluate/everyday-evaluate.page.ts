import {Component, OnInit, ViewChild} from '@angular/core';
import {Help} from '../../utils/Help';
import {EventService} from '../../event.service';
import {BaseListComponent} from '../../components/base-list/base-list.component';
import {StorageService} from '../../storage.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-everyday-evaluate',
  templateUrl: './everyday-evaluate.page.html',
  styleUrls: ['./everyday-evaluate.page.scss'],
})
export class EverydayEvaluatePage implements OnInit {

  @ViewChild('listComponent')
  baseList: BaseListComponent;

  title = '每日评价';

  user: any = {};

  type = '';

  constructor(private help: Help, private eventService: EventService, private storage: StorageService, private router: Router) {
  }

  ngOnInit() {
    this.eventService.on('update', () => {
      this.baseList.doRefresh().then();
    });
    let teacherFlag = false;
    this.help.get('/account/getMyUserInfo').subscribe(d => {
      if (d.success) {
        this.user = d.data;
        this.user.roles.forEach(r => {
          if (r.code == 'teacher') {
            teacherFlag = true;
          }
        });
        let url: string;
        if (teacherFlag) {
          //是老师
          this.title = '每日评价学生';
          url = '/studentteacher/listMyStudent';
          this.type = 'teacher';
        } else {
          //是学生
          this.title = '每日评价老师';
          url = '/studentteacher/listMyTeacher';
          this.type = 'student';
        }
        this.baseList.loadUrl(url);
      }
    });
  }

  intoEval(item: any) {
    if (item.evaluateDetail != null) {
      return;
    }
    if (this.type == 'teacher') {
      this.storage.set('pageParams', {
        fromStaffId: item.teacherStaffId,
        toStaffId: item.stuStaffId,
        startDate: item.startDate,
        endDate: item.endDate
      });
    } else {
      this.storage.set('pageParams', {
        fromStaffId: item.stuStaffId,
        toStaffId: item.teacherStaffId,
        startDate: item.startDate,
        endDate: item.endDate
      });
    }
    this.router.navigate(['/CommonEval', this.type == 'teacher' ? 'EvalType_teacherEveryToStudent' : 'EvalType_studentEveryToTeacher']);
  }
}
