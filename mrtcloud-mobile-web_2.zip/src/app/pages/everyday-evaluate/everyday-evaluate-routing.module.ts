import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EverydayEvaluatePage } from './everyday-evaluate.page';

const routes: Routes = [
  {
    path: '',
    component: EverydayEvaluatePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EverydayEvaluatePageRoutingModule {}
