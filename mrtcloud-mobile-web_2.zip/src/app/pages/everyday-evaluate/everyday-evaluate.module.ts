import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EverydayEvaluatePageRoutingModule } from './everyday-evaluate-routing.module';

import { EverydayEvaluatePage } from './everyday-evaluate.page';
import {BaseListModule} from '../../components/base-list/base-list.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EverydayEvaluatePageRoutingModule,
    BaseListModule
  ],
  declarations: [EverydayEvaluatePage]
})
export class EverydayEvaluatePageModule {}
