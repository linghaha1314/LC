import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AliPlayerComponent} from './ali-player.component';


@NgModule({
  declarations: [AliPlayerComponent],
  imports: [
    CommonModule
  ], exports: [AliPlayerComponent]
})
export class AliPlayerModule {
}
