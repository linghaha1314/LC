import {Component, Input, OnInit} from '@angular/core';
import {Help} from '../../../utils/Help';
import {StorageService} from '../../../storage.service';

declare const Aliplayer;

@Component({
  selector: 'ali-player',
  templateUrl: './ali-player.component.html',
  styleUrls: ['./ali-player.component.scss'],
})
export class AliPlayerComponent implements OnInit {
  @Input()
  source: string;

  @Input()
  cover: string;

  player: any;

  url: any;

  constructor(private help: Help, public storageService: StorageService) {
  }

  destroy() {
    this.player.dispose();
  }

  ngOnInit() {
    this.url = this.source.indexOf('http') > -1
      ? this.source
      : this.storageService.baseUrl + this.source;
    this.help
      .loadAssets([
        'https://g.alicdn.com/de/prismplayer/2.9.11/skins/default/aliplayer-min.css',
        'https://g.alicdn.com/de/prismplayer/2.9.11/aliplayer-min.js',
      ])
      .subscribe((b) => {
        if (b) {
          this.player = new Aliplayer(
            {
              id: 'J_prismPlayer',
              height: '256px', //容器的大小
              autoplay: false,
              playsinline: true, //内置播放
              x5_type: false,
              useH5Prism: true,
              showBuffer: false, //播放缓冲图标
              diagnosisButtonVisible: false,
              videoHeight: '256px', //视频的高度大小
              //支持播放地址播放,此播放优先级最高
              // source: 'http://upyun.xuanheyinhua.com/李娜/李娜老师快剪.mp4',
              // source: 'http://bangvideo.yasn.com/29f812c66e4c4320bb4bbb9f250337cc.m3u8',
              source: this.funcChina(this.url) ? encodeURI(this.url) : this.url,
              cover: this.cover || './assets/images/course-default.jpg',
              skinLayout: [
                {name: 'bigPlayButton', align: 'cc', x: 30, y: 80},
                {
                  name: 'H5Loading',
                  align: 'cc',
                },
                {name: 'errorDisplay', align: 'tlabs', x: 0, y: 0},
                {name: 'infoDisplay'},
                {name: 'tooltip', align: 'blabs', x: 0, y: 56},
                {name: 'thumbnail'},
                {
                  name: 'controlBar',
                  align: 'blabs',
                  x: 0,
                  y: 0,
                  children: [
                    {name: 'progress', align: 'blabs', x: 0, y: 44},
                    {name: 'playButton', align: 'tl', x: 15, y: 12},
                    {name: 'timeDisplay', align: 'tl', x: 10, y: 7},
                    {name: 'fullScreenButton', align: 'tr', x: 10, y: 12},
                    {name: 'volume', align: 'tr', x: 5, y: 10},
                  ],
                },
              ],
            },
            (r) => {
              console.log('播放器创建好了。', r);
            }
          );
          this.err();
        }
      });
  }

  funcChina(v) {
    if (/.*[\u4e00-\u9fa5]+.*$/.test(v)) {
      return true;
    }
    return false;
  }

  stop() {
    this.player.stop();
  }

  err() {
    this.player.on('error', (e) => {
      document.querySelector('.prism-error-content p').innerHTML =
        '资源加载出错，请联系管理员';
      document
        .querySelector('.prism-error-operation .prism-button-refresh')
        .setAttribute('style', 'display:none');
    });
  }
}
