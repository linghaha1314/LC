import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {Help} from '../../utils/Help';
import {StorageService} from '../../storage.service';
import {AliPlayerComponent} from './ali-player/ali-player.component';
import {Router} from '@angular/router';


@Component({
  selector: 'app-course',
  templateUrl: './course.page.html',
  styleUrls: ['./course.page.scss'],
})
export class CoursePage implements OnInit, OnDestroy {
  @ViewChild('aliPlay')
  aliPlay: AliPlayerComponent;
  pageParams: any = {};
  list: any[] = [];
  segmentStatus = 0;
  commentList = null;
  // source = 'http://upyun.xuanheyinhua.com/李娜/李娜老师快剪.mp4' || 'http://bangvideo.yasn.com/29f812c66e4c4320bb4bbb9f250337cc.m3u8';
  source = '';
  content: string;
  rows = 1;
  timeCes: any;
  isCollected = false;
  collectionId: any;
  currentVideo: any = {
    cover: ''
  };
  isShowPlayer = true;
  path = window.location.protocol + '//' + window.location.host;

  constructor(private router: Router, private help: Help, private storage: StorageService) {
  }

  ngOnInit() {
    this.pageParams = this.storage.get('pageParams');
    this.isCollectedByCourseId();
    this.getCourses(0); //默认选中第一个
    this.getComments();

  }

  ngOnDestroy() {
    this.aliPlay.destroy();
  }

  getCourses(index) {
    this.help.showLoading().then();
    this.help.post('/coursechapter/getListQueryByPage', {
      pageNum: 1,
      courseId: this.pageParams.id,
      pageSize: 20
    }).subscribe(async b => {
      this.list = b.list;
      if (this.list[index] && this.list[index].coursewareId) {
        this.currentVideo = this.list[index];
        if (this.list[index].thumbImage) {
          this.currentVideo.cover = this.path + this.list[index].thumbImage;
          //判断图片加载失败就加载默认的图片
        }
        this.currentVideo.source = await this.getCourseById(this.list[index].coursewareId);
      }
    });
  }

  getComments() {
    this.help.showLoading().then();
    this.help.post('/coursecomment/getCommentListByPage', {
      courseId: this.pageParams.id,
      pageNum: 1,
      pageSize: 20
    }).subscribe(b => {
      this.commentList = b.list;
    });
  }

  segmentChanged(status) {
    this.segmentStatus = status;
    if (status === 1 && !this.commentList) {
      this.getComments();
    }
  }

  async getCourseById(coursewareId) {
    const result = await this.help.get(`/courseware/getById/${coursewareId}`).toPromise();
    return result.data.path;
    //   .then(b => {
    //   this.currentVideo.source = b.data.path;
    // });
  }

  isCollectedByCourseId() {
    //是否已经收藏该课程
    this.help.get(`/coursecollection/getByCourseId/${this.pageParams.id}`).toPromise().then(b => {
      if (b.data && b.data.id) {
        this.collectionId = b.data.id;
        this.isCollected = true;
      }
    });
  }

  collection() {
    const params = {
      courseId: this.pageParams.id,
      id: this.collectionId
    };
    if (!this.isCollected) {
      delete params.id;
    }
    this.help.post('/coursecollection/collection', {
      courseId: this.pageParams.id
    }).subscribe(b => {
      this.isCollected = true;
    });
  }

  push() {
    this.help.showLoading('评论中...').then();
    this.help.post('/coursecomment/create', {
      courseId: this.pageParams.id,
      content: this.content
    }).subscribe(b => {
      if (b.success) {
        this.help.toastSuccess('评论成功！');
        this.content = '';
        this.segmentStatus = 1;
        this.getComments();
        this.rows = 1;
      }
    });
  }

  async changeCourse(item: any, index) {
    this.isShowPlayer = false;
    this.currentVideo = this.list[index];
    this.currentVideo.source = await this.getCourseById(item.coursewareId);
    this.isShowPlayer = true;
    if (item.source.indexOf('.mp4') < 0) {
      this.router.navigate(['/file-viewer', this.currentVideo.source]).then();
    }
    this.aliPlay?.stop();
  }
}
