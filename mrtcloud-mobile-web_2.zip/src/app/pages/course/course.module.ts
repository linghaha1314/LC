import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {IonicModule} from '@ionic/angular';

import {CoursePageRoutingModule} from './course-routing.module';

import {CoursePage} from './course.page';
import {FormatTimeModule} from '../../pipe/format-time/format-time.module';
import {AliPlayerModule} from './ali-player/ali-player.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CoursePageRoutingModule,
    FormatTimeModule,
    AliPlayerModule
  ],
  declarations: [CoursePage]
})
export class CoursePageModule {
}
