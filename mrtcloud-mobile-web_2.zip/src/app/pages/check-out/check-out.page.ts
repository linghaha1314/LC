import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {StorageService} from '../../storage.service';
import {EventService} from '../../event.service';

@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.page.html',
  styleUrls: ['./check-out.page.scss'],
})
export class CheckOutPage implements OnInit {
  queryParams: any = {};
  item: any = {};

  constructor(private router: Router, private storage: StorageService, private eventService: EventService) {
  }

  ngOnInit() {
    this.eventService.event.on('update', () => {
      this.queryParams = {...this.queryParams};
    });
  }

  applicative() {
    this.router.navigate(['/CheckOut/add']).then();
  }

  goView(item) {
    this.storage.set('pageParams', item);
    this.router.navigate(['/CheckOut/view']).then();
  }
}
