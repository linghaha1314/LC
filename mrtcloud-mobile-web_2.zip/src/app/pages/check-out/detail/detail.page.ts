import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Help} from '../../../utils/Help';
import {EventService} from '../../../event.service';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {
  form: FormGroup;
  sectionList: any[] = [];

  constructor(private fb: FormBuilder, private help: Help, private eventService: EventService, private navCtrl: NavController) {
  }

  ngOnInit() {
    this.form = this.fb.group({
      sectionId: [null, [Validators.required]],
      sectionName: [null, [Validators.required]],
      checkinId: [null],
      studentId: [null],
      date: [null, [Validators.required]],
      remark: [null],
    });
    this.help.post('/transfercheckin/listMyCheckIn').subscribe(b => {
      if (b.success) {
        this.sectionList = b.rows || b.list;
      }
    });
  }

  submit() {
    if (!this.help.formValid(this.form)) {
      return;
    }
    delete this.form.value.sectionName;
    this.help.post('/transfercheckout/create', {
      ...this.form.value,
      status: 11,
      studentCheckoutFlag: true
    }).subscribe(b => {
      if (b.data.success) {
        this.help.toastSuccess('提交成功');
        this.navCtrl.pop().then();
        this.eventService.event.emit('update');
      }
    });
  }


  changeSelect(e: any) {
    this.form.patchValue(e);
    this.form.patchValue({checkinId: e.id, studentId: e.studentId});
  }
}
