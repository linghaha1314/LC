import {Component, OnInit} from '@angular/core';
import {StorageService} from '../../../storage.service';
import {Help} from '../../../utils/Help';

@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
  queryParam: any;
  pageParams: any;
  private navCtrl: any;
  private eventService: any;

  constructor(private storage: StorageService, private help: Help) {
  }

  ngOnInit() {
    this.pageParams = this.storage.get('pageParams');
  }

  getCurrentApproval($event: any) {

  }

  agree(num: number) {
    this.help.post('/transfercheckout/approval', {
      opinion: '可以',
      processInstanceId: '762501',
      projectId: '0fab2dae-0979-11ec-b0ce-00ffc48e9a17',
      status: 1,
      taskId: '762509,762509,762509'
    }).subscribe(b => {
      if (b.success) {
        this.help.toastSuccess('提交成功');
        this.navCtrl.pop().then();
        this.eventService.event.emit('update');
      }
    });
  }
}
