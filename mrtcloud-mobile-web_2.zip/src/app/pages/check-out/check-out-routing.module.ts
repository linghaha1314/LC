import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {CheckOutPage} from './check-out.page';

const routes: Routes = [
  {
    path: '',
    component: CheckOutPage
  },
  {
    path: 'detail',
    loadChildren: () => import('./detail/detail.module').then(m => m.DetailPageModule)
  },
  {
    path: 'add',
    loadChildren: () => import('./detail/detail.module').then(m => m.DetailPageModule)
  },
  {
    path: 'view',
    loadChildren: () => import('./view/view.module').then( m => m.ViewPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckOutPageRoutingModule {
}
