import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {ExamListOperatePage} from './exam-list-operate.page';

const routes: Routes = [
  {
    path: '',
    component: ExamListOperatePage
  },
  {
    path: 'staffList/:id',
    loadChildren: () => import('./staff-list/staff-list.module').then(m => m.StaffListPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ExamListOperatePageRoutingModule {
}
