import {Component, OnInit} from '@angular/core';
import {StorageService} from '../../../storage.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.page.html',
  styleUrls: ['./detail.page.scss'],
})
export class DetailPage implements OnInit {
  pageParams: any = {};

  constructor(public storage: StorageService) {
  }

  ngOnInit() {
    this.pageParams = this.storage.get('pageParams');
  }

}
