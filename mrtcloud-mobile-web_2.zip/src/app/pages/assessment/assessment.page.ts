import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-assessment',
  templateUrl: './assessment.page.html',
  styleUrls: ['./assessment.page.scss'],
})
export class AssessmentPage implements OnInit {
  list: any[] = [
    {id: 1, name: '国家理论', url: '/annualexamscore/listNowMajor'},
    {id: 2, name: '院级考核', url: '/annualexamscore/listHospitalScore'},
    {id: 3, name: '出科考核', url: '/checkoutsection/listQueryAll'},
    {id: 4, name: '模拟结业', url: '/annualexamscore/getSimulatedListAuthQueryByPage'},
    {id: 5, name: '结业考核', url: '/checkouthospital/getListAuthQueryByPage'}];

  constructor(private router: Router) {
  }

  ngOnInit() {
  }

  goView(item: any) {
    this.router.navigate([`/Assessment/view`], {queryParams: {name: item.name, url: item.url}}).then();
  }
}
