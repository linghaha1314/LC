import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewPageRoutingModule } from './view-routing.module';

import { ViewPage } from './view.page';
import {FilterDropdownModule} from '../../../components/filter-dropdown/filter-dropdown.module';
import {BaseListModule} from '../../../components/base-list/base-list.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ViewPageRoutingModule,
    FilterDropdownModule,
    BaseListModule
  ],
  declarations: [ViewPage]
})
export class ViewPageModule {}
