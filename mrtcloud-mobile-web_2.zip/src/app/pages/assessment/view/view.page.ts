import {Component, OnInit} from '@angular/core';
import {FilterDropdownData} from '../../../components/filter-dropdown/filter-dropdown.component';
import {ActivatedRoute, Router} from '@angular/router';
import {StorageService} from '../../../storage.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
  filters: FilterDropdownData = [
    {
      code: 'qualifiedFlagStatus',
      label: '状态',
      type: 'static',
      selectText: '全部',
      value: '3',
      isShowAllType: 0,
      data: [{id: '3', name: '全部'}, {id: '0', name: '合格'}, {id: '1', name: '不合格'}, {id: '2', name: '缺考'}]
    },
    {code: 'years', label: '日期', type: 'date', dateType: 'year'}
  ];
  queryParams: any = {};
  pageParams: any = {};

  constructor(private route: ActivatedRoute, private router: Router, private storage: StorageService) {
  }

  ngOnInit() {
    this.pageParams = this.route.snapshot.queryParams;
  }


  changeParams(data: any) {
    if (data.qualifiedFlagStatus === '3') {
      delete data.qualifiedFlagStatus;
      delete this.queryParams.qualifiedFlagStatus;
    }
    this.queryParams = {...this.queryParams, ...data};
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  goDetail(item: any) {
    this.storage.set('pageParams', {...item, typeName: this.pageParams.name});
    this.router.navigate(['/Assessment/detail']).then();
  }
}
