import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CheckInDeterminePage } from './check-in-determine.page';

const routes: Routes = [
  {
    path: '',
    component: CheckInDeterminePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckInDeterminePageRoutingModule {}
