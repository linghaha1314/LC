import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CheckInDeterminePageRoutingModule } from './check-in-determine-routing.module';

import { CheckInDeterminePage } from './check-in-determine.page';
import {BaseListModule} from '../../components/base-list/base-list.module';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        CheckInDeterminePageRoutingModule,
        BaseListModule,
        FilterDropdownModule
    ],
  declarations: [CheckInDeterminePage]
})
export class CheckInDeterminePageModule {}
