import {Component, OnInit, QueryList, TemplateRef, ViewChildren} from '@angular/core';
import {Help} from '../../utils/Help';
import {IonDatetime} from '@ionic/angular';
import {FilterDropdownData} from '../../components/filter-dropdown/filter-dropdown.component';

@Component({
  selector: 'app-check-in-determine',
  templateUrl: './check-in-determine.page.html',
  styleUrls: ['./check-in-determine.page.scss'],
})
export class CheckInDeterminePage implements OnInit {
  @ViewChildren('datetime')
  dates: QueryList<IonDatetime>;
  queryParams: any = {};
  checkTime: string;
  filters: FilterDropdownData = [
    {code: 'sectionId', label: '科室', type: 'page', url: '/section/listAuthQueryByPage', listKey: 'rows'},
    {code: 'majorId', label: '专业', type: 'page', url: '/major/listAuthQueryByPage', listKey: 'rows'},
    {
      code: 'inMonth',
      label: '日期',
      type: 'date',
      dateType: 'month',
      value: this.help.formatTime('', 'YY-MM'),
      selectText: this.help.formatTime('', 'YY-MM')
    }
  ];
  currentItem: any = {};
  isShowDate = false;
  currentIdentity: any;

  constructor(private help: Help,) {
  }

  ngOnInit() {
    this.currentIdentity = JSON.parse(localStorage.getItem('currentIdentity'));
  }


  async determined(item) {
    this.openDate('date');
    this.currentItem = item;
  }

  openDate(name) {
    this.dates.filter(d => d.name === name)[0].open().then();
    setTimeout(() => {
      const dom = document.querySelectorAll('.picker-toolbar-button')[1];
      if (dom) {
        dom.addEventListener('click', (b) => {
          if (this.checkTime) {
            this.submit(this.currentItem);
          }
        });
      }
    }, 100);

  }

  async submit(item) {
    const startTime = new Date(item.startDate).getTime();
    const endTime = new Date(item.endDate).getTime();
    const checkTime = new Date(this.help.formatTime(this.checkTime)).getTime();
    if (startTime > checkTime || endTime < checkTime) {
      this.help.toastError('入科时间与当前轮转周期不匹配！');
      this.checkTime = null;
      return;
    }
    // let flag = false;
    // await this.help.post('/transfercheckin/studentIsCheckout', {
    //   studentId: item.studentId,  //判断是否从当前科室出来
    //   sectionId: item.sectionId
    // }).toPromise().then(b => {
    //   if (b.data === 0) {
    //     flag = true;
    //   }
    // });
    // if (!flag) {
    //   return;
    // }
    await this.help.showLoading('提交中...');
    await this.help.post('/transfercheckin/create', {
      transferScheduleId: item.id,
      transferId: item.id,
      studentId: item.studentId,
      sectionId: item.sectionId,
      checkTime: this.help.formatTime(this.checkTime) + ' ' + '00:00:00'
    }).subscribe(b => {
      if (b.status === -1) {
        this.help.toastError(b.message);
      } else {
        this.help.toastSuccess('入科成功！');
        this.queryParams = {...this.queryParams};
      }
    });
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  changeParams(data: any) {
    console.log(data);
    this.queryParams = data;
  }


}
