import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {IonicModule} from '@ionic/angular';

import {CheckOutApprovalRoutingModule} from './check-out-approval-routing.module';

import {CheckOutApprovalPage} from './check-out-approval.page';
import {BaseListModule} from '../../components/base-list/base-list.module';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';
import {FormatTimeModule} from '../../pipe/format-time/format-time.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CheckOutApprovalRoutingModule,
    BaseListModule,
    FilterDropdownModule,
    FormatTimeModule
  ],
  declarations: [CheckOutApprovalPage]
})
export class checkOutApprovalModule {
}
