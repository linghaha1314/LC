import {Component, OnInit} from '@angular/core';
import {StorageService} from '../../../storage.service';
import {Help} from '../../../utils/Help';
import {EventService} from '../../../event.service';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})
export class ViewPage implements OnInit {
  pageParams: any;


  constructor(private storage: StorageService, private help: Help, private eventService: EventService, private navCtrl: NavController) {
  }

  ngOnInit() {
    this.pageParams = this.storage.get('pageParams');
  }

  agree(num: number) {
    const msg: string = num === 1 ? '驳回？' : '同意？';
    this.help.confirm({
      title: '温馨提示', msg: '出科确认' + msg
    }).then(async r => {
      if (r) {
        await this.help.showLoading('提交中...');
        await this.help.post('/transfercheckout/update', {
          status: num,
          id: this.pageParams.id
        }).subscribe(b => {
          if (b.status === 0 || b.data.success) {
            this.help.toastSuccess('成功出科');
            this.navCtrl.pop().then();
            this.eventService.event.emit('update');
          } else {
            this.help.toastError(b.message);
          }
        });
      }
    });
  }

}
