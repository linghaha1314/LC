import {Component, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';
// import {FilterDropdownData} from '../../components/filter-dropdown/filter-dropdown.component';
import {StorageService} from '../../storage.service';
import {Router} from '@angular/router';
import {EventService} from '../../event.service';

@Component({
  selector: 'app-check-in-determine',
  templateUrl: './check-out-approval.page.html',
  styleUrls: ['./check-out-approval.page.scss'],
})
export class CheckOutApprovalPage implements OnInit {
  queryParams: any = {
    status: 11
  };
  // filters: FilterDropdownData = [
  //   // {code: 'sectionId', label: '科室', type: 'page', url: '/section/listAuthQueryByPage', listKey: 'rows'},
  //   {code: 'majorId', label: '专业', type: 'page', url: '/major/listAuthQueryByPage', listKey: 'rows'},
  //   {code: 'endMonth', label: '日期', type: 'date', dateType: 'month'}
  // ];
  currentItem: any = {};

  currentIdentity: any;



  constructor(private help: Help, private router: Router, private storage: StorageService,private eventService: EventService) {
  }

  changeList = (data) => ({
    list: data.rows || data.list,
    total: data.total
  });

  ngOnInit() {
    this.eventService.event.on('update', () => {
      this.queryParams = {...this.queryParams};
    });
    this.currentIdentity = JSON.parse(localStorage.getItem('currentIdentity'));
  }

  search() {
    this.queryParams = {...this.queryParams};
  }

  changeParams(data: any) {
    this.queryParams = {...this.queryParams, ...data};
  }

  goView(item: any) {
    this.router.navigate(['/CheckOutApproval/view']).then();
    this.storage.set('pageParams', item);
  }
}
