import {Component, OnInit} from '@angular/core';
import {FilterDropdownData} from '../../components/filter-dropdown/filter-dropdown.component';
import {EventService} from '../../event.service';
import {Router} from "@angular/router";

@Component({
    selector: 'app-eval-type-student-mini-cex',
    templateUrl: './eval-type-student.page.html',
    styleUrls: [],
})
export class EvalTypeStudentPage implements OnInit {
    currentPath: any = {
        name: this.router.url.indexOf('DOPS') > 0 ? 'Dops' : 'MiniCEX',
        formativeEvalCode: this.router.url.indexOf('DOPS') > 0 ? 'FormativeEval_DOPS' : 'FormativeEval_MiniCEX'
    };
    filters: FilterDropdownData = [
        {
            code: 'evaluateFlag',
            label: '状态',
            type: 'static',
            data: [{id: '0', name: '未评价'}, {id: '1', name: '已评价'}]
        },
        {code: 'startDate', label: '日期', type: 'date', dateType: 'month'}
    ];

    queryParams: any = {
        formativeEvalCode: this.currentPath.formativeEvalCode,
        startDate: '',
        pageNum: 1,
        pageSize: 20,
    };
    item: any = {evaluateTimes: 1};

    constructor(private eventService: EventService, private router: Router) {
    }

    ngOnInit() {
        this.eventService.event.on('update', () => {
            this.queryParams = {...this.queryParams};
        });
    }

    changeParams(data: any) {
        this.queryParams = {...this.queryParams, ...data};
    }

}
