import {Component, OnInit} from '@angular/core';
import {Help} from '../../../utils/Help';
import {Location} from '@angular/common';
import {EventService} from '../../../event.service';
import {NavController} from '@ionic/angular';

/* miniCEX和Dops学生模块*/
@Component({
  selector: 'app-view',
  templateUrl: './view.page.html',
  styleUrls: ['./view.page.scss'],
})

export class ViewPage implements OnInit {
  list: any[] = [];
  studentList: any[] = [];
  params: any = {};

  constructor(private help: Help, private location: Location, private eventService: EventService, private navCtrl: NavController) {
  }

  ngOnInit() {
    const getParams: any = this.location.getState();
    if (JSON.stringify(getParams.item)) {
      this.params.studentEvaluateFlag = getParams.item.studentEvaluateFlag;
      this.params.evalId = getParams.item.teacherEvalId;
      this.params.fromStaffId = getParams.item.staffId;
      this.params.transferId = getParams.item.transferId;
      this.params.formativeEvaluateId = getParams.item.id;
      this.params.staffId = getParams.item.studentStaffId;
      this.params.studentEvalId = getParams.item.studentEvalId;
      this.params.currentPath = getParams.currentPath;
      localStorage.setItem('pageParams', JSON.stringify(this.params));
    } else {
      this.params = localStorage.getItem('pageParams') ? JSON.parse(localStorage.getItem('pageParams')) : {};
    }
    this.getData();
  }

  getData() {
    this.help.post('/formativeevaluate/getAnswerDetail', {
      evalId: this.params.evalId,
      fromStaffId: this.params.fromStaffId
    }).subscribe(b => {
      this.list = b.list;
      this.params.volumeId = this.list[0].volumeId;
    });
    const url = this.params.currentPath == 'FormativeEval_MiniCEX' ? 'EvalType_StudentMiniCEX' : 'EvalType_StudentDOPS';
    //未评价请求
    if (!this.params.studentEvaluateFlag) {
      this.help.get('/formativeevaluate/viewModule/' + url).subscribe(b => {
        if (b.success) {
          this.studentList = b.data.data;
          //处理vescore默认数据
          this.studentList.map(res => {
            if (res.styleCode === 'vescore') {
              res.indexValue = res.options[0].optionValue;
              res.indexResult = res.options[0].optionValue;
            }
          });
        }
      });
    } else {
      //已评价请求
      this.help.post('/formativeevaluate/getAnswerDetail', {
        evalId: this.params.studentEvalId,
        fromStaffId: this.params.staffId
      }).subscribe(b => {
        if (b.success) {
          this.studentList = b.list;
        }
      });
    }
  }

  save() {
    const obj = {
      evalFlag: 2,
      transferId: this.params.transferId,
      volumeId: this.params.volumeId,
      formativeEvalCode: this.params.currentPath,
      formativeEvaluateId: this.params.formativeEvaluateId,
      toStaffId: this.params.staffId,
      volumeName: '评价老师',
      detailList: []
    };
    this.studentList.map(res => {
      const itemObj = {
        indexId: res.id,
        indexName: '学员对本次测评的满意程度',
        staffId: this.params.staffId,
        volumeId: this.params.volumeId,
        indexResult: res.indexValue,
        indexValue: res.indexValue,
      };
      obj.detailList.push(itemObj);
    });
    this.help.confirm({title: '温馨提示', msg: '确定提交？'}).then(r => {
      if (r) {
        this.help.showLoading().then();
        this.help.post('/formativeevaluate/saveQuestionResult', obj).subscribe(b => {
          if (b.success) {
            this.help.toastSuccess(b.msg);
            this.navCtrl.pop().then();
            this.eventService.event.emit('update');
          }
        });
      }
    });
  }

  subAnd(key, num, maxNum) {
    const value = this.studentList[key].indexResult;
    if ((value === 0 && num < 0) || (value == maxNum && num > 0)) {
      return;
    }
    this.studentList[key].indexResult = value + num;
    this.studentList[key].indexValue = value + num;
  }
}
