import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EvalTypeStudentMiniCEXPageRoutingModule } from './eval-type-student-routing.module';

import { EvalTypeStudentPage } from './eval-type-student.page';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';
import {BaseListModule} from '../../components/base-list/base-list.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    EvalTypeStudentMiniCEXPageRoutingModule,
    FilterDropdownModule,
    BaseListModule
  ],
  declarations: [EvalTypeStudentPage]
})
export class EvalTypeStudentMiniCEXPageModule {}
