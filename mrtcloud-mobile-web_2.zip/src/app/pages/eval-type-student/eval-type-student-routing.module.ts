import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {EvalTypeStudentPage} from './eval-type-student.page';

const routes: Routes = [
  {
    path: '',
    component: EvalTypeStudentPage
  },
  {
    path: 'view/:id',
    loadChildren: () => import('./view/view.module').then(m => m.ViewPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EvalTypeStudentMiniCEXPageRoutingModule {
}
