import {Component, OnDestroy, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';
import {ModalController} from '@ionic/angular';
import {DetailComponentComponent} from './detail-component/detail-component.component';

@Component({
  selector: 'app-checkout-section-exam',
  templateUrl: './checkout-section-exam.page.html',
  styleUrls: ['./checkout-section-exam.page.scss'],
})
export class CheckoutSectionExamPage implements OnInit, OnDestroy {
  list: any;
  queryParams: any = {
    checkFlag: false
  };


  constructor(private help: Help, private modalController: ModalController) {
  }

  ngOnInit() {
    this.help.get('/formativeevaluate/viewModule/EvalType_TeacherMiniCEX').subscribe(b => {
      this.list = b.data.data;
    });
  }

  ngOnDestroy() {

  }

  segmentChanged(e) {
    this.queryParams = {...this.queryParams};
  }

  async showModal(item: any) {
    const modal = await this.modalController.create({
      component: DetailComponentComponent,
      cssClass: 'my-custom-class',
      componentProps: {item},
      swipeToClose: true,
    });
    return await modal.present();
  }

}
