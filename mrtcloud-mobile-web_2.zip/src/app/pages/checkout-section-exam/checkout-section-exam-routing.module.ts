import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {CheckoutSectionExamPage} from './checkout-section-exam.page';
import {DetailComponentComponent} from './detail-component/detail-component.component';

const routes: Routes = [
  {
    path: '',
    component: CheckoutSectionExamPage
  },
  {
    path: 'detail/:id',
    component: DetailComponentComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckoutSectionExamPageRoutingModule {
}
