import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {CheckoutSectionExamPageRoutingModule} from './checkout-section-exam-routing.module';

import {CheckoutSectionExamPage} from './checkout-section-exam.page';
import {ExamListModule} from '../../components/exam-list/exam-list.module';
import {BaseListModule} from '../../components/base-list/base-list.module';
import {EditPageModule} from '../talk-note/edit/edit.module';
import {IonicModule} from '@ionic/angular';
import {DetailComponentComponent} from './detail-component/detail-component.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CheckoutSectionExamPageRoutingModule,
    ExamListModule,
    BaseListModule,
    EditPageModule,
    IonicModule
  ],
  declarations: [CheckoutSectionExamPage, DetailComponentComponent]
})
export class CheckoutSectionExamPageModule {
}
