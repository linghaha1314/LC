import {Component, OnInit} from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import {Router} from '@angular/router';

@Component({
  selector: 'app-detail-component',
  templateUrl: './detail-component.component.html',
  styleUrls: ['./detail-component.component.scss'],
})
export class DetailComponentComponent implements OnInit {

  list: any[] = [];
  item: any;

  constructor(public modalCtrl: ModalController, public navParams: NavParams, private router: Router) {
  }

  ngOnInit() {
    this.list = this.navParams.data.list;
    this.item = this.navParams.data.item;
  }

  close() {
    this.modalCtrl.dismiss().then();
  }

  goExam(status) {
    this.router.navigate(['/CommonEvalPagePage']);
    this.close();
    localStorage.setItem('pageParams', JSON.stringify({item: this.item, allowEmpty: true}));
  }
}
