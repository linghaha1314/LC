import {Component, OnInit} from '@angular/core';
import {FilterDropdownData} from '../../components/filter-dropdown/filter-dropdown.component';
import {Help} from '../../utils/Help';

declare const echarts: any;

@Component({
  selector: 'app-attendance-view',
  templateUrl: './attendance-view.page.html',
  styleUrls: ['./attendance-view.page.scss'],
})
export class AttendanceViewPage implements OnInit {
  filters: FilterDropdownData = [];
  status = '0';  //考勤数据，请假数据
  pieData: any = [];
  queryParams: any = {};
  data: any = [];

  constructor(private help: Help) {
  }

  ngOnInit() {
    this.help.loadScript('http://cdn.kbmrt.cn/echarts/echarts.min.js').subscribe(async r => {
      if (r) {
        this.initFilters();
        this.initData();
      }
    });
  }

  initFilters() {
    this.filters = this.status === '0' ? [
      {code: 'selectDate', label: '日期', type: 'date', dateType: 'day', selectText: this.help.formatTime()}
    ] : [
      {code: 'selectDate', label: '年度', type: 'date', dateType: 'year'},
      {code: 'sectionId', label: '科室', type: 'page', url: '/section/listAuthQueryByPage', listKey: 'rows'}
    ];
    this.queryParams = this.status === '0' ? {
      selectDate: this.help.formatTime()
    } : {selectDate: this.help.formatTime('', 'YY')};
  }

  initData() {
    if (this.status === '0') {
      this.initAttendance().then();
      return;
    }
  }

  async initAttendance() {
    this.data = (await this.help.post('/attendancerecord/listAttendanceRecordStudent', this.queryParams).toPromise())?.data;
    if (this.data.length === 0) {
      return;
    }
    this.data.forEach(d => {
      d.value = (d.clocked * 100 / d.total).toFixed(0);
    });
    setTimeout(() => {
      this.showChart(document.getElementById('attendance'), this.data);
    }, 10);
  }

  showChart(dom, data) {
    if (data.length === 1) {
      this.pieData = [{id: 1, name: '未到', value: data[0].total - data[0].clocked}, {
        id: 2,
        name: '已签到',
        value: data[0].clocked
      }];
      this.showPie(dom, data);
    } else {
      this.showBar(dom, data);
    }
  }

  showBar(dom, data) {
    const labels = [];
    const rows = [];
    if (dom) {
      dom.style.height = (80 + data.length * 25) + 'px';
    }
    const chart: any = echarts;
    let total = 0;
    data.forEach(d => {
      labels.push(d.sectionName);
      rows.push(d.value);
      total = total + d.total;
    });
    const myChart: any = chart.init(dom);
    const option = {
      title: {
        text: `总数:${total}`
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
        formatter: (v) => {
          let index = 0;
          option.yAxis.data.forEach((res, key) => {
            if (v[0].name === res) {
              index = key;
            }
          });
          return `<p>${'实到：' + option.yAxis.params[index].clocked + '人'}</p><p>${'应到：' + option.yAxis.params[index].total + '人'}</p>`;
        },
      },
      grid: {
        left: '2%',
        right: '20px',
        bottom: '20px',
      },
      xAxis: {
        type: 'value',
        boundaryGap: false,
        min: 0,
        max: 100,
        axisLabel: {
          formatter: (value) => value + '%'
        }
      },
      yAxis: {
        type: 'category',
        data: labels,
        params: data
      },
      label: {
        show: true,
        align: 'left',
        verticalAlign: 'middle',
        position: 'inside',
        formatter: (value) => value.name + ':' + value.value + '%'
      },
      series: {
        name: '',
        type: 'bar',
        data: rows,
      }
    };
    myChart.setOption(option);
  }

  showPie(dom, data) {
    dom.style.height = (document.body.offsetWidth - 50) + 'px';
    const chart: any = echarts;
    let total = 0;
    data.forEach(d => {
      total = total + d.total;
    });
    const myChart: any = chart.init(dom);
    const option = {
      title: {
        text: `总数: ${total}`
      },
      tooltip: {
        trigger: 'item'
      },
      series: {
        name: '数据',
        type: 'pie',
        label: {
          show: true,
          position: 'inside',
          formatter: '{b}：{c}人'
        },
        radius: '100%',
        data: this.pieData,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    };
    myChart.setOption(option);
  }

  /*条件筛选*/
  changeFilter(data: any) {
    this.queryParams = data;
    this.initData();
  }

  segmentChanged() {
    this.initFilters();
    this.initData();
  }

  search() {
    this.queryParams = {...this.queryParams};
  }
}
