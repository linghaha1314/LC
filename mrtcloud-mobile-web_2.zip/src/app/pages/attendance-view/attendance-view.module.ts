import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AttendanceViewPageRoutingModule } from './attendance-view-routing.module';

import { AttendanceViewPage } from './attendance-view.page';
import {FilterDropdownModule} from '../../components/filter-dropdown/filter-dropdown.module';
import {FormatTimeModule} from '../../pipe/format-time/format-time.module';
import {BaseListModule} from '../../components/base-list/base-list.module';
import {LoadingTextModule} from '../../components/loading-text/loading-text.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AttendanceViewPageRoutingModule,
        FilterDropdownModule,
        FormatTimeModule,
        BaseListModule,
        LoadingTextModule
    ],
  declarations: [AttendanceViewPage]
})
export class AttendanceViewPageModule {}
