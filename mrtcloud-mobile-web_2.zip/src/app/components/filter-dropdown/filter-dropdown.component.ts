import {Component, EventEmitter, Input, OnInit, Output, QueryList, ViewChildren} from '@angular/core';
import {formatDate} from '@angular/common';
import {IonDatetime} from '@ionic/angular';
import {Help} from '../../utils/Help';

export declare type FilterDropdownStaticData = Array<{ id: string; name: string }>;
export declare type FilterDropdownData = Array<FilterDropdownEntityData>;

@Component({
  selector: 'filter-dropdown',
  templateUrl: './filter-dropdown.component.html',
  styleUrls: ['./filter-dropdown.component.scss'],
})
export class FilterDropdownComponent implements OnInit {


  @Input()
  maxDate: string = Number(this.help.formatTime('', 'YY')) + 1 + '-12-31';

  @Input()
  labelKey = 'name';

  @Input()
  valueKey = 'id';

  @Output()
  filterChange = new EventEmitter();

  @ViewChildren('datetime')
  dates: QueryList<IonDatetime>;

  defaultValue: any = {};

  dateDisplay = {
    year: 'YYYY',
    month: 'YYYY-MM',
    day: 'YY-MM-DD',
    full: 'YY-MM-DD HH:mm'
  };

  private dateFormat = {
    year: 'yyyy',
    month: 'yyyy-MM',
    day: 'yyyy-MM-dd',
    full: 'yyyy-MM-dd HH:mm'
  };

  private _data: FilterDropdownData = [];

  get data(): FilterDropdownData {
    return this._data;
  }

  @Input()
  set data(value: FilterDropdownData) {
    this._data = value;
  }


  constructor(private help: Help) {
  }

  ngOnInit() {
    this._data.forEach(d => {
      d.dateType = d.dateType ? d.dateType : 'day';
      if (d.value) {
        const value: any = {};
        value[d.code] = d.value;
        this.defaultValue = {...value, ...this.defaultValue};
        this.filterChange.emit(this.defaultValue);
      }
      this.initData(d);
    });
  }

  initData(d: FilterDropdownEntityData) {
    if (d.type === 'dictionary') {
      this.getDictionaryData(d).then();
    }
  }

  async getDictionaryData(data: FilterDropdownEntityData) {
    if (data.data == null) {
      await this.help.showLoading();
      const d: any = await this.help.post(data.url).toPromise();
      data.data = d._data || d.data;
      await this.help.hideLoading();
    }
  }

  changeData(data: FilterDropdownEntityData) {
    if (data.type !== 'date') {
      if ((data.type === 'static' || data.type === 'dictionary') && data.value === 0) {
        data.selectText = null;
        data.value = null;
      } else if (data.value === '') {
        data.selectText = null;
      } else {
        data.data.some(d => {
          if (data.labelKey) {
            data.selectText = d[data.labelKey];
            return;
          }
          if (d[this.valueKey] === data.value) {
            data.selectText = d[this.labelKey];
            return true;
          }
        });
      }
    } else {
      if (data.value) {
        const date = new Date(data.value);
        data.value = formatDate(date, this.dateFormat[data.dateType], 'zh');
        data.selectText = data.value;
      }
    }
    const value = {};
    this._data.forEach(d => {
      if (d.value && d.value !== 'null') {
        value[d.code] = d.value;
      }
    });
    this.filterChange.emit(value);
  }

  openDate(data: FilterDropdownEntityData) {
    this.dates.filter(d => d.name === data.code)[0].open().then();
  }

  openPage(data: FilterDropdownEntityData) {
    this.help.showSelect({
      title: data.label || '选择筛选科室',
      url: data.url || '/section/listByPage',
      mode: 'single',
      value: data.data ? data.data[0] : null,
      labelKey: data.labelKey,
      listKey: data.listKey
    }).then(r => {
      if (r) {
        if (!r[this.valueKey]) {
          if (data.value) {
            data.value = null;
            data.selectText = null;
            data.data = [];
            this.changeData(data);
          }
          return;
        }
        data.value = r[this.valueKey];
        data.data = [r];
        this.changeData(data);
      }
    });
  }

  dateCancel(d: FilterDropdownEntityData) {
    d.value = null;
    d.selectText = null;
    this.changeData(d);
  }
}

export class FilterDropdownEntityData {
  label: string;
  labelKey?: string;  //参数名
  isShowAllType?: number;  //是否显示全部类型,0不显示，其它都显示
  allValue?: any;  //全部类型值
  code: string;
  type: 'page' | 'dictionary' | 'static' | 'date';
  // type is static
  data?: FilterDropdownStaticData;
  // type is page or dictionary
  url?: string;
  // type is date
  dateType?: 'year' | 'month' | 'day' | 'full';
  value?: any;  //默认选中值，和selectText一组使用，定义默认值
  selectText?: string;   //默认显示名
  //data construct
  listKey?: string;
}
