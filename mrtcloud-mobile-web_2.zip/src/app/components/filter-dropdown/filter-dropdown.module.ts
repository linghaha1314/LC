import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FilterDropdownComponent} from './filter-dropdown.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';
import {LoadingTextModule} from '../loading-text/loading-text.module';


@NgModule({
  declarations: [FilterDropdownComponent],
  exports: [
    FilterDropdownComponent
  ],
    imports: [
        CommonModule,
        IonicModule,
        FormsModule,
        LoadingTextModule
    ]
})
export class FilterDropdownModule {
}
