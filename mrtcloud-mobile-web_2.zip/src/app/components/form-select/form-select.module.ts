import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormSelectComponent} from './form-select.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';


@NgModule({
  exports: [FormSelectComponent],
  declarations: [FormSelectComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})
export class FormSelectModule {
  open() {

  }
}
