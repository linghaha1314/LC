import {Component, ElementRef, EventEmitter, forwardRef, Input, OnChanges, OnInit, Output} from '@angular/core';
import {BaseComponent} from '../base.component';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {Help} from '../../utils/Help';

@Component({
  selector: 'form-select',
  templateUrl: './form-select.component.html',
  styleUrls: ['./form-select.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormSelectComponent),
    multi: true
  }]
})
export class FormSelectComponent extends BaseComponent implements OnInit, OnChanges {

  @Input()
  url: string;

  @Input()
  title?: string;

  @Input()
  list: string;

  @Input()
  labelKey = 'name';

  @Input()
  subTextKey: any = 'serialNo';

  @Input()
  sectionName: any;

  @Input()
  isShowWorkCaseNum: any = false;

  @Input()
  valueKey = 'id'; // 选中的取值识别key

  @Input()
  ariaLabel: string;

  @Input()
  labelValue: string;

  @Input()
  labelValueDefault: string;   //用于表单缓存，比如出科考核安排

  @Input()
  placeholder = '选择';

  @Input()
  queryParams = {};

  @Input()
  subHtml = '';

  @Input()
  subAfterText = '';

  @Output()
  eventEmitter = new EventEmitter();

  constructor(private help: Help, private el: ElementRef) {
    super();
  }

  @Input()
  changeData: (d: any) => any = (data: any) => data;   //改变数据结构

  ngOnInit() {
    this.ariaLabel = this.el.nativeElement.ariaLabel;
  }

  ngOnChanges() {
    if (this.labelValueDefault || this.labelValueDefault === null) {
      this.labelValue = this.labelValueDefault;
    }
  }

  showModal() {
    const data = {id: this.value};
    data[this.labelKey] = this.labelValue;
    const title = this.title ? this.title : (this.ariaLabel ? this.ariaLabel : '');
    const params: any = {
      title: `选择${title}`,
      url: this.url,
      labelKey: this.labelKey,
      value: data,
      subHtml: this.subHtml,
      subAfterText: this.subAfterText,
      valueKey: this.valueKey,//
      isShowWorkCaseNum: this.isShowWorkCaseNum,
      subTextKey: this.subTextKey,
      sectionName: this.sectionName,
      queryParams: this.queryParams,
    };
    if (this.list) {
      params.listKey = this.list;
    } else {
      params.changeData = (d) => this.changeData(d);
    }
    this.help.showSelect(params).then(r => {
      if (r) {
        this.labelValue = r[this.labelKey];
        this.eventEmitter.emit(r);
        if (r[this.valueKey]) {
          this.value = r[this.valueKey];
        } else {
          this.value = null;
        }
      }
    });
  }

}
