import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SelectModalComponent} from './select-modal.component';
import {IonicModule} from '@ionic/angular';
import {BaseListModule} from '../base-list/base-list.module';
import {FormsModule} from '@angular/forms';
import {SubLabelModule} from '../../pipe/sub-label/sub-label.module';
import {FilterDropdownModule} from '../filter-dropdown/filter-dropdown.module';



@NgModule({
  declarations: [SelectModalComponent],
  exports: [SelectModalComponent],
  imports: [
    CommonModule,
    IonicModule,
    BaseListModule,
    FormsModule,
    FilterDropdownModule,
    SubLabelModule
  ]
})
export class SelectModalModule { }
