import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {ModalController} from '@ionic/angular';
import {FilterDropdownData} from '../filter-dropdown/filter-dropdown.component';

@Component({
  selector: 'app-select-modal',
  templateUrl: './select-modal.component.html',
  styleUrls: ['./select-modal.component.scss'],
})
export class SelectModalComponent implements OnInit, OnDestroy {

  @Input()
  title = '请选择';

  @Input()
  url: string;

  @Input()
  labelKey = 'name';

  @Input()
  valueKey = 'id';

  @Input()
  listKey = 'list';

  @Input()
  subKey: Array<string>;

  @Input()
  mode: 'single' | 'multiple' = 'single';

  @Input()
  value: any;

  @Input()
  isShowWorkCaseNum = false;

  @Input()
  queryParams: any = {name: null};

  @Input()
  othersList: any[] = [];

  @Input()
  moreArrFlag: false;

  @Input()
  subTextKey? = 'serialNo';

  @Input()
  sectionName? = 'sectionName';

  @Input()
  searchPlaceholder? = '请输入';

  @Input()
  subHtml: any = '';

  @Input()
  subAfterText: any = '';

  @Input()
  filters: FilterDropdownData;

  @Input()
  isShowAllChecked: false;

  radioValueId: string;
  targetArr: any[];
  isAllChecked: any;
  total = 0;


  constructor(private modalController: ModalController) {
  }

  @Input()
  changeData: (d: any) => any = (data: any) => data;   //改变数据结构

  ngOnInit() {
    if (this.queryParams == undefined) {
      this.queryParams = {name: null};
    }
    if (this.labelKey == undefined) {
      this.labelKey = 'name';
    }
    if (this.valueKey == undefined) {
      this.valueKey = 'id';
    }
    if (this.mode === undefined) {
      this.mode = 'single';
    }
    if (this.mode == 'multiple') {
      if (this.value == null) {
        this.value = [];
      }
    } else {
      if (this.value) {
        this.radioValueId = this.value[this.valueKey];
      }
    }
  }

  ngOnDestroy() {
  }

  changeParams() {
    this.queryParams = {...this.queryParams};
  }

  closeModal(onlyClose = true) {
    this.modalController.dismiss(onlyClose ? null : this.value).then();
  }

  selectData() {
    if (this.mode == 'single') {
      if (this.radioValueId === undefined) {
        this.value = {};
      }
    }
  }

  /*每次分页就加载一次*/
  transfer = (data: any[]) => {
    if (this.mode == 'multiple') {
      const cache = {};
      if (this.isAllChecked) {
        this.value.forEach(d => {
          cache[d[this.valueKey]] = true;
        });
        data.forEach(d => {
          d._value = true;
          this.value.push(d);
        });
        return data;
      }
      this.value.forEach(d => {
        cache[d[this.valueKey]] = true;
      });
      data.forEach(d => {
        if (cache[d[this.valueKey]]) {
          d._value = true;
        }
      });
    }
    return data;
  };

  changeList = (data: any) => {
    this.total = data.total;
    if (!this.moreArrFlag) {
      if (this.listKey) {
        return {
          list: data[this.listKey ? this.listKey : 'list'],
          total: data.total
        };
      }
      return this.changeData ? this.changeData(data) : data;
    } else {
      const dataArr = data[this.listKey ? this.listKey : 'list'];
      const arr = [];
      dataArr.forEach(item => {
        const obj = {};
        this.subKey.forEach(ite => {
          const target = item[ite];
          Object.assign(obj, target);
        });
        arr.push(obj);
      });

      return {
        list: arr,
        total: data.total
      };
    }
  };

  changeSelect(item: any) {
    let flag = false;
    const data = [];
    this.value.forEach(d => {
      if (d[this.valueKey] == item[this.valueKey]) {
        flag = true;
      } else {
        data.push(d);
      }
    });
    if (flag) {
      this.value = data;
      if (this.isAllChecked) {
        this.total--;
      }
    } else {
      this.value.push(item);
      if (this.isAllChecked) {
        this.total++;
      }
    }
  }

  changeRadioValue(d: any) {
    this.value = d;
  }

  /*条件筛选*/
  changeFilter(data: any) {
    this.value = [];
    this.queryParams = {...this.queryParams, ...data};
  }

  /*全选*/
  changeAllChecked() {
    this.queryParams.pageSize = 1000;
    this.queryParams = {...this.queryParams};
    this.value = [];
  }
}
