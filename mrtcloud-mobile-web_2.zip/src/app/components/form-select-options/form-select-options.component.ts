import {
  Component,
  ElementRef,
  EventEmitter,
  forwardRef,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import {Help} from '../../utils/Help';
import {IonSelect} from '@ionic/angular';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';

@Component({
  selector: 'form-select-options',
  templateUrl: './form-select-options.component.html',
  styleUrls: ['./form-select-options.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormSelectOptionsComponent),
    multi: true
  }]
})
export class FormSelectOptionsComponent extends BaseComponent implements OnInit, OnChanges {
  @ViewChild('select')
  select: IonSelect;

  @Input()
  valueKey = 'id'; // 选中的取值识别key

  @Input()
  ariaLabel: string;

  @Input()
  labelValue = 'name';    // 默认name

  @Input()
  placeholder = '选择';

  @Input()
  queryParams = {};

  @Output()
  eventEmitter = new EventEmitter();

  @Input()
  list: any[] = [];

  @Input()
  isShowDate = false;

  @Input()
  interface: any = 'action-sheet';

  @Input()
  isRepeatChoose = false;

  @Input()
  labelValueDefault: string;   //用于表单缓存

  pageObj: any = {};


  constructor(private help: Help, private el: ElementRef) {
    super();
  }

  ngOnInit() {
    this.ariaLabel = this.el.nativeElement.ariaLabel;
  }

  ngOnChanges() {
    if (this.labelValueDefault) {
      this.pageObj[this.labelValue] = this.labelValueDefault;
    }
  }

  showSelect(e) {
    this.select.interface = this.interface;
    this.select.open(e).then();
  }

  changeSelect(e: any) {
    if (e.detail.value != null) {
      this.list.forEach(res => {
        if (res[this.valueKey] === e.detail.value) {
          this.pageObj = res;
          this.eventEmitter.emit(res);
        }
      });
    }
    if (this.isRepeatChoose) {
      this.select.value = null;
    }
  }
}
