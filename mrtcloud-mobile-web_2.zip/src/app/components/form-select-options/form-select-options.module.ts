import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormSelectOptionsComponent} from './form-select-options.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';
import {FormatTimeModule} from "../../pipe/format-time/format-time.module";


@NgModule({
  declarations: [FormSelectOptionsComponent],
    imports: [
        CommonModule,
        IonicModule,
        FormsModule,
        FormatTimeModule
    ], exports: [FormSelectOptionsComponent]
})
export class FormSelectOptionsModule {
}
