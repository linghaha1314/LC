import {Component, OnInit} from '@angular/core';
import {Help} from '../../utils/Help';
import {ModalController, NavParams} from '@ionic/angular';

@Component({
  selector: 'modal-list',
  templateUrl: './modal-list.component.html',
  styleUrls: ['./modal-list.component.scss'],
})
export class ModalListComponent implements OnInit {

  public list = [];
  public langSelect = {
    name: '',
  };

  constructor(public help: Help, public navParams: NavParams, public modalCtrl: ModalController) {
  }

  ngOnInit() {
    this.list = this.navParams.data.list;
    this.langSelect = this.navParams.data.defaultSelect;
  }

  close() {
    this.modalCtrl.dismiss().then();
  }

  save() {
    if (this.modalCtrl) {
      this.navParams.data.modal.dismiss({
        result: {
          currentSelect: this.langSelect,
          flag: true
        }
      });
      window.localStorage.setItem(this.navParams.data.selectName, JSON.stringify(this.langSelect));
    }
  }


}
