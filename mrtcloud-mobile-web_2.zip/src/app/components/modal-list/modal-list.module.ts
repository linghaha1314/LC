import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ModalListComponent} from './modal-list.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [ModalListComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
  ],
  exports: [ModalListComponent]
})
export class ModalListModule {
}
