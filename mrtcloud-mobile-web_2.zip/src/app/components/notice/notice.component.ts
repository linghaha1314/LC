import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'notice-scroll',
  templateUrl: './notice.component.html',
  styleUrls: ['./notice.component.scss'],
})
export class NoticeComponent implements OnInit {
  @Input()
  title = '温馨提示：';

  constructor() {
  }

  ngOnInit() {
  }

}
