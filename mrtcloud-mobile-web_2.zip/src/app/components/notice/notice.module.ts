import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {NoticeComponent} from './notice.component';
import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [NoticeComponent],
  exports: [NoticeComponent],
  imports: [
    CommonModule,
    IonicModule
  ]
})
export class NoticeModule {
}
