import {Component, OnDestroy, OnInit} from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import {Help} from '../../utils/Help';
import {StorageService} from '../../storage.service';

@Component({
  selector: 'app-qr-code',
  templateUrl: './qr-code.component.html',
  styleUrls: ['./qr-code.component.scss'],
})
export class QrCodeComponent implements OnInit, OnDestroy {
  qrcode: string;
  title: any;
  timer: any;
  isShowQr = false;

  constructor(private storage: StorageService, private modalCtrl: ModalController, private navParams: NavParams, private help: Help) {
  }

  async ngOnInit() {
    const qrcode = JSON.stringify(this.navParams.data.qrcode);
    const result = await this.help.post('http://qr.kbmrt.cn/add', {
      data: qrcode,
      name: this.storage.get('userInfo').staff.hospitalName,
    }, {}, false).toPromise();
    this.qrcode = `http://qr.kbmrt.cn/get/${result.id}`;
    this.isShowQr = true;
    this.title = this.navParams.data.title;
  }

  ngOnDestroy() {
    clearInterval(this.timer);
  }

  close() {
    this.modalCtrl.dismiss().then();
  }
}
