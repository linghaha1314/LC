import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {QrCodeComponent} from './qr-code.component';
import {IonicModule} from '@ionic/angular';
import {QRCodeModule} from 'angular2-qrcode';


@NgModule({
  declarations: [QrCodeComponent],
  exports: [QrCodeComponent],
  imports: [
    CommonModule,
    IonicModule,
    QRCodeModule
  ],
})

export class QrCodeDefineModule {
}
