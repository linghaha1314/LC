import {Component, OnInit, Output, EventEmitter, ContentChild, TemplateRef, ViewChild} from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import {Help} from '../../utils/Help';

/*
*在alter-popover里面引用对应的组件,save()方法调用对应的保存方法
* */
@Component({
  selector: 'alert-popover',
  templateUrl: './alert-popover.component.html',
  styleUrls: ['./alert-popover.component.scss'],
})
export class AlertPopoverComponent implements OnInit {
  @Output()
  saveBefore = new EventEmitter();

  @ContentChild(TemplateRef)
  templateRef: TemplateRef<any>;

  label: string = this.navParams.data.label;
  title: string = this.navParams.data.title;

  constructor(private modalController: ModalController, public navParams: NavParams, private help: Help) {
  }

  ngOnInit() {
    console.log(this.label, this.navParams.data);
  }

  close() {
    this.modalController.dismiss().then();
  }

  async save() {
    const result: any = {};
    switch (this.label) {
      case 'test':
        // result = this.test.researchRecordObj;
        // this.test.save();
        break;
    }
    await this.modalController.dismiss(result);
  }
}
