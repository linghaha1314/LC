import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {IonicModule} from '@ionic/angular';
import {AlertPopoverComponent} from './alert-popover.component';

@NgModule({
  declarations: [AlertPopoverComponent],
  imports: [
    CommonModule,
    IonicModule,
  ],
  exports: [AlertPopoverComponent],
})
export class AlertPopoverModule {
}
