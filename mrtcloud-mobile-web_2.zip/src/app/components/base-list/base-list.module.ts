import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {BaseListComponent} from './base-list.component';
import {IonicModule} from '@ionic/angular';
import {ShowEmptyModule} from '../show-empty/show-empty.module';
import {SubLabelModule} from '../../pipe/sub-label/sub-label.module';
import {LoadingTextModule} from '../loading-text/loading-text.module';



@NgModule({
  declarations: [BaseListComponent],
  exports: [
    BaseListComponent
  ],
    imports: [
        CommonModule,
        IonicModule,
        ShowEmptyModule,
        SubLabelModule,
        LoadingTextModule
    ]
})
export class BaseListModule { }
