﻿import {Component, ContentChild, EventEmitter, Input, OnInit, Output, TemplateRef} from '@angular/core';
import {Help} from '../../utils/Help';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';

@Component({
  selector: 'base-list',
  templateUrl: './base-list.component.html',
  styleUrls: ['./base-list.component.scss'],
})

export class BaseListComponent implements OnInit {

  @Input()
  mode: 'default' | 'customize' | 'all' = 'default'; // 标题属性

  get url(): string {
    return this._url;
  }

  @Input()
  set url(value: string) {
    this._url = value;
    if (this.initFlag) {
      this.loading = true;
      this.doRefresh().then();
    }
  }

  @Input()
  showImg = false; // 是否显示图片

  @Input()
  imgKey: string; // 图片地址属性

  @Input()
  titleLabel: string | any = 'name'; // 标题属性

  @Input()
  subtitleLabel: string; // 标题属性

  @Input()
  infoLabel: string; // 标题属性

  @Input()
  httpType = 'post'; // 标题属性

  @Input()
  titleValue: string; // 标题属性

  @Input()
  subtitleValue: string; // 标题属性

  @Input()
  infoValue: string; // 标题属性

  @Input()
  slidingColor = 'danger'; // 右侧滑动按钮颜色

  @Input()
  slidingString = '删除'; // 右侧滑动按钮文字

  @Input()
  set params(value: any) {
    this._params = value;
    if (this.initFlag) {
      this.loading = true;
      this.doRefresh().then();
    }
  }

  get params(): any {
    return this._params;
  }

  @Output()
  clickEvent = new EventEmitter<any>(); // list点击事件

  @ContentChild(TemplateRef)
  templateRef: TemplateRef<any>;

  @Input()
  noParams = false;

  loading = false;
  list: any;
  listParam: { pageSize: number; pageNum: number } = {
    pageSize: 20,
    pageNum: 1
  };

  isRef = true;
  isLoadingEnd = false;

  hasMore = true;

  private _url: string;

  private _params: any;

  private initFlag = false;

  constructor(private help: Help) {
  }

  @Input()
  transferData: (d: any[]) => any[] = (data: any[]) => data; //回调处理数据,采用绑定属性的方式绑定, transfer = (data: any[]) => data;

  @Input()
  changeList: (d: any) => any = (data: any) => data; //处理请求数据结构,需要返回list和total,采用绑定属性的方式绑定, transfer = (data: any[]) => data;

  ngOnInit() {
    if (this.url === undefined) {
      return;
    }
    this.loading = true;
    this.getList().subscribe(() => {
      this.initFlag = true;
    });
    if (this.noParams) {
      // @ts-ignore
      this.listParam = {};
    }
  }

  getList(): Observable<any> {
    const param = {...this.listParam, ...this.params};
    return this.help[this.httpType](this.url, {
      ...param,
      pageSize: this.listParam.pageSize,
      pageNum: this.listParam.pageNum
    }).pipe(map((res: any) => {
      const {list, total} = this.changeList(res);
      this.isLoadingEnd = true;
      this.loading = false;
      if (list) {
        if (!this.isRef) {
          this.list = [...this.list, ...this.transferData(list)];
        } else {
          this.list = [...this.transferData(list)];
        }
        if (total === undefined) {
          this.hasMore = false;
        } else {
          if (total <= this.list.length) {
            this.hasMore = false;
          }
        }
      }
    }));
  }

  loadUrl(url: string) {
    this._url = url;
    this.ngOnInit();
  }

  async doRefresh(event?) {
    this.isRef = true;
    this.hasMore = true;
    this.listParam.pageNum = 1;
    // await this.help.showLoading().then();
    this.getList().subscribe(() => {
      event?.target.complete();
    });
  }

  addMore(event) {
    if (this.loading) {
      return;
    }
    this.isRef = false;
    this.listParam.pageNum++;
    this.getList().subscribe(() => {
      event.target.complete();
    });
  }

  clickFn(data) {
    this.clickEvent.emit(data);
  }
}
