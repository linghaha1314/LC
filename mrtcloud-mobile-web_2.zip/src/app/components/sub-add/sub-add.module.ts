import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SubAddComponent} from './sub-add.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';


@NgModule({
  declarations: [SubAddComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ],
  exports: [SubAddComponent]
})
export class SubAddModule {
}
