import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'sub-add',
  templateUrl: './sub-add.component.html',
  styleUrls: ['./sub-add.component.scss'],
})
export class SubAddComponent implements OnInit {
  @Input()
  unit: any;

  @Input()
  min = 0;

  @Input()
  disabled = false;

  @Input()
  max = 100;

  @Input()
  step = 1;

  @Input()
  color = 'light';

  @Input()
  value = 0;

  @Output()
  valueChange = new EventEmitter<number>();


  constructor() {
  }

  ngOnInit() {
    if (!this.value) {
      this.value = this.min;
    }
  }

  subAnd(step: number, limitValue: number) {
    if (this.value === limitValue) {
      this.value = limitValue;
    } else {
      this.value += step;
    }
    this.valueChange.emit(this.value);
  }

  inputChange() {
    if (typeof this.value === 'number' && this.value > this.max) {
      this.value = this.max;
    }
    if ((typeof this.value === 'number' && this.value < this.min) || typeof this.value !== 'number') {
      this.value = this.min;
    }
    this.valueChange.emit(this.value);
  }
}
