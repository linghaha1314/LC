import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'show-empty',
  templateUrl: './show-empty.component.html',
  styleUrls: ['./show-empty.component.scss'],
})
export class ShowEmptyComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
