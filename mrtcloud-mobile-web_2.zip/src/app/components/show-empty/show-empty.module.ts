import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ShowEmptyComponent} from './show-empty.component';
import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [ShowEmptyComponent],
  exports: [ShowEmptyComponent],
  imports: [
    CommonModule,
    IonicModule
  ]
})
export class ShowEmptyModule {
}
