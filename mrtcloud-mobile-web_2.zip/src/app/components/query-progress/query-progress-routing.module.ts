import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { QueryProgressPage } from './query-progress.page';

const routes: Routes = [
  {
    path: '',
    component: QueryProgressPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class QueryProgressPageRoutingModule {}
