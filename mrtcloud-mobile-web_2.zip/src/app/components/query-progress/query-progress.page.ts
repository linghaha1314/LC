import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Help} from '../../utils/Help';

@Component({
  selector: 'app-query-progress',
  templateUrl: './query-progress.page.html',
  styleUrls: ['./query-progress.page.scss'],
})
export class QueryProgressPage implements OnInit {
  @Input()
  queryParam: {
    processInstanceId: string;
    businessId: string;
  };
  @Input()
  url? = '/workflows/getFlowData';

  @Input()
  autoStatus: any = false;

  @Output()
  getCurrentApproval = new EventEmitter();
  start = 0;
  list: any[] = [];
  currentTeacher: any;

  constructor(
    public help: Help
  ) {
  }

  ngOnInit() {
    this.getProgress();
  }

  getProgress() {
    //审批流程status:0 驳回；1：同意，2：无状态，审批中：11，null:待审核
    this.help.post('/workflows/getFlowData', this.queryParam).subscribe(b => {
      if (b.success) {
        b.list.forEach((r, i) => {
          if (r.status != null) {
            this.start = i;
          }
        });
        this.list = b.list;
        for (const item of this.list) {
          if (!item.status) {
            this.currentTeacher = item.currentApprovalUsers;
            this.getCurrentApproval.emit(item);
            break;
          }
        }
      }
    });
  }
}
