import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { QueryProgressPageRoutingModule } from './query-progress-routing.module';

import { QueryProgressPage } from './query-progress.page';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        QueryProgressPageRoutingModule
    ],
    exports: [
        QueryProgressPage
    ],
    declarations: [QueryProgressPage]
})
export class QueryProgressPageModule {}
