import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ExamListComponent} from './exam-list.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';
import {StarScoreModule} from '../star-score/star-score.module';
import {SafeHtmlModule} from "../../pipe/SafeHtml.module";


@NgModule({
  declarations: [
    ExamListComponent
  ],
  exports: [
    ExamListComponent
  ],
    imports: [
        CommonModule,
        IonicModule,
        FormsModule,
        StarScoreModule,
        SafeHtmlModule
    ]
})
export class ExamListModule {
}
