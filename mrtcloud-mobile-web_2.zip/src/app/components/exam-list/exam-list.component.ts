import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'exam-list',
  templateUrl: './exam-list.component.html',
  styleUrls: ['exam-list.component.scss'],
})
export class ExamListComponent implements OnInit {
  @Input() item: any = {};
  @Input() sequence: any = {};

  constructor() {
  }

  ngOnInit() {
  }

  changeRadio(item) {
    item.options.map(res => {
      res.indexResult = item.indexResult;
      if (item.indexResult == res.id) {
        res.indexValue = res.optionValue;
        item.indexValue = res.optionValue;
      }
    });
  }

  changeInput(item) {
    item.options.map(res => {
      res.indexResult = item.indexResult;
      res.indexValue = 0;
    });
  }

  changeCheckBox(item: any) {
    item.indexResult = '';
    item.options.map(res => {
      if (res.isChecked) {
        item.indexResult += (res.id + ',');
      }
    });
    item.indexResult = item.indexResult.slice(0, item.indexResult.length - 1);
  }
}
