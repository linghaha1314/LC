import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {StarScoreComponent} from './star-score.component';
import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [StarScoreComponent],
  exports: [StarScoreComponent],
  imports: [
    CommonModule,
    IonicModule
  ]
})
export class StarScoreModule {
}
