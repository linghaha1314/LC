import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
    selector: 'star-score',
    templateUrl: './star-score.component.html',
    styleUrls: ['./star-score.component.scss'],
})
export class StarScoreComponent implements OnInit {
    @Input()
    isOnlyView = false;

    @Input()
    maxScore?: number;

    @Input()
    num?: number;

    @Input()
    star!: number | string;
    @Output()
    starChange = new EventEmitter<number>();

    data: any = {
        num: 5,
        score: 0,
        unit: 1,   //一颗星代表1
        numArr: [1, 2, 3, 4, 5]
    };

    constructor() {
    }

    ngOnInit() {
        this.data.score = this.star ? this.star : 0;
        this.data.num = this.num ? this.num : 5;
        this.star = this.star ? this.star : 0; //正对初始化为null的处理
        if (this.data.num !== 5 && this.data.num <= 10) {
            this.data.numArr = [];
            for (let i = 0; i < this.data.num; i++) {
                this.data.numArr.push(i + 1);
            }
        }
        this.data.unit = this.maxScore ? this.maxScore / this.data.num : 1;
        this.defineScore(this.star, this.data.num, this.data.unit);
    }

    defineScore(value, num, unit) {
        if (value > num * unit) {
            unit++;
            this.defineScore(value, num, unit);
        } else {
            this.data.unit = unit;
        }
    }

    chooseStar(e) {
        if (!this.isOnlyView) {
            const star = parseInt(e.target.dataset.index, 10) * this.data.unit;
            if (star) {
                this.data.score = star;
                this.starChange.emit(star);
            }
        }
    }
}
