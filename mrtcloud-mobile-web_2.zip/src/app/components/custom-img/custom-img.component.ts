import {Component, Input} from '@angular/core';
import {StorageService} from '../../storage.service';

@Component({
  selector: 'custom-img',
  templateUrl: './custom-img.component.html',
  styleUrls: ['./custom-img.component.scss'],
})
export class CustomImgComponent {

  @Input()
  baseUrl = this.storageService.baseUrl;

  @Input()
  errorUrl = '/assets/images/file.svg';

  get src(): any {
    return this._src;
  }

  @Input()
  set src(value: any) {
    this._src = value;
    this.renderImg();
  }

  img: string;

  isLoading = false;

  private _src: any;


  constructor(private storageService: StorageService) {
  }

  renderImg() {
    if (this.src === this.errorUrl) {
      return;
    }
    if (this.src && this.src.indexOf('http://localhost') > -1) {
      this.img = this.src.split('http://localhost')[1];
    }
    if (!this.src || !RegExp(/.jpg|.png|jpeg/).test(this.src.toLowerCase())) {
      this.img = this.errorUrl;
      return;
    }
    if (this.baseUrl) {
      this.img = this.baseUrl + decodeURI(this.src);
    }
  }

  errorLoad() {
    this.img = this.errorUrl;
  }

}
