import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CustomImgComponent} from './custom-img.component';
import {IonicModule} from '@ionic/angular';
import {LoadingTextModule} from "../loading-text/loading-text.module";


@NgModule({
  declarations: [CustomImgComponent],
    imports: [
        CommonModule,
        IonicModule,
        LoadingTextModule
    ], exports: [CustomImgComponent]
})
export class CustomImgModule {
}
