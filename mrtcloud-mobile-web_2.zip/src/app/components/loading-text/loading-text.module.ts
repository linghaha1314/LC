import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LoadingTextComponent} from './loading-text.component';
import {IonicModule} from '@ionic/angular';


@NgModule({
  declarations: [LoadingTextComponent],
  imports: [
    CommonModule,
    IonicModule
  ], exports: [LoadingTextComponent]
})
export class LoadingTextModule {
}
