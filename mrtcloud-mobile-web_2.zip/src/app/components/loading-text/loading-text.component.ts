import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'loading-text',
  templateUrl: './loading-text.component.html',
  styleUrls: ['./loading-text.component.scss'],
})
export class LoadingTextComponent implements OnInit {
  @Input()
  height = '94px';

  @Input()
  text = '加载中...';

  constructor() {
  }

  ngOnInit() {
  }

}
