import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FileViewerPage } from './file-viewer.page';

const routes: Routes = [
  {
    path: ':id',
    component: FileViewerPage,
    data: {title: '文件预览'}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FileViewerPageRoutingModule {}
