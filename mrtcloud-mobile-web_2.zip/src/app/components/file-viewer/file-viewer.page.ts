import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {of} from 'rxjs';
import {DomSanitizer} from '@angular/platform-browser';
import {StorageService} from '../../storage.service';
import {Buffer} from 'buffer';

@Component({
  selector: 'app-file-viewer',
  templateUrl: './file-viewer.page.html',
  styleUrls: ['./file-viewer.page.scss'],
})
export class FileViewerPage implements OnInit {

  src: any;

  constructor(public storageService: StorageService, private route: ActivatedRoute, private sanitizer: DomSanitizer, private router: Router) {
  }

  ngOnInit(): void {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => of(params.get('id')))
    ).subscribe(d => {
      let url = this.storageService.baseUrl;
      url = url + d;
      this.src = this.sanitizer.bypassSecurityTrustResourceUrl(`http://116.63.185.184:8012/onlinePreview?url=` + encodeURIComponent(Buffer.from(url).toString('base64')));
    });
  }

  downLoad() {
    window.open(this.storageService.baseUrl + this.route.snapshot.params.id);
  }
}
