import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FileSelectComponent} from './file-select.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {IOSFilePicker} from '@ionic-native/file-picker/ngx';
import {CustomImgModule} from '../custom-img/custom-img.module';
import {ImagePicker} from '@awesome-cordova-plugins/image-picker/ngx';

@NgModule({
  declarations: [FileSelectComponent],
  exports: [FileSelectComponent],
  providers: [IOSFilePicker, ImagePicker],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    RouterModule,
    CustomImgModule
  ]
})
export class FileSelectModule {
}
