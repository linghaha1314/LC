import {
  Component,
  ElementRef,
  EventEmitter,
  forwardRef,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import {ActionSheetController, IonSelect} from '@ionic/angular';
import {Camera, CameraResultType, CameraSource} from '@capacitor/camera';
import {formatDate} from '@angular/common';
import {Help} from '../../utils/Help';
import {BaseComponent} from '../base.component';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {Router} from '@angular/router';
import {IOSFilePicker} from '@ionic-native/file-picker/ngx';
import {Filesystem} from '@capacitor/filesystem';
import {StorageService} from '../../storage.service';
import {ImagePicker} from '@awesome-cordova-plugins/image-picker/ngx';

@Component({
  selector: 'file-select',
  templateUrl: './file-select.component.html',
  styleUrls: ['./file-select.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FileSelectComponent),
    multi: true
  }]
})
export class FileSelectComponent extends BaseComponent implements OnDestroy, OnInit {
  @Input()
  isViewOnly = false;
  @Input()
  uploadUrl = '/account/uploadfile';
  @Input()
  isShowList = true;
  @Input()
  showBefore = false;  //选择文件之前是否有操作
  @Input()
  isUpload = true;
  @Input()
  isAllowDelete = true;
  @Input()
  isDownload = false;
  @Input()
  isCameraOnly = false;
  @Input()
  isPhotoOnly = false;  //只选取照片
  @Output()
  changeEmit = new EventEmitter();
  @Output()
  deleteEmit = new EventEmitter();
  @Output()
  beforeUploadEvent = new EventEmitter();

  @ViewChild('types')
  select: IonSelect;

  @ViewChild('iosInput')
  iosInput: ElementRef;

  list = [];

  nameIndex = 0;
  event: any;
  baseUrl = this.storageService.baseUrl;
  path = window.location.protocol + '//' + window.location.host;
  appInfo: any;

  // private imagePicker: ImagePicker,
  constructor(public storageService: StorageService, private router: Router, private actionSheetController: ActionSheetController, private help: Help, private filePicker: IOSFilePicker, private imagePicker: ImagePicker) {
    super();
  }

  ngOnInit(): void {
    try {
      // @ts-ignore
      this.appInfo = JSON.parse(window.system.getAppInfo());
    } catch (e) {

    }
  }

  ngOnDestroy() {
  }

  async beforeShowType(e) {
    if (this.showBefore) {
      this.beforeUploadEvent.emit();
    } else {
      await this.showType();
    }
  }

  writeValue(value: any) {
    if (value && value.length > 0) {
      value.forEach(v => {
        v.icon = v.path ? v.path : v.attachPath;
      });
      this.list = value;
    }
    super.writeValue(value);
  }

  async showType() {
    if ((this.isCameraOnly || this.isPhotoOnly || this.help.isIos()) && await this.help.getDeviceInfo() !== 'ios') {
      const type = this.help.isIos() ? 'file' : this.isPhotoOnly ? 'photo' : 'camera';
      const dd = await this.openOperation(type);
      const r: any = await this.uploadFile(dd);
      this.list.push(...r);
      this.value = this.list;
      return;
    }
    const actionSheet = await this.actionSheetController.create({
      buttons: [
        {
          text: '拍照',
          role: 'camera',
          icon: 'camera-outline'
        },
        {
          text: '相册',
          role: 'photo',
          icon: 'image-outline'
        },
        {
          text: '文件',
          role: 'file',
          icon: 'document-outline'
        },
        {
          text: '取消',
          icon: 'close',
          role: 'cancel'
        }
      ]
    });
    await actionSheet.present();

    const {role} = await actionSheet.onDidDismiss();
    if (role == 'backdrop' || role == 'cancel') {
      return;
    }
    const d = await this.openOperation(role);
    const result: any = await this.uploadFile(d);
    this.list.push(...result);
    this.value = this.list;
  }

  //没用？？
  async uploadBase64() {
    const d = await this.openOperation('file');
    this.changeEmit.emit(d);
  }

  async openOperation(type: string) {
    if (type === 'file' && await this.help.getDeviceInfo() !== 'ios') {
      return await this.selectFile();
    }
    if (type === 'file' && await this.help.getDeviceInfo() === 'ios') {
      return new Promise((resolve) => {
        this.filePicker.pickFile()
          .then(async uri => {
            const contents = await Filesystem.readFile({
              path: 'file://' + uri
            });
            let name: any = uri.split('/');
            name = name[name.length - 1];
            resolve({
              name: formatDate(new Date(), 'yyyyMMddHHmmss', 'zh') + decodeURI(name),
              data: 'data:image/png;base64,' + contents.data
            });
          })
          .catch(err => console.log('Error', err));
      });
    }
    if (this.appInfo != null && this.appInfo.appVersion != null) {
      if (type === 'photo') {
        return new Promise((resolve) => {
          const photoResult = [];
          const version = parseFloat(this.appInfo.appVersion);
          if (version > 1.4) {
            // @ts-ignore
            const images = window.system.pickerImages();
            if (images.trim().length == 0) {
              return;
            }
            const rr = images.split(',');
            this.help.showLoading();
            rr.forEach(async uri => {
              const contents = await Filesystem.readFile({
                path: 'file://' + uri
              });
              let name: any = uri.split('/');
              name = name[name.length - 1];
              photoResult.push({
                name: formatDate(new Date(), 'yyyyMMddHHmmss', 'zh') + decodeURI(name),
                data: 'data:image/png;base64,' + contents.data
              });
              if (photoResult.length == rr.length) {
                this.help.hideLoading();
                resolve(photoResult);
              }
            });
            return;
          }
          this.imagePicker.getPictures({title: '选择图片'}).then((rr: any) => {
            rr.forEach(async uri => {
              const contents = await Filesystem.readFile({
                path: 'file://' + uri
              });
              let name: any = uri.split('/');
              name = name[name.length - 1];
              photoResult.push({
                name: formatDate(new Date(), 'yyyyMMddHHmmss', 'zh') + decodeURI(name),
                data: 'data:image/png;base64,' + contents.data
              });
              if (photoResult.length == rr.length) {
                resolve(photoResult);
              }
            });
          }, async (err) => {
            console.error(err);
            resolve(await this.cameraGetPhoto('photo'));
          });
        });
      } else {
        return await this.cameraGetPhoto(type);
      }
    } else {
      return await this.cameraGetPhoto(type);
    }

  }

  async cameraGetPhoto(type = 'camera') {
    const file = await Camera.getPhoto({
      quality: 90,
      allowEditing: false,
      webUseInput: type == 'photo',
      source: type == 'camera' ? CameraSource.Camera : CameraSource.Photos,
      resultType: CameraResultType.DataUrl,
      promptLabelHeader: '选择',
      promptLabelPicture: '拍照',
      promptLabelPhoto: '相册',
      promptLabelCancel: '取消'
    });
    this.nameIndex++;
    return {
      name: formatDate(new Date(), 'yyyyMMddHHmmss', 'zh') + this.nameIndex + '.' + (file.format == 'jpeg' ? 'jpg' : file.format),
      data: file.dataUrl
    };
  }

  /*创建一个input上传文件的接口*/
  selectFile(): Promise<any> {
    const iosInput = this.iosInput.nativeElement;
    return new Promise((resolve) => {
      iosInput.onchange = (e: any) => {
        const files = [].slice.call(e.target.files);
        const resultList = [];
        files.forEach((dd, index) => {
          const file = dd as any;
          const reader = new FileReader();
          reader.readAsDataURL(file); // this is reading as data url
          reader.onload = readerEvent => {
            const content = readerEvent.target.result; // this is the content!
            const obj = {name: file.name, data: content};
            resultList.push(obj);
            if (resultList.length === files.length) {  //注意异步，长度相等则解析完所有数据
              resolve(resultList);
            }
          };
        });
      };
      iosInput.click();
    });
  }

  async uploadFile(files: any) {
    const fileList: any = Object.prototype.toString.call(files) === '[object Array]' ? files : [{...files}];
    await this.help.showLoading('文件上传中...', 0).then();
    return await new Promise(resolve => {
      const list = [];
      fileList.forEach((file, index) => {
        fetch(file.data)
          .then(res => res.blob())
          .then(async blob => {
            const fd = new FormData();
            const image = new File([blob], file.name);
            fd.append('fileUpload', image);
            this.help.post(this.uploadUrl, fd).subscribe(result => {
              const obj = {
                name: result.fileName,
                path: result.path,
                icon: this.path + result.path
              };
              if (result.success) {
                list.push(obj);
              }
              if (list.length === fileList.length) { //注意异步，长度相等则解析完所有数据
                this.help.hideLoading().then();
                this.changeEmit.emit(list);   //注意返回
                resolve(list);
              }
            });
          });
      });
    });
  }

  errorLoad(item) {
    item.icon = '/assets/images/file.svg';
  }

  async deleteFile(e: any, item: any) {
    e.preventDefault();
    e.stopPropagation();
    const result = await this.help.confirm({title: '删除', msg: `是否确认删除附件?`});
    if (result) {
      this.deleteEmit.emit(item);
      const data = [];
      this.value.forEach(v => {
        if (v.id && item.id && v.id !== item.id) {
          data.push(v);
        } else if (v.path != item.path) {
          data.push(v);
        }
      });
      this.list = data;
      this.value = data;
      this.onEmit(this.value);
    }
  }

  goView(item) {
    if (!item.path && !item.attachPath) {
      this.help.toastError('文件地址有误，请重新上传！');
      return;
    }
    this.router.navigate(['/file-viewer', item.path ? item.path : item.attachPath]).then();
  }

}
