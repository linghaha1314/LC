import {Component, forwardRef, Input} from '@angular/core';
import {BaseComponent} from '../base.component';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {formatDate} from '@angular/common';
import {Help} from '../../utils/Help';

@Component({
  selector: 'form-date',
  templateUrl: './form-date.component.html',
  styleUrls: ['./form-date.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormDateComponent),
    multi: true
  }]
})
export class FormDateComponent extends BaseComponent {

  @Input()
  placeholder = '选择';

  @Input()
  maxDate: any = Number(this.help.formatTime('', 'YY')) + 1 + '-12-31';

  @Input()
  minDate: string;

  @Input()
  readonly = false;

  @Input()
  type: 'year' | 'month' | 'day' | 'full' | 'hm' | 'halfDay' = 'day';

  dateDisplay = {
    year: 'YYYY',
    month: 'YYYY-MM',
    day: 'YYYY-MM-DD',
    full: 'YYYY-MM-DD HH:mm',
    hm: 'HH:mm',
    halfDay: 'YYYY-MM-DD A'
  };

  private dateFormat = {
    year: 'yyyy',
    month: 'yyyy-MM',
    day: 'yyyy-MM-dd',
    full: 'yyyy-MM-dd HH:mm',
    hm: 'HH:mm',
    halfDay: 'YYYY-MM-DD A'
  };


  constructor(private help: Help) {
    super();
  }

  changeDate() {
    if (this.innerValue.length == this.dateFormat[this.type].length) {
      this.onEmit(this.innerValue);
      return;
    }
    this.onEmit(formatDate(new Date(this.innerValue), this.dateFormat[this.type], 'zh'));
  }
}
