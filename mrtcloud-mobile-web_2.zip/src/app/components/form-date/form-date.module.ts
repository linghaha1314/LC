import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormDateComponent} from './form-date.component';
import {IonicModule} from '@ionic/angular';
import {FormsModule} from '@angular/forms';


@NgModule({
  exports: [FormDateComponent],
  declarations: [FormDateComponent],
  imports: [
    CommonModule,
    IonicModule,
    FormsModule
  ]
})
export class FormDateModule {
}
