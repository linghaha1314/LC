import {Injectable} from '@angular/core';
import {EventEmitter} from 'eventemitter3';
import {NavController} from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  public event = new EventEmitter();

  constructor(private navController: NavController) {
  }

  emit(name: string, params?: any) {
    this.event.emit(name, params);
  }

  back() {
    this.emit('pop');
    this.navController.back();
  }

  off(name) {
    this.event.off(name);   //销毁，每次组件销毁
  }

  on(name: string, fn: (d: any) => any = (data?: any) => data) {
    this.event.on(name, fn);  //存储一个数组，凡是name一样都执行！
  }
}
