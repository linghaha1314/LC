import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouteReuseStrategy} from '@angular/router';

import {IonicModule, IonicRouteStrategy, NavController} from '@ionic/angular';
import zh from '@angular/common/locales/zh';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {HttpClientModule, HttpClientJsonpModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import {HttpBaseInterceptor} from './utils/HttpBaseInterceptor';
import {registerLocaleData} from '@angular/common';
import {SelectModalModule} from './components/select-modal/select-modal.module';
import {FormBuilder} from '@angular/forms';
import {StorageService} from './storage.service';
import {EventService} from './event.service';


registerLocaleData(zh);

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot({
    backButtonText: '',
    mode: 'ios',//强制安卓也使用iOS的样式
  }), AppRoutingModule, HttpClientModule, HttpClientJsonpModule, SelectModalModule],
  providers: [
    {provide: RouteReuseStrategy, useClass: IonicRouteStrategy},
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpBaseInterceptor,
      multi: true
    },
    FormBuilder,
    StorageService,
    EventService
  ],
  bootstrap: [AppComponent],
  exports: []
})
export class AppModule {
}
