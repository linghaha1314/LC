import {NgModule} from '@angular/core';
import {NoPreloading, RouterModule, Routes} from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./pages/tabs/tabs.module').then((m) => m.TabsPageModule),
    data: {
      title: '首页'
    }
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule),
    data: {
      title: '登录'
    }
  },
  {
    path: 'TeachActivity',
    loadChildren: () => import('./pages/teach-activity/teach-activity.module').then(m => m.TeachActivityPageModule),
    data: {
      title: '教学活动'
    }
  },
  {
    path: 'WorkloadReport',
    loadChildren: () => import('./pages/workload/workload.module').then(m => m.WorkloadPageModule),
    data: {
      title: '工作量填报'
    }
  },
  /*绵阳中心医院，郑州人民医院单独的工作量填写;*/
  {
    path: 'myzxyyWorkloadReport',
    loadChildren: () => import('./pages/myzxyy/workload/workload.module').then(m => m.WorkloadPageModule),
    data: {
      title: '工作量填报'
    }
  }, {
    path: 'WorkloadAudit',
    loadChildren: () => import('./pages/workload/workload.module').then(m => m.WorkloadPageModule),
    data: {
      title: '工作量审核'
    }
  },
  {
    path: 'SectionGroup',
    loadChildren: () => import('./pages/section-group/section-group.module').then(m => m.SectionGroupPageModule),
    data: {
      title: '轮转分组'
    }
  },
  {
    path: 'TransferScheduleQuery',
    loadChildren: () => import('./pages/transfer-schedule-query/transfer-schedule-query.module').then(m => m.TransferScheduleQueryPageModule),
    data: {
      title: '轮转查询'
    }
  },
  {
    path: 'MyStudents',
    loadChildren: () => import('./pages/transfer-schedule-query/transfer-schedule-query.module').then(m => m.TransferScheduleQueryPageModule),
    data: {
      title: '我的学员'
    }
  }, {
    path: 'StudentQuery',
    loadChildren: () => import('./pages/transfer-schedule-query/transfer-schedule-query.module').then(m => m.TransferScheduleQueryPageModule),
    data: {
      title: '学员查询'
    }
  },
  {
    path: 'TransferScheduleStudent',
    loadChildren: () => import('./pages/transfer-schedule-query/transfer-schedule-query.module').then(m => m.TransferScheduleQueryPageModule),
    data: {
      title: '轮转学员'
    }
  },
  {
    path: 'EvalType_StudentMiniCEX',
    loadChildren: () => import('./pages/eval-type-student/eval-type-student.module').then(m => m.EvalTypeStudentMiniCEXPageModule),
    data: {
      title: 'MiniCEX(学生)'
    }
  },
  {
    path: 'EvalType_StudentDOPS',
    loadChildren: () => import('./pages/eval-type-student/eval-type-student.module').then(m => m.EvalTypeStudentMiniCEXPageModule),
    data: {
      title: 'Dops(学生)'
    }
  },
  {
    path: 'EvalType_TeacherMiniCEX',
    loadChildren: () => import('./pages/eval-type-teacher/eval-type-teacher.module').then(m => m.EvalTypeTeacherPageModule),
    data: {
      title: 'MiniCEX(老师)'
    }
  },
  {
    path: 'EvalType_TeacherDOPS',
    loadChildren: () => import('./pages/eval-type-teacher/eval-type-teacher.module').then(m => m.EvalTypeTeacherPageModule),
    data: {
      title: 'Dops(老师)'
    }
  },
  {
    path: 'Evaluate',
    loadChildren: () => import('./pages/evaluate/evaluate.module').then(m => m.EvaluatePageModule),
    data: {
      title: '综合评价'
    }
  },
  {
    path: 'CheckoutSectionExam',
    loadChildren: () => import('./pages/checkout-section-exam/checkout-section-exam.module').then(m => m.CheckoutSectionExamPageModule),
    data: {
      title: '出科考核'
    }
  },
  {
    path: 'file-viewer',
    loadChildren: () => import('./components/file-viewer/file-viewer.module').then(m => m.FileViewerPageModule)
  },
  {
    path: 'OnlineExam',
    loadChildren: () => import('./pages/online-exam/online-exam.module').then(m => m.OnlineExamPageModule),
    data: {
      title: '在线考试'
    }
  },
  {
    path: 'QuestionnaireSurvey',
    loadChildren: () => import('./pages/questionnaire-survey/questionnaire-survey.module').then(m => m.QuestionnaireSurveyPageModule),
    data: {
      title: '问卷调查'
    }
  },
  {
    path: 'LeaveAndReturnManage',
    loadChildren: () => import('./pages/leave-and-return-manage/leave-and-return-manage.module').then(m => m.LeaveAndReturnManagePageModule),
    data: {
      title: '请销假'
    }
  },
  {
    path: 'LeaveAndReturnApproval',
    loadChildren: () => import('./pages/leave-and-return-manage/leave-and-return-manage.module').then(m => m.LeaveAndReturnManagePageModule),
    data: {
      title: '请销假审批'
    }
  },
  {
    path: 'LeaveAndReturnHistory',
    loadChildren: () => import('./pages/leave-and-return-manage/leave-and-return-manage.module').then(m => m.LeaveAndReturnManagePageModule),
    data: {
      title: '请销假历史查询'
    }
  },
  {
    path: 'SkillExam',
    loadChildren: () => import('./pages/skill-exam/skill-exam.module').then(m => m.SkillExamPageModule),
    data: {
      title: '技能考核'
    }
  },
  {
    path: 'StudentMonthAppraise',
    loadChildren: () => import('./pages/student-month-checkout-appraise/student-month-checkout-appraise.module').then(m => m.StudentMonthCheckoutAppraisePageModule),
    data: {
      title: '月度评价'
    }
  },
  {
    path: 'StudentCheckOutAppraise',
    loadChildren: () => import('./pages/student-month-checkout-appraise/student-month-checkout-appraise.module').then(m => m.StudentMonthCheckoutAppraisePageModule),
    data: {
      title: '出科评价'
    }
  },
  {
    path: 'StudentMonthApproval',
    loadChildren: () => import('./pages/student-month-checkout-approval/student-month-checkout-approval.module').then(m => m.StudentMonthCheckoutApprovalPageModule),
    data: {
      title: '月度评价审核'
    }
  },
  {
    path: 'StudentCheckOutApproval',
    loadChildren: () => import('./pages/student-month-checkout-approval/student-month-checkout-approval.module').then(m => m.StudentMonthCheckoutApprovalPageModule),
    data: {
      title: '出科评价审核'
    }
  },
  {
    path: 'ArrangeExam',
    loadChildren: () => import('./pages/arrange-exam/arrange-exam.module').then(m => m.ArrangeExamPageModule),
    data: {
      title: '考试安排'
    }
  },
  {
    path: 'AttendanceManagement',
    loadChildren: () => import('./pages/attendance-management/attendance-management.module').then(m => m.AttendanceManagementPageModule),
    data: {
      title: '考勤管理'
    }
  },
  {
    path: 'talkNoteList',
    loadChildren: () => import('./pages/talk-note/talk-note.module').then(m => m.TalkNotePageModule),
    data: {
      title: '一对一谈话'
    }
  },
  {
    path: 'zzrmTalkNoteList',
    loadChildren: () => import('./pages/zzrm/talk-note/talk-note.module').then(m => m.zzrmTalkNotePageModule),
    data: {
      title: '一对一谈话'
    }
  },
  {
    path: 'Transferadjust',
    loadChildren: () => import('./pages/transferadjust/transferadjust.module').then(m => m.TransferadjustPageModule),
    data: {
      title: '轮转调整'
    }
  },
  {
    path: 'TransferAdjustExamine',
    loadChildren: () => import('./pages/transfer-adjust-examine/transfer-adjust-examine.module').then(m => m.TransferAdjustExaminePageModule),
    data: {
      title: '轮转调整审核'
    }
  },
  {
    path: 'TransferEducation',
    loadChildren: () => import('./pages/teach-activity/teach-activity.module').then(m => m.TeachActivityPageModule),
    data: {
      title: '入科教育',
    }
  },
  {
    path: 'CheckInSection',
    loadChildren: () => import('./pages/check-in-determine/check-in-determine.module').then(m => m.CheckInDeterminePageModule),
    data: {
      title: '入科确定'
    }
  },
  {
    path: 'ScoreQuery',
    loadChildren: () => import('./pages/score-query/score-query.module').then(m => m.ScoreQueryPageModule),
    data: {
      title: '成绩查询'
    }
  },
  {
    path: 'singlepartinquire',
    loadChildren: () => import('./pages/singlepartinquire/singlepartinquire.module').then(m => m.SinglepartinquirePageModule),
    data: {
      title: '经费查询'
    }
  },
  {
    path: 'CommonEval/:code',
    loadChildren: () => import('./pages/common-eval-page/common-eval-page.module').then(m => m.CommonEvalPageModule),
    data: {
      title: '评价'
    }
  },
  {
    path: 'CommonExam/:code',
    loadChildren: () => import('./pages/common-exam-page/common-exam-page.module').then(m => m.CommonExamPagePageModule),
    data: {
      title: '考试',
      noSwipeGesture: true,
    }
  },
  {
    path: 'teacher-apply',
    loadChildren: () => import('./pages/teacher-apply/teacher-apply.module').then(m => m.TeacherApplyPageModule),
    data: {
      title: '带教老师申请'
    }
  },
  {
    path: 'CourseDetail',
    loadChildren: () => import('./pages/course/course.module').then(m => m.CoursePageModule),
    data: {
      title: '课程详情'
    }
  },
  {
    path: 'Notice',
    loadChildren: () => import('./pages/notice/notice.module').then(m => m.NoticePageModule),
    data: {
      title: '消息通知'
    }
  },
  {
    path: 'Test',
    loadChildren: () => import('./pages/test-page/test-page.module').then(m => m.TestPagePageModule),
    data: {
      title: '测试页面'
    }
  },
  {
    path: 'statistics',
    loadChildren: () => import('./pages/statistics/statistics.module').then(m => m.StatisticsPageModule),
    data: {
      title: '数据统计'
    }
  },
  {
    path: 'studentEvaluation',
    loadChildren: () => import('./pages/student-evaluation/student-evaluation.module').then(m => m.StudentEvaluationPageModule),
    data: {
      title: '月度评价(学生)'
    }
  },
  {
    path: 'StudentIncome',
    loadChildren: () => import('./pages/student-income/student-income.module').then(m => m.StudentIncomePageModule),
    data: {
      title: '收入填报'
    }
  },
  {
    path: 'TeacherQuery',
    loadChildren: () => import('./pages/teacher-query/teacher-query.module').then(m => m.TeacherQueryPageModule),
    data: {
      title: '带教老师'
    }
  },
  {
    path: 'FileUpload',
    loadChildren: () => import('./pages/file-upload/file-upload.module').then(m => m.FileUploadPageModule),
    data: {
      title: '资料上传'
    }
  },
  {
    path: 'Assessment',
    loadChildren: () => import('./pages/assessment/assessment.module').then(m => m.AssessmentPageModule),
    data: {
      title: '考核'
    }
  },
  {
    path: 'TeacherApproval',
    loadChildren: () => import('./pages/teacher-approval/teacher-approval.module').then(m => m.TeacherApprovalPageModule),
    data: {
      title: '带教审核'
    }
  },
  {
    path: 'CheckStudentEvaluate',
    loadChildren: () => import('./pages/check-student-evaluate/check-student-evaluate.module').then(m => m.CheckStudentEvaluatePageModule),
    data: {
      title: '学生评价情况'
    }
  }, {
    path: 'CheckOut',
    loadChildren: () => import('./pages/check-out/check-out.module').then(m => m.CheckOutPageModule),
    data: {
      title: '出科申请'
    }
  },
  {
    path: 'CheckOutDetermine',
    loadChildren: () => import('./pages/check-out-determine/check-out-determine.module').then(m => m.checkOutDetermineModule),
    data: {
      title: '出科确定'  //手动出科
    }
  },
  {
    path: 'CheckOutApproval',
    loadChildren: () => import('./pages/check-out-approval/check-out-approval.module').then(m => m.checkOutApprovalModule),
    data: {
      title: '出科审批'  //郑州人民；必须出科申请才有审批！！
    }
  },
  {
    path: 'PassRate',
    loadChildren: () => import('./pages/pass-rate/pass-rate.module').then(m => m.PassRatePageModule),
    data: {
      title: '通过率'
    }
  },
  {
    path: 'MessageView',
    loadChildren: () => import('./pages/message-view/message-view.module').then(m => m.MessageViewPageModule),
    data: {
      title: '信息详情'
    }
  },
  /*针对绵阳中心医院教学的单独设置*/
  {
    path: 'AdmissionEducation',
    loadChildren: () => import('./pages/teach-activity/teach-activity.module').then(m => m.TeachActivityPageModule),
    data: {
      title: '入科教育',
    }
  },
  {
    path: 'lecture',
    loadChildren: () => import('./pages/teach-activity/teach-activity.module').then(m => m.TeachActivityPageModule),
    data: {
      title: '小讲课',
    }
  },
  {
    path: 'Rounds-One',
    loadChildren: () => import('./pages/teach-activity/teach-activity.module').then(m => m.TeachActivityPageModule),
    data: {
      title: '教学查房',
    }
  },
  {
    path: 'Discussion',
    loadChildren: () => import('./pages/teach-activity/teach-activity.module').then(m => m.TeachActivityPageModule),
    data: {
      title: '病例讨论',
    }
  },
  {
    path: 'onlinePractice',
    loadChildren: () => import('./pages/online-practice/online-practice.module').then(m => m.OnlinePracticePageModule),
    data: {
      title: '在线练习',
    }
  },
  {
    path: 'everydayEvaluate',
    loadChildren: () => import('./pages/everyday-evaluate/everyday-evaluate.module').then(m => m.EverydayEvaluatePageModule),
    data: {
      title: '每日评价'
    }
  },
  {
    path: 'superviseStatistics',
    loadChildren: () => import('./pages/supervise-statistics/supervise-statistics.module').then(m => m.SuperviseStatisticsPageModule),
    data: {
      title: '督导排名'
    }
  },
  {
    path: 'completionRate',
    loadChildren: () => import('./pages/completion-rate/completion-rate.module').then(m => m.CompletionRatePageModule),
    data: {
      title: '结业通过率'
    }
  },
  {
    path: 'examResultStatistics',
    loadChildren: () => import('./pages/exam-result-statistics/exam-result-statistics.module').then(m => m.ExamResultStatisticsPageModule),
    data: {
      title: '执医考试情况'
    }
  },
  {
    path: 'Feedback',
    loadChildren: () => import('./pages/feedback/feedback.module').then(m => m.FeedbackPageModule),
    data: {
      title: '意见问题反馈'
    }
  },
  {
    path: 'AttendanceView',
    loadChildren: () => import('./pages/attendance-view/attendance-view.module').then(m => m.AttendanceViewPageModule),
    data: {
      title: '考勤数据'
    }
  },
  {
    path: 'EvaluateView',
    loadChildren: () => import('./pages/evaluate-view/evaluate-view.module').then(m => m.EvaluateViewPageModule),
    data: {
      title: '评价查看'
    }
  },
  {
    path: 'ExamListOperate',
    loadChildren: () => import('./pages/exam-list-operate/exam-list-operate.module').then(m => m.ExamListOperatePageModule),
    data: {
      title: '考试安排列表'
    }
  },
  {
    path: 'CheckOutSummary',
    loadChildren: () => import('./pages/check-out-summary/check-out-summary.module').then(m => m.CheckOutSummaryPageModule),
    data: {
      title: '出科小结'
    }
  },
  {
    path: 'MySchedule',
    loadChildren: () => import('./pages/my-schedule/my-schedule.module').then(m => m.MySchedulePageModule),
    data: {
      title: '我的排班'
    }
  },
  /*华西医院*/
  {
    path: 'hxCheckInSection',
    loadChildren: () => import('./pages/hx/check-in-determine/check-in-determine.module').then(m => m.CheckInDeterminePageModule),
    data: {
      title: '入科确定'
    }
  },
  {
    path: 'ClassroomTest',
    loadChildren: () => import('./pages/classroom-test/classroom-test.module').then(m => m.ClassroomTestPageModule),
    data: {
      title: '随堂测试'
    }
  },
  {
    path: 'TeachEval',
    loadChildren: () => import('./pages/teacher-teach-activity-eval/teacher-teach-activity-eval.module').then(m => m.TeacherTeachActivityEvalPageModule),
    data: {
      title: '带教老师评价教学活动'
    }
  },
  {
    path: 'TutorDeclare',
    loadChildren: () => import('./pages/tutor-declare/tutor-declare.module').then(m => m.TutorDeclarePageModule),
    data: {
      title: '导师申报'
    }
  },
  {
    path: 'TutorTask',
    loadChildren: () => import('./pages/tutor-task/tutor-task.module').then(m => m.TutorTaskPageModule),
    data: {
      title: '导师布置任务'
    }
  },
  {
    path: 'TutorTaskStudent',
    loadChildren: () => import('./pages/tutor-task-student/tutor-task-student.module').then(m => m.TutorTaskStudentPageModule),
    data: {
      title: '导师任务'
    }
  },
  {
    path: 'TutorTaskApproval',
    loadChildren: () => import('./pages/tutor-task-approval/tutor-task-approval.module').then(m => m.TutorTaskApprovalPageModule),
    data: {
      title: '导师任务审批'
    }
  },
  {
    path: 'ChooseTour',
    loadChildren: () => import('./pages/choose-tour/choose-tour.module').then(m => m.ChooseTourPageModule),
    data: {
      title: '选择导师'
    }
  },
  {
    path: 'ChooseTourApproval',
    loadChildren: () => import('./pages/choose-tour-approval/choose-tour-approval.module').then(m => m.ChooseTourApprovalPageModule),
    data: {
      title: '导师选择学生'
    }
  },
  {
    path: 'TrainStudentPayFinance',
    loadChildren: () => import('./pages/train-student-pay-finance/train-student-pay-finance.module').then(m => m.TrainStudentPayFinancePageModule),
    data: {
      title: '经费查询'
    }
  },
  {
    path: 'SurveyLevel',
    loadChildren: () => import('./pages/survey-level/survey-level.module').then(m => m.SurveyLevelModule),
    data: {
      title: '胜任力评价'
    }
  },
  {
    path: 'Attendance',
    loadChildren: () => import('./pages/attendance/attendance.module').then(m => m.AttendancePageModule),
    data: {
      title: '考勤数据'
    }
  },
  {
    path: 'iframe',
    loadChildren: () => import('./pages/iframe-view/iframe-view.module').then(m => m.IframeViewPageModule),
    data: {
      title: '嵌入h5'
    }
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {preloadingStrategy: NoPreloading, useHash: true}),
  ],
  exports: [RouterModule],

})
export class AppRoutingModule {
}
