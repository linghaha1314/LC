package com.kbds.mrtcloud.starter;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import com.getcapacitor.BridgeActivity;
import com.getcapacitor.util.UpdateHelper;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import cn.jpush.android.api.JPushInterface;

public class MainActivity extends BridgeActivity {

  @RequiresApi(api = Build.VERSION_CODES.O)
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    try {
      UpdateHelper.UpdateResource(this, null);
      String path = getFilesDir() + "/data.json";
      File f = new File(path);
      if (!f.exists()) {
        UpdateHelper.checkUpdate(this, () -> {
          restartAPP();
          return null;
        }, false);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    UpdateHelper.UpdateApp(this);
    JPushInterface.setDebugMode(true);
    JPushInterface.init(this);
  }


  public void restartAPP() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
      finishAffinity();
      Intent intent = new Intent(getApplicationContext(), MainActivity.class);
      startActivity(intent);
    } else {
      ActivityCompat.finishAffinity(MainActivity.this);
      Intent intent = new Intent(getApplicationContext(), MainActivity.class);
      startActivity(intent);
    }
  }
}
