package com.kbds.mrtcloud.starter.jpush;

import cn.jpush.android.service.JPushMessageReceiver;

public class MyReceiver extends JPushMessageReceiver {
}
