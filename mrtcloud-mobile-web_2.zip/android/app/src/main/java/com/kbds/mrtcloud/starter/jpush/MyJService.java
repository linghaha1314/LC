package com.kbds.mrtcloud.starter.jpush;

import cn.jpush.android.service.JCommonService;

public class MyJService extends JCommonService {
}
