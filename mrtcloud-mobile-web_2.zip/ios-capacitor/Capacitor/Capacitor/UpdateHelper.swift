//
//  UpdateHelper.swift
//  App
//
//  Created by mac on 2021/11/20.
//
import Foundation
import UIKit
import Zip

class UpdateHelper {
    
    func getJason(url: String, vc: UIViewController, completionHandler: @escaping (NSArray?, Error?) -> Void) -> URLSessionDataTask {
        var finalData: NSArray!
        URLCache.shared.removeAllCachedResponses()
        let session = Foundation.URLSession(configuration: .default)
        var UrlRequest = URLRequest(url: URL(string: url)!)
        // 创建一个网络任务
        let task = session.dataTask(with: UrlRequest) { (data, response, error) -> Void in
            if error != nil {
                completionHandler(nil, error)
                return
            } else {
                if let urlContent = data {
                    do {
                        finalData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                        //                        let alert = UIAlertController(title: "Information", message: "sub title", preferredStyle: .alert)
                        //                        finalData.forEach { (f) in
                        //                            let data = f as! NSDictionary
                        //                            print(data["name"] as! String)
                        //                            let item = UIAlertAction(title: data["name"] as! String, style: .default) { (UIAlertAction) in
                        //                                print("you selected ok")
                        //                            }
                        //                            alert.addAction(item)
                        //                        }
                        //                        vc.present(alert, animated: true, completion: nil)
                        completionHandler(finalData, nil)
                        return
                    } catch {
                        print("EMPTY")
                    }
                }
            }
        }
        task.resume()
        return task
    }
    
    static func loadFileSync(url: URL, completion: @escaping (String?, Error?) -> Void)
    {
        let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        let destinationUrl = documentsUrl.appendingPathComponent(url.lastPathComponent)
        if FileManager().fileExists(atPath: destinationUrl.path)
        {
            print("File already exists [\(destinationUrl.path)]")
            completion(destinationUrl.path, nil)
        }
        else if let dataFromURL = NSData(contentsOf: url)
        {
            if dataFromURL.write(to: destinationUrl, atomically: true)
            {
                print("file saved [\(destinationUrl.path)]")
                completion(destinationUrl.path, nil)
            }
            else
            {
                print("error saving file")
                let error = NSError(domain:"Error saving file", code:1001, userInfo:nil)
                completion(destinationUrl.path, error)
            }
        }
        else
        {
            let error = NSError(domain:"Error downloading file", code:1002, userInfo:nil)
            completion(destinationUrl.path, error)
        }
    }
    
    static var dataPath: URL = {
        let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return documentsUrl
    }()
    
    
    static func loadFileAsync(url: URL, config: NSDictionary, force: Bool, completion: @escaping (String?, Error?) -> Void)
    {
        let name = config["name"] as! String
        if(!force && fileExists(name: name)) {
            let fileUrlPath = dataPath.appendingPathComponent("\(name)/data.json")
            do {
                let data = try Data(contentsOf: fileUrlPath)
                createFile(name: "data.json", content: data)
            } catch let error {
                print("读取本地数据出现错误!",error)
            }
            completion(getAssetsFolder(), nil)
            return
        }
        URLCache.shared.removeAllCachedResponses()
        let documentsUrl =  FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationUrl = documentsUrl.appendingPathComponent("assets.zip")
        let session = Foundation.URLSession(configuration: URLSessionConfiguration.default, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        let task = session.dataTask(with: request, completionHandler:
                                        {
            data, response, error in
            if error == nil
            {
                if let response = response as? HTTPURLResponse
                {
                    if response.statusCode == 200
                    {
                        if let data = data
                        {
                            if let _ = try? data.write(to: destinationUrl, options: Data.WritingOptions.atomic)
                            {
                                compileSource(config:config){ (path, error) in
                                    completion(destinationUrl.path, error)
                                }
                            }
                            else
                            {
                                compileSource(config:config){ (path, error) in
                                    completion(destinationUrl.path, error)
                                }
                            }
                        }
                        else
                        {
                            compileSource(config:config){ (path, error) in
                                completion(destinationUrl.path, error)
                            }
                        }
                    }
                }
            }
            else
            {
                compileSource(config:config){ (path, error) in
                    completion(destinationUrl.path, error)
                }
            }
        })
        task.resume()
    }
    
    static func compileSource(config: NSDictionary, completion: @escaping (String?, Error?) -> Void) {
        do {
            let folder = config["name"] as! String
            let filePath = dataPath.appendingPathComponent("assets.zip")
            removeFilePath(path: dataPath.appendingPathComponent(folder).path)
            try Zip.unzipFile(filePath, destination: dataPath.appendingPathComponent(folder), overwrite: true, password: nil, progress:  { (progress) -> () in
                if(progress == 1.0){
                    removeFilePath(path: filePath.path)
                    let data = jsonToData(jsonDic: config)!
                    createFile(name: "data.json", content: data)
                    createFile(name: (config["name"] as! String) + "/data.json", content: data)
                    completion(filePath.path,nil)
                }
            })
            
        }
        catch {
            print("Something went wrong")
        }
    }
    
    static func jsonToData(jsonDic: NSDictionary) -> Data? {
        if (!JSONSerialization.isValidJSONObject(jsonDic)) {
            print("is not a valid json object")
            return nil
            
        }
        let data = try? JSONSerialization.data(withJSONObject: jsonDic, options: [])
        let str = String(data:data!, encoding: String.Encoding.utf8)
        print("Json Str:\(str!)")
        return data
    }
    
    static func removeFilePath(path:String){
        let  fileManager = FileManager.default
        do{
            try fileManager.removeItem(atPath: path)
        } catch{
            print("creat false")
        }
    }
    
    static func createFile(name:String, content: Data){
        let manager = FileManager.default
        let fileUrlPath = dataPath.appendingPathComponent(name)
        let exist = manager.fileExists(atPath: fileUrlPath.path)
        if !exist {
            manager.createFile(atPath:fileUrlPath.path, contents: content, attributes: nil)
        } else {
            do{
                try manager.removeItem(atPath: fileUrlPath.path)
                manager.createFile(atPath:fileUrlPath.path, contents: content, attributes: nil)
            } catch{
                print("creat false")
            }
        }
    }
    
    static func fileExists(name:String) -> Bool {
        let manager = FileManager.default
        let fileUrlPath = dataPath.appendingPathComponent(name)
        let exist = manager.fileExists(atPath: fileUrlPath.path)
        return exist
    }
    
    static func getJSONData(name: String) -> NSDictionary? {
        let fileUrlPath = dataPath.appendingPathComponent(name)
        do {
            /*
             * try 和 try! 的区别
             * try 发生异常会跳到catch代码中
             * try! 发生异常程序会直接crash
             */
            let data = try Data(contentsOf: fileUrlPath)
            let jsonData:Any = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers)
            let json = jsonData as! NSDictionary
            return json
        } catch let error {
            print("读取本地数据出现错误!",error)
            return nil
        }
    }
    
    static func getConfig() -> NSDictionary? {
        return getJSONData(name: "data.json")
    }
    
    static func getAssetsFolder() -> String? {
        let config = getConfig()
        if config == nil {
            return nil
        }
        return dataPath.appendingPathComponent(config!["name"] as! String).path
    }
}
