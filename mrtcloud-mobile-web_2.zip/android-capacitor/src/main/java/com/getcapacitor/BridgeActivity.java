package com.getcapacitor;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.donkingliang.imageselector.utils.ImageSelector;
import com.getcapacitor.android.R;
import com.getcapacitor.util.UpdateHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.jpush.android.api.JPushInterface;

public class BridgeActivity extends AppCompatActivity {

  protected Bridge bridge;
  protected boolean keepRunning = true;
  private CapConfig config;

  private int activityDepth = 0;
  private int REQUEST_CODE = 9;
  private ArrayList<String> images;
  private List<Class<? extends Plugin>> initialPlugins = new ArrayList<>();
  private final Bridge.Builder bridgeBuilder = new Bridge.Builder(this);

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    bridgeBuilder.setInstanceState(savedInstanceState);
  }

  /**
   * Initializes the Capacitor Bridge with the Activity.
   *
   * @param plugins A list of plugins to initialize with Capacitor
   * @deprecated It is preferred not to call this method. If it is not called, the bridge is
   * initialized automatically. If you need to add additional plugins during initialization,
   * use {@link #registerPlugin(Class)} or {@link #registerPlugins(List)}.
   */
  @RequiresApi(api = Build.VERSION_CODES.O)
  @Deprecated
  protected void init(Bundle savedInstanceState, List<Class<? extends Plugin>> plugins) {
    this.init(savedInstanceState, plugins, null);
  }

  /**
   * Initializes the Capacitor Bridge with the Activity.
   *
   * @param plugins A list of plugins to initialize with Capacitor
   * @param config  An instance of a Capacitor Configuration to use. If null, will load from file
   * @deprecated It is preferred not to call this method. If it is not called, the bridge is
   * initialized automatically. If you need to add additional plugins during initialization,
   * use {@link #registerPlugin(Class)} or {@link #registerPlugins(List)}.
   */
  @RequiresApi(api = Build.VERSION_CODES.O)
  @Deprecated
  protected void init(Bundle savedInstanceState, List<Class<? extends Plugin>> plugins, CapConfig config) {
    this.initialPlugins = plugins;
    this.config = config;

    this.load();
  }

  /**
   * @deprecated This method should not be called manually.
   */
  @RequiresApi(api = Build.VERSION_CODES.O)
  @Deprecated
  protected void load(Bundle savedInstanceState) {
    this.load();
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  private void load() {
    getApplication().setTheme(getResources().getIdentifier("AppTheme_NoActionBar", "style", getPackageName()));
    setTheme(getResources().getIdentifier("AppTheme_NoActionBar", "style", getPackageName()));
    setTheme(R.style.AppTheme_NoActionBar);
    setContentView(R.layout.bridge_layout_main);

    Logger.debug("Starting BridgeActivity");

    bridge = bridgeBuilder.addPlugins(initialPlugins).setConfig(config).create();

    this.keepRunning = bridge.shouldKeepRunning();
    this.onNewIntent(getIntent());
  }

  public void registerPlugin(Class<? extends Plugin> plugin) {
    bridgeBuilder.addPlugin(plugin);
  }

  public void registerPlugins(List<Class<? extends Plugin>> plugins) {
    bridgeBuilder.addPlugins(plugins);
  }

  public Bridge getBridge() {
    return this.bridge;
  }

  @Override
  public void onSaveInstanceState(Bundle outState) {
    super.onSaveInstanceState(outState);
    bridge.saveInstanceState(outState);
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  @Override
  public void onStart() {
    super.onStart();

    // Preferred behavior: init() was not called, so we construct the bridge with auto-loaded plugins.
    if (bridge == null) {
      PluginManager loader = new PluginManager(getBaseContext());

      try {
        bridgeBuilder.addPlugins(loader.loadPluginClasses());
      } catch (Exception ex) {
        Logger.error("Error loading plugins.", ex);
      }

      this.load();
    }

    activityDepth++;
    this.bridge.onStart();
    Logger.debug("App started");
    new Handler(Looper.getMainLooper()).post(() -> {
      System.out.println("检查更新");
      String path = getFilesDir() + "/data.json";
      File f = new File(path);
      if (f.exists()) {
        try {
          UpdateHelper.checkUpdate(this, () -> {
            restartAPP();
            return null;
          }, false);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
    BridgeActivity that = this;
    this.bridge.getWebView().addJavascriptInterface(new Object() {
      @JavascriptInterface
      public void changeApp() {
        UpdateHelper.checkUpdate(that, () -> {
          restartAPP();
          return null;
        }, true);
      }

      @JavascriptInterface
      public String getRegistrationID() {
        return JPushInterface.getRegistrationID(that);
      }

      @JavascriptInterface
      public String getAppInfo() {
        return UpdateHelper.getAppInfo(getApplicationContext());
      }

      @JavascriptInterface
      public String pickerImages() {
        images = null;
        ImageSelector.builder()
          .useCamera(true) // 设置是否使用拍照
          .setSingle(false)  //设置是否单选
          .setMaxSelectCount(0) // 图片的最大选择数量，小于等于0时，不限数量。
          .canPreview(true) //是否可以预览图片，默认为true
          .start(that, REQUEST_CODE);
        while (images == null) {
          try {
            Thread.sleep(100);
          } catch (InterruptedException e) {
            throw new RuntimeException(e);
          }
        }
        return String.join(",",images);
      }
    }, "system");
  }


  public void restartAPP() {
    finishAffinity();
    Intent intent = new Intent(getApplicationContext(), BridgeActivity.class);
    startActivity(intent);
  }

  @Override
  public void onRestart() {
    super.onRestart();
    this.bridge.onRestart();
    Logger.debug("App restarted");
  }

  @Override
  public void onResume() {
    super.onResume();
    bridge.getApp().fireStatusChange(true);
    this.bridge.onResume();
    Logger.debug("App resumed");
  }

  @Override
  public void onPause() {
    super.onPause();
    this.bridge.onPause();
    Logger.debug("App paused");
  }

  @Override
  public void onStop() {
    super.onStop();

    activityDepth = Math.max(0, activityDepth - 1);
    if (activityDepth == 0) {
      bridge.getApp().fireStatusChange(false);
    }

    this.bridge.onStop();
    Logger.debug("App stopped");
  }

  @Override
  public void onDestroy() {
    super.onDestroy();
    this.bridge.onDestroy();
    Logger.debug("App destroyed");
  }

  @Override
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.bridge.onDetachedFromWindow();
  }

  /**
   * Handles permission request results.
   * <p>
   * Capacitor is backwards compatible such that plugins using legacy permission request codes
   * may coexist with plugins using the AndroidX Activity v1.2 permission callback flow introduced
   * in Capacitor 3.0.
   * <p>
   * In this method, plugins are checked first for ownership of the legacy permission request code.
   * If the {@link Bridge#onRequestPermissionsResult(int, String[], int[])} method indicates it has
   * handled the permission, then the permission callback will be considered complete. Otherwise,
   * the permission will be handled using the AndroidX Activity flow.
   *
   * @param requestCode  the request code associated with the permission request
   * @param permissions  the Android permission strings requested
   * @param grantResults the status result of the permission request
   */
  @Override
  public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    if (this.bridge == null) {
      return;
    }

    if (!bridge.onRequestPermissionsResult(requestCode, permissions, grantResults)) {
      super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
  }

  /**
   * Handles activity results.
   * <p>
   * Capacitor is backwards compatible such that plugins using legacy activity result codes
   * may coexist with plugins using the AndroidX Activity v1.2 activity callback flow introduced
   * in Capacitor 3.0.
   * <p>
   * In this method, plugins are checked first for ownership of the legacy request code. If the
   * {@link Bridge#onActivityResult(int, int, Intent)} method indicates it has handled the activity
   * result, then the callback will be considered complete. Otherwise, the result will be handled
   * using the AndroidX Activiy flow.
   *
   * @param requestCode the request code associated with the activity result
   * @param resultCode  the result code
   * @param data        any data included with the activity result
   */
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == REQUEST_CODE) {
      if (data != null) {
        images = data.getStringArrayListExtra(ImageSelector.SELECT_RESULT);
      } else {
        images = new ArrayList<>();
      }
    }

    if (this.bridge == null) {
      return;
    }


    if (!bridge.onActivityResult(requestCode, resultCode, data)) {
      super.onActivityResult(requestCode, resultCode, data);
    }
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);

    if (this.bridge == null || intent == null) {
      return;
    }

    this.bridge.onNewIntent(intent);
  }

  @Override
  public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);

    if (this.bridge == null) {
      return;
    }

    this.bridge.onConfigurationChanged(newConfig);
  }

  @Override
  public boolean onKeyDown(int keyCode, KeyEvent event) {
    String u = this.bridge.getWebView().getUrl();
    if (keyCode == 4 && (u.contains("/#/login"))) {
      finish();
    }
    return super.onKeyDown(keyCode, event);
  }
}
