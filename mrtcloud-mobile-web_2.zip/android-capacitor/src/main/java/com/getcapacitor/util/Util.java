package com.getcapacitor.util;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class Util {


  /**
   * 从assets目录下拷贝整个文件夹，不管是文件夹还是文件都能拷贝
   *
   * @param context           上下文
   * @param rootDirFullPath   文件目录，要拷贝的目录如assets目录下有一个tessdata文件夹：
   * @param targetDirFullPath 目标文件夹位置如：/Download/tessdata
   */
  public static void copyFolderFromAssets(Context context, String rootDirFullPath, String targetDirFullPath) {
    Log.d("Tag", "copyFolderFromAssets " + "rootDirFullPath-" + rootDirFullPath + " targetDirFullPath-" + targetDirFullPath);
    try {
      String[] listFiles = context.getAssets().list(rootDirFullPath);// 遍历该目录下的文件和文件夹
      for (String string : listFiles) {// 判断目录是文件还是文件夹，这里只好用.做区分了
        Log.d("Tag", "name-" + rootDirFullPath + "/" + string);
        if (isFileByName(string)) {// 文件
          copyFileFromAssets(context, rootDirFullPath + "/" + string, targetDirFullPath + "/" + string);
        } else {// 文件夹
          String childRootDirFullPath = rootDirFullPath + "/" + string;
          String childTargetDirFullPath = targetDirFullPath + "/" + string;
          new File(childTargetDirFullPath).mkdirs();
          copyFolderFromAssets(context, childRootDirFullPath, childTargetDirFullPath);
        }
      }
    } catch (IOException e) {
      Log.d("Tag", "copyFolderFromAssets " + "IOException-" + e.getMessage());
      Log.d("Tag", "copyFolderFromAssets " + "IOException-" + e.getLocalizedMessage());
      e.printStackTrace();
    }
  }

  private static boolean isFileByName(String string) {
    if (string.contains(".")) {
      return true;
    }
    return false;
  }

  /**
   * 从assets目录下拷贝文件
   *
   * @param context            上下文
   * @param assetsFilePath     文件的路径名如：SBClock/0001cuteowl/cuteowl_dot.png
   * @param targetFileFullPath 目标文件路径如：/sdcard/SBClock/0001cuteowl/cuteowl_dot.png
   */
  public static void copyFileFromAssets(Context context, String assetsFilePath, String targetFileFullPath) {
    Log.d("Tag", "copyFileFromAssets ");
    InputStream assestsFileImputStream;
    try {
      assestsFileImputStream = context.getAssets().open(assetsFilePath);
      copyFile(assestsFileImputStream, targetFileFullPath);
    } catch (IOException e) {
      Log.d("Tag", "copyFileFromAssets " + "IOException-" + e.getMessage());
      e.printStackTrace();
    }
  }

  public static void copyFile(InputStream in, String targetPath) {
    try {
      FileOutputStream fos = new FileOutputStream(targetPath);
      byte[] buffer = new byte[1024];
      int byteCount = 0;
      while ((byteCount = in.read(buffer)) != -1) {// 循环从输入流读取
        // buffer字节
        fos.write(buffer, 0, byteCount);// 将读取的输入流写入到输出流
      }
      fos.flush();// 刷新缓冲区
      in.close();
      fos.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  public static void unzipFolder(String source, String target) throws IOException {

    try (ZipInputStream zis = new ZipInputStream(new FileInputStream(source))) {

      // list files in zip
      ZipEntry zipEntry = zis.getNextEntry();

      while (zipEntry != null) {

        boolean isDirectory = false;
        // example 1.1
        // some zip stored files and folders separately
        // e.g data/
        //     data/folder/
        //     data/folder/file.txt
        if (zipEntry.getName().endsWith(File.separator)) {
          isDirectory = true;
        }

        Path newPath = zipSlipProtect(zipEntry, Paths.get(target));

        if (isDirectory && !newPath.toFile().exists()) {
          Files.createDirectories(newPath);
        } else {

          // example 1.2
          // some zip stored file path only, need create parent directories
          // e.g data/folder/file.txt
          if (newPath.getParent() != null) {
            if (Files.notExists(newPath.getParent())) {
              Files.createDirectories(newPath.getParent());
            }
          }

          // copy files, nio
          Files.copy(zis, newPath, StandardCopyOption.REPLACE_EXISTING);

          // copy files, classic
//          try (FileOutputStream fos = new FileOutputStream(newPath.toFile())) {
//            byte[] buffer = new byte[1024];
//            int len;
//            while ((len = zis.read(buffer)) > 0) {
//              fos.write(buffer, 0, len);
//            }
//          }
        }

        zipEntry = zis.getNextEntry();

      }
      zis.closeEntry();

    }

  }

  // protect zip slip attack
  @RequiresApi(api = Build.VERSION_CODES.O)
  public static Path zipSlipProtect(ZipEntry zipEntry, Path targetDir)
    throws IOException {

    // test zip slip vulnerability
    // Path targetDirResolved = targetDir.resolve("../../" + zipEntry.getName());

    Path targetDirResolved = targetDir.resolve(zipEntry.getName());

    // make sure normalized file still has targetDir as its prefix
    // else throws exception
    Path normalizePath = targetDirResolved.normalize();
    if (!normalizePath.startsWith(targetDir)) {
      throw new IOException("Bad zip entry: " + zipEntry.getName());
    }

    return normalizePath;
  }

  private static Boolean flag = false;
  private static File file;

  public static   boolean DeleteFolder(String sPath) {
    flag = false;
    file = new File(sPath);
    // 判断目录或文件是否存在
    if (!file.exists()) {  // 不存在返回 false
      return flag;
    } else {
      // 判断是否为文件
      if (file.isFile()) {  // 为文件时调用删除文件方法
        return deleteFile(sPath);
      } else {  // 为目录时调用删除目录方法
        return deleteDirectory(sPath);
      }
    }
  }

  private static boolean deleteFile(String sPath) {
    flag = false;
    file = new File(sPath);
    // 路径为文件且不为空则进行删除
    if (file.isFile() && file.exists()) {
      file.delete();
      flag = true;
    }
    return flag;
  }

  private static boolean deleteDirectory(String sPath) {
    //如果sPath不以文件分隔符结尾，自动添加文件分隔符
    if (!sPath.endsWith(File.separator)) {
      sPath = sPath + File.separator;
    }
    File dirFile = new File(sPath);
    //如果dir对应的文件不存在，或者不是一个目录，则退出
    if (!dirFile.exists() || !dirFile.isDirectory()) {
      return false;
    }
    flag = true;
    //删除文件夹下的所有文件(包括子目录)
    File[] files = dirFile.listFiles();
    for (int i = 0; i < files.length; i++) {
      //删除子文件
      if (files[i].isFile()) {
        flag = deleteFile(files[i].getAbsolutePath());
        if (!flag) break;
      } //删除子目录
      else {
        flag = deleteDirectory(files[i].getAbsolutePath());
        if (!flag) break;
      }
    }
    if (!flag) return false;
    //删除当前目录
    if (dirFile.delete()) {
      return true;
    } else {
      return false;
    }
  }
}
