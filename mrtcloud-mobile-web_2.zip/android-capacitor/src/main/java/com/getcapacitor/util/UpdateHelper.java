package com.getcapacitor.util;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class UpdateHelper {

  static ProgressDialog progressDialog;

  static JSONObject jsonObject;

  public static String getAppInfo(Context context) {
    try {
      jsonObject.put("appVersion", getAppVersionCode(context));
      jsonObject.put("device", "android");
    } catch (JSONException e) {
      Log.e("put app version", e.getMessage());
    }
    return jsonObject.toString();
  }

  public static String getAppVersionCode(Context context) {
    String appVersionCode = "0";
    try {
      PackageInfo packageInfo = context.getApplicationContext()
        .getPackageManager()
        .getPackageInfo(context.getPackageName(), 0);
      appVersionCode = packageInfo.versionName;
    } catch (PackageManager.NameNotFoundException e) {
      Log.e("get app version", e.getMessage());
    }
    return appVersionCode;
  }

  public static JSONObject getNowConfig(Context context) {
    if (jsonObject == null) {
      String p = context.getFilesDir() + "/data.json";
      File f = new File(p);
      if (f.exists()) {
        jsonObject = parseJSON(p);
      }
    }
    return jsonObject;
  }

  public static String getAssetsContent(Context context, String path) {
    if (jsonObject == null) {
      String p = context.getFilesDir() + "/data.json";
      File f = new File(p);
      if (f.exists()) {
        jsonObject = parseJSON(p);
      }
    }
    File file;
    byte b[] = new byte[0];
    try {
      file = new File(context.getFilesDir() + "/" + jsonObject.getString("name") + "/" + path);
      InputStream in = new FileInputStream(file);
      int fileLength = (int) file.length();
      b = new byte[fileLength];
      in.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return new String(b);
  }

  public static InputStream getInputStreamAssets(Context context, String path) throws Exception {
    if (jsonObject == null) {
      String p = context.getFilesDir() + "/data.json";
      File f = new File(p);
      if (f.exists()) {
        jsonObject = parseJSON(p);
      }
    }
    System.out.println(context.getFilesDir() + "/" + jsonObject.getString("name") + "/" + path);
    return new FileInputStream(context.getFilesDir() + "/" + jsonObject.getString("name") + "/" + path);
  }

  public static InputStreamReader getInputStreamReader(Context context, String path) throws Exception {
    return new InputStreamReader(getInputStreamAssets(context, path));
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  public static void checkUpdate(Context context, Callable<Void> func, Boolean force) {
    RequestQueue queue = Volley.newRequestQueue(context);
    StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://gitlab.kbmrt.cn/root/config-data/raw/master/app-config.json",
      response -> {
        try {
          handleUpdate(context, response, func, force, false);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }, error -> error.printStackTrace());
    queue.getCache().clear();
    queue.add(stringRequest);
  }

  public static void UpdateApp(Context context) {
    new Thread(() -> {
      RequestQueue queue = Volley.newRequestQueue(context);
      StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://gitlab.kbmrt.cn/root/config-data/raw/master/mrtcloud.json",
        response -> {
          try {
            JSONObject config = new JSONObject(response);
            String versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            System.out.println(config.toString());
            System.out.println(versionName);
            if (!versionName.equals(config.getString("version"))) {
              Handler handler = new Handler(Looper.getMainLooper());
              handler.post(() -> new AlertDialog.Builder(context)
                .setTitle("提示")
                .setMessage("检测到更新,是否前往下载?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                  Uri uri = null;
                  try {
                    uri = Uri.parse(config.getString("download"));
                  } catch (JSONException e) {
                    e.printStackTrace();
                  }
                  Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                  context.startActivity(intent);
                })
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show());
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        }, error -> {
      });
      queue.getCache().clear();
      queue.add(stringRequest);
    }).start();
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  public static void UpdateResource(Context context, JSONObject config) {
    jsonObject = null;
    try {
      if (config == null) {
        String path = context.getFilesDir() + "/data.json";
        File f = new File(path);
        if (f.exists()) {
          config = parseJSON(path);
        } else {
          return;
        }
      }
      File file = new File(context.getFilesDir().getPath() + "/assets.zip");
      if (!file.exists()) {
        return;
      }
      byte[] data = config.toString().getBytes();
      //下载完成进行相关逻辑操作
      String asset = context.getFilesDir().getPath() + "/" + config.getString("name");
      Util.DeleteFolder(asset);
      Util.unzipFolder(context.getFilesDir().getPath() + "/assets.zip", asset);
      Util.DeleteFolder(context.getFilesDir() + "/data.json");
      Files.write(Paths.get(asset + "/data.json"), data);
      Files.write(Paths.get(context.getFilesDir() + "/data.json"), data);
      Util.DeleteFolder(context.getFilesDir().getPath() + "/assets.zip");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  private static void handleUpdate(Context context, String response, Callable<Void> func, Boolean force, Boolean allFlag) throws Exception {
    JSONArray config = new JSONArray(response);
    String path = context.getFilesDir() + "/data.json";
    File f = new File(path);
    if (!force && f.exists()) {
      JSONObject c = parseJSON(path);
      for (int i = 0; i < config.length(); i++) {
        try {
          System.out.println(config.get(i).toString());
          if (c.getString("name").equals(config.getJSONObject(i).getString("name")) && !c.getString("version").equals(config.getJSONObject(i).getString("version"))) {
            System.out.println("开始更新!");
            downloadFile(context, config.getJSONObject(i), func);
          }
        } catch (Exception e) {
          System.out.println("判断失败!");
          e.printStackTrace();
        }
      }
    } else {
      // setup the alert builder
      AlertDialog.Builder builder = new AlertDialog.Builder(context);
      builder.setTitle("请选择您的医院");
      // add a list
      List<JSONObject> rows = new ArrayList();
      List<JSONObject> exitsRows = new ArrayList();
      List<JSONObject> datas;
      List<String> animals = new ArrayList<>();
      for (int i = 0; i < config.length(); i++) {
        if (config.getJSONObject(i).has("version")) {
          rows.add(config.getJSONObject(i));
          String name = config.getJSONObject(i).getString("name");
          String p = context.getFilesDir() + "/" + name;
          File file = new File(p);
          if (file.exists()) {
            exitsRows.add(config.getJSONObject(i));
          }
        }
      }
      if (exitsRows.size() > 0 && !allFlag) {
        datas = exitsRows;
        if (exitsRows.size() != rows.size()) {
          JSONObject all = new JSONObject();
          all.put("type", "all");
          datas.add(all);
        }
      } else {
        datas = rows;
      }
      for (int i = 0; i < datas.size(); i++) {
        if (!datas.get(i).has("type")) {
          animals.add(datas.get(i).getString("name"));
        } else {
          animals.add("查看全部");
        }
      }
      builder.setItems(animals.toArray(new String[animals.size()]), (dialog, which) -> {
        try {
          jsonObject = null;
          JSONObject c = datas.get(which);
          if (!c.has("type")) {
            String newPath = context.getFilesDir() + "/" + c.getString("name");
            File assetsFile = new File(context.getFilesDir() + "/" + c.getString("name"));
            if (assetsFile.exists()) {
              Util.DeleteFolder(context.getFilesDir() + "/data.json");
              Files.copy(Paths.get(newPath + "/data.json"), Paths.get(context.getFilesDir() + "/data.json"));
              func.call();
            } else {
              downloadFile(context, c, func);
            }
          } else {
            handleUpdate(context, response, func, force, true);
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
      });
      builder.setCancelable(force);
      // create and show the alert dialog
      AlertDialog dialog = builder.create();
      dialog.show();
    }
  }

  @RequiresApi(api = Build.VERSION_CODES.O)
  private static void downloadFile(Context context, JSONObject config, Callable<Void> func) throws Exception {
    progressDialog = new ProgressDialog(context);
    progressDialog.setTitle("下载中,请勿退出");
    progressDialog.setMessage("正在下载其需要的资源文件...");
    progressDialog.setProgressStyle(progressDialog.STYLE_HORIZONTAL);
    progressDialog.setCancelable(false);
    progressDialog.setMax(100);
    progressDialog.setProgress(0);
    progressDialog.show();
    DownloadUtil.get().download(config.getString("android"), context.getFilesDir().getPath(), "assets.zip", new DownloadUtil.OnDownloadListener() {
      @Override
      public void onDownloadSuccess(File file) throws Exception {
        progressDialog.dismiss();
        UpdateResource(context, config);
        func.call();
      }

      @Override
      public void onDownloading(int progress) {
        progressDialog.setProgress(progress);
      }

      @Override
      public void onDownloadFailed(Exception e) {
        //下载异常进行相关提示操作
        e.printStackTrace();
      }
    });
  }


  public static JSONObject parseJSON(String path) {
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path)))) {
      StringBuilder builder = new StringBuilder();
      String line;
      while ((line = reader.readLine()) != null) {
        builder.append(line);
      }
      String jsonString = builder.toString();
      return new JSONObject(jsonString);
    } catch (IOException e) {
      throw new RuntimeException("Could not json");
    } catch (JSONException e) {
      throw new RuntimeException("Could not parse json file as JSON");
    }
  }

}
