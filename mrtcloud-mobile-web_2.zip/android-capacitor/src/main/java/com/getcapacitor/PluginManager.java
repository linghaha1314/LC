package com.getcapacitor;

import android.content.Context;

import com.getcapacitor.util.UpdateHelper;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PluginManager {

  private final Context context;

  public PluginManager(Context context) {
    this.context = context;
  }

  public List<Class<? extends Plugin>> loadPluginClasses() throws Exception {
    JSONArray pluginsJSON = parsePluginsJSON();
    ArrayList<Class<? extends Plugin>> pluginList = new ArrayList<>();

    try {
      for (int i = 0, size = pluginsJSON.length(); i < size; i++) {
        JSONObject pluginJSON = pluginsJSON.getJSONObject(i);
        String classPath = pluginJSON.getString("classpath");
        Class<?> c = Class.forName(classPath);
        pluginList.add(c.asSubclass(Plugin.class));
      }
    } catch (JSONException e) {
      throw new PluginLoadException("Could not parse capacitor.plugins.json as JSON");
    } catch (ClassNotFoundException e) {
      throw new PluginLoadException("Could not find class by class path: " + e.getMessage());
    }

    return pluginList;
  }

  private JSONArray parsePluginsJSON() throws Exception {
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(context.getAssets().open("capacitor.plugins.json")))) {
      StringBuilder builder = new StringBuilder();
      String line;
      while ((line = reader.readLine()) != null) {
        builder.append(line);
      }
      String jsonString = builder.toString();
      return new JSONArray(jsonString);
    } catch (IOException e) {
      throw new PluginLoadException("Could not load capacitor.plugins.json");
    } catch (JSONException e) {
      throw new PluginLoadException("Could not parse capacitor.plugins.json as JSON");
    }
  }
}
