module.exports = {

    module: {
        rules: [
            {
                test: /\.less$/,
                loader: "style-loader!css-loader!less-loader"
            }
        ]
    },
    externals: {
        'BMap': 'BMap'
    }
}