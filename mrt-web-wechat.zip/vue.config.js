module.exports = {
    devServer: {
        proxy: {
            '/api': {
                // 此处的写法，目的是为了 将 /api 替换成 https://www.baidu.com/
                target: 'https://localhost:64002',
                // 允许跨域
                changeOrigin: true,
                ws: true,
                pathRewrite: {
                    '^/api': ''
                }
            }
        },
        disableHostCheck: true
    },
    // 打包静态文件
    publicPath:  process.env.NODE_ENV === 'production'
        ? '/assets/'
        : '/',
    productionSourceMap:false
}
