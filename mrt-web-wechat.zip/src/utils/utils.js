export function getNowFormatDate(date) {
    let seperator1 = "-";
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    let strDate = date.getDate(),
        hh = date.getHours(),
        mm = date.getMinutes();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    if (hh >= 0 && hh <= 9) {
        hh = "0" + hh;
    }
    if (mm >= 0 && mm <= 9) {
        mm = "0" + mm;
    }
    return year + seperator1 + month + seperator1 + strDate + ' ' + hh + ':' + mm;
}

export function getNowTime() {
    let date = new Date();
    let month = date.getMonth() + 1;
    let day = date.getDate();
    let hours = date.getHours();
    let min = date.getMinutes();
    let sec = date.getSeconds();

    let code = date.getFullYear() + '-' + toForMatter(month) + '-' +
        toForMatter(day) + ' ' + toForMatter(hours) + ':' + toForMatter(min)
        + ':' + toForMatter(sec);

    function toForMatter(num) {
        if (num < 10) {
            num = "0" + num;
        }
        return num + "";
    }

    return code;
}
