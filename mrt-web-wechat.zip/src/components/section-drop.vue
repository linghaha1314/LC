<template>
  <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="value" @change="dropFn" :options="option3"/>
</template>

<script>
import { urlForPost } from '../http/apiMap';
export default {
  name: "batch-drop",
  props:{
    val:{
      default:''
    }
  },
  data(){
    return{
      value: this.val,
      option3:[],
      role: localStorage.getItem('roleCode')
    }
  },
  methods:{
    dropFn(){
      this.$emit('input',this.value)
      this.$emit('change',this.value)
    },
    getYear() {
      urlForPost('/section/getListByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option3 = arr
      }).catch(()=>{})
    },
  },
  mounted() {
    this.getYear()
  }
}
</script>

<style scoped>

</style>
