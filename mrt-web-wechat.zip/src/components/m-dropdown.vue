<template>
  <div>
    <van-dropdown-menu active-color="#17d4b5">
      <van-dropdown-item v-for="item in data" :key="item.title" :title="item.title" v-model="listParams[item.prop]" @change="getList"
                         :options="item.option"/>
<!--      <van-dropdown-item title="批次" v-model="listParams.sectionId" @change="getList" :options="option4"/>-->
    </van-dropdown-menu>
  </div>
</template>
<script>
import { urlForPost } from '../http/apiMap';
export default {
  name: 'dropdownComponent',
  props: {
    data: [], // 数据结构
    listProp: { // 传入的属性名字
      type: Array,
      default: () => ['teacherName', 'teacherId']
    },
    optionProp: { // 传入的筛选栏属性名字
      type: Array,
      default: () => ['name', 'id']
    },
    placeholder: { // 提示的文字信息
      default: () => '请输入搜索名称'
    },
    value: {
      type: Array,
      default: () => []
    },
    showDrop: {
      type: Boolean,
      default: () => false
    },
    dropName: { // 默认下拉名字
      type: String
    },
    dropId: { // 默认下拉id
      type: String
    },
    queryParam:{
      type: Object
    }
  },
  data() {
    return {
      currentPage: 1,
      list: [],
      error: false,
      loading: false,
      total: 0,

      sectionName: this.dropName || '筛选',
      listParams: {},
      transferParams: {
        pageSize: 999,
        pageNum: 1,
        name: ''
      },
      listOption: [],
      checkedSection: this.value,
      totalList: []
    }
  },
  methods: {
    getList() { // 获取列表
      this.$emit('change',this.listParams)
    },
    getOptionList() { // 获取列表
      urlForPost(this.urlOption, this.transferParams).then(res => {
        let data = res.data.list
        let arr = []
        data.forEach(item => {
          let obj = {
            text: item[this.optionProp[0]],
            value: item[this.optionProp[1]]
          }
          arr.push(obj)
        })
        this.listOption = arr;
        this.getList();
      })
    },
    checkedSectionFn(e) {
      let idArr = e;
      let nameArr = [];
      this.totalList.forEach(item => {
        idArr.forEach(ite => {
          if (ite === item.id) {
            nameArr.push(item.name)
          }
        })
      })
      nameArr = [...new Set(nameArr)]
      let data = {
        ids: e.join(),
        names: nameArr.join()
      }
      this.$emit('checkFn', data)
    },
    changeItem(e) {
      this.listOption.forEach(item => {
        if (item.value === e) {
          this.sectionName = item.text
        }
      })
      this.getList()
    }
  },
  mounted() {
    if (this.showDrop) {
      this.getOptionList()
    }
  }
}
</script>
<style lang="less">
.pagerBox {
  background: #fff;
  margin: 12px 0;
}
</style>
