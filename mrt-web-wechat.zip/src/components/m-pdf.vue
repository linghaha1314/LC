<template>
  <div class="pagerBox">
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div style="margin: 16px;display: flex;">
      <van-button style="margin-bottom: 12px;" round block @click="goPre">
        上一页
      </van-button>
      <van-button round block color="#17d4b5" @click="attendAdd">
        下一页
      </van-button>
    </div>
    <div style="margin: 12px; color: #409EFF">{{ pageNum }} / {{ pageTotalNum }}</div>
    <pdf
        :page="pageNum"
        :src="url"
        @progress="loadedRatio = $event"
        @num-pages="pageTotalNum = $event"
    ></pdf>
  </div>
</template>
<script>
  // import {urlForPost} from '../http/apiMap';
  import pdf from 'vue-pdf'

  export default {
    name: 'pagerComponent',
    components: {
      pdf
    },
    data() {
      return {
        pageNum: 1,
        pageTotalNum: 1,
        loadedRatio: 0,
        name: '预览',
        url: this.$route.query.url || ''
      }
    },
    methods: {
      goPre(){
        let page = this.pageNum
        page = page > 1 ? page - 1 : this.pageTotalNum
        this.pageNum = page
      },
      attendAdd(){
        let page = this.pageNum
        page = page < this.pageTotalNum ? page + 1 : 1
        this.pageNum = page
      }
    },
    mounted() {
    }
  }
</script>
<style lang="less">
  .pagerBox {
    background: #fff;
    margin: 12px 0;
  }
</style>