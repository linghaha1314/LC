<template>
  <van-dropdown-item ref="item" title="年月">
    <van-datetime-picker
        v-model="currentDate"
        type="year-month"
        title="选择年月"
        :formatter="formatter"
        @confirm="dropFn"
        @cancel="cancelFn"
    />
  </van-dropdown-item>
</template>

<script>
export default {
  name: "year-drop",
  props:{
    val:{
      default:''
    }
  },
  data(){
    return{
      value: this.val,
      minDate: new Date(2020, 0, 1),
      maxDate: new Date(2025, 10, 1),
      currentDate: new Date(),
    }
  },
  methods:{
    dropFn(data){
      let date = this.getNowFormatDate(data).substring(0,7)
      this.$emit('input',date)
      this.$emit('change',date)
      this.$refs.item.toggle()
    },
    cancelFn(){
      this.$emit('input','')
      this.$emit('change','')
      this.$refs.item.toggle()
    },
    formatter(type, val) {
      if (type === 'year') {
        return `${val}年`;
      } else if (type === 'month') {
        return `${val}月`;
      }
      return val;
    },
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }

      return year + seperator1 + month + seperator1 + strDate;
    },
  },
  mounted() {
  }
}
</script>

<style scoped>

</style>
