<template>
  <van-dropdown-item title="批次" v-model="value" @change="dropFn" :options="option3"/>
</template>

<script>
import { urlForPost } from '../http/apiMap';
export default {
  name: "batch-drop",
  props:{
    val:{
      default:''
    }
  },
  data(){
    return{
      value: this.val,
      option3:[]
    }
  },
  methods:{
    dropFn(){
      this.$emit('input',this.value)
      this.$emit('change',this.value)
    },
    getYear() {
      urlForPost('/backboneTraining/getBatchByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option3 = arr
      }).catch(()=>{})
    },
  },
  mounted() {
    this.getYear()
  }
}
</script>

<style scoped>

</style>
