<template>
  <van-dropdown-item title="年度" v-model="value" @change="dropFn" :options="option1"/>
</template>

<script>
export default {
  name: "year-drop",
  props:{
    val:{
      default:''
    }
  },
  data(){
    return{
      value: this.val,
      option1:[]
    }
  },
  methods:{
    dropFn(){
      this.$emit('input',this.value)
      this.$emit('change',this.value)
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
  },
  mounted() {
    this.getYear()
  }
}
</script>

<style scoped>

</style>
