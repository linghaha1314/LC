<template>
    <div class="pagerBox">
        <div>
            <div>
                <van-search v-model="listParams.name" shape="round" @change="getList" :placeholder="placeholder" />
            </div>
        </div>
        <div>
            <van-list error-text="请求失败，点击重新加载">
                <van-cell v-for="item in list" :key="item.value" :title="item.text+' ( '+(item.sectionName||'')+' ) '" @click="checkThis(item)" />
            </van-list>
        </div>
        <div>
            <van-pagination v-model="listParams.pageNum" :total-items="total" :show-page-size="3" force-ellipses @change="getList" />
        </div>
    </div>
</template>
<script>
    import { urlForPost } from '../http/apiMap';
    export default {
        name: 'pagerComponent',
        props: {
            url: {
                type: String
            },
            listProp: { // 传入的属性名字
                type: Array,
                default: () => ['teacherName', 'teacherId']
            },
            placeholder: { // 提示的文字信息
                default: () => '请输入搜索名称'
            },
            sectionId: {
                type: String
            },
            params:{
               type: Object
            }
        },
        data() {
            return {
                currentPage: 1,
                list: [],
                error: false,
                loading: false,
                listParams: {
                    pageSize: 10,
                    pageNum: 1,
                    name: '',
                    sectionId: this.sectionId || ''
                },
                total: 0
            }
        },
        methods: {
            getList() { // 获取列表
                Object.assign(this.listParams, this.params)
                urlForPost(this.url, this.listParams).then(res => {
                    this.total = res.data.total || 30
                    let data = res.data.list
                    let arr = []
                    data.forEach(item => {
                        let obj = {
                            text: item[this.listProp[0]],
                            value: item[this.listProp[1]],
                            id: item['id'],
                            row: item,
                            ...item
                        }
                        arr.push(obj)
                    })
                    this.list = arr;
                })
            },
            checkThis(data) { // 选择时
                this.$emit('check', data)
            }
        },
        mounted() {
            this.getList();
        }
    }
</script>
<style lang="less">
    .pagerBox {
        background: #fff;
        margin: 12px 0;
    }
</style>
