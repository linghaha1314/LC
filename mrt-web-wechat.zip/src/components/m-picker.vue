<template>
    <div class="pagerBox">
        <div v-if="showSearch">
            <van-search v-model="listParams.name" shape="round" @change="getList" placeholder="搜索" />
        </div>
        <van-picker :columns="columns" :show-toolbar="true" @cancel="onCancel" @confirm="onConfirm" />
    </div>
</template>
<script>
    import { urlForPost } from '../http/apiMap';
    export default {
        name: 'pagerComponent',
        props: {
            url: {
                type: String,
                require: true
            },
            code: {
                type: String
            },
            urlOption: {
                type: String
            },
            listProp: { // 传入的属性名字
                type: Array,
                default: () => ['name', 'id']
            },
            optionProp: { // 传入的筛选栏属性名字
                type: Array,
                default: () => ['name', 'id']
            },
            placeholder: { // 提示的文字信息
                default: () => '请输入搜索名称'
            },
            value: {
                type: Array,
                default: () => []
            },
            showSearch: {
                type: Boolean,
                default: () => false
            }
        },
        data() {
            return {
                listParams: {
                    name: '',
                    code: this.code
                },
                columns: []
            }
        },
        methods: {
            getList() { // 获取列表
                urlForPost(this.url, this.listParams).then(res => {
                    let data = res.data.list,
                        targetArr = [];
                    data.forEach(item => {
                        targetArr.push({
                            text: item[this.listProp[0]],
                            value: item[this.listProp[1]]
                        })
                    })
                    this.columns = targetArr
                })
            },

            onConfirm(value) {
                this.$emit('confirm', value)
            },
            onCancel() {
                this.$emit('cancel')
            }
        },
        mounted() {
            this.getList();
        }
    }
</script>
<style lang="less">
    .pagerBox {
        background: #fff;
        margin: 12px 0;
    }
</style>