<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">

      <van-field readonly clickable required name="typeId" label="培训阶段" :value="formData.typeName" placeholder="选择培训阶段" @click="showTypePicker = true"
                 :rules="[{ required: true, message: '请选择培训阶段' }]" />
      <van-popup v-model="showTypePicker" round position="bottom">
        <van-picker :columns="typeColumns" :show-toolbar="true" @cancel="showTypePicker = false" @confirm="onTypeConfirm" />
      </van-popup>

<!--      <van-field name="medicalTeamLeaderId" readonly required label="学生姓名" :value="formData.medicalTeamLeaderName" />-->

      <van-field readonly clickable required name="studentId" label="学生姓名" :value="formData.studentName"
                 placeholder="选择学生姓名" @click="showStudentPicker = true"
                 :rules="[{ required: true, message: '请选择学生姓名' }]"/>
      <van-popup v-model="showStudentPicker" round position="bottom">
        <van-picker :columns="studentColumns" :show-toolbar="true" @cancel="showStudentPicker = false"
                    @confirm="onConfirm($event,formData,'studentName','studentId','showStudentPicker')"
        />
      </van-popup>

      <van-field v-model="formData['theory']" name="theory" required label="理论部分"
                 placeholder="请输入理论部分" type="textarea" rows="2" show-word-limit :autosize="true" :rules="[{ required: true, message: '请填写理论部分'}]"
      />
      <van-field v-model="formData['skill']" name="skill" required label="技能部分"
                 placeholder="请输入技能部分" type="textarea" rows="2" show-word-limit :autosize="true" :rules="[{ required: true, message: '请填写技能部分'}]"
      />
      <van-field v-model="formData['clinicalPractice']" name="clinicalPractice" required label="临床实践部分"
                 placeholder="请输入临床实践部分" type="textarea" rows="2" show-word-limit :autosize="true" :rules="[{ required: true, message: '请填写临床实践部分'}]"
      />
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field readonly clickable name="startDate" required label="开始时间" :value="formData.startDate.substring(0,10)"
                 placeholder="选择开始时间" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择开始时间' }]" />
      <van-popup v-model="showDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="formData.currentDate" type="date" @cancel="showDatePicker = false" @confirm="onDateConfirm($event,formData,'startDate','showDatePicker')"
                               :min-date="minDate" />
        </div>
      </van-popup>
      <van-field readonly clickable name="endDate" required label="结束时间" :value="formData.endDate.substring(0,10)"
                 placeholder="选择结束时间" @click="showEndDatePicker = true" :rules="[{ required: true, message: '请选择结束时间' }]" />
      <van-popup v-model="showEndDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="formData.currentEndDate" type="date" @cancel="showEndDatePicker = false" @confirm="onDateConfirm($event,formData,'endDate','showEndDatePicker')"
                               :min-date="minDate" />
        </div>
      </van-popup>
      <van-field v-model="formData['remark']" name="remark" label="备注"
                 placeholder="请输入备注" type="textarea" rows="2" show-word-limit :autosize="true"
      />

      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="margin: 16px;">
        <van-button round block :disabled="disabled" color="#17d4b5" @click="onSubmit   ">
          提交申请
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import { urlForPost, plansCreate, planscheduleTimeList } from '../http/apiMap.js'
import { Dialog } from 'vant';
export default {
  name: 'test',
  data() {
    return {
      formData: {
        startDate: '',
        endDate: '',
      },
      teacherParams: {
        sectionId: localStorage.getItem('currentSectionId')
      },
      showPicker: false,
      showTypePicker: false,
      showStudentPicker: false,
      showDatePicker: false,
      showEndDatePicker: false,
      typeColumns: [],
      studentColumns: [],
      action: 3,
      columns: [],
      minDate: new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), new Date().getHours() < 13 ? 9 : 13, 0, 0),
      attachFlag: false,
      leaveDays: 0,
      disabled: false,
      columns1: ['上午', '下午'],
      columnsValue: ''
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {

          plansCreate(this.formData).then(res => {
            if (res.data.data.success) {
              this.$toast.clear();
              this.$router.go(-1)
            } else {
              this.$toast.fail(res.data.msg || '出问题啦!!')
            }
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },
    onConfirm(value, target, name, id, show) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
    },
    onTypeConfirm(value) {
      this.formData.typeId = value.value;
      this.formData.typeName = value.text;
      this.attachFlag = value.attachFlag;
      this.showTypePicker = false;
    },

    onDateConfirm(value,target,prop,show) {
      target[prop] = this.getNowFormatDate(value)+' 00:00:00'
      this[show] = false;
    },
    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      return year + seperator1 + month + seperator1 + strDate;
    },

    // 获取阶段列表
    planscheduleTimeListFn(){
      planscheduleTimeList({
        pageSize: 999,
        pageNum: 1
      }).then(res => {
        if(res.data.rows){
          let arr = res.data.rows
          arr.forEach(item => {
            item.text = item.typeName
            item.value = item.id
          })
          this.typeColumns = [...arr]
        }
      })
    },

    // 获取学生
    getStudent(){
      urlForPost('/student/listStudentByTeacherId').then(res => {

        let arr = res.data.list
        arr.forEach(item => {
          item.text = item.studentName;
          item.value = item.id;
        })
        this.studentColumns = [...arr]
      })
    }
  },
  mounted() {
    this.planscheduleTimeListFn() // 获取
    this.getStudent() // 获取
    let queryData = this.$route.query
    if(queryData.id){
      this.formData = {
        id: queryData.id,
        startDate: queryData.startDate,
        endDate: queryData.endDate,
        typeName: queryData.typeName,
        typeId: queryData.typeId,
        studentName: queryData['staffName'],
        studentId: queryData.staffId,
        theory: queryData.theory,
        skill: queryData.skill,
        clinicalPractice: queryData.clinicalPractice,
        remark: queryData.remark,
      }
    }
  }
}
</script>