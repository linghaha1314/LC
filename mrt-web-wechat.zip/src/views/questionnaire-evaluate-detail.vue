<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="老师姓名:" :value="currentData.teacherName"/>
        <van-cell title="学生姓名:" :value="currentData['studentName']"/>
        <van-cell title="科室:" :value="currentData.sectionName||'无'"/>
        <van-cell title="专业:" :value="currentData.majorName||'无'"/>
        <van-cell title="批次:" :value="currentData['batchName']||'无'"/>
        <van-cell title="评价老师:">
          <template #label>
            <div>{{currentData['teacherCricism']||'无'}}</div>
          </template>
        </van-cell>
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: '评价详情',
    }
  },
  computed: {
  },
  methods: {
  },
  mounted() {
    // urlForGet('/staff/getStaffDetail',this.currentData.teacherId
    // , 'teacherId').then(res => {
    //   let data = res.data.data
    //   let target = Object.assign(this.currentData, data)
    //   this.$set(this, 'currentData', target)
    // })
    // this.certificateInfo()
  }
}
</script>
