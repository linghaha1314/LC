<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="warningForm" style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div
          style="border-left: 4px solid #17d4b5; font-size: 14px; font-weight: bold; margin: 20px 12px; text-align: left; padding-left: 4px">
        注册请提前准备:
      </div>
      <van-field
          name="picture"
          label="需要一寸蓝底头像(电子版)"
          required
          :value="formData.picture"
          :rules="[{ required: true, message: '请一定要准备哦！' }]"
      >
        <template #input>
          <van-radio-group v-model="formData.picture" direction="horizontal">
            <van-radio :name="1"></van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <div style="text-align: center;color: red">资格证、执业证、毕业证、学位证等</div>
      <van-field
          name="certificates"
          label="需要相关证件(电子版照片)"
          required
          :value="formData.certificates"
          :rules="[{ required: true, message: '请一定要准备哦！' }]"
      >
        <template #input>
          <van-radio-group v-model="formData.certificates" direction="horizontal">
            <van-radio :name="1"></van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field
          name="invoice"
          label="需要开票单位及统一信用码"
          required
          :value="formData.invoice"
          :rules="[{ required: true, message: '请一定要准备哦！' }]"
      >
        <template #input>
          <van-radio-group v-model="formData.invoice" direction="horizontal">
            <van-radio :name="1"></van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field
          name="patience"
          label="上传体积比较大的文件请耐心等待"
          required
          :value="formData.patience"
          :rules="[{ required: true, message: '请一定要准备哦！' }]"
      >
        <template #input>
          <van-radio-group v-model="formData.patience" direction="horizontal">
            <van-radio :name="1"></van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="margin: 16px;display: flex;">
        <van-button round block color="#17d4b5" @click="attendAdd">
          都准备好了
        </van-button>
      </div>
    </van-form>
    <div style="margin: 16px;display: flex;">
      <van-button round block color="#17d4b5" @click="show = true">
        进度查询
      </van-button>
    </div>
    <van-popup v-model="show" style="width: 100vw;height: 50vh; padding: 30px 0;">
      <div>
        <div style="font-size: 20px; font-weight: bold; color: #333333; margin-bottom: 24px;">进度查询</div>
        <van-field
            v-model="idCard"
            name="username"
            label="身份证"
            placeholder="请输入身份证"
            required
            :rules="[{ pattern:pattern, message: '必须填写身份证' }]"
        />
        <div style="margin: 16px;">
          <van-button round block type="primary" @click="query">查询</van-button>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script>
import {urlForPost} from '../http/apiMap.js'
import {getStudentDetailById} from '../http/apiMap'
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      url: {
        info: '/advancedsignup/queryProgressInfo'
      },
      currentData: this.$route.query,
      name: '注册须知',
      idCard: '',
      formData: {},
      show: false,
      pattern: /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/
    }
  },
  computed: {},
  methods: {
    attendAdd() {
      this.$refs.warningForm.validate().then(() => {
        this.$router.push('/sign-check')
      })
    },
    query() {
      if (this.idCard === '') {
        this.$toast.fail('身份证不能为空哦!')
      } else {
        // 开始查询
        this.gerProgress()
      }
    },
    gerProgress() {
      sessionStorage.setItem('identifyNo', this.idCard)
      urlForPost(this.url.info, {
        identifyNo: this.idCard
      }).then(res => {
        if (!res.data.data) {
          this.$toast.fail('您还未进行报名哦!')
        } else {
          this.show = false
          let info = res.data.data
          let signInfo = {
            id: info.batchId,
            hospitalId: info.hospitalId,
            projectId: info.projectId || '',
            trainTypeCode: info.trainTypeCode
          }
          localStorage.setItem('signInfo', JSON.stringify(signInfo))
          localStorage.setItem('progressInfo', JSON.stringify(info))
          this.$router.push({
            path: '/sign-progress',
            query: {
              identifyNo: this.idCard,
              data: res.data.data
            }
          })
        }
      })
    },
  },
  mounted() {
    getStudentDetailById(this.currentData.studentId).then(res => {
      let data = res.data.data
      let target = Object.assign(this.currentData, data)
      this.$set(this, 'currentData', {...target})
    })
  }
}
</script>
