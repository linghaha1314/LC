<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="姓名:" :value="currentData.studentName"/>
        <van-cell title="性别:" :value="currentData['genderName']"/>
        <van-cell title="生日:" :value="currentData['birthday'] && currentData['birthday'].substring(0,10)"/>
        <van-cell title="民族:" :value="currentData['nationName']"/>
        <van-cell title="学历:" :value="currentData['academicName']"/>
        <van-cell title="身份证号码:" :value="currentData['identifyNo']"/>
        <van-cell title="推荐单位:" :value="currentData['fromUnitName']"/>
        <van-cell title="单位等级:" :value="currentData['levelStandard']"/>
        <van-cell title="单位联系电话:" :value="currentData['workUnitTelephone']"/>
        <van-cell title="资格证书编码:" :value="currentData['physicianQualification']||'无'"/>
        <van-cell title="执业证书编码:" :value="currentData['physicianPractice']||'无'"/>
        <van-cell title="入学批次:" :value="currentData['kbabatchName']"/>
        <van-cell title="家庭住址:" :value="currentData['staff']['homeAddress']"/>
        <van-cell title="手机号码:" :value="currentData['mobile'] || '无'"/>
        <van-cell title="医院等级:" :value="currentData['levelStandard']"/>
        <van-cell title="带教老师:" :value="currentData.teacherName||'无'"/>
        <van-cell title="进修科室:" :value="currentData.sectionName||'无'"/>
        <van-cell title="进修专业:" :value="currentData.majorName||'无'"/>
        <van-cell title="进修期限:" :value="currentData['month']+'个月'"/>
        <van-cell title="进修类型:" :value="currentData['sectionTypeName']"/>
        <van-cell title="结业日期签发时间:" :value="currentData['leaveHospitalDate']||'未结业'"/>
        <van-cell title="状态:" :value="statusFn"/>
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
import {getStudentDetailById} from '../http/apiMap'
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: this.$route.name
    }
  },
  computed: {
    typeFn(){
      let row = this.currentData
      let education = "";
      let union = "";
      let support = "";
      if (row['educationFlag']==='true') {
        education = "普通进修"
      }
      if (row['unionsFlag']==='true') {
        union = "医联体"
      }
      if (row['supportFlag']==='true') {
        support = "对口帮扶"
      }
      return " " + education + " " + union + " " + support + " ";
    },
    statusFn(){
      let value = parseInt(this.currentData.status)
      switch (value) {
        case 0:
          return "在训";
        case 1:
          return "已提前结业";
        case 2:
          return "已结业";
        case 3:
          return "拟结业";
        case 4:
          return "结业中";
        default :
          return "--";
      }
    }
  },
  methods: {},
  mounted() {
    getStudentDetailById(this.currentData.studentId).then(res => {
      let data = res.data.data
      let target = Object.assign(this.currentData, data)
      this.$set(this, 'currentData', {...target})
    })
  }
}
</script>