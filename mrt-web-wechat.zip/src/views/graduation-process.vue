<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">
      <div v-if="processType===1">
        <van-field name="status" label="是否同意" required :value="formData.status"
                   :rules="[{ required: true, message: '请选择是否同意'}]">
          <template #input>
            <van-radio-group v-model="formData.status" direction="horizontal" @change="radioFn">
              <van-radio :name="0">不同意</van-radio>
              <van-radio :name="1">同意</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field v-if="formData.status===1" v-model="teachOpinionT" name="teachOpinion" required label="老师评价"
                   placeholder="请输入老师评价,不少于30个字" type="textarea" rows="5" show-word-limit
                   maxlength="100"
                   :autosize="true"
                   :rules="[{ validator, message: '请填写老师评价,不少于30个字'}]"
                   @change="formData.teachOpinion = teachOpinionT"
        />
        <div v-else>
          <van-field name="teachOpinion" label="老师评价" required :value="formData.teachOpinion"
                     :rules="[{ required: true, message: '请选择老师评价'}]">
            <template #input>
              <van-radio-group v-model="teachOpinion" direction="horizontal" @change="formData.teachOpinion = teachOpinion">
                <van-radio name="个人鉴定不客观或属实，请结合承担工作和实际学习情况修改后重新提交。">个人鉴定不客观或属实，请结合承担工作和实际学习情况修改后重新提交。</van-radio>
              </van-radio-group>
            </template>
          </van-field>
        </div>

        <div style="margin: 16px;">
          <van-button round block color="#17d4b5" @click="onSubmit">
            审批
          </van-button>
        </div>
      </div>

      <div v-if="processType===2">
        <van-field name="theoryScore" v-model="formData.theoryScore" type="number" readonly label="理论成绩"
                   :rules="[{ required: true, message: '请填写理论成绩'}]"/>
        <van-field name="skillScore" v-model="formData['skillScore']" type="number" required label="技能成绩"
                   :rules="[{ required: true, message: '请填写技能成绩'}]"/>
        <van-field name="moralScore" v-model="formData['moralScore']" type="number" required label="品行成绩"
                   :rules="[{ required: true, message: '请填写品行成绩'}]"/>
        <van-field name="affairDays" v-model="formData.affairDays" type="number" readonly label="事假"
                   :rules="[{ required: true, message: '请填写事假'}]"/>
        <van-field name="illnessDays" v-model="formData.illnessDays" type="number" readonly label="病假"
                   :rules="[{ required: true, message: '请填写病假'}]"/>
        <van-field name="skipWorkDays" v-model="formData.skipWorkDays" type="number" required label="旷工"
                   :rules="[{ required: true, message: '请填写旷工'}]"/>

        <van-field name="status" label="是否同意" required :value="formData.status"
                   :rules="[{ required: true, message: '请选择是否同意'}]">
          <template #input>
            <van-radio-group v-model="formData.status" direction="horizontal">
              <van-radio :name="0">不同意</van-radio>
              <van-radio :name="1">同意</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field name="sectionResult" label="科室考评" required :value="formData.sectionResult"
                   :rules="[{ required: true, message: '请选择科室考评'}]">
          <template #input>
            <van-radio-group v-model="formData.sectionResult" direction="horizontal">
              <van-radio v-if="formData.status===1" style="border-bottom: 1px solid #cccccc"
                         name="同意学员个人鉴定及带教老师评语，该生达到我科进修学员能力提升培养要求，考核合格。">同意学员个人鉴定及带教老师评语，该生达到我科进修学员能力提升培养要求，考核合格。
              </van-radio>
              <van-radio v-if="formData.status===1" style="border-bottom: 1px solid #cccccc"
                         name="同意学员个人鉴定及带教老师评语，该生达到我科进修学员能力提升培养要求，考核优秀。">同意学员个人鉴定及带教老师评语，该生达到我科进修学员能力提升培养要求，考核优秀。
              </van-radio>
              <van-radio v-if="formData.status===0" style="border-bottom: 1px solid #cccccc"
                         name="该生未能达到我科进修学员能力提升培养要求，考核不合格。">该生未能达到我科进修学员能力提升培养要求，考核不合格。
              </van-radio>
              <van-radio v-if="formData.status===0" style="border-bottom: 1px solid #cccccc"
                         name="不同意进修学员个人鉴定，请修改后重新提交。">不同意进修学员个人鉴定，请修改后重新提交。
              </van-radio>
              <van-radio v-if="formData.status===0" style="border-bottom: 1px solid #cccccc" name="不同意带教老师评语，请修改后重新提交。">
                不同意带教老师评语，请修改后重新提交。
              </van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <div style="margin: 16px;">
          <van-button :disabled="!formData.theoryScore||formData.theoryScore===0" round block color="#17d4b5"
                      @click="onSubmit">
            {{ !formData.theoryScore || formData.theoryScore === 0 ? '理论成绩异常' : '审批' }}
          </van-button>
        </div>
      </div>

      <div v-if="processType===3">

        <van-field name="status" label="是否同意" required :value="formData.status"
                   :rules="[{ required: true, message: '请选择是否同意'}]">
          <template #input>
            <van-radio-group v-model="formData.status" direction="horizontal">
              <van-radio :name="0">不同意</van-radio>
              <van-radio :name="1">同意</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field name="deptResult" label="部门考评" required :value="formData.deptResult"
                   :rules="[{ required: true, message: '请选择部门考评'}]">
          <template #input>
            <van-radio-group v-model="formData.deptResult" direction="horizontal">
              <van-radio v-if="formData.status===1" name="同意科室考核意见，准予结业。">同意科室考核意见，准予结业。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意。">不同意。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意个学员人鉴定。">不同意学员个人鉴定。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意带教老师评语。">不同意带教老师评语。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意科室考核意见，不予结业。">不同意科室考核意见。</van-radio>
              <van-radio v-if="formData.status===0" name="期间参加教学活动不达标。">期间参加教学活动不达标。</van-radio>
              <van-radio v-if="formData.status===0" name="期间上报的工作量不达标。">期间上报的工作量不达标。</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <div style="margin: 16px;">
          <van-button round block color="#17d4b5" @click="onSubmit">
            审批
          </van-button>
        </div>
      </div>

    </van-form>
  </div>
</template>
<script>
import {getApplyInfo, getAuthType, applyProcess, getStudentDetail} from '../http/apiMap.js'
import {Dialog} from 'vant';

export default {
  name: 'test',
  data() {
    return {
      teachOpinion: '',
      teachOpinionT: '',
      formData: {},
      studentInfo: {},
      disabled: false,
      processType: 2,
      queryData: this.$route.query
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          this.formData.taskId = this.queryData.taskId
          this.formData.projectId = this.queryData.id
          this.formData.processInstanceId = this.queryData.processInstanceId
          applyProcess(this.formData).then(res => {
            this.$toast.success(res.data.msg || '操作成功!')
            this.$router.go(-1)
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },

    // 获取学员结业信息
    getApplyInfoFn() {
      let studentId = this.queryData.studentId || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
      })
    },
    getAuthTypeFn(cb) {
      getAuthType().then(res => {
        let data = res.data.data;
        if (data === 'personal') {
          this.processType = 1
        } else if (data === 'section') {
          this.processType = 2
        } else {
          this.processType = 3
        }
        cb()
      })
    },
    radioFn() {
      this.formData.teachOpinion = ''
      this.teachOpinion = ''
      this.teachOpinionT = ''
    },
    getStudentDetailFn() {
      let query = this.$route.query
      getStudentDetail(query.id).then(res => {
        let info = JSON.parse(res.data.data)
        this.formData.affairDays = info.affairDays || 0
        this.formData.illnessDays = info.illnessDays || 0
        this.formData.theoryScore = info["answerScore"] || 0
        this.formData = {...this.formData}
      })
    },
    validator() {
      return this.formData.teachOpinion.length > 29
    }
  },
  mounted() {
    let query = this.$route.query
    this.getAuthTypeFn(() => {
      if (this.processType === 2) {
        this.getStudentDetailFn()
      }
    })
    if (!query.id) {
      this.getApplyInfoFn()
    }
  }
}
</script>
