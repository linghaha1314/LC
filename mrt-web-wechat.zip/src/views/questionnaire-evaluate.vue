<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <template #right v-if="role === 'StudentType_jxs'">
        <span style="color: #17d4b5" @click="goMyRecord()">我的</span>
      </template>
    </van-nav-bar>
    <div>
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.sectionId" @change="changeSection"
                           :options="option4"/>
        <van-dropdown-item title="专业" v-model="listParams.majorId" @change="getList" :options="majorOption" />
        <van-dropdown-item title="批次" v-model="listParams.batchId" @change="getList" :options="option3"/>
        <year-drop v-model="listParams.year" @change="getList"></year-drop>
      </van-dropdown-menu>
    </div>
    <div>
      <van-search v-model="listParams.name" shape="round" @change="getList" placeholder="搜索"/>
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <div>
              <div style="font-size: 14px;display: flex;justify-content: space-between;">
                老师姓名: {{ data.teacherName || '无' }}
              </div>
              <van-divider/>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">科室:</div>
                <div>{{ data.sectionName }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">专业:</div>
                <div>{{ data['majorName'] }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <router-link :to="{path:'/questionnaire-evaluate-detail',query:data}">
                <van-button type="default" size="mini">查看详情</van-button>
              </router-link>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>

      <div style="position: fixed;right: 26px;bottom: 60px"
           v-if="role==='sectionManager' || role==='superadmin' || role==='JXS_manager' || role==='headNurse'">
        <router-link :to="{path:'/activities-add',query:{typePage: this.typePage}}">
          <van-icon color="#ff0000" name="add" size="40"/>
        </router-link>
      </div>
    </div>
  </div>
</template>
<script>
import { getDictionaryType, getTransferSchedule, urlForPost} from '../http/apiMap';
import YearDrop from '../components/year-drop'
export default {
  name: 'test',
  components: {
    YearDrop
  },
  data() {
    return {
      listParams: {
        pageSize: 10,
        pageNum: 0,
        typeId: '',
        sectionId: '',
        name: '',
        status: null
      },
      role: '',
      option1: [],
      option2: [ // 上级
        {text: '全部', value: null},
        {text: '已结束', value: 3},
        {text: '已发布', value: 1},
        {text: '未提交', value: 0},
      ],
      option3: [],
      majorOption:[],
      option4: [],
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      testData: [],
      typePage: '0',
      name: '评价查看',
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {},
  mounted() {
    this.role = localStorage.getItem('roleCode')
    this.getBatch();
    this.getTypeList();
    this.transferGet();
    this.getListMajor();
  },
  methods: {
    goDetail(data) {
      data.typePage = this.typePage
      localStorage.setItem('currentData', JSON.stringify(data))
      this.$router.push({
        path: '/activities-add',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;

      // 重新加载数据
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.getList(flag)
    },
    // 获取列表
    getList(f) {
      urlForPost('/advancedgraduation/getListEvaluateByTeacherForstudent', this.listParams).then(res => {
        if (f === 'onLoad') {
          this.state.loading = false;
          if (res.data.data.list.length === 0 || res.data.data.list.length<this.listParams.pageSize) {
            this.state.finished = true
          }
          this.testData = [...this.testData,...res.data.data.list]
        } else {
          this.testData = [...res.data.data.list];
        }
      })

    },
    // 获取类型
    getTypeList() {
      getDictionaryType('ActivityPlanContent').then(res => {
        let data = res.data.data
        let arr = [{
          text: '全部',
          value: ''
        }]
        data.forEach(item => {
          if (item.name !== '入科教育') {
            let obj = {
              text: item.name,
              value: item.id
            }
            arr.push(obj)
          }
        })
        this.option1 = arr;
      })
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option4 = [...optionArr]
      })
    },
    // 我的签到记录
    goMyRecord() {
      this.$router.push({
        path: '/activities-record',
        query: this.typePage
      })
    },
    // 获取批次
    getBatch(){
      urlForPost('/backboneTraining/getBatchByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option3 = arr
      }).catch(()=>{})
    },
    // 获取专业
    getListMajor(){
      urlForPost('/submajor/getListQueryByPage',{
        pageSize: 999,
        sectionId: this.listParams.sectionId,
        pageNum: 1
      }).then(res => {
        let optionArr = [
          { text: '全部', value: '' }
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.sectionName+' - '+item.name,
            value: item.id,
            ...item
          }
          optionArr.push(obj)
        })
        this.majorOption = [...optionArr]
      })
    },
    changeSection(){
      this.getList()
      this.getListMajor()
    }
  }
}
</script>
