<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div>
      <van-search
          v-model="listParams.name"
          shape="round"
          @change="getList"
          placeholder="搜索科室名字"
      />
    </div>
    <div style="background:#cccccc;min-height: 90vh; padding: 12px 0">
      <div v-for="item in currentData" :key="item.id" style="margin: 0 12px 24px;">
        <van-cell title="转科人员" :value="item['staffName'] || '无'"/>
        <van-cell title="轮转科室" :value="item.sectionName || '无'"/>
        <van-cell title="带教老师" :value="item.teacherName || '无'"/>
        <van-cell title="开始日期" :value="item.startDate.substring(0,10)"/>
        <van-cell title="结束日期" :value="item.endDate.substring(0,10)"/>
        <van-cell title="状态">
          <template #default>
            <div style="width: 10em; margin-left: 12px; text-align: right">
              <van-tag style="text-align: center" :type="'danger'" v-if="item.checkinFlag===1 && item['outStatus']===2" size="medium">已出科</van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-else-if="item.checkinFlag===1 && item['outStatus']===1" size="medium">已轮转</van-tag>
              <van-tag style="text-align: center" :type="'success'" v-else-if="item.checkinFlag===1 && item['outStatus']===0" size="medium">正在轮转</van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-else size="medium">未入科</van-tag>
            </div>
          </template>
        </van-cell>
      </div>
    </div>
  </div>
</template>
<script>
    import { myschedule } from '../http/apiMap';

    export default {
        name: 'test',
        data(){
            return{
                currentData: {},
                listParams:{
                    pageSize: 999,
                    pageNum: 1,
                    name: ''
                }
            }
        },
        computed:{
            name(){
                return this.$route.name
            }
        },
        methods:{
            getList(){
                myschedule(this.listParams).then(res => {
                    this.currentData = res.data.list
                })
            }

        },
        mounted() {
            this.getList() // 获取数据
        }
    }
</script>
