<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div>
      <van-tabs color="#17d4b5" v-model="active" @change="tabFn">
        <van-tab title="本科室学员"></van-tab>
        <van-tab title="轮转学员"></van-tab>
      </van-tabs>
    </div>
    <div>
      <m-dropdown v-if="role !== 'StudentType_jxs'" :data="filterData" @change="filterFn"></m-dropdown>
    </div>
    <div>
      <van-search
          v-model="listParams.name"
          shape="round"
          @change="onRefresh"
          placeholder="搜索"
      />
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
               v-for="data in testData" :key="data.title"
          >
            <div @click="goDetail(data)">
              <div style="font-size: 14px;display: flex;justify-content: space-between;">
                {{ data.studentName || '无' }}
                <div style="width: 4em; margin-left: 12px">
                  <van-tag style="text-align: center" :type="'danger'" v-if="data.status===2" size="medium">已确认
                  </van-tag>
                  <van-tag style="text-align: center" :type="'warning'" v-if="data.status===1" size="medium">已确认
                  </van-tag>
                  <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">待确认
                  </van-tag>
                </div>
              </div>
              <van-divider/>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">入科学生:</div>
                <div>{{ data.studentName || data['staffName'] || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">科室:</div>
                <div>{{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">专业:</div>
                <div>{{ data.majorName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">学号:</div>
                <div>{{ data['serialNo'] || data['enrollNo'] || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">进修期限:</div>
                <div>{{ data['periodMonths'] || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.checkTime">
                <div style="color: #cccccc;margin-bottom: 4px;">入科时间:</div>
                <div>{{ data.checkTime.substring(0, 10) }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">带教老师:</div>
                <div>{{ data.teacherName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="active===1">
                <div style="color: #cccccc;margin-bottom: 4px;">轮转时间:</div>
                <div v-if="data.startDate && data.endDate">{{ data.startDate.substring(0, 10) }} 至
                  {{ data.endDate.substring(0, 10) }}
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              <van-button style="width: 4em;" type="primary"
                          size="mini" @click="goDetail(data)">查看
              </van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>

    </div>
  </div>
</template>
<script>
import {getDictionaryType, getTransferSchedule, intoFamilyList, intoFamilySectionList, urlForPost} from '../http/apiMap';
import mDropdown from '../components/m-dropdown'

export default {
  name: 'test',
  components: {
    mDropdown
  },
  data() {
    return {
      listParams: {
        pageSize: 10,
        pageNum: 1,
        checkinFlag: null,
        flag: true,
        studentCurrentStatus: 0
      },
      role: '',
      filterData: [
        {
          title: '年度',
          prop: 'year',
          option: [
            {
              text: '全部',
              value: '',
            }
          ]
        },
        {
          title: '批次',
          prop: 'batchId',
          option: [
            {
              text: '全部',
              value: '',
            }
          ]
        },
        {
          title: '是否入科',
          prop: 'checkinFlag',
          option: [
            {
              text: '已入科',
              value: '1',
            },
            {
              text: '未入科',
              value: '0',
            }
          ]
        }
      ],
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      testData: [],
      active: parseInt(sessionStorage.getItem('currentActive'))||0,
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    // this.active = sessionStorage.getItem('currentActive')? parseInt(sessionStorage.getItem('currentActive')) : 0
    // this.onRefresh()
    // this.getTypeList();
    // this.transferGet();
    this.yearOption();
    this.getBatch()
  },
  methods: {
    goDetail(data) {
      data.transferFlag = this.active === 1
      sessionStorage.setItem('currentActive', this.active)
      this.$router.push({
        path: '/into-family-confirm',
        query: data
      })
    },
    // goInfo(data){
    //     data.transferFlag = this.active === 1
    //     sessionStorage.setItem('currentActive',this.active)
    //     this.$router.push({
    //       path: '/we-rotary',
    //       query: data
    //     })
    // },
    // 获取列表
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;

      this.testData = []
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.getList(flag)
    },
    getList(f) {
      if (this.active === 1) {
        intoFamilySectionList(this.listParams).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            if(res.data.total === 0){
              this.testData = []
            }else{
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      } else {
        intoFamilyList(this.listParams).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            if(res.data.total === 0){
              this.testData = []
            }else{
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      }
    },
    // 获取类型
    getTypeList() {
      getDictionaryType('TeachActivityType').then(res => {
        let data = res.data.data
        let arr = [{
          text: '全部',
          value: ''
        }]
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          arr.push(obj)
        })
        this.option1 = arr;
      })
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option4 = [...optionArr]
      })
    },
    // 标签栏
    tabFn() {
      // this.listParams.flag = this.active === 0? 'unread':'read'
      sessionStorage.setItem('currentActive',this.active)
      this.testData = []
      this.onRefresh();
    },
    // 年度筛选条件
    yearOption(){
      let date = new Date().getFullYear();
      for (let y = date; y>2015; y--){
        this.filterData[0].option.push({
          text: y,
          value: y
        })
      }
    },
    // 获取批次
    getBatch() {
      urlForPost('/advancedsignup/listBatchByPage',{status: 1}).then(res => {
        let data = res.data
        data.forEach(item => {
          this.filterData[1].option.push({
            text: item.name,
            value: item.id
          })
        })
      })
    },
    filterFn(data){
      this.listParams.year = data.year
      this.listParams.batchId = data.batchId
      this.listParams.checkinFlag = data.checkinFlag
      this.onRefresh()
    }
  }
}
</script>
