<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div>
      <van-tabs color="#17d4b5" v-model="active" @change="tabFn">
        <van-tab title="未读"></van-tab>
        <van-tab title="已读"></van-tab>
      </van-tabs>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <van-cell @click="goDetail({name: '系统消息', item: item, code:listParams.code, flag:listParams.flag})"
                    v-for="item in testData" :key="item.id">
            <template #title>`
              <div style="display: flex;align-items: center">
                <div style="margin-right: 12px">
                  <div style="width: 50px;height: 50px; display: flex;justify-content: center;align-items: center;">
                    <van-image
                        round
                        width="50px"
                        height="50px"
                        src="https://img.yzcdn.cn/vant/cat.jpeg"
                    />
                  </div>
                </div>
                <div style="flex: 1;">
                  <div style="font-size: 16px;font-weight: bold">【{{ item.title }}】</div>
                  <div
                      style="padding-left: 8px;width:206px;box-sizing: border-box; overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
                    {{ item.content }}
                  </div>
                </div>
              </div>
            </template>
          </van-cell>
        </van-list>
      </van-pull-refresh>

    </div>
  </div>
</template>
<script>
import {getOneTypeMessages} from '../http/apiMap';

export default {
  name: 'test',
  data() {
    return {
      listParams: {
        pageSize: 20,
        pageNum: 0,
        code: this.$route.query.code,
        flag: 'unread'
      },
      role: '',
      testData: [],
      name: this.$route.query.name,
      active: '',
      state:{
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {},
  mounted() {
    this.role = localStorage.getItem('roleCode')
    this.getList();
    // this.getTypeList();
  },
  methods: {
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;


      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.getList(flag)
    },
    // 获取列表
    getList(f) {
      getOneTypeMessages(this.listParams).then(res => {
        if(f==='onLoad'){
          this.state.loading = false;
          if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
            this.state.finished = true
          }
          if(res.data.total === 0){
            this.testData = []
          }else{
            this.testData = [...this.testData, ...res.data.list];
          }
        }else{
          this.testData = [...res.data.list];
        }
      })
    },

    goDetail(data) {
      this.$router.push({
        path: '/message-detail',
        query: data
      })
    },
    // 标签栏
    tabFn() {
      this.listParams.flag = this.active === 0 ? 'unread' : 'read'
      this.getList();
    }
  }
}
</script>
