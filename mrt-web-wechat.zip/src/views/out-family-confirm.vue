<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="activitiesForm">
      <van-field
          readonly
          clickable
          name="type"
          label="申请出科科室"
          :value="currentData.sectionName || formData.sectionName"
      />
      <van-field
          readonly
          clickable
          name="applyTime"
          required
          label="申请时间"
          :value="formData.applyTime.substring(0,10)"
          placeholder="选择申请时间"
          @click="showDatePicker = true"
          :rules="[{ required: true, message: '请选择申请时间' }]"
          v-if="role==='StudentType_jxs'"
      />
      <van-field
          readonly
          clickable
          name="applyTime"
          :required="role!=='StudentType_jxs'"
          label="申请时间"
          :value="formData.applyTime.substring(0,10)"
          v-if="role!=='StudentType_jxs'"
      />
      <van-popup v-model="showDatePicker" round position="bottom">
        <van-datetime-picker
            v-model="dateValue"
            type="date"
            title="选择年月日"
            @cancel="showDatePicker = false"
            @confirm="onDateConfirm"
        />
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field
          v-model="formData['selfEvaluation']"
          name="remake"
          label="自我鉴定"
          placeholder="请填写自我鉴定不少于300个字"
          rows="3"
          :autosize="true"
          type="textarea"
          maxlength="500"
          show-word-limit
          :required="role==='StudentType_jxs'"
          :rules="[{ validator:(val)=>val.length>300, message: '请填写不少于300个字' }]"
          :readonly="role!=='StudentType_jxs'"
      />
<!--      <van-field-->
<!--          v-if="formData['teacherOpinion']"-->
<!--          v-model="formData['teacherOpinion']"-->
<!--          name="remake"-->
<!--          label="带教老师评语"-->
<!--          rows="3"-->
<!--          :autosize="true"-->
<!--          type="textarea"-->
<!--          maxlength="500"-->
<!--          show-word-limit-->
<!--          :readonly="true"-->
<!--      />-->
      <van-field
          v-if="role==='teacher'"
          v-model="formData.teachOpinion"
          name="teachOpinion"
          label="老师评价"
          placeholder="请填写老师评价不少于30个字"
          rows="3"
          :autosize="true"
          type="textarea"
          maxlength="100"
          show-word-limit
          required
          :rules="[{ validator:(val)=>val.length>30, message: '请填写不少于30个字' }]"
      />
      <van-field
          v-if="role==='sectionManager' || role==='headNurse'"
          v-model="queryData['teacherOpinion']"
          name="teachOpinion"
          label="老师评价"
          placeholder="请填写老师评价"
          rows="3"
          :autosize="true"
          type="textarea"
          maxlength="100"
          show-word-limit
          readonly
      />
      <div style="margin: 16px;" v-if="role==='StudentType_jxs' && formData.status !== 2 && formData.status !== 11">
        <van-button round block color="#17d4b5" @click="onSubmit">
          保存
        </van-button>
      </div>
      <div style="margin: 16px;" v-if="role!=='StudentType_jxs'">
        <van-button style="margin-bottom: 12px;" round block color="#17d4b5" @click="release(1)">
          同意
        </van-button>
        <van-button round block type="danger" @click="release(0)">
          不同意
        </van-button>
      </div>
    </van-form>
    <van-dialog v-model="show"
                confirmButtonColor="#17d4b5"
                title="确定此操作么?"
                show-cancel-button
                @cancel="show = false"
                @confirm="getApprove"
    >
      <van-field v-if="role!=='teacher'" label="理由" placeholder="请选择理由">
        <template #input>
          <van-radio-group v-if="num === 1" v-model="formData.sectionOpinion" direction="horizontal">
            <van-radio name="同意带教老师评语，该生达到进修专业轮转要求，准予出科。">同意带教老师评语，该生达到进修专业轮转要求，准予出科。</van-radio>
          </van-radio-group>
          <van-radio-group v-else v-model="formData.sectionOpinion" direction="horizontal">
            <van-radio name="不同意进修生个人鉴定，请重新填写后提交。">不同意进修生个人鉴定，请重新填写后提交。</van-radio>
            <van-radio name="不同意带教老师评语，请重新填写后提交。">不同意带教老师评语，请重新填写后提交。</van-radio>
          </van-radio-group>
        </template>
      </van-field>
    </van-dialog>
  </div>
</template>
<script>
import {
  checkinIntoFamily,
  checkinTeacher,
  outFamilyApprovalProcess,
  urlForPost,
  urlForGetCode
} from '../http/apiMap';
import {getNowFormatDate} from '../utils/utils'
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      url:{
        save: '/transfercheckout/create',
        update: '/transfercheckout/update'
      },
      formData: {
        sectionOpinion:'',
        applyTime: ''
      },
      listInfo: [],
      ac_userId: '',
      currentData: this.$route.query,
      showPicker: false,
      showTeacherPicker: false,
      showTypePicker: false,
      showDatePicker: false,
      showStartTimePicker: false,
      showEndTimePicker: false,

      action: 3,
      dateValue: new Date(),
      currentDate: new Date(),
      currentTime: '12:00',
      currentEndDate: '12:00',
      option1: [],
      role: '',
      userId: '',
      typeColumns: [],
      name: '',
      num: 0,
      reason: '',
      show: false,
      queryData: this.$route.query,
      teacherStaffInfo: {}
    }
  },
  computed: {
    isEdit() {
      return this.action === 3 || (this.action === 0 && this.userId === this.formData.userId);
    }
  },
  methods: {
    onSubmit() {
      this.$refs.activitiesForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          this.formData.teacherStaffId = this.teacherStaffInfo.teacherStaffId
          this.formData.teacherStaffId = this.teacherStaffInfo.teacherStaffId

          urlForPost(this.formData.id?this.url.update:this.url.save,this.formData).then(() => {
            this.$toast.success('操作成功!')
            setTimeout(() => {
              this.$router.go(-1)
            }, 1000)
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    // 发布
    release(num) {
      this.$refs.activitiesForm.validate().then(() => {
        this.num = num
        this.show = true
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    getApprove() {
      let param = {
        "opinion": this.reason,
        "processInstanceId": this.formData.processInstanceId,
        "projectId": this.formData.id,
        "status": this.num,
        "taskId": this.formData.taskId
      }
      if(this.role === 'teacher'){
        param.teachOpinion = this.formData.teachOpinion
      }else{
        if(!this.formData.sectionOpinion){
          this.$toast.fail('请选择科室意见')
          return
        }
        param.sectionOpinion = this.formData.sectionOpinion
      }
      outFamilyApprovalProcess(param).then(() => {
        this.$toast.success('操作成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },
    onTypeConfirm(value, index) {
      this.formData.checkinId = this.listInfo[index].id;
      this.formData.sectionName = value.text;
      this.formData.sectionId = value.value;
      this.showTypePicker = false;
    },

    onDateConfirm(value) {
      this.formData.applyTime = getNowFormatDate(value) + ':00'
      this.showDatePicker = false;
    },
    // 开始时间
    onStartDateConfirm(value) {
      this.formData.startTime = value
      this.showStartTimePicker = false;
    },
    // 结束时间
    onEndDateConfirm(value) {
      this.formData.endTime = value
      this.showEndTimePicker = false;
    },
    checkFn(data) {
      this.formData.teacherId = data.value
      this.formData.teacherName = data.text
      this.showPicker = false
      this.showTeacherPicker = false
      this.checkinTeacherFn()
    },
    // 结束活动
    activitiesOver() {
      let param = {
        ids: this.currentData.id,
      }
      checkinIntoFamily(param).then(() => {
        this.$toast.success('入科成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },
    // 选择带教老师
    checkinTeacherFn() {
      let p = {
        "transferFlag": !!this.currentData.transferId,
        "teacherId": this.formData.teacherId,
        "ids": this.currentData.id
      }
      checkinTeacher(p).then(() => {
      })
    }

  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    if (this.role === 'StudentType_jxs') {
      this.name = '申请填写'
      if(!this.currentData.id){
        let studentId = localStorage.getItem('studentId') || ''
        urlForGetCode('/transfercheckout/getCurrentCheckoutInfoByStudentId',studentId).then(res => {
          if(res.data.success){
            this.teacherStaffInfo = res.data.data
            this.$set(this.formData,'sectionName',this.teacherStaffInfo.sectionName)
            this.$set(this.formData,'sectionId',this.teacherStaffInfo.sectionId)
            this.$set(this.formData,'checkinId',this.teacherStaffInfo.checkinId)
          }else{
            Dialog.confirm({
              message: '当前不能提交出科申请!',
            }).then(()=>{
              this.$router.go(-1)
            }).catch(()=>{
              this.$router.go(-1)
            })
          }
        })
      }
    } else {
      this.name = '申请详情'
    }
    if(this.currentData.id){
      this.formData = {
        ...this.currentData
      }
    }
    // this.userId = localStorage.getItem('userId')
    // let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
    // this.ac_userId = localStorage.getItem('userId')
    // this.currentData = currentForm
    //
    // let len = Object.keys(currentForm).length
    // if (len === 0) {
    //   this.action = 3
    // } else {
    //   this.action = currentForm.status
    //   this.formData = Object.assign(this.formData, currentForm)
    // }
    localStorage.setItem('currentData', '')

  }
}
</script>
