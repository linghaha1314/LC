<template>
  <div class="about">
    <van-nav-bar title="注册选择" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 20px 12px; text-align: center; box-sizing: border-box; width: 100vw">
      <van-button v-for="item in typeList" :key="item.id" type="primary" style="margin: 24px 0;" round block @click="paramFn(item.code,item)">{{item.name}}</van-button>
    </div>
    <div style="padding: 20px 12px; text-align: center; box-sizing: border-box; width: 100vw" v-if="show">
      <div style="color:#17d4b5; font-size: 16px; text-align: center;" v-if="dataList.length === 0">当前没有开通报名通道!</div>
      <div type="primary" style="margin: 24px 0; background: #17d4b5; padding: 12px; border-radius: 6px; color: #ffffff;" @click="clickBtn(item)" v-for="item in dataList" :key="item.id">
        <h3>
          {{item['projectName'] || item.name}}
        </h3>
        <div v-if="item.startDate && item.endDate">
          报名时间: {{item.startDate.substring(0,10)}} 至 {{item.endDate.substring(0,10)}}
        </div>
        <div v-if="item['enrollment']">
          当前火热报名中,{{item['enrollment']}} 人已报名
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import { urlForPost } from '../http/apiMap';
  import XEUtils from 'xe-utils'
  import VXEUtils from 'vxe-utils'
  export default {
    name: 'sign-check',
    data() {
      return {
        url: {
          list: '/advancedsignup/getSignupBatch', // 获取批次,
          oList:'/advancedsignup/getSignupProject', // 政府指令性
          PractisingCategory: '/dictionary/getByTypeCode/AdvancedType',
        },
        param: '',
        show: false,
        dataList: [],
        typeList: []
      }
    },
    methods: {
      clickBtn(data) {
        // advancedsignup/getBatchByProjectId
        // 参数：
        // projectId：当前指令性项目的id
        if(this.param === 'MandatoryCommissionedTraining'){
          urlForPost('/advancedsignup/getBatchByProjectId', {
            projectId: data.id
          }).then(r => {
            const now = this.$utils.timestamp(new Date())
            const target = this.$utils.timestamp(r.data.data.endDate)
            if(now>target){
              this.$toast.fail('当前项目的报名批次已结束，请等待下一个批次!')
            }else{
              data.trainTypeCode = this.param
              localStorage.setItem('signInfo',JSON.stringify(data))
              this.$router.push({
                path: '/sign-phone'
              })
            }
          })
        }else{
          data.trainTypeCode = this.param
          localStorage.setItem('signInfo',JSON.stringify(data))
          this.$router.push({
            path: '/sign-phone'
          })
        }
      },
      paramFn(str,data) {
        this.param = str
        this.show = true
        localStorage.setItem('AdvancedType', data.id)
        if(str === 'MandatoryCommissionedTraining'){
          this.getOList()
        }else{
          this.getList()
        }
      },
      getType(){
        urlForPost(this.url.PractisingCategory).then(res => {
          this.typeList = res.data.data
        })
      },
      getList(){
        urlForPost(this.url.list,{
          trainTypeCode: this.param
        }).then(res => {
          this.dataList = res.data.list
        })
      },
      getOList() {
        urlForPost(this.url.oList, {
          status: '0'
        }).then(res => {
          this.dataList = res.data.list
        })
      }
    },
    mounted() {
      // let warningFlag = localStorage.getItem('warningFlag')
      // if(!warningFlag){
      //   this.$router.replace('/warning')
      // }
      this.getType()
    }
  }
</script>
