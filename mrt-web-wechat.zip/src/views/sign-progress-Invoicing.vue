<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-tabs v-model="active" animated>
      <van-tab title="单位" name="a">
      </van-tab>
<!--      <van-tab title="个人/其他" name="b">-->
<!--      </van-tab>-->
    </van-tabs>
    <van-form ref="activitiesForm">
      <van-field v-model="formData.fee" name="fee" label="开票金额" placeholder="" readonly
      />
      <van-field v-model="formData.content" name="content" label="开票内容" placeholder="" readonly
      />
      <van-field
          name="onlineFlag"
          label="票种"
          required :value="formData.fpzldm"
          :rules="[{ required: true, message: '请选择票种' }]"
      >
        <template #input>
          <van-radio-group disabled v-model="formData.fpzldm" direction="horizontal">
            <van-radio :name="51">普通发票(电子)</van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field v-model="formData.gfmc" name="gfmc" label="抬头" required placeholder="请填写企业名称或者开票代码"
                 :rules="[{ required: true, message: '请填写企业名称或者开票代码' }]"
      />
      <van-field v-if="active === 'a'" v-model="formData.gfsh" name="gfsh" label="税号" required
                 placeholder="请填写6~20位企业税号"
                 :maxlength="20"
                 show-word-limit
                 :rules="[{ required: true, message: '请填写6~20位单位税号' }]"
      />
      <van-field v-model="formData.gfsj" name="gfsj" label="手机号" required placeholder="请填写手机号"
                 :rules="[{ required: true, message: '请填写手机号' }]"
      />
      <van-field v-model="formData.gfemail" name="gfemail" label="邮箱" required placeholder="请填写邮箱"
                 :rules="[{ validator, message: '请填写邮箱' }]"
      />
      <div style="text-align: center; font-size: 14px; color: orangered;padding: 12px">
        以下是非必填项
      </div>
      <van-field v-model="formData.gfdzdh" name="gfdzdh" label="地址电话" rows="2" :autosize="true" type="textarea"
                 placeholder="非必填项-请填写单位注册地址和电话"
      />
      <van-field v-model="formData.gfyhzh" name="gfyhzh" label="开户行及账号" rows="2" :autosize="true" type="textarea"
                 placeholder="非必填项-请填写开户行及账号"
      />
      <div style="text-align: center; font-size: 16px; color: orangered;padding: 12px">
        请注意: 若开票,则无法退款
      </div>
      <div style="margin: 16px;">
        <van-button :disabled="disabledApply" round block color="#17d4b5" @click="onSubmit">
          申请开票
        </van-button>
      </div>

    </van-form>
  </div>
</template>
<script>
import {
  urlForPost
} from '../http/apiMap';
import { Dialog } from 'vant';

export default {
  name: 'test',
  data() {
    return {
      formData: {
        fpzldm: 51,
        fee: 2000,
        content: '培训费',
        gfsh: '',
        gfmc: '',
        gfsj: '',
        gfemail: '',
        gfdzdh: '',
        gfyhzh: '',
        pattern: /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/
      },
      active: '',
      name: '申请开票',
      orderData: this.$route.query,
      disabledApply: false
    }
  },
  methods: {
    onSubmit() {
      Dialog.confirm({
        title: '温馨提示:',
        message: '请认真核对开票信息，一经开票费用概不退还！',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        this.disabledApply = true
        this.$refs.activitiesForm.validate().then(() => {
          this.disabledApply = true
          urlForPost('/advancedpayonline/toInvoice', {
            orderNo: this.orderData.orderNo,
            staffId: this.orderData.staffId,
            signupId: this.orderData.signupId,
            gfdzdh: this.formData.gfdzdh,
            gfyhzh: this.formData.gfyhzh,
            gfmc: this.formData.gfmc,
            gfsh: this.formData.gfsh,
            gfemail: this.formData.gfemail,
            fpzldm: this.formData.fpzldm,
            gfsj: this.formData.gfsj
          }).then(res => {
            if (res.data.data.success) {
              this.$toast.success(res.data.data.message || '支付成功!')
            }else {
              Dialog.alert({
                message: res.data.data.message || '未知错误'
              }).then()
              this.disabledApply = false
            }
          })
        }).catch(() => {
          this.$toast.fail('请正确填写表单!')
        })
      })
    },
    validator(val) {
      return this.pattern.test(val);
    },
  },
  mounted() {
    this.formData.fee = this.orderData.payFee
    this.formData.gfmc = this.orderData.billingUnit
    this.formData.gfsh = this.orderData.taxNo
    this.formData.gfsj = this.orderData.mobile
    this.formData.gfemail = this.orderData.email
  }
}
</script>
