<template>
  <div class="about">
    <van-nav-bar title="相关证书" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        相关证书
      </div>
    </div>
    <div>
      <van-form ref="certificateForm">

        <van-field readonly clickable required name="staffTypeId" label="人员类别" :value="formData.staffTypeName" placeholder="选择人员类别"
          @click="showaDvancedStaffTypePicker = true" :rules="[{ required: true, message: '请选择人员类别' }]" />
        <van-popup v-model="showaDvancedStaffTypePicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams" code="advancedStaffType" @cancel="showaDvancedStaffTypePicker = false" @confirm="onConfirm($event,formData,'staffTypeName','staffTypeId','showaDvancedStaffTypePicker')"></m-picker>
        </van-popup>
        <van-popup v-model="showImg" @click="showImg = false">
          <van-image style="width: 100vw" v-if="formData.staffTypeName==='医师' && type_img==='zgz'" :src="require('../assets/advancedsignup/yszgz.jpg')"
            alt="暂无此照片" />
          <van-image style="width: 100vw" v-if="formData.staffTypeName==='护士' && type_img==='zgz'" :src="require('../assets/advancedsignup/hszgz.jpg')"
            alt="暂无此照片" />
          <van-image style="width: 100vw" v-if="formData.staffTypeName==='医师' && type_img==='zyz'" :src="require('../assets/advancedsignup/yszyz.jpg')"
            alt="暂无此照片" />
          <van-image style="width: 100vw" v-if="formData.staffTypeName==='护士' && type_img==='zyz'" :src="require('../assets/advancedsignup/hszyz.jpg')"
            alt="暂无此照片" />
          <van-image style="width: 100vw" v-if="type_img==='byz'" :src="require('../assets/advancedsignup/byz.jpg')" alt="暂无此照片" />
          <van-image style="width: 100vw" v-if="type_img==='sfz'" :src="require('../assets/advancedsignup/sfz.jpg')" alt="暂无此照片" />
          <van-image style="width: 100vw" v-if="type_img==='zyjsz'" :src="require('../assets/advancedsignup/zyjsz.jpg')" alt="暂无此照片"
          />

        </van-popup>
        <div v-if="formData.staffTypeName === '医师' || formData.staffTypeName === '护士'">
          <van-field v-model="formData.code" :label="formData.staffTypeName+'资格证书编码'" required :placeholder="'请输入'+formData.staffTypeName+'资格证书编码'" :rules="[{ required: true, message: '请输入资格证书编码' }]"/>

          <van-field readonly clickable name="certificateDate" required label="资格证书签发时间" :value="formData.certificateDate&&formData.certificateDate.substring(0,10)"
            placeholder="选择资格证书签发时间" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择资格证书签发时间' }]" />
          <van-popup v-model="showDatePicker" round position="bottom">
            <van-datetime-picker v-model="formData.dateValue" type="date" title="选择年月日" :min-date="minDate" @cancel="showDatePicker = false" @confirm="onDateConfirm($event,formData,'certificateDate','showDatePicker')"
            />
          </van-popup>

          <van-field v-model="formData['attachScore']" :label="formData.staffTypeName+'执业证书编码'" required :placeholder="'请输入'+formData.staffTypeName+'执业证书编码'" :rules="[{ required: true, message: '请输入执业证书编码' }]"/>

          <van-field readonly clickable name="passDate" required label="执业证书签发时间" :value="formData.passDate&&formData.passDate.substring(0,10)"
            placeholder="选择执业证书签发时间" @click="showPassDatePicker = true" :rules="[{ required: true, message: '请选择执业证书签发时间' }]"
          />
          <van-popup v-model="showPassDatePicker" round position="bottom">
            <van-datetime-picker v-model="formData.dateValue" type="date" title="选择年月日" :min-date="minDate" @cancel="showDatePicker = false" @confirm="onDateConfirm($event,formData,'passDate','showPassDatePicker')"
            />
          </van-popup>

          <van-field v-if="formData.staffTypeName === '护士'" readonly clickable required name="categoryId" label="执业证类别" :value="formData['categoryName']" placeholder="选择执业证类别"
                     @click="categoryPicker = true" :rules="[{ required: true, message: '请选择执业证类别' }]" />
          <van-popup v-model="categoryPicker" round position="bottom">
            <van-picker :columns="categoryColumns" :show-toolbar="true" @cancel="categoryPicker = false" @confirm="onConfirm($event,formData,'categoryName','categoryId','categoryPicker',getPracticeRangeColumns)"
            />
          </van-popup>

          <van-field v-if="formData.staffTypeName === '护士'" readonly clickable required name="practiceRangeId" label="执业证范围" :value="formData['practiceRangeName']" placeholder="选择执业证范围"
                     @click="practiceRangePicker = true" :rules="[{ required: true, message: '请选择执业证范围' }]" />
          <van-popup v-model="practiceRangePicker" round position="bottom">
            <van-picker :columns="practiceRangeColumns" :show-toolbar="true" @cancel="practiceRangePicker = false" @confirm="onConfirm($event,formData,'practiceRangeName','practiceRangeId','practiceRangePicker')"
            />
          </van-popup>

          <div style="text-align: center; color: orangered">上传前, 请先查看模板 <van-button type="primary" size="mini" @click="editProp('zgz')">查看模板</van-button></div>

          <van-field name="fileZiList" required :label="formData.staffTypeName+'资格证书'" @click="typeCode = 'Credentials'" :value="fileZiList[0]&&fileZiList[0].pathAttach" :rules="[{ required: true, message: '请上传资格证书' }]">
            <template #input>
              <van-uploader v-model="fileZiList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('zyz')">查看模板</van-button>
          </div>
          <van-field name="fileZhiList" required :label="formData.staffTypeName+'执业证书'" @click="typeCode = 'PracticeCertificate'" :value="fileZhiList[0]&&fileZhiList[0].pathAttach" :rules="[{ required: true, message: '请上传执业证书' }]">
            <template #input>
              <van-uploader v-model="fileZhiList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('byz')">查看模板</van-button>
          </div>
          <van-field name="fileBiList" required label="毕业证书" @click="typeCode = 'GraduationCertificate'" :value="fileBiList[0]&&fileBiList[0].pathAttach" :rules="[{ required: true, message: '请上传毕业证书' }]">
            <template #input>
              <van-uploader v-model="fileBiList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>

        </div>

        <div v-if="formData.staffTypeName === '医技' || formData.staffTypeName === '药剂'">
          <van-field v-model="formData.code" label="专业技术资格证书编码" required placeholder="请输入专业技术资格证书编码" />
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('zyjsz')">查看模板</van-button>
          </div>
          <van-field name="fileZiList" required label="专业技术资格证书" @click="typeCode = 'Credentials'" :value="fileZiList[0]&&fileZiList[0].pathAttach" :rules="[{ required: true, message: '请上传资格证书' }]">
            <template #input>
              <van-uploader v-model="fileZiList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('byz')">查看模板</van-button>
          </div>
          <van-field name="fileBiList" required label="毕业证书" @click="typeCode = 'GraduationCertificate'" :value="fileBiList[0]&&fileBiList[0].pathAttach" :rules="[{ required: true, message: '请上传毕业证书' }]">
            <template #input>
              <van-uploader v-model="fileBiList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('sfz')">查看模板</van-button>
          </div>
          <van-field name="fileXueList" required label="身份证" @click="typeCode = 'IdentityCard'" :value="fileXueList[0]&&fileXueList[0].pathAttach" :rules="[{ required: true, message: '请上传身份证' }]">
            <template #input>
              <van-uploader v-model="fileXueList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
        </div>

        <div v-if="formData.staffTypeName === '其它' || formData.staffTypeName === '管理'">
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('byz')">查看模板</van-button>
          </div>
          <van-field name="fileBiList" required label="毕业证书" @click="typeCode = 'GraduationCertificate'" :value="fileBiList[0]&&fileBiList[0].pathAttach" :rules="[{ required: true, message: '请上传毕业证书' }]">
            <template #input>
              <van-uploader v-model="fileBiList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
          <div style="text-align: center; color: orangered">上传前, 请先查看模板
            <van-button type="primary" size="mini" @click="editProp('sfz')">查看模板</van-button>
          </div>
          <van-field name="fileXueList" required label="身份证" @click="typeCode = 'IdentityCard'" :value="fileXueList[0]&&fileXueList[0].pathAttach" :rules="[{ required: true, message: '请上传身份证' }]">
            <template #input>
              <van-uploader v-model="fileXueList" :after-read="afterRead" :before-delete='beforeDelete' />
            </template>
          </van-field>
        </div>
      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button style="margin-bottom: 12px;" round block @click="goPre">
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          下一步
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
  // import { updateBymessageId, updateStatus, msgFile } from '../http/apiMap';
  import { uploadSignFile, urlForPost, getCertificate, getCertificatesByStaff } from "../http/apiMap";

  import mPicker from '../components/m-picker'
  export default {
    name: 'certificate',
    components: {
      mPicker
    },
    data() {
      return {
        url: {
          PractisingCategory: '/advancedsignup/getByCode/PractisingCategory',
          listPracticingRangeByPage: '/advancedsignup/listPracticingRangeByPage',
          create: '/advancedsignupattach/create',
          save: '/advancedsignup/saveOrUpdateStaffCertification',
          removeFile: '/advancedsignupattach/attachDeleteFile',
          removeData: '/advancedsignupattach/remove',
          saveStaff: '/advancedsignup/saveOrUpdateStaff',
          advancedSignup: '/advancedsignup/saveOrUpdateAdvancedSignup',
          certificate: '/advancedsignup/getCertificatesByStaff'
        },
        active: 0,
        formData: {},
        showImg: false,
        showSectionPicker: false,
        categoryPicker: false,
        practiceRangePicker: false,
        showMajorPicker: false,
        showaDvancedStaffTypePicker: false,
        showDatePicker: false,
        showPassDatePicker: false,
        categoryColumns: [],
        practiceRangeColumns: [],
        majorColumns: [],
        fileZiList: [],
        fileZhiList: [],
        fileBiList: [],
        fileXueList: [],
        saveArr: [
          {file: 'fileZiList', code: 'Credentials'},
          {file: 'fileZhiList', code: 'PracticeCertificate'},
          {file: 'fileBiList', code: 'GraduationCertificate'},
          {file: 'fileXueList', code: 'IdentityCard'}
        ],
        minDate: new Date(1970, 1, 1),
        typeCode: '',
        type_img: '',
        signupId: sessionStorage.getItem('signupId') || '',
        staffId: sessionStorage.getItem('staffId'),
        projectInfo:  JSON.parse(localStorage.getItem('signInfo'))
      }
    },
    computed: {

    },
    methods: {

      onConfirm(value, target, name, id, show, cb) {
        target[name] = value.text
        target[id] = value.value
        this[show] = false;
        if (cb) {
          cb()
        }
      },
      goPre() {
        this.$router.push({
          path: '/sign-write-contact'
        })
      },
      attendAdd() {
        this.$refs.certificateForm.validate().then(() => {
          sessionStorage.setItem('fileObj', JSON.stringify(this.fileObj))
          this.formData.staffId = sessionStorage.getItem('staffId');
          let batchId;
          if(this.projectInfo.trainTypeCode!=='MandatoryCommissionedTraining'){
            batchId = this.projectInfo.id
          }else{
            let batchData = JSON.parse(sessionStorage.getItem('majorData'))
            batchId = batchData.batchId
          }
          urlForPost(this.url.advancedSignup, {
            id: sessionStorage.getItem('signupId'),
            staffId: this.staffId,
            batchId: batchId,
            staffTypeId: this.formData.staffTypeId
          }).then()
          let param = {...this.formData}
          param.passDate = param["passDateTime"] || param.passDate
          param.certificateDate = param["certificateDateTime"] || param.certificateDate
          param.typeId = param.staffTypeId
          urlForPost(this.url.save, param).then(res => { // 证书
            if(res.data && res.data.success){
              sessionStorage.setItem('certificateData', JSON.stringify(this.formData))
              this.formData.id = res.data.data.id
            }
            this.$router.push({
              path: '/sign-write-education'
            })
          })
        }).catch(() => {
          this.$toast.fail('请正确填写表单!')
        })
      },
      afterRead(file) {
        let data = new FormData()
        data.append('multipartFile', file.file)
        uploadSignFile(data).then(res => {
          file.pathAttach = res.data.path
          this.saveAttach(res.data.path, file)
        })
      },
      beforeRead(file) {
        if (file.type === 'image/jpeg' || file.type === 'image/png') {
          return true;
        } else {
          this.$toast.fail('请上传图片');
          return false;
        }
      },
      beforeDelete(file){
        urlForPost(this.url.removeFile,{
          path: file.pathAttach
        }).then()
        urlForPost(this.url.removeData + "/" + file.id).then(()=>{
          this.getCertificateFn()
        })
      },
      onDateConfirm(value, target, prop, show) {
        target[prop + 'Time'] = this.getNowFormatDate(value) + ' 00:00:00'
        target[prop] = this.getNowFormatDate(value)
        this[show] = false;
      },
      getNowFormatDate(date) {
        let seperator1 = "-";
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let strDate = date.getDate();
        if (month >= 1 && month <= 9) {
          month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
        }

        return year + seperator1 + month + seperator1 + strDate;
      },
      // 获取picker数据格式
      getData(url, params, target, prop = 'name', propId = 'id') {
        urlForPost(url, params).then(res => {
          let optionArr = []
          res.data.list.forEach(item => {
            let obj = {
              text: item[prop],
              value: item[propId]
            }
            optionArr.push(obj)
          })
          this[target] = optionArr
        })
      },
      saveAttach(path, objFile) {
        let param = {
          "signupId": sessionStorage.getItem('signupId'),
          "typeCode": this.typeCode,
          "path": path
        }
        urlForPost(this.url.create,param).then(res => {
          objFile.id = res.data.data["reasons"].data.id
        })
      },
      getPracticeRangeColumns(){
        this.getData(this.url.listPracticingRangeByPage, {
          pageSize: 999,
          pageNum: 1,
          categoryId: this.formData.categoryId
        }, 'practiceRangeColumns')
      },
      getCertificateFn(code=''){
        if(this.signupId){
          getCertificate({
            "signupId": this.signupId,
            "typeCode": code,
            "pageSize": 999,
            "pageNum": 1
          }).then(res => {
            let data = res.data.list
            data.forEach(item => {
              this.saveArr.forEach(ite => {
                if(item.typeCode === ite.code){
                  this[ite.file].push({
                    url: item.path,
                    pathAttach: item.path,
                    id: item.id
                  })
                }
              })
            })
          })
        }
      },
      // 缓存本地
      getSession(){
        sessionStorage.setItem('certificateData', JSON.stringify(this.formData))
        sessionStorage.setItem('fileObj', JSON.stringify(this.fileObj))
      },
      certificateInfo(){
        let data = JSON.parse(sessionStorage.getItem('identifyNoInfo') || '{}')
        if(data.id){
          urlForPost(this.url.certificate, {
            "hospitalId": data.hospitalId,
            "staffId": data.id
          }).then(res => {
            if(res.data.data&& res.data.data.id){
              let rInfo = res.data.data
              rInfo.staffTypeName = rInfo.typeName
              rInfo.staffTypeId = rInfo.typeId
              let obj = this.removePropertyOfNull(rInfo)
              this.$set(this,'formData',{...obj})
            }
          })
        }
      },
      removePropertyOfNull(obj) {
        Object.keys(obj).forEach(item => {
          if (!obj[item]) delete obj[item]
        })
        return obj;
      },
      editProp(str){
        this.showImg=true
        this.type_img=str
      }
    },
    mounted() {
      let info = sessionStorage.getItem('certificateData')
      if (info) {
        this.formData = { ...JSON.parse(info) }
      } else {
        let identifyNoInfo = JSON.parse(sessionStorage.getItem('identifyNoInfo') || '{}')
        let staffBatchInfo = {};
        let cardInfo = {};
        if (sessionStorage.getItem('staffBatchInfo') !== 'undefined') {
          staffBatchInfo = JSON.parse(sessionStorage.getItem('staffBatchInfo') || '{}')
        }
        if (sessionStorage.getItem('cardInfo') !== 'undefined') {
          cardInfo = JSON.parse(sessionStorage.getItem('cardInfo') || '{}')
        }
        let obj = {}
        if (identifyNoInfo.id || staffBatchInfo.id || cardInfo.id) {
          let data = JSON.parse(localStorage.getItem('signInfo'))
          let param = {
            hospitalId: data.hospitalId,
            staffId: sessionStorage.getItem('staffId')
          }
          getCertificatesByStaff(param).then(res => {
            if(res.data&& res.data.success){
              let obj = res.data.data || {}
              if(obj.typeId){
                obj.staffTypeId = obj.typeId
                obj.staffTypeName = obj.typeName
              }
              this.formData = {...obj}
            }
          })

          this.formData = { ...obj }
        } else {
          this.formData = {}
        }
      }
      this.fileObj = JSON.parse(sessionStorage.getItem('fileObj') || '{}')
      this.getData(this.url.PractisingCategory, {
        pageSize: 999,
        pageNum: 1
      }, 'categoryColumns')
      // 获取文件上传的数据
      this.getCertificateFn()
      this.certificateInfo()
    }
  }
</script>
