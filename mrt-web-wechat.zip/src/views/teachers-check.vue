<template>

  <div style="height: 100vh">
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.push('/home')">返回</span>
      </template>
    </van-nav-bar>
    <div style="display: flex; flex-direction: column;justify-content: center;height: 82vh;padding: 24px;">
<!--      <router-link v-if="role === 'JXS_manager'" to="/teachers-nursing">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          护理师资审核人员设置-->
<!--        </van-button>-->
<!--      </router-link>-->
<!--      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'" :to="{path: '/teachers',query: {type: 'teacher-library'}}">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          新增师资-->
<!--        </van-button>-->
<!--      </router-link>-->
      <router-link v-if="role === 'teacher'" :to="{path: '/teachers',query: {type: 'teacher-apply'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          带教老师申请
        </van-button>
      </router-link>
      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"  :to="{path: '/teachers',query: {type: 'teacher-approve'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          带教老师审批
        </van-button>
      </router-link>
<!--      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"  :to="{path: '/teachers',query: {type: 'tutor-approve'}}">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          进修导师审批-->
<!--        </van-button>-->
<!--      </router-link>-->
      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"  :to="{path: '/teachers',query: {type: 'teacher-query'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          师资查询
        </van-button>
      </router-link>
      <router-link v-if="role === 'tutor'" :to="{path: '/teachers',query: {type: 'tutor-apply'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          进修导师申请
        </van-button>
      </router-link>

<!--      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"  :to="{path: '/teachers',query: {type: 'tutor-query'}}">-->
<!--        <van-button round block color="#17d4b5">-->
<!--          进修导师查询-->
<!--        </van-button>-->
<!--      </router-link>-->

    </div>
  </div>

</template>
<script>
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {

      role: ''
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {

  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')

  }
}
</script>
