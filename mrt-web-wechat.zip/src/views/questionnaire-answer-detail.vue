<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell :title="index+1+'、'+item.question" v-for="(item,index) in answer" :key="index">
          <template #label>
            <div>回答：{{item['answer']||'无'}}</div>
          </template>
        </van-cell>
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {urlForPost} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: '问卷填写详情',
      answer: []
    }
  },
  computed: {
  },
  methods: {
  },
  mounted() {
    urlForPost('/surveyanswerlist/getQuestionItem',{
      staffId: this.currentData.staffId,
      answerId: this.currentData.id
    }).then(res => {
      this.answer = [
          ...res.data.data
      ]
    })
    // this.certificateInfo()
  }
}
</script>
