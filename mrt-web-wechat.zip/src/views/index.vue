<template>
  <div>
    <div style="padding: 12px; border-bottom: 1px solid #efefef">
      <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
        <van-swipe-item>
          <van-image :src="require('../assets/img/banner-1.png')" />
        </van-swipe-item>
        <van-swipe-item>
          <van-image :src="require('../assets/img/banner-2.png')" />
        </van-swipe-item>
      </van-swipe>
    </div>
<!--    <div style="display: flex;">-->
<!--      <div-->
<!--          style="width: 22%;display: flex;justify-content: right; align-items: center; font-size: 14px;font-weight: bold">-->
<!--                <span style="color: #17d4b5">-->
<!--                    进修-->
<!--                </span>头条-->
<!--      </div>-->
<!--      <div style="flex: 1">-->
<!--        <van-notice-bar-->
<!--            background="#fff"-->
<!--            color="#999"-->
<!--            text="在代码阅读过程中人们说脏话的频率是衡量代码质量的唯一标准。"-->
<!--        />-->
<!--      </div>-->
<!--    </div>-->
    <!--间隔-->
    <div style="width:100%; height: 10px; background: #f6f6f6"></div>
    <div>

      <van-grid :border="false" square>
        <van-grid-item v-for="value in menuData" :key="value.name"  :icon="value.code" :text="value.name" @click="goUrl(value)"/>
      </van-grid>
    </div>
    <!--间隔-->
    <div style="width:100%; height: 10px; background: #f6f6f6"></div>
    <div style="display: flex;">
      <div
          style="padding: 4px 12px; display: flex; align-items: center; font-size: 16px;font-weight: bold; min-height: 28px">
                <span style="color: #17d4b5">
                    最新
                </span>资讯
      </div>
    </div>
    <van-list
    >
      <van-cell v-for="item in list" :key="item.id" :title="item.title" is-link @click="toNews(item)"/>
      <div style="text-align: center; margin: 12px;" @click="onLoad">
        {{isMore? '点击加载更多...' : '没有更多了'}}
      </div>
    </van-list>
  </div>
</template>

<script>
    import { getListQueryByPage, getMyFunctions } from '../http/apiMap.js'
    export default {
        name: "index.vue",
        data (){
            return{
                isMore: true,
                menuData:[],
                list: [],
                loading: false,
                finished: false,
                newsParam: {
                    infoType:"news",
                    pageSize: 10,
                    pageNum: 1
                }
            }
        },
        methods:{
            goUrl(data){
                sessionStorage.setItem('listParams', '')
                this.$router.push(data.url)
            },
            getNews(){
                if(this.isMore){
                    getListQueryByPage(this.newsParam).then( res =>{
                        this.list = this.list.concat(res.data.list)
                        this.newsParam.pageNum++
                        // 数据全部加载完成
                        if (res.data.lastPage) {
                            this.isMore = false;
                        }
                    })
                }
            },
            onLoad() {
                // 异步更新数据
                this.getNews()
            },
            toNews(data){
                this.$router.push({
                    path: '/news',
                    query: data
                })
            }
        },
        mounted() {
            getMyFunctions({ // 加载菜单
                roleId: sessionStorage.getItem('roleId') || '',
                child: 1
            }).then(res => {
                this.menuData = res.data.list;
            })
            this.getNews()
        }
    }
</script>

<style scoped>
  .my-swipe .van-swipe-item {
    color: #fff;
    font-size: 20px;
    text-align: center;
  }
</style>