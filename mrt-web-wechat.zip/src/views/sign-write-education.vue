<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div style="background: #f6f6f6; padding: 12px;">
      <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
        v-for="data in testData" :key="data.title"
      >
        <van-divider/>
        <div @click="goDetail(data)">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学校名称：</div>
            <div>{{data['school']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学历：</div>
            <div>{{data['academicName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学位：</div>
            <div>{{data['degreeName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">所学专业:</div>
            <div>{{data.subject || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学制:</div>
            <div>{{data['schoolYears']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">开始日期:</div>
            <div>{{data.startDate && data.startDate.substring(0,10) || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">结束日期:</div>
            <div>{{data.endDate && data.endDate.substring(0,10) || '无'}}</div>
          </div>
        </div>
        <div style="text-align: right;">
          <van-button type="warning" size="mini" @click="delEducation(data)">删除学历</van-button>
        </div>
      </div>
      <div style="position: fixed;right: 26px;bottom: 70px">
        <van-icon color="#ff0000" name="add" size="40" @click="addFn"/>
      </div>
    </div>
    <div style="margin: 30px 16px 16px;display: flex;">
      <van-button style="margin-bottom: 12px;" round block @click="goPre">
        上一步
      </van-button>
      <van-button round block color="#17d4b5" @click="attendAdd">
        下一步
      </van-button>
    </div>
  </div>
</template>
<script>
  import {Dialog} from 'vant';
  import {urlForPost} from '../http/apiMap';

  export default {
    name: 'test',
    data() {
      return {
        url: {
          list: '/advancedsignup/listEduBackgroudByPage',
          advancedSignup: '/advancedsignup/saveOrUpdateAdvancedSignup',
          remove: '/advancedsignup/removeEduBackground'
        },
        testData: [],
        pageParam: {
          staffId: sessionStorage.getItem('staffId') || '',
          pageSize: 999,
          pageNum: 1,
          dateDesc: true
        },
        name: '学历信息'
      }
    },
    computed: {},
   
    methods: {
      goDetail(data) {
        localStorage.setItem('currentEducationData', JSON.stringify(data))
        this.$router.push({
          path: '/sign-write-education-add',
          query: data
        })
      },
      
      deleteFn() {
        Dialog.confirm({
          title: '温馨提示:',
          message: '确认删除么?',
          confirmButtonColor: '#17d4b5'
        }).then(() => {
          let removeArr = []
          this.testData.forEach(item => {
            if (item.checked) {
              removeArr.push(item.id)
            }
          })
          if (removeArr.length === 0) {
            this.$toast.fail('请勾选后操作!')
          } 
        })
      },
      
      getList() {
        urlForPost(this.url.list,this.pageParam).then(res => {
          this.testData = res.data.list
        })
      },
      goPre() {
        this.$router.push({
          path: '/sign-write-certificate'
        })
      },
      attendAdd() {
        if(this.testData.length !== 0){
          urlForPost(this.url.advancedSignup,{
            id: sessionStorage.getItem('signupId'),
            staffId: sessionStorage.getItem('staffId'),
            academicId: this.testData[0].academicId,
            degreeId: this.testData[0].degreeId,
            academicSchool: this.testData[0]["school"]
          }).then(() => {
              this.$router.push({
                path: '/sign-write-work'
              })
          })
        }else{
          this.$toast.fail('请先添加学历!')
        }
      },
      delEducation(data){
        urlForPost(this.url.remove, [data.id]).then(res => {
          if(res.data.success){
            this.$toast.fail('删除成功!')
            this.getList()
          }else{
            this.$toast.fail('删除失败!')
          }
        })
      },
      addFn(){
        localStorage.setItem('currentEducationData', '')
        this.$router.push({
          path:'/sign-write-education-add'
        })
      }
    },
    mounted() {
      this.getList();
    }
  }
</script>