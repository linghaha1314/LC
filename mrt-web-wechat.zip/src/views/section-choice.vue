<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>

    <div v-if="role !== 'StudentType_jxs'">
        <van-dropdown-menu active-color="#17d4b5">
<!--            <van-dropdown-item :title="dropdownTitle" v-model="listParams.sectionId" @change="leaveListGet" :options="option2" />-->
          <van-dropdown-item title="年度" v-model="listParams.enrollYear" @change="leaveListGet" :options="option1"/>
          <van-dropdown-item :title="dropdownTitles" v-model="listParams.status" @change="leaveListGet" :options="option3" />
          <van-dropdown-item title="专业" v-model="listParams.mobileMajorId" @change="leaveListGet" :options="majorOption" />
        </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <div>
        <van-search v-model="listParams.name" shape="round" @change="leaveListGet" placeholder="搜索" />
      </div>
      <div style="background: #f6f6f6; padding: 12px;">
        <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
          <van-list
              v-model="state.loading"
              :finished="state.finished"
              finished-text="没有更多了"
              @load="onLoad"
          >
            <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px" v-for="data in testData"
                 :key="data.title">
              <div>
                <div style="font-size: 14px;display: flex;justify-content: space-between;">
                  {{data['staffName'] || '无'}}
                  <div style="width: 4em; margin-left: 12px">
                    <van-tag style="text-align: center" :type="'primary'" v-if="data.status===3" size="medium">待录取</van-tag>
                    <van-tag style="text-align: center" :type="'danger'" v-if="data.status===4" size="medium">不录取</van-tag>
                    <van-tag style="text-align: center" :type="'warning'" v-if="data.status===5 || data.status===6 || data.status===7 || data.status===8 || data.status===12" size="medium">已录取</van-tag>
<!--                    <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交</van-tag>-->
                  </div>
                </div>
                <van-divider />
                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">报名学员:</div>
                  <div>{{data['staffName'] || '无'}}</div>
                </div>
                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">科室:</div>
                  <div>{{data.sectionName}}</div>
                </div>
                <div style="margin-bottom: 10px" v-if="data.majorName">
                  <div style="color: #cccccc;margin-bottom: 4px;">专业:</div>
                  <div>{{data.majorName}}</div>
                </div>
                <div style="margin-bottom: 10px" v-if="data['gradationTypeName']">
                  <div style="color: #cccccc;margin-bottom: 4px;">期限:</div>
                  <div>{{data['periodName']}}</div>
                </div>

                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">报名时间:</div>
                  <div>{{data.created.substring(0,10)}}</div>
                </div>
                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">选送单位:</div>
                  <div>{{data.billingUnit || '无'}}</div>
                </div>
              </div>
              <div style="text-align: right;">
                <van-button style="width: 5em" v-if="data.status === 3" type="primary" size="mini" @click="processFn(data,5)">录取</van-button>
                <van-button style="width: 5em" v-if="data.status === 3" type="danger" size="mini" @click="processFn(data,4)">不录取</van-button>
                <van-button style="width: 50px; margin-right: 12px"
                            size="mini" @click="goDetail(data)">查看
                </van-button>
              </div>
            </div>
          </van-list>
        </van-pull-refresh>

      </div>
      <div v-if="role === 'StudentType_jxs'" style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>
    </div>
    <van-dialog v-model="show" confirmButtonColor="#17d4b5" :title="this.num === 4?'确定此操作么? 请输入理由':'确定此操作么?'" show-cancel-button @cancel="show = false" @confirm="getApprove(num, notTarget)">
        <van-field v-if="this.num === 4" v-model="auditOpinion" label="理由" placeholder="请输入理由" />
    </van-dialog>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getTransferSchedule,
  advancedsignupList,
  getApplyInfo,
  urlForPost, urlForGet,
} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      url: {
        update: '/advancedsignup/update'
      },
      reason: '',
      show: false,
      listParams: {
        type: 'enroll',
        pageSize: 10,
        pageNum: 0,
        mobileMajorId: '',
        name: ''
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option1: [],
      option2: [],
      majorOption: [],
      option3: [
        {text: '全部', value: null},
        {text: '待录取', value: 3},
        {text: '不录取', value: 4},
        {text: '已录取', value: 5},
      ],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      studentInfo: {},
      state:{
        loading: false,
        finished: false,
        refreshing: false
      },
      auditOpinion: '',
      num: null
    }
  },
  computed: {
    name() {
      return this.$route.name
    },
    dropdownTitle(){
      let title = '科室'
      this.option2.forEach(item => {
        if(item.value === this.listParams.sectionId){
          title = item.text
        }
      })
      return title
    },
    dropdownTitles(){
      let title = '状态'
      this.option3.forEach(item => {
        if(item.value === this.listParams.status){
          title = item.text
        }
      })
      return title
    }
  },
  methods: {
    goDetail(data) {
      sessionStorage.setItem('listParams', JSON.stringify(this.listParams))
      this.$router.push({
        path: '/department-student-detail',
        query: data
      })
    },
    onRefresh(){
      // 清空列表数据
      this.state.finished = false;


      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad(){
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    // 获取申请列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }

      advancedsignupList(params).then(res => {
        if(f==='onLoad'){
          this.state.loading = false;
          if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
            this.state.finished = true
          }
          if(res.data.total === 0){
            this.testData = []
          }else{
            this.testData = [...this.testData, ...res.data.list];
          }
        }else{
          this.testData = [...res.data.list];
        }
      })
    },

    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },
    // 通过审批
    getApprove(num, target) {
      let param = {
        "id": target.id,
        "auditOpinion": this.auditOpinion,
        "status": num,
      }
      urlForPost(this.url.update,param).then(res => {
        if(res.data.data.success){
          this.$toast.success({
            message: '操作成功!',
            duration: 2000
          })
          this.leaveListGet();
        }
        else{
          this.$toast.fail({
            message: '操作失败!',
            duration: 2000
          })
        }
      })
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    // 判断是否有正在审核的申请
    addLeave() {
      let flag = true
      this.testData.forEach(item => {
        if (item.status === 11) {
          flag = false
          this.$toast.fail('您已有还在审核的申请, 请耐心等待!')
        }
        if (item["returnStatus"] !== 2) {
          if (item.status === 1) {
            this.$toast.fail('您的申请未通过, 请编辑驳回的申请后重试!')
          } else {
            this.$toast.fail('您已有还在完成的申请, 请申请后重试!')
          }
          flag = false
        }
      })
      if (flag) {
        this.$router.push({
          path: '/graduation-add'
        })
      }
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    processFn(data,status){
      if(status === 4){
        this.show = true
        this.num = status
        this.notTarget = data
      }else{
        Dialog.confirm({
          title: '温馨提示:',
          message: '确定此操作么?',
          confirmButtonColor: '#17d4b5'
        }).then(() => {
          this.getApprove(status,data)
        }).catch(() => {
          this.$toast.fail('取消操作!')
        })
      }
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
    // 获取专业
    getListMajor(){
      urlForGet('/student/getSectionId').then(r => {
        urlForPost('/submajor/getListQueryByPage',{
          pageSize: 999,
          sectionId: r.data.data,
          pageNum: 1
        }).then(res => {
          let optionArr = [
            { text: '全部', value: '' }
          ]
          res.data.list.forEach(item => {
            let obj = {
              text: item.sectionName+' - '+item.name,
              value: item.id,
              ...item
            }
            optionArr.push(obj)
          })
          this.majorOption = [...optionArr]
        })
      })

    },
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let listP = sessionStorage.getItem('listParams') || null
    if(listP){
      this.listParams = JSON.parse(listP)
    }
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.leaveListGet() // 获取申请列表
    this.transferGet() // 获取科室数据
    this.getYear() // 获取年度
    this.getListMajor() // 获取专业
  },

}
</script>
