<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.replace({
        path: '/home'
        })" style="color: #17d4b5">首页</span>
      </template>
      <template #right v-if="ac_list.length>1">
        <span @click="show=true" style="color: #17d4b5">列表</span>
      </template>
    </van-nav-bar>
    <div v-if="type !== '1'">
      <van-cell-group>
        <van-cell title="活动标题" :value="currentData.subject" />
        <van-cell title="主讲人" :value="currentData.teacherName" />
        <van-cell title="活动地址" :value="currentData.location" />
        <van-cell title="活动日期" :value="currentData.startDate && currentData.startDate.substring(0,10) || '无'" />

        <div style="width:100%; height: 7px; background: #f6f6f6"></div>

        <van-cell title="开始时间" :value="currentData.startTime" />
        <van-cell title="结束时间" :value="currentData.endTime" />

        <div style="width:100%; height: 7px; background: #f6f6f6"></div>

        <van-cell title="活动类型" :value="currentData.typeName" />
        <van-cell title="备注信息" :value="currentData.remark" />

        <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      </van-cell-group>
    </div>
    <div v-if="type === '1'">
      <van-cell-group>
        <van-cell title="活动标题" value="岗前培训" />
        <van-cell title="活动地址" :value="currentData.address" />
        <van-cell title="活动日期" :value="currentData.startDate && currentData.startDate.substring(0,10) || '无'" />


        <van-cell title="开始时间" :value="currentData.startTime" />
        <div style="width:100%; height: 7px; background: #f6f6f6"></div>
        <van-cell title="上午签到" :value="currentData['amCheckTime'] || '未签到'" />
        <van-cell title="下午签到" :value="currentData['pmCheckTime'] || '未签到'" />


        <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      </van-cell-group>
    </div>
    <div v-if="type !== '1'">
      <div style="border-left: 4px solid #17D4B5;margin: 8px 12px;padding: 0 4px;">
        签到记录
      </div>
      <div v-if="currentData.checkTime" style="margin: 8px 12px;color: #878787">
        <div>
          签到日期: {{currentData.checkTime.substring(0,10)}}
        </div>
        <div style="margin: 8px 0;color: #373A40;font-size: 14px">
          签到时间 {{currentData.checkTime.substring(11)}}
        </div>

      </div>
      <div v-if="!currentData.checkTime" style="margin: 8px 12px;color: #878787">
        无
      </div>
    </div>
    <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    <div v-if="!currentData.checkTime" style="text-align: center;color: #878787;margin-top: 12px;">
      <div>
        {{currentDate.getFullYear()}}年{{currentDate.getMonth()+1}}月{{currentDate.getDate()}}日
      </div>
      <div style="font-size: 36px;color: #373A40;">
        {{getNowTime}}
      </div>
    </div>
    <van-form v-if="!currentData.checkTime">

      <div style="margin: 16px auto;width: 200px"  v-if="action===3">

        <van-button v-if="!isSign" style="font-size: 16px" round block color="#17d4b5" :disabled="isDisabled || timeUp" @click="signFn">
          {{returnSign}}
        </van-button>
        <van-button v-if="isSign" disabled style="font-size: 16px" round block color="#17d4b5">
          已签到
        </van-button>
        <!--        <van-button style="font-size: 16px" round block color="#17d4b5" @click="signFn">-->
        <!--          测试签到-->
        <!--        </van-button>-->
      </div>
    </van-form>
    <div style="width: 100%;">
<!--      <van-icon name="location-o" color="#17D4B5"/>  @click="goToMap"-->
<!--      {{address || '无'}}-->
      <div style="text-align: center; color: #333333;margin: 12px 0;">小提示：位置在圈内才可以打卡哦！</div>
      <div id="container"></div>
    </div>

    <van-popup
            v-if="ac_list.length>1"
            v-model="show"
            round
            position="bottom"
            :style="{height: '60%'}">
      <div style="text-align: center; color: orangered; padding: 12px 0">您有多个活动待打卡,请选当前活动!</div>
      <van-cell-group style="margin: 20px 0;">
        <van-cell :title="ac.subject" :value="ac.teacherName" v-for="ac in ac_list" :key="ac.id" @click="checkAc(ac)"/>
      </van-cell-group>
    </van-popup>
    <div>{{st}}</div>
  </div>
</template>
<script>
  import { Dialog } from 'vant';
  import wx from 'weixin-js-sdk';
  import {
    getTeachactivity,
    getActivityMember,
    preJobTrainingUpdate,
    preJobTrainingRecord,
    signAddress,
    getSignWx
  } from '../http/apiMap';
  import AMapLoader from '@amap/amap-jsapi-loader';
  import axios from 'axios'
  export default {
    name: 'test',
    data(){
      return{
        showPicker: false,
        showTypePicker: false,
        showDatePicker: false,
        showStartTimePicker: false,
        showEndTimePicker: false,
        getNowTime: '',
        action: 3,
        show: true,
        currentData: {
          title: '活动',
          people: '某老师'
        },
        ac_list: [],
        columns: ['王老师', '李老师', '刘老师'],
        minDate: new Date(),
        maxDate: new Date(2025, 10, 1),
        currentDate: new Date(),
        currentTime: '12:00',
        currentEndDate: '12:00',
        formData:{
          title: '',
          address: '',
          peopleValue: '',
          dateValue: '',
          startValue: '',
          endValue: '',
          typeValue: '',
          content: '',
          remake: '',
          uploader: []
        },
        listParams: {
          pageSize: 999,
          pageNum: 1,
          QrCode:1
        },
        option1: [
          { text: '教学查房', value: 'Rounds-One' },
          { text: '病案讨论', value: 'Discussion' },
          { text: '读书报告', value: 'Report' },
          { text: '小讲课', value: 'lecture' },
          { text: '理论授课', value: 'theory_teaching' },
          { text: '技能培训', value: 'SkillTraining' },
          { text: '专题培训', value: 'special_training' },
          { text: '主任查房', value: 'director_round' },
        ],
        type: window.location.href.split('=')[1] || this.$route.query.id,
        isSign: false,
        localData:[],
          isDisabled: true,
          timeUp: true,
        // btnStr: '未在打卡时间',
        apiList:[
          'scanQRCode',
          'getLocation'
        ],
        name:'活动签到',
        map:null,
        st:'',
        mapKey:'2907987da4053f3160937e0b10625ede',
        mapKey1:'ba6087354935a856736e10736fbfb718',
        secretKey: '6a1677887774db9c58d6a76f7c57d06b',
        loc:[],
        distanceFlag: 800
      }
    },
    computed:{
      returnSign(){
        if(!this.isDisabled && !this.timeUp){
          return '签到'
        }else if(this.isDisabled && !this.timeUp){
          return '未在打卡范围'
        } else if (!this.isDisabled && this.timeUp) {
          return '未在打卡时间'
        }else{
          return '未在打卡范围也未在打卡时间'
        }

        //  ? '签到' : isDisabled ? '未在打卡范围' : timeUp ? '未在打卡时间'
      }
    },
    methods:{
      // 动态更新时间
      nowTime(){
        setInterval(()=>{
          let nowDate = new Date();
          let h = nowDate.getHours()<10?"0" + nowDate.getHours():nowDate.getHours();
          let m = nowDate.getMinutes()<10?"0" + nowDate.getMinutes():nowDate.getMinutes();
          let s = nowDate.getSeconds()<10?"0" + nowDate.getSeconds():nowDate.getSeconds();
          this.getNowTime = h+ ":" + m+ ":" + s;
        },1000)
      },
      // 签到
      signFn(){
        let role = localStorage.getItem('roleCode')
        if(role !== 'StudentType_jxs'){
          this.$toast.fail('您不是学生,请勿打卡!')
          this.isDisabled = true
          return false;
        }
        Dialog.confirm({
          title: '标题',
          message: '确认签到么?',
          confirmButtonColor: '#17d4b5'
        }).then(()=>{
          if(this.type==='1'){
            let preParam = {
              "id": this.currentData.id
            }
            let timeObj = new Date();
            let time = timeObj.getHours()
            if(time<12){
              preParam.amSigninFlag = true
            }else{
              preParam.pmSigninFlag = true
            }
            preJobTrainingUpdate(preParam).then((res)=>{
              if(res.data.status===0 && res.data.data.success === true){
                this.$toast.success('签到成功!')
                setTimeout(()=>{
                  this.$router.replace({
                    path: '/home'
                  })
                },1000)
              }else{
                this.$toast.fail('签到失败!')
              }
            })
          }else{
            if(!this.currentData.id){
              this.$toast.fail('您还没选择签到的活动!')
            }else{
                getActivityMember({
                  activityId: this.currentData.id
                }).then(() => {
                  this.$toast.success('签到成功!')
                  setTimeout(()=>{
                    this.$router.replace({
                      path: '/home'
                    })
                  },1000)
                })
            }
          }
        })
      },
      // 选择活动
      checkAc(data){
        this.currentData = data;
        this.show = false;
        this.checkTime(data);
      },
      // 获取列表
      getList(){
        let param = {...this.listParams}
        // if(this.type==='2'){
        //     param = {
        //         ...this.listParams
        //     }
        //     param.typeId = '63e37fba-85df-11ea-8355-00163e0603fa'
        // }else {
        //     param = {
        //         ...this.listParams,
        //         "notTypeCode":"admission_training"
        //     }
        // }
        getTeachactivity(param).then(res => {
          this.ac_list = res.data.list;
          if(this.ac_list.length === 0){
            Dialog.alert({
              title: '温馨提示:',
              message: '今天没有可签到的活动!',
            }).then(() => {
              this.$router.replace('/home')
            });
          }else if(this.ac_list.length === 1){
            this.currentData = this.ac_list[0];
            this.checkTime(this.currentData);
            this.isSignUp();
          }
        })
      },
      // 获取岗前列表
      getPreList(){
        let timeObj = new Date();
        let timeDate = {
          startDate: timeObj.getFullYear()+'-'+(timeObj.getMonth()+1<10?'0'+(timeObj.getMonth()+1):timeObj.getMonth()+1)+'-'+(timeObj.getDate()<10?'0'+timeObj.getDate():timeObj.getDate())
        }
        preJobTrainingRecord(timeDate).then(res => {
          this.ac_list = res.data.list;
          if(this.ac_list.length === 0){
            Dialog.alert({
              title: '温馨提示:',
              message: '今天没有可签到的活动!',
            }).then(() => {
              this.$router.replace('/home')
            });
          }else if(this.ac_list.length === 1){
            this.currentData = this.ac_list[0];
            this.isSignUp();
          }
        }).catch(()=>{
          sessionStorage.setItem('scan',this.type==='1'?"2":'1')
          this.$router.replace('/login')
        })
      },
      // 判断是否登录
      isSignUp(){
        let timeObj = new Date();
        let time = timeObj.getHours()
        this.isSign = time < 12 && this.currentData.amSigninFlag;
      },
      getlocation(){
        let that = this
        this.initMap((res,AMap)=>{
          // this.st=JSON.stringify(res)
          // alert(JSON.stringify(this.loc))
          //
          // let marker = new AMap.Marker({
          //   position: new AMap.LngLat([res.position.lng,res.position.lat]),   // 经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
          //   title: '您的位置'
          // });
          // this.map.add(marker)
          // this.map.setCenter([res.position.lng,res.position.lat],true)
          let loc = [res.position.lng,res.position.lat]
          this.timeOut(()=>{
            if(!this.timeUp){
              this.isDisabled = true
              this.localData.forEach(item=>{
                let pos = [
                  parseFloat(item.longitude),
                  parseFloat(item.latitude)
                ]
                let flag = that.gaoDistance(AMap,loc, pos)
                if(flag === true){
                  that.isDisabled = false
                  // that.btnStr = '签到'
                }
                if(that.currentData.id && that.currentData.id.length!==0){
                  that.checkTime(that.currentData)
                }
              })
            }
          })
          // this.st = JSON.stringify(res)

        },()=>{
          this.$toast.fail('获取坐标失败!请确认重试。。。')
        })
      },
      initMap(res,err){
        let that = this
        // JSON.stringify()
        AMapLoader.load({
          key: this.mapKey1,             // 申请好的Web端开发者Key，首次调用 load 时必填
          securityJsCode: this.secretKey,
          version: "2.0",      // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
          plugins: ['AMap.Geolocation'],       // 需要使用的的插件列表，如比例尺'AMap.Scale'等
          AMapUI:{
            version:"1.1",
            plugins:[],

          },
          Loca:{
            version:"2.0"
          },
        }).then((AMap)=>{
          this.map = new AMap.Map("container", {  //设置地图容器id
            viewMode: "3D",    //是否为3D地图模式
            zoom: 16,           //初始化地图级别
          });

          AMap.plugin('AMap.Geolocation', function() {
            let geolocation = new AMap.Geolocation({
              // 是否使用高精度定位，默认：true
              enableHighAccuracy: true,
              // 设置定位超时时间，默认：无穷大
              timeout: 10000,
              //自动偏移坐标，偏移后的坐标为高德坐标，默认：true
              // convert: false,
              // 定位按钮的停靠位置的偏移量，默认：Pixel(10, 20)
              buttonOffset: new AMap.Pixel(10, 20),
              //  定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
              zoomToAccuracy: true,
              //  定位按钮的排放位置,  RB表示右下
              buttonPosition: 'RB',
              // 查看更多信息
              extensions: 'all'
            })
            that.map.addControl(geolocation);
            geolocation.getCurrentPosition(function(status,result){

              that.getTargetLocal(AMap,()=>{
                if(status==='complete'){
                  res(result,AMap)
                }else{
                  err(result)
                }
              }); // 获取坐标
            });
          })
        })

      },

      getTargetLocal(AMap,bf){

        signAddress({
          pageSize: 100,
          pageNum: 1
        }).then(res => {
          this.formLocal(res.data.list,(data)=>{
            data.forEach(item => {
              let circle = new AMap.Circle({
                center: new AMap.LngLat(item.longitude,item.latitude),  // 圆心位置
                radius: 500, // 圆半径
                fillColor: 'blue',   // 圆形填充颜色
                strokeColor: '#fff', // 描边颜色
                strokeWeight: 2, // 描边宽度
              });
              this.map.add(circle);
            })
            this.localData = data
            this.getLoc(()=>{
              bf()
            })
          })
        })
      },
      formLocal(arr,ac){
        let result = []
        let resArr = []

        arr.forEach(item=>{
          if(item.longitude&&item.latitude){
            let arr = [item.longitude,item.latitude]
            result.push(arr.join(','))
          }
        })
        axios.get(`https://restapi.amap.com/v3/assistant/coordinate/convert?&key=${this.mapKey}&locations=${result.join('|')}&coordsys=baidu`).then(res=>{

          if(res.data.status==='1'){
            let arr = res.data.locations.split(';')
            arr.forEach(item=>{
              let p = item.split(',')
              let pos = {
                longitude:p[0],
                latitude:p[1]
              }
              resArr.push(pos)
            })
            ac(resArr)
          }
        })
      },
      gaoDistance(AMap,p1, p2){
        return AMap.GeometryUtil.distance(p1, p2) < this.distanceFlag;
      },
      // 判断打卡时间
      timeOut(cb){
        // let date = new Date()
        // let hh = date.getHours()
        // if(this.type === '1'){
        //   this.timeUp = !(hh === 7 || hh === 8 || hh === 14 || hh === 13); // 检测上下午
        // }else{
        //     this.timeUp = false
        // }
        this.timeUp = false
        cb()
      },      //判断活动打卡时间
      checkTime(data){
        if(this.type !== '1'){
          let startTime=data.startDate.substring(0,10)+" "+data.startTime;
          let endTime=data.startDate.substring(0,10)+" "+data.endTime;
          let now = (new Date()).valueOf(),
                  lTime = (new Date(startTime.replace(/-/g, "/"))).valueOf(),
                  mTime = (new Date(endTime.replace(/-/g, "/"))).valueOf();
          if(now>lTime && now<mTime){
            this.timeUp = false;
          }else{
            if(!data.checkTime){
              this.$toast.fail('未在打卡时间!');
            }
            this.timeUp=true;
          }
        }
      },
      getQueryString(name){
        let reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        let r = window.location.search.substr(1).match(reg);
        if(r!=null)return  unescape(r[2]); return null;
      },
      getAuth(){
        if(navigator.geolocation){
          navigator.geolocation.getCurrentPosition(
              ()=>{
                console.log('有')
              },
              (err)=>{
                console.log(err, 778)
              }
          )
        }else {
          console.log('出错了')
        }
      },
      getLoc(bf){
        let url = location.href.split('#')[0]
        getSignWx(url).then(r => {
          let res = r.data
          wx.config({
            // debug: true,
            appId: res.appId,
            timestamp: res.timestamp,
            nonceStr: res["noncestr"],
            signature: res.signature,
            jsApiList: ['getLocation']
          })
          wx.ready(function (){
            wx.getLocation({
              type: 'gcj02', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
              success: function (res) {
                this.loc = [res.longitude,res.latitude]
                bf()
                // let latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
                // let longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
                // let speed = res.speed; // 速度，以米/每秒计
                // let accuracy = res.accuracy; // 位置精度
              }
            });
          })
        })
      }
    },
    created() {

    },
    mounted() {

      if(this.type === '1'){
        this.name = '培训签到'
      }
      // 判断是否登录
      let log = localStorage.getItem('isLogin') || '';
      if(log !== '1'){
        Dialog.alert({
          title: '温馨提示',
          message: '请先登录后再签到!'
        }).then(()=>{
          sessionStorage.setItem('scan',this.type==='1'?"2":'1')
          this.$router.replace('/login')
        })
      }
      this.getAuth();
      this.getlocation();
      if(this.type !== '1'){
        this.getList()
      }else{
        this.getPreList()
      }
      let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
      let len = Object.keys(currentForm).length
      if(len === 0){
        this.action = 3
      }else {
        this.action = currentForm.status
        this.formData = Object.assign(this.formData,currentForm)
      }
      localStorage.setItem('currentData', '')
      this.nowTime();

    }
  }
</script>
<style>
#container {
  padding: 0;
  margin: 0;
  width: 100%;
  height: 300px;
}
body{
  padding: 0;
  margin: 0;
}
</style>
