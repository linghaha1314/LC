<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div v-if="role !== 'StudentType_jxs'">
      <van-dropdown-menu active-color="#17d4b5">
        <!--            <van-dropdown-item title="科室" v-model="listParams.sectionId" @change="leaveListGet" :options="option2" />-->
        <van-dropdown-item title="类型" v-model="listParams.dictionaryId" @change="onRefresh" :options="option3"/>
      </van-dropdown-menu>
    </div>
    <div style="display: flex;justify-content: space-between;align-items: center; padding: 0 12px;">

      <van-search v-model="listParams.name" shape="round" @change="onRefresh" placeholder="搜索考试" style="width: 100%"/>
      <!--      <router-link to="/my-test">-->
      <!--        <div style="display: flex; flex-direction: column;align-items: center; color: #17d4b5">-->
      <!--          <van-icon name="records" size="22"/>-->
      <!--          <span style="font-size: 10px">我的考试</span>-->
      <!--        </div>-->
      <!--      </router-link>-->
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <div>
              <div style="font-size: 16px;">
                {{ data.name }}
              </div>
              <van-divider/>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">医院名字:</div>
                <div>{{ data['hospitalName'] }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.sectionName">
                <div style="color: #cccccc;margin-bottom: 4px;">科室:</div>
                <div>{{ data.sectionName }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.userName">
                <div style="color: #cccccc;margin-bottom: 4px;">发布人:</div>
                <div>{{ data.userName }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">考试时间:</div>
                <div>{{ data.startDate }} 至 {{ data.endDate }}</div>
              </div>
              <div>
                <div style="color: #cccccc;margin-bottom: 4px;">备注内容:</div>
                <div>{{ data.remark }}</div>
              </div>
              <div style="position: absolute;right: -6px;top: -6px;" v-if="data.completed">
                <van-icon name="checked" color="#17d4b5" size="20"/>
              </div>
            </div>
            <div style="text-align: right;">
              <van-button style="width: 50px; margin-right: 12px"
                          type="danger" size="mini" @click="delFn(data)">删除
              </van-button>
              <van-button style="width: 50px; margin-right: 12px" type="primary"
                          size="mini"
                          @click="goTestDetail(data)"
              >
                修改
              </van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>


      <div style="position: fixed;right: 26px;bottom: 60px"
           v-if="role==='sectionManager' || role==='superadmin' || role==='JXS_manager' || role==='headNurse'">

        <router-link to="/test-add">
          <van-icon color="#ff0000" name="add" size="40"/>
        </router-link>
      </div>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {examplanLists, urlForPost} from '../http/apiMap';

export default {
  name: 'test',
  data() {
    return {
      testData: [],
      role: '',
      listParams: {
        pageSize: 10,
        pageNum: 0,
        name: '',
        dictionaryId: ''
      },
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      option3: []
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    // this.examListFn()
    this.getData('/dictionary/getByTypeCode/EvaluateType', '', 'marketColumns')
  },
  methods: {
    goTestDetail(data) {
      this.$router.push({
        path: '/test-add',
        query: {
          ...data
        }
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;

      this.testData = [];
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.examListFn(flag)
    },
    examListFn(f) {
      examplanLists(this.listParams).then(res => {
        if (f === 'onLoad') {
          this.state.loading = false;
          if (res.data.list.length === 0 || res.data.list.length < this.listParams.pageSize) {
            this.state.finished = true
          }
          if (res.data.total === 0) {
            this.testData = []
          } else {
            this.testData = [...this.testData, ...res.data.list];
          }
        } else {
          this.testData = [...res.data.list];
        }
      })
    },
    getData(url, params) {
      urlForPost(url, params).then(res => {
        let optionArr = []
        res.data.data.forEach(item => {

          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option3 = optionArr
      })
    },
    delFn(data) {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认删除该安排以及所有安排人员的考试信息吗？',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        urlForPost('/examplan/remove', {
          id: data.id
        }).then(() => {
          this.$toast.success('操作成功!')
          this.examListFn() // 获取列表
        })
      }).catch(() => {
      })
    }
  }
}
</script>
