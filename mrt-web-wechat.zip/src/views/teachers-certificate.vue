<template>
  <div class="about">
    <van-nav-bar title="个人信息" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        个人信息填写
      </div>
    </div>
    <div>
      <van-form ref="infoForm">
        <van-field name="fileZiList" :value="fileZiList.pathAttach" required label="资格证书"
                   :rules="[{ required: true, message: '请上传资格证书' }]">
          <template #input>
            <van-uploader v-model="fileZiList" :after-read="afterRead" :before-delete='beforeDelete'/>
          </template>
        </van-field>
        <van-field name="fileZhiList" :value="fileZhiList.pathAttach" required label="执业证书"
                   :rules="[{ required: true, message: '请上传执业证书' }]">
          <template #input>
            <van-uploader v-model="fileZhiList" :after-read="afterRead" :before-delete='beforeDelete'/>
          </template>
        </van-field>
        <van-field name="fileBiList" :value="fileBiList.pathAttach" required label="毕业证书"
                   :rules="[{ required: true, message: '请上传毕业证书' }]">
          <template #input>
            <van-uploader v-model="fileBiList" :after-read="afterRead" :before-delete='beforeDelete'/>
          </template>
        </van-field>
        <van-field name="fileXueList" :value="fileXueList.pathAttach" required label="学位证书"
                   :rules="[{ required: true, message: '请上传学位证书' }]">
          <template #input>
            <van-uploader v-model="fileXueList" :after-read="afterRead" :before-delete='beforeDelete'/>
          </template>
        </van-field>
      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button style="margin-bottom: 12px;" round block @click="goPre">
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          完成
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
import {uploadFile, urlForPost, urlForGet} from "../http/apiMap";

export default {
  name: 'sign-info',

  data() {
    return {
      url: {
        removeFile: '/advancedsignupattach/attachDeleteFile',
      },
      fileZiList: [],
      fileZhiList: [],
      fileBiList: [],
      fileXueList: [],
      formData: {},
      saveArr: [
        {file: 'fileZiList', code: 'Credentials'},
        {file: 'fileZhiList', code: 'PracticeCertificate'},
        {file: 'fileBiList', code: 'GraduationCertificate'},
        {file: 'fileXueList', code: 'TheHighestDegree'}
      ]
    }
  },
  computed: {},
  methods: {

    attendAdd() {
      this.$refs.infoForm.validate().then(() => {

        this.saveArr.forEach(item => {
          this[item.file].forEach(ite=>{
            if(!ite.id){
              let param = {
                staffId: sessionStorage.getItem('staffId'),
                typeCode: item.code,
                attachCert: this[item.file][0].pathAttach
              }
              urlForPost('/advancedsignup/createQualification', param).then(() => {

              })
            }
          })
        })
        urlForPost('/teacher/createdteacher', {
          staffId: sessionStorage.getItem('staffId'),
          typeCode: sessionStorage.getItem('typeCode')
        }).then(res => {
          if(res.data.success){
            this.$toast.success({
              message: '添加成功!',
              duration: 2000,
              onClose:()=>{
                this.$router.replace('/teachers')
              }
            })
          }else{
            this.$toast.fail(res.data.message)
          }
        })
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        // this.formData.avator = res.data.path
        file.pathAttach = res.data.path
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    beforeDelete(file) {
      urlForPost(this.url.removeFile, {
        path: file.pathAttach
      }).then()
      if(file.id){
        urlForGet('/advancedsignup/remove',file.id).then(() => {
        })
      }
      return true
    },

    certificateInfo() {

      urlForPost('/advancedsignup/getListByPage',{
        staffId: sessionStorage.getItem('staffId'),
        typeCode: ''
      }).then(res => {
        let data = res.data.data.list
        data.forEach(item => {
          this.saveArr.forEach(ite => {
            if(item.typeCode === ite.code){
              this[ite.file].push({
                url: item.attachCert,
                pathAttach: item.attachCert,
                code: ite.code,
                id: item.id
              })
            }
          })
        })
      })
    },
    goPre() {
      this.$router.push({
        name: 'education'
      })
    },

  },
  mounted() {
    this.certificateInfo()
  }
}
</script>
