<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">
      <van-field name="year" required label="年份" :rules="[{ required: true, message: '请选择年份' }]">
        <template #input>
          <van-stepper v-model="formData.year" theme="round" button-size="22" disable-input/>
        </template>
      </van-field>

      <van-field readonly clickable required name="typeId" label="类型" :value="formData.typeName" placeholder="选择类型" @click="showTypePicker = true"
                 :rules="[{ required: true, message: '请选择类型' }]" />
      <van-popup v-model="showTypePicker" round position="bottom">
        <van-picker :columns="columns" :show-toolbar="true" @cancel="showTypePicker = false" @confirm="onConfirm($event,formData,'typeName','typeId','showTypePicker')"
        />
      </van-popup>

      <van-field readonly clickable name="startDate" required label="开始时间" :value="formData.startDate&&formData.startDate.substring(0,10)"
                 placeholder="选择开始时间" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择开始时间' }]" />
      <van-popup v-model="showDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="currentDate" type="date" @cancel="showDatePicker = false" @confirm="onDateConfirm($event,formData,'startDate','showDatePicker')"/>
        </div>
      </van-popup>
      <van-field readonly clickable name="endDate" required label="结束时间" :value="formData.endDate&&formData.endDate.substring(0,10)"
                 placeholder="选择结束时间" @click="showEndDatePicker = true" :rules="[{ required: true, message: '请选择结束时间' }]" />
      <van-popup v-model="showEndDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="currentDate" type="date" @cancel="showEndDatePicker = false" @confirm="onDateConfirm($event,formData,'endDate','showEndDatePicker')" />
        </div>
      </van-popup>

      <van-field v-model="formData['remark']" name="remark" label="备注"
                 placeholder="请输入备注" type="textarea" rows="2" show-word-limit :autosize="true"
      />

      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="margin: 16px;">
        <van-button round block :disabled="disabled" color="#17d4b5" @click="onSubmit">
          提交
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import { urlForPost, getForCode } from '../http/apiMap.js'
import { Dialog } from 'vant';
export default {
  name: 'test',
  data() {
    return {
      url:{
        save: '/planschedule/create',
        update: '/planschedule/update'
      },
      formData: {
        startDate: '',
        endDate: ''
      },

      showDatePicker: false,
      showEndDatePicker: false,
      showTypePicker: false,
      currentDate: new Date(),
      attachFlag: false,
      leaveDays: 0,
      disabled: false,
      columns: []
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          let url = this.formData.id ? this.url.update : this.url.save
          this.formData.startDate = this.formData.startDate.substring(0, 10)+' 00:00:00'
          this.formData.endDate = this.formData.endDate.substring(0, 10)+' 00:00:00'
          urlForPost(url,this.formData).then(res => {
            if (res.data.data.success) {
              this.$toast.success({
                message: '提交成功!',
                duration: 2000,
                onClose: ()=>{
                  this.$router.go(-1)
                }
              });
            } else {
              this.$toast.fail(res.data.msg || '出问题啦!!')
            }
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },

    onDateConfirm(value,target,prop,show) {
      target[prop] = this.getNowFormatDate(value)+' 00:00:00'
      this[show] = false;
    },

    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      return year + seperator1 + month + seperator1 + strDate;
    },

    // 获取类型
    getForCodeFn(){
      getForCode('TrainPhase').then(res => {
        if(res.data.success){
          let arr = res.data.data
          arr.forEach(item => {
            item.text = item.name
            item.value = item.id
          })
          this.columns = [...arr]
        }
      })
    },
    onConfirm(value, target, name, id, show) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
    }
  },
  mounted() {

    this.formData.year = new Date().getFullYear()
    this.getForCodeFn()
    if(this.$route.query.id){
      this.formData = {
        ...this.$route.query
      }
    }
  }
}
</script>