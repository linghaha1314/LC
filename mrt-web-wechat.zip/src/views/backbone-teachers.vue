<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <template #right v-if="role === 'StudentType_jxs'">
        <span style="color: #17d4b5" @click="goMyRecord()">我的</span>
      </template>
    </van-nav-bar>
<!--    <div>-->
<!--      <van-dropdown-menu active-color="#17d4b5">-->
<!--        <van-dropdown-item title="状态" v-model="listParams.status" @change="getList"-->
<!--                           :options="role==='StudentType_jxs'?option3:option2"-->
<!--        />-->
<!--        <van-dropdown-item title="科室" v-model="listParams.sectionId" @change="getList" :options="option4"/>-->
<!--      </van-dropdown-menu>-->
<!--    </div>-->
    <div>
      <van-search v-model="listParams.name" shape="round" @change="getList" placeholder="搜索"/>
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <div @click="goDetail(data)">
              <div style="font-size: 14px;display: flex;justify-content: space-between;">
                {{ data['staffName'] || '无' }}
<!--                <div style="width: 4em; margin-left: 12px">-->
<!--                  <van-tag style="text-align: center" :type="'danger'" v-if="data.status===3" size="medium">已结束</van-tag>-->
<!--                  <van-tag style="text-align: center" :type="'danger'" v-if="data.status===2" size="medium">已过期</van-tag>-->
<!--                  <van-tag style="text-align: center" :type="'warning'" v-if="data.status===1" size="medium">已发布</van-tag>-->
<!--                  <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交</van-tag>-->
<!--                </div>-->
              </div>
              <van-divider/>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">学生:</div>
                <div>{{ data['staffName'] }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.typeName">
                <div style="color: #cccccc;margin-bottom: 4px;">阶段:</div>
                <div>{{ data.typeName }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.startDate && data.endDate">
                <div style="color: #cccccc;margin-bottom: 4px;">时间:</div>
                <div>{{ data.startDate.substring(0, 10) }}至{{ data.endDate.substring(0, 10) }}</div>
              </div>
            </div>
            <div style="text-align: right;">
                <van-button style="width: 5em" type="primary" size="mini" @click="goDetail(data)">修改</van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>

      <div style="position: fixed;right: 26px;bottom: 60px" v-if="role==='tutor' || role==='StudentType_jxs'">
        <!--                <router-link :to="{path:'/backbone-teachers-add',query:{typePage: this.typePage}}">-->
        <!--                    <van-icon color="#ff0000" name="add" size="40" @click="addFn"/>-->
        <!--                </router-link>-->
        <van-icon color="#ff0000" name="add" size="40" @click="addFn"/>
      </div>
    </div>
  </div>
</template>
<script>
import {plansList, getDictionaryType, getTransferSchedule, plansummaryList} from '../http/apiMap';

export default {
  name: 'test',
  data() {
    return {
      listParams: {
        pageSize: 10,
        pageNum: 0,
        typeId: '',
        sectionId: '',
        name: '',
        status: null
      },
      role: '',
      option1: [],
      option2: [ // 上级
        {text: '全部', value: null},
        {text: '已结束', value: 3},
        {text: '已发布', value: 1},
        {text: '未提交', value: 0},
      ],
      option3: [ // 学生
        {text: '全部', value: null},
        {text: '已结束', value: 3},
        {text: '已发布', value: 1},
      ],
      option4: [],
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      testData: [],
      name: '骨干教师',
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      typePage: ''
    }
  },
  computed: {},
  mounted() {
    this.role = localStorage.getItem('roleCode')
    this.name = this.role === 'tutor' ? '骨干教师安排' : '培训阶段小结'
    this.typePage = this.role === 'tutor' ? '1' : '0'
    this.getList();
    this.getTypeList();
    this.transferGet();
  },
  methods: {
    goDetail(data) {
      data.typePage = this.typePage
      localStorage.setItem('currentData', JSON.stringify(data))
      this.$router.push({
        path: '/backbone-teachers-add',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;


      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.getList(flag)
    },
    // 获取列表
    getList(f) {
      if (this.typePage === '1') {
        plansList(this.listParams).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if (this.testData.length || res.data.rows.length === 0 && (this.testData.length >= res.data.total)) {
              this.state.finished = true
            }
            let flag = false
            this.testData.forEach(item => {
              res.data.rows.forEach(ite => {
                if (item.id === ite.id) {
                  flag = true
                }
              })
            })
            if (flag) {
              this.testData = [...this.testData]
            } else {
              this.testData = [...this.testData, ...res.data.rows];
            }
          } else {
            this.testData = [...res.data.rows];
          }
        })
      } else {
        plansummaryList({
          ...this.listParams
        }).then(res => {
          if (f === 'onLoad') {
            // this.testData = [...this.testData,...res.data.list];
            this.state.loading = false;
            if (this.testData.length || res.data.rows.length === 0 && (this.testData.length >= res.data.total)) {
              this.state.finished = true
            }
            let flag = false
            this.testData.forEach(item => {
              res.data.rows.forEach(ite => {
                if (item.id === ite.id) {
                  flag = true
                }
              })
            })
            if (flag) {
              this.testData = [...this.testData]
            } else {
              this.testData = [...this.testData, ...res.data.rows];
            }
          } else {
            this.testData = [...res.data.rows];
          }
        })
      }

    },
    // 获取类型
    getTypeList() {
      getDictionaryType('ActivityPlanContent').then(res => {
        let data = res.data.data
        let arr = [{
          text: '全部',
          value: ''
        }]
        data.forEach(item => {
          if (item.name !== '入科教育') {
            let obj = {
              text: item.name,
              value: item.id
            }
            arr.push(obj)
          }
        })
        this.option1 = arr;
      })
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option4 = [...optionArr]
      })
    },
    // 我的签到记录
    goMyRecord() {
      this.$router.push({
        path: '/backbone-teachers-record',
        query: this.typePage
      })
    },
    addFn() {
      if (this.role === 'tutor') {
        this.$router.push({
          path: '/backbone-teachers-add',
        })
      } else {
        this.$router.push({
          path: '/backbone-student-add',
        })
      }
    }
  }
}
</script>
