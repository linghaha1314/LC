<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="姓名:" :value="currentData.studentName||'无'"/>
        <van-cell title="培训日期:" :value="currentData['startDate'] && currentData['startDate'].substring(0,10)"/>
        <van-cell title="签到时间:" :value="currentData['checkinDate']||'无'"/>
        <van-cell title="开始时间:" :value="currentData['startTime']||'无'"/>
        <van-cell title="科室:" :value="currentData.sectionName||'无'"/>
        <van-cell title="专业:" :value="currentData.majorName||'无'"/>
        <van-cell title="上午打卡:" :value="currentData['amSigninFlag']==='true' ? '已签到' : '未签到'"/>
        <van-cell title="下午打卡:" :value="currentData['pmSigninFlag']==='true' ? '已签到' : '未签到'"/>

        <!--        <van-cell title="个人鉴定:">-->
        <!--          <template #label>-->
        <!--            <div>{{currentData.summary||'无'}}</div>-->
        <!--          </template>-->
        <!--        </van-cell>-->
        <!--        <van-cell style="width:100vw;" title="老师评语:">-->
        <!--          <template #label>-->
        <!--            <div style="max-width:340px;overflow-wrap:break-word;box-sizing: border-box;">{{currentData.teachOpinion||'无'}}</div>-->
        <!--          </template>-->
        <!--        </van-cell>-->
        <!--        <van-cell title="科室考评:">-->
        <!--          <template #label>-->
        <!--            <div>{{currentData['sectionOpinion']||'无'}}</div>-->
        <!--          </template>-->
        <!--        </van-cell>-->
        <!--        <van-cell title="部门考评:" :label="currentData['deptOpinion']||'无'" />-->
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: this.$route.name
    }
  },
  computed: {
    typeFn(){
      let row = this.currentData
      let education = "";
      let union = "";
      let support = "";
      if (row['educationFlag']==='true') {
        education = "普通进修"
      }
      if (row['unionsFlag']==='true') {
        union = "医联体"
      }
      if (row['supportFlag']==='true') {
        support = "对口帮扶"
      }
      return " " + education + " " + union + " " + support + " ";
    },
    statusFn(){
      let value = parseInt(this.currentData.status)
      switch (value) {
        case 0:
          return "在训";
        case 1:
          return "已提前结业";
        case 2:
          return "已结业";
        case 3:
          return "拟结业";
        case 4:
          return "结业中";
        default :
          return "--";
      }
    }
  },
  methods: {},
  mounted() {
  }
}
</script>
