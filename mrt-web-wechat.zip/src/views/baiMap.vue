<template>
  <div>
    <van-nav-bar title="地图" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <!--    <div id="map" style="width:100vw;height:93vh;"></div>-->
    <div id="container"></div>
  </div>
</template>
<script>
//百度地图
// import Vue from 'vue'
// import BaiduMap from 'vue-baidu-map'
import {signAddress} from '../http/apiMap';
import AMapLoader from '@amap/amap-jsapi-loader';
import axios from 'axios'
//
// Vue.use(BaiduMap, {
//   /* Visit http://lbsyun.baidu.com/apiconsole/key for details about app key. */
//   ak: 'mqUqkxXtbVTYHkD3BAsZZKIMpokrSgqu'
// })
export default {
  name: 'bai-map',
  data() {
    return {
      point: this.$route.query,
      param: {
        pageSize: 100,
        pageNum: 1
      },
      map:null
    }
  },
  methods: {
    //查看详情
    initMap() {
      AMapLoader.load({
        key: "71951107bf32bb43a68e59ab7f8ad9a4",             // 申请好的Web端开发者Key，首次调用 load 时必填
        version: "2.0",      // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
        plugins: [''],       // 需要使用的的插件列表，如比例尺'AMap.Scale'等
      }).then((AMap) => {
        this.map = new AMap.Map("container", {  //设置地图容器id
          viewMode: "3D",    //是否为3D地图模式
          zoom: 16,           //初始化地图级别
          center: [parseFloat(this.point.lng),parseFloat(this.point.lat)], //初始化地图中心点位置
        });

        let marker = new AMap.Marker({
          position: new AMap.LngLat(this.point.lng, this.point.lat),   // 经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
          title: '成都'
        });
        this.map.add(marker)

        signAddress(this.param).then(res => {
          this.formLocal(res.data.list,(data)=>{
            data.forEach(item => {
              // eslint-disable-next-line
              // let poi = new BMap.Point(item.longitude,item.latitude)
              // // eslint-disable-next-line
              // let circleI = new BMap.Circle(poi,500,{strokeColor:"blue", strokeWeight:2, strokeOpacity:0.5}); //创建圆
              // map.addOverlay(circleI);
              let circle = new AMap.Circle({
                center: new AMap.LngLat(item.longitude,item.latitude),  // 圆心位置
                radius: 500, // 圆半径
                fillColor: 'blue',   // 圆形填充颜色
                strokeColor: '#fff', // 描边颜色
                strokeWeight: 2, // 描边宽度
              });

              this.map.add(circle);

            })
          });

        })
      }).catch(e => {
        console.log(e);
      })
    },
    formLocal(arr,ac){
      let result = []
      let resArr = []

      arr.forEach(item=>{
        if(item.longitude&&item.latitude){
          let arr = [item.longitude,item.latitude]
          result.push(arr.join(','))
        }
      })
      axios.get(`https://restapi.amap.com/v3/assistant/coordinate/convert?&key=9163e13b3edd22658e29a088137a5ab1&locations=${result.join('|')}&coordsys=baidu`).then(res=>{

        if(res.data.status==='1'){
          let arr = res.data.locations.split(';')
          arr.forEach(item=>{
            let p = item.split(',')
            let pos = {
              longitude:p[0],
              latitude:p[1]
            }
            resArr.push(pos)
          })
          ac(resArr)
        }
      })
    },
  },
  mounted() {
    this.initMap()
    // 百度地图API功能
    // eslint-disable-next-line
    // let map = new BMap.Map("map");    // 创建Map实例
    // // eslint-disable-next-line
    // let point = new BMap.Point(this.point.lng,this.point.lat)
    // map.centerAndZoom(point, 17);  // 初始化地图,设置中心点坐标和地图级别
    // map.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
    //
    // // eslint-disable-next-line
    // let marker = new BMap.Marker(point);        // 创建标注
    // map.addOverlay(marker);


  }
}
</script>
<style>
#container {
  padding: 0;
  margin: 0;
  width: 100%;
  height: 800px;
}
</style>
