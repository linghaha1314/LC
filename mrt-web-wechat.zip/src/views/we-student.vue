<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div>
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item title="科室" v-model="listParams.sectionId" @change="getList" :options="option4" />
        <van-dropdown-item title="专业" v-model="listParams.majorId" @change="getList" :options="option1" />
      </van-dropdown-menu>
    </div>
    <div>
      <van-search
          v-model="listParams.name"
          shape="round"
          @change="getList"
          placeholder="搜索"
      />
    </div>
    <div>
      <van-list
          error-text="请求失败，点击重新加载"
      >
        <van-cell v-for="item in testData" :key="item.value" :title="item.studentName" @click="checkThis(item)" />
      </van-list>
    </div>
    <van-popup v-model="show" position="top" >
      <div style="padding: 24px 0;">
        <van-cell title="学生姓名" :value="userInfo.studentName || '无'"/>
        <van-cell title="所在科室" :value="userInfo.sectionName || '无'"/>
        <van-cell title="性别" :value="userInfo['genderName'] || '无'"/>
        <van-cell title="学历" :value="userInfo['academicName'] || '无'"/>
        <van-cell title="专业" :value="userInfo.majorName || '无'"/>
        <van-cell title="带教老师" :value="userInfo.teacherName || '无'"/>
      </div>
    </van-popup>
  </div>
</template>
<script>
    import { getTransferSchedule, listStudentByPage, listMajorAd } from '../http/apiMap';
    export default {
        name: 'test',
        data(){
            return{
                listParams: {
                    pageSize: 999,
                    pageNum: 1,
                    sectionId: '',
                    name: '',
                    majorId: ''
                },
                role:'',
                option1: [],
                option4: [],
                transferParams:{
                    pageSize: 999,
                    pageNum: 1,
                },
                testData: [],
                show: false,
                userInfo:{}
            }
        },
        computed:{
            name(){
                return this.$route.name
            }
        },
        mounted() {
            this.role = localStorage.getItem('roleCode')
            this.getList();
            this.transferGet();
            this.getListMajor();
        },
        methods:{
            goDetail(data){
                localStorage.setItem('currentData',JSON.stringify(data))
                this.$router.push({
                    path: '/activities-add'
                })
            },

            // 获取列表
            getList(){
                listStudentByPage(this.listParams).then(res => {
                    this.testData = res.data.list;
                })
            },
            // 获取科室信息
            transferGet(){
                getTransferSchedule(this.transferParams).then(res => {
                    let optionArr = [
                        { text: '全部', value: '' }
                    ]
                    res.data.list.forEach(item => {
                        let obj = {
                            text: item.name,
                            value: item.id
                        }
                        optionArr.push(obj)
                    })
                    this.option4 = [...optionArr]
                })
            },
            // 获取专业
            getListMajor(){
                listMajorAd({
                    pageSize: 999,
                    pageNum: 1
                }).then(res => {
                    let optionArr = [
                        { text: '全部', value: '' }
                    ]
                    res.data.list.forEach(item => {
                        let obj = {
                            text: item.majorName,
                            value: item.majorId
                        }
                        optionArr.push(obj)
                    })
                    this.option1 = [...optionArr]
                })
            },
            checkThis(item){
                this.userInfo = item
                this.show = true
            }
        }
    }
</script>