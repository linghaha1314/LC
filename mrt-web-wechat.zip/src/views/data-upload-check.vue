<template>

  <div style="height: 100vh">
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.push('/home')">返回</span>
      </template>
    </van-nav-bar>
    <div style="display: flex; flex-direction: column;justify-content: center;height: 82vh;padding: 24px;">
      <router-link to="/data-upload">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          查看资料
        </van-button>
      </router-link>
      <router-link to="/data-upload-add">
        <van-button round block color="#17d4b5">
          资料上传
        </van-button>
      </router-link>

    </div>
  </div>

</template>
<script>
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {

      role: ''
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {

  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')

  }
}
</script>
