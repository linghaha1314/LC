<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="activitiesForm" v-if="isEdit">
      <van-field name="startDate" readonly clickable required label="开始时间" :value="formData.startDate"
                 placeholder="选择开始时间" @click="showStartTimePicker = !!isEdit"
                 :rules="[{ required: true, message: '请选择开始时间' }]"/>
      <van-popup v-model="showStartTimePicker" round position="bottom">
        <van-datetime-picker v-model="formData.dateStartValue" type="datetime" title="选择年月日"
                             @cancel="showStartTimePicker = false"
                             @confirm="onStartDateConfirm" :min-date="minDate"/>
      </van-popup>
      <van-field name="endDate" readonly clickable required label="结束时间" :value="formData.endDate" placeholder="选择结束时间"
                 @click="showEndTimePicker = true"
                 :rules="[{ required: true, message: '请选择结束时间' }]"/>
      <van-popup v-model="showEndTimePicker" round position="bottom">
        <van-datetime-picker v-model="formData.dateEndValue" type="datetime" title="选择年月日"
                             @cancel="showEndTimePicker = false" @confirm="onEndDateConfirm"
                             :min-date="minDate"/>
      </van-popup>
      <van-field v-model="formData.name" name="name" label="考试名称" required placeholder="请填写活动标题"
                 :rules="[{ required: true, message: '请填写活动标题' }]"
      />

      <van-field readonly clickable required name="typeId" label="考试类型" :value="formData.typeName" placeholder="选择考试类型"
                 @click="showTypePicker = true"
                 :rules="[{ required: true, message: '请选择考试类型' }]"/>
      <van-popup v-model="showTypePicker" round position="bottom">
        <van-picker :columns="marketColumns" :show-toolbar="true" @cancel="showTypePicker = false"
                    @confirm="onConfirm($event,formData,'typeName','type','showTypePicker',typeChange)"
        />
      </van-popup>
      <van-field
          name="onlineFlag"
          label="考试方式"
          required :value="formData.onlineFlag"
          :rules="[{ required: true, message: '请选择考试方式' }]"
      >
        <template #input>
          <van-radio-group v-model="formData.onlineFlag" direction="horizontal">
            <van-radio :name="0">线下考试</van-radio>
            <van-radio :name="1">在线考试</van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field v-if="formData.onlineFlag===1" name="volumeId" readonly clickable required label="采用试卷"
                 :value="formData.volumeName" placeholder="选择采用试卷" @click="showPicker = true"
                 :rules="[{ required: true, message: '请选择采用试卷' }]"/>
      <van-popup v-model="showPicker" round position="bottom">
        <Pager url="/examvolume/listSomeVolume" :section-id="sectionId" :list-prop="['title', 'id']"
               @check="checkFn"></Pager>
      </van-popup>
      <van-field v-model="formData.scoreLine" type="number" required label="合格线"/>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <van-field readonly required clickable name="type" label="参考人员"
                 :value="formData.staffIds ? '已选'+(formData.staffIds.length || checkStaff.length)+`人`:'未选择'"
                 placeholder="选择参考人员" @click="clickStaff" :rules="[{ required: true, message: '请选择参考人员' }]"/>
      <van-popup v-model="staffIdsPicker" round position="bottom" style="height: 80vh">
        <div>
          <van-dropdown-menu active-color="#17d4b5">
            <!--            <van-dropdown-item title="类型" v-model="listParams.typeId" @change="getList"   :options="option1" />-->
            <!--            <van-dropdown-item title="状态" v-model="listParams.status" @change="getList" :options="role==='StudentType_jxs'?option3:option2" />-->
            <van-dropdown-item :title="itemTitle" v-model="staffParam.sectionList" @change="beforeStaffListsFn"
                               :options="option4"/>
          </van-dropdown-menu>
        </div>
        <div>
          <van-search v-model="staffParam.name" shape="round" @change="staffListsFn" placeholder="搜索"/>
        </div>
        <div style="padding: 12px;">
          <van-checkbox-group v-model="formData.staffIds" ref="checkboxGroup">
            <van-checkbox style="height: 30px" :name="item.id" v-for="(item,index) in staffList" :key="index" @click="changeStaff($event, item)">
              {{ item.name }}(
              {{ item.sectionName || '无科室' }} )
            </van-checkbox>
          </van-checkbox-group>
        </div>
      </van-popup>

      <!--      <van-field-->
      <!--          v-model="formData.intervalTime"-->
      <!--          type="number"-->
      <!--          label="有效性间隔时间" />-->
      <!--      <div style="width:100%; height: 7px; background: #f6f6f6"></div>-->

      <!--      <van-field-->
      <!--          name="vocationFlag"-->
      <!--          label="试题打乱顺序"-->
      <!--      >-->
      <!--        <template #input>-->
      <!--          <van-radio-group v-model="formData.vocationFlag" direction="horizontal">-->
      <!--            <van-radio name="1">是</van-radio>-->
      <!--            <van-radio name="0">否</van-radio>-->
      <!--          </van-radio-group>-->
      <!--        </template>-->
      <!--      </van-field>-->
      <!--      <van-field-->
      <!--          name="vocationFlag"-->
      <!--          label="防止刷新"-->
      <!--      >-->
      <!--        <template #input>-->
      <!--          <van-radio-group v-model="formData.vocationFlag" direction="horizontal">-->
      <!--            <van-radio name="1">是</van-radio>-->
      <!--            <van-radio name="0">否</van-radio>-->
      <!--          </van-radio-group>-->
      <!--        </template>-->
      <!--      </van-field>-->
      <!--      <div style="width:100%; height: 7px; background: #f6f6f6"></div>-->

      <!--      <van-field-->
      <!--          readonly-->
      <!--          clickable-->
      <!--          name="type"-->
      <!--          label="结束方式"-->
      <!--          :value="currentData.effective || formData.effective"-->
      <!--          placeholder="选择结束方式"-->
      <!--          @click="showOverPicker = true"-->
      <!--      />-->
      <!--      <van-popup v-model="showOverPicker" round position="bottom">-->
      <!--        <van-picker-->
      <!--            :columns="typeColumns"-->
      <!--            value-key="value"-->
      <!--            :show-toolbar="true"-->
      <!--            @cancel="showOverPicker = false"-->
      <!--            @confirm="onTypeConfirm"-->
      <!--        />-->
      <!--      </van-popup>-->
      <van-field v-model="formData.remark" name="remake" label="考试说明" rows="2" :autosize="true" type="textarea"
                 placeholder="请填写考试说明"
      />

      <div style="margin: 16px;" v-if="action===3">
        <van-button round block color="#17d4b5" @click="onSubmit">
          保存
        </van-button>
      </div>
      <div style="margin: 16px;" v-if="action===0 && userId===formData.userId">
        <van-button style="margin-bottom: 12px;" round block color="#17d4b5" @click="release">
          发布
        </van-button>
        <van-button round block type="danger" @click="removeA">
          删除
        </van-button>
      </div>
    </van-form>
    <div v-if="!isEdit">
      <van-cell title="活动标题" :value="formData.name"/>
      <van-cell title="主讲人" :value="formData.teacherName"/>
      <van-cell title="活动地址" :value="formData.location"/>
      <van-cell title="活动日期" :value="formData.startDate.substring(0,10)"/>
      <van-cell title="开始时间" :value="formData.startDate"/>
      <van-cell title="结束时间" :value="formData.endDate"/>
      <van-cell title="活动类型" :value="currentData.effective || formData.effective"/>
      <van-cell title="备注信息" :value="formData.remark || '无'"/>
      <div style="margin: 16px;" v-if="userId===formData.userId && action===1">
        <van-button round block color="#17d4b5" @click="activitiesOver">
          结束
        </van-button>
      </div>
    </div>
    <div style="background:#cccccc;padding: 12px" v-if="testDetailInfo['passRate']">
      <div style="background: #ffffff">
        <div style="text-align: center;font-size: 16px;font-weight: bold;padding: 12px 0;">考试统计</div>
        <van-cell title="及格率" :value="(testDetailInfo['passRate'] || 0)+'%'"/>
        <van-cell title="及格人数" :value="testDetailInfo['passNum']+'人'"/>
        <van-cell title="参考率" :value="(testDetailInfo['joinRate'] || 0)+'%'"/>
        <van-cell title="参考人数" :value="testDetailInfo.totalNum+'人'"/>
        <van-cell title="交卷人数" :value="testDetailInfo['realNum']+'人'"/>
        <van-cell title="未交卷人数" :value="testDetailInfo['noExamNum']+'人'"/>
      </div>
    </div>
  </div>
</template>
<script>
import Pager from '../components/searchPager'
import {
  createPlanAndUser,
  getDictionaryType,
  updateTeachactivity,
  removeTeachactivity,
  getTeachactivity,
  getTransferSchedule,
  staffLists,
  updatePlanAndUser,
  examplanUser,
  testDetail,
  urlForPost
} from '../http/apiMap';

import {getNowFormatDate} from '../utils/utils'

export default {
  name: 'test',
  components: {
    Pager
  },
  data() {
    return {
      formData: {
        name: '',
        volumeId: '',
        volumeName: '',
        dateValue: null,
        dateStartValue: null,
        dateEndValue: null,
        startDate: '',
        endDate: '',
        scoreLine: 1,
        intervalTime: 1,
        typeId: '',
        effective: 1,
        effectiveText: '',
        content: '',
        remark: '',
        vocationFlag: '1',
        staffIds: [],
        "effectiveIp": true,
        "endNum": 0,
        "endType": 1,
        "mixFlag": false,
        "refresh": 0,
        "typeFlag": 0,
      },
      // ac_userId: '',
      currentData: {},
      showPicker: false,
      showTypePicker: false,
      showOverPicker: false,
      showEffectivePicker: false,
      staffIdsPicker: false,
      showPaperPicker: false,
      showDatePicker: false,
      showStartTimePicker: false,
      showEndTimePicker: false,

      action: 3,
      minDate: new Date(),

      currentDate: new Date(),
      currentTime: '12:00',
      currentEndDate: '12:00',
      option1: [],
      role: '',
      userId: '',
      state: {
        activeId: [1, 2],
        activeIndex: 0,
      },
      paperColumns: [],
      marketColumns: [],
      effectiveColumns: [
        {text: '不限制', value: -1},
        {text: '使用Cookie技术', value: 2},
        {text: '使用来源IP检测', value: 3},
        {text: '每台电脑或手机只能答一次', value: 4},
      ],
      listParams: {
        pageSize: 999,
        pageNum: 1,
        typeId: '',
        sectionId: '',
        name: '',
        status: null
      },
      staffParam: {
        "pageNum": 1,
        "pageSize": 999,
        sectionList: '',
        "staffTypeList": "edc5e614-96bd-11e7-9412-00163e065a89"
      },
      staffList: [],
      option2: [ // 上级
        {text: '全部', value: null},
        {text: '已结束', value: 2},
        {text: '已发布', value: 1},
        {text: '未提交', value: 0},
      ],
      option3: [ // 学生
        {text: '全部', value: null},
        {text: '已结束', value: 2},
        {text: '已发布', value: 1},
      ],
      option4: [],
      name: this.$route.query.id ? '安排修改' : '添加安排',
      checkStaff: [],
      itemTitle: '科室',
      testDetailInfo: {},
      sectionId: ''
    }
  },
  computed: {

    typeColumns() {
      let arr = []
      this.option1.map(item => {
        arr.push(item.text)
      })
      return arr;
    },
    isEdit() {
      return this.action === 3 || (this.action === 0 && this.userId === this.formData.userId);
    }
  },
  methods: {
    onSubmit() {
      this.$refs.activitiesForm.validate().then(() => {

        if (this.formData.id) {
          updatePlanAndUser(this.formData).then(() => {
            this.$toast.success('修改成功!')
            setTimeout(() => {
              this.$router.go(-1)
            }, 1000)
          })
        } else {
          createPlanAndUser(this.formData).then(() => {
            this.$toast.success('添加成功!')
            setTimeout(() => {
              this.$router.go(-1)
            }, 1000)
          })
        }
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    // 发布
    release() {
      let param = {
        "endDate": this.formData.endDate,
        "location": this.formData.location,
        "remark": this.formData.remark,
        "startDate": this.formData.startDate,
        "name": this.formData.name,
        "volumeId": this.formData.volumeId,
        "typeId": this.formData.typeId.value,
        id: this.currentData.id,
        status: 1
      }
      updateTeachactivity(param).then(() => {
        this.$toast.success('发布成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },
    // 删除活动
    removeA() {
      removeTeachactivity({
        id: this.currentData.id
      }).then(() => {
        this.$toast.success('删除成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },
    onConfirm(value, target, name, id, show, cb) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (cb) {
        cb(value)
      }
    },

    onTypeConfirm(value, index) {
      this.formData.typeId = this.option1[index].value;
      this.formData.effective = value;
      this.showTypePicker = false;
    },


    onDateConfirm(value) {
      this.formData.startDate = getNowFormatDate(value) + ' 00:00:00'
      this.showDatePicker = false;
    },
    // 开始时间
    onStartDateConfirm(value) {
      this.formData.startDate = getNowFormatDate(value)
      this.showStartTimePicker = false;
    },
    // 结束时间
    onEndDateConfirm(value) {
      this.formData.endDate = getNowFormatDate(value)
      this.showEndTimePicker = false;
    },
    checkFn(data) {
      this.formData.volumeId = data.value
      this.formData.volumeName = data.text
      this.showPicker = false
    },
    // 获取类型
    getTypeList() {
      getDictionaryType('TeachActivityType').then(res => {
        let data = res.data.data
        let arr = []
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          arr.push(obj)
        })

        this.option1 = arr;
      })
    },
    // 结束活动
    activitiesOver() {
      let param = {
        id: this.currentData.id,
        status: 2
      }
      updateTeachactivity(param).then(() => {
        this.$toast.success('结束成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },

    // 获取列表
    getList() {
      getTeachactivity(this.listParams).then(res => {
        this.testData = res.data.list;
      })
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule({
        pageSize: 999,
        pageNum: 1,
      }).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option4 = [...optionArr]
        this.itemTitle = this.option4[0].text
        this.staffParam.sectionList = this.option4[0].value
        if(this.formData.typeName === '结业考核'){
          this.staffParam.studentStatus = 3
        }
        this.staffListsFn()
      })
    },
    // 获取人员信息
    staffListsFn() {
      staffLists(this.staffParam).then(res => {
        this.staffList = res.data.list
      })
    },
    // 设置科室选中更新
    beforeStaffListsFn(val) {
      this.option4.forEach(item => {
        if (item.value === val) {
          this.itemTitle = item.text
        }
      })
      this.staffListsFn()
    },
    // 获取考试详情
    testDetailFn() {
      testDetail({
        planId: this.formData.id || ''
      }).then(r => {
        if (r.data) {
          this.testDetailInfo = r.data
        }
      })
    },
    // 获取picker数据格式
    getData(url, params, target, prop = 'name', propId = 'id') {
      urlForPost(url, params).then(res => {
        let optionArr = []
        res.data.data.forEach(item => {
          let obj = {
            text: item[prop],
            value: item[propId]
          }
          optionArr.push(obj)
        })
        this[target] = optionArr
      })
    },
    typeChange(data){
      if(data.text === '结业考核'){
        this.staffParam.studentStatus = 3
        this.staffListsFn()
      }else{
        delete this.staffParam.studentStatus
        this.staffListsFn()
      }
    },
    clickStaff(){
      if(!this.formData.type){
        this.$toast.fail('请先选择考试类型!')
      }else{
        this.staffIdsPicker = true
      }
    },
    changeStaff(e, data){
      if(this.formData.id){
        urlForPost('/examplan/selectIsCompletedByStaffId', {
          planId: this.formData.id,
          staffIdsStr: data.id
        }).then(res => {
          if(res.data.list.length !== 0){
            this.$toast.fail('该学员已完成考试, 不能取消!')
            this.formData.staffIds.push(data.id)
          }
        })
      }
    }
  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    if (this.role !== 'JXS_manager') {
      this.sectionId = localStorage.getItem('sectionId')
    }
    if (this.$route.query.id) {
      let arr = this.$route.query
      arr.staffIds = arr.staffIds || []
      this.formData = arr
      this.formData.onlineFlag = parseInt(arr.onlineFlag)
      examplanUser({examId: this.$route.query.id}).then(res => {
        let arr = []
        this.checkStaff = res.data.data.list
        this.checkStaff.forEach(item => {
          arr.push(item.id)
        })
        this.formData.staffIds = arr;
      })
    }
    this.userId = localStorage.getItem('userId')
    // let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
    // this.ac_userId = localStorage.getItem('userId')
    // this.currentData = currentForm
    // let len = Object.keys(currentForm).length
    // if (len === 0) {
    //   this.action = 3
    // } else {
    //   this.action = currentForm.status
    //   this.formData = Object.assign(this.formData, currentForm)
    // }
    // localStorage.setItem('currentData', '')
    this.getTypeList() // 获取类型
    this.transferGet() // 获取科室
    this.testDetailFn() // 获取考试结果统计
    this.getData('/dictionary/getByTypeCode/EvaluateType', '', 'marketColumns')
  }
}
</script>
