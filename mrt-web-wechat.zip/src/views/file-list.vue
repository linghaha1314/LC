<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div style="background: #f6f6f6;">
      <div style="min-height: 60vh; font-size: 16px; font-weight: bold; text-align: center;">
        <div style="margin:12px 0; background: #fff; padding: 12px;" v-for="(item, index) in attachList" :key="index">
            <div style="text-align: center; display: flex; flex-direction: column; align-items: center; margin-bottom: 12px;" v-if='item.attachPath'>
              <van-icon name="photo-o" size="30" @click="checkimgFn(item.attachPath)" v-if="item.attachPath.indexOf('jpg')>0 ||item.attachPath.indexOf('png')>0 "
              />
              <a :href="item.attachPath" download="附件" v-else>
                <van-icon name="orders-o" size="30" />
              </a>
              {{item.attachPath.split('/')[item.attachPath.split('/').length-1]}}
            </div>
            <van-button square text="删除" size="mini" type="danger" class="delete-button" v-if="role !== 'StudentType_jxs' && formData.id" @click="delFile(item)"/>
        </div>
      </div>
      <van-popup v-model="showImgFilePicker" position="bottom">
        <img style="max-width:100vw;max-height:100vh" :src="seeImgUrl" alt="图片出问题了"/>
      </van-popup>
    </div>

    <van-field name="attachPath" label="附件上传" v-if="role !== 'StudentType_jxs' && formData.id">
      <template #input>
        <van-uploader accept=".doc,.docx,image/*,.pdf" v-model="attachPath" :after-read="afterRead"
                      @delete="delFn"/>
      </template>
    </van-field>
  </div>
</template>
<script>
  import { uploadFile, deleteAttachFile, addAttachFile, activityattachList } from '../http/apiMap';
  export default {
    name: 'test',
    data() {
      return {
        formData:{},
        listParams: {
          pageSize: 999,
          pageNum: 1,
          activityId: this.$route.query.id,
        },
        attachList:[],
        name: '附件',
        showImgFilePicker: false,
        seeImgUrl: '',
        attachPath: [],
        saveFile:[],
        role: ''
      }
    },
    computed: {

    },
    
    methods: {
      // 获取列表
      getList() {
        activityattachList(this.listParams).then(res => {
          this.attachList = res.data.list;
        })
      },

      goDetail(data) {
        this.$router.push({
          path: '/message-detail',
          query: data
        })
      },
      // 标签栏
      tabFn() {
        this.listParams.flag = this.active === 0 ? 'unread' : 'read'
        this.getList();
      },
      // 选择图片
      checkimgFn(url){
        this.showImgFilePicker = true;
        this.seeImgUrl = url
      },
      afterRead(file) {
        let data = new FormData()
        data.append('multipartFile', file.file)
        uploadFile(data).then(res => {
          this.formData.attachPath = res.data.path
          this.saveAttach()
        })
      },
      // 删除附件
      delFn(file) {
        let name = file.file.name
        let param = {}
        this.saveFile.forEach(item => {
          if(item.attachPath.indexOf(name)>0){
            param=item
          }
        })
        deleteAttachFile(param).then()
      },
      delFile(data){
        deleteAttachFile(data).then(()=>{
          this.getList()
        })
      },
      saveAttach(){
          let param = {
            "activityId": this.formData.id,
            "attachPath": this.formData.attachPath
          }
          addAttachFile(param).then(res=>{
            this.saveFile.push({
              id: res.data.data["reasons"].data.id,
              attachPath: this.formData.attachPath
            })
            this.getList()
          })
      },
    },
    mounted() {
        this.role = localStorage.getItem('roleCode')
        this.formData = this.$route.query
        this.getList()
      },
  }
</script>