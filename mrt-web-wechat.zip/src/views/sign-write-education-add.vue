<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form @submit="onSubmit">
      <div>

        <van-field
            readonly
            clickable
            required
            name="date"
            label="开始日期"
            :value="formData.startDate&&formData.startDate.substring(0,10)"
            placeholder="选择开始日期"
            @click="showDatePicker = true"
            :rules="[{ required: true, message: '请选择开始日期' }]"
        />
        <van-popup v-model="showDatePicker" round position="bottom">
          <van-datetime-picker
              v-model="formData.currentDate"
              type="date"
              title="开始日期"
              @cancel="showDatePicker = false"
              @confirm="onDateConfirm($event,formData,'startDate','showDatePicker')"
              :min-date="minEndDate"
          />
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="date"
            label="结束时间"
            :value="formData.endDate&&formData.endDate.substring(0,10)"
            placeholder="选择结束时间"
            @click="showEndDatePicker = true"
            :rules="[{ required: true, message: '请选择结束时间' }]"
        />
        <van-popup v-model="showEndDatePicker" round position="bottom">
          <van-datetime-picker
              v-model="formData.currentDate"
              type="date"
              title="结束时间"
              @cancel="showEndDatePicker = false"
              @confirm="onDateConfirm($event,formData,'endDate','showEndDatePicker')"
              :min-date="minDate"
          />
          <div style="font-size:20px;text-align: center;margin: 30px"
               @click="setNow"
          >至今</div>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="学历"
            :value="formData['academicName']"
            placeholder="选择学历"
            @click="showEducationPicker = true"
            :rules="[{ required: true, message: '请选择学历' }]"
        />
        <van-popup v-model="showEducationPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Education"
                    @cancel="showEducationPicker = false"
                    @confirm="onConfirm($event,formData,'academicName','academicId','showEducationPicker')"
          ></m-picker>
        </van-popup>


        <van-field
            v-model="formData['academicNo']"
            label="学历证书编码"
            required
            placeholder="请输入学历证书编码"
            :rules="[{ required: true, message: '请输入学历证书编码' }]"
        />

        <van-field
            readonly
            clickable
            name="typeId"
            label="学位"
            :value="formData['degreeName']"
            placeholder="选择学位"
            @click="showDegreePicker = true"
            :rules="[{ required: true, message: '请选择学位' }]"
            v-if="formData['academicName']!=='大学专科' && formData['academicName']!=='高中' && formData['academicName']!=='中专'"
        />
        <van-popup v-model="showDegreePicker" round position="bottom">
          <van-picker :columns="degreeColumns" :show-toolbar="true" @cancel="categoryPicker = false" @confirm="onConfirm($event,formData,'degreeName','degreeId','showDegreePicker')"
          />
          <!-- <m-picker :url="edubackgroudDegreeUrl"
                    code=""
                    @cancel="showDegreePicker = false"
                    @confirm="onConfirm($event,formData,'degreeName','degreeId','showDegreePicker')"
          ></m-picker> -->
        </van-popup>

        <van-field
            v-model="formData['degreeNo']"
            label="学位证书编码"
            placeholder="请输入学位证书编码"
            v-if="formData['academicName']!=='大学专科' && formData['academicName']!=='高中' && formData['academicName']!=='中专'"
        />

        <van-field
            v-model="formData.subject"
            required
            label="所学专业"
            :rules="[{ required: true, message: '请填写所学专业' }]"
        />

        <van-field
            v-model="formData['school']"
            required
            label="学校名称"
            :rules="[{ required: true, message: '请填写学校名称' }]"
        />

        <van-field
            v-model="formData['schoolYears']"
            required
            type="number"
            label="学制"
            :rules="[{ required: true, message: '请填写学制' }]"
        />

        <van-field
            v-model="formData.remark"
            name="remark"
            label="备注信息"
            placeholder="请填写备注信息"
        />
      </div>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <div style="margin: 16px;">
        <van-button round block color="#17d4b5" native-type="submit">
          提交
        </van-button>
      </div>

    </van-form>
  </div>
</template>
<script>
  import mPicker from '../components/m-picker'
  import {
    urlForPost
  } from '../http/apiMap'
  export default {
    name: 'test',
    components: {
      mPicker
    },
    data() {
      return {
        url:{
          SaveOrUpdateEduBackgroud: '/advancedsignup/SaveOrUpdateEduBackgroud',
          degree: '/dictionary/getByTypeCodeParams'
        },
        formData: {},
        showDatePicker: false, 
        showEducationPicker: false,
        showDegreePicker: false,
        showEndDatePicker: false,
        minDate: new Date(1960, 1, 1), 
        minEndDate: new Date(1960, 1, 1),
        currentDate: new Date(),
        degreeColumns: [],
        name: '学历',
        edubackgroudDegreeUrl: "'dg_none'"
      }
    },
    computed: {},
    methods: {
      onSubmit() {
        this.formData.staffId = sessionStorage.getItem('staffId')
        urlForPost(this.url.SaveOrUpdateEduBackgroud,this.formData).then(res => {
          if (res.data.success) {
            this.$toast.fail('保存成功!')
            this.formData = {}
            this.$router.replace('/sign-write-education')
          } else {
            this.$toast.fail('保存失败!')
          }
        })
      },
      onConfirm(value, target, name, id, show) {
        target[name] = value.text
        target[id] = value.value
        this[show] = false;
        if(id==='academicId'){
          this.te()
        }
      },
      onDateConfirm(value, target, prop, show) {
        target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
        this[show] = false;
        if(prop === 'startDate'){
          this.minEndDate = value
        }
      },
      // 时间格式
      getNowFormatDate(date) {
        let seperator1 = "-";
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let strDate = date.getDate();
        if (month >= 1 && month <= 9) {
          month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
        }
        return year + seperator1 + month + seperator1 + strDate;
      },
      getDegree(){
        urlForPost(this.url.degree, {
          pageNum: 1,
          pageSize: 999,
          dtCode: 'Degree',
          containCodes: this.edubackgroudDegreeUrl
        }).then(res => {
          let data = res.data.list,
            targetArr = [];
          data.forEach(item => {
            targetArr.push({
              text: item['name'],
              value: item['id']
            })
          })
          this.degreeColumns = targetArr
        })
      },
      te(){
        if (this.formData['academicName'] === '硕士研究生') {//硕士研究生
          this.edubackgroudDegreeUrl = "'dg_master','dg_none'";
        } else if (this.formData['academicName'] === '博士研究生') {//博士研究生
          this.edubackgroudDegreeUrl = "'dg_postDoctor','dg_doctor','dg_none'";
        } else if (this.formData['academicName'] === '大学本科') {//本科
          this.edubackgroudDegreeUrl = "'dg_bachelor','dg_none'";
        } else {//专科
          this.edubackgroudDegreeUrl = "'dg_none'";
        }
        this.getDegree()
      },
      setNow(){
        this.formData.endDate = '至今'
        this.showEndPicker = false
      }
    },
    mounted() {
      this.formData = JSON.parse(localStorage.getItem('currentEducationData') || '{}')
    }
  }
</script>