<template>
    <div class="about">
        <van-nav-bar title="进修申请表" left-arrow>
            <template #left>
                <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
            </template>
        </van-nav-bar>
        <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
            <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
                进修申请表上传
            </div>
        </div>
        <div>
            <div style="font-size: 16px;padding: 12px;">
                1. 点击按钮" 下载申请表 ", 打印后交选送单位盖章.
                <van-button style="width: 30vw; margin: 12px" size="mini" round block color="#17d4b5" @click="goDownload">
                        下载申请表
                </van-button>
            </div>
            <div style="font-size: 16px;padding: 12px;">
                2. 拍照上传盖章后的申请表
            </div>
            <van-form>
                <van-field name="application" required label="上传申请表" :value="application[0]&&application[0].pathAttach" :rules="[{ required: true, message: '请上传申请表' }]">
                    <template #input>
                      <van-uploader v-model="application" :after-read="afterRead" :before-delete='beforeDelete' />
                    </template>
                </van-field>
            </van-form>
            <div style="margin: 16px;display: flex;">
                <van-button style="margin-bottom: 12px;" round block @click="goPre">
                    上一步
                </van-button>
                <van-button round block color="#17d4b5" @click="attendAdd">
                    提交报名
                </van-button>
            </div>
        </div>
    </div>
</template>
<script>
    import { uploadSignFile, urlForPost, getCertificate } from "../http/apiMap";
    import { Dialog } from 'vant';
    export default {
        name: 'application',
        data() {
            return {
                url: {
                    create: '/advancedsignupattach/create',
                    removeFile: '/advancedsignupattach/deleteFile',
                    removeData: '/advancedsignupattach/remove',
                    save: '/advancedsignup/saveOrUpdateAdvancedSignup'
                },
                formData: {},
                projectInfo: JSON.parse(localStorage.getItem('signInfo')),
                signupId: sessionStorage.getItem('signupId'),
                application: []
            }
        },
        computed: {
        },
        methods: {

            goPre() {
                sessionStorage.setItem('application', JSON.stringify(this.application))
                this.$router.push({
                    path: '/sign-write-company'
                })
            },
            attendAdd() {
                if(this.application.length>0){
                  let batchData = JSON.parse(sessionStorage.getItem('majorData'))
                  Dialog.confirm({
                    title: '温馨提示:',
                    message: '一旦提交报名便无法修改,确认继续吗？',
                    confirmButtonColor: '#17d4b5'
                  }).then(() => {
                    let batchId;
                    if(this.projectInfo.trainTypeCode!=='MandatoryCommissionedTraining'){
                      batchId = this.projectInfo.id
                    }else{
                      batchId = batchData.batchId
                    }
                    let fromUnit = JSON.parse(sessionStorage.getItem('companyData'))
                    let param = {
                      status: 1,
                      applyDate: this.getNowFormatDate(new Date()),
                      id: sessionStorage.getItem('signupId'),
                      staffId: sessionStorage.getItem('staffId'),
                      typeCode: this.projectInfo.trainTypeCode,
                      batchId: batchId,
                      fromUnitId: fromUnit.id
                    }
                    urlForPost(this.url.save,param).then(res => {
                      let data = res.data
                      if (data.success) {
                        this.$toast.success('提交报名成功!');
                        this.$router.replace({
                          path: '/login'
                        })
                      }
                    })
                  })
                }else{
                  this.$toast.fail('请上传申请书后提交!')
                }
            },
            afterRead(file) {
                let data = new FormData()
                data.append('multipartFile', file.file)
                uploadSignFile(data).then(res => {
                    this.formData.attachPath = res.data.path
                    file.pathAttach = res.data.path
                    this.saveAttach(res.data.path, file)
                })
            },
            beforeRead(file) {
                if (file.type === 'image/jpeg' || file.type === 'image/png') {
                    return true;
                } else {
                    this.$toast.fail('请上传图片');
                    return false;
                }
            },
            goDownload(){
                this.$router.push({
                    path: '/download-page',
                    query: {
                        type: 'application',
                        hospitalId: this.projectInfo.hospitalId,
                        staffId: sessionStorage.getItem('staffId'),
                        trainTypeCode: this.projectInfo.trainTypeCode
                    }
                })
            },

            saveAttach(path, objFile) {
                let param = {
                    "signupId": sessionStorage.getItem('signupId'),
                    "typeCode": 'ApplicationForm',
                    "path": path
                }
                urlForPost(this.url.create, param).then(res => {
                    objFile.id = res.data.data["reasons"].data.id
                })
            },
            getNowFormatDate(date) {
                let seperator1 = "-";
                let year = date.getFullYear();
                let month = date.getMonth() + 1;
                let strDate = date.getDate();
                if (month >= 1 && month <= 9) {
                    month = "0" + month;
                }
                if (strDate >= 0 && strDate <= 9) {
                    strDate = "0" + strDate;
                }

                return year + seperator1 + month + seperator1 + strDate;
            },
            beforeDelete(file) {
                urlForPost(this.url.removeFile, {
                    path: file.pathAttach
                }).then()
                urlForPost(this.url.removeData + "/" + file.id).then(() => {
                    this.getCertificateFn('ApplicationForm')
                })
            },
            getCertificateFn(code = '') {
                if(this.signupId){
                    getCertificate({
                      "signupId": this.signupId,
                      "typeCode": code,
                      "pageSize": 999,
                      "pageNum": 1
                    }).then(res => {
                      let data = res.data.list
                      if(data[0].id){
                        this.$set(this,'application',[{
                          url: data[0].path,
                          pathAttach: data[0].path,
                          id: data[0].id
                        }])
                      }
                    })
                }
            },
            // 缓存本地
            getSession() {
                sessionStorage.setItem('application', JSON.stringify(this.formData))
            }
        },
        mounted() {
            this.getCertificateFn('ApplicationForm')
        }
    }
</script>
