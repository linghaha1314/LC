<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.replace('/home')">返回</span>
      </template>
    </van-nav-bar>
    <div v-if="role !== 'StudentType_jxs'">
      <van-dropdown-menu active-color="#17d4b5">
        <section-drop  v-model="listParams.sectionId" @change="onRefresh"></section-drop>
        <batch-drop v-model="listParams.batchId" @change="onRefresh"></batch-drop>
        <van-dropdown-item v-if="this.queryData.type !== 'back-approve'" title="类型" v-model="listParams.volumeId" @change="onRefresh" :options="option2" />
        <year-drop v-model="listParams.year" @change="getList"></year-drop>
        <van-dropdown-item title="状态" v-model="listParams.status" @change="onRefresh" :options="option3"/>
      </van-dropdown-menu>
    </div>
    <div style="display: flex;justify-content: space-between;align-items: center; padding: 0 12px;">

      <van-search v-model="listParams.name" shape="round" @change="onRefresh" placeholder="搜索" style="width: 100%" />
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <!--      testData ||-->
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <van-cell v-for="(item,index) in testData"
                    :key="index">
            <!-- 使用 title 插槽来自定义标题 -->
            <template #title>
              <div style="display: flex;align-items: center">
                <!--            <div style="margin-right: 12px">-->
                <!--              <div style="width: 50px;height: 50px; display: flex;justify-content: center;align-items: center;">-->
                <!--                <van-image-->
                <!--                    round-->
                <!--                    width="50px"-->
                <!--                    height="50px"-->
                <!--                    src="https://img.yzcdn.cn/vant/cat.jpeg"-->
                <!--                />-->
                <!--              </div>-->
                <!--            </div>-->
                <div style="flex: 1;">
                  <div style="padding-left: 8px;font-size: 16px;font-weight: bold">{{ item.volumeName || '无' }}</div>
                  <div
                      style="padding-left: 8px;width:206px;box-sizing: border-box; overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
                    姓名：{{
                      item['studentName']
                      || '无'
                    }}
                  </div>
                  <div
                      style="padding-left: 8px;width:206px;box-sizing: border-box; overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
                    科室：{{
                      item['sectionName']
                      || '无'
                    }}
                  </div>
                  <div
                      style="padding-left: 8px;width:206px;box-sizing: border-box; overflow: hidden;white-space: nowrap;text-overflow: ellipsis;">
                    专业：{{
                      item['majorName']
                      || '无'
                    }}
                  </div>
                </div>
                <div style="text-align: right;">
                  <van-button v-if="item.status !== 0" style="width: 50px; margin-right: 12px"
                              type="danger" size="mini" @click="goDetail(item,'/questionnaire-answer-detail')">查看
                  </van-button>
                  <van-button v-if="role === 'StudentType_jxs' && item.status === 0"
                              style="width: 50px; margin-right: 12px" type="primary" size="mini" @click="goDetail(item,'/paper')">填写
                  </van-button>
                </div>
              </div>
            </template>
            <template #right-icon>
              <van-icon v-if="item.status === 0" size="20" name="cross" class="search-icon"  color="#ee0a24"/>
              <van-icon v-else name="success" size="20" class="search-icon" color="#1aff53"/>
              {{item.status === 0?'未填':'已填'}}
            </template>
          </van-cell>
        </van-list>
      </van-pull-refresh>

    </div>
  </div>
</template>
<script>
import {urlForPost} from '../http/apiMap';
import SectionDrop from '../components/section-drop'
import BatchDrop from '../components/batch-drop'
import YearDrop from '../components/year-drop'
export default {
  name: 'test',
  components: {
    SectionDrop,
    BatchDrop,
    YearDrop
  },
  data() {
    return {
      listParams: {
        pageSize: 10,
        pageNum: 0,
        code: this.$route.query.code,
        flag: 'unread',
        year: null
      },
      role: '',
      testData: [],
      option2: [],
      name: '问卷调查',
      active: '',
      queryData: this.$route.query,
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      option3: [
        {text: '全部', value: null},
        {text: '已填', value: 1},
        {text: '未填', value: 0},
        // {text: '已通过', value: 3},
      ],
    }
  },
  computed: {},
  mounted() {
    this.role = localStorage.getItem('roleCode')
    if(this.queryData.type === 'back-approve'){
      this.name = '结业随访'
    }
    this.getType()
  },
  methods: {
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.testData = [];
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.getList(flag)
    },
    // 获取列表
    getList(f) {
      if(this.$route.query.type === 'edit'){
        urlForPost('/surveyanswer/getMySurveyVolume',this.listParams).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.list]
          }else{
            this.testData = [...res.data.list];
          }
          // this.testData = res.data.list;
        })
      } else if (this.$route.query.type === 'back') {
        urlForPost('/returnVisitStudent/getMySurveyVolume',this.listParams).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.list]
          }else{
            this.testData = [...res.data.list];
          }
          // this.testData = res.data.list;
        })
      } else if (this.$route.query.type === 'back-approve') {
        urlForPost('/returnVisitStudent/getAllstudent',this.listParams).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if (res.data.data.list.length === 0 || res.data.data.list.length<this.listParams.pageSize) {
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.data.list]
          }else{
            this.testData = [...res.data.data.list];
          }
          // this.testData = res.data.list;
        })
      } else {
        urlForPost('/surveyanswer/getAllstudent',this.listParams).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if (res.data.data.list.length === 0 || res.data.data.list.length<this.listParams.pageSize) {
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.data.list]
          }else{
            this.testData = [...res.data.data.list];
          }
          // this.testData = res.data.list;
        })
      }

    },

    goDetail(data,path) {
      this.$router.push({
        path: path,
        query: {
          type: 'questionnaire',
          ...data
        }
      })
    },
    // 标签栏
    tabFn() {
      this.listParams.flag = this.active === 0 ? 'unread' : 'read'
      this.getList();
    },
    getType(){
      urlForPost('/surveyvolume/getListQueryByPage',{
        pageSize: 888,
        pageNum: 1,
        volumeFlag: 1
      }).then(res=>{
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          if(item.name!=='结业回访问卷'){
            let obj = {
              text: item.name,
              value: item.id
            }
            optionArr.push(obj)
          }
        })
        this.option2 = [...optionArr]
      })
    }
  }
}
</script>
