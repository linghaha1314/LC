<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">

      <van-field readonly clickable required name="typeId" label="类型" :value="formData.typeName" placeholder="选择类型"
                 @click="showTypePicker = true"
                 :rules="[{ required: true, message: '请选择类型' }]"/>
      <van-popup v-model="showTypePicker" round position="bottom">
        <van-picker :columns="typeColumns" :show-toolbar="true" @cancel="showTypePicker = false"
                    @confirm="onTypeConfirm"/>
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field name="fileList" :value="fileList[0]&&fileList[0].attachPath" label="附件上传" required :rules="[{ required: true, message: '请上传附件' }]">
        <template #input>
          <van-uploader v-model="fileList" :after-read="afterRead" :before-read="beforeRead" :before-delete='beforeDelete'/>
        </template>
      </van-field>
      <div style="margin: 16px;">
        <van-button round block :disabled="disabled" color="#17d4b5" @click="onSubmit   ">
          保存资料
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {
  getLeaveType,
  getTeacher,
  uploadFile,
  getMobileProcess,
  getLeaveVerification,
  currentTeacher,
  urlForPost
} from '@/http/apiMap'
import {Dialog} from 'vant';
export default {
  name: 'test',

  data() {
    return {
      url: {
        removeFile: '/advancedsignupattach/attachDeleteFile',
        removeData: '/advancedsignupattach/remove',
      },
      formData: {
        typeId: '',
        typeName: '',
        attachPath: '',
        attach: [],
      },
      teacherParams: {
        sectionId: localStorage.getItem('currentSectionId')
      },
      showPicker: false,
      showTypePicker: false,
      showTripPicker: false,
      showRiskPicker: false,
      showDatePicker: false,
      showEndDatePicker: false,
      typeColumns: [],
      action: 3,
      columns: [],
      attachFlag: false,
      leaveDays: 0,
      disabled: false,
      columns1: ['上午', '下午'],
      columnsValue: '',
      fileList: []
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          let param = {
            path: this.formData.attachPath,
            typeCode: this.formData.typeId,
            signupId: this.formData.id || ''
          }
          urlForPost('/student/getDetailById', {
            id: localStorage.getItem('studentId')
          }).then(res => {
            param.signupId = res.data.data.signupId
            this.fileList.forEach(item => {
              param.path = item.attachPath
              urlForPost('/advancedsignupattach/create', param).then(() => {
                this.$toast.success('上传成功!!')
              })
            })
            Dialog.alert({
              message: '上传成功!!'
            }).then(()=>{
              this.$router.go(-1)
            })
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },
    onConfirm(value, target, name, id, show, cb) {
      target[id] = value.value
      target[name] = value.text
      this[show] = false;
      if (cb) {
        cb()
      }
    },
    onTypeConfirm(value) {
      this.formData.typeId = value.code;
      this.formData.typeName = value.text;
      this.attachFlag = value.attachFlag;
      this.showTypePicker = false;
    },
    // onDateConfirmF(value, target, prop, show) {
    //   target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
    //   this[show] = false;
    // },
    onDateConfirm(value) {
      let yy = value.getFullYear(),
          mm = value.getMonth(),
          dd = value.getDate();
      this.formData.startDate = this.getNowFormatDate(new Date(yy, mm, dd, this.columnsValue === '下午' ? 13 : 9), 0, 0) + ':00:00';
      this.formData.currentDate = new Date(yy, mm, dd)
      let endDD = new Date(yy, mm, dd).valueOf() + ((this.columnsValue === '下午' ? 0.5 : 0) + parseFloat(this.formData.days)) * (1000 * 60 * 60 * 24)-1
      this.formData.currentEndDate = new Date(endDD)

      this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      if (this.columnsValue === '') {
        this.columnsValue = '上午'
      }
      this.showDatePicker = false;
    },

    // 请假时长
    leaveNum() {
      if (this.formData.days > this.leaveDays) {
        this.$toast.fail('剩下休假时间不足,已改为最大天数!')
        this.formData.days = this.leaveDays
      }
      if (this.formData.currentDate) {
        let endDD = this.formData.currentDate.valueOf() + ((this.columnsValue === '下午' ? 0.5 : 0) + parseFloat(this.formData.days)) * (1000 * 60 * 60 * 24)-1
        this.formData.currentEndDate = new Date(endDD)
        this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      } else {
        this.formData.days = 0
        this.$toast.fail('请先选择起始时间!')
      }
    },

    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      let strH = date.getHours();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      if (strH >= 0 && strH <= 9) {
        strH = "0" + strH;
      }
      return year + seperator1 + month + seperator1 + strDate + ' ' + strH;
    },

    // 获取请假类型
    leaveTypeGet() {
      urlForPost('/advancedsignup/getByCode/advancedAttachType',{}).then(res => {
        let arr = res.data.list
        let typeArr = []
        arr.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            attachFlag: item.attachFlag,
            ...item
          }
          // item.values = item.name
          typeArr.push(obj)
        })
        this.typeColumns = typeArr
      })
    },
    // 获取带教老师数据
    teacherGet() {
      getTeacher(this.teacherParams).then(res => {
        let arr = res.data.list
        let teacherArr = []
        arr.forEach(item => {
          let obj = {
            text: item.teacherName,
            value: item.teacherId
          }
          // item.values = item.name
          teacherArr.push(obj)
        })
        this.columns = teacherArr
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        this.formData.attachPath = res.data.path
        file.attachPath = res.data.path
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    filterFn(type, options) {
      if (type === 'hour') {
        let arr = []
        options.forEach(item => {
          if (parseInt(item) === 9 || parseInt(item) === 13) {
            arr.push(item)
          }
        })
        return options = arr;
      }
      return options;
    },
    getDaysFn() {
      getLeaveVerification({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        let data = res.data.data;
        this.leaveDays = data["maxLeaveDays"] - data["totalDays"]
      })
    },
    onChange(picker, value) {
      this.columnsValue = value
    },
    currentTeacherFn() {
      currentTeacher({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        this.formData.medicalTeamLeaderName = res.data.data.teacherName
        this.formData.medicalTeamLeaderId = res.data.data.teacherStaffId
      })
    },
    // 缓存本地
    getSession() {
      sessionStorage.setItem('currentData', JSON.stringify(this.formData))
    },
    beforeDelete(file){
      if(file.id){
        urlForPost(this.url.removeData + "/" + file.id).then(()=>{
          this.getCertificateFn()
        })
      }
      if(file.attachPath){
        urlForPost(this.url.removeFile,{
          path: file.attachPath
        }).then(()=>{
          let arr = []
          this.fileList.forEach(item => {
            if(file.attachPath !== item.attachPath){
              arr.push(item)
            }
          })
          this.fileList = [...arr]
        })
      }
    },
  },
  mounted() {
    let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
    let len = Object.keys(currentForm).length
    if (len === 0) {
      this.action = 3
    } else {
      this.formData = Object.assign(this.formData, currentForm)
      this.fileList.push({
        attachPath: this.formData.path
      })
    }
    this.leaveTypeGet() // 获取类型
  }
}
</script>
