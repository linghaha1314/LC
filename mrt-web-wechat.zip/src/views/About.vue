<template>
  <div class="about">
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 20px 12px;text-align: justify;" v-html="msg"></div>
  </div>
</template>
<script>

    import { aboutus } from '../http/apiMap';
    export default {
        name: 'About',
        data(){
            return{
                msg:''
            }
        },
        computed:{
            name(){
                return this.$route.name
            },
        },
        methods:{

        },
        mounted() {
            aboutus().then(res => {
                this.msg = res.data
            })
        }
    }
</script>