<template>
  <div id="pBox" style="width: 100%;min-height: 60px;">
    外: {{hCount+'px'}} 子: {{childBox+'个'}}
    <van-row v-for="t in hCount" :key="t" gutter="20" type="flex" justify="space-between" :style="{'flex-direction': t%2 === 0?'row-reverse':'row'}">
      <van-col class="childBox" v-for="i in childBox" :key="i" :style="{width: childBoxWidth+'px','text-align':'center'}">
        <div style="background:#cccccc;padding: 12px; margin: 12px;" v-if="innerInfo(t,i) < testData.length">
          元素: {{testData[innerInfo(t,i)]}}
          <van-icon v-if="i !== childBox && innerInfo(t,i) !== testData.length-1" :name="t%2 === 0?'arrow-left':'arrow'" />
        </div>
      </van-col>
      <div v-if="t !== hCount" :style="{'text-align': (t-1)%2 === 0 ? 'right' : 'left','width': '100%'}">
        <div :style="{width: childBoxWidth+'px','text-align':'center',display: 'inline-block'}">
          <van-icon name="arrow-down" />
        </div>
      </div>
    </van-row>
  </div>
</template>
<script>
export default {
  name: 'test',
  components: {
  },
  data() {
    return {
      testData: [1,2,3,4,5,6,7,8,9],
      pWidth: 0,
      childBoxWidth: 180,
      childBox: 0,
      hCount: 0
    }
  },
  computed: {
    // innerInfo(h,l){
    //   let ind = 0
    //
    //   return this.testData[ind]
    // }
  },
  methods: {
    onResize(){
      this.pWidth = document.getElementById('pBox').clientWidth
      this.childBox = Math.floor(this.pWidth/this.childBoxWidth)
      this.hCount = Math.ceil(this.testData.length/this.childBox)
    },
    innerInfo(h,l){
      let ind = 0
      ind = (h-1)*this.childBox + (l-1)
      return ind
    }
  },
  mounted() {
    this.onResize()
    window.addEventListener('resize', this.onResize)
  }
}
</script>
