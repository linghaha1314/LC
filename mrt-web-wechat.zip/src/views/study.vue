<template>
    <div>
        <div>
            <van-search
                v-model="listParams.name"
                shape="round"
                placeholder="搜索课程"
                @change="getCourseList"
            />
        </div>
        <div>
            <van-tabs color="#17d4b5" @click="checkType">
                <van-tab v-for="type in typeList" :title="type.name" :key="type.id">
                </van-tab>
            </van-tabs>
        </div>
        <div style="border-left: 4px solid #17d4b5; font-size: 14px; font-weight: bold; margin: 20px 12px; text-align: left; padding-left: 4px">
            课程
        </div>
        <div v-for="item in list" :key="item.id" style="position: relative; margin-bottom: 12px;">
            <van-card
                :title="item.name"
                :thumb="item['thumbImage'] ||'https://img.yzcdn.cn/vant/ipad.jpeg'"
                @click="startStudy(item)"
            >
                <template #num>
                    <div style="flex: 1;width: 100%; display: flex; flex-direction: column">
                        <div style="text-align: right">
                            <img style="width: 14px; height: 14px; border-radius: 50%;" src="https://img.yzcdn.cn/vant/cat.jpeg" alt="头像">
                            {{item.userName || '无'}}老师
                        </div>
                        <div>{{item.startDate || '无'}} 至 {{item.endDate || '无'}}</div>
                    </div>
                </template>

            </van-card>
<!--            <div style="position: absolute; right: 12px; bottom: 16px;">-->
<!--                <van-button type="primary" size="mini">查看详情</van-button>-->
<!--            </div>-->
        </div>
    </div>
</template>

<script>
    import {courseList, courseTypeList, memberCreate, memberDetail} from '../http/apiMap';
    export default {
        name: "study.vue",
        data () {
            return{
                value: '',
                listParams:{
                    pageSize: 999,
                    pageNum: 1,
                    type: 'selectCourse',
                    courseType: '',
                    name: ''
                },
                list: [],
                typeList: [],
                studyParam:{
                    courseId: '',
                    userId: localStorage.getItem('userId')
                }
            }
        },
        methods:{
            getCourseList(){
                courseList(this.listParams).then(res => {
                    this.list = res.data.list
                })
            },
            getCourseTypeList(){
                courseTypeList({
                    pageSize: 999,
                    pageNum: 1
                }).then(res => {
                    this.typeList = [{id:'',name:'全部'},...res.data.list]
                })
            },
            checkType(data){
                this.listParams.courseType = this.typeList[data].id
                this.getCourseList()
            },
            startStudy(data){
                this.studyParam.courseId = data.id
                memberDetail(this.studyParam).then( res => {
                    this.memberData = res.data.data
                    // !this.memberData || this.memberData.length === 0
                    if(!this.memberData){ // 未报名
                        this.$dialog.confirm({
                            title: '温馨提示:',
                            message: '需要报名后才学习!',
                            cancelButtonText: '报名'
                        }).then(()=>{
                                this.memberCreateFn()
                        }).catch(()=>{})
                    }else{
                        this.$router.push({
                            path:'/study-detail',
                            query:data
                        })
                    }
                })
            },
            // 报名
            memberCreateFn(){
                memberCreate({
                    courseId: this.data.id
                }).then(res => {
                    this.$toast.fail(res.data.msg)
                })
            },
        },
        mounted() {
            this.getCourseList() // 获取列表
            this.getCourseTypeList() // 获取分类
        }
    }
</script>

<style scoped>
</style>