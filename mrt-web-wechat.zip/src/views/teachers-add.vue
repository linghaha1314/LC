<template>
  <div class="about">
    <van-nav-bar title="个人信息" left-arrow>
      <template #left>
        <span @click="$router.replace('/teachers-check')" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        个人信息填写
      </div>
    </div>
    <div>
      <van-form ref="infoForm">
        <div v-if="!isLibrary" style="text-align: center; color: orangered">请上传本人一寸蓝底照片,分辨率不小于413*295</div>
        <van-field v-if="!isLibrary" name="attachPath" :value="formData.avator" required label="头像"
                   :rules="[{ required: true, message: '请上传头像' }]">
          <template #input>
            <van-uploader v-model="fileList" :after-read="afterRead" :before-delete='beforeDelete'/>
          </template>
        </van-field>

        <van-field
            name="name"
            clickable
            required
            label="姓名"
            v-model="formData.name"
            placeholder="请输入姓名"
            :rules="[{ required: true, message: '请输入姓名' }]"
        />
        <van-field readonly clickable required name="typeId" label="科室" :value="formData.sectionName" placeholder="选择科室"
                   @click="showSectionPicker = true"
                   :rules="[{ required: true, message: '请选择科室' }]"/>
        <van-popup v-model="showSectionPicker" round position="bottom">
          <div>
            <van-search v-model="transferParams.name" shape="round" @change="transferGet" placeholder="搜索"/>
          </div>
          <van-picker :columns="sectionColumns" :show-toolbar="true" @cancel="showSectionPicker = false"
                      @confirm="onConfirm($event,formData,'sectionName','sectionId','showSectionPicker',submajorListFn)"
          />
        </van-popup>
        <van-field readonly clickable required name="typeId" label="专业" :value="formData.majorName"
                   placeholder="选择专业" @click="showMajorPicker = true"
                   :rules="[{ required: true, message: '请选择专业' }]"/>
        <van-popup v-model="showMajorPicker" round position="bottom">
          <van-picker :columns="majorColumns" :show-toolbar="true" @cancel="showMajorPicker = false"
                      @confirm="onConfirm($event,formData,'majorName','majorId','showMajorPicker')"
          />
        </van-popup>

        <van-field readonly clickable required name="professionals" label="从事专业" :value="formData.professionals"
                   placeholder="选择从事专业" @click="showProfessionalsPicker = true"
                   :rules="[{ required: true, message: '请选择从事专业' }]"/>
        <van-popup v-model="showProfessionalsPicker" round position="bottom">
          <van-picker :columns="professionalsColumns" :show-toolbar="true" @cancel="showProfessionalsPicker = false"
                      @confirm="onConfirm($event,formData,'professionals','professionals','showProfessionalsPicker')"
          />
        </van-popup>

        <van-field
            v-if="!isLibrary"
            readonly
            clickable
            required
            name="typeId"
            label="民族"
            :value="formData['nationName']"
            placeholder="选择民族"
            @click="showNationPicker = true"
            :rules="[{ required: true, message: '请选择民族' }]"
        />
        <van-popup v-model="showNationPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Nation"
                    @cancel="showNationPicker = false"
                    @confirm="onConfirm($event,formData,'nationName','nationId','showNationPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="性别"
            :value="formData['genderName']"
            placeholder="选择性别"
            @click="showSexPicker = true"
            :rules="[{ required: true, message: '请选择性别' }]"
        />
        <van-popup v-model="showSexPicker" round position="bottom">
          <m-picker
              url="/dictionary/getByTypeCodeParams"
              code="gender"
              @cancel="showSexPicker = false"
              @confirm="onConfirm($event,formData,'genderName','genderId','showSexPicker')"
          ></m-picker>
        </van-popup>


        <van-field
            readonly
            clickable
            name="birthday"
            required
            label="出生日期"
            :value="formData.birthday&&formData.birthday.substring(0,10)"
            placeholder="选择出生日期"
            @click="showWorkDatePicker = true"
            :rules="[{ required: true, message: '请选择出生日期' }]"
        />
        <van-popup v-model="showWorkDatePicker" round position="bottom">
          <van-datetime-picker
              v-model="formData['dateWork']"
              type="date"
              title="选择年月日"
              :min-date="minDate"
              @cancel="showWorkDatePicker = false"
              @confirm="onDateConfirm($event,formData,'birthday','showWorkDatePicker')"
          />
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="职称"
            :value="formData.titleName"
            placeholder="选择职称"
            @click="showTitlePicker = true"
            :rules="[{ required: true, message: '请选择职称' }]"
        />
        <van-popup v-model="showTitlePicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Title"
                    @cancel="showTitlePicker = false"
                    @confirm="onConfirm($event,formData,'titleName','titleId','showTitlePicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="职务"
            :value="formData['positionName']"
            placeholder="选择职务"
            @click="showPositionPicker = true"
            :rules="[{ required: true, message: '请选择职务' }]"
        />
        <van-popup v-model="showPositionPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Position"
                    @cancel="showPositionPicker = false"
                    @confirm="onConfirm($event,formData,'positionName','positionId','showPositionPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            v-if="!isLibrary"
            readonly
            clickable
            name="joinDate"
            required
            label="参加工作日期"
            :value="formData.joinDate&&formData.joinDate.substring(0,10)"
            placeholder="选择参加工作日期"
            @click="showDatePicker = true"
            :rules="[{ required: true, message: '请选择参加工作日期' }]"
        />
        <van-popup v-model="showDatePicker" round position="bottom">
          <van-datetime-picker
              v-model="formData.dateValue"
              type="date"
              title="选择年月日"
              :min-date="minDate"
              @cancel="showDatePicker = false"
              @confirm="onDateConfirm($event,formData,'joinDate','showDatePicker')"
          />
        </van-popup>

        <van-field v-if="!isLibrary" readonly clickable required name="unitName" label="工作单位" :value="formData.unitName"
                   placeholder="选择工作单位"
                   @click="showUnitPicker = true"
                   :rules="[{ required: true, message: '请选择工作单位' }]"/>
        <van-popup v-model="showUnitPicker" round position="bottom">
          <Pager :list-prop="['unitName','unitId']" url="/advancedsignup/listAdvancedUnitByPage
" @check="checkFn($event,formData,'unitName','workUnitId','showUnitPicker')"></Pager>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="最高学历"
            :value="formData['academicName']"
            placeholder="选择学历"
            @click="showEducationPicker = true"
            :rules="[{ required: true, message: '请选择学历' }]"
        />
        <van-popup v-model="showEducationPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Education"
                    @cancel="showEducationPicker = false"
                    @confirm="onConfirm($event,formData,'academicName','academicId','showEducationPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            v-if="!isLibrary"
            readonly
            clickable
            required
            name="typeId"
            label="政治面貌"
            :value="formData['policyName']"
            placeholder="选择政治面貌"
            @click="showPolicyPicker = true"
            :rules="[{ required: true, message: '请选择政治面貌' }]"
        />
        <van-popup v-model="showPolicyPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Policy"
                    @cancel="showPolicyPicker = false"
                    @confirm="onConfirm($event,formData,'policyName','policy','showPolicyPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            v-if="!isLibrary"
            v-model="formData['contactAddress']"
            required
            label="地址"
            :rules="[{ required: true, message: '请填写地址'}]"/>

        <van-field
            v-model="formData.mobile"
            required
            label="联系电话"
            :rules="[{ required: true, message: '请填写联系电话'}]"
        />
        <van-field
            v-if="isLibrary"
            v-model="formData['identifyNo']"
            required
            label="身份证号"
            :rules="[{ required: true, message: '请填写身份证号'}]"
        />
        <van-field
            v-if="!isLibrary"
            v-model="formData['bankCardNo']"
            required
            label="建设银行"
            :rules="[{ required: true, message: '请填写建设银行卡号'}]"
        />
        <van-field
            v-if="isLibrary"
            v-model="formData['serialNo']"
            required
            label="工号"
            :rules="[{ required: true, message: '请填写工号'}]"
        />
        <van-field v-if="isLibrary" name="nurseFlag" label="师资类型" required :value="formData.nurseFlag"
                   :rules="[{ required: true, message: '请选择师资类型'}]">
          <template #input>
            <van-radio-group v-model="formData.nurseFlag" direction="horizontal">
              <van-radio style="margin: 4px;" :name="1">护理师资</van-radio>
              <van-radio style="margin: 4px;" :name="0">医生师资</van-radio>
              <van-radio style="margin: 4px;" :name="2">行政师资</van-radio>
              <van-radio style="margin: 4px;" :name="3">药剂师资</van-radio>
              <van-radio style="margin: 4px;" :name="4">医技师资</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field
            v-model="formData.email"
            label="邮箱"/>

        <van-field v-if="!isLibrary" v-model="formData.workBrief" name="workBrief" required label="工作简介"
                   placeholder="请输入工作简介" type="textarea" rows="5" maxlength="500" show-word-limit :autosize="true"
                   :rules="[{ required: true, message: '请填写工作简介'}]"
        />
        <van-field v-if="!isLibrary" v-model="formData.hobbyDetail" name="hobbyDetail" required label="专业特长"
                   placeholder="请输入专业特长" type="textarea" rows="5" maxlength="500" show-word-limit :autosize="true"
                   :rules="[{ required: true, message: '请填写专业特长'}]"
        />
      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button round block color="#17d4b5" @click="attendAdd">
          {{ isLibrary === '1' ? '创建' : '下一步' }}
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
import {uploadFile, urlForPost, urlForGet, submajorList} from "../http/apiMap";
import mPicker from '../components/m-picker'
import Pager from '../components/searchPager'

const {Dialog} = require("vant");
export default {
  name: 'sign-info',
  components: {
    mPicker,
    Pager
  },
  data() {
    return {
      url: {
        city: '/area/listByPage',
        saveStaff: '/advancedsignup/saveOrUpdateStaff',
        advancedSignup: '/advancedsignup/saveOrUpdateAdvancedSignup',
        staffLanguage: '/advancedsignup/saveOrUpdateStaffLanguage',
        removeFile: '/advancedsignupattach/attachDeleteFile',
        staffBatch: '/advancedsignup/getByBatchAndStaff',
        getLanguage: '/advancedsignup/getLanguageByStaff'
      },
      params: {
        province: {
          pageSize: 999,
          pageNum: 1,
          province: 1
        },
        city: {
          pageSize: 999,
          pageNum: 1,
          city: ''
        },
      },
      formData: {},
      showImg: false,
      showWorkDatePicker: false,
      showSectionPicker: false,
      showMajorPicker: false,
      showProfessionalsPicker: false,
      showSexPicker: false,
      showEducationPicker: false,
      showUnitPicker: false,
      showNationPicker: false,
      showTitlePicker: false,
      showPositionPicker: false,
      showPolicyPicker: false,
      showClothesPicker: false,
      showShoePicker: false,
      showCityPicker: false,
      showMarketPicker: false,
      showHealthConditionPicker: false,
      showEnglishLevelPicker: false,
      showDatePicker: false,
      cityColumns: [],
      sectionColumns: [],
      majorColumns: [],
      unitColumns: [],
      marketColumns: [],
      professionalsColumns: [
        {text: "临床", value: '临床'},
        {text: "医技", value: '医技'},
        {text: "药剂", value: '药剂'},
        {text: "护理", value: '护理'},
        {text: "党务管理", value: '党务管理'},
        {text: "教学管理", value: '教学管理'},
        {text: "后勤管理", value: '后勤管理'},
        {text: "行政管理", value: '行政管理'},
        {text: "其它", value: '其它'}
      ],
      attach: {},
      projectInfo: JSON.parse(localStorage.getItem('signInfo')),
      minDate: new Date(1960, 1, 1),
      languageInfo: {},
      transferParams: {
        pageSize: 999,
        pageNum: 1,
        name: '',
      },
      fileList: [],
      isLibrary: sessionStorage.getItem('isLibrary')
    }
  },
  computed: {},
  methods: {
    onConfirm(value, target, name, id, show, cb) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (cb) {
        cb()
      }
    },

    attendAdd() {
      this.$refs.infoForm.validate().then(() => {
        if (this.isLibrary !== '1') {
          urlForPost('/staff/updateTeacherData', this.formData).then(() => {
            sessionStorage.setItem('staffId', this.formData.id)
            this.$router.push({
              name: 'education',
              params: this.formData
            })
          })
        } else {
          this.formData.typeCode = sessionStorage.getItem('typeCode')
          urlForPost('/teacher/addTeacherInfo', this.formData).then(res => {
            if (res.data.success) {
              sessionStorage.setItem('staffId', this.formData.id)
              this.$toast.success({
                message: '操作成功!',
                duration: 2000,
                onClose: () => {
                  this.$router.replace('/teachers-check')
                }
              })

            } else {
              Dialog.confirm({
                message: res.data.message,
                showCancelButton: false
              }).then(() => {
              })
            }
          })
        }
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        this.formData.avator = res.data.path
        file.pathAttach = res.data.path
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    beforeDelete(file) {
      urlForPost(this.url.removeFile, {
        path: file.pathAttach
      }).then()
      return true
    },
    onDateConfirm(value, target, prop, show) {
      target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
      this[show] = false;
    },
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }

      return year + seperator1 + month + seperator1 + strDate;
    },
    // 选择老师的数据
    checkFn(data, target, prop, propId, show) {
      target[propId] = data.value
      target[prop] = data.text
      this[show] = false
    },
    // 获取picker数据格式
    getData(url, params, target, prop = 'name', propId = 'id') {
      urlForPost(url, params).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item[prop],
            value: item[propId]
          }
          optionArr.push(obj)
        })
        this[target] = optionArr
      })
    },


    // 获取科室信息
    transferGet() {
      // this.transferParams.hospitalId = this.projectInfo.hospitalId
      // if (this.projectInfo.trainTypeCode === 'MandatoryCommissionedTraining') {
      //   this.transferParams.projectId = this.projectInfo.id || ''
      // }
      // this.transferParams.sectionCategoryId = this.formData.sectionCategoryId
      // this.transferParams.code = this.projectInfo.trainTypeCode
      urlForPost('/section/listByPage', this.transferParams).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            sectionStaffId: item.sectionId
          }
          optionArr.push(obj)
        })
        this.sectionColumns = [...optionArr]
      })
    },
    // 获取工作单位
    unitColumnsGet() {
      // unitColumns
      urlForPost('/advancedsignup/getUnitByPage', {
        pageSize: 999,
        pageNum: 1
      }).then(() => {
      })
    },
    // 获取专业列表
    submajorListFn() {
      let p = {};

      p = {
        pageSize: 999,
        pageNum: 1,
        sectionId: this.formData.sectionId
      }

      submajorList(p).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          optionArr.push(obj)
        })
        this.majorColumns = [...optionArr]
      })
    },
  },
  mounted() {
    this.transferGet()
    this.unitColumnsGet()
    if (!this.isLibrary) {
      const query = this.$route.params
      urlForGet('/teacher/getApplicantData',query.id).then(res => {
        if (res.data.data.id) {
          let data = res.data.data
          if (data.id) {
            this.$set(this, 'formData', data)
            this.submajorListFn()
            if (data.avator) {
              this.fileList = [
                {
                  url: data.avator,
                  pathAttach: data.avator
                }
              ]
            }
          }
        }
      })
    }

  }
}
</script>
