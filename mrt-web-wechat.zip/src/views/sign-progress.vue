<template>
  <div class="about">
    <van-nav-bar title="报名进度" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 20px 12px; text-align: center;">
      <van-steps
          direction="vertical"
          :active="actives">
        <van-step v-for="(item, index) in listProgress" :key="item.title">
          <h3>{{ index + 1 }}.{{ item.title }}</h3>
          <template v-if="status === 0 && actives===index">报名资料待完善</template>
          <template v-if="status === 1 && actives===index">您的报名已完成，请等待初审</template>
          <template v-if="status === 2 && actives===index">您的初审未通过，原因：<span>{{ info.auditOpinion || '无' }}</span>，请
            点击
            <van-button size="mini" color="#17d4b5" v-on:click="goAdjust">修改</van-button>
            后重新提交；
          </template>
          <template v-if="status === 9 && actives===index">您的初审未通过，原因：<span>{{ info.auditOpinion || '无' }}</span>
          </template>
          <template v-if="status === 3 && actives===index">您的初审已通过，<span>{{ info['staffName'] || '无' }}</span>
          </template>
          <template v-if="status === 4 && actives===index">很抱歉，您未被录取，原因：<span>{{ info.auditOpinion || '无' }}</span>
          </template>
          <template v-if="status === 5 && actives===index">您已被录取，<span>{{ info['staffName'] || '无' }}</span></template>
          <template v-if="status === 6 && actives===index">您需要按以下步骤确认信息:

            <div style="margin-top: 24px; text-align: center">
              1. 点击按钮下载录取通知书
              <van-button style="width: 30vw; margin: 12px" size="mini" round color="#17d4b5" @click="goDownload">
                下载录取通知书
              </van-button>
            </div>

            <div class="col-md-12">
              <div>
                2. 请将录取通知书中的“入学须知、承诺书”打印并盖章后再将照片进行上传:
              </div>
              <van-form>
                <van-field name="attachPath" required label="上传入学须知、承诺书" :value="application[0]"
                           :rules="[{ required: true, message: '请上传申请表' }]">
                  <template #input>
                    <van-uploader v-model="application" :after-read="afterRead" :before-read="beforeRead"
                                  :before-delete='beforeDelete'/>
                  </template>
                </van-field>
              </van-form>
            </div>

            <div class="col-md-12">
              3. 点击'完成'确认录取
              <br>
              <van-button style="width: 30vw; margin: 12px" size="mini" :disabled="disabled" round color="#17d4b5" @click="complete">
                完成
              </van-button>
            </div>

<!--            <div v-if="showFour">-->
<!--              4. 缴费信息-->
<!--              <br>-->
<!--              <van-cell-group>-->
<!--                <van-cell title="学生姓名:" :value="info.staffName||'无'"/>-->

<!--                <van-cell title="进修费用:" :value="info['advancedFee']||0 + '元'"/>-->
<!--                <van-cell title="住宿费用:" :value="(info.lodgmentFlag===true? info['lodgmentFee']:0) + '元'"/>-->
<!--                <van-cell :title="`工装费: ${info['clothingFee']||0}元`">-->
<!--                  <template #right-icon>-->
<!--                    <van-checkbox-->
<!--                        :name="item"-->
<!--                        v-model="info['clothingCheck']"-->
<!--                        @change="changeFee"-->
<!--                    />-->
<!--                  </template>-->
<!--                </van-cell>-->
<!--                <van-cell title="总计:"-->
<!--                          :value="parseFloat(info['advancedFee'])+parseFloat(info.lodgmentFlag===true? info['lodgmentFee']:'0')+parseFloat(info['clothingCheck']?info['clothingFee']:'0')"/>-->
<!--                <div v-if="orderData && orderData.orderNo" style="margin-top: 12px;">-->
<!--                  订单信息:-->
<!--                  <van-cell v-if="orderData.status" title="支付状态">-->
<!--                    <template #default>-->
<!--                      <div v-if="orderData.status===1" style="color: #17D4B5">-->
<!--                        已支付-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===0" style="color: #1a1aff">-->
<!--                        未支付-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===2" style="color: #ff3333">-->
<!--                        取消支付-->
<!--                      </div>-->
<!--                    </template>-->
<!--                  </van-cell>-->
<!--                  <van-cell title="订单号:" :value="orderData['orderNo']||'无'"/>-->
<!--                  <van-cell title="创建时间:" :value="orderData['created']||'无'"/>-->
<!--                </div>-->
<!--              </van-cell-group>-->
<!--              <van-button v-if="!showPay" style="width: 30vw; margin: 12px" size="mini" round color="#3399ff"-->
<!--                          :disabled="disabledPay"-->
<!--                          @click="nextDone(info)">-->
<!--                确认信息-->
<!--              </van-button>-->
<!--              <van-button v-else style="width: 30vw; margin: 12px" size="mini" round color="#17d4b5"-->
<!--                          :disabled="disabledPay"-->
<!--                          @click="payFn(orderData)">-->
<!--                支付-->
<!--              </van-button>-->
<!--            </div>-->
          </template>
          <template v-if="status === 7 && actives===index">
<!--            <div>-->
<!--              缴费信息-->
<!--              <br>-->
<!--              <van-cell-group>-->
<!--                <van-cell title="学生姓名:" :value="info.staffName||'无'"/>-->

<!--                <van-cell title="进修费用:" :value="info['advancedFee']||0 + '元'"/>-->
<!--                <van-cell title="住宿费用:" :value="(info.lodgmentFee==='自行安排'? 0:info['lodgmentFee']) + '元'"/>-->
<!--                &lt;!&ndash;                <van-cell :title="`进修费用: ${info['advancedFee']||0}元`">&ndash;&gt;-->
<!--                &lt;!&ndash;                  <template #right-icon>&ndash;&gt;-->
<!--                &lt;!&ndash;                    <van-checkbox&ndash;&gt;-->
<!--                &lt;!&ndash;                        :name="item"&ndash;&gt;-->
<!--                &lt;!&ndash;                        v-model="info['advancedCheck']"&ndash;&gt;-->
<!--                &lt;!&ndash;                    />&ndash;&gt;-->
<!--                &lt;!&ndash;                  </template>&ndash;&gt;-->
<!--                &lt;!&ndash;                </van-cell>&ndash;&gt;-->
<!--                &lt;!&ndash;                <van-cell :title="`住宿费用: ${info.lodgmentFlag===true? info['lodgmentFee']:0}元`">&ndash;&gt;-->
<!--                &lt;!&ndash;                  <template #right-icon>&ndash;&gt;-->
<!--                &lt;!&ndash;                    <van-checkbox&ndash;&gt;-->
<!--                &lt;!&ndash;                        :name="item"&ndash;&gt;-->
<!--                &lt;!&ndash;                        v-model="info['lodgmentCheck']"&ndash;&gt;-->
<!--                &lt;!&ndash;                    />&ndash;&gt;-->
<!--                &lt;!&ndash;                  </template>&ndash;&gt;-->
<!--                &lt;!&ndash;                </van-cell>&ndash;&gt;-->
<!--                <van-cell :title="`工装费: ${info['clothingFee']||0}元`">-->
<!--                  <template #right-icon>-->
<!--                    <van-checkbox-->
<!--                        :name="item"-->
<!--                        v-model="info['clothingCheck']"-->
<!--                        :disabled="!(!orderData.status || orderData.status === 1 || orderData.status === 3)"-->
<!--                        @change="changeFee"-->
<!--                    />-->
<!--                  </template>-->
<!--                </van-cell>-->
<!--                <van-cell title="总计:"-->
<!--                          :value="parseFloat(info['advancedFee'])+parseFloat(info.lodgmentFlag===true? info['lodgmentFee']:'0')+parseFloat(info['clothingCheck']?info['clothingFee']:'0')"/>-->
<!--                <div v-if="orderData && orderData.orderNo" style="margin-top: 12px;">-->
<!--                  订单信息:-->
<!--                  <van-cell v-if="orderData.status" title="支付状态">-->
<!--                    <template #default>-->
<!--                      <div v-if="orderData.status===2" style="color: #17D4B5">-->
<!--                        支付成功-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===1" style="color: #1a1aff">-->
<!--                        未支付-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===3" style="color: #ff3333">-->
<!--                        支付失败-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===4" style="color: #1a1aff">-->
<!--                        退款申请中-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===5" style="color: #17D4B5">-->
<!--                        退款成功-->
<!--                      </div>-->
<!--                      <div v-else-if="orderData.status===6" style="color: #ff3333">-->
<!--                        退款失败-->
<!--                      </div>-->
<!--                    </template>-->
<!--                  </van-cell>-->
<!--                  <van-cell title="订单号:" :value="orderData['orderNo']||'无'"/>-->
<!--                  <van-cell title="创建时间:" :value="orderData['created']||'无'"/>-->
<!--                </div>-->
<!--              </van-cell-group>-->
<!--              <van-button v-if="!orderData.status || orderData.status === 1 || orderData.status === 3" style="width: 30vw; margin: 12px" size="mini" round color="#3399ff"-->
<!--                          :disabled="disabledSure"-->
<!--                          @click="nextDone(info)">-->
<!--                {{doneTime}}-->
<!--              </van-button>-->
<!--              <van-button v-if="showPay" style="width: 30vw; margin: 12px" size="mini" round color="#17d4b5"-->
<!--                          :disabled="disabledPay"-->
<!--                          @click="payFn(orderData)">-->
<!--                支付-->
<!--              </van-button>-->
<!--              <van-button v-if="orderData.status===2" style="width: 30vw; margin: 12px" size="mini" round color="#ff3333"-->
<!--                          @click="invoicing(orderData, 'refund')">-->
<!--                退款-->
<!--              </van-button>-->
<!--&lt;!&ndash;              <van-button v-if="orderData.status===4" style="width: 30vw; margin: 12px" size="mini" round color="#3399ff"&ndash;&gt;-->
<!--&lt;!&ndash;                          @click="queryOrder(orderData)">&ndash;&gt;-->
<!--&lt;!&ndash;                查询退款结果&ndash;&gt;-->
<!--&lt;!&ndash;              </van-button>&ndash;&gt;-->
<!--              <van-button v-if="orderData.status===2" style="width: 30vw; margin: 12px" size="mini" round color="#3399ff" :disabled="invoicingFlag"-->
<!--                          @click="invoicing(orderData)">-->
<!--                {{invoicingStr}}-->
<!--              </van-button>-->
<!--            </div>-->
<!--            <div style="text-align: center; color: orangered">-->
<!--              注：如果退款失败，请联系管理员! 致电 : 0851-86817477-->
<!--            </div>-->
            等待报到，报到时间为:{{ comeTime }}。如果录取通知书不见了,请点击"
            <van-button style="width: 30vw; margin: 12px" size="mini" round color="#17d4b5" @click="goDownload">
              下载录取通知书
            </van-button>
          </template>
          <template v-if="status === 8 && actives===index">恭喜您已完成报到！</template>

        </van-step>
      </van-steps>
    </div>
  </div>
</template>
<script>
import {uploadSignFile, urlForPost, getSignupTime} from '../http/apiMap';

export default {
  name: 'sign-progress',
  data() {
    return {
      url: {
        info: '/advancedsignup/getByBatchAndStaff',
        create: '/advancedsignupattach/create',
        removeFile: '/advancedsignupattach/deleteFile',
        removeData: '/advancedsignupattach/remove',
        save: '/advancedsignup/saveOrUpdateAdvancedSignup'
      },
      status: 0,
      // status: 9,
      listProgress: [
        {title: '填写报名资料'},
        {title: '审核资质'},
        {title: '科室遴选'},
        {title: '发放录取通知书'},
        {title: '上传盖章后的入学须知和承诺书'},
        {title: '学员缴费和报到'},
      ],
      advancedSignup: {},
      info: {},
      application: [],
      comeTime: '2021-10-10',
      queryData: {},
      disabled: false,
      disabledSure: true,
      disabledPay: false,
      showFour: false,
      showPay: false,
      currentData: {},
      orderData: {
        status: 0
      },
      invoicingStr: '申请开票',
      invoicingFlag: false,
      doneTime: '不在操作时间'
    }
  },
  computed: {
    actives() {
      if (this.status === 1 || this.status === 2 || this.status === 9) {
        return 1
      } else if (this.status === 3 || this.status === 4) {
        return 2
      } else if (this.status === 5) {
        return 3
      } else if (this.status === 6) {
        return 4
      } else {
        return 5
      }
    }
  },
  methods: {
    gerProgress(progressInfo) {
      urlForPost(this.url.info, {
        identifyNo: this.queryData.identifyNo,
        batchId: this.queryData.batchId
      }).then(res => {
        this.info = res.data.data
        this.isSurePay(this.info)
        if (this.info.status === 7) {
          this.getSignupTimeFn()
          urlForPost('/advancedpayonline/mySignupOrderNo', {
            staffId: progressInfo.staffId,
            signupId: progressInfo.id
          }).then(d => {
            this.orderData = d.data.data || {}
            this.disabledPay = this.orderData.status === 2
            this.showPay = this.orderData.status === 2
            if(d.data.data.status === 2){
              this.info['clothingCheck'] = d.data.data['clothingFlag']
              urlForPost('/advancedpayonline/toInvoiceDetails',{
                orderNo: this.orderData.orderNo,
                signupId: this.orderData.signupId,
                staffId: this.orderData.staffId
              }).then(data => {
                if(data.data.data && data.data.data.status === 1){
                  this.invoicingStr = '已开票至邮箱'
                  this.invoicingFlag = true
                }
              })
            }
            if(this.orderData.status!==1){
              urlForPost('/advancedpayonline/toPayBillDetails',{
                orderNo: this.orderData.orderNo
              }).then(res => {
                this.orderData.bnkPyOrdrNo = res.data.data && res.data.data.bnkPyOrdrNo || null
                if(this.orderData.status === 4 && this.orderData.bnkPyOrdrNo){
                  urlForPost('/advancedpayonline/toPayReturnDetails',{
                    bnkPyOrdrNo: this.orderData.bnkPyOrdrNo,
                    orderNo: this.orderData.orderNo
                  }).then(re => {
                    urlForPost('/advancedpayonline/getReturnPayStatus', {
                      bnkPyOrdrNo: re.data.data.bnkPyOrdrNo,
                      rfndTrcNo: re.data.data.rfndTrcNo,
                      ittPartyJrnlNo: re.data.data.ittPartyJrnlNo,
                      orderNo: this.orderData.orderNo
                    }).then((r)=>{
                      this.orderData.status = r.data.data.message==='退款成功' ? 5 : 6
                    })
                  })
                }
              })
            }

          })
        }
      })
    },
    goDownload() {
      this.$router.push({
        path: '/download-page',
        query: {
          type: 'TZ',
          ...this.info
        }
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadSignFile(data).then(res => {
        file.pathAttach = res.data.path
        this.saveAttach(res.data.path, file)
      })
    },
    saveAttach(path, objFile) {
      let param = {
        "signupId": this.info.id,
        "path": path
      }
      if (this.status === 6) {
        param.typeCode = 'CheckinNotice'
      }
      urlForPost(this.url.create, param).then(res => {
        objFile.id = res.data.data["reasons"].data.id
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    // 删除前操作
    beforeDelete(file) {
      urlForPost(this.url.removeFile, {
        path: file.pathAttach
      }).then()
      urlForPost(this.url.removeData, {
        id: file.id
      }).then()
      return true
    },
    // 确认上传
    complete() {
      if (this.application.length < 2) {
        this.$toast.fail('请按规定上传文件!')
      } else {
        urlForPost(this.url.save, {
          id: this.queryData.id,
          batchId: this.queryData.batchId,
          staffId: this.queryData.staffId,
          status: 7
        }).then(res => {
          if (res.data.success) {
            this.$toast.success('操作成功!')
            this.disabled = true
            // this.showFour = true
          } else {
            this.$toast.fail('操作失败!')
          }
        })
      }

    },
    nextDone() {
      this.isSurePay(this.info, ()=>{
        if(this.disabledSure === false){
          const staffId = this.queryData.staffId
          const signupId = this.queryData.id
          const advancedFee = parseFloat(this.info.advancedFee)
          const clothingFee = parseFloat(this.info.clothingCheck ? this.info.clothingFee : 0)
          const lodgmentFee = parseFloat(this.info.lodgmentFlag ? this.info.lodgmentFee : 0.00)
          const param = {
            staffId,
            signupId,
            advancedFee: advancedFee,
            lodgmentFee: lodgmentFee,
            clothingFee: clothingFee,
            payFee: advancedFee + lodgmentFee + clothingFee,
            clothingFlag: this.info.clothingCheck
          }
          if (this.orderData.id) {
            param.id = this.orderData.id
            param.orderNo = this.orderData.orderNo
          }
          urlForPost('/advancedpayonline/savePayOrderNo', {
            ...param
          }).then((re) => {
            if(re.data.success){
              this.orderData = re.data.reasons.data
              // this.disabledPay = this.orderData.status === 2
              // this.showFour = true
              this.disabledSure = true
              this.disabledPay = false
              this.showPay = true
              // urlForPost('/advancedpayonline/mySignupOrderNo',{
              //   staffId, signupId
              // }).then(re => {
              //   this.currentData = re.data.data
              //   this.disabledPay = this.currentData === 1
              //   this.showFour = true
              // })
            }else {
              this.$toast.fail(re.data.message || '未知错误')
            }
          })
        } else {
          this.disabledSure = true
          this.doneTime = '不在操作时间'
        }
      })
    },
    payFn({orderNo, advancedFee, lodgmentFee, clothingFee}) {
      urlForPost('/advancedpayonline/toPayOnline', {
        orderNo,
        payFee: advancedFee + lodgmentFee + clothingFee
      }).then(res => {
        if (res.data.success) {
          this.disabledPay = true
          this.orderData.status = 2
          window.location.href = res.data.data.Py_URL
        }else {
          this.$toast.fail(res.data.message || '未知错误')
        }
      })
    },
    getSignupTimeFn() {
      getSignupTime(this.info.id).then(res => {
        this.comeTime = res.data.data["checkinDate"] || '无'
      })
    },
    goAdjust() {
      sessionStorage.clear()
      sessionStorage.setItem('batchInfo', JSON.stringify(this.$route.query))
      localStorage.setItem('AdvancedType', this.info.typeId)
      this.$router.push({
        path: '/sign-write-tab'
      })
    },

    changeFee() {
      // if(!this.showPay){
      //   this.disabledPay = false
      // }
      if(this.doneTime === '确认信息'){
        this.disabledPay = true
        this.disabledSure = false
      }
    },
    invoicing(data, refund){
      this.$router.push({
        path: refund ? '/sign-progress-refund' : '/sign-progress-Invoicing',
        query: {
          ...data
        }
      })
    },
    // queryOrder(data){
    //
    // }
    isSurePay(data,cb){
      const now = new Date().getTime()
      const q = new Date(data.payStartDate).getTime()
      const o = new Date(data.payEndDate).getTime()
      if(q<now && o>now){
        this.disabledSure = false
        this.doneTime = '确认信息'
      }
      if (cb) {
        cb()
      }
    }
  },
  mounted() {
    let progressInfo = JSON.parse(localStorage.getItem('progressInfo') || '{}')
    if (progressInfo.id) {
      this.queryData = progressInfo;
      this.status = progressInfo.status;
      this.gerProgress(progressInfo)
    }
  }
}
</script>
