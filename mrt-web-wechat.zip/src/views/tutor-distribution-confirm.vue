<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div v-if="true">
      <van-cell title="进修科室" :value="formData.sectionName || '无'"/>
      <van-cell title="进修学生" :value="formData['staffName'] || '无'"/>
      <van-cell title="专业" :value="formData.majorName || '无'"/>
      <van-cell title="进修期限(月)" :value="formData['batchName'] || '无'"/>
      <van-cell v-if="formData.startDate" title="入科日期" :value="formData.startDate.substring(0,10) || '无'"/>
      <van-cell title="备注信息" :value="formData.remark || '无'"/>
      <div style="margin: 16px;">
        <van-button style="margin-bottom: 24px" round block type="primary" @click="showTeacherPicker = true">
          分配带教老师
        </van-button>
        <van-button round block @click="download" v-if="!!this.formData['admissionFlag']">
          查看入科通知
        </van-button>
        <van-popup style="height: 50vh" v-model="showTeacherPicker" round position="bottom">
          <van-field
              name="teacherId"
              readonly
              clickable
              required
              label="带教老师"
              :value="formData.teacherName"
              placeholder="选择带教老师"
              @click="showPicker = true"
              :rules="[{ required: true, message: '请选择带教老师' }]"
          />
          <van-popup v-model="showPicker" round position="bottom">
            <Pager :list-prop="['teacherName','id']" url="/teacher/listQueryTeacher" @check ="checkFn"></Pager>
          </van-popup>

        </van-popup>
<!--        <van-popup v-model="show" style="height: 400px; width: 100vw; ">-->
<!--            <van-button style="margin: 100px auto; width: 60vw" round block type="primary" @click="download">-->
<!--              入科通知下载-->
<!--            </van-button>-->
<!--        </van-popup>-->
      </div>
    </div>
  </div>
</template>
<script>
    import Pager from '../components/searchPager'
    import {
        createTeachactivity,
        getDictionaryType,
        updateTeachactivity,
        removeTeachactivity,
        checkinIntoFamily,
        urlForPost,
        outFamilyCreate
    } from '../http/apiMap';

    import {getNowFormatDate} from '../utils/utils'
    export default {
        name: 'test',
        components: {
            Pager
        },
        data(){
            return{
                formData:{
                    subject: '',
                    location: '',
                    teacherId: '',
                    teacherName: '',
                    dateValue: null,
                    startTime: '',
                    startDate: '',
                    endTime: '',
                    typeId: '',
                    typeName: '',
                    content: '',
                    remark: ''
                },
                ac_userId: '',
                currentData: {},
                showPicker: false,
                showTeacherPicker: false,
                showTypePicker: false,
                showDatePicker: false,
                showStartTimePicker: false,
                showEndTimePicker: false,

                action: 3,
                minDate: new Date(),
                maxDate: new Date(2025, 10, 1),
                currentDate: new Date(),
                currentTime: '12:00',
                currentEndDate: '12:00',
                option1: [],
                role: '',
                userId: '',
                show: false,
                hrefU: ''
            }
        },
        computed:{
            name(){
                return this.$route.name
            },
            typeColumns(){
                let arr = []
                this.option1.map(item => {
                    arr.push(item.text)
                })
                return arr;
            },
            isEdit(){
                return this.action === 3 || (this.action === 0 && this.userId === this.formData.userId);
            }
        },
        methods:{
            onSubmit(){
                this.$refs.activitiesForm.validate().then(()=>{
                    let param = {
                        "endTime":this.formData.endTime,
                        "location":this.formData.location,
                        "remark":this.formData.remark,
                        "startDate":this.formData.startDate,
                        "startTime":this.formData.startTime,
                        "subject":this.formData.subject,
                        "teacherId":this.formData.teacherId,
                        "typeId":this.formData.typeId
                    }
                    createTeachactivity(param).then(() => {
                        this.$toast.success('添加成功!')
                        setTimeout(()=>{
                            this.$router.go(-1)
                        },1000)
                    })

                }).catch(()=>{
                    this.$toast.fail('请正确填写表单!')
                })
            },
            // 发布
            release(){
                let param = {
                    "endTime":this.formData.endTime,
                    "location":this.formData.location,
                    "remark":this.formData.remark,
                    "startDate":this.formData.startDate,
                    "startTime":this.formData.startTime,
                    "subject":this.formData.subject,
                    "teacherId":this.formData.teacherId,
                    "typeId":this.formData.typeId.value,
                    id: this.currentData.id,
                    status: 1
                }
                updateTeachactivity(param).then(() => {
                    this.$toast.success('发布成功!')
                    setTimeout(()=>{
                        this.$router.go(-1)
                    },1000)
                })
            },
            // 删除活动
            removeA(){
                removeTeachactivity({
                    id: this.currentData.id
                }).then(() => {
                    this.$toast.success('删除成功!')
                    setTimeout(()=>{
                        this.$router.go(-1)
                    },1000)
                })
            },

            onTypeConfirm(value,index) {
                this.formData.typeId = this.option1[index].value;
                this.formData.typeName = value;
                this.showTypePicker = false;
            },

            onDateConfirm(value) {
                this.formData.startDate = getNowFormatDate(value)+' 00:00:00'
                this.showDatePicker = false;
            },
            // 开始时间
            onStartDateConfirm(value){
                this.formData.startTime = value
                this.showStartTimePicker = false;
            },
            // 结束时间
            onEndDateConfirm(value){
                this.formData.endTime = value
                this.showEndTimePicker = false;
            },
            checkFn(data){
                this.formData.teacherId = data.value
                this.formData.teacherName = data.text
                this.showPicker = false
                this.showTeacherPicker = false
                this.checkinTeacherFn()
            },
            // 获取类型
            getTypeList(){
                getDictionaryType('TeachActivityType').then(res => {
                    let data = res.data.data
                    let arr = []
                    data.forEach(item => {
                        let obj = {
                            text: item.name,
                            value: item.id
                        }
                        arr.push(obj)
                    })

                    this.option1 = arr;
                })
            },
            // 结束活动
            activitiesOver(){
                if(!this.currentData.transferFlag){
                    let param = {
                        ids: this.currentData.id,
                    }
                    checkinIntoFamily(param).then((res) => {
                        
                        if(res.data.success){
                            this.$toast.success('入科成功!')
                            this.formData.status = 0
                        }else{
                            this.$toast.fail('入科失败!')
                        }
                        // setTimeout(()=>{
                        //     this.$router.go(-1)
                        // },1000)
                    })
                }else {
                    let param = [
                        {
                            "hospitalId": this.formData.hospitalId,
                            "sectionId": this.formData.sectionId,
                            "studentId": this.formData.studentId,
                            "transferId": this.formData.transferId
                        }
                    ]
                    outFamilyCreate(param).then((res) => {
                        if (res.data.success) {
                            this.$toast.success('入科成功!')
                            this.formData.status = 0
                        } else {
                            this.$toast.fail('入科失败!')
                        }
                    })
                }
            },
            // 选择带教老师
            checkinTeacherFn(){
                let p = {
                    "signupId": this.formData.id,
                    "teacherId": this.formData.teacherId,
                }
                urlForPost('/backboneTraining/allocationTutor',p).then(res => {
                    if (res.data.success) {
                        this.$toast.success('安排成功!')
                    } else {
                        this.$toast.fail('安排失败!')
                    }
                })
            },
            // 下载通知书
            download(){
                this.$router.push({
                    path: '/download-page',
                    query: {
                        id: this.formData.studentId
                    }
                })
            }
        },
        mounted() {
            this.role = localStorage.getItem('roleCode')
            this.formData = this.$route.query
            // this.userId = localStorage.getItem('userId')
            // let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
            // this.ac_userId = localStorage.getItem('userId')
            // this.currentData = currentForm
            // let len = Object.keys(currentForm).length
            // if(len === 0){
            //     this.action = 3
            // }else {
            //      this.action = currentForm.status
            //     this.formData = Object.assign(this.formData,currentForm)
            // }
            // localStorage.setItem('currentData', '')
            // this.getTypeList() // 获取类型
        }
    }
</script>