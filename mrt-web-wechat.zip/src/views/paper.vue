<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="testBack">返回</span>
      </template>
      <template #title>
        <div style="color: #17d4b5; display: flex; align-items: center;">
          <template v-if="testType !== 'questionnaire'&&!isDone">
            {{ name }}
            <van-count-down :time="time" format="mm:ss" @finish="onFinish"/>
          </template>
          <template v-if="testType === 'questionnaire'">
            填写问卷
          </template>
        </div>
      </template>
    </van-nav-bar>
    <div v-if="this.questions.length===0" style="color:red; text-align: center;font-size: 16px;">
      此试卷无试题, 请联系出题人更换试卷!!!
    </div>
    <div v-if="testType !== 'questionnaire'">
      <div class="p12" style="padding: 15px 12px;font-size: 14px" v-if="testType !== 'questionnaire'">
      <span v-if="thisQuestion['examQuestion']">
        {{ thisQuestion['examQuestion'].typeName || '其他' }}
      </span>
      </div>
      <!--间隔-->
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="padding: 13px 26px;">
        <div style="margin-bottom: 10px;" v-if="thisQuestion.parent">
          {{ qIndex + 1 + '.' + (thisQuestion.parent.name || thisQuestion.parent.remark) }}
        </div>
        <div style="margin-bottom: 20px;" v-if="thisQuestion['examQuestion']">
          {{ thisQuestion.parent ? thisQuestion['examQuestion'].name : qIndex + 1 + '.' + thisQuestion['examQuestion'].name }}
          <div v-if="thisQuestion['examQuestion']['pic']" style="text-align: center">
            <van-image :src="thisQuestion['examQuestion']['pic']" alt="图片"></van-image>
          </div>
        </div>

        <div v-if="testType !== 'questionnaire'&&thisQuestion['examQuestion']">
          <!--        单选题-->
          <div
              v-if="thisQuestion['examQuestion'].typeCode === 'radio' || thisQuestion['examQuestion'].typeCode === 'multiquestion'">
            <van-radio-group v-model="thisQuestion.optionId" @change="checkChange(thisQuestion)">
              <van-radio :name="option.id"
                         checked-color="#17d4b5"
                         v-for="option in thisQuestion['examOptions']"
                         :key="option.id"
              >{{ option['optionName'] }}
              </van-radio>
            </van-radio-group>
          </div>
          <!--        多选题-->
          <div v-if="thisQuestion['examQuestion'].typeCode === 'checkbox' && thisQuestion['examOptions']">
            <van-checkbox-group v-model="thisQuestion.optionId" @change="checkChange(thisQuestion)">
              <van-checkbox :name="option.id"
                            checked-color="#17d4b5"
                            v-for="option in thisQuestion['examOptions']"
                            :key="option.id">{{ option['optionName'] }}
              </van-checkbox>
            </van-checkbox-group>`
          </div>
          <!--        填空题-->
          <div
              v-if="thisQuestion['examQuestion'].typeCode === 'shortblank' || thisQuestion['examQuestion'].typeCode === 'fillblank'">
            <van-field
                style="background:#cccccc;"
                v-model="thisQuestion.answerText"
                rows="5"
                :autosize="true"
                type="textarea"
                maxlength="800"
                show-word-limit
                placeholder="请输入答案"
                @change="checkChange(thisQuestion)"
            />
          </div>
        </div>

      </div>
    </div>
    <div v-else>
      <div class="p12" style="padding: 15px 12px;font-size: 14px" v-if="testType === 'questionnaire'">
        <span v-if="thisQuestion['styleCode']">
          {{ thisQuestionName }}
        </span>
      </div>
      <!--间隔-->
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="padding: 13px 26px;">
        <div style="margin-bottom: 10px;" v-if="thisQuestion.name">
          {{ qIndex + 1 + '.' + thisQuestion.name }}
        </div>
<!--        <div style="margin-bottom: 20px;" v-if="thisQuestion['options']">-->
<!--          {{ thisQuestion.parent ? thisQuestion['options'].name : qIndex + 1 + '.' + thisQuestion['options'].name }}-->
<!--          <div v-if="thisQuestion['options']['pic']" style="text-align: center">-->
<!--            <van-image :src="thisQuestion['options']['pic']" alt="图片"></van-image>-->
<!--          </div>-->
<!--        </div>-->

        <div v-if="testType === 'questionnaire' && thisQuestion['options']">
          <!--        单选题-->
          <div v-if="thisQuestion['styleCode'] === 'veradio'">
            <van-radio-group v-model="thisQuestion.optionId" @change="checkChange(thisQuestion)">
              <van-radio :name="option.id"
                         checked-color="#17d4b5"
                         v-for="option in thisQuestion['options']"
                         :key="option.id"
              >{{ option['optionText'] }}
              </van-radio>
            </van-radio-group>
          </div>
          <!--        多选题-->
          <div v-if="thisQuestion['styleCode'] === 'vecheckbox'">
            <van-checkbox-group v-model="thisQuestion['optionIds']" @change="checkChange(thisQuestion)">
              <van-checkbox :name="option.id"
                            checked-color="#17d4b5"
                            v-for="option in thisQuestion['options']"
                            :key="option.id">{{ option['optionText'] }}
              </van-checkbox>
            </van-checkbox-group>
          </div>
          <!--        填空题-->
          <div
              v-if="thisQuestion['styleCode'] === 'vetextarea' || thisQuestion['styleCode'] === 'veinput'">
            <van-field
                style="background:#cccccc;"
                v-model="thisQuestion.answerText"
                rows="5"
                :autosize="true"
                type="textarea"
                maxlength="800"
                show-word-limit
                placeholder="请输入答案"
                @change="checkChange(thisQuestion)"
            />
          </div>
          <div
              v-if="thisQuestion['styleCode'] === 'vescore'">
            <van-rate v-model="thisQuestion.answerText" :count="10"/>
          </div>
        </div>

      </div>
    </div>

    <div style="position: fixed;left: 0;bottom: 0;display: flex;width: 100%">
      <van-button style="flex: 1" type="default" @click="show=true">
        <van-icon name="orders-o"/>
        查看/提交
      </van-button>
      <van-button style="width: 110px" type="default" @click="upQuestion" :disabled="qIndex === 0">上一题</van-button>
      <van-button style="width: 110px" type="default" :disabled="qIndex === questions.length-1"
                  @click="nextQuestion">下一题
      </van-button>
    </div>
    <van-popup
        v-model="show"
        round
        position="bottom"
        style="height: 70%"
    >
      <div style="padding: 34px 15px;">
        <div style="display: flex;justify-content: space-between; align-items: center;">
          <div style="display: flex;align-items: center;">
            <van-icon color="#ff0000" name="orders-o" size="16px"/>
            题目
          </div>
          <div class="cc">
            <div class="cc">
              <div style="background:#ccc;width: 14px;height: 14px;margin-right: 12px;"></div>
              已答
            </div>
            <div class="cc">
              <div style="background:#17d4b5;width: 14px;height: 14px;margin: 0 12px;"></div>
              当前
            </div>
          </div>
        </div>
        <van-divider/>

        <div style="display: flex; flex-wrap: wrap; height: 200px; overflow: auto;">
          <div class="checkItem" :class="item.done?'done':''" v-for="(item, index) in questions" :key="index"
               @click="checkQuestion(item,index)">
            <div v-if="qIndex === index" class="ac">
              {{ index + 1 }}
            </div>
            <div v-if="qIndex !== index">
              {{ index + 1 }}
            </div>
          </div>
        </div>
        <div style="margin: 12px 18px; display: flex;justify-content: space-between;">
          <van-button style="width: 120px; height: 34px;font-size: 16px" size="small" @click="show=false">取消
          </van-button>
          <van-button v-if="!isDone" style="width: 120px; height: 34px;font-size: 16px" color="#17d4b5" type="primary" size="small"
                      @click="submitPaper">提交
          </van-button>
        </div>
      </div>
    </van-popup>

    <div v-if="isDone && testType!=='questionnaire'" class="p12" style="background:#efefef;
min-height: 100px;padding-top: 12px">
      <div style="padding: 0 12px">
        <div v-if="thisQuestion['examQuestion']['refAnswer']">
          正确答案: {{ thisQuestion['examQuestion']['refAnswer'] }}
        </div>
        <div v-if="thisQuestion['examQuestion']['refRemark']">解析: {{ thisQuestion['examQuestion']['refRemark'] }}</div>
      </div>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {getNowTime} from '../utils/utils';
import {examQuestion, saveExamStartInfo, examCompleted, saveAnswer, examResult, saveQuestionResult, questionnairePro, surveyAnswer, urlForPost} from '../http/apiMap';

export default {
  name: 'test',
  data() {
    return {
      activeNames: ['1'],
      time: this.$route.query.time * 60 * 1000 || 2 * 60 * 60 * 1000,
      radio: '',
      show: false,
      result: [],
      startDate: getNowTime(),
      className: '',
      qIndex: 0,
      isDone: false,
      testType: this.$route.query.type,
      questions: [],
      startInfo: {},
      answerParam: this.$route.query.paperParam,
      queryData: this.$route.query
    }
  },
  computed: {
    name() {

      return this.$route.name
    },
    thisQuestion() {
      return this.questions[this.qIndex] || {}
    },
    thisQuestionName(){
      if(this.questions[this.qIndex]['styleCode'] === "veradio"){
        return '单选题'
      }
      else if(this.questions[this.qIndex]['styleCode'] === "vecheckbox"){
        return '多选题'
      }
      else if(this.questions[this.qIndex]['styleCode'] === "vetextarea"){
        return '解答题'
      }
      else if(this.questions[this.qIndex]['styleCode'] === "veinput"){
        return '填空题'
      }
      else if(this.questions[this.qIndex]['styleCode'] === "vescore"){
        return '打分题'
      }
      else{
        return '其他';
      }
    }
  },
  mounted() {
    if(this.testType==='questionnaire'){
      questionnairePro(this.queryData['surveyId']).then(res => {
        if (res.data.success) {
          let list = res.data.list
          this.questions = [...list]
          this.current = this.questions[0];
          if(!this.queryData.status||this.queryData.status === '1'){
            this.isDone = true
            this.getAnswer()
          }
        }
      })
    }else{
      this.answerParam.isCompleted = this.answerParam.isCompleted === 'true' || this.answerParam.isCompleted === true
      this.isDone = this.answerParam.isCompleted
      if(this.answerParam.isCompleted){
        this.startInfo = this.answerParam
        this.startInfo.userId = localStorage.userId
        this.examResultFn()
      }else{
        examQuestion(this.answerParam).then(res => {
          if (res.data.success) {
            let list = res.data.list
            let single = []
            let bigQuestions = []
            let bigQuestionsTitle = []
            let indexArr = []
            list.forEach(item => {

              if(item['examQuestion'].pid){
                bigQuestions.push(item)
              }else{
                single.push(item)
              }
            })
            single.forEach((item,index) => {
              bigQuestions.forEach(i => {
                if(i['examQuestion'].pid === item.questionId){
                  indexArr.push(index)
                  bigQuestionsTitle.push(item)
                }
              })
            })
            indexArr = [...new Set(indexArr)]

            if(indexArr.length!==0){
              single.forEach((item,index)=>{
                indexArr.forEach(ite=>{
                  if(ite===index){
                    delete single[index]
                  }
                })
              })
            }
            single = single.filter(item => item)
            bigQuestionsTitle.forEach(item => {
              bigQuestions.forEach(i => {
                if(i['examQuestion'].pid === item.questionId){
                  i.parent = item['examQuestion']
                }
              })
            })

            this.questions = [...single,...bigQuestions]

            this.current = this.questions[0];
            // this.getAnswer()
          }

        })
      }
    }
  },
  methods: {
    // 答题卡点击题目
    checkQuestion(data, index) {
      this.current = data
      this.current.index = index + 1
      this.qIndex = index;
      this.show = false
    },
    // 上一题
    upQuestion() {
      if (this.qIndex > 0) {
        this.qIndex--
        this.current = this.questions[this.qIndex]
      }
    },
    // 下一题点击
    nextQuestion() {
      if (this.qIndex < this.questions.length - 1) {
        this.qIndex++
        this.current = this.questions[this.qIndex]
      }
    },
    // 提交试卷
    submitPaper() {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认提交么??',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        if(this.testType==='questionnaire'){
          this.questionnaireSave()
        }else{
          this.testUpdate()
        }
      }).catch(() => {
        return false
      })
    },
    questionnaireSave(){
      let answer = []
      try {
        this.questions.forEach(item => {
          if(item['styleCode'] === 'veradio'){ // 单选题
            item.options.forEach(ite => {
              let answerObj = {
                "staffId": localStorage.getItem('staffId')
              }
              answerObj.volumeId = item.volumeId || null
              answerObj.questionId = item.id || null
              answerObj.answerId = this.queryData['id'] || null
              answerObj.questionName = item.name || null
              answerObj.questionResult = item['optionId'] || null
              if(ite.id === item.optionId){
                answerObj.questionValue = ite['sequence']
                answer.push(answerObj)
              }
            })
          }
          else if(item['styleCode'] === 'vecheckbox'){ // 多选题
            item['optionIds'].forEach(ite => {
              item.options.forEach(it => {
                let answerObj = {
                  "staffId": localStorage.getItem('staffId')
                }
                answerObj.volumeId = item.volumeId || null
                answerObj.questionId = item.id || null
                answerObj.answerId = this.queryData['id'] || null
                answerObj.questionName = item.name || null
                answerObj.questionResult = ite || null
                if(ite === it.id){
                  answerObj.questionValue = it['sequence'] || null
                  answer.push(answerObj)
                }
              })
            })
          }
          else if(item['styleCode'] === 'vetextarea' || item['styleCode'] === 'veinput' || item['styleCode'] === 'vescore'){
            let answerObj = {
              "staffId": localStorage.getItem('staffId')
            }
            answerObj.volumeId = item.volumeId || null
            answerObj.questionId = item.id || null
            answerObj.answerId = this.queryData['id'] || null
            answerObj.questionName = item.name || null
            answerObj.questionResult = item['answerText'] || null
            answerObj.questionValue = item.options[0]['sequence'] || null
            answer.push(answerObj)
          }
          // else if(item['styleCode'] === 'vescore'){
          //   let answerObj = {
          //     "staffId": localStorage.getItem('staffId')
          //   }
          //   answerObj.volumeId = item.volumeId || null
          //   answerObj.questionId = item.id || null
          //   answerObj.answerId = this.queryData['id'] || null
          //   answerObj.questionName = item.name || null
          //   answerObj.questionResult = item.options[0]['id'] || null
          //   answerObj.questionValue = item['answerText'] || null
          //   answer.push(answerObj)
          // }
        })
      }catch (err){
        console.log(err)
      }
      saveQuestionResult(answer).then(res => {
        if(res.data.success){
          this.$router.replace({
            path: '/test-submit'
          })
        }
      })
    },
    testUpdate(){
      this.answerParam.isCompleted = true
      this.saveExamStartInfoFn(()=>{
        let num = 0
        let answer = []
        this.questions.forEach(item => {
          let answerObj = {
            "examType": "onlineExam",
            "pId": this.startInfo.id,
            "questionId": item["examQuestion"].id,
            "volumeId": this.$route.query.paperParam["volumeId"]
          }
          if (item["examQuestion"].typeCode === 'radio') {
            answerObj.optionId = item.optionId
          } else if (item["examQuestion"].typeCode === 'checkbox') {
            if(item['optionId']){
              answerObj.optionId = item['optionId'].join(',')
            }else{
              answerObj.optionId = ''
            }
          } else {
            answerObj.answerText = item.answerText
          }
          answer.push(answerObj)
          if (item.done) {
            num++
          }
        })
        let param = {
          id: this.startInfo.id,
          completeNum: num,
          startDate: this.startDate
        }
        saveAnswer(answer).then(() => {
          examCompleted(param).then(() => {
            this.$router.replace({
              path: '/test-submit'
            })
          })
        })
      })
    },
    // 做题时切换状态
    checkChange(data) {
      if (!this.isDone) {
        if (data.optionId) {
          data.done = data.optionId.length !== 0
        } else data.done = data.answerText !== '';
      }
    },
    // 上传开始时间
    saveExamStartInfoFn(cb) {
      let u = navigator.userAgent;
      let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
      let param = {
        ...this.answerParam,
        client: isAndroid ? 'android' : 'ios',
        totalNum: this.questions.length
      }
      param["startDate"] = this.startDate;
      saveExamStartInfo(param).then(res => {
        this.startInfo = res.data.data
        cb && cb()
        if (this.startInfo.isCompleted) {
          this.isDone = true
          this.examResultFn()
        }
      })
    },
    // 获取考试结果
    examResultFn() {
      examResult({
        "answerId": this.startInfo.id,
        "uncontainsAnswerStatus": "1",
        "examId": this.startInfo.examId,
        "volumeId": this.startInfo.volumeId,
        "userId": this.startInfo.userId
      }).then(res => {
        let data = res.data.list
        data.forEach(item => {
          if (item["examQuestion"].typeCode === 'checkbox') {
            item.optionId = item.optionId.split(',')
          }
        })
        this.questions = data;
      })
    },
    // 点击返回
    testBack() {
      this.$router.go(-1)

    },
    onFinish() {
      let num = 0
      let answer = []
      this.questions.forEach(item => {

        let answerObj = {
          "examType": "onlineExam",
          "pId": this.startInfo.id,
          "questionId": item["examQuestion"].id,
          "volumeId": this.$route.query.paperParam["volumeId"]
        }

        if (item["examQuestion"].typeCode === 'radio') {
          answerObj.optionId = item.optionId
        } else if (item["examQuestion"].typeCode === 'checkbox') {
          answerObj.optionId = item.optionId.join(',')
        } else {
          answerObj.answerText = item.answerText
        }

        answer.push(answerObj)
        if (item.done) {
          num++
        }
      })
      let param = {
        id: this.startInfo.id,
        completeNum: num,
        startDate: this.startDate
      }
      saveAnswer(answer).then(() => {
        examCompleted(param).then(() => {
          this.$toast.fail('时间结束已自动提交!')
          this.$router.replace({
            path: '/test-submit'
          })
        })
      })
    },
    // 问卷答案
    getAnswer(){
      surveyAnswer({
        staffId: localStorage.getItem('staffId'),
        volumeId: this.queryData['surveyId']||this.queryData['volumeId']
      }).then(re => {
        if(re.data.success){
          let data = re.data.data.list
          this.questions.forEach(item => {
            data.forEach(ite => {
              if(item.id === ite.questionId && item['styleCode'] === 'veradio'&& ite['style'] === 'veradio'){
                item.optionId = ite.questionResult
              }
              else if(item.id === ite.questionId && item['styleCode'] === 'vecheckbox' && ite['style'] === 'vecheckbox'){
                if(item['optionIds']){
                  item['optionIds'].push(ite.questionResult)
                }else {
                  item['optionIds'] = [ite.questionResult]
                }
              }
              else if(item.id === ite.questionId && item['styleCode'] === 'vescore' && ite['style'] === 'vescore'){
                item.answerText = ite.questionValue
              }
              else if(item.id === ite.questionId && item['styleCode'] === 'vetextarea' && ite['style'] === 'vetextarea'){
                item.answerText = ite.questionResult
              }
              else if(item.id === ite.questionId && item['styleCode'] === 'veinput' && ite['style'] === 'veinput'){
                item.answerText = ite.questionResult
              }
            })
          })
          this.questions = [...this.questions]
        }
      })
    }
  }
}
</script>
<style lang="less">

  .p12 {
    padding: 0 12px;
  }

  .van-radio {
    margin-bottom: 12px;
  }

  .van-checkbox {
    margin-bottom: 12px;
  }

  .checkItem {
    font-size: 16px;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    text-align: center;
    line-height: 36px;
    margin: 4px;
  }

  .done {
    background: #ccc;
  }

  .ac {
    background: #17d4b5;
    color: #fff;
    font-size: 16px;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    text-align: center;
    line-height: 36px;
  }

</style>
