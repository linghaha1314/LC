<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">
      <van-field readonly clickable required name="studentId" label="培训阶段" :value="formData['planName']"
                 placeholder="选择培训阶段" @click="showPlanPicker = true"
                 :rules="[{ required: true, message: '请选择培训阶段' }]"/>
      <van-popup v-model="showPlanPicker" round position="bottom">
        <van-picker :columns="planColumns" :show-toolbar="true" @cancel="showPlanPicker = false"
                    @confirm="onConfirm($event,formData,'planName','planId','showPlanPicker', addId($event))"
        />
      </van-popup>
      <van-field
          :readonly="formData.status===11"
          v-model="formData['skillMastered']" name="skillMastered" required label="知识、技能掌握情况"
                 placeholder="请输入知识、技能掌握情况" type="textarea" rows="5" show-word-limit :autosize="true" :rules="[{ required: true, message: '请填写知识、技能掌握情况'}]"
      />
      <van-field
          :readonly="formData.status===11"
          v-model="formData['remark']" name="remark" label="备注"
                 placeholder="请输入备注" type="textarea" rows="2" show-word-limit :autosize="true"
      />

      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="margin: 16px;">
        <van-button v-if="formData.status!==11 && formData.status!==2"  style="margin-bottom: 24px;" round block :disabled="disabled" color="#17d4b5" @click="onSubmit">
          保存
        </van-button>
<!--        <van-button v-if="formData.status===0 || formData.status===1" type="primary" style="margin-bottom: 24px;" round block :disabled="disabled" @click="upSub">-->
<!--          提交-->
<!--        </van-button>-->
        <van-button v-if="formData.status === 11" type="primary" style="margin-bottom: 24px;" round block disabled>
          正在审核
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {
  getLeaveType,
  getTeacher,
  uploadFile,
  plansList,
  getLeaveVerification,
  currentTeacher,
  urlForPost, urlForGet
} from '../http/apiMap.js'
import { Dialog } from 'vant';
export default {
  name: 'test',
  data() {
    return {
      formData: {},
      teacherParams: {
        sectionId: localStorage.getItem('currentSectionId')
      },
      showPlanPicker: false,
      showTypePicker: false,
      showDatePicker: false,
      showEndDatePicker: false,
      typeColumns: [],
      planColumns: [],
      action: 3,
      columns: [],
      minDate: new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), new Date().getHours() < 13 ? 9 : 13, 0, 0),
      attachFlag: false,
      leaveDays: 0,
      disabled: false,
      columns1: ['上午', '下午'],
      columnsValue: '',
      queryData: this.$route.query,
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          urlForPost(this.formData.id ? '/plansummary/update':'/plansummary/create',this.formData).then(res => {
            if (res.data.data.success && res.data.data['reasons']) {
              // this.$toast.clear();
              // this.$router.go(-1)
              this.formData.id = res.data.data['reasons'].data.id
              this.$set(this.formData,'status',0)
              this.$router.go(-1)
            } else {
              this.$toast.fail(res.data.msg || '出问题啦!!')
            }
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },

    onTypeConfirm(value) {
      this.formData.typeId = value.value;
      this.formData.typeName = value.text;
      this.attachFlag = value.attachFlag;
      this.showTypePicker = false;
    },
    onConfirm(value, target, name, id, show,cb) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      cb && cb()
    },
    addId(value){
      this.formData.teacherStaffId = value.staffId
    },
    onDateConfirm(value) {
      let yy = value.getFullYear(),
          mm = value.getMonth(),
          dd = value.getDate();
      this.formData.startDate = this.getNowFormatDate(new Date(yy, mm, dd, this.columnsValue === '下午' ? 13 : 9), 0, 0) + ':00:00';
      this.formData.currentDate = new Date(yy, mm, dd)
      let endDD = new Date(yy, mm, dd).valueOf() + (Math.ceil((this.columnsValue === '下午' ? 0.5 : 0) + parseFloat(this.formData.days)) - 2) * (1000 * 60 * 60 * 24)
      this.formData.currentEndDate = new Date(endDD)

      this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      if (this.columnsValue === '') {
        this.columnsValue = '上午'
      }
      this.showDatePicker = false;
    },

    // 请假时长
    leaveNum() {
      this.attachFlag = this.formData.days >= 3;
      if (this.formData.days > this.leaveDays) {
        this.$toast.fail('剩下休假时间不足!')
        this.formData.days = this.leaveDays
        this.disabled = true
      } else {
        this.disabled = false
      }
      if (this.formData.currentDate) {
        let endDD = this.formData.currentDate.valueOf() + (Math.ceil((this.columnsValue === '下午' ? 0 : 0.5) + parseFloat(this.formData.days)) - 2) * (1000 * 60 * 60 * 24)
        this.formData.currentEndDate = new Date(endDD)
        this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      } else {
        this.$toast.fail('请先选择起始时间!')
      }
    },

    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      let strH = date.getHours();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      if (strH >= 0 && strH <= 9) {
        strH = "0" + strH;
      }
      return year + seperator1 + month + seperator1 + strDate + ' ' + strH;
    },

    // 获取请假类型
    leaveTypeGet() {
      getLeaveType({}).then(res => {
        let arr = res.data.list
        let typeArr = []
        arr.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            attachFlag: item.attachFlag
          }
          // item.values = item.name
          typeArr.push(obj)
        })
        this.typeColumns = typeArr
      })
    },
    // 获取带教老师数据
    teacherGet() {
      getTeacher(this.teacherParams).then(res => {
        let arr = res.data.list
        let teacherArr = []
        arr.forEach(item => {
          let obj = {
            text: item.teacherName || '',
            value: item.teacherId
          }
          // item.values = item.name
          teacherArr.push(obj)
        })
        this.columns = teacherArr
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        this.formData.attachPath = res.data.path
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    filterFn(type, options) {
      if (type === 'hour') {
        let arr = []
        options.forEach(item => {
          if (parseInt(item) === 9 || parseInt(item) === 13) {
            arr.push(item)
          }
        })
        return options = arr;
      }
      return options;
    },
    getDaysFn() {
      getLeaveVerification({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        let data = res.data.data;
        this.leaveDays = data["maxLeaveDays"] - data["totalDays"]
      })
    },
    onChange(picker, value) {
      this.columnsValue = value
    },
    currentTeacherFn() {
      currentTeacher({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        if(res.data.data){
          this.formData.medicalTeamLeaderName = res.data.data.teacherName || ''
          this.formData.medicalTeamLeaderId = res.data.data.teacherStaffId
        }
      })
    },
    // 缓存本地
    getSession() {
      sessionStorage.setItem('currentData', JSON.stringify(this.formData))
    },

    upSub(){
      let param = {
        "id": this.formData.id,
        "teacherStaffId":this.formData.teacherStaffId
      }
      urlForPost('/plansummary/startProcess',param).then(res => {
        this.formData.status = 11
      })
    },
    getStudentWrite(){
      urlForGet('/plansummary/getCreateInfoById',this.queryData.id).then(res => {
        if(res.data.success){
          let data = res.data.data
          if(data && data.id){
            this.$set(this.formData,'skillMastered',data.skillMastered)
            this.$set(this.formData,'remark',data.remark)
            this.formData.planId = data.planId
            this.formData.status = data.status
            this.formData.teacherStaffId = data.teacherStaffId
          }
        }
      })
    },
    plansListFn(){
      plansList({
        pageSize: 999,
        pageNum: 1
      }).then(res => {
        let data = res.data.rows
        data.forEach(item => {
          this.planColumns.push({
            text: item.typeName,
            value: item.id,
            ...item
          })
        })
      })
    }
  },
  mounted() {

    this.plansListFn()
    if(this.queryData.id){
      this.$set(this.formData,'planName',this.queryData['planName'])
      this.$set(this.formData,'planId',this.queryData.planId)
      this.$set(this.formData,'id',this.queryData.id)
      this.$set(this.formData,'remark',this.queryData.remark)
      this.$set(this.formData,'skillMastered',this.queryData.skillMastered)
      this.$set(this.formData,'teacherStaffId',this.queryData.staffId)
      // this.plansummaryListFn();
    }
  }
}
</script>