<template>
  <div class="about">
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 20px 12px; text-align: center;">
      <div style="font-size: 18px; margin-bottom: 12px">
      {{data.title}}
      </div>
      <div style="color: #cccccc">
        <div>作者: {{data['authorName']}}</div>
      </div>
      <div style="padding: 20px 12px;text-align: justify; color: #333333" v-html="data.content"></div>

    </div>
  </div>
</template>
<script>

    import { aboutus } from '../http/apiMap';
    export default {
        name: 'news',
        data(){
            return{
                msg:'',
                data: this.$route.query
            }
        },
        computed:{
            name(){
                return this.$route.name
            },
        },
        methods:{

        },
        mounted() {
            aboutus().then(res => {
                this.msg = res.data
            })
        }
    }
</script>