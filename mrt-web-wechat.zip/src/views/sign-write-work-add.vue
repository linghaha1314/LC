<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form @submit="onSubmit">
      <div>

        <van-field
            readonly
            clickable
            required
            name="date"
            label="开始日期"
            :value="formData.startDate&&formData.startDate.substring(0,10)"
            placeholder="选择开始日期"
            @click="showDatePicker = true"
            :rules="[{ required: true, message: '请选择开始日期' }]"
        />
        <van-popup v-model="showDatePicker" round position="bottom">
          <van-datetime-picker
              v-model="formData.currentDate"
              type="date"
              title="开始日期"
              @cancel="showDatePicker = false"
              @confirm="onDateConfirm($event,formData,'startDate','showDatePicker')"
              :min-date="minDate"
          />

        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="date"
            label="结束时间"
            :value="formData.endDate&&formData.endDate.substring(0,10)"
            placeholder="选择结束时间"
            @click="showEndPicker = true"
            :rules="[{ required: true, message: '请选择结束时间' }]"
        />
        <van-popup v-model="showEndPicker" round position="bottom">
          <van-datetime-picker
              v-model="formData.currentDate"
              type="date"
              title="结束时间"
              @cancel="showEndPicker = false"
              @confirm="onDateConfirm($event,formData,'endDate','showEndPicker')"
              :min-date="minDate"
          />
          <div style="font-size:20px;text-align: center;margin: 30px"
               @click="setNow"
          >至今</div>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="工作单位"
            :value="formData['unitName']"
            placeholder="选择工作单位"
            @click="showUnitPicker = true"
            :rules="[{ required: true, message: '请选择工作单位' }]"
        />
        <van-popup v-model="showUnitPicker" round position="bottom">
          <Pager :list-prop="['unitName','id']" url="/advancedsignup/getUnitByPage" :params="{status: 1}" @check ="checkFn($event,formData,'unitName','unitId','showUnitPicker')"></Pager>
        </van-popup>

        <van-field
            v-model="formData.sectionName"
            required
            label="科室名称"
            :rules="[{ required: true, message: '请填写科室名称' }]"
        />

        <van-field
            v-model="formData.position"
            required
            label="职务/职位"
            :rules="[{ required: true, message: '请填写职务/职位' }]"
        />

      </div>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>


      <div style="margin: 16px;">
        <van-button round block color="#17d4b5" native-type="submit">
          提交
        </van-button>
      </div>

    </van-form>
  </div>
</template>
<script>
  import Pager from '../components/searchPager'
  import {
    urlForPost
  } from '../http/apiMap'

  export default {
    name: 'test',
    components: {
      Pager
    },
    data() {
      return {
        url: {
          save: '/advancedsignup/SaveOrUpdateWorkExperience'
        },
        formData: {},
        showDatePicker: false,
        showUnitPicker: false,
        showEndPicker: false,
        minDate: new Date(1960, 1, 1),
        currentDate: new Date(),
        name: '工作'
      }
    },
    computed: {},
    methods: {
      onSubmit() {
        this.formData.staffId = sessionStorage.getItem('staffId')
        urlForPost(this.url.save, this.formData).then(res => {
          if (res.data.success) {
            this.$toast.fail('保存成功!')
            this.formData = {}
            this.$router.replace('/sign-write-work')
          } else {
            this.$toast.fail('保存失败!')
          }
        })
      },

      onDateConfirm(value,target,prop,show) {
        target[prop] = this.getNowFormatDate(value)+' 00:00:00'
        this[show] = false;
      },
      // 时间格式
      getNowFormatDate(date) {
        let seperator1 = "-";
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let strDate = date.getDate();
        if (month >= 1 && month <= 9) {
          month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
        }
        return year + seperator1 + month + seperator1 + strDate;
      },
      checkFn(data,target,name,id,show) {
        target[id] = data.value
        target[name] = data.text
        this[show] = false
      },
      setNow(){
        this.formData.endDate = '至今'
        this.showEndPicker = false
      }
    },
    mounted() {
      this.formData = JSON.parse(localStorage.getItem('currentWorkData') || '{}')
    }
  }
</script>
