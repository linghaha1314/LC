<template>
  <div class="about">
    <van-nav-bar title="进修科室及专业" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        进修科室及专业填写
      </div>
    </div>
    <div>
      <van-form ref="majorForm">
        <van-field v-if="projectInfo.trainTypeCode!=='MandatoryCommissionedTraining'" readonly clickable required
                   name="typeId" label="科室目录" :value="formData['sectionCategoryName']" placeholder="选择科室目录"
                   @click="showMenuPicker = true"
                   :rules="[{ required: true, message: '请选择科室目录' }]"/>
        <van-popup v-model="showMenuPicker" round position="bottom">
          <div>
            <van-search v-model="menuParams.name" shape="round" @change="menuGet" placeholder="搜索"/>
          </div>
          <van-picker :columns="menuColumns" :show-toolbar="true" @cancel="showMenuPicker = false"
                      @confirm="onConfirm($event,formData,'sectionCategoryName','sectionCategoryId','showMenuPicker')"
          />
        </van-popup>

        <van-field readonly clickable required name="typeId" label="科室" :value="formData.sectionName" placeholder="选择科室"
                   @click="showSectionPicker = true"
                   :rules="[{ required: true, message: '请选择科室' }]"/>
        <van-popup v-model="showSectionPicker" round position="bottom">
          <div>
            <van-search v-model="transferParams.name" shape="round" @change="transferGet" placeholder="搜索"/>
          </div>
          <van-picker :columns="sectionColumns" :show-toolbar="true" @cancel="showSectionPicker = false"
                      @confirm="onConfirm($event,formData,'sectionName','sectionId','showSectionPicker')"
          />
        </van-popup>

        <van-field readonly clickable required name="typeId" label="专业" :value="formData.majorName" placeholder="选择专业"
                   @click="showMajorPicker = true"
                   :rules="[{ required: true, message: '请选择专业' }]"/>
        <van-popup v-model="showMajorPicker" round position="bottom">
          <van-picker :columns="majorColumns" :show-toolbar="true" @cancel="showMajorPicker = false"
                      @confirm="onConfirm($event,formData,'majorName','majorId','showMajorPicker',getBatch)"
          />
        </van-popup>
        <van-field v-if="projectInfo.trainTypeCode === 'MandatoryCommissionedTraining'" readonly clickable required
                   name="batchId" label="项目期别" :value="formData['batchName']" placeholder="选择项目期别"
                   @click="showBatchPicker = true"
                   :rules="[{ required: true, message: '请选择项目期别' }]"/>
        <van-popup v-model="showBatchPicker" round position="bottom">
          <van-picker :columns="batchColumns" :show-toolbar="true" @cancel="showBatchPicker = false"
                      @confirm="onConfirm($event,formData,'batchName','batchId','showBatchPicker')"
          />
        </van-popup>

        <van-field v-model="formData.months" readonly type="number" required label="进修期限" input-align="right">
          <template #extra>
            个月
          </template>
        </van-field>
        <van-field v-model="formData.fee" readonly type="number" required label="费用" input-align="right">
          <template #extra>
            元
          </template>
        </van-field>
        <van-field name="diagnosis" clickable required label="进修要求" v-model="formData['purpose']" placeholder="请输入进修要求"
                   :rules="[{ required: true, message: '请输入进修要求' }]"
        />
        <van-field v-if="projectInfo.trainTypeCode === 'TrainingOfKeyDoctors'" readonly clickable required
                   name="teacherId" label="选择导师" :value="formData['tutorName']" placeholder="选择选择导师"
                   @click="showTutorPicker = true"
                   :rules="[{ required: true, message: '请选择选择导师' }]"/>
        <van-popup v-model="showTutorPicker" round position="bottom">
          <van-picker :columns="tutorColumns" :show-toolbar="true" @cancel="showTutorPicker = false"
                      @confirm="onConfirm($event,formData,'tutorName','teacherId','showTutorPicker')"
          />
        </van-popup>
        <van-field v-model="formData['actuality']" label="本人进修专业现有业务水平"/>

      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button style="margin-bottom: 12px;" disabled round block>
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          下一步
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
import {getTransferSign, listMajorAd, urlForPost, getCategory, getStaffByIdentifyNo} from "../http/apiMap";
import {Dialog} from "vant";

export default {
  name: 'sign-tab',
  components: {},
  data() {
    return {
      url: {
        tutorList: '/advancedsignup/tutorList',
        // tutorList: '/backboneTraining/getTeachers',
        batch: '/advancedsignup/getBatchListByPage',
        info: '/advancedsignup/getDetailById',
        staffBatch: '/advancedsignup/getByBatchAndStaff',
        cardInfo: '/advancedsignup/getInfoByBatchIdAndStaffId',
        batchId: '/advancedsignup/queryRecord'
      },
      active: 0,

      formData: {},
      transferParams: {
        pageSize: 999,
        pageNum: 1,
        name: '',
      },
      menuParams: {
        pageSize: 999,
        pageNum: 1,
        name: '',
      },
      showMenuPicker: false,
      showBatchPicker: false,
      showTutorPicker: false,
      showSectionPicker: false,
      showMajorPicker: false,
      showTeacherDetailPicker: false,
      showTeacherPicker: false,
      menuColumns: [],
      sectionColumns: [],
      batchColumns: [],
      majorColumns: [],
      tutorColumns: [],
      projectInfo: JSON.parse(localStorage.getItem('signInfo')),
      teacherInfo: '',
      tutorLists: [],
      acTeacher: {},
    }
  },
  computed: {},
  methods: {
    // 获取科室目录信息
    menuGet() {
      getCategory(this.menuParams).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.menuColumns = [...optionArr]
      })
    },
    // 获取科室信息
    transferGet() {
      this.transferParams.hospitalId = this.projectInfo.hospitalId
      if (this.projectInfo.trainTypeCode === 'MandatoryCommissionedTraining') {
        this.transferParams.projectId = this.projectInfo.id || ''
      }
      this.transferParams.sectionCategoryId = this.formData.sectionCategoryId
      this.transferParams.code = this.projectInfo.trainTypeCode
      this.transferParams.status = 0
      getTransferSign(this.transferParams).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            sectionStaffId: item.sectionId
          }
          optionArr.push(obj)
        })
        this.sectionColumns = [...optionArr]
      })
    },
    // 获取专业
    getListMajor() {
      let majorParams = {
        pageSize: 999,
        pageNum: 1,
        hospitalId: this.projectInfo.hospitalId,
        projectId: this.projectInfo.projectId || '',
        sectionId: this.formData.sectionId,
        status: 0
      }
      listMajorAd(majorParams).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.majorName + `(${item.months}个月)`,
            value: item.id,
            majorStaffId: item.majorId,
            ...item
          }
          optionArr.push(obj)
        })
        this.majorColumns = [...optionArr]
      })

    },
    // 获取期别
    getBatch() {
      let params = {
        pageSize: 999,
        pageNum: 1,
        "advancedMajorId": this.formData.majorId,
        "openBatch": true,
        "status": 1
      }
      urlForPost(this.url.batch, params).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: `${item.name}-${item.startDate} - ${item.endDate}`,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.batchColumns = [...optionArr]
      })
    },
    onConfirm(value, target, name, id, show, cb) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (id === 'majorId') {
        this.chooseAdvancedMajor(value)
        if (cb && this.projectInfo.trainTypeCode === 'MandatoryCommissionedTraining') {
          cb()
        }
      } else if (id === 'sectionId') {
        target['sectionStaffId'] = value.sectionStaffId
        this.getListMajor() // 获取专业
        if (this.projectInfo.trainTypeCode === 'TrainingOfKeyDoctors') {
          this.getTutorList() // 获取导师
        }
        if (this.projectInfo.trainTypeCode === 'MandatoryCommissionedTraining') {
          target['batchId'] = ''
          target['batchName'] = ''
        }
        target['majorName'] = ''
        target['majorId'] = ''
        target['months'] = ''
        target['fee'] = ''
        cb&&cb()
      } else if (id === 'sectionCategoryId') {
        this.transferGet()
        if (this.projectInfo.trainTypeCode === 'MandatoryCommissionedTraining') {
          target['batchId'] = ''
          target['batchName'] = ''
        }
        target['sectionName'] = ''
        target['sectionId'] = ''
        target['majorName'] = ''
        target['majorId'] = ''
        target['months'] = ''
        target['fee'] = ''
        if (cb) {
          cb()
        }
      } else {
        this.getListMajor() // 获取专业

      }

    },
    attendAdd() {
      this.$refs.majorForm.validate().then(() => {
        if (this.projectInfo.trainTypeCode !== 'MandatoryCommissionedTraining') {
          this.formData.batchId = this.projectInfo.id
        }
        sessionStorage.setItem('majorData', JSON.stringify(this.formData))
        this.$router.push({
          path: '/sign-write-info'
        })
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    // 选择老师的数据
    checkFn(data) {
      this.formData.teacherId = data.value
      this.formData.teacherName = data.text
      this.showPicker = false
      this.showTeacherPicker = false
    },
    goDetail(data, ind) {
      this.active = ind;
      this.acTeacher = data
      this.formData.teacherName = data["tutorName"]
      this.formData.teacherId = data.teacherId
    },
    // 获取导师
    getTutorList() {
      urlForPost(this.url.tutorList, {
        "advancedSectionId": this.formData.sectionId,
        "batchId": this.projectInfo.id
        // "status":"2",
        // "typeCode":"tutor",
        // "activeStatus":"0",
        // "page":"1",
        // "rows":"999",
        // "sectionId":this.formData.sectionId
      }).then(res => {
        this.tutorColumns = res.data.list || []
        this.tutorColumns.forEach(item => {
          item.text = item['tutorName']
          item.value = item.id
        })
      })
    },
    // 更新数据
    upDataFn(getData) {
      this.$set(this.formData, 'fee', parseInt(getData.fee))
      this.$set(this.formData, 'months', parseInt(getData.months))
      this.$set(this.formData, 'actuality', getData["actuality"])
      this.$set(this.formData, 'purpose', getData["purpose"])
      this.$set(this.formData, 'sectionCategoryName', getData["sectionCategoryName"])
      this.$set(this.formData, 'sectionCategoryId', getData.sectionCategoryId)
      this.$set(this.formData, 'sectionName', getData.sectionName)
      this.$set(this.formData, 'sectionId', getData.sectionId)
      this.$set(this.formData, 'majorName', getData.majorName)
      this.$set(this.formData, 'teacherId', getData.teacherId)
      this.$set(this.formData, 'tutorName', getData['tutorName'])
      this.$set(this.formData, 'majorId', getData.majorId)
      this.$set(this.formData, 'batchName', getData["batchName"])
      this.$set(this.formData, 'batchId', getData.batchId)
      this.$set(this.formData, 'id', getData.id)
      this.transferGet()
      this.getListMajor()
      this.getBatch()
      this.getTutorList()
    },
    chooseAdvancedMajor(obj) {
      let flag = false;
      //普通临床进修4,5,6,10,11,12月份只招收1、3、4个月的专业
      if (this.projectInfo.trainTypeCode === 'GeneralClinicalAdvanced') {
        let date = new Date();
        let month = date.getMonth() + 1;
        let arr = [4, 5, 6, 10, 11, 12];
        for (let i = 0; i < arr.length; i++) {
          if (arr[i] === month) {
            if (obj.months === 6 || obj.months === 12) {
              flag = true;
            }
            break;
          }
        }
        if (flag) {
          Dialog.confirm({
            message: '本期只招收培养期限为3个月/期的专业! '
          }).then().catch(()=>{});
          this.formData.majorId = null;
          this.formData.majorName = null;
          this.formData.periodId = '';
          this.formData.months = '';
          this.formData.fee = '';
          return;
        }
      }
      this.formData.periodId = obj.periodId;
      this.formData.months = obj.months;
      this.formData.fee = obj.fee;
      // if (trainTypeCode == 'MandatoryCommissionedTraining'){
      //   this.openBatchParams.advancedMajorId=obj.id;
      //   this.advancedSignup.batchId=null;
      //   this.showBatch=true;
      // }
    }
  },
  mounted() {

    let info = sessionStorage.getItem('majorData')
    if (info) {
      this.formData = {...JSON.parse(info)}
      delete this.formData.status
    } else {
      let data = JSON.parse(sessionStorage.getItem('batchInfo'))
      if (data) {
        sessionStorage.setItem('majorData', '')

        let obj = {...data.data}
        obj.id = obj.projectId
        this.projectInfo = {...obj}
        if (data.data.trainTypeCode !== 'MandatoryCommissionedTraining') {
          this.menuGet()
        } else {
          this.transferGet()
        }
        getStaffByIdentifyNo(data.identifyNo).then(res => {
          if (res.data && res.data.data[0]) {
            let identifyNoInfo = res.data.data[0]
            this.formData.sectionStaffId = identifyNoInfo.sectionId
            this.formData.majorStaffId = identifyNoInfo.majorId
          }
          sessionStorage.setItem('identifyNoInfo', JSON.stringify(res.data.data[0]))
          if (data.data && data.data.batchId) {
            urlForPost(this.url.cardInfo, {
              "staffId": data.data.staffId,
              "batchId": data.data.batchId
            }).then(res => {
              delete res.data.data.status

              sessionStorage.setItem('cardInfo', JSON.stringify(res.data.data))
            })
            urlForPost(this.url.staffBatch, {
              "staffId": data.data.staffId,
              "batchId": data.data.batchId
            }).then(resS => {
              sessionStorage.setItem('staffBatchInfo', JSON.stringify(resS.data.data))
              let getData = {...resS.data.data}
              this.upDataFn(getData)
            })
          }
        })

      } else {
        let signInfo = JSON.parse(localStorage.getItem('signInfo') || '{}')
        getStaffByIdentifyNo(sessionStorage.getItem('identifyNo')).then(res => {
          let identifyNoInfo = res.data.data[0] || {}
          if (identifyNoInfo) {
            this.formData.sectionStaffId = identifyNoInfo.sectionId
            this.formData.majorStaffId = identifyNoInfo.majorId
          }
          if (identifyNoInfo.id) {
            sessionStorage.setItem('identifyNoInfo', JSON.stringify(res.data.data[0]))
            if (this.projectInfo.trainTypeCode !== 'MandatoryCommissionedTraining') {
              urlForPost(this.url.cardInfo, {
                "staffId": identifyNoInfo.id,
                "batchId": signInfo.id
              }).then(res => {
                if (res.data.data && res.data.data.status) {
                  delete res.data.data.status
                }
                sessionStorage.setItem('cardInfo', JSON.stringify(res.data.data))
              })
              urlForPost(this.url.staffBatch, {
                "staffId": identifyNoInfo.id,
                "batchId": signInfo.id
              }).then(resS => {
                sessionStorage.setItem('staffBatchInfo', JSON.stringify(resS.data.data))
                let getData = {...resS.data.data}
                this.upDataFn(getData)
              })
            } else {
              urlForPost(this.url.batchId, {
                "projectId": this.projectInfo.id,
                "identifyNo": sessionStorage.getItem('identifyNo')
              }).then(resB => {
                urlForPost(this.url.cardInfo, {
                  "staffId": identifyNoInfo.id,
                  "batchId": resB.data.data.batchId
                }).then(resI => {
                  sessionStorage.setItem('cardInfo', JSON.stringify(resI.data.data))
                })
                urlForPost(this.url.staffBatch, {
                  "staffId": identifyNoInfo.id,
                  "batchId": resB.data.data.batchId
                }).then(resS => {
                  sessionStorage.setItem('staffBatchInfo', JSON.stringify(resS.data.data))
                  let getData = {...resS.data.data}
                  this.upDataFn(getData)
                })
              })
            }


          } else {
            this.formData = {}
          }
        })
      }
    }
    if (this.projectInfo.trainTypeCode !== 'MandatoryCommissionedTraining') {
      this.menuGet()
    }
    else {
      this.transferGet()
    }
  }
}
</script>
<style lang="less">
  .ac {
    box-shadow: 0 0 7px 4px rgba(23, 212, 181, 0.75);
    -webkit-box-shadow: 0 0 7px 4px rgba(23, 212, 181, 0.75);
    -moz-box-shadow: 0 0 7px 4px rgba(23, 212, 181, 0.75);
  }
</style>
