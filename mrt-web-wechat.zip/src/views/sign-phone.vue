<template>
  <div style="text-align: center">
    <van-nav-bar title="报名" left-arrow>
        <template #left>
            <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
        </template>
</van-nav-bar>
<!--    <div class="sub-title mb20">贵医大进修</div>-->
<van-form @submit="onSubmit">
    <van-field required v-model="loginInfo.phoneNum" name="username" label="手机号" placeholder="请输入手机号" :rules="[{ pattern:/^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/, message: '请填写正确手机号' }]" />
    <van-field required v-model="loginInfo.idCard" name="username" label="身份证号" placeholder="请输入身份证号" :rules="[{ pattern:/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/, message: '必须填写正确身份证号' }]" />
    <div style="display:flex; align-items: center;padding-right: 12px;">
        <van-field required v-model="loginInfo.yzmCode" name="username" label="验证码" placeholder="请输入验证码" :rules="[{ required: true, message: '必须填写验证码' }]" />
        <div style="width: 100px; height: 34px;border-radius: 17px; background: #07c160; line-height: 34px; color: #ffffff;" round size="mini" type="primary" @click="getCode" v-if="!show">获取验证码</div>
        <div style="width: 100px; height: 34px;border-radius: 17px; background: #cccccc; line-height: 34px; color: #ffffff;" round size="mini" type="primary" v-if="show">
            {{time}} 秒后重试
        </div>
    </div>
    <div style="padding: 12px; color: rgb(138, 109, 59);">
        <van-checkbox v-model="checked" shape="square" checked-color="#17d4b5">
            <span style="color: rgb(138, 109, 59);">
                本人承诺，本次报名信息真实有效，不存在任何虚假信息，并对所填信息负全部责任。
            </span>
        </van-checkbox>
    </div>
    <div style="margin: 16px;">
        <van-button :disabled="!checked" round block type="primary" native-type="submit">报名</van-button>
    </div>
</van-form>
</div>
</template>
<script>
    import {
        urlForPost
    } from '../http/apiMap.js'

    export default {
        data() {
            return {
                url: {
                    yzmCode: '/account/sendVerificationCode',
                    getAdvancedsignupInfo: '/advancedsignup/getAdvancedsignupInfo',
                    validateInfo: '/advancedsignup/validateInfo'
                },
                loginInfo: {
                    phoneNum: '',
                    idCard: '',
                    yzmCode: ''
                },
                time: 60,
                show: false,
                checked: false,
                hospitalId: 'c77e18b0-1ffa-11e7-b036-00163e0603fa',
                projectInfo: JSON.parse(localStorage.getItem('signInfo')),
            };
        },
        methods: {
            onSubmit() {
                sessionStorage.clear()
                urlForPost(this.url.getAdvancedsignupInfo,{ "identifyNo": this.loginInfo.idCard }).then(res => {
                    let data = res.data
                    if (data.data === null || data.data.status === 0 || data.data.status === 4 || data.data.status === 8 || data.data.status === 11) {
                        urlForPost(this.url.validateInfo,{
                            "mobile": this.loginInfo.phoneNum,
                            "code": this.loginInfo.yzmCode,
                            "identifyNo": this.loginInfo.idCard,
                            "hospitalId": this.hospitalId,
                            "trainTypeCode": this.projectInfo.trainTypeCode,
                            "status": 0
                        }).then(res => {
                            let data = res.data
                            if (data.status === 0) {
                                sessionStorage.setItem('identifyNo', this.loginInfo.idCard)
                                sessionStorage.setItem('mobile', this.loginInfo.phoneNum)
                                this.$router.replace({
                                    path: '/sign-write-tab'
                                })
                            } else {
                                this.$toast.fail(data.msg);
                            }
                        })
                    } else {
                        this.$toast.fail("您上次报名未完成报到！");
                    }
                })
            },
            getCode() {
                if (this.loginInfo.phoneNum) {
                    this.show = true;
                    this.time = 60;
                    urlForPost(this.url.yzmCode, {
                        mobiles: this.loginInfo.phoneNum
                    }).then()
                    this.finish()
                } else {
                    this.$toast.fail('您还没输入手机号!')
                }
            },
            finish() {
                let timer = setInterval(() => {
                    if (this.time < 1) {
                        this.show = false;
                        clearInterval(timer);
                    } else {
                        this.time--
                    }
                }, 1000)

            }
        },
        mounted(){
        }
    };
</script>
<style lang="less">
    .title {
        font-size: 20px;
    }
    
    .sub-title {
        font-size: 16px;
        color: rgb(203, 203, 203)
    }
    
    .mb20 {
        margin-bottom: 20px;
    }
</style>