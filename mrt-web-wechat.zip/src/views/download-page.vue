<template>
  <div class="about">
    <van-nav-bar title="下载" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 20px 12px; text-align: center;">
      <div style="margin: 12px;color: red;text-align: center;font-size: 16px">如果您手机浏览器无法下载, 请用电脑浏览器访问贵医进修网进行操作: http://jxglxt.gmcah.cn:4215/logon.html
      </div>
      <van-button v-if="type==='intoFamily'" style="margin: 100px auto; width: 60vw" round block type="primary"
                  :disabled="isDis"
                  @click="download">
        入科通知下载
      </van-button>
      <van-button v-if="type==='studentCard'" style="margin: 100px auto; width: 60vw" round block type="primary"
                  :disabled="isDis"
                  @click="cardDownload">
        学员证
      </van-button>
      <van-button v-if="type==='application'" style="margin: 100px auto; width: 60vw" round block type="primary"
                  :disabled="isDis"
                  @click="applicationDownload">
        申请表下载
      </van-button>
      <van-button v-if="type === 'TZ'" style="margin: 100px auto; width: 60vw" round block type="primary" :disabled="isDis"
                  @click="noticeDownload">
        录取通知书下载
      </van-button>
      <van-button v-if="type === 'graduationCertificate'" style="margin: 100px auto; width: 60vw" round block type="primary" :disabled="isDis"
                  @click="graduationDownload">
        结业证下载
      </van-button>
      <van-button v-if="type === 'advancedgraduationTable'" style="margin: 100px auto; width: 60vw" round block type="primary" :disabled="isDis"
                  @click="graduationFormDownload">
        结业鉴定下载
      </van-button>
      <van-button v-if="type === 'studentInfoForm' || type === 'studentInfoFormBy2'" style="margin: 100px auto; width: 60vw" round block type="primary" :disabled="isDis"
                  @click="studentInfoForm">
        学籍信息表
      </van-button>
    </div>
  </div>
</template>
<script>
import {wordtemplate, downFile, getOneWordTemplateByObject, urlForPost} from '../http/apiMap';

export default {
  name: 'download',
  data() {
    return {
      isDis: false,
      type: this.$route.query.type
    }
  },
  computed: {},
  methods: {
    download() {
      // this.show = true
      let id = this.$route.query.id
      wordtemplate(id || '').then(r => {
        downFile({
          "templateId": r.data.data,
          "studentId": id || '',
          "print": true
        }).then(res => {
          // let blob = res.data
          // let reader = new FileReader();
          // reader.readAsDataURL(blob); // 转换为base64，可以直接放入a表情href
          // reader.onload = (e) => {
          //     // 转换完成
          //     this.hrefU = e.target.result;
          //     this.show = true
          // };
          // let data = res.data
          // this.hrefU = window.URL.createObjectURL(new Blob([data]));
          // this.show = true
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "入科通知单.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })

    },
    isWeixin() {
      let ua = navigator.userAgent.toLowerCase();
      return ua.indexOf('weixin') > 0 || ua.indexOf('wechat') > 0 || ua.indexOf('micromessenger') > 0;
    },

    applicationDownload() {
      let query = this.$route.query
      let code = ''
      if (query.trainTypeCode === 'TrainingOfKeyDoctors') {
        code = 'trainingOfKeyDoctorsForm';
      } else {
        code = 'generalClinicalAdvancedForm';
      }
      getOneWordTemplateByObject({
        code: code
      }).then(r => {
        downFile({
          "templateId": r.data.data.id,
          hospitalId: query.hospitalId,
          id: query.staffId,
          "print": true
        }).then(res => {
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "申请表.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })
    },
    noticeDownload() {
      let query = this.$route.query
      let code = ''
      if (query.typeCode === 'MandatoryCommissionedTraining') {
        code = 'MandatoryCommissioned';
      } else {
        code = query.typeCode;
      }
      getOneWordTemplateByObject({
        code: code+'Notice'
      }).then(r => {
        downFile({
          "templateId": r.data.data.id,
          signupId: query.id,
          "print": true
        }).then(res => {
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "录取通知书.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })
    },
    cardDownload() {
      let query = this.$route.query
      getOneWordTemplateByObject({
        code: 'advancedWorkCard'
      }).then(r => {
        downFile({
          "templateId": r.data.data.id,
          studentId: query.id,
          "print": true
        }).then(res => {
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "学员证.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })
    },
    graduationDownload() {
      let query = this.$route.query
      getOneWordTemplateByObject({
        code: 'graduationCertificate'
      }).then(r => {
        downFile({
          "templateId": r.data.data.id,
          studentId: query.studentId,
          "print": true
        }).then(res => {
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "结业证.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })
    },
    graduationFormDownload() {
      let query = this.$route.query
      getOneWordTemplateByObject({
        code: this.type
      }).then(r => {
        downFile({
          "templateId": r.data.data.id,
          studentId: query.studentId,
          hospitalId: query.hospitalId,
          "print": true
        }).then(res => {
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "结业鉴定.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })
    },
    studentInfoForm() {
      let query = this.$route.query
      urlForPost('/advancedsignup/getTemplateByObj',{
        code: this.type
      }).then(r => {
        downFile({
          subMajorId: query.advancedMajorId,
          batchId: query['kbabatchId'],
          "templateId": r.data.data.data[0].id,
          studentId: query.studentId,
          hospitalId: query.hospitalId || 'c77e18b0-1ffa-11e7-b036-00163e0603fa',
          id: query.staffId,
          "print": true
        }).then(res => {
          let _res = res.data
          let blob = new Blob([_res], {type: 'charset=utf-8'});
          let downloadElement = document.createElement("a");
          let href = window.URL.createObjectURL(blob); //创建下载的链接
          downloadElement.href = href;
          downloadElement.download = "学籍信息表.pdf"; //下载后文件名
          document.body.appendChild(downloadElement);
          downloadElement.click(); //点击下载
          document.body.removeChild(downloadElement); //下载完成移除元素
          window.URL.revokeObjectURL(href); //释放掉blob对象
        })
      })
    },
  },
  mounted() {
    let app = this.isWeixin()
    if (app) {
      this.$toast.fail({
        message: '点击右上角选项,在其他浏览器打开当前页面',
        duration: 0
      })
    }
  }
}
</script>
