<template>
  <div class="about">
    <van-nav-bar title="课件学习" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
</van-nav-bar>
<div>
    <van-list>
        <van-cell title="文件名" :value="studyData.name || '无'" />
        <van-cell title="文件大小" :value="(studyData.size || 0)+'m'" />
        <van-cell v-if="studyType" title="文件格式" :value="studyType" />
        <van-cell title="已学习" :value="(studyData['studyNum'] || 0)+'人'" />
        <!--      <van-cell title="时长" :value="parseInt(studyData.minutes/60)+':'+studyData.minutes%60"/>-->
    </van-list>

    <!--    studyData.path ||-->
    <div v-if="studyData.path && studyData.path.split('.')[1]==='mp4'">
        <video id="video" style="width: 100%" :src="studyData.path" controls="controls">
<!--        <video id="video" ref="video" style="width: 100%" src="../../public/img/test.mp4" controls="controls">-->
          您的浏览器不支持 video 标签。
        </video>
    </div>
    <div v-if="studyData.path && studyData.path.split('.')[1]!=='mp4'" style="text-align: center; margin: 24px;">
        <a :href="studyData.path || ''" download="附件">
            {{studyData.path?'查看课件':'未找到该课件'}}
        </a>
    </div>
    <!-- <div v-if="studyData.path && studyData.path.split('.')[1]==='doc'" style="text-align: center; margin: 24px;">
        <a :href="studyData.path || ''" download="附件">
          {{studyData.path?'下载课件':'未找到该课件'}}
        </a>
    </div> -->
</div>
</div>
</template>
<script>
    import {
        courseWare,
        processUpdate
    } from '../http/apiMap';
    export default {
        name: 'study-play',
        data() {
            return {
                queryData: this.$route.query,
                studyData: {},
                studyType:"",
                updateParam: {
                    id: this.$route.query.reasonId,
                    minutes: 0,
                    completed: 0
                }
            }
        },
        computed: {},
        methods: {
            getCourseWare() {
                courseWare(this.queryData["coursewareId"]).then(res => {
                    // courseWare('f515df34-6755-11eb-8ea8-00163e0603fa').then(res => {
                    this.studyData = res.data || {}
                    if(this.studyData.path){
                        this.studyType=this.studyData.path.split('.')[1]
                    }

                })
            },

        },
        mounted() {
            let that = this;
            this.getCourseWare();
            //监听播放时间
            this.$nextTick(() => {
                setTimeout(() => {
                    let video = document.getElementById('video');
                    if (video) {
                        //使用事件监听方式捕捉事件
                        video.addEventListener("timeupdate", function() {
                            let timeDisplay;
                            //用秒数来显示当前播放进度
                            timeDisplay = Math.floor(video.currentTime);
                            that.updateParam.minutes = timeDisplay
                            if (timeDisplay % 3 === 0) {
                                processUpdate(that.updateParam).then()
                            }
                        }, false);
                        video.addEventListener("ended", function() {
                            that.updateParam.completed = 1
                            processUpdate(that.updateParam).then()
                        })
                    }
                }, 1000)



            })


        }

    }
</script>