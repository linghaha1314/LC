<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <!--            <template #right v-if="role !== 'StudentType_jxs'">-->
      <!--                <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">我的</span>-->
      <!--                <span v-else style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>-->
      <!--            </template>-->
    </van-nav-bar>

    <div v-if="role !== 'StudentType_jxs'">
      <van-dropdown-menu active-color="#17d4b5">
<!--        <van-dropdown-item title="年度" v-model="listParams['searchMonth']" @change="leaveListGet" :options="option1"/>-->
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.sectionId" @change="onRefresh" :options="option2"/>
        <van-dropdown-item v-if="role === 'JXS_manager' || role === 'sectionManager'" title="申请状态" v-model="listParams.status" @change="onRefresh" :options="queryData.type==='teacher-query'?option5:option3"/>
        <van-dropdown-item v-if="isLibrary" title="状态" v-model="listParams.activeStatus" @change="onRefresh" :options="option4"/>
      </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <div>
        <van-search v-model="listParams.name" shape="round" @change="searchLeaveListGet" placeholder="搜索" />
      </div>
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.id">
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
               姓名: {{ data.teacherName}}
              <template v-if="isLibrary">
                <van-tag style="text-align: center" :type="'success'" v-if="data.activeStatus===2" size="medium">
                  注销
                </van-tag>
                <van-tag style="text-align: center" :type="'danger'" v-if="data.activeStatus===1" size="medium">停职
                </van-tag>
                <van-tag style="text-align: center" :type="'primary'" v-if="data.activeStatus===0" size="medium">
                  在职
                </van-tag>
<!--                <van-tag style="text-align: center" :type="'warning'" v-if="data.status===11" size="medium">-->

<!--                  {{isLibrary?'在职':'审核中'}}-->
<!--                </van-tag>-->
              </template>
              <template v-else>
                <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">
                  已审核
                </van-tag>
                <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">已拒绝
                </van-tag>
                <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">
                  未提交
                </van-tag>
                <van-tag style="text-align: center" :type="'warning'" v-if="data.status===11" size="medium">

                  审核中
                </van-tag>
              </template>
<!--              <div v-if="isLibrary">-->
<!--                <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">-->
<!--                  注销-->
<!--                </van-tag>-->
<!--                <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">停职-->
<!--                </van-tag>-->
<!--                <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">-->
<!--                  在职-->
<!--                </van-tag>-->
<!--              </div>-->
            </div>
            <van-divider/>
            <div @click="goDetail(data)">
              <div style="margin-bottom: 10px">
                <div>单位: {{ data['unitName'] || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>科室: {{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>专业: {{ data.majorName || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <template v-if="isLibrary">
                <van-button v-if="data.status === 0||data.status === 11"
                            style="width: 4em; margin-right: 12px" type="warning" size="mini" @click="operation(data, 1)">
                  停职
                </van-button>
                <van-button v-if="data.status === 1"
                            style="width: 4em; margin-right: 12px" type="warning" size="mini" @click="operation(data, 0)">
                  复职
                </van-button>
                <van-button v-if="data.status !== 2"
                            style="width: 4em; margin-right: 12px" type="warning" size="mini" @click="operation(data, 2)">
                  注销
                </van-button>
                <van-button v-if="data.status === 0 || data.status === 11"
                            style="width: 7em; margin-right: 12px" type="warning" size="mini" @click="operation(data, 2, 'tutor')">
                  加入导师库
                </van-button>
                <van-button v-if="data.status === 0 || data.status === 1 || data.status === 11"
                            style="width: 6em; margin-right: 12px"
                            type="primary"
                            size="mini"
                            @click="upFn(data)">
                  修改资料
                </van-button>
              </template>
              <van-button v-if="role !== 'teacher' && queryData.type!=='teacher-query' && queryData.type!=='tutor-query' && !isLibrary && data.status !== 0"
                          style="width: 50px; margin-right: 12px" type="warning" size="mini" @click="goProcess(data)">
                去审核
              </van-button>
<!--              <van-button v-if="role === 'StudentType_jxs' && data.status === 0" style="width: 50px; margin-right: 12px"-->
<!--                          type="danger" size="mini" @click="delFn(data)">删除-->
<!--              </van-button>-->
              <router-link v-if="data.status === 11 && !isLibrary" :to="{path:'/approval-detail',query:data}">
                <van-button style="margin-right: 12px" type="default" size="mini">查看审批进度</van-button>
              </router-link>
              <van-button v-if="data.status === 11 && role === 'teacher'"
                  style="width: 6em; margin-right: 12px" type="primary" size="mini" @click="reSub(data)">撤销申请
              </van-button>
              <van-button v-if="(data.status === 0 || data.status === 1) && queryData.type!=='teacher-query' && queryData.type!=='tutor-query' && role === 'teacher'"
                  style="width: 6em; margin-right: 12px" type="primary" size="mini" @click="upSub(data)">提交申请
              </van-button>
              <van-button v-if="(data.status === 0 || data.status === 1) && queryData.type!=='teacher-query' && queryData.type!=='tutor-query' && role === 'teacher'"
                          style="width: 6em; margin-right: 12px"
                          type="primary"
                          size="mini"
                          @click="upFn(data)">
                修改资料
              </van-button>


<!--              <router-link v-if="data.status === 11" :to="{path:'/approval-detail',query:data}">-->
<!--                <van-button type="default" size="mini">查看审批进度</van-button>-->
<!--              </router-link>-->
              <router-link :to="{path:'/teachers-detail',query:data}">
                <van-button style="width: 4em" type="primary"
                            size="mini">详情
                </van-button>
              </router-link>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
      <div style="position: fixed;right: 26px;bottom: 60px" v-if="addFlag && !(isTutor&&isLibrary)">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getApplyInfo,
  delThreemonthcheck,
  urlForPost,
  urlForGet
} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      reason: '',
      show: false,
      listParams: {
        pageSize: 10,
        pageNum: 0,
        // typeCode: 'teacher',
        staffTypeCode: 'trainQualifiedCertificate',
        status: null,

      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option1: [],
      option2: [],
      option3: [
        {text: '全部', value: null},
        // {text: '已拒绝', value: 1},
        // {text: '已通过', value: 2},
        {text: '审核中', value: 11},
      ],
      option5: [
        {text: '全部', value: null},
        {text: '已拒绝', value: 1},
        {text: '已通过', value: 2},
        {text: '审核中', value: 11},
      ],
      option4: [
        {text: '全部', value: null},
        {text: '停职', value: 1},
        {text: '注销', value: 2},
        {text: '在职', value: 0},
      ],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      studentInfo: {},
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      isLoading: false,
      count: 0,
      addFlag: true,
      queryData: this.$route.query,
      name: '带教老师',
      isTutor: false,
      isLibrary: false
    }
  },
  methods: {
    goDetail(data) {
      if (this.role === 'StudentType_jxs') {
        // localStorage.setItem('currentData', JSON.stringify(data))
        this.$router.push({
          path: '/three-mouths-add',
          query: data
        })
      }
    },
    searchLeaveListGet(){
      this.listParams.pageNum = 1
      this.onRefresh()
    },
    // 获取申请列表
    leaveListGet(f) {
      // let params = {
      //   ...this.listParams
      // }
      if(this.queryData.type==='teacher-approve'||this.queryData.type==='tutor-approve'){
        urlForPost('/teacher/getTeacherLibraryList',this.listParams).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if(res.data.rows.length === 0 || res.data.rows.length<this.listParams.pageSize){
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.rows];
          }else{
            this.testData = [...res.data.rows];
          }
          this.addFlag = this.testData.length===0
        })
      }else if(this.queryData.type==='teacher-apply'||this.queryData.type==='tutor-apply'){
        this.isLibrary = false
        urlForGet('/teacher/getApplicantData').then(res => {
          if(res.data.data.id){
            urlForPost('/teacher/getListQueryByPage',{
              teacherId: res.data.data.id,
              // typeCode: this.listParams.typeCode
            }).then(res => {
              if(f==='onLoad'){
                this.state.loading = false;
                if( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length){
                  this.state.finished = true
                }
                if(res.data.total === 0){
                  this.testData = []
                }else{
                  this.testData = [...this.testData, ...res.data.list];
                }
              }else{
                this.testData = [...res.data.list];
              }
            })
          }
        })
      }else if(this.queryData.type==='teacher-query'||this.queryData.type==='tutor-query'){
        urlForPost('/teacher/getTeacherList',this.listParams).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if(res.data.data.list.length === 0 || res.data.data.list.length<this.listParams.pageSize){
              this.state.finished = true
            }
            if(res.data.data.total === 0){
              this.testData = []
            }else{
              this.testData = [...this.testData, ...res.data.data.list];
            }
          }else{
            this.testData = [...res.data.data.list];
          }
        })
      }else if(this.queryData.type==='teacher-library'||this.queryData.type==='tutor-library'){
        this.addLeave()
        // let param = {
        //   isTransfer: 1,
        //   ...this.listParams
        // }
        // param.status = 2
        // delete param.staffTypeCode
        // urlForPost('/teacher/getTeacherWarehouse',param).then(res => {
        //   if(f==='onLoad'){
        //     this.state.loading = false;
        //     if(res.data.data.list.length === 0 || this.testData.length && (this.testData.length >= res.data.data.total)){
        //       this.state.finished = true
        //     }
        //     let flag = false
        //     this.testData.forEach(item => {
        //       res.data.data.list.forEach(ite => {
        //         if(item.id === ite.id){
        //           flag = true
        //         }
        //       })
        //     })
        //     if(flag){
        //       this.testData = [...this.testData]
        //     }else{
        //       this.testData = [...this.testData,...res.data.data.list];
        //     }
        //
        //   }else{
        //     this.testData = [...res.data.data.list];
        //   }
        // })
      }
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
    // 获取科室信息
    transferGet() {
      urlForPost('/student/listSectionsForPage',this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },
    // 获取批次
    getBatch(){
      urlForPost('/backboneTraining/getBatchByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option3 = arr
      }).catch(()=>{})
    },

    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.onRefresh()
    },

    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    // 判断是否有正在审核的申请
    addLeave() {
      if(this.isLibrary){
        sessionStorage.setItem('isLibrary', 1)
      }else {
        sessionStorage.setItem('isLibrary', '')
      }
      this.$router.push({
        path: '/teachers-add'
      })
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    delFn(data) {
      delThreemonthcheck({
        id: data.id
      }).then(() => {
        this.$toast.success('操作成功!')
        this.onRefresh() // 获取申请列表
      })
    },
    upFn(data) {
      sessionStorage.setItem('isLibrary', '')
      this.$router.push({
        name: '带教老师申请',
        params:data
      })
    },
    upSub(data){
      Dialog.confirm({
        message: '确认提交么?'
      }).then(()=>{
        urlForPost('/teacher/teacherStartProcess',data).then(() => {
          this.onRefresh()
        })
      })
    },
    reSub(data){
      Dialog.confirm({
        message: '确认撤销么?'
      }).then(()=>{
        urlForPost('/teacher/updateTeacher',{
          id: data.id,
          status: 0
        }).then(() => {
          this.onRefresh()
        })
      })
    },
    goProcess(data) {
      // this.$router.push({
      //   path: '/teachers-process',
      //   query: data
      // })
      this.$router.push({
        path: '/teachers-process',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.testData = [];
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    operation(data, ac, flag){
      Dialog.confirm({
        message: '确认此操作么?'
      }).then(() => {
        let parma = {
          id: data.id,
          teacherId: data.id,
          activeStatus: ac
        }
        let tParma = {
          id: data.id,
          // typeCode: 'tutor'
        }
        urlForPost(flag?'/teacher/joinToTeacherOrTutor':'/teacher/updateStatus', flag ? parma : tParma).then(() => {
          this.$toast.success({
            message: '操作成功!',
            duration: 2000,
            onClose:()=>{
              this.onRefresh()
            }
          })
        })
      })
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    if(!this.queryData.type){
      this.$router.replace('/teachers-check')
    }
    sessionStorage.setItem('typeCode', 'teacher')
    if(this.queryData.type && this.queryData.type.indexOf('tutor')!==-1){
      // this.listParams.typeCode = 'tutor'
      this.listParams.staffTypeCode = 'TrainingEvidence'
      this.isTutor = true
      this.name = '进修导师'
      sessionStorage.setItem('typeCode', 'tutor')
    }
    if(this.queryData.type && this.queryData.type.indexOf('library')!==-1){
      this.$set(this,'isLibrary',true)
    }
    // this.getYear()
    this.transferGet() // 获取科室数据
    // this.getBatch() // 获取批次数据
  },
}
</script>
