<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <!-- <template #right v-if="role !== 'StudentType_jxs'">
          <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">我的</span>
          <span v-if="isMine" style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>
      </template> -->
    </van-nav-bar>
    <div>
      <van-tabs color="#17d4b5" @click="checkType">
        <van-tab v-for="type in listProgress" :title="type.title" :key="type.title">
        </van-tab>
      </van-tabs>
    </div>
    <div
        style="border-left: 4px solid #17d4b5; font-size: 14px; font-weight: bold; margin: 20px 12px; text-align: left; padding-left: 4px">
      {{ titleName }}
    </div>
    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='基本信息'">
      <van-cell-group>
        <van-cell title="头像">
          <template #default>
            <div style="width: 90%;min-height: 50px">
              <van-image :src="currentData.img" alt="头像"></van-image>
            </div>
          </template>
        </van-cell>
        <van-cell title="申请人:" :value="currentData['staffName'] || '无'"/>
        <van-cell title="性别:" :value="cardData['genderName'] || '无'"/>
        <van-cell title="民族:" :value="cardData['nationName'] || '无'"/>
        <van-cell v-if="identityData['birthday']" title="出生日期:" :value="identityData['birthday'].substring(0,10) || '无'"/>
        <van-cell title="职称:" :value="identityData['titleName'] || '无'"/>
        <van-cell title="职务:" :value="identityData['positionName'] || '无'"/>
        <van-cell title="健康状况:" :value="cardData['healthName'] || '无'"/>
        <van-cell title="政治面貌:" :value="cardData['policyName'] || '无'"/>
        <van-cell title="证件号:" :value="currentData['identifyNo'] || '无'"/>
        <van-cell title="籍贯(省):" :value="cardData['provinceName'] || '无'"/>
        <van-cell title="籍贯(市):" :value="cardData['cityName'] || '无'"/>
        <van-cell title="是否需要住宿:" :value="!batchData['lodgmentFlag']?'否':'是'"/>
        <van-cell title="工作服尺寸:" :value="batchData['clothesSize'] || '无'"/>
        <van-cell title="鞋码:" :value="batchData['shoeSize'] || '无'"/>

      </van-cell-group>
    </div>

    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='联系方式'">
      <van-cell-group>
        <van-cell title="手机号码:" :value="identityData['mobile'] || '无'"/>
        <van-cell title="电子邮箱:" :value="identityData['email'] || '无'"/>
        <van-cell title="qq号码:" :value="identityData['qq'] || '无'"/>
        <van-cell title="微信号:" :value="identityData['wechat'] || '无'"/>
        <van-cell title="紧急联系人:" :value="identityData['contactName'] || '无'"/>
        <van-cell title="紧急联系人电话:" :value="identityData['contactPhone'] || '无'"/>
        <van-cell title="家庭住址:" :value="identityData['homeAddress'] || '无'"/>
        <van-cell title="家庭电话:" :value="identityData['homePhone'] || '无'"/>
      </van-cell-group>
    </div>

    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='进修科室和专业'">
      <van-cell-group>
        <van-cell title="进修科室:" :value="currentData['sectionName'] || '无'"/>
        <van-cell title="进修专业:" :value="currentData['majorName'] || '无'"/>
        <van-cell v-if="batchData['tutorName']" title="导师:" :value="batchData['tutorName'] || '无'"/>
        <van-cell title="进修期限:" :value="(currentData['months'] || '0')+'个月'"/>
        <van-cell title="进修费:" :value="(currentData['advancedFee'] || '0')+'元'"/>
      </van-cell-group>
    </div>
    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='执业资格证书'">
      <van-cell-group>
        <van-cell v-if="certificateData['code']" title="资格证书编码:" :value="certificateData['code'] || '无'"/>
        <van-cell v-if="certificateData['certificateDate']" title="资格证书签发时间:" :value="certificateData['certificateDate'].substring(0,10) || '无'"/>
        <van-cell v-if="certificateData['attachScore']" title="执业证书编码:" :value="(certificateData['attachScore'] || '无')"/>
        <van-cell v-if="certificateData['passDate']" title="执业证书签发时间:" :value="certificateData['passDate'].substring(0,10) || '无'"/>
        <van-cell v-if="certificateData['categoryName']" title="执业证类别:" :value="certificateData['categoryName'] || '无'"/>
        <van-cell v-if="certificateData['practiceRangeName']" title="执业证范围:" :value="certificateData['practiceRangeName'] || '无'"/>
        <van-cell v-if="fileObj['Credentials'].length!==0" title="资格证书附件">
          <template #default>
            <div style="width: 90%;min-height: 50px">
              <van-image v-for="item in fileObj['Credentials']" :key="item.id" :src="item.path" alt="资格证书附件"></van-image>
            </div>
          </template>
        </van-cell>
        <van-cell v-if="fileObj['PracticeCertificate'].length!==0" title="执业证书附件">
          <template #default>
            <div style="width: 90%;min-height: 50px">
              <van-image v-for="item in fileObj['PracticeCertificate']" :key="item.id" :src="item.path" alt="执业证书附件"></van-image>
            </div>
          </template>
        </van-cell>
        <van-cell v-if="fileObj['GraduationCertificate'].length!==0" title="毕业证书附件">
          <template #default>
            <div style="width: 90%;min-height: 50px">
              <van-image v-for="item in fileObj['GraduationCertificate']" :key="item.id" :src="item.path" alt="毕业证书附件"></van-image>
            </div>
          </template>
        </van-cell>

        <van-cell v-if="fileObj['IdentityCard'].length!==0" title="身份证附件">
          <template #default>
            <div style="width: 90%;min-height: 50px">
              <van-image v-for="item in fileObj['IdentityCard']" :key="item.id" :src="item.path" alt="身份证附件"></van-image>
            </div>
          </template>
        </van-cell>
      </van-cell-group>
    </div>
    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='学历信息'">
      <div style="background: #f6f6f6; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
           v-for="data in educationData" :key="data.title"
      >
        <van-divider/>
        <div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学校名称：</div>
            <div>{{data['school']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学历：</div>
            <div>{{data['academicName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学位：</div>
            <div>{{data['degreeName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">所学专业:</div>
            <div>{{data.subject || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学制:</div>
            <div>{{data['schoolYears']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">开始日期:</div>
            <div>{{data.startDate && data.startDate.substring(0,10) || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">结束日期:</div>
            <div>{{data.endDate && data.endDate.substring(0,10) || '无'}}</div>
          </div>
        </div>

      </div>
    </div>
    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='工作经历'">
      <div style="background: #f6f6f6; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
           v-for="data in workData" :key="data.title"
      >
        <van-divider/>
        <div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">工作单位：</div>
            <div>{{data['unitName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">职务/职位：</div>
            <div>{{data.position || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">科室：</div>
            <div>{{data.sectionName || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">开始日期:</div>
            <div>{{data.startDate && data.startDate.substring(0,10) || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;" v-if="data.endDate">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">结束日期:</div>
            <div>{{data.endDate.length>2? data.endDate.substring(0,10) : data.endDate}}</div>
          </div>
        </div>

      </div>
    </div>
    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='选送单位信息'">
      <van-cell-group>

        <van-cell title="单位:" :value="unitData['unitName'] || '无'"/>
        <van-cell title="单位地址:" :value="unitData['address'] || '无'"/>
        <van-cell title="邮编:" :value="unitData['postcode'] || '无'"/>
        <!--        <van-cell title="出生日期:" :value="unitData['birthday'].substring(0,10) || '无'"/>-->
        <van-cell title="单位等级:" :value="unitData['levelName']+unitData['gradeName'] || '无'"/>
        <van-cell title="所在省:" :value="unitData['provinceName'] || '无'"/>
        <van-cell title="所在市:" :value="unitData['cityName'] || '无'"/>
        <van-cell title="单位主管部门:" :value="unitData['deptName'] || '无'"/>
        <van-cell title="主管部门电话:" :value="unitData['deptPhone'] || '无'"/>
        <van-cell title="是否医联体医院:" :value="unitData['unionFlag']?'是':'否'"/>
        <van-cell title="开票单位名称:" :value="batchData['billingUnit'] || '无'"/>
        <van-cell title="开票单位统一信用代码:" :value="batchData['taxNo'] || '无'"/>
<!--        <van-cell v-if="fileObj['Credentials'].length!==0" title="发票附件">-->
<!--          <template #default>-->
<!--            <div style="width: 90%;min-height: 50px">-->
<!--              <van-image v-for="item in fileObj['Credentials']" :key="item.id" :src="item.path" alt="发票附件"></van-image>-->
<!--            </div>-->
<!--          </template>-->
<!--        </van-cell>-->
      </van-cell-group>
    </div>
    <div style="position: relative; margin-bottom: 12px;" v-if="titleName==='进修申请表'">
      <van-cell-group>
        <van-cell v-if="fileObj['ApplicationForm'].length!==0" title="申请表附件">
          <template #default>
            <div style="width: 90%;min-height: 50px">
              <van-image v-for="item in fileObj['ApplicationForm']" :key="item.id" :src="item.path" alt="申请表附件"></van-image>
            </div>
          </template>
        </van-cell>
      </van-cell-group>
    </div>
  </div>
</template>

<script>
import {memberCreate, memberDetail, getStaffByIdentifyNo, urlForPost, getCertificatesByStaff, getCertificate} from '../http/apiMap';

export default {
  name: "study.vue",
  data() {
    return {
      url: {
        list: '/advancedsignup/listEduBackgroudByPage',
        workList: '/advancedsignup/getWorkByStaff',
        tutorList: '/advancedsignup/tutorList',
        batch: '/advancedsignup/getBatchListByPage',
        info: '/advancedsignup/getDetailById',
        staffBatch: '/advancedsignup/getByBatchAndStaff',
        cardInfo: '/advancedsignup/getInfoByBatchIdAndStaffId',
        batchId: '/advancedsignup/queryRecord',
        unit: '/advancedsignup/listAdvancedUnitByPage'
      },
      value: '',
      listParams: {
        pageSize: 999,
        pageNum: 1,
        type: 'selectCourse',
        courseType: '',
        name: ''
      },
      list: [],
      typeList: [],
      studyParam: {
        courseId: '',
        userId: localStorage.getItem('userId')
      },
      listProgress: [
        {title: '基本信息'},
        {title: '联系方式'},
        {title: '进修科室和专业'},
        {title: '执业资格证书'},
        {title: '学历信息'},
        {title: '工作经历'},
        {title: '选送单位信息'},
        {title: '进修申请表'},
        // {title: '报到须知'},
      ],
      name: '报名详情',
      titleName: '基本信息',
      currentData: {},
      identityData: {},
      cardData: {},
      batchData: {},
      certificateData: {},
      educationData: {},
      workData: {},
      unitData: {},
      fileObj: {
        Credentials: [],
        PracticeCertificate: [],
        GraduationCertificate: [],
        IdentityCard: [],
        ApplicationForm: []
      },
    }
  },
  methods: {
    getCourseList() {
      // courseList(this.listParams).then(res => {
      //     this.list = res.data.list
      // })
    },
    getCourseTypeList() {
      // courseTypeList({
      //     pageSize: 999,
      //     pageNum: 1
      // }).then(res => {
      //     this.typeList = [{id:'',name:'全部'},...res.data.list]
      // })
    },
    checkType(data) {
      this.titleName = this.listProgress[data].title
      this.getCourseList()
    },
    startStudy(data) {
      this.studyParam.courseId = data.id
      memberDetail(this.studyParam).then(res => {
        this.memberData = res.data.data
        // !this.memberData || this.memberData.length === 0
        if (!this.memberData) { // 未报名
          this.$dialog.confirm({
            title: '温馨提示:',
            message: '需要报名后才学习!',
            cancelButtonText: '报名'
          }).then(() => {
            this.memberCreateFn()
          }).catch(()=>{})
        } else {
          this.$router.push({
            path: '/study-detail',
            query: data
          })
        }
      })
    },
    // 报名
    memberCreateFn() {
      memberCreate({
        courseId: this.data.id
      }).then(res => {
        this.$toast.fail(res.data.msg)
      })
    },
    getStaffByIdentifyNoFn() {
      getStaffByIdentifyNo(this.currentData.identifyNo).then(res => {
        if(res.data&&res.data.data){
          this.identityData = {...res.data.data[0]}
        }
      })
      urlForPost(this.url.cardInfo, {
        "staffId": this.currentData.staffId,
        "batchId": this.currentData.batchId
      }).then(res => {
        if(res.data&&res.data.data){
          this.cardData = {...res.data.data}
        }
      })
      urlForPost(this.url.staffBatch, {
        "staffId": this.currentData.staffId,
        "batchId": this.currentData.batchId
      }).then(res => {
        if(res.data&&res.data.data){
          this.batchData = {...res.data.data}
          this.getUnit() // 获取单位信息
        }
      })
    },
    getCertificatesByStaffFn(){
      let param = {
        hospitalId: this.currentData.hospitalId,
        staffId: this.currentData.staffId
      }
      getCertificatesByStaff(param).then(res => {
        if(res.data&&res.data.data){
          this.certificateData = res.data.data
        }
      })
    },
    getCertificateFn(){
      let param = {
        "signupId": this.currentData.id,
        "typeCode": '',
        "pageSize": 999,
        "pageNum": 1
      }
      getCertificate(param).then(res => {
        let Credentials = []
        let PracticeCertificate = []
        let GraduationCertificate = []
        let IdentityCard = []
        let ApplicationForm = []
        let data = res.data.list
        data.forEach(r => {
          if (r.typeCode === 'Credentials') { //资格证书
            Credentials.push(r)
            this.$set(this.fileObj,'Credentials',[...Credentials])
          }
          else if (r.typeCode === 'PracticeCertificate') { //执业证书
            PracticeCertificate.push(r)
            this.$set(this.fileObj,'PracticeCertificate',[...PracticeCertificate])
          }
          else if (r.typeCode === 'GraduationCertificate') { //毕业证书
            GraduationCertificate.push(r)
            this.$set(this.fileObj,'GraduationCertificate',[...GraduationCertificate])
          }
          else if (r.typeCode === 'IdentityCard') { //身份证
            IdentityCard.push(r)
            this.$set(this.fileObj,'IdentityCard',[...IdentityCard])
          }
          else if (r.typeCode === 'ApplicationForm') { //身份证
            ApplicationForm.push(r)
            this.$set(this.fileObj,'ApplicationForm',[...ApplicationForm])
          }
        })
      })
    },
    getEducation(){
      let param = {
        staffId: this.currentData.staffId,
        pageSize: 999,
        pageNum: 1,
        dateDesc: true
      }
      urlForPost(this.url.list,param).then(res => {
        this.educationData = res.data.list
      })
    },
    getWork(){
      let param = {
        staffId: this.currentData.staffId,
        pageSize: 999,
        pageNum: 1
      }
      urlForPost(this.url.workList,param).then(res => {
        this.workData = res.data.list
      })
    },
    getUnit(){
      let param = {
        id: this.batchData.fromUnitId,
        pageSize: 999,
        pageNum: 1
      }
      urlForPost(this.url.unit,param).then(res => {
        this.unitData = res.data.list[0]
      })
    }
  },
  mounted() {
    const data = {...this.$route.query}
    this.$set(this, 'currentData', data)
    this.getCourseList() // 获取列表
    this.getCourseTypeList() // 获取分类
    this.getStaffByIdentifyNoFn() // 获取学员信息
    this.getCertificatesByStaffFn() // 获取证书信息
    this.getCertificateFn() // 获取证书附件
    this.getEducation() // 获取学历信息
    this.getWork() // 获取工作信息
  }
}
</script>

<style scoped>

</style>
