<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 4px 16px;font-size: 16px;">
      请选择角色:
    </div>
    <van-radio-group v-model="radio">
      <van-cell-group>
        <van-cell v-for="item in roleList" :key="item.id" :title="item.name" clickable @click="checkRadio(item)">
          <template #right-icon>
            <van-radio :name="item.code" />
          </template>
        </van-cell>
      </van-cell-group>
    </van-radio-group>
  </div>
</template>
<script>

    import { getMyRoles, changeRole } from '../http/apiMap';
  export default {
      name: 'we-role',
      data(){
          return{
              radio: '1',
              role: '',
              roleList: []
          }
      },
      computed:{
          name(){
              return this.$route.name
          },
      },
      methods:{
          checkRadio(data){
              this.radio = data.code
              localStorage.setItem('roleCode',data.code)
              localStorage.setItem('roleName',data.name)
              sessionStorage.setItem('roleId',data.id)
              changeRole(data.id).then(res => {
                  this.$toast.fail(res.data.msg)
                  localStorage.setItem('token',res.data.data)
                  this.$router.replace('/home')
              })
          }
      },
      mounted() {
          getMyRoles().then(res => {
              this.roleList = res.data.data
              this.radio = localStorage.getItem('roleCode')
              let login = this.$route.query.isLogin || ''
              if(login==='login' && this.roleList.length === 1){
                  this.$router.replace('/home')
              }
          })
      }
  }
</script>