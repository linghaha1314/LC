<template>
    <div>
        课程页面
    </div>
</template>