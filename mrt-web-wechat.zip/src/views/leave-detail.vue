<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="请假状态">
          <template #default>
            <div v-if="currentData.status===2" style="color: #17D4B5">
              请假已通过
            </div>
            <div v-if="currentData.status===11" style="color: #1a1aff">
              审核中
            </div>
            <div v-if="currentData.status===1" style="color: #ff3333">
              已驳回
            </div>
          </template>
        </van-cell>
        <van-cell title="请假类型" :value="currentData.typeName" />
        <van-cell title="请假天数" :value="currentData.days+'天'" />
        <van-cell title="去向" :value="currentData.destination" />
        <!--        <van-cell title="风险等级" :value="currentData.riskName" />-->
        <van-cell title="出行方式" :value="currentData.tripName" />
        <div style="display: flex;justify-content: space-between;width: 100%;padding: 0 12px 10px;box-sizing: border-box;font-size: 12px; margin-top: 10px;">
          <div style="color: #B0B0B0">
            申请时间:
          </div>
          <div style="color: #3E3E3E">
            {{currentData.created}}
          </div>
        </div>
        <div style="display: flex;justify-content: space-between;width: 100%;padding: 0 14px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            带教老师:
          </div>
          <div style="color: #3E3E3E">
            {{currentData.medicalTeamLeaderName || '无'}}
          </div>
        </div>
        <div style="display: flex;justify-content: space-between;width: 100%;padding: 0 14px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            理由:
          </div>
          <div style="color: #3E3E3E">
            {{currentData.reason}}
          </div>
        </div>
        <div style="display: flex;justify-content: space-between;width: 100%;padding: 0 14px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            开始时间:
          </div>
          <div style="color: #3E3E3E" v-if="currentData.startDate">
            {{currentData.startDate.substring(0,10)+' '+(currentData.startDate.substring(10).indexOf('13')>0?'下午':'上午')}}
          </div>
        </div>
        <div style="display: flex;justify-content: space-between;width: 100%;padding: 0 14px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            结束时间:
          </div>
          <div style="color: #3E3E3E" v-if="currentData.endDate">
            {{currentData.endDate.substring(0, 10)}}
          </div>
        </div>
        <div style="display: flex;justify-content: space-between;width: 100%;padding: 0 14px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            附件:
          </div>
          <div style="color: #3E3E3E">
            <template v-if="!currentData.attachPath && currentData.attachPath === ''">
              无
            </template>
            <template v-if="currentData.attachPath && currentData.attachPath !== ''">
              <div style="color: #17D4B5" @click="showImg(currentData)">
                点击查看附件
              </div>
            </template>
          </div>
        </div>
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <div style="margin: 16px;">
        <div>
          审批进度

        </div>
        <van-steps direction="vertical" :active="processNum">
          <van-step v-for="process in processData" :key="process.title">
            <div style="display: flex; align-items: center">
              <van-image
                  round
                  width="40px"
                  height="40px"
                  :src="process['avatar'] || 'https://img.yzcdn.cn/vant/cat.jpeg'"
              />
              <span style="margin: 0 16px; color: #3E3E3E; font-size: 14px">
                {{process['stepName'] || '无'}}: {{process.name || '无'}}
              </span>
              <div>
                <van-tag style="text-align: center" v-if="process['deleteReason']==='completed' && process.status === '1'" type="success">已通过</van-tag>
                <van-tag style="text-align: center" v-if="process['deleteReason'] !== 'completed'" type="warning">待审批</van-tag>
                <van-tag style="text-align: center" v-if="process['deleteReason']==='completed' && process.status !== '1'" type="danger">已拒绝</van-tag>
              </div>
            </div>
            <div>审核意见: {{process.opinion || '无'}}</div>
          </van-step>
        </van-steps>
      </div>
      <div style="margin: 16px;">
            当前审批人: {{msg}}
      </div>
      <div style="margin: 16px;" v-if="currentData.status===1">
        <van-button round block color="#17d4b5" @click="goToAdd">
          重新提交
        </van-button>
      </div>
    </van-form>
    <van-dialog v-model="show"
                confirmButtonColor="#17d4b5"
                title="查看附件"
                @confirm="show = false"
    >
      <div style="display: flex;justify-content: center;align-items: center;padding: 30px 0;min-height: 60px">
        <van-image :src="srcImg" alt="本地图片无法显示"/>
      </div>
    </van-dialog>
  </div>
</template>
<script>
    import {getFlowData} from '../http/apiMap'
    import { Dialog } from 'vant';
    export default {
        name: 'test',
        components: {
            [Dialog.Component.name]: Dialog.Component,
        },
        data(){
            return{
                formData:{
                    address: '',
                    peopleValue: '',
                    dateValue: '',
                    startValue: '',
                    endValue: '',
                    typeValue: '',
                    content: '',
                    remake: '',
                    uploader: [],
                    number: 1,
                    dateEnd: '',
                    isLeave: '1'
                },
                currentData: {},
                showPicker: false,
                showTypePicker: false,
                showDatePicker: false,
                showStartTimePicker: false,
                showEndTimePicker: false,

                action: 3,
                columns: ['王老师', '李老师', '刘老师'],
                minDate: new Date(),
                maxDate: new Date(2025, 10, 1),
                currentDate: new Date(),
                currentTime: '12:00',
                currentEndDate: '12:00',
                option1: [],
                host: window.location.host,
                processData: [],
                processNum: -1,
                srcImg: '',
                show: false,
                msg: '',
            }
        },
        computed:{
            name(){
                return this.$route.name
            },
            typeColumns(){
                let arr = []
                this.option1.map(item => {
                    arr.push(item.text)
                })
                return arr;
            },

        },
        methods:{
            onConfirm(value) {
                this.formData.peopleValue = value;
                this.showPicker = false;
            },

            onTypeConfirm(value) {
                this.formData.typeValue = value;
                this.showTypePicker = false;
            },

            onDateConfirm(value) {
                this.formData.dateValue = this.getNowFormatDate(value)
                this.showDatePicker = false;
            },
            // 开始时间
            onStartDateConfirm(value){
                this.formData.startValue = value
                this.showStartTimePicker = false;
            },
            // 结束时间
            onEndDateConfirm(value){
                this.formData.endValue = value
                this.showEndTimePicker = false;
            },
            // 时间格式
            getNowFormatDate(date) {
                let seperator1 = "-";
                let year = date.getFullYear();
                let month = date.getMonth() + 1;
                let strDate = date.getDate();
                if (month >= 1 && month <= 9) {
                    month = "0" + month;
                }
                if (strDate >= 0 && strDate <= 9) {
                    strDate = "0" + strDate;
                }
                return year + seperator1 + month + seperator1 + strDate;
            },
            goToAdd(){
              localStorage.setItem('currentData', JSON.stringify(this.currentData))
              this.$router.replace({
                  path: '/leave-add',
                  query: this.currentData
              })
            },
            // 获取审批进程
            getFlowDataFn(){
                let param = {
                    "processInstanceId": this.currentData.processInstanceId,
                    "businessId":this.currentData.id
                }
                getFlowData(param).then(res => {
                    this.msg = res.data.data;
                    this.processData = res.data.list
                    this.getActionNum();
                })
            },
            getActionNum(){
                for (let i = 0; i<this.processData.length;i++){
                    if(this.processData[i]["deleteReason"] === 'completed'){
                        this.processNum = i
                    }
                }
            },
            showImg(currentData){
                this.srcImg = currentData.attachPath
                this.show = true
            }
        },
        mounted() {
            let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
            this.currentData = currentForm;
            let len = Object.keys(currentForm).length
            if(len === 0){
                this.action = 3
            }else {
                this.action = currentForm.status
                this.formData = Object.assign(this.formData,currentForm)
            }
            localStorage.setItem('currentData', '')
            this.getFlowDataFn(); // 获取进程
        }
    }
</script>
