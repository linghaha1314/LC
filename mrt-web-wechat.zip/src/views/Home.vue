<template>
  <div class="home">
    <van-nav-bar :title="name">
      <template #left>
        <div style="font-size:10px;color: #17d4b5" @click="sao">
          <van-icon name="scan" color="#17d4b5" size="20"/>
        </div>
      </template>
      <template #right>
        <div style="font-size:10px;color: #17d4b5" @click="loginOut">
          退出
        </div>
      </template>
    </van-nav-bar>
    <router-view style="overflow: auto; padding-bottom: 60px"></router-view>
    <div>
      <van-tabbar v-model="active" route active-color="#17d4b5" @change="activeFn">
        <van-tabbar-item icon="wap-home" to="/home/index">首页</van-tabbar-item>
        <van-tabbar-item icon="video" to="/home/study">课程</van-tabbar-item>
<!--        @click="goMsg"-->
        <van-tabbar-item icon="chat" :badge="msgNum===0?null:msgNum" to="/home/message">消息
        </van-tabbar-item>
        <van-tabbar-item icon="manager" to="/home/we">我的</van-tabbar-item>
      </van-tabbar>
    </div>
  </div>
</template>

<script>
import {Dialog} from 'vant';
import wx from 'weixin-js-sdk';
import {getMyMessage, getSignWx} from '../http/apiMap';


export default {
  name: "home",
  data() {
    return {
      active: 0,
      msgNum: 0,
      msgInfo: {},
      toQuery: {
        path: '/home/message',
        query: this.msgInfo
      },
      name: this.$route.name,
      apiList: [
        'scanQRCode',
        'getLocation'
      ]
    }
  },
  computed: {},
  methods: {
    loginOut() {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认退出么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        localStorage.setItem('isLogin', '');
        localStorage.setItem('token', '');
        sessionStorage.clear()
        this.$router.replace({
          path: '/login'
        })
      })
    },
    goMsg() {
      this.$router.push({
        path: '/home/message',
        query: this.msgInfo
      })
    },
    activeFn(active) {
      this.name = ['首页', '课程', '消息', '我的'][active]
    },
    sao() {
      let url = location.href.split('#')[0]
      getSignWx(url).then(r => {
        let res = r.data
        wx.config({
          // debug: true,
          appId: res.appId,
          timestamp: res.timestamp,
          nonceStr: res["noncestr"],
          signature: res.signature,
          jsApiList: this.apiList
        })
        wx.ready(function (){
          wx.scanQRCode({
            // 默认为0，扫描结果由微信处理，1则直接返回扫描结果
            needResult: 1,
            desc: 'scanQRCode desc',
            success: (res) => {
              let codes = res.resultStr;
              if (codes.indexOf('/activities') > 0) {
                window.location.href = codes
              } else {
                this.$toast.fail('无效二维码!')
              }
            },
            fail: (err) => {
              alert(JSON.stringify(err))
              this.$toast.fail('扫描失败!')
            }
          });
        })
      })
    }

  },
  mounted() {
    let string = location.href
    let urlB = location.href.split('?')[0]
    if (string.indexOf('code=') !== -1 && string.indexOf('state=') !== -1) {
      location.href = urlB+'#/home/index'
    }
    getMyMessage().then(res => {
      let target = res.data.data
      if (target && target["sysNotify"] && target["sysInfo"]) {
        this.msgNum = target["sysNotify"].total + target["sysInfo"].total
      }
      this.msgInfo = res.data.data
    })
  }
};
</script>
