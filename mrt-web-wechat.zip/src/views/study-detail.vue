<template>
  <div class="about">
    <van-nav-bar title="课程详情" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
</van-nav-bar>
<div style="padding: 20px 12px;">
    <div style="font-size: 18px; margin-bottom: 12px;text-align: center;">
        {{data.name || '无'}}
    </div>
    <div style="color: #666; display: flex; flex-wrap: wrap;justify-content: space-around">
        <div style="margin: 6px;">老师: {{data.userName}}</div>
        <div style="margin: 6px;">最近学习人数 {{data['studyNum']}} 人</div>
        <div style="margin: 6px;">总数 {{data['memberCount']}} 人</div>
        <div style="margin: 6px;">课程时间 {{data.startDate}} 至 {{data.endDate}}</div>
    </div>
    <div style="padding: 20px 12px;text-align: justify; color: #333333" v-html="data.content"></div>
    <div style="display: flex;">
        <div style="padding: 4px 12px; display: flex; align-items: center; font-size: 16px;font-weight: bold; min-height: 28px">
            <span style="color: #17d4b5">
                    课程
                </span>目录
        </div>
    </div>
    <van-list>
        <van-cell v-for="item in data['studyList']" :key="item.id" :title="item.title" :value="item['studyed']?'已学'+item['studyed']+'%':'未学习'" @click="startCourse(item)" is-link />
    </van-list>
</div>
</div>
</template>
<script>
    import {
        courseDetail,
        addCourseWareStudyNum,
        processCreate
    } from '../http/apiMap';
    export default {
        name: 'study-detail',
        data() {
            return {
                msg: '',
                data: {},
                code: this.$route.query.code,
                isMore: true,
                studyParam: {
                    courseId: '',
                    userId: localStorage.getItem('userId')
                },
                memberData: []
            }
        },
        computed: {},
        methods: {

            getCourseDetail() {
                let courseId = this.$route.query.id
                courseDetail(courseId).then(res => {
                    this.data = res.data.data;
                })
            },
            // 学习
            startCourse(data) {
                this.studyParam.courseId = data.id
                addCourseWareStudyNum(data.id).then()
                processCreate({
                        courseId: this.$route.query.id,
                        chapterId: data.id,
                        minutes: 0,
                        completed: 0
                    }).then(res => {
                        data.reasonId = res.data["reasons"].data.id
                        this.$router.push({
                            path: '/study-play',
                            query: data
                        })
                    })
                    // this.getMember()
            },

            // 继续学习
            // continueStudy(){
            //
            // }
        },
        mounted() {
            this.getCourseDetail();
        }
    }
</script>