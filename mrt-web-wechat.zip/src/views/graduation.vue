<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <template #right v-if="role !== 'StudentType_jxs'">
          <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">查询审核</span>
          <span v-else style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>
      </template>
    </van-nav-bar>

    <div v-if="role !== 'StudentType_jxs'">
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item title="科室" v-model="listParams.sectionId" @change="onRefresh" :options="option2"/>
        <!--            <van-dropdown-item title="状态" v-model="listParams.status" @change="leaveListGet" :options="option3" />-->
        <batch-drop v-model="listParams.batchId" @change="onRefresh"></batch-drop>
      </van-dropdown-menu>
    </div>
    <div>
      <van-search v-model="listParams.name" shape="round" @change="leaveListGet" placeholder="搜索"/>
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
              {{ data.typeName }}
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">已通过</van-tag>
              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">已拒绝</van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交</van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===11" size="medium">审核中</van-tag>
            </div>
            <van-divider/>
            <div>
              <div style="margin-bottom: 10px">
                <div>申请人: {{ data.studentName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>时间: {{ data.created && data.created.substring(0, 10) }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>科室: {{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>专业: {{ data.majorName || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <van-button v-if="role !== 'StudentType_jxs' &&  data.status === 11 && !isMine" style="width: 50px; margin-right: 12px" type="warning"
                          size="mini" @click="goProcess(data)">去审核
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && data.status === 0" style="width: 50px; margin-right: 12px"
                          type="danger" size="mini" @click="delFn(data)">删除
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && (data.status === 0 || data.status === 1)"
                          style="width: 50px; margin-right: 12px" type="info" size="mini" @click="upFn(data)">提交
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && (data.status === 0 || data.status === 1)"
                          style="width: 50px; margin-right: 12px" type="primary" size="mini" @click="goDetail(data)">修改
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && data.status === 2"
                          style="width: 10em; margin-right: 12px" type="info" size="mini" @click="download(data)">下载结业鉴定
              </van-button>

              <van-button v-if="role === 'StudentType_jxs' && data.status === 2"
                          style="width: 10em; margin-right: 12px" type="primary" size="mini"
                          @click="downloadCertificate(data)"
                          :disabled="!(downFlag === '2'||downFlag === 2)">
                {{ downFlag === '2' || downFlag === 2 ? '下载结业证书' : '未发放结业证' }}
              </van-button>
              <router-link :to="{path:'/graduation-detail',query:data}">
                <van-button style="width: 50px; margin-right: 12px" type="primary"
                            size="mini">详情
                </van-button>
              </router-link>
              <router-link v-if="data.status === 11" :to="{path:'/approval-detail',query:data}">
                <van-button type="default" size="mini">查看审批进度</van-button>
              </router-link>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
      <div v-if="role === 'StudentType_jxs' && isLoad" style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getTransferSchedule,
  getStudentApplyList,
  getApplyInfo,
  delApply,
  upApplyProcess,
  applyProcessList,
  getStudentById,
  getStudentDetailDown
} from "../http/apiMap";
import BatchDrop from '../components/batch-drop'

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
    BatchDrop
  },
  data() {
    return {
      reason: '',
      show: false,
      listParams: {
        pageSize: 10,
        pageNum: 1,
        sectionId: '',
        studentId: '',
        name: '',
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option2: [],
      option3: [
        {text: '全部', value: null},
        {text: '已拒绝', value: 1},
        {text: '已通过', value: 2},
        {text: '审核中', value: 11},
      ],
      testData: [],
      role: '',
      isMine: true,
      notTarget: {},
      studentInfo: {},
      isSuccess: undefined,
      downFlag: '',
      isLoad: false,
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    goDetail(data) {
      this.$router.push({
        path: '/graduation-add',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      this.testData = [];
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    // 获取申请列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }
      if (this.role === 'StudentType_jxs' || this.isMine) {
        // this.getApplyInfoFn(()=>{
        //     // params.studentId = this.studentInfo.studentId
        //     // params.sectionId = this.studentInfo.sectionId

        // })
        getStudentApplyList(params).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if (res.data.rows.length === 0 || res.data.rows.length < this.listParams.pageSize) {
              this.state.finished = true
            }
            if (res.data.total === 0) {
              this.testData = []
            } else {
              this.testData = [...this.testData, ...res.data.rows];
            }
          } else {
            this.testData = [...res.data.rows];
          }
          // this.testData = [...res.data.rows]
          this.isLoad = true
          if (this.role === 'StudentType_jxs' && this.testData[0] && this.testData[0].status === 2) {
            this.getStudentDetailDownFn() // 查询是否发证
          }
        })
      } else {
        applyProcessList({
          ...this.listParams
        }).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if (res.data.list.length === 0 || res.data.list.length < this.listParams.pageSize) {
              this.state.finished = true
            }
            if (res.data.total === 0) {
              this.testData = []
            } else {
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      }
    },

    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },


    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.leaveListGet()
    },


    // 判断是否有正在审核的申请
    addLeave() {
      if (this.testData.length === 0) {
        this.$router.push({
          path: '/graduation-add'
        })
      } else {
        this.$toast.fail('请勿重复申请!')
      }
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    delFn(data) {
      delApply({
        id: data.id
      }).then(() => {
        this.$toast.success('操作成功!')
        this.leaveListGet() // 获取申请列表
      })
    },
    upFn(data) {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认提交么!',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        upApplyProcess(data).then(() => {
          this.$toast.success('操作成功!')
          this.leaveListGet() // 获取申请列表
        })
      }).catch(() => {
      })
    },
    goProcess(data) {

      this.$router.push({
        path: '/graduation-process',
        query: data
      })
    },
    download(data) {
      let {studentId, hospitalId} = data
      this.$router.push({
        path: '/download-page',
        query: {
          type: 'advancedgraduationTable',
          studentId,
          hospitalId
        }
      })
    },
    // 下载通知书
    downloadCertificate(data) {
      this.$router.push({
        path: '/download-page',
        query: {
          ...data,
          type: 'graduationCertificate'
        }
      })
    },
    getStudentDetailDownFn() {
      getStudentDetailDown({
        id: this.testData[0].studentId
      }).then(res => {
        if (res.data.success) {
          this.downFlag = res.data.data.status
        }
      })
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    if (this.role === 'StudentType_jxs') {
      getStudentById(localStorage.getItem('studentId')).then(res => {
        if (res.data && res.data.success) {
          this.isSuccess = res.data.data.status
        }
      })
    }
    this.transferGet() // 获取科室数据
  },

}
</script>
