<template>
  <div style="text-align: center; padding-top: 30px">
    <img style="height:50px; margin-bottom: 30px" src="../assets/img/logo.png" alt="风景照">
    <div class="title">进修教育信息化管理平台</div>
    <!--    <div class="sub-title mb20">贵医大进修</div>-->
    <div style="text-align: center; color: orangered;margin: 12px;"> {{msg}} </div>
    <van-form @submit="onSubmit">
      <van-field
          v-model="loginInfo.username"
          name="username"
          label="账号"
          placeholder="请输入账号"
          :rules="[{ required: true, message: '必须填写账号' }]"
      />
      <van-field
          v-model="loginInfo.password"
          type="password"
          name="password"
          label="密码"
          placeholder="请输入密码"
          :rules="[{ required: true, message: '必须填写密码' }]"
      />
      <div style="margin: 16px;display: flex;justify-content: center;flex-wrap: wrap">
        <van-button style="margin-bottom: 12px;width: 343px;height: 44px" round block type="primary" native-type="submit">登录</van-button>
      </div>
    </van-form>
<!--    <div style="text-align: center;padding: 12px;display: flex;justify-content: center;flex-wrap: wrap">-->
<!--      <van-button style="margin-bottom: 12px;width: 343px;height: 44px" round block type="primary" size="small" to="/warning">在线报名</van-button>-->
<!--      <van-button style="margin-bottom: 12px;width: 343px;height: 44px" round block type="primary" size="small" @click="show = true">进度查询</van-button>-->
<!--    </div>-->
    <van-popup v-model="show" style="width: 100vw;height: 50vh; padding: 30px 0;">
      <div>
        <div style="font-size: 20px; font-weight: bold; color: #333333; margin-bottom: 24px;">进度查询</div>
        <van-field
            v-model="idCard"
            name="username"
            label="身份证"
            placeholder="请输入身份证"
            required
            :rules="[{ pattern:pattern, message: '必须填写身份证' }]"
        />
        <div style="margin: 16px;">
          <van-button round block type="primary" @click="query">查询</van-button>
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script>
import {getLogin, urlForPost} from '../http/apiMap.js'

export default {
  data() {
    return {
      url: {
        info: '/advancedsignup/queryProgressInfo'
      },
      loginInfo: {
        username: '',
        password: '',
        code: ''
      },
      show: false,
      idCard: '',
      appid: 'wx71a4dbf5272399a0',
      secret: '044f7c1f60486126ceda34655e294922',
      msg: '',
      pattern: /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/
    };
  },
  methods: {
    onSubmit(values) {
      this.$toast.loading({
        message: '正在登录...',
        forbidClick: true,
        duration: 0
      });
      Object.assign(this.loginInfo, values)
      getLogin(this.loginInfo).then((res) => {
        if (res.data.success) {
          localStorage.setItem('token', res.data.data)
          localStorage.setItem('staffId', res.data.staffId)
          localStorage.setItem('roleCode', res.data["roleCode"])
          localStorage.setItem('currentSectionId', res.data.currentSectionId || res.data.sectionId)
          localStorage.setItem('userId', res.data.userId)
          localStorage.setItem('roleName', res.data.roleName)
          localStorage.setItem('staffName', res.data["staffName"])
          localStorage.setItem('studentId', res.data.studentId)
          localStorage.setItem('admissionFlag', res.data["admissionFlag"])
          localStorage.setItem('signType', res.data.signType)
          sessionStorage.setItem('WxData', JSON.stringify(res.data["WxData"]))

          if (res.data["constraintFlag"] === false) {
            let scan = sessionStorage.getItem('scan') || ''; // 是否是扫描过来的
            localStorage.setItem('isLogin', '1') // 存储登录标识
            localStorage.setItem('constraintFlag', res.data["constraintFlag"]) // 存储登录标识
            this.$toast.clear()
            if (scan === '1') {
              sessionStorage.setItem('scan', '')
              this.$router.replace({
                path: '/activities-sign'
              })
            } else if (scan === '2') {
              sessionStorage.setItem('scan', '')
              this.$router.replace({
                path: '/activities-sign?type=1'
              })
            } else {
              this.$router.push({
                path: '/we-role',
                query: {
                  isLogin: 'login'
                }
              })
            }
          } else {
            localStorage.setItem('isLogin', '1') // 存储登录标识
            this.$router.replace({
              path: '/we-changePassword',
              // path:'/we-role',
              query: {
                isLogin: 'login'
              }
            })
          }
        } else {
          this.$toast.fail(res.data.msg);
        }
      }).catch(() => {
        this.$router.push('/login')
      })
    },
    query() {
      if (this.idCard === '') {
        this.$toast.fail('身份证不能为空哦!')
      } else {
        // 开始查询
        this.gerProgress()
      }
    },
    gerProgress() {
      sessionStorage.setItem('identifyNo', this.idCard)
      urlForPost(this.url.info, {
        identifyNo: this.idCard
      }).then(res => {
        if (!res.data.data) {
          this.$toast.fail('您还未进行报名哦!')
        } else {
          this.show = false
          let info = res.data.data
          let signInfo = {
            id: info.batchId,
            hospitalId: info.hospitalId,
            projectId: info.projectId || '',
            trainTypeCode: info.trainTypeCode
          }
          localStorage.setItem('signInfo', JSON.stringify(signInfo))
          localStorage.setItem('progressInfo', JSON.stringify(info))
          this.$router.push({
            path: '/sign-progress',
            query: {
              identifyNo: this.idCard,
              data: res.data.data
            }
          })
        }
      })
    },
    getQueryString(name) {
      let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
      let r = window.location.search.substr(1).match(reg);
      if (r != null) return unescape(r[2]);
      return null;
    }
  },
  created() {
    let code = this.getQueryString('code')
    if (!code) {
      // let urlB = location.href.split('#')[0]
      // let url = encodeURI(urlB)
      // let param = 123
      // location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${this.appid}&redirect_uri=${url}&response_type=code&scope=snsapi_base&state=${param}#wechat_redirect`
    }else{
      this.loginInfo.code = code
    }
  }
};
</script>
<style lang="less">
.title {
  font-size: 20px;
}

.sub-title {
  font-size: 16px;
  color: rgb(203, 203, 203)
}

.mb20 {
  margin-bottom: 20px;
}
</style>
