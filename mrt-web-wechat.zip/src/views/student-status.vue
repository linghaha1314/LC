<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <!--            <template #right v-if="role !== 'StudentType_jxs'">-->
      <!--                <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">我的</span>-->
      <!--                <span v-else style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>-->
      <!--            </template>-->
    </van-nav-bar>

    <div v-if="role !== 'StudentType_jxs'">
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item title="年度" v-model="listParams['searchMonth']" @change="leaveListGet" :options="option1"/>
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.sectionId" @change="sectionChange" :options="option2"/>
        <van-dropdown-item title="专业" v-model="listParams.majorId" @change="leaveListGet" :options="majorOption" />
        <van-dropdown-item title="批次" v-model="listParams.batchId" @change="leaveListGet" :options="option3"/>
        <van-dropdown-item title="状态" v-model="listParams.status" @change="leaveListGet" :options="option4"/>
        <van-dropdown-item title="期限" v-model="listParams.months" @change="leaveListGet" :options="monthsOption"/>
      </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <div v-if="role !== 'StudentType_jxs'">
        <van-search v-model="listParams.name" shape="round" @change="searchLeaveListGet" placeholder="搜索" />
      </div>
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.id">
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
              {{ data.studentName }}
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">
                已结业
              </van-tag>
              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">提前结业
              </van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">
                在训
              </van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===3" size="medium">
                结业中
              </van-tag>
            </div>
            <van-divider/>
            <div>
              <div style="margin-bottom: 10px">
                <div>年度: {{ data['startYear'] || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>科室: {{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>专业: {{ data.majorName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>批次: {{ data['kbabatchName'] || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>期限: {{ data['periodName'] || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">

              <van-button
                          style="width: 10em; margin-right: 12px" type="info" size="mini" @click="download(data)">学籍信息表
              </van-button>
              <keep-alive>
                <router-link :to="{path:'/student-status-detail',query:data}">
                  <van-button style="width: 4em;" type="primary"
                              size="mini">详情
                  </van-button>
                </router-link>
              </keep-alive>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
<!--      <div v-if="role === 'StudentType_jxs'" style="position: fixed;right: 26px;bottom: 60px">-->
<!--        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>-->
<!--      </div>-->
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  studentsStatusList,
  getLeaveApprovalProcess,
  getLeaveVerification,
  getApplyInfo,
  delThreemonthcheck,
  urlForPost,
  threemonthProcess,
  urlForGetCode,
  urlForGet
} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      reason: '',
      show: false,
      listParams: {
        pageSize: 10,
        pageNum: 1,
        sectionId: '',
        studentId: '',
        type: '进修生'
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option1: [],
      option2: [],
      option3: [],
      option4:[
        {text: '全部', value: null},
        {text: '提前结业', value: 1},
        {text: '已结业', value: 2},
        {text: '在训', value: 0},
        // {text: '结业中', value: 3}
      ],
      majorOption: [],
      monthsOption: [],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      studentInfo: {},
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      isLoading: false,
      count: 0
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // goDetail(data) {
    //   if (this.role === 'StudentType_jxs') {
    //     // localStorage.setItem('currentData', JSON.stringify(data))
    //     this.$router.push({
    //       path: '/three-mouths-add',
    //       query: data
    //     })
    //   }
    // },
    searchLeaveListGet(){
      this.listParams.pageNum = 1
      this.leaveListGet()
    },
    // 获取申请列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }
      studentsStatusList(params).then(res => {
        if (f === 'onLoad') {
          this.state.loading = false;
          if (res.data.data.list.length === 0 || res.data.data.list.length<this.listParams.pageSize) {
            this.state.finished = true
          }
          this.testData = [...this.testData,...res.data.data.list]
        } else {
          this.testData = [...res.data.data.list];
        }
      })
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
    // 获取科室信息
    transferGet() {
      urlForPost('/student/listSectionsForPage',this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },
    // 获取批次
    getBatch(){
      urlForPost('/backboneTraining/getBatchByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option3 = arr
      }).catch(()=>{})
    },
    // 审批
    throughFn(num) {
      let target = {}
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          target = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选申请信息!')
      } else {
        let msg = '';
        getLeaveVerification({
          "studentId": target.studentId
        }).then(res => {
          let data = res.data.data
          msg = num === 1 ? `${data.studentName}在本次进修期间剩余申请天数为${data["maxLeaveDays"] - data["totalDays"]}天,确认要同意他的申请申请吗？` : '确认拒绝申请么?'
          Dialog.confirm({
            title: '温馨提示:',
            message: msg,
            confirmButtonColor: '#17d4b5'
          }).then(() => {
            this.getApprove(num, target)
          }).catch(() => {
          })
        })
      }
    },
    // 点击不通过
    notThrough() {
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          this.notTarget = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选申请信息!')
      } else {
        this.show = true;
      }
    },
    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.leaveListGet()
    },
    // 通过审批
    getApprove(num, target) {
      let param = {
        "opinion": num === 1 ? "同意" : this.reason,
        "processInstanceId": target.processInstanceId,
        "projectId": target.id,
        "retryStatus": 0,
        "status": num,
        "taskId": target.taskId,
      }
      getLeaveApprovalProcess(param).then(res => {
        this.$toast.success(res.data.msg)
        this.leaveListGet();
      })
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    // 判断是否有正在审核的申请
    addLeave() {
      if (this.testData.length === 0) {
        let student = localStorage.getItem('studentId')
        urlForGetCode('/student/getById', student).then(res => {
          if (res.data.success) {
            let data = res.data.data
            if (data['checkStatus'] === 1) {
              this.$router.push({
                path: '/three-mouths-add'
              })
            } else {
              this.$toast.fail('您未在入科三个月考核名单中！')
            }
          }

        })
      } else {
        this.$toast.fail('不能重复申请哦!')
      }
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    delFn(data) {
      delThreemonthcheck({
        id: data.id
      }).then(() => {
        this.$toast.success('操作成功!')
        this.leaveListGet() // 获取申请列表
      })
    },
    upFn(data) {
      threemonthProcess(data).then(() => {
        this.$toast.success('操作成功!')
        this.leaveListGet() // 获取申请列表
      })
    },
    goProcess(data) {

      this.$router.push({
        path: '/three-mouths-process',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    download(data){
      let {student,hospitalId,staffId,advancedMajorId,kbabatchId,status} = data
      this.$router.push({
        path: '/download-page',
        query: {
          type: status === 2 ? 'studentInfoFormBy2' : 'studentInfoForm',
          studentId: student.id,
          staffId,
          hospitalId,
          advancedMajorId,
          kbabatchId
        }
      })
    },
    // 获取专业
    getListMajor(){
      urlForPost('/submajor/getListQueryByPage',{
        pageSize: 999,
        sectionId: this.listParams.sectionId,
        pageNum: 1
      }).then(res => {
        let optionArr = [
          { text: '全部', value: '' }
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.sectionName+' - '+item.name,
            value: item.id,
            ...item
          }
          optionArr.push(obj)
        })
        this.majorOption = [...optionArr]
      })
    },
    sectionChange(){
      this.getListMajor()
      this.leaveListGet()
    },
    getPeriodMonthsFn(){
      urlForPost('/student/getPeriodMonths',{
        pageNum: 1,
        pageSize: 999
      }).then(res => {
        let optionArr = [
          { text: '全部', value: '' }
        ]
        res.data.data.list.forEach(item => {
          let obj = {
            text: item.months,
            value: item.months
          }
          optionArr.push(obj)
        })
        this.monthsOption = [...optionArr]
      })
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    this.getYear()
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.transferGet() // 获取科室数据
    this.getBatch() // 获取批次数据
    this.getPeriodMonthsFn() // 获取期限
    if(this.role === 'sectionManager'){
      urlForGet('/student/getSectionId').then(res => {
        this.listParams.sectionId = res.data.data
        this.getListMajor() // 获取专业
      })
    }
  },
}
</script>
