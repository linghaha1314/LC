<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div style="background: #f6f6f6; padding: 12px;">
      <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
           v-for="data in testData" :key="data.title"
      >
        <!-- <div style="font-size: 14px;">
          <van-checkbox v-model="data.checked" shape="square" checked-color="#17d4b5">{{data.date}}</van-checkbox>
        </div> -->
        <van-divider/>
        <div @click="goDetail(data)">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">工作单位：</div>
            <div>{{data['unitName']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">职务/职位：</div>
            <div>{{data.position}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">科室：</div>
            <div>{{data.sectionName}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">开始日期:</div>
            <div>{{data.startDate && data.startDate.substring(0,10) || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">结束日期:</div>
            <div>{{data.endDate && data.endDate.substring(0,10) || '无'}}</div>
          </div>
        </div>
        <div style="text-align: right;">
          <van-button type="warning" size="mini" @click="delEducation(data)">删除</van-button>
        </div>
      </div>
      <div style="position: fixed;right: 26px;bottom: 70px">
        <van-icon color="#ff0000" name="add" size="40" @click="addFn" />
      </div>
    </div>
    <div style="margin: 16px;display: flex;">
      <van-button style="margin-bottom: 12px;" round block @click="goPre">
        上一步
      </van-button>
      <van-button round block color="#17d4b5" @click="attendAdd">
        下一步
      </van-button>
    </div>
  </div>
</template>
<script>
  import {Dialog} from 'vant';
  import { urlForPost } from '../http/apiMap';

  export default {
    name: 'test',
    data() {
      return {
        url: {
          list: '/advancedsignup/getWorkByStaff',
          remove: '/advancedsignup/removeWorkExperience'
        },
        testData: [],
        pageParam: {
          staffId: sessionStorage.getItem('staffId') || '',
          pageSize: 999,
          pageNum: 1
        },
        name: '工作经历'
      }
    },
    computed: {},
    
    methods: {

      goDetail(data) {
        localStorage.setItem('currentWorkData', JSON.stringify(data))
        this.$router.push({
          path: '/sign-write-work-add',
          query: data
        })
      },
      deleteFn() {
        Dialog.confirm({
          title: '温馨提示:',
          message: '确认删除么?',
          confirmButtonColor: '#17d4b5'
        }).then(() => {
          let removeArr = []
          this.testData.forEach(item => {
            if (item.checked) {
              removeArr.push(item.id)
            }
          })
          if (removeArr.length === 0) {
            this.$toast.fail('请勾选后操作!')
          } 
          // else {
          //   removeMobileProcess(removeArr).then(() => {
          //     this.$toast.success('删除成功!')
          //     advancedWorkloadMr(this.pageParam).then(res => {
          //       this.testData = res.data.list
          //     })
          //   })
          // }

        })
      },
      getList() {
        urlForPost(this.url.list, this.pageParam).then(res => {
          this.testData = res.data.list
        })
      },
      goPre() {
        this.$router.push({
          path: '/sign-write-education'
        })
      },
      attendAdd() {
        if (this.testData.length !== 0) {
          this.$router.push({
            path: '/sign-write-company'
          })
        } else {
          this.$toast.fail('请先添加工作!')
        }
        
      },
      delEducation(data) {
        Dialog.confirm({
          message: '确认删除么!'
        }).then(()=>{
          urlForPost(this.url.remove, [data.id]).then(res => {
            this.$toast.fail(res.data.msg)
          })
        }).catch(()=>{})
      },
      addFn() {
        localStorage.setItem('currentWorkData', '')
        this.$router.push({
          path: '/sign-write-work-add'
        })
      }
    },
    mounted() {
      this.getList()
    }
  }
</script>