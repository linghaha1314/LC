<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">
      <van-field v-model="formData.studentName" name="remake" readonly label="姓名"/>
      <van-field v-model="formData.teacherName" name="remake" readonly label="带教老师"/>
      <van-field readonly clickable name="startDate" required label="入科时间" :value="formData.startDate.substring(0,10)"
                 placeholder="选择入科时间" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择入科时间' }]"/>
      <van-popup v-model="showDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="formData.currentDate" type="date" @cancel="showDatePicker = false"
                               @confirm="onDateConfirm($event,formData,'startDate','showDatePicker')"/>
        </div>
      </van-popup>
      <van-field readonly clickable name="endDate" required label="考核时间" :value="formData.endDate.substring(0,10)"
                 placeholder="选择考核时间" @click="showEndDatePicker = true"
                 :rules="[{ required: true, message: '请选择考核时间' }]"/>
      <van-popup v-model="showEndDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="formData.currentEndDate" type="date" @cancel="showEndDatePicker = false"
                               @confirm="onDateConfirm($event,formData,'endDate','showEndDatePicker')"/>
        </div>
      </van-popup>
      <van-field v-model="formData.summary" :readonly="formData.status&&(formData.status===0 || formData.status===1)" name="content" required
                 label="个人鉴定" placeholder="请输入个人鉴定不少于300字" type="textarea"
                 rows="5" maxlength="1000" show-word-limit :autosize="true"
                 :rules="[{ validator:(val)=>val.length>300, message: '请填写个人鉴定不少于300字'}]"
      />
      <div style="margin: 16px;">
        <van-button round block :disabled="formData.status && formData.status!=='0' && formData.status!=='1'"
                    color="#17d4b5" @click="onSubmit">
          {{ formData.status === 1 ? '重新提交' : '提交申请' }}
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {getCurrentTeacherInfo, urlForPost} from '../http/apiMap.js'
import {Dialog} from 'vant';

export default {
  name: 'test',
  data() {
    return {
      url: {
        create: '/threemonthcheck/create',
        update: '/threemonthcheck/update'
      },
      formData: {
        startDate:'',
        endDate:''
      },
      studentInfo: {},
      showDatePicker: false,
      showEndDatePicker: false,
      disabled: false,
      teacherInfo: [],
      userName: '测试'
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '确认提交么?'
        }).then(() => {
          let param = {}
          if (this.formData.id) {
            param = {
              id: this.formData.id,
              summary: this.formData.summary
            }
          }
          urlForPost(
              !this.formData.id ? this.url.create : this.url.update,
              this.formData.id ? param : this.formData
          ).then(res => {
            if (res.data.data && res.data.data.success) {
              this.$toast.success('提交成功!')
              this.$router.go(-1)
            } else {
              this.$toast.fail('提交失败!')
            }
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },
    onDateConfirm(value,target,prop,show) {
      target[prop] = this.getNowFormatDate(value)+' 00:00:00'
      this[show] = false;
    },
    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      return year + seperator1 + month + seperator1 + strDate;
    },
  },
  mounted() {

    let query = this.$route.query
    if (query.id) {
      this.formData = {...query}
    } else {
      getCurrentTeacherInfo().then(res => {
        if (res.data && res.data.success) {
          this.formData.studentName = res.data.data.studentName
          this.formData.studentId = res.data.data.studentId
          this.$set(this.formData, 'studentName', res.data.data.studentName)
          this.$set(this.formData, 'teacherName', res.data.data.teacherName)
          this.formData.teacherName = res.data.data.teacherName
          this.formData.teacherId = res.data.data.teacherId
          this.formData.teacherStaffId = res.data.data.teacherStaffId
        }
      })
    }


  }
}
</script>
