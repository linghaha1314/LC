<template>
  <div>
    <div style="display: flex;justify-content: space-between; padding: 20px">
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <van-uploader :after-read="afterRead">
          <template #default>
            <van-image
                round
                width="54px"
                height="54px"
                :src="userInfo.avator"
            />
          </template>
        </van-uploader>

        <div style="width: 60vw;margin-left: 24px;">
          <div style="font-size: 14px;margin-bottom: 6px">{{ userInfo.name }}</div>
          <div>
            <van-tag style="text-align: center" color="#17d4b5" size="medium">{{ roleName }}</van-tag>
          </div>
        </div>
      </div>
    </div>

    <!--间隔-->
    <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    <div style="padding: 0 12px; background: #f6f6f6;">
      <van-cell title="所在科室" :value="userInfo.sectionName || '无'"/>
      <van-cell title="所在医院" :value="userInfo['hospitalName'] || '无'"/>
      <van-cell title="职称" :value="userInfo.titleName || '无'"/>
      <van-cell title="带教老师" :value="teacherName || '无'" v-if="role === 'StudentType_jxs'"/>
    </div>
    <!--        <div>-->
    <!--            <div style="display: flex; justify-content: space-between;align-items: center; padding: 12px 20px">-->
    <!--                <h3>-->
    <!--                   工具箱-->
    <!--                </h3>-->
    <!--                <div style="color: #ccc; font-size: 10px">-->
    <!--                    查看全部工具-->
    <!--                    <van-icon name="arrow" />-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <van-grid :border="false">-->
    <!--                <van-grid-item v-for="value in 8" :key="value" icon="photo-o" text="文字"/>-->
    <!--            </van-grid>-->
    <!--        </div>-->

    <!--间隔-->
    <div style="width:100%; height: 7px; background: #f6f6f6"></div>

    <div>
      <van-cell v-if="role!=='teacher' && role!=='tutor'" title="轮转信息" icon="upgrade" is-link to="/we-rotary"/>
      <van-cell v-if="role!=='StudentType_jxs'" title="我的学员" icon="friends-o" is-link to="/we-student"/>
      <van-cell title="修改密码" icon="edit" is-link to="/we-changePassword"/>
      <van-cell title="切换身份" icon="manager-o" is-link to="/we-role"/>
      <van-cell :title=" showFlag === 'true' ? '查看入科通知' : '入科通知暂未发放(重新登录后刷新)'" v-if="role==='StudentType_jxs'" icon="label-o" is-link
                @click="download"/>
      <van-cell title="查看学员证" v-if="role==='StudentType_jxs'" icon="user-o" is-link
                @click="download($event,'studentCard')"/>
      <van-cell title="关于我们" icon="warning-o" is-link to="/about"/>
    </div>
    <van-popup v-model="show" style="height: 400px; width: 100vw; ">
      <a :href="hrefU">
        <van-button style="margin: 100px auto; width: 60vw" round block type="primary">
          入科通知下载
        </van-button>
      </a>
    </van-popup>
  </div>
</template>

<script>
import {currentTeacher, getMyUserInfo, updateAvator, uploadFile} from '../http/apiMap';

export default {
  name: "we.vue",
  data() {
    return {
      userInfo: {},
      photo: [],
      attachURL: '',
      imgSrc: 'https://img.yzcdn.cn/vant/cat.jpeg',
      roleName: '',
      role: '',
      teacherName: '',
      show: false,
      hrefU: '',
      showFlag: localStorage.getItem('admissionFlag') || ''
    }
  },
  methods: {
    getInfo() {
      if (this.attachURL === '') {
        getMyUserInfo().then(res => {
          this.attachURL = res.data.data.attachURL

          this.userInfo = res.data.data["staff"]
        })
      }
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        updateAvator({value: res.data.path}).then(res => {
          this.$toast.success(res.data.msg)
          this.getInfo();
        })
      })
    },
    currentTeacherFn() {
      currentTeacher({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        if (res.data && res.data.data) {
          this.teacherName = res.data.data.teacherName
        }
      })
    },
    download($event, type = 'intoFamily') {
      if (this.showFlag === 'true') {
        this.$router.push({
          path: '/download-page',
          query: {
            id: localStorage.getItem('studentId'),
            type: type
          }
        })
      }else{
        this.$toast.fail('暂未发放, 请重新登录重试!')
      }
    }
  },
  mounted() {
    this.getInfo();
    this.roleName = localStorage.getItem('roleName')
    this.role = localStorage.getItem('roleCode')
    if (this.role === 'StudentType_jxs') {
      this.currentTeacherFn()
    }
  }
}
</script>

<style scoped>

</style>
