<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>

    </van-nav-bar>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData" :key="data.title"
          >
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
              {{ data.studentName }}
              <!--          status: 0未提交，1已驳回，2,已审批，11审批中-->
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">已销假</van-tag>
              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">已驳回</van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===0" size="medium">未提交</van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===11" size="medium">审批中</van-tag>
            </div>
            <van-divider/>
            <div @click="goDetail(data)"
            >
              <div style="margin-bottom: 10px">
                <div>阶段: {{ data.typeName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.startDate">
                <div>开始时间: {{ data.startDate.substring(0,10) || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.endDate">
                <div>结束时间: {{data.endDate.substring(0,10) || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <!--        <van-button style="width: 5em" v-if="data.status === 1" type="primary" size="mini" @click="processFn(data,3)">通过</van-button>-->
              <!--        <van-button style="width: 5em" v-if="data.status === 1" type="warning" size="mini" @click="processFn(data,2)">驳回</van-button>-->
              <van-button style="width: 5em" type="danger" size="mini" @click="processFn(data)">删除</van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>


      <div style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave" />
      </div>
    </div>
  </div>
</template>
<script>
import {planscheduleTimeList} from '../http/apiMap.js'

import {Dialog} from "vant";
import {getTransferSchedule, urlForPost} from "../http/apiMap";

export default {
  name: 'test',
  data() {
    return {
      listParams: {
        pageSize: 10,
        pageNum: 0,
        sectionId: '',
        status: null,
      },
      option1: [],
      option2: [
        {text: '全部', value: null},
        {text: '未提交', value: 0},
        {text: '已驳回', value: 1},
        {text: '已通过', value: 2},
        {text: '审批中', value: 11},
      ],
      testData: [],
      role: '',
      transferParams: {
        pageSize: 10,
        pageNum: 1,
      },
      isMine: false,
      state:{
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')

    this.leaveReturnListGet() // 获取销假列表
  },
  methods: {
    goDetail(data) {

      localStorage.setItem('leaveBinData', JSON.stringify(data))
      this.$router.push({
        path: '/backbone-time-add',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;


      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveReturnListGet(flag)
    },
    // 获取销假列表
    leaveReturnListGet(f) {
      let params = {
        ...this.listParams
      }
      planscheduleTimeList(params).then(res => {
        if(f==='onLoad'){
          this.state.loading = false;
          if(res.data.rows.length === 0 || res.data.rows.length<this.listParams.pageSize){
            this.state.finished = true
          }
          this.testData = [...this.testData,...res.data.rows];
        }else{
          this.testData = [...res.data.rows];
        }
        // this.testData = res.data.list
      })
    },

    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option1 = [...optionArr]
      })
    },
    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.leaveReturnListGet()
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    addLeave(){
      this.$router.push({
        path: '/backbone-time-add'
      })
    },
    processFn(data){
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认删除么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        urlForPost('/planschedule/remove', {
          id: data.id
        }).then(() => {
          this.leaveReturnListGet()
        })
      }).catch(() => {
      })

    }
  }
}
</script>
