<template>
  <div class="about">
    <van-nav-bar title="参加学生" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 12px; color: #17D4B5;" v-for="item in list" :key="item.id">
      <div style="border-bottom: 1px solid #cccccc; padding: 12px 0" @click="nowS(item)">
        {{item['staffName']}} ({{item.sectionName}})
      </div>
    </div>
    <van-popup v-model="show" position="bottom" :style="{ height: '30%' }">
      <van-field label="学生姓名" readonly :value="now['staffName']"/>
      <van-field label="科室" readonly :value="now.sectionName"/>
      <van-field label="核心内容" readonly :value="now.remark" :autosize="true" type="textarea" rows="3"/>
    </van-popup>
  </div>
</template>
<script>
    export default {
        name: 'activities-detail',
        data(){
            return{
                list: this.$route.query,
                show: false,
                now:{}
            }
        },

        methods:{
            nowS(data){
                this.now = data
                this.show = true;
            }
        }
    }
</script>
