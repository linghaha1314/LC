<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.replace('/workload')">返回</span>
      </template>
    </van-nav-bar>
    <!--        <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;" v-if="formFlag===1">-->
    <!--            <div style="border-left: 3px solid #17d4b5;padding: 0 4px">-->
    <!--                <div>基础工作量（例/次）{{workInfo.basicWorkNum||0}}例</div>-->
    <!--                <div>实际完成（例/次）{{workInfo.completeNum||0}}例</div>-->
    <!--            </div>-->
    <!--        </div>-->
    <div style="background: #f6f6f6; padding: 12px;">
      <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
           v-for="data in testData"
           :key="data.title">
        <div style="font-size: 14px;" v-if="role==='StudentType_jxs'">
          <van-checkbox v-model="data.checked" shape="square" checked-color="#17d4b5">{{ data.date }}</van-checkbox>
        </div>
        <van-divider/>
        <div v-if="data.formFlag===0">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">住院号：</div>
            <div>{{ data.inpatientNo }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">病人姓名：</div>
            <div>{{ data.patientName }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">床位号：</div>
            <div>{{ data.bedNo }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">诊断:</div>
            <div>{{ data['diagnosisName'] }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">入院时间:</div>
            <div>{{ data.inHospitalDate && data.inHospitalDate.substring(0, 10) || '无' }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">病种:</div>
            <div>{{ data.diseasesName }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">工作内容:</div>
            <div>{{ data.skillName }}</div>
          </div>
        </div>
        <div v-if="data.formFlag===1">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">科室：</div>
            <div>{{ data.sectionName }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">专业：</div>
            <div>{{ data.majorName }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">老师指导完成数：</div>
            <div>{{ data.guideNum || 0 }}例</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">独立完成数:</div>
            <div>{{ data.independentNum || 0 }}例</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">参与完成数:</div>
            <div>{{ data.joinNum || 0 }}例</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">工作内容:</div>
            <div>{{ data.workItemName }}</div>
          </div>
        </div>
        <div v-if="data.formFlag===2">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">开始时间：</div>
            <div>{{ data.startDate.substring(0, 10) || '无' }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">结束时间：</div>
            <div>{{ data.endDate.substring(0, 10) || '无' }}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">门诊接诊次/人:</div>
            <div>{{ data['acceptNum'] || 0 }}例</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">门诊手术次/人:</div>
            <div>{{ data['surgeryNum'] || 0 }}例</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">门诊治疗次/人:</div>
            <div>{{ data['treatNum'] || 0 }}例</div>
          </div>
        </div>
        <div v-if="data.formFlag===3">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">创建时间：</div>
            <div>{{ data.created.substring(0, 10) || '无' }}</div>
          </div>

          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">做实验次/数:</div>
            <div>{{ data['experimentNum'] || 0 }}次</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">查文献次/数:</div>
            <div>{{ data['literatureNum'] || 0 }}次</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">数据整理次/数:</div>
            <div>{{ data['dataCollationNum'] || 0 }}次</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">撰写论文次/数:</div>
            <div>{{ data['articleNum'] || 0 }}次</div>
          </div>
        </div>

      </div>
      <div style="position: fixed;right: 26px;bottom: 70px" v-if="isDisabled">
        <router-link to="/workload-clinical-add">
          <van-icon color="#ff0000" name="add" size="40"/>
        </router-link>
      </div>
    </div>
    <div style="position: fixed;left: 0;bottom: 0;width: 100vw;" v-if="role==='StudentType_jxs' && isDisabled">
      <van-button style="width: 33%" @click="backTo">上一步</van-button>
      <van-button style="width: 33%" type="danger" @click="deleteFn">删除</van-button>
      <van-button style="width: 34%" color="#17d4b5" @click="onSubmit">返回列表</van-button>
    </div>
    <div style="position: fixed;left: 0;bottom: 0;width: 100vw;"
         v-if="(role === 'sectionManager' || role === 'teacher' || role === 'headNurse')&&isMine!=='isMine'">
      <van-button style="width: 33%" color="#17d4b5" @click="onSubmit">返回列表</van-button>
      <van-button style="width: 33%" type="warning" @click="throughFn(0)">不通过</van-button>
      <van-button style="width: 34%" color="#4dff79" @click="throughFn(1)">通过</van-button>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  advancedworkloadApprovalProcess,
  advancedWorkloadMr,
  removeMobileProcess,
  othersList,
  getDetailWorkload,
  advancedworkloadoutpatientList,
  removeOutpatient,
  removeWd,
  urlForPost
} from '../http/apiMap';

export default {
  name: 'test',
  data() {
    return {
      value: '',
      isEdit: false,
      option2: [
        {text: '未提交', value: 'c'},
        {text: '开展中', value: 'a'},
        {text: '已完成', value: 'b'},
      ],
      testData: [],
      pageParam: {
        workloadId: '',
        pageSize: 999,
        pageNum: 1
      },
      isShowBtn: '0',
      role: '',
      isDisabled: true, // 是否可编辑
      currentData: {},
      formFlag: 0,
      workInfo: {},
      isMine: sessionStorage.getItem('isMine') || ''
    }
  },
  computed: {
    name() {
      if (this.role === 'StudentType_jxs') {
        return this.$route.name
      } else {
        return '审核工作量详情'
      }
    }
  },

  methods: {
    goDetail(data) {
      // localStorage.setItem('currentData', JSON.stringify(data))
      // this.$router.push({
      //     path: '/workload-clinical-add',
      //     query: data
      // })
    },
    onSubmit() {
      this.$router.replace({
        path: '/workload'
      })
      // Dialog.confirm({
      //     title: '温馨提示:',
      //     message: '确认提交么?',
      //     confirmButtonColor: '#17d4b5'
      // }).then(()=>{
      //     startMobileProcess({
      //         id: localStorage.getItem('workloadId')
      //     }).then(()=>{
      //         this.$toast.success('提交成功!')
      //
      //     })
      // })
    },
    deleteFn() {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认删除么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        // let removeArr = []
        let arrS = []
        let arrJ = []
        let arrM = []
        let arrR = []
        this.testData.forEach(item => {
          if (item.checked && item.formFlag === 0) {
            arrS.push(item.id)
          } else if (item.checked && item.formFlag === 1) {
            arrJ.push(item.id)
          } else if (item.checked && item.formFlag === 2) {
            arrM.push(item.id)
          } else if (item.checked && item.formFlag === 3) {
            arrR.push(item.id)
          }
        })
        if (arrS.length === 0 && arrJ.length === 0 && arrM.length === 0 && arrR.length === 0) {
          this.$toast.fail('请勾选后操作!')
        } else {
          if(arrS.length>0){
            removeMobileProcess(arrS).then()
          }
          if(arrJ.length>0){
            removeWd(arrJ).then()
          }
          if(arrM.length>0){
            removeOutpatient(arrM).then()
          }
          if(arrR.length>0){
            urlForPost('/advancedworkloadre/removeWorkloadRe', arrR).then()
          }
          this.$toast.success('删除成功!')
          setTimeout(()=>{
            this.getList()
          }, 2000)
        }

      })
    },
    backTo() {
      localStorage.setItem('formAction', '1')
      this.$router.replace({
        path: '/workload-add'
      })
    },
    getList() {
      this.testData = []
      advancedWorkloadMr(this.pageParam).then(res => { // 医师
        let data = res.data.list
        data.forEach(item => {
          item.formFlag = 0
        })
        this.testData = [...this.testData, ...data]
      })
      othersList(this.pageParam).then(res => {  // 医技
        let data = res.data.list
        data.forEach(item => {
          item.formFlag = 1
        })
        this.testData = [...this.testData, ...data]
      })
      advancedworkloadoutpatientList(this.pageParam).then(res => { // 门诊
        let data = res.data.list
        data.forEach(item => {
          item.formFlag = 2
        })
        this.testData = [...this.testData, ...data]
      })
      urlForPost('/advancedworkloadre/listByWorkloadId', this.pageParam).then(res => {
        let data = res.data.list
        data.forEach(item => {
          item.formFlag = 3
        })
        this.testData = [...this.testData, ...data]
      })
    },
    // 审批
    throughFn(num) {
      let target = {...this.currentData}
      Dialog.confirm({
        title: '温馨提示:',
        message: '是否确定提交!',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        let param = {
          "opinion": num === 1 ? "同意" : "不同意",
          "processInstanceId": target.processInstanceId,
          "projectId": target.id,
          "retryStatus": 0,
          "status": num,
          "taskId": target.taskId
        }
        advancedworkloadApprovalProcess(param).then(res => {
          this.$toast.success(res.data.msg)
          this.$router.replace('/workload')
        })
      }).catch(() => {
        this.$toast.success('取消')
      })
    },
    getDetailWorkloadFn() {
      let param = {
        id: localStorage.getItem('workloadId') || ''
      }
      getDetailWorkload(param).then(res => {
        this.workInfo = res.data.data
      })
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    // 判断学员类型
    // let workType = localStorage.getItem('workType')
    // if (workType === '医师0') {
    //     this.formFlag = 0
    // } else if (workType === '医师1') {
    //     this.formFlag = 2
    // } else {
    //     this.formFlag = 1
    // }

    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')

    this.isShowBtn = sessionStorage.getItem('isSubmit') || '0'
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.pageParam.workloadId = localStorage.getItem('workloadId')
    this.getList()
    let currentForm = JSON.parse(localStorage.getItem('currentWorkloadData') || "{}")
    this.currentData = currentForm
    this.isDisabled = !currentForm.status || currentForm.status === 0 || currentForm.status === 1
    if (this.formFlag === 1) { // 是医技时候
      this.getDetailWorkloadFn()
    }
  },
}
</script>
