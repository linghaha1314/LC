<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <template #right v-if="role !== 'StudentType_jxs'">
        <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">查询审核</span>
        <span v-else style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>
      </template>
    </van-nav-bar>

    <div v-if="role !== 'StudentType_jxs'">
        <van-dropdown-menu active-color="#17d4b5">
<!--            <van-dropdown-item title="科室" v-model="listParams.sectionId" @change="leaveListGet" :options="option2" />-->
          <section-drop  v-model="listParams.sectionId" @change="onRefresh"></section-drop>
          <van-dropdown-item title="状态" v-model="listParams.status" @change="onRefresh" :options="option3" />
          <batch-drop v-model="listParams.batchId" @change="onRefresh"></batch-drop>
        </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
              {{ data.typeName }}
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">已通过</van-tag>
              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">已拒绝</van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交</van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===11" size="medium">审核中</van-tag>
            </div>
            <van-divider/>
            <div>
              <div style="margin-bottom: 10px">
                <div>申请人: {{ data.studentName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.startDate">
                <div style="margin-bottom: 10px;">入科时间:</div>
                <div>{{ data.startDate.substring(0, 10) }}</div>
              </div>
              <div style="margin-bottom: 10px" v-if="data.endDate">
                <div style="margin-bottom: 10px;">考核时间:</div>
                <div>{{ data.endDate.substring(0, 10) }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>科室: {{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>专业: {{ data.majorName || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <van-button v-if="role === 'StudentType_jxs' && (data.status === 0 || data.status === 1)"
                          style="width: 50px; margin-right: 12px" type="primary" size="mini" @click="goDetail(data)">修改
              </van-button>
              <van-button v-if="role !== 'StudentType_jxs' &&  data.status === 11 && !isMine"
                          style="width: 50px; margin-right: 12px" type="warning" size="mini" @click="goProcess(data)">
                去审核
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && data.status === 0" style="width: 50px; margin-right: 12px"
                          type="danger" size="mini" @click="delFn(data)">删除
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && (data.status === 0 || data.status === 1)"
                          style="width: 50px; margin-right: 12px" type="primary" size="mini" @click="upFn(data)">提交
              </van-button>
              <router-link :to="{path:'/three-mouths-detail',query:data}">
                <van-button style="width: 50px; margin-right: 12px" type="primary"
                            size="mini">详情
                </van-button>
              </router-link>
              <router-link v-if="data.status === 11" :to="{path:'/approval-detail',query:data}">
                <van-button type="default" size="mini">查看审批进度</van-button>
              </router-link>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
      <div v-if="role === 'StudentType_jxs'" style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getTransferSchedule,
  listThreeMonthCheckByPage,
  getLeaveApprovalProcess,
  getLeaveVerification,
  getApplyInfo,
  delThreemonthcheck,
  listProcessByPageThree,
  threemonthProcess,
  urlForGetCode,
  urlForGet
} from "../http/apiMap";
import SectionDrop from '../components/section-drop'
import BatchDrop from '../components/batch-drop'
export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
    SectionDrop,
    BatchDrop
  },
  data() {
    return {
      reason: '',
      show: false,
      listParams: {
        pageSize: 10,
        pageNum: 0,
        sectionId: '',
        studentId: ''
      },
      transferParams: {
        pageSize: 10,
        pageNum: 1,
      },
      option2: [],
      option3: [
        {text: '全部', value: null},
        {text: '未提交', value: 0},
        {text: '已拒绝', value: 1},
        {text: '已通过', value: 2},
        {text: '审核中', value: 11},
      ],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      studentInfo: {},
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      isLoading: false,
      count: 0
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    goDetail(data) {
      if (this.role === 'StudentType_jxs') {
        // localStorage.setItem('currentData', JSON.stringify(data))
        this.$router.push({
          path: '/three-mouths-add',
          query: data
        })
      }
    },
    // 获取申请列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }
      if (this.role === 'StudentType_jxs' || this.isMine) {
        if(this.role === 'StudentType_jxs'){
          this.getApplyInfoFn(()=>{
            params.studentId = this.studentInfo.studentId
            // params.sectionId = this.studentInfo.sectionId
            listThreeMonthCheckByPage(params).then(res => {
              if (f === 'onLoad') {
                this.state.loading = false;
                if(res.data.rows.length === 0 || res.data.rows.length<this.listParams.pageSize){
                  this.state.finished = true
                }
                this.testData = [...this.testData,...res.data.rows];
              } else {
                this.testData = [...res.data.rows];
              }
            })
          })
        }else {
          listThreeMonthCheckByPage(params).then(res => {
            if (f === 'onLoad') {
              this.state.loading = false;
              if(res.data.rows.length === 0 || res.data.rows.length<this.listParams.pageSize){
                this.state.finished = true
              }
              this.testData = [...this.testData,...res.data.rows];
            } else {
              this.testData = [...res.data.rows];
            }
          })
        }
      } else {
        listProcessByPageThree(params).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            if(res.data.total === 0){
              this.testData = []
            }else{
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      }
    },

    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },
    // 审批
    throughFn(num) {
      let target = {}
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          target = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选申请信息!')
      } else {
        let msg = '';
        getLeaveVerification({
          "studentId": target.studentId
        }).then(res => {
          let data = res.data.data
          msg = num === 1 ? `${data.studentName}在本次进修期间剩余申请天数为${data["maxLeaveDays"] - data["totalDays"]}天,确认要同意他的申请申请吗？` : '确认拒绝申请么?'
          Dialog.confirm({
            title: '温馨提示:',
            message: msg,
            confirmButtonColor: '#17d4b5'
          }).then(() => {
            this.getApprove(num, target)
          }).catch(() => {
          })
        })
      }
    },
    // 点击不通过
    notThrough() {
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          this.notTarget = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选申请信息!')
      } else {
        this.show = true;
      }
    },
    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.leaveListGet()
    },
    // 通过审批
    getApprove(num, target) {
      let param = {
        "opinion": num === 1 ? "同意" : this.reason,
        "processInstanceId": target.processInstanceId,
        "projectId": target.id,
        "retryStatus": 0,
        "status": num,
        "taskId": target.taskId,
      }
      getLeaveApprovalProcess(param).then(res => {
        this.$toast.success(res.data.msg)
        this.leaveListGet();
      })
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    // 判断是否有正在审核的申请
    addLeave() {
      if (this.testData.length === 0) {
        let student = localStorage.getItem('studentId')
        urlForGetCode('/student/getById', student).then(res => {
          if (res.data.success) {
            let data = res.data.data
            if (data['checkStatus'] === 1) {
              urlForGet('/student/getStudentByIdAndVolume').then(re=>{
                if(re.data.status === 0){
                  this.$router.push({
                    path: '/three-mouths-add'
                  })
                }else{
                  this.$toast.fail(re.data.message)
                }
              })

            } else {
              this.$toast.fail('您未在入科三个月考核名单中！')
            }
          }
        })
      } else {
        this.$toast.fail('不能重复申请哦!')
      }
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    delFn(data) {
      delThreemonthcheck({
        id: data.id
      }).then(() => {
        this.$toast.success('操作成功!')
        this.leaveListGet() // 获取申请列表
      })
    },
    upFn(data) {
      threemonthProcess(data).then(() => {
        this.$toast.success('操作成功!')
        this.leaveListGet() // 获取申请列表
      })
    },
    goProcess(data) {

      this.$router.push({
        path: '/three-mouths-process',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      this.testData = [];
      // 重新加载数据
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
  },
}
</script>
