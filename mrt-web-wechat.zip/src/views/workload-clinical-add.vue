<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form @submit="onSubmit">
      <van-field readonly clickable required name="typeId" label="当前科室" :value="formData.sectionName"
                 placeholder="选择当前科室" @click="sectionClick" :rules="[{ required: true, message: '请选择当前科室' }]" />
      <van-popup v-model="showSectionPicker" round position="bottom">
        <div>
          <van-search v-model="sName" shape="round" @change="transferGet" placeholder="搜索" />
        </div>
        <van-picker :columns="sectionColumns" :show-toolbar="true" @cancel="showSectionPicker = false" @confirm="onConfirm($event,formData,'sectionName','sectionId','showSectionPicker')"
        />
      </van-popup>

      <van-field v-if="formData.sectionName" readonly clickable required name="typeId" label="当前专业" :value="formData.majorName"
                 placeholder="选择当前专业" @click="showMajorPicker = true, formData.majorName = null" :rules="[{ required: true, message: '请选择当前专业' }]" />
      <van-popup v-model="showMajorPicker" round position="bottom">
        <van-picker :columns="majorColumns" :show-toolbar="true" @cancel="showMajorPicker = false" @confirm="onConfirm($event,formData,'majorName','majorId','showMajorPicker')"
        />
      </van-popup>

<!--      <van-field name="outpatientType" label="是否是病房" required :rules="[{ required: true, message: '请选择是否是病房' }]">-->
<!--        <template #input>-->
<!--          <van-radio-group v-model="formData.outpatientType" direction="horizontal">-->
<!--            <van-radio :name="0">是</van-radio>-->
<!--            <van-radio :name="1">否</van-radio>-->
<!--          </van-radio-group>-->
<!--        </template>-->
<!--      </van-field>-->

      <van-field v-if="formData.majorName" name="outpatientFlag" label="工作类型" required :value="formData.outpatientFlag" :rules="[{ required: true, message: '请选择类型' }]">
        <template #input>
          <van-radio-group v-model="formData.outpatientFlag" direction="horizontal" @change="radioChange">
            <van-radio :name="2">医学研究</van-radio>
            <van-radio v-if="formData.wardFlag" :name="0">管床医师</van-radio>
            <van-radio v-if="formData.wardFlag" :name="1">门诊医师</van-radio>
            <van-radio v-else :name="3">日常工作</van-radio>
          </van-radio-group>
        </template>
      </van-field>


      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <div v-if="(formData.wardFlag &&formData.outpatientFlag === 0) && formData.outpatientFlag!==2">
        <van-field v-model="formData.inpatientNo" name="inpatientNo" label="住院号" required placeholder="请填写住院号" :rules="[{ required: true, message: '请填写住院号' }]"
        />
        <van-field v-model="formData.patientName" patientName="name" label="病人姓名" required placeholder="请填写病人姓名" :rules="[{ required: true, message: '请填写病人姓名' }]"
        />

        <van-field v-model="formData.bedNo" name="bedNo" required :rules="[{ required: true, message: '请填写病人床位号' }]" label="床位号"
        />

        <van-field readonly clickable required name="date" label="入院日期" :value="formData.inHospitalDate&&formData.inHospitalDate.substring(0,10)"
          placeholder="选择入院日期" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择入院日期' }]" />
        <van-popup v-model="showDatePicker" round position="bottom">
          <van-datetime-picker v-model="formData.currentDate" type="date" title="入院日期" @cancel="showDatePicker = false" @confirm="onDateConfirm($event,formData,'inHospitalDate','showDatePicker')"
            :min-date="minDate" :max-date="maxDate" />
        </van-popup>

<!--        <van-field readonly clickable required name="typeId" label="科室" :value="formData.sectionName" placeholder="选择科室" @click="showSectionPicker = true"-->
<!--          :rules="[{ required: true, message: '请选择科室' }]" />-->
<!--        <van-popup v-model="showSectionPicker" round position="bottom">-->
<!--          <div>-->
<!--            <van-search v-model="transferParams.name" shape="round" @change="transferGet" placeholder="搜索" />-->
<!--          </div>-->
<!--          <van-picker :columns="sectionColumns" :show-toolbar="true" @cancel="showSectionPicker = false" @confirm="onConfirm($event,formData,'sectionName','sectionId','showSectionPicker')"-->
<!--          />-->
<!--        </van-popup>-->

        <div style="width:100%; height: 7px; background: #f6f6f6"></div>
        <van-field readonly clickable required name="type" label="病种" type="textarea" :autosize="true" :value="formData.diseasesName"
          placeholder="选择病种" @click="showTypePicker = true" :rules="[{ required: true, message: '请选择病种' }]" />
        <van-popup v-model="showTypePicker" style="height: 70vh" round position="bottom">
          <m-checkbox url="/diseases/getListQueryByPage" url-option="/section/getListByPage" :query-param="{majorId: formData.majorId}" :value="formData.diseasesId?formData.diseasesId.split(','):[]" @checkFn="checkboxFn($event,'diseasesName','diseasesId')"></m-checkbox>
        </van-popup>
        <van-field name="diagnosis" clickable required readonly label="诊断" :value="formData['diagnosisName']" placeholder="请输入诊断结果"
                   :autosize="true" type="textarea" @click="showDiagnosisPicker = true" :rules="[{ required: true, message: '请输入诊断结果' }]"
        />
        <van-popup v-model="showDiagnosisPicker" style="height: 70vh" round position="bottom">
          <m-checkbox url="/advancedworkloaddiagnosis/getListAuthQueryByPage" url-option="/section/getListByPage" :query-param="{majorId: formData.majorId}" :value="formData.diagnosis?formData.diagnosis.split(','):[]"
            @checkFn="checkboxFn($event,'diagnosisName','diagnosis')"></m-checkbox>
        </van-popup>
        <van-field readonly clickable required name="type" label="工作内容" :value="formData.skillName" placeholder="选择工作内容" :autosize="true"
          type="textarea" @click="showSkillPicker = true" :rules="[{ required: true, message: '请选择工作内容' }]" />
        <van-popup style="height: 60vh; padding: 24px 0" v-model="showSkillPicker" round position="bottom">
          <m-checkbox url="/advancedskill/getListQueryByPage" :value="formData.skillId?formData.skillId.split(','):[]" @checkFn="checkboxFn($event,'skillName','skillId')"></m-checkbox>
        </van-popup>
      </div>

      <div v-if="formData.outpatientFlag === 3">
        <van-field readonly clickable required name="type" label="工作内容" :value="formData.workItemName" placeholder="选择工作内容" @click="showSkillPicker = true"
          :rules="[{ required: true, message: '请选择工作内容' }]" />
        <van-popup v-model="showSkillPicker" round position="bottom">
          <van-picker :columns="skillColumns" :show-toolbar="true" @cancel="showSkillPicker = false" @confirm="onSkillConfirm" />
        </van-popup>
        <van-field v-model="formData.joinNum" type="number" required label="参与完成" />
        <van-field v-model="formData.guideNum" type="number" required label="指导完成" />
        <van-field v-model="formData.independentNum" type="number" required label="独立完成" />
      </div>

      <div v-if="formData.wardFlag && formData.outpatientFlag === 1">
        <van-field readonly clickable required name="date" label="开始日期" :value="formData.startDate&&formData.startDate.substring(0,10)"
          placeholder="选择开始日期" @click="showStartDatePicker = true" :rules="[{ required: true, message: '请选择开始日期' }]" />
        <van-popup v-model="showStartDatePicker" round position="bottom">
          <van-datetime-picker v-model="formData.currentDate" type="date" title="开始日期" @cancel="showStartDatePicker = false" @confirm="onDateConfirm($event,formData,'startDate','showStartDatePicker')"
            :min-date="minDate" :max-date="maxDate" />
        </van-popup>

        <van-field readonly clickable required name="date" label="结束日期" :value="formData.endDate&&formData.endDate.substring(0,10)"
          placeholder="选择结束日期" @click="showEndDatePicker = true" :rules="[{ required: true, message: '请选择结束日期' }]" />
        <van-popup v-model="showEndDatePicker" round position="bottom">
          <van-datetime-picker v-model="formData.currentDate" type="date" title="结束日期" @cancel="showEndDatePicker = false" @confirm="onDateConfirm($event,formData,'endDate','showEndDatePicker')"
            :min-date="minDate" :max-date="maxDate" />
        </van-popup>

        <van-field v-model="formData['acceptNum']" type="number" required label="门诊接诊次/人" />
        <van-field v-model="formData['surgeryNum']" type="number" required label="门诊手术次/人" />
        <van-field v-model="formData['treatNum']" type="number" required label="门诊治疗次/人" />
      </div>

      <div v-if="formData.outpatientFlag === 2">
        <van-field v-model="formData['experimentNum']" type="number" required label="做实验次/数" />
        <van-field v-model="formData['literatureNum']" type="number" required label="查文献次/数" />
        <van-field v-model="formData['dataCollationNum']" type="number" required label="数据整理次/数" />
        <van-field v-model="formData['articleNum']" type="number" required label="撰写论文字/数" />
      </div>

      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <div style="margin: 16px;" v-if="(action===3 || action === 1 ||  action === 0) && role === 'StudentType_jxs'">
        <van-button round block color="#17d4b5" native-type="submit">保存工作量详情</van-button>
      </div>
      <!-- <div style="margin: 16px;" v-if="action===1">
        <van-button style="margin-bottom: 12px;" round block color="#17d4b5" native-type="submit">发布</van-button>
        <van-button round block type="danger">删除</van-button>
      </div>
      <div style="margin: 16px;" v-if="action===2">
        <van-button round block color="#17d4b5" native-type="submit">结束活动</van-button>
      </div> -->
    </van-form>
  </div>
</template>
<script>
  import mCheckbox from "../components/m-checkbox";
  import {
    getListDiseases,
    advancedWorkloadMrSave,
    advancedSkill,
    urlForPost,
    saveOrUpdateWorkloadWd,
    advancedSkillItem,
    advancedworkloadoutpatient, getStudentInfo, getTransferscheduleCode
  } from "../http/apiMap";

  export default {
    name: "test",
    components: {
      mCheckbox
    },
    data() {
      return {
        formData: {
          bedNo: "",
          diagnosis: "",
          diseasesId: "",
          diseasesName: "",
          sectionId: "",
          sectionName: "",
          majorId: "",
          majorName: "",
          inHospitalDate: "",
          inpatientNo: "",
          patientName: "",
          skillId: "",
          skillName: "",
          workloadId: "",
          joinNum: 0,
          guideNum: 0,
          independentNum: 0,
          experimentNum: 0,
          literatureNum: 0,
          dataCollationNum: 0,
          articleNum: 0
        },

        showSkillPicker: false,
        showDiagnosisPicker: false,
        showTypePicker: false,
        showDatePicker: false,
        showSectionPicker: false,
        showMajorPicker: false,
        showStartDatePicker: false,
        showEndDatePicker: false,
        diseasesColumns: [],
        skillColumns: [],
        sectionColumns: [],
        majorColumns: [],
        action: 3,
        minDate: new Date(2015, 1, 1),
        maxDate: new Date(2025, 10, 1),
        currentDate: new Date(),
        currentTime: "12:00",
        currentEndDate: "12:00",
        diseasesParam: {
          pageNum: 1,
          pageSize: 999,
          majorId: ''
        },
        listParams: {
          pageSize: 999,
          pageNum: 1,
          typeId: "",
          // sectionId: "",
          name: "",
          status: null
        },
        listDiseases: [],
        option4: [],
        transferParams: {
          pageSize: 999,
          pageNum: 1,
          name: ""
        },
        formFlag: 0,
        checkedSection: [],
        skillList: [],
        checkedSkill: [],
        sectionName: "科室",
        role: '',
        sName: '',
        parentId: '',
        sectionId: '',
        isSpecial: false
      };
    },
    computed: {
      name() {
        return this.$route.name;
      }
    },
    methods: {
      onSubmit() {
        this.formData.workloadId = localStorage.getItem("workloadId") || "";
        if (this.formData.wardFlag && this.formData.outpatientFlag === 0) {

          advancedWorkloadMrSave(this.formData).then(() => {
            this.$toast.success("添加成功!");
            this.$router.go(-1);
          });
        } else if ((!this.formData.wardFlag || this.formData.outpatientFlag!==0 && this.formData.outpatientFlag!==1) && this.formData.outpatientFlag!==2) {
          saveOrUpdateWorkloadWd(this.formData).then(() => {
            this.$toast.success("添加成功!");
            this.$router.go(-1);
          });
        } else if(this.formData.wardFlag && this.formData.outpatientFlag === 1){
          advancedworkloadoutpatient(this.formData).then(() => {
            this.$toast.success("添加成功!");
            this.$router.go(-1);
          });
        }else if(this.formData.outpatientFlag === 2){
          urlForPost('/advancedworkloadre/saveOrUpdateWorkloadRe', this.formData).then(() => {
            this.$toast.success("添加成功!");
            this.$router.go(-1);
          })
        }

        // localStorage.setItem('addItem',JSON.stringify(data))
      },

      onConfirm(value, target, name, id, show) {
        // this.formData.majorName = ''
        // this.formData.sectionName = ''
        // this.formData.outpatientFlag = -1
        target[name] = value.text;
        target[id] = value.value;
        this[show] = false;
        if (id === "sectionId") {
          this.submajorListFn();
          // this.advancedSkillFn();
        }else if (id === "majorId") {
          target['wardFlag'] = value.wardFlag
          this.advancedSkillFn();
        }
      },

      onTypeConfirm(value) {
        this.formData.diseasesName = value.text;
        this.formData.diseasesId = value.value;
        this.showTypePicker = false;
      },
      onSectionConfirm(value) {
        this.formData.diseasesName = value.text;
        this.formData.diseasesId = value.value;
        this.showTypePicker = false;
      },
      onMajorConfirm(value) {
        this.formData.diseasesName = value.text;
        this.formData.diseasesId = value.value;
        this.showTypePicker = false;
      },
      onSkillConfirm(value) {
        this.formData.workItemName = value.text;
        this.formData.workItemId = value.value;
        this.showSkillPicker = false;
      },
      onDateConfirm(value, target, prop, show) {
        target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
        this[show] = false;
      },
      // 开始时间
      onStartDateConfirm(value) {
        this.formData.startValue = value;
        this.showStartTimePicker = false;
      },
      // 结束时间
      onEndDateConfirm(value) {
        this.formData.endValue = value;
        this.showEndTimePicker = false;
      },
      // 时间格式
      getNowFormatDate(date) {
        let seperator1 = "-";
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let strDate = date.getDate();
        if (month >= 1 && month <= 9) {
          month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
        }
        return year + seperator1 + month + seperator1 + strDate;
      },
      changeItem(e) {
        this.option4.forEach(item => {
          if (item.value === e) {
            this.sectionName = item.text;
          }
        });
        this.getListDiseasesFn();
      },
      // 获取病种列表
      getListDiseasesFn() {
        this.listParams.majorId = this.formData.majorId
        getListDiseases(this.listParams).then(res => {
          this.listDiseases = res.data.list;
        });
      },
      // 获取工作内容列表
      advancedSkillFn() {

        this.diseasesParam.majorId = this.formData.majorId
        if ( !this.formData.wardFlag || this.formData.outpatientFlag!==0 && this.formData.outpatientFlag!==1) { // 护理
          advancedSkillItem(this.diseasesParam).then(res => {
            this.skillList = res.data.list;
            let data = res.data.list;
            let arr = [];
            data.forEach(item => {
              let obj = {
                text: item.name,
                value: item.id
              };
              arr.push(obj);
            });
            if(arr.length===0){
              arr = [{
                text: '还未添加工作内容哦!',
                value: null
              }]
            }
            this.skillColumns = arr;
          });
        } else { // 医师
          advancedSkill(this.diseasesParam).then(res => {
            this.skillList = res.data.list;
            let data = res.data.list;
            let arr = [];
            data.forEach(item => {
              let obj = {
                text: item.name,
                value: item.id
              };
              arr.push(obj);
            });
            this.skillColumns = arr;
          });
        }
      },
      // 获取科室信息
      // transferGet() {
      //   getTransferSchedule(this.transferParams).then(res => {
      //     let optionArr = [];
      //     res.data.list.forEach(item => {
      //       let obj = {
      //         text: item.name,
      //         value: item.id
      //       };
      //       optionArr.push(obj);
      //     });
      //     this.sectionColumns = [...optionArr];
      //     this.option4 = [...optionArr];
      //     this.listParams.sectionId = this.option4[0].value;
      //     this.sectionName = this.option4[0].text;
      //     this.getListDiseasesFn();
      //   });
      // },
      // 获取科室信息
      transferGet() {
        urlForPost('/transferschedule/getAllTransferSectionByStudentId',{
          pageNum: 1,
          pageSize: 99,
          // name: this.sName,
          studentId: localStorage.getItem('studentId')||''
        }).then(res => {
          let optionArr = []
          res.data.data.rows.forEach(item => {
            let obj = {
              text: item.sectionName,
              value: item.sectionId
            }
            optionArr.push(obj)
          })
          this.sectionColumns = [...optionArr]
        })
      },

      // 获取专业列表
      submajorListFn() {

        let p = {
          pageSize: 99,
          pageNum: 1,
          sectionId: this.formData.sectionId,
          status: 0
        };
        urlForPost('/submajor/listBylistSubMajorByPageForWorkingPage',p).then(res => {
          let optionArr = [];
          res.data.list.forEach(item => {
            let obj = {
              text: item.name,
              value: item.id,
              ...item
            };
            optionArr.push(obj);
          });
          this.majorColumns = [...optionArr];
        });
      },
      checkboxFn(data, name, id) {
        this.formData[name] = data.names;
        this.formData[id] = data.ids;
      },
      // 判断科室是否特殊处理
      getTransferscheduleFn(){
        let studentId = localStorage.getItem('studentId') || ''
        let thatV = this
        getTransferscheduleCode(studentId).then(res => {
          if(res.data&& res.data.data){
            this.transferFlag = !!res.data.data.transferId;
            this.specialFlag = res.data.data.specialFlag
            getStudentInfo(studentId).then(r => { // 获取当前科室
              thatV.isSpecial= r.data.data.isSpecial === 1; // 特殊科室
              if(this.transferFlag && !this.isSpecial){
                this.formData.sectionId = res.data.data.id
                this.submajorListFn();
              }else{
                this.formData.sectionId = r.data.data.sectionId
                this.submajorListFn();
              }
            })
          }else{
            this.$toast.fail('您还没入科哟!')
          }
        })
      },
      sectionClick(){
        this.showSectionPicker = true
      },
      radioChange(){
      }
    },
    mounted() {
      // 获取角色
      this.role = localStorage.getItem("roleCode");

      let workType = localStorage.getItem("workType");
      if (workType === '医师0') {
        this.formFlag = 0
      } else if (workType === '医师1') {
        this.formFlag = 2
      } else {
        this.formFlag = 1
      }

      if (this.$route.query.id) {
        this.formData = this.$route.query;
      }
      let currentForm = JSON.parse(localStorage.getItem("currentWorkloadData")) || {};
      if (!this.formData.id) {
        this.action = 3;
      } else {
        this.action = currentForm.status;
        this.formData = Object.assign(this.formData, currentForm);
      }
      localStorage.setItem("currentData", "");
      this.getTransferscheduleFn()
      this.transferGet();
      this.advancedSkillFn() // 获取工作内容
    }
  };
</script>
