<template>
  <div class="about">
    <van-nav-bar title="个人信息" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        个人信息填写
      </div>
    </div>
    <div>
      <van-form ref="infoForm">
        <div style="text-align: center; color: orangered">请上传本人一寸蓝底照片,分辨率不小于413*295</div>
        <van-field name="attachPath" :value="formData.avator" required label="头像"
                   :rules="[{ required: true, message: '请上传头像' }]">
          <template #input>
            <van-uploader v-model="fileList" :after-read="afterRead" :before-delete='beforeDelete'/>
          </template>
        </van-field>

        <van-field
            name="name"
            clickable
            required
            label="姓名"
            v-model="formData.name"
            placeholder="请输入姓名"
            :rules="[{ required: true, message: '请输入姓名' }]"
        />

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="性别"
            :value="formData['genderName']"
            placeholder="选择性别"
            @click="showSectionPicker = true"
            :rules="[{ required: true, message: '请选择性别' }]"
        />
        <van-popup v-model="showSectionPicker" round position="bottom">
          <m-picker
              url="/dictionary/getByTypeCodeParams"
              code="gender"
              @cancel="showSectionPicker = false"
              @confirm="onConfirm($event,formData,'genderName','genderId','showSectionPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="民族"
            :value="formData['nationName']"
            placeholder="选择民族"
            @click="showNationPicker = true"
            :rules="[{ required: true, message: '请选择民族' }]"
        />
        <van-popup v-model="showNationPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Nation"
                    @cancel="showNationPicker = false"
                    @confirm="onConfirm($event,formData,'nationName','nationId','showNationPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            name="birthday"
            required
            label="出生日期"
            :value="formData.birthday&&formData.birthday.substring(0,10)"
            placeholder="选择出生日期"
            @click="showDatePicker = true"
            :rules="[{ required: true, message: '请选择出生日期' }]"
        />
        <van-popup v-model="showDatePicker" round position="bottom">
          <van-datetime-picker
              v-model="formData.dateValue"
              type="date"
              title="选择年月日"
              :min-date="minDate"
              @cancel="showDatePicker = false"
              @confirm="onDateConfirm($event,formData,'birthday','showDatePicker')"
          />
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="职称"
            :value="formData.titleName"
            placeholder="选择职称"
            @click="showTitlePicker = true"
            :rules="[{ required: true, message: '请选择职称' }]"
        />
        <van-popup v-model="showTitlePicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Title"
                    @cancel="showTitlePicker = false"
                    @confirm="onConfirm($event,formData,'titleName','titleId','showTitlePicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="职务"
            :value="formData['positionName']"
            placeholder="选择职务"
            @click="showPositionPicker = true"
            :rules="[{ required: true, message: '请选择职务' }]"
        />
        <van-popup v-model="showPositionPicker" round position="bottom">
          <m-picker url="/dictionary/getByPositionCodeParams"
                    code="Position"
                    @cancel="showPositionPicker = false"
                    @confirm="onConfirm($event,formData,'positionName','positionId','showPositionPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="政治面貌"
            :value="formData['policyName']"
            placeholder="选择政治面貌"
            @click="showPolicyPicker = true"
            :rules="[{ required: true, message: '请选择政治面貌' }]"
        />
        <van-popup v-model="showPolicyPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="Policy"
                    @cancel="showPolicyPicker = false"
                    @confirm="onConfirm($event,formData,'policyName','policy','showPolicyPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            v-model="formData.identifyNo"
            required
            readonly
            label="证件号"/>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="籍贯(省)"
            :value="formData.provinceName"
            placeholder="选择籍贯(省)"
            @click="showCityPicker = true"
            :rules="[{ required: true, message: '请选择籍贯(省)' }]"
        />
        <van-popup v-model="showCityPicker" round position="bottom">
          <van-picker
              :columns="cityColumns"
              :show-toolbar="true"
              @cancel="showCityPicker = false"
              @confirm="onConfirm($event,formData,'provinceName','birthCityId','showCityPicker',getCityFn)"
          />
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="籍贯(市)"
            :value="formData.cityName"
            placeholder="选择籍贯(市)"
            @click="showMarketPicker = true"
            :rules="[{ required: true, message: '请选择籍贯(市)' }]"
        />
        <van-popup v-model="showMarketPicker" round position="bottom">
          <van-picker :columns="marketColumns" :show-toolbar="true" @cancel="showMarketPicker = false"
                      @confirm="onConfirm($event,formData,'cityName','birthProvinceId','showMarketPicker')"
          />
        </van-popup>

        <van-field
            readonly
            clickable
            required
            name="typeId"
            label="健康状况"
            :value="formData['healthName']"
            placeholder="选择健康状况"
            @click="showHealthConditionPicker = true"
            :rules="[{ required: true, message: '请选择健康状况' }]"
        />
        <van-popup v-model="showHealthConditionPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="HealthCondition"
                    @cancel="showHealthConditionPicker = false"
                    @confirm="onConfirm($event,formData,'healthName','healthStatus','showHealthConditionPicker')"
          ></m-picker>
        </van-popup>

        <van-field
            readonly
            clickable
            name="typeId"
            label="外语水平"
            :value="formData.englishLevelName"
            placeholder="选择外语水平"
            @click="showEnglishLevelPicker = true"
            :rules="[{ required: true, message: '请选择外语水平' }]"
        />
        <van-popup v-model="showEnglishLevelPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams"
                    code="EnglishLevel"
                    @cancel="showEnglishLevelPicker = false"
                    @confirm="onConfirm($event,formData,'englishLevelName','englishLevelId','showEnglishLevelPicker')"
          ></m-picker>
        </van-popup>
        <div style="text-align: center; color: orangered">
          <van-button type="primary" size="mini" @click="showImg=true">查看尺码</van-button>
        </div>
        <van-popup v-model="showImg" @click="showImg = false">
          <van-image style="width: 100vw" :src="require('../assets/advancedsignup/gzf.jpg')" alt="暂无此照片"
          />
        </van-popup>
        <van-field name="diagnosis" readonly clickable required label="工作服尺寸" v-model="formData.clothesSize"
                   placeholder="请选择工作服尺寸" :rules="[{ required: true, message: '请选择工作服尺寸' }]"
                   @click="showClothesPicker = true"
        />
        <!-- <van-field readonly clickable v-model="formData.shoeSize" label="护士鞋码" placeholder="如(36,37,38)" :value="formData.cityName"
            @click="showClothesPicker = true" /> -->

        <van-popup v-model="showClothesPicker" round position="bottom">
          <van-picker :columns="clothesSize" :show-toolbar="true" @cancel="showClothesPicker = false"
                      @confirm="onConfirm($event,formData,'clothesSize','clothesSizeName','showClothesPicker')"
          />
        </van-popup>
        <van-field
                readonly
                clickable
                name="workStartDate"
                required
                label="首次参加工作日期"
                :value="formData.workStartDate&&formData.workStartDate.substring(0,10)"
                placeholder="首次参加工作日期"
                @click="showFirstWorkPicker = true"
                :rules="[{ required: true, message: '首次参加工作日期' }]"
        />
        <van-popup v-model="showFirstWorkPicker" round position="bottom">
          <van-datetime-picker
                  v-model="formData.workStartDate"
                  type="date"
                  title="选择年月日"
                  :min-date="minDate"
                  @cancel="showFirstWorkPicker = false"
                  @confirm="onDateConfirm($event,formData,'workStartDate','showFirstWorkPicker')"
          />
        </van-popup>
<!--        <van-field readonly clickable-->
<!--                   v-model="formData.shoeSize"-->
<!--                   type="number"-->
<!--                   label="护士鞋码"-->
<!--                   placeholder="如(36,37,38)"-->
<!--                   :value="formData.shoeSize"-->
<!--                   @click="showShoePicker = true"-->
<!--        />-->

<!--        <van-popup v-model="showShoePicker" round position="bottom">-->
<!--          <van-picker :columns="shoeSize" :show-toolbar="true" @cancel="showShoePicker = false"-->
<!--                      @confirm="onConfirm($event,formData,'shoeSize','shoeSizeName','showShoePicker')"-->
<!--          />-->
<!--        </van-popup>-->

        <van-field
            name="vocationFlag"
            label="是否住宿"
            required
        >
          <template #input>
            <van-radio-group v-model="formData.lodgmentFlag" direction="horizontal">
              <van-radio :name="true">是</van-radio>
              <van-radio :name="false">否</van-radio>
            </van-radio-group>
          </template>
        </van-field>
      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button style="margin-bottom: 12px;" round block @click="goPre">
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          下一步
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
import {uploadFile, urlForPost, getForCode} from "../http/apiMap";
import mPicker from '../components/m-picker'

export default {
  name: 'sign-info',
  components: {
    mPicker,
  },
  data() {
    return {
      url: {
        city: '/area/listByPage',
        saveStaff: '/advancedsignup/saveOrUpdateStaff',
        advancedSignup: '/advancedsignup/saveOrUpdateAdvancedSignup',
        staffLanguage: '/advancedsignup/saveOrUpdateStaffLanguage',
        removeFile: '/advancedsignupattach/attachDeleteFile',
        staffBatch: '/advancedsignup/getByBatchAndStaff',
        getLanguage: '/advancedsignup/getLanguageByStaff'
      },
      params: {
        province: {
          pageSize: 999,
          pageNum: 1,
          province: 1
        },
        city: {
          pageSize: 999,
          pageNum: 1,
          city: ''
        },
      },
      formData: {},
      showImg: false,
      showSectionPicker: false,
      showNationPicker: false,
      showTitlePicker: false,
      showPositionPicker: false,
      showPolicyPicker: false,
      showClothesPicker: false,
      showShoePicker: false,
      showCityPicker: false,
      showMarketPicker: false,
      showHealthConditionPicker: false,
      showEnglishLevelPicker: false,
      showDatePicker: false,
      showFirstWorkPicker: false,
      cityColumns: [],
      marketColumns: [],
      attach: {},
      projectInfo: JSON.parse(localStorage.getItem('signInfo')),
      minDate: new Date(1960, 1, 1),
      languageInfo: {},
      clothesSize: [
        {
          text: 'AS',
          value: 'AS'
        },
        {
          text: 'S',
          value: 'S'
        },
        {
          text: 'M',
          value: 'M'
        },
        {
          text: 'L',
          value: 'L'
        },
        {
          text: 'XL',
          value: 'XL'
        },
        {
          text: 'XXL',
          value: 'XXL'
        },
        {
          text: 'XXXL',
          value: 'XXXL'
        }
      ],
      shoeSize: [
        {
          text: 34,
          value: 34
        },
        {
          text: 35,
          value: 35
        },
        {
          text: 36,
          value: 36
        },
        {
          text: 37,
          value: 37
        },
        {
          text: 38,
          value: 38
        },
        {
          text: 39,
          value: 39
        }
      ],
      fileList: []
    }
  },
  computed: {},
  methods: {
    onConfirm(value, target, name, id, show, cb) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (cb) {
        cb()
      }
    },
    goPre() {
      this.$router.push({
        path: '/sign-write-tab'
      })
    },
    attendAdd() {
      this.$refs.infoForm.validate().then(() => {
        sessionStorage.setItem('infoData', JSON.stringify(this.formData))
        sessionStorage.setItem('attach', JSON.stringify(this.attach))
        let majorData = JSON.parse(sessionStorage.getItem('majorData'))
        let params = {...this.formData}
        params.hospitalId = this.projectInfo.hospitalId
        // params.sectionId = majorData.sectionStaffId
        // params.majorId = majorData.majorStaffId
        delete params.status
        let languageId = 'c9d38db8-3a70-11e9-bd4b-94c691901e8d'
        urlForPost(this.url.saveStaff, params).then(res => {
          let obj = {
            staffId: res.data.data.id,
            hospitalId: this.projectInfo.hospitalId
          }
          sessionStorage.setItem('staffId', res.data.data.id)

          let pParam = Object.assign(obj, majorData, this.formData)
          // 上传报名信息
          pParam.typeId = localStorage.getItem('AdvancedType')
          pParam.majorId = majorData.majorId
          pParam.sectionId = majorData.sectionId
          pParam.typeCode = this.projectInfo.trainTypeCode
          delete pParam.status
          urlForPost(this.url.advancedSignup, pParam).then(re => {
            if (re.data && re.data.data) {
              sessionStorage.setItem('signupId', re.data.data.id)
            }
          })
          // 上传语言信息
          let param = [{
            languageId: languageId,
            perfectId: this.formData["englishLevelId"],
            staffId: res.data.data.id,
          }]
          if (this.languageInfo && this.languageInfo.id) {
            param[0].id = this.languageInfo.id
          }
          urlForPost(this.url.staffLanguage, param).then(() => {
            this.$router.push({
              path: '/sign-write-contact'
            })
          })
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        this.formData.avator = res.data.path
        file.pathAttach = res.data.path
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    beforeDelete(file) {
      urlForPost(this.url.removeFile, {
        path: file.pathAttach
      }).then()
      return true
    },
    onDateConfirm(value, target, prop, show) {
      target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
      this[show] = false;
    },
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }

      return year + seperator1 + month + seperator1 + strDate;
    },
    // 选择老师的数据
    checkFn(data, target, prop, propId, show) {
      target[propId] = data.value
      target[prop] = data.text
      this[show] = false
    },
    // 获取picker数据格式
    getData(url, params, target, prop = 'name', propId = 'id') {
      urlForPost(url, params).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item[prop],
            value: item[propId]
          }
          optionArr.push(obj)
        })
        this[target] = optionArr
      })
    },
    getCityFn() {
      this.params.city.city = this.formData["birthCityId"]
      this.getData(this.url.city, this.params.city, 'marketColumns')
    },
    getLanguageFn() {

      let data = JSON.parse(sessionStorage.getItem('identifyNoInfo') || '{}')

      if (data.id) {
        urlForPost(this.url.getLanguage, {
          "hospitalId": data.hospitalId,
          "languageCode": "English",
          "staffId": data.id
        }).then(res => {
          this.languageInfo = res.data.data[0]

          if (res.data.data[0] && res.data.data[0]["perfectName"]) {
            let obj = {...this.formData}
            obj.englishLevelName = res.data.data[0]["perfectName"]
            this.formData = obj
          }
        })
      }

    }
  },
  mounted() {
    let info = sessionStorage.getItem('infoData')
    this.getData(this.url.city, this.params.province, 'cityColumns')

    if (info) {
      this.formData = {...JSON.parse(info)}
      if (this.formData.avator) {
        this.fileList = [{url: this.formData.avator, pathAttach: this.formData.avator}]
      }
    } else {
      let identifyNoInfo = JSON.parse(sessionStorage.getItem('identifyNoInfo') || '{}')
      let staffBatchInfo = {};
      let cardInfo = {};
      if (sessionStorage.getItem('staffBatchInfo') !== 'undefined') {
        staffBatchInfo = JSON.parse(sessionStorage.getItem('staffBatchInfo') || '{}')
      }
      if (sessionStorage.getItem('cardInfo') !== 'undefined') {
        cardInfo = JSON.parse(sessionStorage.getItem('cardInfo') || '{}')
      }
      let obj = {}
      if (identifyNoInfo.id || staffBatchInfo.id || cardInfo.id) {
        Object.assign(obj, identifyNoInfo)
        Object.assign(obj, cardInfo)
        this.formData = {...obj}
        this.formData.clothesSize = staffBatchInfo.clothesSize
        this.formData.shoeSize = staffBatchInfo.shoeSize
        this.formData.lodgmentFlag = staffBatchInfo.lodgmentFlag
        if (this.formData.avator) {
          this.fileList = [{url: this.formData.avator, pathAttach: this.formData.avator}]
        }
      } else {
        this.formData.identifyNo = sessionStorage.getItem('identifyNo') || ''
      }
    }
    this.getLanguageFn() // 获取语言信息

    // // 获取头像
    // let avator = JSON.parse(sessionStorage.getItem('uploadData') || '{}')
    // if(avator.path !== ''){
    //     // this.formData[avator.target] = avator.path;
    //     this.$set(this.formData,avator.target,avator.path)
    //     this.attach = avator.path
    //     sessionStorage.setItem('uploadData', '')
    // }
  }
}
</script>
