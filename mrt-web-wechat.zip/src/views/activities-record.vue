<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div>
      <van-dropdown-menu active-color="#17d4b5" v-if="typePage==='0'">
        <van-dropdown-item :options="option1" title="类型" v-model="listParams.typeId" />
        <!--        <van-dropdown-item title="状态" v-model="listParams.status" :options="option2" />-->
      </van-dropdown-menu>
    </div>
    <div>
      <van-search @change="getList" placeholder="搜索" shape="round" v-model="listParams.name" />
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <div :key="data.title" @click="goDetail(data)" style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
        v-for="data in testData">
        <div style="font-size: 14px;display: flex;justify-content: space-between;">
          {{data.subject}}
          <van-tag style="text-align: center" :type="'success'" size="medium" v-if="data.isWrite===1">已填写</van-tag>
          <van-tag style="text-align: center" :type="'warning'" size="medium" v-if="data.isWrite===0">未填写</van-tag>
        </div>
        <van-divider />
        <div style="margin-bottom: 10px">
          <div style="color: #cccccc;margin-bottom: 4px;">活动时间:</div>
          <div>{{data.startDate.substring(0,10)}} {{data.startTime}}-{{data.endTime}}</div>
        </div>
        <div style="margin-bottom: 10px">
          <div style="color: #cccccc;margin-bottom: 4px;">讲师:</div>
          <div>{{data.teacherName}}</div>
        </div>
        <div style="margin-bottom: 10px">
          <div style="color: #cccccc;margin-bottom: 4px;">活动地址:</div>
          <div>{{data.location || '无'}}</div>
        </div>
        <div style="margin-bottom: 10px">
          <div style="color: #cccccc;margin-bottom: 4px;">核心知识:</div>
          <div style="width: 99%;text-overflow: ellipsis;overflow: hidden;white-space: nowrap">{{data.memberRemark || '无'}}</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import { getTeachactivity, getDictionaryType } from '../http/apiMap';
  export default {
    name: 'test',
    data() {
      return {
        listParams: {
          pageSize: 999,
          pageNum: 1,
          typeId: '',
          name: '',
          status: null,
          checkIn: 1,
          notTypeCode: null
        },
        option1: [],
        option2: [
          { text: '全部', value: null },
          { text: '已过期', value: 2 },
          { text: '开展中', value: 1 },
          { text: '未提交', value: 0 },
        ],
        testData: [],
        typePage: ''
      }
    },
    computed: {
      name() {
        return this.$route.name
      }
    },

    methods: {
      goDetail(data) {
        localStorage.setItem('currentData', JSON.stringify(data))
        this.$router.push({
          path: '/activities-write'
        })
      },
      // 获取列表
      getList() {
        getTeachactivity(this.listParams).then(res => {
          this.testData = res.data.list;
          this.testData.forEach(item => {
            if (item.memberRemark) {
              item.isWrite = 1
            } else {
              item.isWrite = 0
            }
          })
        })
      },
      // 获取类型
      getTypeList() {
        getDictionaryType('TeachActivityType').then(res => {
          let data = res.data.data
          let arr = [{
            text: '全部',
            value: ''
          }]
          data.forEach(item => {
            if (item.name !== '入科教育') {
              let obj = {
                text: item.name,
                value: item.id
              }
              arr.push(obj)
            }
          })
          this.option1 = arr;
        })
      }
    },
    mounted() {
      let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
      let len = Object.keys(newData).length
      if (len !== 0) {
        newData.status = 2
        this.testData.unshift(newData);
        localStorage.setItem('addItem', '')
      }
      this.typePage = this.$route.query[0];
      if (this.typePage === '1') {
        this.listParams.typeId = '63e37fba-85df-11ea-8355-00163e0603fa'
      } else if (this.typePage === '0') {
        this.listParams.notTypeCode = "admission_training";
      }
      this.getList();
      this.getTypeList();
    },
  }
</script>
