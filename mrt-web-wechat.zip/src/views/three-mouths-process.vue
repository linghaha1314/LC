<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">
      <div v-if="processType===1">
        <van-field name="outpatientFlag" label="是否同意" required :value="formData.status"
                   :rules="[{ required: true, message: '请选择是否同意'}]">
          <template #input>
            <van-radio-group v-model="formData.status" direction="horizontal" @change="radioFn">
              <van-radio :name="0">不同意</van-radio>
              <van-radio :name="1">同意</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field v-if="formData.status===1" v-model="formData.teachOpinion" name="content" required label="老师评价"
                   placeholder="请输入老师评价" type="textarea" rows="5" show-word-limit :autosize="true"
                   :rules="[{ required: true, message: '请填写老师评价'}]"
        />
        <div v-if="formData.status===0">
          <van-field v-if="formData.status===0" name="outpatientFlag" label="老师评价" required
                     :value="formData.teachOpinion" :rules="[{ required: true, message: '请选择老师评价'}]">
            <template #input v-if="formData.status===0">
              <van-radio-group v-model="formData.teachOpinion" direction="horizontal" v-if="formData.status===0">
                <van-radio name="个人鉴定不客观或属实，请结合实际进修学习情况修改后重新提交。">个人鉴定不客观或属实，请结合承担工作和实际学习情况修改后重新提交。</van-radio>
              </van-radio-group>
            </template>
          </van-field>
        </div>

        <div style="margin: 16px;">
          <van-button round block color="#17d4b5" @click="onSubmit">
            审批
          </van-button>
        </div>
      </div>

      <div v-if="processType===2">
        <van-field v-model="formData.theoryScore" type="number" readonly label="理论成绩"/>
        <van-field v-model="formData.skillScore" type="number" required label="技能成绩"
                   :rules="[{ required: true, message: '请填写技能成绩'}]"/>
        <van-field v-model="formData.conductScore" type="number" required label="品行成绩"
                   :rules="[{ required: true, message: '请填写品行成绩'}]"/>
        <van-field v-model="formData['businessScore']" type="number" required label="业务能力"
                   :rules="[{ required: true, message: '请填写业务能力'}]"/>
        <van-field v-model="formData['moralScore']" type="number" required label="医德医风"
                   :rules="[{ required: true, message: '请填写医德医风'}]"/>
        <van-field v-model="formData['disciplineScore']" type="number" required label="组织纪律"
                   :rules="[{ required: true, message: '请填写组织纪律'}]"/>
        <van-field v-model="studentInfo.affairDays" type="number" readonly label="事假"
                   :rules="[{ required: true, message: '请填写事假'}]"/>
        <van-field v-model="studentInfo['sickDays']" type="number" readonly label="病假"
                   :rules="[{ required: true, message: '请填写病假'}]"/>
        <van-field v-model="studentInfo['absenteeismDays']" type="number" required label="旷工"
                   :rules="[{ required: true, message: '请填写旷工'}]"/>
        <van-field name="outpatientFlag" label="是否同意" required :value="formData.status"
                   :rules="[{ required: true, message: '请选择是否同意'}]">
          <template #input>
            <van-radio-group v-model="formData.status" direction="horizontal">
              <van-radio :name="0">不同意</van-radio>
              <van-radio :name="1">同意</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <van-field name="sectionOpinion" label="科室考评" required :value="formData.sectionOpinion"
                   :rules="[{ required: true, message: '请选择科室考评'}]">
          <template #input>
            <van-radio-group v-model="formData.sectionOpinion" direction="horizontal">
              <van-radio v-if="formData.status===1" style="border-bottom: 1px solid #cccccc"
                         name="同意进修学员个人鉴定及带教老师评语，通过前期三个月对常规流程和本专业部分“三基”进行培训，达到我科进修学员阶段性培养要求，且能在带教老师的指导下，能较好的完成资质允许内的部分工作，考核合格。">
                同意学员个人鉴定及带教老师评语，该生达到我科进修学员能力提升培养要求，考核合格。
              </van-radio>
              <van-radio v-if="formData.status===0" style="border-bottom: 1px solid #cccccc"
                         name="该生未能达到我科进修学员前期阶段培养和考核要求，不能在带教老师的指导下胜任临床及其相关工作，考核不合格。">该生未能达到我科进修学员能力提升培养要求，考核不合格。
              </van-radio>
              <van-radio v-if="formData.status===0" style="border-bottom: 1px solid #cccccc"
                         name="不同意进修学员个人鉴定，请修改后重新提交。">不同意进修学员个人鉴定，请修改后重新提交。
              </van-radio>
              <van-radio v-if="formData.status===0" style="border-bottom: 1px solid #cccccc" name="不同意带教老师评语，请修改后重新提交。">
                不同意带教老师评语，请修改后重新提交。
              </van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <div style="margin: 16px;">
          <van-button round block color="#17d4b5" @click="onSubmit">
            审批
          </van-button>
        </div>
      </div>

      <div v-if="processType===3">
        <van-field name="outpatientFlag" label="是否同意" required :value="formData.status"
                   :rules="[{ required: true, message: '请选择是否同意'}]">
          <template #input>
            <van-radio-group v-model="formData.status" direction="horizontal">
              <van-radio :name="0">不同意</van-radio>
              <van-radio :name="1">同意</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <!--                <van-field type="textarea" rows="5" name="deptOpinion" label="部门考评" required v-model="formData.deptOpinion" :rules="[{ validator:(val)=>val.length>30, message: '请填写部门考评不少于30字'}]">-->
        <van-field name="deptOpinion" label="部门考评" required :value="formData.deptOpinion"
                   :rules="[{ required: true, message: '请选择部门考评'}]">
          <template #input>
            <van-radio-group v-model="formData.deptOpinion" direction="horizontal">
              <van-radio v-if="formData.status===1" name="同意科室考核意见，考核合格。">同意科室考核意见，考核合格。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意。">不同意。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意个学员人鉴定。">不同意学员个人鉴定。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意带教老师评语。">不同意带教老师评语。</van-radio>
              <van-radio v-if="formData.status===0" name="不同意科室考核意见。">不同意科室考核意见。</van-radio>
            </van-radio-group>
          </template>
        </van-field>

        <div style="margin: 16px;">
          <van-button round block color="#17d4b5" @click="onSubmit">
            审批
          </van-button>
        </div>
      </div>

    </van-form>
  </div>
</template>
<script>
import {
  getApplyInfo,
  getAuthType,
  getStudentDetail,
  threemonthApproval,
  getTheoryScoreByStudentId,
  getThreemonthAttendance,
  updateThreemonthAttendance
} from '../http/apiMap.js'
import {Dialog} from 'vant';

export default {
  name: 'test',
  data() {
    return {
      formData: {},
      studentInfo: {},
      disabled: false,
      processType: 2,
      queryData: this.$route.query
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          this.formData.taskId = this.queryData.taskId
          this.formData.projectId = this.queryData.id
          this.formData.processInstanceId = this.queryData.processInstanceId
          delete this.formData.id
          updateThreemonthAttendance({
            threeMonthCheckId: this.queryData.id,
            ...this.studentInfo
          }).then()
          threemonthApproval(this.formData).then(res => {
            this.$toast.success(res.data.msg || '操作成功!')
            this.$router.go(-1)
          })

        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },

    // 获取学员结业信息
    getApplyInfoFn() {
      let studentId = this.queryData.studentId || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
      })
    },
    getAuthTypeFn(cb) {
      getAuthType().then(res => {
        let data = res.data.data;
        if (data === 'personal') {
          this.processType = 1
        } else if (data === 'section') {
          this.processType = 2
        } else {
          this.processType = 3
        }
        cb()
      })
    },
    radioFn() {
      this.formData.teachOpinion = ''
    },
    getStudentDetailFn() {
      let query = this.$route.query
      getStudentDetail(query.id).then(res => {
        let info = JSON.parse(res.data.data)
        this.formData.affairDays = info.affairDays
        this.formData.illnessDays = info.illnessDays
        this.formData.theoryScore = info.theory
      })
    },
    getTheoryScoreByStudentIdFn() {
      let studentId = this.queryData.studentId || ''
      getTheoryScoreByStudentId({
        studentId
      }).then(res => {
        if (res.data.data && res.data.success) {
          this.formData.theoryScore = res.data.data.theoryScore
        }
      })
    }
  },
  mounted() {
    let query = this.$route.query
    this.getAuthTypeFn(() => {
      if (this.processType === 2) {
        getThreemonthAttendance({
          "threeMonthCheckId": this.queryData.id
        }).then(res => {
          if (res.data.list && res.data.list.length !== 0) {
            this.studentInfo = {...res.data.list[0]}
          } else {
            this.$toast.fail('数据出错了!')
          }
        })
      }
    })
    if (query.id) {
      this.formData = {...query}
      this.formData.status = parseInt(this.formData.status)
    } else {
      this.getApplyInfoFn()
    }
    this.getTheoryScoreByStudentIdFn()
  }
}
</script>
