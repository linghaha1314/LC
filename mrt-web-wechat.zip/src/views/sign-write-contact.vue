<template>
    <div class="about">
    <van-nav-bar title="联系方式" left-arrow>
        <template #left>
            <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
        </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
        <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
            联系方式填写
        </div>
    </div>
    <div>
        <van-form ref="contactForm">
        <van-field
            v-model="formData.mobile"
            type="number"
            label="手机号码"
            required
            placeholder="请输入手机号码"
            :rules="[{ pattern:/^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/, message: '请填写正确手机号' }]"
        />

        <van-field
            name="email"
            clickable
            required
            label="电子邮箱"
            v-model="formData.email"
            placeholder="请输入电子邮箱"
            :rules="[{ pattern, message: '请输入正确电子邮箱' }]"
        />

        <van-field
            v-model="formData.qq"
            type="number"
            label="QQ号码"
            placeholder="请输入QQ号码"
        />

        <van-field
            name="wechat"
            clickable
            label="微信号"
            v-model="formData.wechat"
            placeholder="请输入微信号"
        />

        <van-field
            name="contactName"
            clickable
            required
            label="紧急联系人"
            v-model="formData.contactName"
            placeholder="请输入紧急联系人"
            :rules="[{ required: true, message: '请输入紧急联系人' }]"
        />

        <van-field
            v-model="formData.contactPhone"
            type="number"
            required
            label="紧急联系人手机"
            placeholder="请输入紧急联系人手机"
            :rules="[{ pattern:/^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/, message: '请填写正确手机号' }]"
        />

        <van-field
            name="homeAddress"
            clickable
            required
            label="家庭地址"
            v-model="formData.homeAddress"
            placeholder="请输入家庭地址"
            :rules="[{ required: true, message: '请输入家庭地址' }]"
        />

        <van-field
            v-model="formData.homePhone"
            type="number"
            label="家庭电话"
            placeholder="请输入家庭电话"
        />
      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button style="margin-bottom: 12px;" round block @click="goPre">
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          下一步
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
    import {urlForPost} from "../http/apiMap";

    export default {
        name: 'contact',
        components:{
            // mPicker
        },
        data(){
            return{
                url:{
                    saveStaff: '/advancedsignup/saveOrUpdateStaff'
                },
                formData:{
                },
                // eslint-disable-next-line
                pattern:/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                projectInfo: JSON.parse(localStorage.getItem('signInfo')),
            }
        },
        computed:{

        },
        methods:{
            goPre(){
                this.$router.push({
                    path: '/sign-write-info'
                })
            },
            attendAdd(){
                this.$refs.contactForm.validate().then(() => {
                    sessionStorage.setItem('contactData', JSON.stringify(this.formData))
                    let param = {...this.formData,
                        id: sessionStorage.getItem('staffId'),
                        hospitalId: this.projectInfo.hospitalId
                    }
                    urlForPost(this.url.saveStaff,param).then(() => {
                        this.$router.push({
                            path: '/sign-write-certificate'
                        })
                    })
                    
                }).catch(() => {
                    this.$toast.fail('请正确填写表单!')
                })
            },

        },
        mounted() {
            let info = sessionStorage.getItem('contactData')
            if (info) {
                this.formData = {...JSON.parse(info)}
            } else {
                let identifyNoInfo = JSON.parse(sessionStorage.getItem('identifyNoInfo') || '{}')
                let staffBatchInfo = {};
                if (sessionStorage.getItem('staffBatchInfo') !== 'undefined') {
                    staffBatchInfo = JSON.parse(sessionStorage.getItem('staffBatchInfo') || '{}')
                }
                let obj = {}
                if (identifyNoInfo.id || staffBatchInfo.id) {
                    obj.mobile = identifyNoInfo.mobile
                    obj.email = identifyNoInfo.email
                    obj.qq = identifyNoInfo.qq
                    obj.wechat = identifyNoInfo.wechat
                    obj.contactName = identifyNoInfo.contactName
                    obj.contactPhone = identifyNoInfo.contactPhone
                    obj.homeAddress = identifyNoInfo.homeAddress
                    obj.homePhone = identifyNoInfo.homePhone
                    obj.id = identifyNoInfo.id
                    this.formData = { ...obj }
                    if (sessionStorage.getItem('mobile')) {
                        this.formData.mobile = parseInt(sessionStorage.getItem('mobile'))
                    }
                } else {
                    if (sessionStorage.getItem('mobile')) {
                        obj.mobile = parseInt(sessionStorage.getItem('mobile'))
                        this.formData = {...obj}
                    }
                }
            }
        }
    }
</script>