<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <template #right v-if="role !== 'StudentType_jxs'">
        <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">我的</span>
        <span v-if="isMine" style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>
      </template>
    </van-nav-bar>
    <div>
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.sectionId" :options="option1" @change="leaveReturnListGet"/>
        <van-dropdown-item title="状态" v-model="listParams.status" :options="option2" @change="leaveReturnListGet"/>
      </van-dropdown-menu>
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData" :key="data.title"
          >
            <van-checkbox v-if="role !== 'StudentType_jxs'"
                          v-model="data.checked"
                          shape="square"
                          checked-color="#17d4b5"
                          @change="changeChecked(data)"
            >{{ data.date }}
            </van-checkbox>
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
              {{ data.studentName }}
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">已销假</van-tag>
              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">已驳回</van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===0" size="medium">未提交</van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===11" size="medium">审批中</van-tag>
            </div>
            <van-divider/>
            <div>
              <div style="margin-bottom: 10px">
                <div>请假类型: {{ data.typeName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>带教老师: {{ data.medicalTeamLeaderName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>科室: {{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>时间:
                  {{ data['applyStartDate'].substring(0, 10) }}
                  ~ {{ data['applyEndDate'].substring(0, 10) }}
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              <van-button style="width: 50px; margin-right: 12px"
                          size="mini" @click="goDetail(data)">查看
              </van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>

    <div style="position: fixed;left: 0;bottom: 0;width: 100vw;"
         v-if="role !== 'StudentType_jxs' && !isMine"
    >
      <van-button style="width: 50%" type="warning" @click="throughFn(0)">不通过</van-button>
      <van-button style="width: 50%" color="#17d4b5" @click="throughFn(1)">通过</van-button>
    </div>
  </div>
</template>
<script>
import {getLeaveReturn, getLeavereturnList, getLeavereturnApprovalProcess} from '../http/apiMap.js'

import {Dialog} from "vant";
import {getTransferSchedule} from "../http/apiMap";

export default {
  name: 'test',
  data() {
    return {
      listParams: {
        pageSize: 999,
        pageNum: 0,
        sectionId: '',
        status: null,
      },
      option1: [],
      option2: [
        {text: '全部', value: null},
        {text: '未提交', value: 0},
        {text: '已驳回', value: 1},
        {text: '已通过', value: 2},
        {text: '审批中', value: 11},
      ],
      testData: [],
      role: '',
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      isMine: false,
      state:{
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.transferGet() // 获取科室列表
  },
  methods: {
    goDetail(data) {

      localStorage.setItem('leaveBinData', JSON.stringify(data))
      this.$router.push({
        path: '/leave-binform'
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;


      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveReturnListGet(flag)
    },
    // 获取销假列表
    leaveReturnListGet(f) {
      let params = {
        ...this.listParams
      }
      if (this.role === 'StudentType_jxs' || this.isMine) {
        getLeaveReturn(params).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.list]
          }else{
            this.testData = [...res.data.list];
          }
          // this.testData = res.data.list
        })
      } else {
        getLeavereturnList(params).then(res => {
          if(f==='onLoad'){
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            this.testData = [...this.testData,...res.data.list]
          }else{
            this.testData = [...res.data.list];
          }
        })
      }

    },
    // 审批
    throughFn(num) {
      let target = {}
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          target = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选请假信息!')
      } else {

        let msg = num === 1 ? `确认要同意他的销假申请吗？` : '确认拒绝申请么?'
        Dialog.confirm({
          title: '温馨提示:',
          message: msg,
          confirmButtonColor: '#17d4b5'
        }).then(() => {

          let param = {
            "opinion": num === 1 ? "同意" : "不同意",
            "processInstanceId": target.processInstanceId,
            "projectId": target.id,
            "status": num,
            "retryStatus": 0,
            "taskId": target.taskId,
          }
          getLeavereturnApprovalProcess(param).then(res => {
            this.$toast.success(res.data.msg)
            this.leaveReturnListGet();
          })
        }).catch(() => {
          this.$toast.success('请联系管理员')
        })
      }
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option1 = [...optionArr]
      })
    },
    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.leaveReturnListGet()
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    }
  }
}
</script>
