<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveBinForm">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
<!--      <van-field-->
<!--          v-if="currentData.status === 0"-->
<!--          readonly-->
<!--          clickable-->
<!--          required-->
<!--          name="riskName"-->
<!--          label="风险等级"-->
<!--          :value="formData['riskName']"-->
<!--          placeholder="选择风险等级"-->
<!--          @click="showRiskPicker = true"-->
<!--          :rules="[{ required: true, message: '请选择风险等级' }]"-->
<!--      />-->
<!--      <van-popup v-model="showRiskPicker" round position="bottom">-->
<!--        <m-picker url="/dictionary/getByTypeCodeParams"-->
<!--                  code="RiskLevel"-->
<!--                  @cancel="showRiskPicker = false"-->
<!--                  @confirm="onConfirm($event,formData,'riskName','riskName','showRiskPicker')"-->
<!--        ></m-picker>-->
<!--      </van-popup>-->
      <!--      <van-field-->
      <!--              v-if="currentData.status === 0"-->
      <!--              readonly-->
      <!--              clickable-->
      <!--              name="nucleicDate"-->
      <!--              required-->
      <!--              label="核酸报告日期"-->
      <!--              :value="formData.nucleicDate&&formData.nucleicDate.substring(0,10)"-->
      <!--              placeholder="选择核酸报告日期"-->
      <!--              @click="showNucleicPicker = true"-->
      <!--              :rules="[{ required: true, message: '请选择核酸报告日期' }]"-->
      <!--      />-->
      <!--      <van-popup v-model="showNucleicPicker" round position="bottom">-->
      <!--        <van-datetime-picker-->
      <!--                v-model="formData.dateValue"-->
      <!--                type="date"-->
      <!--                title="选择年月日"-->
      <!--                :min-date="minDate"-->
      <!--                @cancel="showNucleicPicker = false"-->
      <!--                @confirm="onDateConfirmF($event,formData,'nucleicDate','showNucleicPicker')"-->
      <!--        />-->
      <!--      </van-popup>-->
      <!--      <van-field-->
      <!--              v-if="currentData.status === 0"-->
      <!--              readonly-->
      <!--              clickable-->
      <!--              required-->
      <!--              name="nucleicName"-->
      <!--              label="核酸结果"-->
      <!--              :value="formData['nucleicName']"-->
      <!--              placeholder="选择核酸结果"-->
      <!--              @click="showNucleicAcidPicker = true"-->
      <!--              :rules="[{ required: true, message: '请选择核酸结果' }]"-->
      <!--      />-->
      <!--      <van-popup v-model="showNucleicAcidPicker" round position="bottom">-->
      <!--        <m-picker url="/dictionary/getByTypeCodeParams"-->
      <!--                  code="NucleicAcidResults"-->
      <!--                  @cancel="showNucleicAcidPicker = false"-->
      <!--                  @confirm="onConfirm($event,formData,'nucleicName','nucleicName','showNucleicAcidPicker')"-->
      <!--        ></m-picker>-->
      <!--      </van-popup>-->
      <van-field
          name="vocationFlag"
          label="是否已休假"
          required
          v-if="currentData.status === 0">
        <template #input>
          <van-radio-group v-model="formData.vocationFlag" direction="horizontal">
            <van-radio name="1">是</van-radio>
            <van-radio name="0">否</van-radio>
          </van-radio-group>
        </template>
      </van-field>
      <van-field
              v-if="currentData.status === 0  && formData.vocationFlag==='1'"
              readonly
              clickable
              required
              name="tripName"
              label="返回方式"
              :value="formData['tripName']"
              placeholder="选择返回方式"
              @click="showTripPicker = true"
              :rules="[{ required: true, message: '请选择返回方式' }]"
      />
      <van-popup v-model="showTripPicker" round position="bottom">
        <m-picker url="/dictionary/getByTypeCodeParams"
                  code="TripMode"
                  @cancel="showTripPicker = false"
                  @confirm="onConfirm($event,formData,'tripName','tripName','showTripPicker')"
        ></m-picker>
      </van-popup>

      <van-field v-if="currentData.status === 0  && formData.vocationFlag==='1'" v-model="formData.placeOfDeparture" name="placeOfDeparture" label="出发地点" required placeholder="填写出发地点"
                 :rules="[{ required: true, message: '请填写出发地点' }]"
      />
      <van-field
              v-if="currentData.status === 0  && formData.vocationFlag==='1'"
              readonly
              clickable
              name="arrivingDate"
              required
              label="抵达日期"
              :value="formData.arrivingDate&&formData.arrivingDate.substring(0,10)"
              placeholder="选择抵达日期"
              @click="showArrivingPicker = true"
              :rules="[{ required: true, message: '请选择抵达日期' }]"
      />
      <van-popup v-model="showArrivingPicker" round position="bottom">
        <van-datetime-picker
                v-model="formData.dateValue"
                type="date"
                title="选择年月日"
                :min-date="minDate"
                @cancel="showArrivingPicker = false"
                @confirm="onDateConfirmF($event,formData,'arrivingDate','showArrivingPicker')"
        />
      </van-popup>

      <van-field
          v-if="formData.vocationFlag==='1' && currentData.status === 0"
          readonly
          clickable
          name="startDate"
          required
          label="开始时间"
          :value="formData.startDate&&(formData.startDate.substring(0,10)+' '+columnsValue)"
          placeholder="选择开始时间"
          @click="showDatePicker = true"
          :rules="[{ required: true, message: '必须选择开始时间' }]"
      />
      <van-popup v-model="showDatePicker" round position="bottom">
        <div style="">
          <van-datetime-picker
              v-model="formData.currentDate"
              type="date"
              @cancel="showDatePicker = false"
              @confirm="onDateConfirm"
              :min-date="minDate"
          />
          <van-picker :columns="columns1" @change="onChange"/>
        </div>
      </van-popup>

      <van-field
          v-if="formData.vocationFlag==='1' && currentData.status === 0"
          v-model="formData.days"
          name="days"
          type="number"
          required
          label="请假时长(天)" @change="leaveNum"
          :rules="[{ required: true, message: '必须填写请假时长' }]"
      />

      <van-field
          v-if="formData.vocationFlag==='1' && currentData.status === 0"
          readonly
          name="endDate"
          label="结束时间"
          :value="formData.endDate&&formData.endDate.substring(0,10)"
      />
      <van-field
          v-if="currentData.status === 0"
          v-model="formData.remake"
          name="remake"
          label="备注"
          placeholder="请填写备注"
      />
      <van-cell title="销假状态"
                v-if="currentData.status !== 0"
      >
        <template #default>
          <div v-if="currentData.status===2" style="color: #17D4B5">
            已通过
          </div>
          <div v-if="currentData.status===11" style="color: #1a1aff">
            审核中
          </div>
          <div v-if="currentData.status===1" style="color: #ff3333">
            已驳回
          </div>
        </template>
      </van-cell>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <van-cell-group>
        <van-cell title="请假类型" :value="currentData.typeName"/>
        <van-cell title="请假天数(天)" :value="currentData.days || currentData.leaveDays"/>
        <van-cell title="原因" :value="currentData.reason"/>
        <van-cell title="风险等级" :value="currentData.riskName"/>
        <van-cell title="出行方式" :value="currentData.tripName"/>
        <div
            style="display: flex;justify-content: space-between;width: 100%;padding: 0 12px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            申请时间:
          </div>
          <div style="color: #3E3E3E">
            {{ currentData.created }}
          </div>
        </div>
        <div
            style="display: flex;justify-content: space-between;width: 100%;padding: 0 12px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            带教老师:
          </div>
          <div style="color: #3E3E3E">
            {{ currentData.medicalTeamLeaderName || '无' }}
          </div>
        </div>
        <div
            style="display: flex;justify-content: space-between;width: 100%;padding: 0 12px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            请假事由:
          </div>
          <div style="color: #3E3E3E">
            {{ currentData.typeName }}
          </div>
        </div>
        <div
            style="display: flex;justify-content: space-between;width: 100%;padding: 0 12px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            开始时间:
          </div>
          <div style="color: #3E3E3E" v-if="currentData['applyStartDate']">
            {{ currentData['applyStartDate'].substring(0, 10) + ' ' + (currentData['applyStartDate'].substring(10).indexOf('13') > 0 ? '下午' : '上午') }}
          </div>
        </div>
        <div
            style="display: flex;justify-content: space-between;width: 100%;padding: 0 12px 10px;box-sizing: border-box;font-size: 12px">
          <div style="color: #B0B0B0">
            结束时间:
          </div>
          <div style="color: #3E3E3E" v-if="currentData['applyEndDate']">
            {{ currentData['applyEndDate'].substring(0, 10) }}
          </div>
        </div>
      </van-cell-group>
      <div style="margin: 16px;" v-if="currentData.status !== 0 || processData.length !== 0">
        <div>审批进度</div>
        <van-steps direction="vertical" :active="processNum">
          <van-step v-for="process in processData" :key="process.title">
            <div style="display: flex; align-items: center">
              <van-image
                  round
                  width="40px"
                  height="40px"
                  src="https://img.yzcdn.cn/vant/cat.jpeg"
              />
              <span style="margin: 0 16px; color: #3E3E3E; font-size: 14px">
                {{ process['stepName'] || '无' }}: {{ process.name || '无' }}
              </span>
              <div>
                <van-tag style="text-align: center"
                         v-if="process['deleteReason'] === 'completed' && process.status === '1'" type="success">已通过
                </van-tag>
                <van-tag style="text-align: center" v-if="process['deleteReason'] !== 'completed'" type="warning">待审批
                </van-tag>
                <van-tag style="text-align: center"
                         v-if="process['deleteReason'] === 'completed' && process.status !== '1'" type="danger">已拒绝
                </van-tag>
              </div>
            </div>
            <div>审核意见: {{ process.opinion || '无' }}</div>
          </van-step>
        </van-steps>
      </div>
      <div style="margin: 16px;">
        当前审批人: {{ msg }}
      </div>
      <div style="margin: 16px;" v-if="currentData.status === 0">
        <van-button round block color="#17d4b5" @click="onSubmit">
          提交申请
        </van-button>
      </div>
      <div style="margin: 16px;" v-if="currentData.status===1">
        <van-button round block color="#17d4b5" @click="goToAdd">
          重新提交
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {getLeaveReturnStartProcess, getFlowData} from '../http/apiMap.js'
import mPicker from '../components/m-picker'

export default {
  name: 'test',
  components: {
    mPicker
  },
  data() {
    return {
      formData: {
        days: 1,
        address: '',
        peopleValue: '',
        dateValue: '',
        startDate: '',
        startValue: '',
        endDate: '',
        typeValue: '',
        content: '',
        remake: '',
        uploader: [],
        number: 1,
        dateEnd: '',
        vocationFlag: '1',
        currentDate: null,
        currentEndDate: null
      },
      currentData: {},
      showDatePicker: false,
      showArrivingPicker: false,
      showEndDatePicker: false,
      showTripPicker: false,
      showRiskPicker: false,
      showNucleicAcidPicker: false,
      showNucleicPicker: false,

      action: 3,
      minDate: new Date(2021, 0, 1),
      maxDate: new Date(2025, 10, 1),
      currentDate: new Date(),
      processNum: -1,
      processData: [],
      msg: '',
      columns1: ['上午', '下午'],
      columnsValue: ''
    }
  },
  computed: {
    name() {
      return this.$route.name
    },
  },
  methods: {
    onSubmit() {
      this.$refs.leaveBinForm.validate().then(() => {
        let param
        if (this.formData.vocationFlag === '1') {
          param = {
            id: this.currentData.id,
            leaveId: this.currentData.leaveId,
            days: this.formData.days,
            endDate: this.formData.endDate,
            startDate: this.formData.startDate,
            remark: this.formData.remake,
            riskName: this.formData.riskName,
            tripName: this.formData.tripName,
            placeOfDeparture: this.formData.placeOfDeparture,
            arrivingDate: this.formData.arrivingDate,
            nucleicDate: this.formData.nucleicDate,
            nucleicName: this.formData.nucleicName,
            vocationFlag: parseInt(this.formData.vocationFlag) //是否已休假 0-是 1-否
          }
        } else {
          param = {
            id: this.currentData.id,
            leaveId: this.currentData.leaveId,
            remark: this.formData.remake,
            vocationFlag: parseInt(this.formData.vocationFlag) //是否已休假 0-是 1-否
          }
        }
        getLeaveReturnStartProcess(param).then(() => {
          this.$router.go(-1)
        })
        // localStorage.setItem('addItem',JSON.stringify(data))
      })
    },
    onConfirm(value, target, name, id, show, cb) {
      target[id] = value.value
      target[name] = value.text
      this[show] = false;
      if (cb) {
        cb()
      }
    },
    onDateConfirmF(value, target, prop, show) {
      target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
      this[show] = false;
    },
    onDateConfirm(value) {
      let yy = value.getFullYear(),
          mm = value.getMonth(),
          dd = value.getDate();
      this.formData.startDate = this.getNowFormatDate(new Date(yy, mm, dd, this.columnsValue === '下午' ? 13 : 9), 0, 0) + ':00:00';
      this.formData.currentDate = new Date(yy, mm, dd)
      let endDD = new Date(yy, mm, dd).valueOf() + ((this.columnsValue === '下午' ? 0.5 : 0) + parseFloat(this.formData.days)) * (1000 * 60 * 60 * 24)-1
      this.formData.currentEndDate = new Date(endDD)

      this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      if (this.columnsValue === '') {
        this.columnsValue = '上午'
      }
      this.showDatePicker = false;
      // this.formData.startDate = this.getNowFormatDate(value) + ':00:00';
      // this.formData.currentDate = value
      // let time = value.valueOf();
      // let days = 0
      // if (this.formData.currentEndDate) {
      //   days = (this.formData.currentEndDate.valueOf() - time) / (1000 * 60 * 60 * 24)
      //   if (days.toString().indexOf('.') > 0) {
      //     days = days.toString().split('.')[0] + '.5'
      //   }
      //   this.formData.days = parseFloat(days)
      // }
      // this.showDatePicker = false;
    },
    onEndDateConfirm(value) {
      this.formData.endDate = this.getNowFormatDate(value) + ':00:00';
      this.formData.currentEndDate = value
      let time = value.valueOf();
      let days = (time - this.formData.currentDate.valueOf()) / (1000 * 60 * 60 * 24)
      if (days.toString().indexOf('.') > 0) {
        days = days.toString().split('.')[0] + '.5'
      }
      this.formData.days = parseFloat(days)
      this.showEndDatePicker = false;
    },
    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      return year + seperator1 + month + seperator1 + strDate;
    },
    // 请假时长
    leaveNum() {
      // this.attachFlag = this.formData.days >= 3;
      // if (this.formData.days > this.leaveDays) {
      //   this.$toast.fail('剩下休假时间不足!')
      //   this.formData.days = this.leaveDays
      //   this.disabled = false
      // } else {
      //   this.disabled = false
      // }
      // if (this.formData.currentDate) {
      //   let endDD = this.formData.currentDate.valueOf() + (Math.ceil((this.columnsValue === '下午' ? 0 : 0.5) + parseFloat(this.formData.days)) - 1) * (1000 * 60 * 60 * 24)
      //   this.formData.currentEndDate = new Date(endDD)
      //   this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      // } else {
      //   this.$toast.fail('请先选择起始时间!')
      // }
      if (this.formData.days > this.leaveDays) {
        this.$toast.fail('剩下休假时间不足,已改为最大天数!')
        this.formData.days = this.leaveDays
      }
      if (this.formData.currentDate) {
        let endDD = this.formData.currentDate.valueOf() + ((this.columnsValue === '下午' ? 0.5 : 0) + parseFloat(this.formData.days)) * (1000 * 60 * 60 * 24)-1
        this.formData.currentEndDate = new Date(endDD)
        this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      } else {
        this.formData.days = 0
        this.$toast.fail('请先选择起始时间!')
      }
    },
    // 重新提交
    goToAdd() {
      this.currentData.status = 0;
    },
    // 获取审批进程
    getFlowDataFn() {
      let param = {
        "processInstanceId": this.currentData.processInstanceId,
        "businessId": this.currentData.id
      }
      getFlowData(param).then(res => {
        this.msg = res.data.data;
        this.processData = res.data.list || []
        if (this.processData.length !== 0) {
          this.getActionNum();
        }
      })
    },
    getActionNum() {
      for (let i = 0; i < this.processData.length; i++) {
        if (this.processData[i]["deleteReason"] === 'completed') {
          this.processNum = i
        }
      }
    },
    // 筛选时间
    filterFn(type, options) {
      if (type === 'hour') {
        let arr = []
        options.forEach(item => {
          if (parseInt(item) === 9 || parseInt(item) === 13) {
            arr.push(item)
          }
        })
        return options = arr;
      }
      return options;
    },
    onChange(picker, value) {
      this.columnsValue = value
    },
  },
  mounted() {
    let currentForm = JSON.parse(localStorage.getItem('leaveBinData') || "{}")
    this.currentData = currentForm;
    let len = Object.keys(currentForm).length
    if (len === 0) {
      this.action = 3
    } else {
      this.action = currentForm.status
      this.formData = Object.assign(this.formData, currentForm)
    }
    localStorage.setItem('leaveBinData', '')
    this.getFlowDataFn(); // 获取进程
  }
}
</script>
