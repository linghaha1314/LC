<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>

    <div v-if="role !== 'StudentType_jxs'">
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item v-if="role === 'JXS_manager'" title="年度" v-model="listParams.enrollYear" @change="onRefresh" :options="option1"/>
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.mobileSectionId" @change="onRefresh" :options="option2"/>
        <van-dropdown-item title="状态" v-model="listParams.status" @change="onRefresh" :options="option3"/>
        <van-dropdown-item title="批次" v-model="listParams.batchId" @change="onRefresh" :options="option4"/>
      </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <div>
        <van-search v-model="listParams.name" shape="round" @change="onRefresh" placeholder="搜索"/>
      </div>
      <div style="background: #f6f6f6; padding: 12px;">
        <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
          <van-list
              v-model="state.loading"
              :finished="state.finished"
              finished-text="没有更多了"
              @load="onLoad"
          >
            <div
                style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
                v-for="data in testData"
                :key="data.title">
              <div @click="goDetail(data)">
                <div style="font-size: 14px;display: flex;justify-content: space-between;">
                  {{ data['staffName'] || '无' }}
                  <div style="width: 4em; margin-left: 12px">
                    <van-tag style="text-align: center" :type="'warning'" v-if="data.status===3" size="medium">等待科室遴选
                    </van-tag>
                    <van-tag style="text-align: center" :type="'danger'" v-if="data.status===2" size="medium">已驳回
                    </van-tag>
                    <van-tag style="text-align: center" :type="'warning'" v-if="data.status===1" size="medium">待审批
                    </van-tag>
                    <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交
                    </van-tag>
                  </div>
                </div>
                <van-divider/>
                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">报名学员:</div>
                  <div>{{ data['staffName'] || '无' }}</div>
                </div>
                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">科室:</div>
                  <div>{{ data.sectionName }}</div>
                </div>
                <div style="margin-bottom: 10px" v-if="data.majorName">
                  <div style="color: #cccccc;margin-bottom: 4px;">专业:</div>
                  <div>{{ data.majorName }}</div>
                </div>
                <div style="margin-bottom: 10px" v-if="data['gradationTypeName']">
                  <div style="color: #cccccc;margin-bottom: 4px;">期限:</div>
                  <div>{{ data['periodName'] }}</div>
                </div>

                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">报名时间:</div>
                  <div>{{ data.created.substring(0, 10) }}</div>
                </div>
                <div style="margin-bottom: 10px">
                  <div style="color: #cccccc;margin-bottom: 4px;">选送单位:</div>
                  <div>{{ data.billingUnit || '无' }}</div>
                </div>
              </div>
              <div style="text-align: right;">
                <van-button style="width: 5em" v-if="data.status === 1" type="primary" size="mini"
                            @click="processFn(data,3)">通过
                </van-button>
                <van-button style="width: 5em" v-if="data.status === 1" type="warning" size="mini"
                            @click="processFn(data,2)">驳回
                </van-button>
                <van-button style="width: 5em" type="primary" size="mini" @click="goDetail(data)">详情</van-button>
                <van-button style="width: 5em" v-if="data.status === 1" type="danger" size="mini"
                            @click="processFn(data,11)">拒绝
                </van-button>
              </div>
            </div>
          </van-list>
        </van-pull-refresh>

      </div>
      <div v-if="role === 'StudentType_jxs'" style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>
    </div>
    <van-dialog v-model="show" confirmButtonColor="#17d4b5" title="确定此操作么?" show-cancel-button @cancel="show = false"
                @confirm="getApprove(num, notTarget)">
      <van-field v-model="auditOpinion" label="理由" placeholder="请输入理由"/>
    </van-dialog>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getTransferSchedule,
  advancedsignupList,
  getApplyInfo,
  urlForPost,
} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      url: {
        update: '/advancedsignup/update'
      },
      reason: '',
      show: false,
      listParams: {
        type: 'first',
        pageSize: 10,
        pageNum: 0,
        mobileSectionId: '',
        name: '',
        enrollYear: ''
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option2: [],
      option3: [
        {text: '全部', value: null},
        {text: '等待部门初审', value: 1},
        {text: '部门初审未通过', value: 2},
        // {text: '已通过', value: 3},
        {text: '等待科室遴选', value: 3},
      ],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      studentInfo: {},
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      auditOpinion: '',
      num: null,
      option4: [],
      option1: [],
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    goDetail(data) {
      if (this.role === 'JXS_manager') {
        sessionStorage.setItem('listParams', JSON.stringify(this.listParams))
        this.$router.push({
          path: '/department-student-detail',
          query: data
        })
      }
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;

      this.testData = [];
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    // 获取申请列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }

      advancedsignupList(params).then(res => {
        if (f === 'onLoad') {
          this.state.loading = false;
          if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
            this.state.finished = true
          }
          if(res.data.total === 0){
            this.testData = []
          }else{
            this.testData = [...this.testData, ...res.data.list];
          }
        } else {
          this.testData = [...res.data.list];
        }
      })
    },

    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },

    // 通过审批
    getApprove(num, target) {
      let param = {
        "id": target.id,
        "auditOpinion": this.auditOpinion,
        "status": num,
      }
      urlForPost(this.url.update, param).then(res => {
        if (res.data.data.success) {
          this.$toast.success({
            message: '操作成功!',
            duration: 2000
          })
          this.onRefresh();
        } else {
          this.$toast.fail({
            message: '操作失败!',
            duration: 2000
          })
        }
      })
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    // 判断是否有正在审核的申请
    addLeave() {
      let flag = true
      this.testData.forEach(item => {
        if (item.status === 11) {
          flag = false
          this.$toast.fail('您已有还在审核的申请, 请耐心等待!')
        }
        if (item["returnStatus"] !== 2) {
          if (item.status === 1) {
            this.$toast.fail('您的申请未通过, 请编辑驳回的申请后重试!')
          } else {
            this.$toast.fail('您已有还在完成的申请, 请申请后重试!')
          }
          flag = false
        }
      })
      if (flag) {
        this.$router.push({
          path: '/graduation-add'
        })
      }
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    processFn(data, status) {
      if (status === 2) {
        this.show = true
        this.num = status
        this.notTarget = data
      } else {
        Dialog.confirm({
          title: '温馨提示:',
          message: '确定此操作么?',
          confirmButtonColor: '#17d4b5'
        }).then(() => {
          this.getApprove(status, data)
        }).catch(() => {
          this.$toast.fail('取消操作!')
        })
      }
    },
    // 获取批次
    getBatch(){
      urlForPost('/backboneTraining/getBatchByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option4 = arr
      }).catch(()=>{})
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let listP = sessionStorage.getItem('listParams') || null
    if (listP) {
      this.listParams = JSON.parse(listP)
    }
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.transferGet() // 获取科室数据
    this.getBatch() // 获取批次
    this.getYear() // 获取年度
  },

}
</script>
