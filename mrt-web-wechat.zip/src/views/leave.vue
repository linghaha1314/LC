<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
      <template #right v-if="role !== 'StudentType_jxs'">
        <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">我的</span>
        <span v-if="isMine" style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>
      </template>
    </van-nav-bar>

    <div>
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item title="年度" v-model="listParams.startYear" @change="leaveListGet" :options="option1"/>
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.sectionId" @change="leaveListGet" :options="option2"/>
        <van-dropdown-item title="状态" v-model="listParams.status" @change="leaveListGet" :options="option3"/>
      </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <van-checkbox v-if="role !== 'StudentType_jxs'" v-model="data.checked" shape="square"
                          checked-color="#17d4b5" @click="changeChecked(data)">{{ data.date }}
            </van-checkbox>
            <div style="font-size: 14px;display: flex;justify-content: space-between;">
              {{ data.typeName }}
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">
                已通过
              </van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===1" size="medium">
                已拒绝
              </van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===11" size="medium">
                审核中
              </van-tag>
            </div>
            <van-divider/>
            <div>
              <div style="margin-bottom: 10px">
                <div>请假人: {{ data.studentName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>时间: {{ data.startDate.substring(0, 10) }} ~ {{ data.endDate.substring(0, 10) }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>去向: {{ data.destination || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <van-button v-if="role === 'StudentType_jxs' && data.status === 1" style="width: 50px; margin-right: 12px"
                          type="danger"
                          size="mini" @click="delFn(data)">删除
              </van-button>
              <van-button style="width: 50px; margin-right: 12px"
                          size="mini" @click="goDetail(data)">查看
              </van-button>
              <van-button v-if="role === 'StudentType_jxs' && data.status === 1" style="width: 50px; margin-right: 12px"
                          type="warning"
                          size="mini" @click="goSet(data)">修改
              </van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>


      <div v-if="role === 'StudentType_jxs'" style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>

    </div>
    <div style="position: fixed;left: 0;bottom: 0;width: 100vw;" v-if="role !== 'StudentType_jxs' && !isMine">
      <van-button style="width: 50%" type="warning" @click="notThrough">不通过</van-button>
      <van-button style="width: 50%" color="#17d4b5" @click="throughFn(1)">通过</van-button>
    </div>
    <van-dialog v-model="show" confirmButtonColor="#17d4b5" title="确定拒绝么?" show-cancel-button @cancel="show = false"
                @confirm="getApprove(0, notTarget)">
      <van-field v-model="reason" label="理由" placeholder="请输入理由"/>
    </van-dialog>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getLeaveList,
  getTransferSchedule,
  getListProcess,
  getLeaveApprovalProcess,
  getLeaveVerification,
  removeLeave
} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      reason: '',
      show: false,
      listParams: {
        pageSize: 10,
        pageNum: 0,
        sectionId: '',
        typeId: '',
        startYear: ''
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option1: [],
      option2: [],
      option3: [
        {text: '全部', value: null},
        {text: '已拒绝', value: 1},
        {text: '已通过', value: 2},
        {text: '审核中', value: 11},
      ],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')

    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.leaveListGet() // 获取请假列表
    this.getYear() // 年份数据
    this.transferGet() // 获取科室数据

  },
  methods: {
    goDetail(data) {
      localStorage.setItem('currentData', JSON.stringify(data))
      this.$router.push({
        path: '/leave-detail'
      })
    },
    goSet(data){
      localStorage.setItem('currentData', JSON.stringify(data))
      this.$router.push({
        path: '/leave-add'
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;

      // 重新加载数据
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    // 获取请假列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }
      params.startYear = params.startYear.toString() || ''
      if (this.role === 'StudentType_jxs' || this.isMine) {
        getLeaveList(params).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            let flag = false
            this.testData.forEach(item => {
              res.data.list.forEach(ite => {
                if (item.id === ite.id) {
                  flag = true
                }
              })
            })
            if (flag) {
              this.testData = [...this.testData]
            } else {
              this.testData = [...this.testData, ...res.data.list];
            }
            // this.testData = [...this.testData,...res.data.list];
            // this.state.loading = false;
            // if(res.data.list.length === 0 || this.testData.length && (this.testData.length >= res.data.total)){
            //   this.state.finished = true
            // }
          } else {
            this.testData = [...res.data.list];
          }
        })
      } else {
        getListProcess(params).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
              this.state.finished = true
            }
            let flag = false
            this.testData.forEach(item => {
              res.data.list.forEach(ite => {
                if (item.id === ite.id) {
                  flag = true
                }
              })
            })
            if (flag) {
              this.testData = [...this.testData]
            } else {
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      }
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },
    // 审批
    throughFn(num) {
      let target = {}
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          target = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选请假信息!')
      } else {
        let msg = '';
        getLeaveVerification({
          "studentId": target.studentId
        }).then(res => {
          let data = res.data.data
          msg = num === 1 ? `${data.studentName}在本次进修期间剩余请假天数为${data["maxLeaveDays"] - data["totalDays"]}天,确认要同意他的请假申请吗？` : '确认拒绝申请么?'
          Dialog.confirm({
            title: '温馨提示:',
            message: msg,
            confirmButtonColor: '#17d4b5'
          }).then(() => {
            this.getApprove(num, target)
          }).catch(() => {
          })
        })
      }
    },
    // 点击不通过
    notThrough() {
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          this.notTarget = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选请假信息!')
      } else {
        this.show = true;
      }
    },
    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      this.onRefresh()
    },
    // 通过审批
    getApprove(num, target) {
      let param = {
        "opinion": num === 1 ? "同意" : this.reason,
        "processInstanceId": target.processInstanceId,
        "projectId": target.id,
        "retryStatus": 0,
        "status": num,
        "taskId": target.taskId,
      }
      getLeaveApprovalProcess(param).then(res => {
        this.$toast.success(res.data.msg)
        this.leaveListGet();
      })
    },
    changeChecked(data) {
      this.testData.forEach(item => {
        item.checked = false
      })
      data.checked = true
    },
    // 判断是否有正在审核的请假
    addLeave() {
      let flag = true
      this.testData.forEach(item => {
        if (item.status === 11) {
          flag = false
          this.$toast.fail('您已有还在审核的请假, 请耐心等待!')
        }
        if (item["returnStatus"] !== 2) {
          if (item.status === 1) {
            this.$toast.fail('您的请假未通过, 不能进行此操作!')
          } else {
            this.$toast.fail('您已有未完成的请假, 不能进行此操作!')
          }
          flag = false
        }
      })
      if (flag) {
        localStorage.setItem('currentData', '')
        this.$router.push({
          path: '/leave-add'
        })
      }
    },
    delFn(data) {
      removeLeave(data.id).then(() => {
        this.$toast.success('操作成功!')
        this.leaveListGet()
      })
    },
  }
}
</script>
