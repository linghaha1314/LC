<template>
    <div class="about">
        <van-nav-bar title="上传" left-arrow>
            <template #left>
                <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
            </template>
        </van-nav-bar>
        <div style="padding: 20px 12px; text-align: center;">
            <van-uploader :max-size="1024*1024*20" v-model="attach" @oversize="oversizeFn" :after-read="afterRead" :before-read="beforeRead" :before-delete='beforeDelete'/>
        </div>
    </div>
</template>
<script>
    import { urlForPost, uploadSignFile } from '../http/apiMap';
    export default {
        name: 'upload',
        data() {
            return {
                url: {
                    create: '/advancedsignupattach/create',
                    removeFile: '/advancedsignupattach/attachDeleteFile'
                },
                attach: [],
                queryData: this.$route.query
            }
        },
        computed: {

        },
        methods: {
            afterRead(file) {
                let data = new FormData()
                data.append('multipartFile', file.file)
                uploadSignFile(data).then(res => {
                    file.pathAttach = res.data.path
                    let obj = {
                        path: res.data.path,
                        target: this.queryData.target,
                        // file: file
                    }
                    sessionStorage.setItem("uploadData", JSON.stringify(obj))
                    if(this.queryData&& this.queryData.id&& this.queryData.code){
                        this.saveAttach(res.data.path, file)
                    }else{
                      this.$router.go(-1)
                    }
                }).catch(()=>{})
            },
            beforeRead(file) {
                if (file.type === 'image/jpeg' || file.type === 'image/png') {
                    return true;
                } else {
                    this.$toast.fail('请上传图片');
                    return false;
                }
            },
            beforeDelete(file) {
                urlForPost(this.url.removeFile, {
                    path: file.pathAttach
                }).then()
                return true
            },
            saveAttach(path, objFile) {
                let param = {
                "signupId": this.queryData.id,
                "typeCode": this.queryData.code,
                "path": path
                }
                urlForPost(this.url.create,param).then(res => {
                objFile.id = res.data.data["reasons"].data.id
                  this.$router.go(-1)
                })
            },
            oversizeFn(file){
            }
        },
        mounted() {
            sessionStorage.setItem("uploadUrl", '')
        }
    }
</script>