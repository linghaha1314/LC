<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="activitiesForm">
      <van-field :value="formData.fee + '元'" name="fee" label="退款金额" placeholder="退款金额" readonly
      />
      <van-field v-model="formData.reason" name="reason" label="退款理由" rows="2" :autosize="true" type="textarea" required
                 placeholder="请填写退款理由"
                 :rules="[{ required: true, message: '请填写退款理由' }]"
      />
      <div style="margin: 16px;">
        <van-button :disabled="disabledApply" round block color="#17d4b5" @click="onSubmit">
          申请退款
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {
  urlForPost
} from '../http/apiMap';
import { Dialog } from 'vant';
export default {
  name: 'test',
  data() {
    return {
      formData: {
        fpzldm: 51,
        fee: 2000,
        content: '培训费',
        reason: ''
      },
      active: '',
      name: '退款',
      orderData: this.$route.query,
      disabledApply: false
    }
  },
  methods: {
    onSubmit() {
      Dialog.confirm({
        title: '温馨提示:',
        message: '退款申请由临床教学部进行审核，审核通过后查询退款状态!',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        this.$refs.activitiesForm.validate().then(() => {
          this.disabledApply = true
          urlForPost('/advancedpayonline/toApplyReturnPay', {
            advFee: this.orderData.payFee,
            orderNo: this.orderData.orderNo,
            bnkPyOrdrNo: this.orderData.bnkPyOrdrNo,
            reason: this.formData.reason,
            checkStatus:7
          }).then(res => {
            this.$toast.success(res.data.data.message || '成功申请!')
            this.$router.back(-1)
          })
        }).catch(() => {
          this.$toast.fail('请正确填写表单!')
        })
      })

    }
  },
  mounted() {
    this.formData.fee = this.orderData.payFee
  }
}
</script>
