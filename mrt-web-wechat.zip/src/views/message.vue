<template>
  <div>
    <van-cell @click="goList({name: '系统消息',code: msgList['sysInfo'].code})" v-if="msgList['sysInfo']">
      <template #title>
        <div style="display: flex;align-items: center">
          <div style="margin-right: 12px">
            <div
                style="width: 50px;height: 50px;border-radius: 4px;background: rgb(21,117,255); display: flex;justify-content: center;align-items: center;">
              <van-icon name="smile-comment" color="#fff" size="30"/>
            </div>
          </div>
          <div>
            <div style="font-size: 16px;font-weight: bold">【{{msgList['sysInfo'].name}}】</div>
            <div style="padding: 0 8px;">您有{{ msgList['sysInfo'].total || 0 }}条新消息</div>
          </div>
        </div>
      </template>
    </van-cell>
    <van-cell @click="goList({name: '通知',code: msgList['sysNotify'].code})" v-if="msgList['sysNotify']">
      <template #title>
        <div style="display: flex;align-items: center">
          <div style="margin-right: 12px">
            <div
                style="width: 50px;height: 50px;border-radius: 4px;background: rgb(254,212,78); display: flex;justify-content: center;align-items: center;">
              <van-icon name="volume" color="#fff" size="30"/>
            </div>
          </div>
          <div>
            <div style="font-size: 16px;font-weight: bold">【{{msgList['sysNotify'].name}}】</div>
            <div style="padding: 0 8px;">您有{{ msgList['sysNotify'].total || 0 }}条新消息</div>
          </div>
        </div>
      </template>
    </van-cell>
  </div>
</template>
<script>
import {getMyMessage} from '../http/apiMap';

export default {
  name: 'message',
  data() {
    return {
      msgList: {},
    }
  },
  methods: {
    goList(data) {
      this.$router.push({
        path: '/message-list',
        query: data
      })
    }
  },
  created() {
  },
  mounted() {
    getMyMessage().then(res => {
      this.$set(this,'msgList',res.data.data)
    })
  }
}
</script>