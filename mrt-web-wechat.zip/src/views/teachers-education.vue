<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div style="background: #f6f6f6; padding: 12px;">
      <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
        v-for="data in testData" :key="data.title"
      >
        <van-divider/>
        <div @click="goDetail(data)">
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学校名称：</div>
            <div>{{data['school']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学历：</div>
            <div>{{data['academicName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学位：</div>
            <div>{{data['degreeName'] || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">所学专业:</div>
            <div>{{data.subject || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">学制:</div>
            <div>{{data['schoolYears']}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">开始日期:</div>
            <div>{{data.startDate && data.startDate.substring(0,10) || '无'}}</div>
          </div>
          <div style="margin-bottom: 10px;display: flex;align-items: center;">
            <div style="color: #cccccc;margin-right: 4px;width: 22vw;">结束日期:</div>
            <div>{{data.endDate && data.endDate.substring(0,10) || '无'}}</div>
          </div>
        </div>
        <div style="text-align: right;">
          <van-button type="primary" size="mini" @click="updateEducation(data)">修改学历</van-button>
          <van-button type="warning" size="mini" @click="delEducation(data)">删除学历</van-button>
        </div>
      </div>
      <div style="position: fixed;right: 26px;bottom: 70px">
        <van-icon color="#ff0000" name="add" size="40" @click="addFn"/>
      </div>
    </div>
    <div style="margin: 30px 16px 16px;display: flex;">
      <van-button style="margin-bottom: 12px;" round block @click="goPre">
        上一步
      </van-button>
      <van-button round block color="#17d4b5" @click="attendAdd">
        下一步
      </van-button>
    </div>
  </div>
</template>
<script>
  import {Dialog} from 'vant';
  import {urlForPost} from '../http/apiMap';

  export default {
    name: 'test',
    components: {
      [Dialog.Component.name]: Dialog.Component,
    },
    data() {
      return {
        url: {
          list: '/advancedsignup/listEduBackgroudByPage',
          advancedSignup: '/advancedsignup/saveOrUpdateAdvancedSignup',
          remove: '/advancedsignup/removeEduBackground'
        },
        testData: [],
        pageParam: {
          staffId: sessionStorage.getItem('staffId') || '',
          pageSize: 999,
          pageNum: 1,
          dateDesc: true
        },
        name: '学历信息',
        queryData: this.$route.params
      }
    },
    computed: {},
   
    methods: {
      goDetail(data) {
        localStorage.setItem('currentEducationData', JSON.stringify(data))
        this.$router.push({
          path: '/sign-write-education-add',
          query: data
        })
      },

      getList() {
        urlForPost(this.url.list,this.pageParam).then(res => {
          this.testData = res.data.list
        })
      },
      goPre() {
        this.$router.push({
          name: '带教老师申请'
        })
      },
      attendAdd() {
        if(this.testData.length !== 0){
          this.$router.push({
            path: '/teachers-certificate'
          })
        }else{
          this.$toast.fail('请先添加学历!')
        }
      },
      delEducation(data){
        Dialog.confirm({
          message: '确定删除么?'
        }).then(()=>{
          urlForPost(this.url.remove, [data.id]).then(res => {
            if(res.data.success){
              this.$toast.fail('删除成功!')
              this.getList()
            }else{
              this.$toast.fail('删除失败!')
            }
          })
        }).catch(()=>{})
      },
      addFn(){
        // localStorage.setItem('currentEducationData', '')
        this.$router.push({
          path:'/teachers-education-add'
        })
      },
      updateEducation(data){
        this.$router.push({
          name: 'educationAdd',
          params: data
        })
      }
    },
    mounted() {
      this.getList();
    }
  }
</script>