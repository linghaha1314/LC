<template>
    <div>
        <van-nav-bar :title="name" left-arrow>
            <template #left v-if="$route.query.isLogin!=='login'">
                <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
            </template>
        </van-nav-bar>
        <div style="padding: 4px 16px;font-size: 16px;">
            修改新密码:
        </div>
        <van-form @submit="onSubmit">
            <van-field v-model="oldPassword" required name="oldPassword" label="旧密码" placeholder="旧密码" :rules="[{ required: true, message: '请填写旧密码' }]"
            />
            <div style="text-align: center; color: orangered">请填写8位以上包含大小写字母 数字 特殊符号(不要加逗号、句号等标点符号)任意三种的密码</div>
            <van-field v-model="newPassword" name="newPassword" required label="新密码" placeholder="请填写" :rules="[{ validator, message: '请正确填写' }]"
            />
            <div style="margin: 24px 12px;">
                <van-button round block color="#17d4b5" native-type="submit">
                    确认修改
                </van-button>
            </div>
        </van-form>

    </div>
</template>
<script>
    import { changePassword } from '../http/apiMap';
    export default {
        name: 'we-changePassword',
        data() {
            return {
                radio: '1',
                "oldPassword": "",
                "newPassword": "",
                pattern: /^(?!\d+$)(?![a-zA-Z]+$)[a-zA-Z\d]+$/
            }
        },
        computed: {
            name() {
                return this.$route.name
            },
        },
        methods: {
            onSubmit(value) {
                changePassword(value).then(res => {
                    if(res.data.success){
                      this.$toast.success({
                        message: res.data.msg,
                        onClose:()=>{
                          localStorage.setItem('isLogin', '');
                          localStorage.setItem('token', '');
                          sessionStorage.clear()
                          this.$router.replace('/login')
                        }
                      })
                    }else{
                      this.$toast.fail({
                        message: res.data.msg,
                        duration: 0
                      })
                    }
                })
            },
            validator(){
                let modes = 0;
                let val = this.newPassword
                if (val.length < 7) return false;
                if (/\d/.test(val)) modes++; //数字
                if (/[a-z]/.test(val)) modes++; //小写
                if (/[A-Z]/.test(val)) modes++; //大写
                if (/\W/.test(val)) modes++; //特殊字符
                return modes>2;
            }
        }
    }
</script>