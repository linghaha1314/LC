<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="申请人:" :value="currentData.studentName" />
        <van-cell title="学历:" :value="currentData['academicName']" />
        <van-cell title="性别:" :value="currentData['genderName']" />
        <van-cell title="民族:" :value="currentData['nationName']" />
        <van-cell title="职称:" :value="currentData.titleName" />
        <van-cell title="期限:" :value="currentData.period+'个月'" />
        <van-cell title="生日:" :value="currentData['birthday'] && currentData['birthday'].substring(0,10)" />
        <van-cell title="所属医院:" :value="currentData['unitName']" />
        <van-cell title="带教老师:" :value="currentData.teacherName||'无'" />
        <van-cell title="申请科室:" :value="currentData.sectionName||'无'" />
        <van-cell title="申请专业:" :value="currentData.majorName||'无'" />
        <van-cell title="理论成绩:" :value="currentData.theoryScore||'无'" />
        <van-cell title="技能成绩:" :value="currentData['skillScore']||'无'" />
        <van-cell title="品行成绩:" :value="currentData['conductScore']||'无'" />
        <van-cell title="业务能力:" :value="currentData['businessScore']||'无'" />
        <van-cell title="医德医风:" :value="currentData['moralScore']||'无'" />
        <van-cell title="组织纪律:" :value="currentData['disciplineScore']||'无'" />
        <van-cell title="个人鉴定:">
          <template #label>
            <div>{{currentData.summary||'无'}}</div>
          </template>
        </van-cell>
        <van-cell v-if="currentData['evaluteDetail']" style="width:100vw;" title="对老师的评价:">
          <template #label>
            <div style="max-width:340px;overflow-wrap:break-word;box-sizing: border-box;">{{currentData['evaluteDetail']||'无'}}</div>
          </template>
        </van-cell>
        <van-cell style="width:100vw;" title="老师评语:">
          <template #label>
            <div style="max-width:340px;overflow-wrap:break-word;box-sizing: border-box;">{{currentData.teachOpinion||'无'}}</div>
          </template>
        </van-cell>
        <van-cell title="科室考评:">
          <template #label>
            <div>{{currentData['sectionOpinion']||'无'}}</div>
          </template>
        </van-cell>
        <van-cell title="部门考评:" :label="currentData['deptOpinion']||'无'" />
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
    import {getStudentDetailById} from '../http/apiMap'
    import { Dialog } from 'vant';
    export default {
        name: 'test',
        components: {
            [Dialog.Component.name]: Dialog.Component,
        },
        data(){
            return{
                currentData: this.$route.query,
                name: this.$route.name
            }
        },
        computed:{

        },
        methods:{

        },
        mounted() {
          getStudentDetailById(this.currentData.studentId).then(res => {
            let data = res.data.data
            let target =  Object.assign(this.currentData,data)
            this.$set(this,'currentData',{...target})
          })
        }
    }
</script>
