<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div v-if="true">
      <van-cell title="进修科室" :value="formData.sectionName || '无'"/>
      <van-cell title="进修学生" :value="formData.studentName || '无'"/>
      <van-cell title="专业" :value="formData.majorName || '无'"/>
      <van-cell title="进修期限(月)" :value="formData['periodMonths'] || '无'"/>
      <van-cell v-if="currentData.transferFlag==='true'" title="轮转日期"
                :value="formData.startDate.substring(0,10)+'至'+formData.endDate.substring(0,10) || '无'"/>
      <van-cell title="备注信息" :value="formData.remark || '无'"/>
      <van-field
          readonly
          clickable
          name="startDate"
          required
          label="入科日期"
          :value="formData.checkTime?formData.checkTime.substring(0,10):''"
          placeholder="选择入科日期"
          @click="showDatePicker = true"
          :rules="[{ required: true, message: '请选择入科日期' }]"
      />
      <van-popup v-model="showDatePicker" round position="bottom">
        <van-datetime-picker
            v-model="dateValue"
            type="date"
            title="选择年月日"
            @cancel="showDatePicker = false"
            @confirm="onDateConfirm($event,formData,'checkTime','showDatePicker')"
            :max-date="maxDate"
        />
      </van-popup>
      <div style="margin: 16px;">
        <van-button v-if="formData.status==='0'" style="margin-bottom: 24px"
                    :disabled="!intoFlag||(currentData.status === '1'||currentData.status === 1)" round block
                    color="#17d4b5" @click="activitiesOver">
          {{ intoFlag ? '确认入科' : '上个科室未出科' }}
        </van-button>
        <van-button v-else-if="formData.status==='1'" style="margin-bottom: 24px"
                    disabled round block
                    color="#17d4b5">
          已经入科
        </van-button>
<!--        && (currentData['transferTeacherFlag'] === 'false' || currentData['transferTeacherFlag'] === null)-->
        <van-button style="margin-bottom: 24px"
                    v-if="isInto"
                    round block type="primary" @click="showListPicker = true">
          分配带教老师
        </van-button>
        <van-button round block @click="download" v-if="!!this.currentData['admissionFlag']">
          查看入科通知
        </van-button>
        <van-popup style="height: 70vh" v-model="showListPicker" round position="bottom">
          <div style="padding: 12px;display: flex; justify-content: space-between;align-items: center">
            当前带教老师: {{currentTeacher || '无'}}
            <van-button v-if="!isDone" style="width: 4em;" type="primary" size="mini" @click="addFn">
              添加
            </van-button>
          </div>
          <div class="box">
            <div
                style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
                v-for="data in testData"
                :key="data.title">

              <div>
                <div style="margin-bottom: 10px">
                  <div>老师: {{ data.teacherName || '无' }}</div>
                </div>
                <div style="margin-bottom: 10px" v-if="data.startDate">
                  <div>开始时间: {{ data.startDate.substring(0, 10) }}</div>
                </div>
                <div style="margin-bottom: 10px" v-if="data.endDate">
                  <div>结束时间: {{ data.endDate.substring(0, 10) }}</div>
                </div>
              </div>
              <div style="text-align: right;" v-if="!isDone">
                <van-button style="width: 12em; margin-right: 12px"
                            type="warning"
                            size="mini" @click="goSetCurrent(data)">设为当前带教老师
                </van-button>

                <van-button style="width: 50px; margin-right: 12px"
                            type="danger"
                            size="mini" @click="delFn(data)">删除
                </van-button>

<!--                <van-button style="width: 50px; margin-right: 12px"-->
<!--                            type="warning"-->
<!--                            size="mini" @click="goSet(data)">修改-->
<!--                </van-button>-->
              </div>
            </div>
          </div>
        </van-popup>
        <van-popup style="height: 50vh" v-model="showTeacherPicker" round position="bottom">
          <div style="height: 30vh;padding: 24px 0;">
            <van-form ref="addForm">
              <van-field
                  readonly
                  clickable
                  name="startDate"
                  required
                  label="开始日期"
                  :value="addData.startDate?addData.startDate.substring(0,10):''"
                  placeholder="选择开始日期"
                  @click="showStartDatePicker = true"
                  :rules="[{ required: true, message: '请选择开始日期' }]"
              />
              <van-popup v-model="showStartDatePicker" round position="bottom">
                <van-datetime-picker
                    v-model="addData.dateValue"
                    type="date"
                    title="选择年月日"
                    @cancel="showDatePicker = false"
                    @confirm="onDateConfirmN($event,addData,'startDate','showStartDatePicker')"
                />
              </van-popup>
              <van-field
                  readonly
                  clickable
                  name="startDate"
                  required
                  label="结束日期"
                  :value="addData.endDate?addData.endDate.substring(0,10):''"
                  placeholder="选择结束日期"
                  @click="showEndDatePicker = true"
                  :rules="[{ required: true, message: '请选择结束日期' }]"
              />
              <van-popup v-model="showEndDatePicker" round position="bottom">
                <van-datetime-picker
                    v-model="addData.endValue"
                    type="date"
                    title="选择年月日"
                    @cancel="showDatePicker = false"
                    @confirm="onDateConfirmN($event,addData,'endDate','showEndDatePicker')"
                />
              </van-popup>
              <van-field
                  name="teacherId"
                  readonly
                  clickable
                  required
                  label="带教老师"
                  :value="addData.teacherName"
                  placeholder="选择带教老师"
                  @click="showPicker = true"
                  :rules="[{ required: true, message: '请选择带教老师' }]"
              />
              <van-popup v-model="showPicker" round position="bottom">
                <Pager :list-prop="['teacherName','id']" url="/teacher/listQueryTeacher" :sectionId="formData.sectionId"
                       @check="checkFn"></Pager>
              </van-popup>

            </van-form>
            <div style="width:100%; height: 7px; background: #f6f6f6"></div>
            <div style="display: flex;justify-content: space-around; margin-top: 30px;">
              <van-button style="width: 6em" round type="warning" size="mini"
                          @click="showTeacherPicker = false">取消</van-button>
              <van-button style="width: 6em" round type="primary" size="mini"
                          @click="checkinTeacherFn">提交</van-button>
            </div>
          </div>
        </van-popup>
      </div>
    </div>
  </div>
</template>
<script>
import Pager from '../components/searchPager'
import {
  getDictionaryType,
  updateTeachactivity,
  removeTeachactivity,
  checkinIntoFamily,
  // checkinTeacher,
  urlForGet,
  urlForPost,
  outFamilyCreate,
  urlForGetCode
} from '../http/apiMap';

import {Dialog} from "vant";

export default {
  name: 'test',
  components: {
    Pager
  },
  data() {
    return {
      formData: {},
      addData: {},
      ac_userId: '',
      currentData: {},
      showPicker: false,
      showTeacherPicker: false,
      showListPicker: false,
      showTypePicker: false,
      showDatePicker: false,
      showStartDatePicker: false,
      showStartTimePicker: false,
      showEndTimePicker: false,
      showEndDatePicker: false,

      action: 3,
      minDate: new Date(),
      maxDate: new Date(),
      currentDate: new Date(),
      currentTime: '12:00',
      currentEndDate: '12:00',
      option1: [],
      testData: [],
      role: '',
      userId: '',
      show: false,
      hrefU: '',
      isInto: false,
      dateValue: new Date(),
      intoFlag: false,
      isDone: false,
      currentTeacher: ''
    }
  },
  computed: {
    name() {
      return this.$route.name
    },
    typeColumns() {
      let arr = []
      this.option1.map(item => {
        arr.push(item.text)
      })
      return arr;
    },
    isEdit() {
      return this.action === 3 || (this.action === 0 && this.userId === this.formData.userId);
    }
  },
  methods: {
    // 发布
    release() {
      let param = {
        "endTime": this.formData.endTime,
        "location": this.formData.location,
        "remark": this.formData.remark,
        "startDate": this.formData.startDate,
        "startTime": this.formData.startTime,
        "subject": this.formData.subject,
        "teacherId": this.formData.teacherId,
        "typeId": this.formData.typeId.value,
        id: this.currentData.id,
        status: 1
      }
      updateTeachactivity(param).then(() => {
        this.$toast.success('发布成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },
    // 删除活动
    removeA() {
      removeTeachactivity({
        id: this.currentData.id
      }).then(() => {
        this.$toast.success('删除成功!')
        setTimeout(() => {
          this.$router.go(-1)
        }, 1000)
      })
    },

    onTypeConfirm(value, index) {
      this.formData.typeId = this.option1[index].value;
      this.formData.typeName = value;
      this.showTypePicker = false;
    },

    // onDateConfirm(value) {
    //   this.formData.checkTime = getNowFormatDate(value) + ':00'
    //   this.showDatePicker = false;
    // },
    onDateConfirm(value,target,prop,show) {
      target[prop] = this.getNowFormatDate(value)+' 00:00:00'
      this[show] = false;
    },
    onDateConfirmN(value,target,prop,show) {
      target[prop] = this.getNowFormatDate(value)
      this[show] = false;
    },
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }

      return year + seperator1 + month + seperator1 + strDate;
    },
    checkFn(data) {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        this.addData.teacherId = data.value
        this.addData.teacherName = data.text
        this.showPicker = false
        // this.showTeacherPicker = false
        // this.checkinTeacherFn()
      }).catch(() => {
      })
    },
    // 获取类型
    getTypeList() {
      getDictionaryType('TeachActivityType').then(res => {
        let data = res.data.data
        let arr = []
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          arr.push(obj)
        })
        this.option1 = arr;
      })
    },
    // 提交
    activitiesOver() {
      if (this.formData.checkTime) {
        if (this.currentData.transferFlag === 'false' || this.currentData.transferFlag === false) {
          let param = {
            ids: this.currentData.id,
            checkTime: this.formData.checkTime
          }
          checkinIntoFamily(param).then((res) => {
            if (res.data.success) {
              this.$toast.success('操作成功!')
              this.currentData.status = 1
              this.isInto = true
            } else {
              this.$toast.fail('操作失败!')
            }
          })
        } else {

          let param = [
            {
              "hospitalId": this.formData.hospitalId,
              "sectionId": this.formData.sectionId,
              "studentId": this.formData.studentId,
              "transferId": this.formData.transferId,
              "checkTime": this.formData.checkTime
            }
          ]
          outFamilyCreate(param).then((res) => {
            if (res.data.data.success) {
              this.$toast.success('操作成功!')
              this.currentData.status = 1
              this.isInto = true
            } else {
              this.$toast.fail('操作失败!')
            }
          })
        }
      } else {
        this.$toast.fail('您还未选择时间!')
      }
    },
    // 选择带教老师
    checkinTeacherFn() {
      let p = {
        "transferFlag": this.currentData.transferFlag.toString(),
        "teacherId": this.addData.teacherId,
        "startDate": this.addData.startDate,
        "endDate": this.addData.endDate,
        "transferId": this.currentData.id,
        id: this.addData.id || ''
      }
      urlForPost(p.id?'/studentteacher/updateHistoricalRecordsOfTeacher':'/transfercheckin/transferInSectionDistributionTeacher', p).then(res => {
        if (res.data.success) {
          this.$toast.success('安排成功!')
          this.showListPicker = true
          this.showTeacherPicker = false
          this.getTeacherData()
        } else {
          this.$toast.fail('安排失败!')
        }
      })
    },
    // 下载通知书
    download() {
      this.$router.push({
        path: '/download-page',
        query: {
          id: this.formData.studentId,
          type: 'intoFamily'
        }
      })
    },
    delFn(data) {
      Dialog.confirm({
        message: '确认删除吗?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        urlForGet('/studentteacher/deleteByIdAndStatus',data.id).then(()=> {
          this.$toast.success({
            message: '操作成功!',
            duration: 2000,
            onClose:()=>{
              this.getTeacherData();
            }
          })
        })
      })
    },
    goSet(data) {
      this.addData.startDate = data.startDate
      this.addData.endDate = data.endDate
      this.addData.teacherId = data.teacherId
      this.addData.teacherName = data.teacherName
      this.addData.id = data.id
      this.showListPicker = false
      this.showTeacherPicker = true
    },
    goSetCurrent(data){
      Dialog.confirm({
        message: '确认么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        urlForPost('/studentteacher/updateCurrentTeacher', {
          transferFlag: this.currentData.transferFlag==='true',
          status: 0,
          id: data.id
        }).then(() => {
          this.$toast.success({
            message: '操作成功!',
            duration: 2000,
            onClose:()=>{
              this.getTeacherData();
            }
          })
        })
      }).catch(() => {
      })
    },
    addFn(){
      this.showTeacherPicker = true
      this.addData = {}
    },
    getTeacherData() {
      urlForPost('/teacher/getTeacherByStudentId', {
        studentId: this.formData.studentId,
        pageSize: 10,
        pageNum: 1,
        transferId: this.formData.transferId || ''
      }).then(res => {
        this.testData = res.data.rows
        if(res.data.rows !== 0){
          this.setCurrentTeacher(res.data.rows)
        }
      })
    },
    setCurrentTeacher(data){
      data.forEach(item => {
        if(item.status === 0){
          this.currentTeacher = item.teacherName
        }
      })
    },
    isOut(){
      let now = Date.parse(new Date())
      let end = Date.parse(new Date(this.currentData.endDate))
      if(now>end){
        this.isDone = true
      }
    }
  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    this.userId = localStorage.getItem('userId')
    this.formData = this.$route.query
    this.currentData = this.$route.query
    this.isOut()
    this.isInto = this.currentData.status === '1'
    this.getTypeList() // 获取类型
    urlForGetCode('/transfercheckin/studentIsCheckout', this.formData.studentId).then(res => {
      this.intoFlag = !!(res.data && res.data.data === 0);
    })
    this.getTeacherData();
  }
}
</script>
<style>
.box{
  padding: 6px 12px 30px;
  background:#efefef;
  height: calc(70vh - 84px);
  overflow: auto;
}
</style>
