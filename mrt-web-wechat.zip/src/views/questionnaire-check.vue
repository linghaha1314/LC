<template>

  <div style="height: 100vh">
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.push('/home')">返回</span>
      </template>
    </van-nav-bar>
    <div style="display: flex; flex-direction: column;justify-content: center;height: 82vh;padding: 24px;">
      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'" :to="{path: '/questionnaire-evaluate',query: {type: 'teacher-library'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          查看学员对老师的评价
        </van-button>
      </router-link>
<!--      <router-link v-if="role === 'teacher'" :to="{path: '/questionnaire',query: {type: 'teacher-apply'}}">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          带教老师申请-->
<!--        </van-button>-->
<!--      </router-link>-->
<!--      v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"-->
      <router-link v-if="role !== 'StudentType_jxs'" :to="{path: '/questionnaire',query: {type: 'teacher-approve'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          查看问卷填写
        </van-button>
      </router-link>
      <router-link v-if="role === 'StudentType_jxs'" :to="{path: '/questionnaire',query: {type: 'edit'}}">
        <van-button style="margin-bottom: 40px" round block color="#17d4b5">
          填写问卷
        </van-button>
      </router-link>
<!--      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"  :to="{path: '/questionnaire',query: {type: 'tutor-approve'}}">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          进修导师审批-->
<!--        </van-button>-->
<!--      </router-link>-->
<!--      <router-link v-if="role === 'JXS_manager' || role==='sectionManager'|| role==='headNurse'"  :to="{path: '/questionnaire',query: {type: 'teacher-query'}}">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          师资查询-->
<!--        </van-button>-->
<!--      </router-link>-->
<!--      <router-link v-if="role === 'tutor'" :to="{path: '/questionnaire',query: {type: 'tutor-apply'}}">-->
<!--        <van-button style="margin-bottom: 40px" round block color="#17d4b5">-->
<!--          进修导师申请-->
<!--        </van-button>-->
<!--      </router-link>-->
    </div>
  </div>

</template>
<script>
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      role: ''
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {

  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')

  }
}
</script>
