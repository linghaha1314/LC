<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">
      <van-field name="studentId" readonly required label="申报人" :value="formData.studentName"/>
      <van-field name="medicalTeamLeaderId" readonly required label="带教老师" :value="formData.medicalTeamLeaderName"/>

      <van-field v-model="formData.patientName" name="patientName" label="患者姓名" required placeholder="填写患者姓名"
                 :rules="[{ required: true, message: '请填写患者姓名' }]"
      />

      <van-field v-model="formData.inpatientNo" name="inpatientNo" label="患者住院号" required placeholder="填写患者住院号"
                 :rules="[{ required: true, message: '请填写患者住院号' }]"
      />

      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <van-field
          readonly
          clickable
          required
          name="typeId"
          label="表扬物类型"
          :value="formData['typeName']"
          placeholder="选择表扬物类型"
          @click="showHealthConditionPicker = true"
          :rules="[{ required: true, message: '请选择表扬物类型' }]"
      />
      <van-popup v-model="showHealthConditionPicker" round position="bottom">
        <m-picker url="/dictionary/getByTypeCodeParams"
                  code="PraiseTypes"
                  @cancel="showHealthConditionPicker = false"
                  @confirm="onConfirm($event,formData,'typeName','typeId','showHealthConditionPicker')"
        ></m-picker>
      </van-popup>

      <van-field readonly clickable name="favourTime" required label="赠与时间"
                 :value="formData.favourTime.substring(0,10)+' '+columnsValue"
                 placeholder="选择赠与时间" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择赠与时间' }]"/>
      <van-popup v-model="showDatePicker" round position="bottom">
        <div>
          <van-datetime-picker v-model="formData.currentDate" type="date" @cancel="showDatePicker = false"
                               @confirm="onDateConfirm"/>
        </div>
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field v-model="formData.remark" name="reason" label="备注" placeholder="请填写备注"
      />
      <van-field name="fileList" required :value="fileList[0]&&fileList[0].attachPath" label="附件上传" :rules="[{ required: true, message: '请上传附件' }]">
        <template #input>
          <van-uploader v-model="fileList" :after-read="afterRead" :before-read="beforeRead"/>
        </template>
      </van-field>
      <div style="margin: 16px;">
        <van-button round block :disabled="disabled" color="#17d4b5" @click="onSubmit">
          提交申请
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {
  getLeaveType,
  getTeacher,
  uploadFile,
  getMobileProcess,
  getLeaveVerification,
  currentTeacher,
    urlForPost
} from '@/http/apiMap'
import {Dialog} from 'vant';
import mPicker from '../components/m-picker'
export default {
  name: 'test',
  components: {
    mPicker
  },
  data() {
    return {
      formData: {
        userId: '',
        userName: '',
        medicalTeamLeaderId: '',
        medicalTeamLeaderName: '',
        favourTime: '',
        startValue: '',
        patientName: '',
        inpatientNo: '',
        remark: '',
        attachPath: '',
        attach: [],
        currentDate: new Date(),
        currentEndDate: null,
        typeName: '',
        typeId: ''
      },
      teacherParams: {
        sectionId: localStorage.getItem('currentSectionId')
      },
      showPicker: false,
      showTypePicker: false,
      showTripPicker: false,
      showRiskPicker: false,
      showDatePicker: false,
      showEndDatePicker: false,
      showHealthConditionPicker: false,
      typeColumns: [],
      action: 3,
      columns: [],
      minDate: new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), new Date().getHours() < 13 ? 9 : 13, 0, 0),
      attachFlag: false,
      leaveDays: 0,
      disabled: false,
      columns1: ['上午', '下午'],
      columnsValue: '',
      fileList: []
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          let param = {
            ...this.formData
          }
          urlForPost(this.formData.id?'/studentpraise/update':'/studentpraise/create',param).then(res => {
            if (res.data.data.success) {
              this.$toast.clear();
              this.$router.go(-1)
            } else {
              this.$toast.fail(res.data.data.message || '出问题啦!!')
            }
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },
    onConfirm(value, target, name, id, show, cb) {
      target[id] = value.value
      target[name] = value.text
      this[show] = false;
      if (cb) {
        cb()
      }
    },
    onTypeConfirm(value) {
      this.formData.typeId = value.value;
      this.formData.typeName = value.text;
      this.attachFlag = value.attachFlag;
      this.showTypePicker = false;
    },
    // onDateConfirmF(value, target, prop, show) {
    //   target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
    //   this[show] = false;
    // },
    onDateConfirm(value) {
      this.formData.favourTime = this.getNowFormatDate(value)
      this.showDatePicker = false;
    },

    // 请假时长
    leaveNum() {
      if (this.formData.days > this.leaveDays) {
        this.$toast.fail('剩下休假时间不足,已改为最大天数!')
        this.formData.days = this.leaveDays
      }
      if (this.formData.currentDate) {
        let endDD = this.formData.currentDate.valueOf() + ((this.columnsValue === '下午' ? 0.5 : 0) + parseFloat(this.formData.days)) * (1000 * 60 * 60 * 24)-1
        this.formData.currentEndDate = new Date(endDD)
        this.formData.endDate = this.getNowFormatDate(this.formData.currentEndDate) + ':00:00'
      } else {
        this.formData.days = 0
        this.$toast.fail('请先选择起始时间!')
      }
    },

    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      // let strH = date.getHours();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      // if (strH >= 0 && strH <= 9) {
      //   strH = "0" + strH;
      // }
      return year + seperator1 + month + seperator1 + strDate;
    },

    // 获取请假类型
    leaveTypeGet() {
      getLeaveType({}).then(res => {
        let arr = res.data.list
        let typeArr = []
        arr.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            attachFlag: item.attachFlag
          }
          // item.values = item.name
          typeArr.push(obj)
        })
        this.typeColumns = typeArr
      })
    },
    // 获取带教老师数据
    teacherGet() {
      getTeacher(this.teacherParams).then(res => {
        let arr = res.data.list
        let teacherArr = []
        arr.forEach(item => {
          let obj = {
            text: item.teacherName,
            value: item.teacherId
          }
          // item.values = item.name
          teacherArr.push(obj)
        })
        this.columns = teacherArr
      })
    },
    afterRead(file) {
      let data = new FormData()
      data.append('multipartFile', file.file)
      uploadFile(data).then(res => {
        this.formData.attachPath = res.data.path
        file.attachPath = res.data.path
      })
    },
    beforeRead(file) {
      if (file.type === 'image/jpeg' || file.type === 'image/png') {
        return true;
      } else {
        this.$toast.fail('请上传图片');
        return false;
      }
    },
    filterFn(type, options) {
      if (type === 'hour') {
        let arr = []
        options.forEach(item => {
          if (parseInt(item) === 9 || parseInt(item) === 13) {
            arr.push(item)
          }
        })
        return options = arr;
      }
      return options;
    },
    getDaysFn() {
      getLeaveVerification({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        let data = res.data.data;
        this.leaveDays = data["maxLeaveDays"] - data["totalDays"]
      })
    },
    onChange(picker, value) {
      this.columnsValue = value
    },
    currentTeacherFn() {
      currentTeacher({
        "studentId": localStorage.getItem('studentId') || ''
      }).then(res => {
        this.formData.medicalTeamLeaderName = res.data.data.teacherName
        this.formData.medicalTeamLeaderId = res.data.data.teacherStaffId
        this.formData.studentName = res.data.data.studentName
        this.formData.studentId = res.data.data.studentId
      })
    },
    // 缓存本地
    getSession() {
      sessionStorage.setItem('currentData', JSON.stringify(this.formData))
    },
  },
  mounted() {
    let currentForm = JSON.parse(localStorage.getItem('currentData') || "{}")
    let len = Object.keys(currentForm).length
    if (len === 0) {
      this.action = 3
      this.currentTeacherFn()
    } else {
      this.action = currentForm.status
      this.formData = Object.assign(this.formData, currentForm)
      let str = this.formData.favourTime.substring(10)
      if (str.indexOf('09') > 0) {
        this.columnsValue = '上午'
      } else {
        this.columnsValue = '下午'
      }
    }
    this.leaveTypeGet() // 获取类型
    this.teacherGet() // 获取带教老师
    this.getDaysFn() // 获取请假天数
    // 获取头像
    let uploadData = JSON.parse(sessionStorage.getItem('uploadData') || '{}')
    if (uploadData.path !== '') {
      this.formData[uploadData.target] = uploadData.path;
    }
  }
}
</script>
