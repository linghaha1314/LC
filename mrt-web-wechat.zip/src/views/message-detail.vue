<template>
  <div class="about">
    <van-nav-bar title="消息详情" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="padding: 20px 12px; text-align: center;">
      <div style="font-size: 18px; margin-bottom: 12px">
        {{data.title || '无'}}
      </div>
      <div style="padding: 20px 12px;text-align: justify; color: #333333">{{data.content || '无'}}</div>

    </div>
    <div style="padding: 24px;text-align: right; color: #17D4B5" v-for="item in file" :key="item.id">
        <a :href="item.attachPath || ''" download="附件">
            {{item.attachPath ? item.attachPath.split('/')[item.attachPath.split('/').length-1] : '未找到该附件'}}
        </a>
    </div>
  </div>
</template>
<script>
    import { updateBymessageId, updateStatus, msgFile } from '../http/apiMap';
    export default {
        name: 'message-detail',
        data(){
            return{
                msg:'',
                data: this.$route.query.item,
                code: this.$route.query.code,
                flag: this.$route.query.flag,
                file: []
            }
        },
        computed:{
            name(){
                return this.$route.name
            },
        },
        methods:{
            isKnow(){
                let param = {
                    id: this.data.id,
                    messageId: this.data.messageId
                }
                if(this.code === 'notify'){ // 通知
                    updateBymessageId(param).then()
                }else{
                    updateStatus({
                        id: this.data.id,
                        status: 1
                    }).then()
                }
            },
            // 获取消息附件
            msgFileFn(){
                msgFile({
                    messageId: this.data.messageId
                }).then(res => {
                    this.file = res.data.list
                })
            }
        },
        mounted() {
            if(this.flag === 'unread'){
                this.isKnow() // 已读
            }
            if(this.data.messageId){
                this.msgFileFn() // 消息附件
            }
        }
    }
</script>