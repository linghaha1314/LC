<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="姓名:" :value="currentData.name"/>
        <van-cell title="性别:" :value="currentData['genderName']"/>
        <van-cell title="生日:" :value="currentData['birthday'] && currentData['birthday'].substring(0,10)"/>
        <van-cell title="身份证号码:" :value="currentData['identifyNo']"/>
        <van-cell title="民族:" :value="currentData['nationName']"/>
        <van-cell title="学历:" :value="currentData['academicName']"/>
        <van-cell title="家庭住址:" :value="currentData['genderName']"/>
        <van-cell title="手机号码:" :value="currentData['mobile'] || '无'"/>
        <van-cell title="科室:" :value="currentData.sectionName||'无'"/>
        <van-cell title="专业:" :value="currentData.majorName||'无'"/>
        <van-cell title="从事专业:" :value="currentData['professionals']||'无'"/>
        <van-cell title="职称:" :value="currentData.titleName||'无'"/>
        <van-cell title="状态:" :value="statusFn"/>
        <van-cell title="资格证书:">
          <template #label>
            <div>
              <img v-for="item in fileZiList" style="width: 100%" :src="item.url" :key="item.url">
            </div>
          </template>
        </van-cell>
        <van-cell title="执业证书:">
          <template #label>
            <div>
              <img v-for="item in fileZhiList" style="width: 100%" :src="item.url" :key="item.url">
            </div>
          </template>
        </van-cell>
        <van-cell title="毕业证书:">
          <template #label>
            <div>
              <img v-for="item in fileBiList" style="width: 100%" :src="item.url" :key="item.url">
            </div>
          </template>
        </van-cell>
        <van-cell title="学历证书:">
          <template #label>
            <div>
              <img v-for="item in fileXueList" style="width: 100%" :src="item.url" :key="item.url">
            </div>
          </template>
        </van-cell>
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
import {urlForGet, urlForPost} from '../http/apiMap'
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: '申请详情',
      fileZiList: [],
      fileZhiList: [],
      fileBiList: [],
      fileXueList: [],
      // formData: {},
      saveArr: [
        {file: 'fileZiList', code: 'Credentials'},
        {file: 'fileZhiList', code: 'PracticeCertificate'},
        {file: 'fileBiList', code: 'GraduationCertificate'},
        {file: 'fileXueList', code: 'TheHighestDegree'}
      ]
    }
  },
  computed: {
    typeFn(){
      let row = this.currentData
      let education = "";
      let union = "";
      let support = "";
      if (row['educationFlag']==='true') {
        education = "普通进修"
      }
      if (row['unionsFlag']==='true') {
        union = "医联体"
      }
      if (row['supportFlag']==='true') {
        support = "对口帮扶"
      }
      return " " + education + " " + union + " " + support + " ";
    },
    statusFn(){
      let value = parseInt(this.currentData.status)
      switch (value) {
        case 0:
          return "未申请";
        case 11:
          return "已申请";
        // case 2:
        //   return "已结业";
        // case 3:
        //   return "拟结业";
        // case 4:
        //   return "结业中";
        default :
          return "--";
      }
    }
  },
  methods: {
    certificateInfo() {

      urlForPost('/advancedsignup/getListByPage',{
        staffId: this.currentData.teacherId,
        typeCode: ''
      }).then(res => {
        let data = res.data.data.list
        data.forEach(item => {
          this.saveArr.forEach(ite => {
            if(item.typeCode === ite.code){
              this[ite.file].push({
                url: item.attachCert,
                pathAttach: item.attachCert,
                id: item.id
              })
            }
          })
        })
      })
    },
  },
  mounted() {
    urlForGet('/staff/getStaffDetail',this.currentData.teacherId
    , 'teacherId').then(res => {
      let data = res.data.data
      let target = Object.assign(this.currentData, data)
      this.$set(this, 'currentData', target)
    })
    this.certificateInfo()
  }
}
</script>
