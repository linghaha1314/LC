<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div class="p12" style="padding: 15px 12px;font-size: 16px;text-align: center;">
      {{ testQuery.name || '无' }}
    </div>
    <!--间隔-->
    <div style="width:100%; height: 7px; background: #f6f6f6"></div>

    <div class="p12">

      <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #efefef;padding: 12px 0;
">
        <div>考试时间</div>
        <div style="color:#999999;">{{ testQuery.startDate }} 至 {{ testQuery.endDate }}</div>
      </div>
      <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #efefef;padding: 12px 0;
">
        <div>备注内容</div>
        <div style="color:#999999;">{{ testQuery.remark || '无' }}</div>
      </div>
      <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #efefef;padding: 12px 0;
">
        <div>试卷名称</div>
        <div style="color:#999999;">{{ pagerInfo.title }}</div>
      </div>
    </div>

    <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    <div class="p12" v-if="testQuery.completed==='true'">
      <div
          style="font-size: 20px;text-align: center;padding: 24px;color: #17D4B5;border-bottom: rgb(239, 239, 239) solid 1px;">
        得分: {{ testInfo['score'] }}
      </div>
      <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #efefef;padding: 12px 0;
">
        <div>考试时长</div>
        <div style="color:#999999;">{{ Math.abs(testInfo['totalTime']) }}分钟</div>
      </div>
    </div>
    <div class="p12" v-if="testQuery.completed !== 'true'">
      <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #efefef;padding: 12px 0;
">
        <div>考试总分</div>
        <div style="color:#999999;">{{ pagerInfo['totalScore'] }}分</div>
      </div>
      <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #efefef;padding: 12px 0;
" v-if="pagerInfo['timeLimit']">
        <div>考试限时</div>
        <div style="color:#999999;">{{ pagerInfo['timeLimit'] }}分钟</div>
      </div>
    </div>
    <div>
      <!--      <van-collapse v-model="activeNames">-->
      <!--        <van-collapse-item title="注意事项" name="1">1、考生必须自觉服从监考员等考试工作人员管理，不得以任何理由妨碍监考员等考试工作人员履行职责，不得扰乱考场及其他考试工作地点的秩序。-->
      <!--          <br>-->
      <!--          <br>-->
      <!--          2、考生凭准考证、身份证，按规定时间和准考证上各科目的考试试室、座位号参加考试。-->
      <!--        </van-collapse-item>-->
      <!--      </van-collapse>-->
      <div style="padding: 30px 12px;" v-if="testQuery.onlineFlag==='1'||testQuery.onlineFlag==='1'">
        <router-link replace :to="{path:'/paper',query:paperParam}" v-if="!isDisable||testQuery.completed==='true'">
          <!--          :disabled="testQuery.completed==='true'"-->
          <van-button round type="primary" :disabled="isDisable&&testQuery.completed!=='true'" block color="#17d4b5">
            {{ testQuery.completed === 'true' ? '查看试题答案' : '开始考试' }}
          </van-button>
        </router-link>
        <van-button round type="primary" :disabled="isDisable" block color="#17d4b5"
                    v-if="isDisable&&testQuery.completed!=='true'">未在考试时间内
        </van-button>
      </div>
      <div v-else style="text-align: center;color: #333">
        此考试为线下考试!
      </div>
    </div>
  </div>
</template>
<script>
import {examMsg, examPaperMsg} from '../http/apiMap';

export default {
  name: 'test',
  data() {
    return {
      activeNames: ['1'],
      testQuery: this.$route.query,
      name: this.$route.name,
      testInfo: {},
      paperParam: {},
      pagerInfo: {},
      isDisable: true
    }
  },
  mounted() {
    examMsg(this.$route.query.examAnswerId).then(res => { // 考试信息
      // examMsg('080eb133-668c-11eb-8ea8-00163e0603fa').then(res => {
      this.testInfo = res.data.data
    })
    if (this.testQuery.onlineFlag==='1'||this.testQuery.onlineFlag==='1') {
      examPaperMsg(this.$route.query.volumeId).then(res => { // 试卷信息
        // examPaperMsg('e766b833-5f8a-11eb-b1bc-00163e0603fa').then(res => {
        this.pagerInfo = res.data.data
        this.paperParam.time = this.pagerInfo['timeLimit']
        this.paperParam.paperParam = {
          "examId": this.$route.query.id,
          "volumeId": this.$route.query.volumeId,
          "pid": this.$route.query.volumeId,
          "isCompleted": this.$route.query.completed
        }
      })
    }
    this.checkTimeUp()
  },
  methods: {
    checkTimeUp() {
      let now = (new Date()).valueOf(),
          lTime = (new Date(this.testQuery.startDate.replace(/-/g, "/"))).valueOf(),
          mTime = (new Date(this.testQuery.endDate.replace(/-/g, "/"))).valueOf();
      if (now > lTime && now < mTime) {
        this.isDisable = false
      } else {
        if (this.testQuery.completed !== 'true') {
          this.$toast.fail('不在考试时间!');
          this.isDisable = true;
        }
      }
    }
  }
}
</script>
<style lang="less">
.p12 {
  padding: 0 12px;
}
</style>
