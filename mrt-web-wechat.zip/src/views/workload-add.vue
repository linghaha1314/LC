<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        {{ formTitle[action_form] }}
      </div>
    </div>
    <van-form @submit="onSubmit" ref="basicInfoForm" style="padding: 0 12px">
      <template v-if="action_form===0">
        <van-field v-model="userName" disabled name="remake" readonly label="登记人"/>
        <van-field name="people" readonly disabled clickable label="带教老师" :value="basicInfo.teacherName"
                   placeholder="选择带教老师"
        />
<!--        <van-popup v-model="showPicker" round position="bottom">-->
<!--          <Pager url="/teacher/listQueryTeacher" @check="checkFn"></Pager>-->
<!--        </van-popup>-->
        <van-field readonly clickable disabled name="typeId" label="科室" :value="basicInfo.sectionName||'无'"
                   placeholder="选择科室"
        />
<!--        <van-popup v-model="showSectionPicker" round position="bottom">-->
<!--          <div>-->
<!--            <van-search v-model="sName" shape="round" @change="transferGet" placeholder="搜索"/>-->
<!--          </div>-->
<!--          <van-picker :columns="sectionColumns" :show-toolbar="true" @cancel="showSectionPicker = false"-->
<!--                      @confirm="onConfirm($event,basicInfo,'sectionName','sectionId','showSectionPicker')"-->
<!--          />-->
<!--        </van-popup>-->

        <van-field readonly clickable disabled name="typeId" label="专业" :value="basicInfo.majorName||'无'"
                   placeholder="选择专业" @click="isDisabledFn('showMajorPicker')"
                   />
<!--        <van-popup v-model="showMajorPicker" round position="bottom">-->
<!--          <van-picker :columns="majorColumns" :show-toolbar="true" @cancel="showMajorPicker = false"-->
<!--                      @confirm="onConfirm($event,basicInfo,'majorName','majorId','showMajorPicker')"-->
<!--          />-->
<!--        </van-popup>-->
        <van-field readonly clickable name="startDate" required label="登记月份" :value="basicInfo.period"
                   placeholder="选择登记月份" @click="showDateMoPicker= role==='StudentType_jxs'"
                   :rules="[{ required: true, message: '请选择登记月份' }]"/>
        <van-popup v-model="showDateMoPicker" style="height: 50vh" round position="bottom">
          <!-- <van-radio-group style="margin:24px" v-model="checked" @change="redioFn">
  <van-radio style="margin-bottom: 12px" name="1">当前月</van-radio>
  <van-radio name="2">上个月</van-radio>
  </van-radio-group> -->
          <van-datetime-picker v-model="currentDate" type="year-month" title="选择年月"
                               @cancel="showDateMoPicker = false" @confirm="onDateConfirm" :min-date="minDateC"
          />
        </van-popup>
        <van-field readonly clickable name="startDate" required label="开始时间" :value="basicInfo.startDate&&basicInfo.startDate.substring(0,10)"
                   placeholder="选择开始时间" @click="showDatePicker = true" :rules="[{ required: true, message: '请选择开始时间' }]" />
        <van-popup v-model="showDatePicker" round position="bottom">
          <div>
            <van-datetime-picker v-model="basicInfo.currentDate" type="date" @cancel="showDatePicker = false" @confirm="onDateConfirms($event,basicInfo,'startDate','showDatePicker')"/>
          </div>
        </van-popup>
        <van-field readonly clickable name="endDate" required label="结束时间" :value="basicInfo.endDate&&basicInfo.endDate.substring(0,10)"
                   placeholder="选择结束时间" @click="showEndDatePicker = true" :rules="[{ required: true, message: '请选择结束时间' }]" />
        <van-popup v-model="showEndDatePicker" round position="bottom">
          <div>
            <van-datetime-picker v-model="basicInfo.currentEndDate" type="date" @cancel="showEndDatePicker = false" @confirm="onDateConfirms($event,basicInfo,'endDate','showEndDatePicker')"/>
          </div>
        </van-popup>
        <van-field v-model="basicInfo.liveDetailAddress" name="liveDetailAddress" required label="现居住地详细地址"
                   placeholder="请输入现居住地详细地址" type="textarea" rows="5" maxlength="100" show-word-limit :autosize="true"
                   :rules="[{ required: true, message: '请填写现居住地详细地址'}]"
        />
      </template>
      <template v-if="action_form===1">
        <div style="text-align: center; color: orangered" v-if="role==='StudentType_jxs'">请确认考勤信息,如无误请点 "下一步"</div>
        <div style="text-align: center; color: orangered" v-if="role==='sectionManager' || role==='headNurse' || role==='teacher'">请确认考勤信息,如有旷工请填写</div>
        <van-field v-model="attendInfo.affairDays" type="number" readonly label="事假"/>
        <van-field v-model="attendInfo.illnessDays" type="number" readonly label="病假"/>
        <van-field v-model="attendInfo.skipWorkDays" type="number" :required="!(role==='sectionManager' || role==='headNurse' || role==='teacher')"
                   :readonly="!(role==='sectionManager' || role==='headNurse' || role==='teacher')"
                   label="旷工"/>

        <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
          <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
            值班情况
          </div>
        </div>
        <van-field v-model="basicInfo.independentDuty" required type="number" label="独立值班天数" :rules="[{ required: true, message: '请填写' }]"/>
        <van-field name="checkAbility" label="是否通过综合能力考核" required v-if="basicInfo.independentDuty>0" :value="basicInfo.checkAbility" :rules="[{ required: true, message: '请选择' }]">
          <template #input>
            <van-radio-group v-model="basicInfo.checkAbility" direction="horizontal">
              <van-radio :name="0">否</van-radio>
              <van-radio :name="1">是</van-radio>
            </van-radio-group>
          </template>
        </van-field>
        <van-field v-model="basicInfo.partakeDay" required type="number" label="参与值班天数" :rules="[{ required: true, message: '请填写' }]"/>
        <van-field v-model="basicInfo.administrationDay" required type="number" label="行政班天数" :rules="[{ required: true, message: '请填写' }]"/>
        <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
          <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
            其他情况
          </div>
        </div>
        <van-field name="disputeFlag" label="是否发生医疗纠纷" :value="basicInfo.disputeFlag">
          <template #input>
            <van-radio-group :disabled="!(role==='sectionManager' || role==='headNurse')" v-model="basicInfo.disputeFlag" direction="horizontal">
              <van-radio :name="0">否</van-radio>
              <van-radio :name="1">是</van-radio>
            </van-radio-group>
          </template>
        </van-field>
        <van-field name="malpracticeFlag" label="是否发生医疗事故" :value="basicInfo.malpracticeFlag">
          <template #input>
            <van-radio-group :disabled="!(role==='sectionManager' || role==='headNurse')" v-model="basicInfo.malpracticeFlag" direction="horizontal">
              <van-radio :name="0">否</van-radio>
              <van-radio :name="1">是</van-radio>
            </van-radio-group>
          </template>
        </van-field>
        <van-field name="violationFlag" label="是否违反相关纪律" :value="basicInfo.violationFlag">
          <template #input>
            <van-radio-group :disabled="!(role==='sectionManager' || role==='headNurse')" v-model="basicInfo.violationFlag" direction="horizontal">
              <van-radio :name="0">否</van-radio>
              <van-radio :name="1">是</van-radio>
            </van-radio-group>
          </template>
        </van-field>
      </template>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>


      <div style="margin: 16px;" v-if="action_form===0">
        <van-button :disabled="!basicInfo.teacherName || isDate" round block color="#17d4b5" @click="addWorkload">
          下一步
        </van-button>
      </div>
      <div style="margin: 16px;display: flex;" v-if="action_form===1">
        <van-button style="margin-bottom: 12px;" round block @click="goPre">
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          下一步
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
// import Pager from '../components/searchPager'
import {
  advancedWorkload,
  advancedWorkloadAttend,
  advancedworkloadattendList,
  getlLeaveDay,
  getTransferscheduleCode,
  staffTypeWord,
  submajorList,
  getTransferSchedule,
  getStudentInfo,
  getDetailWorkload,
  urlForPost
} from '../http/apiMap'
import { Dialog } from 'vant';

export default {
  name: 'test',
  components: {
  },
  data() {
    return {
      isDate: false,
      formData: {

      },
      basicInfo: {
        "period": "",
        "remark": "",
        "id": '',
        "status": 0,
        "teacherName": '',
        "teacherId": "03d866b2-761e-11e9-ba47-144f8a3ef444",
        "workloadStaffTypeId": '',
        "workloadStaffTypeName": '',
        "sectionId": "",
        sectionName: '',
        "majorId": "",
        majorName: '',
        liveDetailAddress: '',
        currentDate: new Date(),
        currentEndDate: new Date(),
      },
      attendInfo: {
        "affairDays": 0,
        "id": '',
        "illnessDays": 0,
        "skipWorkDays": 0,
        independentDuty: 0,
        partakeDay: 0,
        administrationDay: 0,
        "workloadId": '',
        checkAbility: 0,
        disputeFlag: 0,
        malpracticeFlag: 0,
        violationFlag: 0,
      },
      attendListParam: {
        workloadId: '',
        pageSize: 999,
        pageNum: 1
      },
      userName: '',
      formTitle: [
        '基本信息',
        '考勤情况'
      ],
      showPicker: false,
      showTypePicker: false,
      showDateMoPicker: false,
      showDatePicker: false,
      showEndDatePicker: false,
      showStartTimePicker: false,
      showSectionPicker: false,
      showMajorPicker: false,
      showEndTimePicker: false,
      currentWorkloadData: {},
      action_form: 1,
      sectionColumns: [],
      majorColumns: [],
      minDateC: new Date(2020, 1),
      maxDate: new Date(),
      currentDate: new Date(),
      currentTime: '12:00',
      currentEndDate: '12:00',
      role: '',
      isDisabled: false, // 是否可编辑,
      readonly: true, // 是否可编辑,
      option1: [],
      sName: '',
      isShow: false,
      checked: '',
      transferFlag: false,
      isSpecial: false,
      parentId: '',
      specialFlag: false
    }
  },
  computed: {
    name() {
      if(this.role === 'StudentType_jxs'){
        let nameArr = [
          '基本信息',
          '综合信息汇总'
        ]
        return nameArr[this.action_form]
      }else {
        return '查看填写信息'
      }
    },
    typeColumns() {
      let arr = []
      this.option1.map(item => {
        arr.push(item.name)
      })
      return arr;
    },
    minDate() {
      let date = new Date()
      return new Date(date.getFullYear, date.getMonth - 1)
    }
  },
  methods: {
    onSubmit(data) {
      localStorage.setItem('addItem', JSON.stringify(data))
    },
    // 添加工作量
    addWorkload() {
      this.$refs.basicInfoForm.validate().then(() => {
        this.attendInfo.workloadId = localStorage.getItem('workloadId')
        this.attendListParam.workloadId = localStorage.getItem('workloadId')
        localStorage.setItem('workType', this.basicInfo.workloadStaffTypeName === '医师' ? '医师' + this.basicInfo.outpatientFlag : this.basicInfo.workloadStaffTypeName)
        if (this.role === 'StudentType_jxs') {
          this.getLeaveDayFn()
          if (!this.basicInfo.status || this.basicInfo.status === 0 || this.basicInfo.status === 1) {
            localStorage.setItem('currentWorkloadData', JSON.stringify(this.basicInfo))
            // 搜索是否已添加
            // advancedWorkloadList({
            //   period: this.basicInfo.period,
            //   // studentId: localStorage.getItem('studentId') || ''
            // }).then(res => {
            //   let tData = [...res.data.list]
            //   if (tData && tData.length === 0 || this.basicInfo.id) {
            //     // this.basicInfo.status === 0 || tData.length === 0 || this.basicInfo.status === 1
            //     if (this.basicInfo.status === 0 || this.basicInfo.status === 1) {
            //       if (this.basicInfo.status === 1) {
            //         this.basicInfo.status = 0
            //       }
            //       advancedWorkload(this.basicInfo).then(res => {
            //         if (res.data.data.success) {
            //           this.action_form = 1
            //           this.attendInfo.workloadId = res.data.data["reasons"].data.id
            //           this.attendListParam.workloadId = res.data.data["reasons"].data.id
            //           this.basicInfo.id = res.data.data["reasons"].data.id
            //           localStorage.setItem('workloadId', this.attendInfo.workloadId)
            //           if (this.basicInfo.status === 0) {
            //             this.advancedworkloadattendListFn(); // 搜索考勤
            //           }
            //         } else {
            //           this.$toast.fail('提交出错!请重试!')
            //         }
            //       })
            //     }
            //   }
            //   else {
            //     this.$toast.success('您该月份的已经填写完毕!')
            //
            //   }
            // })
            if (this.basicInfo.status === 0 || this.basicInfo.status === 1) {
              if (this.basicInfo.status === 1) {
                this.basicInfo.status = 0
              }
              if (!(this.basicInfo.startDate.substring(0,7)===this.basicInfo.period || this.basicInfo.endDate.substring(0,7)===this.basicInfo.period)) {
                Dialog.alert({
                  title: '温馨提示:',
                  message: '填写时间有误, 请确认!',
                }).then(() => {
                });
                return
              }
              // student/updateLivePlace
              // 参数：
              // studentId:当前学员的id
              // livePlace:
              urlForPost('/student/updateLivePlace',{
                studentId: localStorage.getItem('studentId') || '',
                livePlace: this.basicInfo.liveDetailAddress
              }).then()
              advancedWorkload(this.basicInfo).then(res => {
                if (res.data.data.success) {
                  this.action_form = 1
                  this.attendInfo.workloadId = res.data.data["reasons"].data.id
                  this.attendListParam.workloadId = res.data.data["reasons"].data.id
                  this.basicInfo.id = res.data.data["reasons"].data.id
                  localStorage.setItem('workloadId', this.attendInfo.workloadId)
                  if (this.basicInfo.status === 0) {
                    this.advancedworkloadattendListFn(); // 搜索考勤
                  }
                } else {
                  this.$toast.fail('提交出错!请重试!')
                }
              })
            }
          } else {
            this.action_form = 1
            this.advancedworkloadattendListFn(); // 搜索考勤
            sessionStorage.setItem('isSubmit', this.formData.status.toString())
          }
        } else {
          this.action_form = 1
          this.advancedworkloadattendListFn(); // 搜索考勤
        }
      }).catch(() => {
      })
    },
    // 添加考勤详情
    attendAdd() {
      let h = parseInt(this.basicInfo.independentDuty)+parseInt(this.basicInfo.partakeDay)+parseInt(this.basicInfo.administrationDay)
      if(h<=28){
        advancedWorkload(this.basicInfo).then()
        advancedWorkloadAttend(this.attendInfo).then(() => {
          this.$router.push('/workload-clinical')
        })
      }else{
        this.$toast.fail('值班情况合计超过28天, 请确认后重填!')
      }
    },

    onConfirm(value, target, name, id, show) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (id === 'sectionId') {
        this.submajorListFn();
      }
    },

    onTypeConfirm(value, index) {
      this.basicInfo.workloadStaffTypeName = value;
      this.basicInfo.workloadStaffTypeId = this.option1[index].id;
      this.showTypePicker = false;
    },
    onSectionConfirm(value) {
      this.basicInfo.sectionName = value.text;
      this.basicInfo.sectionId = value.value;
      this.showSectionPicker = false;
    },
    onMajorConfirm(value) {
      this.basicInfo.majorName = value.text;
      this.basicInfo.majorId = value.value;
      this.showMajorPicker = false;
    },
    onDateConfirm(value) {
      this.formData.dateValue = this.getNowFormatDate(value)
      this.basicInfo.period = value.getFullYear() + "-" + (value.getMonth() + 1 < 10 ? '0' + (value.getMonth() + 1) : value.getMonth() + 1)
      this.showDateMoPicker = false;
      this.getDateA(this.basicInfo.period)
    },

    onDateConfirms(value,target,prop,show) {
      target[prop] = this.getNowFormatDate(value)+' 00:00:00'
      this[show] = false;
    },
    // 时间格式
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }
      return year + seperator1 + month + seperator1 + strDate;
    },
    // 开始时间
    onStartDateConfirm(value) {
      this.formData.startValue = value
      this.showStartTimePicker = false;
    },
    // 结束时间
    onEndDateConfirm(value) {
      this.formData.endValue = value
      this.showEndTimePicker = false;
    },
    goPre() {
      localStorage.setItem('formAction', '0')
      this.action_form = 0 // setLc
    },
    getLocalDate() {
      let date = new Date()
      let year = date.getFullYear()
      let month = date.getMonth()
      if (month === 0) {
        this.basicInfo.period = `${year - 1}-${12}`
      } else {
        this.basicInfo.period = `${year}-${month < 10 ? "0" + month : month}`
      }
    },
    checkFn(data) {
      this.basicInfo.teacherId = data.value
      this.basicInfo.teacherName = data.text
      this.showPicker = false
    },
    // 获取考勤信息
    advancedworkloadattendListFn() {
      advancedworkloadattendList(this.attendListParam).then(res => {
        let data = res.data ? res.data.list[0] : {}
        if (data) {
          if (this.role !== 'StudentType_jxs' || this.basicInfo.status !== 0) {
            this.attendInfo.illnessDays = data.illnessDays || 0
            this.attendInfo.affairDays = data.affairDays || 0
          }
          this.attendInfo.skipWorkDays = data.skipWorkDays || 0
          this.attendInfo.id = data.id
        }
      })
    },
    isDisabledFn() {
      return false
    },
    getLeaveDayFn() {
      let studentId = localStorage.getItem('studentId') || ''

      getlLeaveDay({
        "studentId": studentId === 'undefined' ? this.currentWorkloadData.studentId : studentId,
        "month": this.basicInfo.period
      }).then(res => {
        let data = res.data.data
        if (data.length === 0) {
          this.attendInfo.affairDays = 0
          this.attendInfo.illnessDays = 0
        } else {
          let days = 0
          data.forEach(item => {
            if (item.type === '病假') {
              this.attendInfo.illnessDays = item.days
            } else {
              this.attendInfo.affairDays = days += item.days
            }
          })
        }
      })
    },
    staffTypeWordFn() {
      staffTypeWord('WorkloadStaffType').then(res => {
        this.option1 = res.data.data
      })
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule({
        pageNum: 1,
        pageSize: 999,
        name: this.sName,
        parentId: this.parentId || ''
      }).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.sectionColumns = [...optionArr]
      })
    },
    // 获取专业列表
    submajorListFn() {
      let p = {};
      if (this.isSpecial || this.transferFlag) {
        p = {
          pageSize: 999,
          pageNum: 1,
          sectionId: this.basicInfo.specialSectionId
        }
      } else {
        p = {
          pageSize: 999,
          pageNum: 1,
          sectionId: this.basicInfo.sectionId
        }
      }

      submajorList(p).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.majorColumns = [...optionArr]
      })
    },
    // redioFn(data) {
    //     let value = new Date()
    //     if (data === '1') { // 当前月
    //         this.basicInfo.period = value.getFullYear() + "-" + (value.getMonth() + 1 < 10 ? '0' + (value.getMonth() + 1) : value.getMonth() + 1)
    //     } else {
    //         this.basicInfo.period = value.getFullYear() + "-" + (value.getMonth() < 10 ? '0' + (value.getMonth()) : value.getMonth())
    //     }
    //     advancedWorkloadList({
    //         period: this.basicInfo.period
    //     }).then(res => {
    //         let tData = [...res.data.list]
    //         if (tData.length !== 0) {
    //             this.$toast.success('您上个月的已经填写完毕,请重选!')
    //             this.basicInfo.period = ''
    //         }
    //     })
    // },
    // 判断科室是否特殊处理
    getTransferscheduleFn() {
      let studentId = localStorage.getItem('studentId') || ''
      let thatV = this
      let type = null
      getTransferscheduleCode(studentId).then(res => {
        if (res.data && res.data.data) {
          this.transferFlag = !!res.data.data.transferId;
          this.specialFlag = res.data.data.specialFlag
          if (res.data.data.specialFlag) {
            thatV.basicInfo.workloadStaffTypeName = thatV.option1[2].name
            thatV.basicInfo.workloadStaffTypeId = thatV.option1[2].id
          }
          let resF = res
          getStudentInfo(studentId).then(re => { // 获取当前科室
            thatV.basicInfo.studentName = re.data.data.studentName;
            thatV.basicInfo.teacherName = re.data.data.teacherName;
            thatV.basicInfo.teacherId = re.data.data.teacherStaffId;
            thatV.basicInfo.specialSectionName = re.data.data.sectionName;
            thatV.basicInfo.sectionId = re.data.data.sectionId;
            thatV.basicInfo.sectionName = resF.data.data.name;
            thatV.basicInfo.majorName = re.data.data.majorName;
            thatV.basicInfo.liveDetailAddress = re.data.data["livePlace"];
            thatV.basicInfo.majorId = re.data.data["subMajorId"];
            type = re.data.data["staffTypeCode"];
            if (type !== 'Doctor') {
              thatV.basicInfo.majorId = re.data.data["subMajorId"];
              thatV.basicInfo.majorName = re.data.data.majorName;
            } else {
              thatV.basicInfo.completeNum = null;
            }

            thatV.isSpecial = re.data.data.isSpecial === 1; // 特殊科室

            if (!thatV.isSpecial && !thatV.transferFlag) { // 不是特殊也不是轮转就回填
              thatV.basicInfo.sectionId = re.data.data.sectionId;
              thatV.basicInfo.sectionName = resF.data.data.name;
              thatV.basicInfo.majorId = re.data.data["subMajorId"];
              thatV.basicInfo.majorName = re.data.data.majorName;
            }

            //判断如果是特殊科室则手动选择，并将科室id作为手动选择科室的父id参数
            if (thatV.isSpecial || thatV.transferFlag) {
              thatV.parentId = re.data.data.sectionId;
              thatV.basicInfo.specialSectionId = re.data.data.sectionId;
              thatV.basicInfo.specialSectionName = re.data.data.sectionName;
              this.transferGet()
            }
            thatV.basicInfo.sectionId = re.data.data.sectionId;
            thatV.basicInfo.sectionName = resF.data.data.name;
            thatV.basicInfo.majorId = re.data.data["subMajorId"];
            thatV.basicInfo.majorName = re.data.data.majorName;
          })
        } else {
          this.$toast.fail('您还没入科哟!')
        }
      })
    },
    getDetailWorkloadFn(id) {
      getDetailWorkload({
        id: id
      }).then()
    },
    getDateA(d){
      //       advancedworkload/queryWorkloadByStudentIdAndPeriod
      //       参数：
      // studentId:学员id
      //       period:2023-01
      let studentId = localStorage.getItem('studentId') || ''
      urlForPost('/advancedworkload/queryWorkloadByStudentIdAndPeriod',{
        studentId: studentId === 'undefined' ? this.currentWorkloadData.studentId : studentId,
        period: d
      }).then(r => {
        if(r.data.data.length > 1){
          this.$toast.fail('本月已经提交两次, 请核实后重新填写!')
          this.isDate = true
        }else{
          this.isDate = false
        }
      })
    }
  },
  mounted: function () {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let currentForm = JSON.parse(localStorage.getItem('currentWorkloadData') || "{}")
    if (!currentForm.id) { // 如果是添加过来的
      // this.getLocalDate();
      this.action_form = 0 // setLc
      if (this.role === 'StudentType_jxs') {
        this.userName = localStorage.getItem('staffName')

        // getCurrentSection().then(res => {
        //     this.basicInfo.sectionId = res.data.data.id
        //     this.basicInfo.sectionName = res.data.data.name
        //     // this.isShow = false
        // })
        // currentTeacher({
        //     "studentId": localStorage.getItem('studentId') || ''
        // }).then(res => {
        //     if(res.data&&res.data.data){
        //         this.basicInfo.teacherName = res.data.data.teacherName
        //         this.basicInfo.teacherId = res.data.data.teacherStaffId
        //     }
        // })
        this.getTransferscheduleFn()
      }
    } else { // 如果是修改的过来的
      this.getDetailWorkloadFn(currentForm.id)
      this.basicInfo = JSON.parse(localStorage.getItem('currentWorkloadData') || '')
      this.basicInfo.outpatientFlag = parseInt(this.basicInfo.outpatientFlag)
      this.basicInfo.status = parseInt(this.basicInfo.status)
      this.basicInfo.specialSectionId = this.basicInfo.sectionId
      this.basicInfo.specialSectionName = this.basicInfo.sectionName
      this.basicInfo.checkAbility = !this.basicInfo.checkAbility ? 0 : 1
      this.basicInfo.disputeFlag = !this.basicInfo.disputeFlag ? 0 : 1
      this.basicInfo.malpracticeFlag = !this.basicInfo.malpracticeFlag ? 0 : 1
      this.basicInfo.violationFlag = !this.basicInfo.violationFlag ? 0 : 1
      this.currentWorkloadData = currentForm
      this.userName = this.basicInfo.userName
      // this.basicInfo.remark = currentForm.remark
      // this.basicInfo.teacherName = currentForm.teacherName
      // this.basicInfo.id = currentForm.id
      // this.basicInfo.teacherId = currentForm.teacherId
      localStorage.setItem('workloadId', currentForm.id) // 缓存id
      this.action = currentForm.status
      this.isDisabled = currentForm.status === 0 || currentForm.status === 1
      // this.formData = Object.assign(this.formData, currentForm)
    }
    localStorage.setItem('currentData', '') // 缓存本地数据
    this.action_form = parseInt(localStorage.getItem('formAction') || '0');
    // this.action_form = 1  // setLc
    this.staffTypeWordFn();
  }
}
</script>
