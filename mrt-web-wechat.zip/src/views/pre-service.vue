<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div>
      <van-dropdown-menu active-color="#17d4b5">
<!--        <van-dropdown-item title="日期">-->
<!--          <van-calendar-->
<!--              :poppable="false"-->
<!--              :style="{ height: '500px' }"-->
<!--              :min-date="new Date('2020/01/01')"-->
<!--              :show-confirm="false"-->
<!--              :show-title="false"-->
<!--              @confirm="dateConfirm"/>-->
<!--        </van-dropdown-item>-->
        <year-drop v-model="listParams.enrollYear" @change="getList"></year-drop>
        <batch-drop v-model="listParams.batchId" @change="getList"></batch-drop>
        <!--        <van-dropdown-item title="带教老师" ref="teacher">-->
        <!--          <Pager url="/teacher/listQueryTeacher" @check ="checkFn"></Pager>-->
        <!--        </van-dropdown-item>-->
        <!--        <van-dropdown-item title="状态" v-model="listParam.status" :options="option2" @change="advancedWorkloadListFn"/>-->
      </van-dropdown-menu>
    </div>
    <div>
      <van-search
          v-model="listParams.name"
          shape="round"
          @change="getList"
          placeholder="搜索学生名字"
      />
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.id">
            <div>
              <div style="font-size: 14px;display: flex;justify-content: space-between;">
                学生:
                {{ data.studentName || '无' }}
                <!--          <div style="width: 4em; margin-left: 12px">-->
                <!--            <van-tag style="text-align: center" :type="'danger'" v-if="data.status===2" size="medium">已结束</van-tag>-->
                <!--            <van-tag style="text-align: center" :type="'warning'" v-if="data.status===1" size="medium">已发布</van-tag>-->
                <!--            <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交</van-tag>-->
                <!--          </div>-->
              </div>
              <van-divider/>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">科室:</div>
                <div>{{ data.sectionName || '无' }}</div>
              </div>
              <!--        <div style="margin-bottom: 10px">-->
              <!--          <div style="color: #cccccc;margin-bottom: 4px;">签到日期:</div>-->
              <!--          <div>{{data.startDate.substring(0,10)}}</div>-->
              <!--        </div>-->
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">早上签到:</div>
                <!--          <div>{{data['amCheckTime'] || '未签到'}}</div>-->
                <div>{{ data['amSigninFlag'] ? '已签到' : '未签到' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">下午签到:</div>
                <!--          <div>{{data['pmCheckTime'] || '未签到'}}</div>-->
                <div>{{ data['pmSigninFlag'] ? '已签到' : '未签到' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div style="color: #cccccc;margin-bottom: 4px;">签到地址:</div>
                <div>{{ data.address || '无' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
              <keep-alive>
                <router-link :to="{path:'/pre-service-detail',query:data}">
                  <van-button style="width: 4em;" type="primary"
                              size="mini">详情
                  </van-button>
                </router-link>
              </keep-alive>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>

      <div style="position: fixed;right: 26px;bottom: 60px"
      >
        <router-link to="/pre-service-add">
          <van-icon color="#ff0000" name="add" size="40"/>
        </router-link>
      </div>
    </div>
  </div>
</template>
<script>
import {getDictionaryType, getTransferSchedule, preJobTrainingRecord} from '../http/apiMap';
import YearDrop from '../components/year-drop'
import BatchDrop from '../components/batch-drop'
export default {
  name: 'test',
  components:{
    YearDrop,
    BatchDrop
  },
  data() {
    return {
      value: '',
      listParams: {
        enrollYear: '',
        startDate: '',
        pageSize: 10,
        pageNum: 0
      },
      role: '',
      option1: [],
      option2: [ // 上级
        {text: '全部', value: null},
        {text: '已结束', value: 2},
        {text: '已发布', value: 1},
        {text: '未提交', value: 0},
      ],
      option3: [ // 学生
        {text: '全部', value: null},
        {text: '已结束', value: 2},
        {text: '已发布', value: 1},
      ],
      option4: [],
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      testData: [],
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    this.getTypeList();
    this.transferGet();
  },
  methods: {
    // goDetail(data){
    //     localStorage.setItem('currentData',JSON.stringify(data))
    //     this.$router.push({
    //         path: '/pre-service-detail',
    //         query: data
    //     })
    // },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.getList(flag)
    },

    // 获取列表
    getList(f) {
      preJobTrainingRecord(this.listParams).then(res => {
        // this.testData = res.data.list;
        if (f === 'onLoad') {
          this.state.loading = false;
          if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
            this.state.finished = true
          }
          if(res.data.total === 0){
            this.testData = []
          }else{
            this.testData = [...this.testData, ...res.data.list];
          }
        } else {
          this.testData = [...res.data.list];
        }
      })
    },
    // 获取类型
    getTypeList() {
      getDictionaryType('TeachActivityType').then(res => {
        let data = res.data.data
        let arr = [{
          text: '全部',
          value: ''
        }]
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          arr.push(obj)
        })
        this.option1 = arr;
      })
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option4 = [...optionArr]
      })
    },
    // 时间格式
    formatDate(date) {
      return `${date.getFullYear()}-${date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1}-${date.getDate() < 10 ? '0' + date.getDate() : date.getDate()}`;
    },
    // 筛选条件
    dateConfirm(date) {
      this.listParams.startDate = this.formatDate(date);
      this.getList();
    },
  }
}
</script>
