<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell title="状态">
          <template #default>
            <div v-if="currentData.status==='2'" style="color: #17D4B5">
              已通过
            </div>
            <div v-if="currentData.status==='11'" style="color: #1a1aff">
              审核中
            </div>
            <div v-if="currentData.status==='1'" style="color: #ff3333">
              已驳回
            </div>
          </template>
        </van-cell>
        <van-cell title="申请人:" :value="currentData.studentName"/>
        <van-cell title="申请科室:" :value="currentData.sectionName||'无'"/>
        <van-cell title="申请专业:" :value="currentData.majorName||'无'"/>
        <van-cell title="理论成绩:" :value="currentData.theoryScore||'无'"/>
        <van-cell title="技能成绩:" :value="currentData['skillScore']||'无'"/>
        <van-cell title="品行成绩:" :value="currentData['moralScore']||'无'"/>
        <van-cell title="自我鉴定:">
          <template #label>
            <div v-html="currentData.summary || '无'"></div>
          </template>
        </van-cell>
<!--        <van-cell title="当前带教老师:" :value="currentData.teacherName||'无'"/>-->

        <div style="width:100%; height: 7px; background: #f6f6f6"></div>

        <template v-if="role !== 'teacher'">
          <div v-for="item in teacherArr" :key="item.id">
            <van-cell style="width:100vw;" :title="`对${item.teacherName}老师的评价:`">
              <template #label>
                <div style="max-width:340px;overflow-wrap:break-word;box-sizing: border-box;">{{item['evaluateDetail']||'无'}}</div>
              </template>
            </van-cell>
          </div>
        </template>
        <div style="width:100%; height: 7px; background: #f6f6f6"></div>

        <van-cell style="width:100vw;" title="老师评语:">
          <template #label>
            <div style="max-width:340px;overflow-wrap:break-word;box-sizing: border-box;">
              {{ currentData.teachOpinion || '无' }}
            </div>
          </template>
        </van-cell>
        <van-cell title="科室考评:">
          <template #label>
            <div>{{ currentData['sectionResult'] || '无' }}</div>
          </template>
        </van-cell>
        <van-cell title="部门考评:" :label="currentData['deptResult']||'无'"/>
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
    <div style="width: 100vw" v-if="role==='StudentType_jxs'">
      <van-button style="margin: 24px auto; width: 80%" round block type="primary" @click="download" :disabled="!(downFlag === '2'||downFlag === 2)">
        {{downFlag === '2'||downFlag === 2 ? '下载结业证书' : '未发放结业证'}}
      </van-button>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {getStudentDetailDown, urlForPost} from '../http/apiMap'
export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: this.$route.name,
      downFlag: '',
      role: '',
      teacherArr: []
    }
  },
  computed: {},
  methods: {
    // 下载通知书
    download() {
      this.$router.push({
        path: '/download-page',
        query: {
          ...this.currentData,
          type: 'graduationCertificate'
        }
      })
    },
    getStudentDetailDownFn(){
      getStudentDetailDown({
        id: this.currentData.studentId
      }).then(res=>{
        if(res.data.success){
          this.downFlag = res.data.data.status
        }
      })
    },
    getTeacherPr(){
      urlForPost('/studentteacher/listMyToTeacherVolume',{
        studentId: this.currentData.studentId
      }).then(res => {
        this.teacherArr = res.data.list
      })
    }
  },
  mounted() {
    this.role = localStorage.getItem('roleCode')
    this.getStudentDetailDownFn()
    this.getTeacherPr()

  }
}
</script>
