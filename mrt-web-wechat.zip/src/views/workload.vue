<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.push('/home')">返回</span>
      </template>
      <template #right v-if="role !== 'StudentType_jxs' && role !== 'JXS_manager'">
        <span v-if="!isMine" style="color: #17d4b5" @click="goMyApprove(true)">查询审核</span>
        <span v-else style="color: #17d4b5" @click="goMyApprove(false)">去审核</span>
      </template>
    </van-nav-bar>
    <div>
      <van-dropdown-menu active-color="#17d4b5">
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParam.sectionId" @change="dropdownChange('s')"
                           :options="option4"/>
        <van-dropdown-item v-if="role === 'JXS_manager'" title="专业" v-model="listParam.majorId" @change="dropdownChange" :options="option1"/>
        <van-dropdown-item v-if="isMine && (role !== 'sectionManager' || role !== 'teacher' || role !== 'headNurse')" title="状态" v-model="listParam.status" :options="option2" @change="dropdownChange"/>
        <year-month-drop v-model="listParam.enrollYear" @change="dropdownChange"></year-month-drop>
      </van-dropdown-menu>
    </div>
    <div style="display: flex;justify-content: space-between;align-items: center; padding: 0 12px;">
      <van-search v-model="listParam.remark" shape="round" style="flex: 1" placeholder="搜索"
                  @change="advancedWorkloadListFn"
      />
    </div>
    <div style="background: #f6f6f6; padding: 12px;margin-bottom: 60px">
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.title">
            <div style="font-size: 16px;font-weight: bold; display: flex;justify-content: space-between;">
              {{ data.userName }}
              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">已通过</van-tag>
              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">不通过</van-tag>
              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">未提交</van-tag>
              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===11" size="medium">审核中</van-tag>
            </div>
            <van-divider/>
            <div style="display: flex;flex-wrap: wrap;">
              <div style="margin-bottom: 10px;width: 50%;">
                <div style="color: #cccccc;margin-bottom: 4px;">年月:</div>
                <div>{{ data.period }}</div>
              </div>
              <div style="margin-bottom: 10px;width: 50%;">
                <div style="color: #cccccc;margin-bottom: 4px;">带教老师:</div>
                <div>{{ data.teacherName }}</div>
              </div>
<!--              <div style="margin-bottom: 10px;width: 50%;">-->
<!--                <div style="color: #cccccc;margin-bottom: 4px;">操作时间:</div>-->
<!--                <div>{{ data.created }}</div>-->
<!--              </div>-->
              <div style="margin-bottom: 10px;width: 50%;">
                <div style="color: #cccccc;margin-bottom: 4px;">学生姓名:</div>
                <div>{{ data.userName }}</div>
              </div>
<!--              <div style="margin-bottom: 10px;width: 50%;">-->
<!--                <div style="color: #cccccc;margin-bottom: 4px;">人员类型:</div>-->
<!--                <div>{{ data.workloadStaffTypeName || '无'}}</div>-->
<!--              </div>-->
<!--              <div style="margin-bottom: 10px;width: 50%;">-->
<!--                <div style="color: #cccccc;margin-bottom: 4px;">备注:</div>-->
<!--                <div>{{ data.remark || '无' }}</div>-->
<!--              </div>-->
              <div style="margin-bottom: 10px;width: 50%;" v-if="data.startDate && data.endDate">
                <div style="color: #cccccc;margin-bottom: 4px;">时间:</div>
                <div>{{ data.startDate.substring(0, 10) }}至{{ data.endDate.substring(0, 10) }}</div>
              </div>
              <div style="margin-bottom: 10px;width: 50%;" v-if="data['basicWorkNum']">
                <div style="color: #cccccc;margin-bottom: 4px;">基础工作量例数:</div>
                <div>{{ data['basicWorkNum'] }}例</div>
              </div>
              <div style="margin-bottom: 10px;width: 50%;" v-if="data.completeNum">
                <div style="color: #cccccc;margin-bottom: 4px;">实际完成例数:</div>
                <div>{{ data.completeNum }}例</div>
              </div>
            </div>

            <div style="text-align: right;" v-if="data.status !== 0">

              <router-link :to="{path:'/approval-detail',query:data}">
                <van-button type="default" size="mini">查看审批进度</van-button>
              </router-link>
              <van-button style="margin-left: 12px;width: 4em;"
                          v-if="!isMine && (role === 'sectionManager' || role === 'teacher' || role === 'headNurse')" type="primary" size="mini"
                          @click="goDetail(data)">审批
              </van-button>
              <van-button style="margin-left: 12px;width: 4em;" type="primary" size="mini"
                          @click="goDetail(data)">查看
              </van-button>
              <van-button v-if="data.status === 1 && role === 'StudentType_jxs'" style="margin-left: 12px;width: 6em;" type="primary" size="mini"
                          @click="goDetail(data)">修改
              </van-button>
              <van-button v-if="(data.status === 11 && role === 'StudentType_jxs')||role === 'JXS_manager'" style="margin-left: 12px;width: 4em;" type="primary" size="mini"
                          @click="revoke(data)">撤销
              </van-button>
              <van-button v-if="data.status === 1 && role === 'StudentType_jxs'" style="margin-left: 12px;width: 6em;" type="warning" size="mini"
                          @click="onDelete(data)">删除
              </van-button>
            </div>
            <div style="text-align: right;" v-if="role === 'StudentType_jxs'">
              <van-button v-if="data.status === 0" style="margin-left: 12px;width: 6em;" type="primary" size="mini"
                          @click="goDetail(data)">修改
              </van-button>
              <van-button v-if="data.status === 0" style="margin-left: 12px;width: 6em;" type="warning" size="mini"
                          @click="onDelete(data)">删除
              </van-button>
              <van-button v-if="data.status === 0" style="margin-left: 12px;width: 6em;" type="primary" size="mini"
                          @click="onSubmit(data)">提交
              </van-button>
            </div>
          </div>
        </van-list>
      </van-pull-refresh>

      <div v-if="role === 'StudentType_jxs'" style="position: fixed;right: 26px;bottom: 70px" @click="workloadAddGo">
        <van-icon color="#ff0000" name="add" size="40"/>
      </div>
    </div>
  </div>
</template>
<script>
import {
  advancedWorkloadList,
  advancedworkloadListProcess,
  advancedworkloadApprovalProcess,
  startMobileProcess,
  advancedWorkloadRemove,
  getTransferSchedule,
  listMajor
} from '../http/apiMap'
import {Dialog} from "vant";
import YearMonthDrop from '../components/year-month-drop'
const {urlForPost} = require("../http/apiMap");

export default {

  name: 'test',
  components: {
    // Pager
    YearMonthDrop
  },
  data() {
    return {
      value: '',
      isEdit: false,
      role: '',
      isMine: false,
      listParam: {
        teacherId: '',
        created: '',
        sectionId: '',
        status: null,
        pageSize: 10,
        pageNum: 1,
        remark: ''
      },
      option1: [],
      option4: [],
      option2: [
        {text: '未提交', value: 0},
        {text: '不同意', value: 1},
        {text: '同意', value: 2},
        {text: '审核中', value: 11},
      ],
      testData: [],
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    // this.advancedWorkloadListFn()
    this.transferGet()
  },
  methods: {
    goDetail(data) {
      data.outpatientFlag = data.outpatientFlag ? 1 : 0
      localStorage.setItem('currentWorkloadData', JSON.stringify(data))
      localStorage.setItem('formAction', '')
      this.$router.push({
        path: '/workload-add',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;


      this.state.loading = true;
      this.listParam.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParam.pageNum++
      this.advancedWorkloadListFn(flag)
    },
    // 获取列表
    advancedWorkloadListFn(f) {
      if (this.role === 'JXS_manager' || this.role === 'StudentType_jxs' || this.isMine) {
        advancedWorkloadList(this.listParam).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if (res.data.list.length === 0 || res.data.list.length<this.listParam.pageSize) {
              this.state.finished = true
            }
            if(res.data.total === 0){
              this.testData = []
            }else{
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      } else {
        advancedworkloadListProcess(this.listParam).then(res => {
          if (f === 'onLoad') {
            this.state.loading = false;
            if (res.data.list.length === 0 || res.data.list.length<this.listParam.pageSize) {
              this.state.finished = true
            }
            if(res.data.total === 0){
              this.testData = []
            }else{
              this.testData = [...this.testData, ...res.data.list];
            }
          } else {
            this.testData = [...res.data.list];
          }
        })
      }

    },
    dropdownChange(s){
      this.listParam.pageNum = 1
      if(s){
        this.getListMajor()
      }
      this.advancedWorkloadListFn()
    },
    // 审批
    throughFn(num) {
      let target = {}
      let flag = false
      this.testData.forEach(item => {
        if (item.checked === true) {
          target = item
          flag = true
        }
      })
      if (!flag) {
        this.$toast.fail('请先勾选请假信息!')
      } else {
        Dialog.confirm({
          title: '温馨提示:',
          message: '是否确定提交!',
          confirmButtonColor: '#17d4b5'
        }).then(() => {

          let param = {
            "opinion": num === 1 ? "同意" : "不同意",
            "processInstanceId": target.processInstanceId,
            "projectId": target.id,
            "retryStatus": 0,
            "status": num,
            "taskId": target.taskId,
          }
          advancedworkloadApprovalProcess(param).then(res => {
            this.$toast.success(res.data.msg)
            this.advancedWorkloadListFn();
          })
        }).catch(() => {
          this.$toast.success('请联系管理员')
        })
      }
    },
    // 提交
    onSubmit(data) {
      Dialog.confirm({
        title: '温馨提示:',
        message: '提交后不能修改,确认提交么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        let param = {
          'id': data.id
        }
        startMobileProcess(param).then(() => {
          this.$toast.success('提交成功!')
          this.listParam.pageNum = 1
          this.advancedWorkloadListFn()
        })
      })
    },
    onDelete(data) {
      Dialog.confirm({
        title: '温馨提示:',
        message: '确认删除么?',
        confirmButtonColor: '#17d4b5'
      }).then(() => {
        let param = {
          'id': data.id
        }
        advancedWorkloadRemove(param).then(() => {
          this.$toast.success('删除成功!')
          this.advancedWorkloadListFn()
        })
      })
    },
    // 获取当前月'yy-mm'
    getLocalDate() {
      let date = new Date()
      let year = date.getFullYear()
      let month = date.getMonth()
      if (month === 0) {
        return `${year - 1}-${12}`
      } else {
        return `${year}-${month}`
      }
    },
    // 跳转添加页面
    workloadAddGo() {

      localStorage.setItem('currentWorkloadData', '')
      localStorage.setItem('formAction', '')
      this.$router.push({
        path: '/workload-add'
      })
    },
    // 时间格式
    formatDate(date) {
      return `${date.getMonth() + 1}/${date.getDate()}`;
    },
    // 筛选条件
    dateConfirm(date) {
      this.listParam.created = this.formatDate(date);
      this.advancedWorkloadListFn();
    },
    // 分页选择
    checkFn(data) {
      this.listParam.teacherId = data.value
      this.advancedWorkloadListFn();
    },
    // 跳转到我的列表
    goMyApprove(bol) {
      this.isMine = bol;
      sessionStorage.setItem('isMine', this.isMine?'isMine':'')
      this.advancedWorkloadListFn()
    },
    // 获取科室信息
    transferGet(){
      getTransferSchedule(this.transferParams).then(res => {
        let optionArr = [
          { text: '全部', value: '' }
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          optionArr.push(obj)
        })
        this.option4 = [...optionArr]
      })
    },
    // 获取专业
    getListMajor(){
      listMajor({
        pageSize: 999,
        pageNum: 1,
        sectionId: this.listParam.sectionId
      }).then(res => {
        let optionArr = [
          { text: '全部', value: '' }
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          optionArr.push(obj)
        })
        this.option1 = [...optionArr]
      })
    },
    // 撤销
    revoke(data){
      Dialog.confirm({
        message: '确认撤销么?'
      }).then(()=>{
        urlForPost('/advancedworkload/saveOrUpdate',{
          id: data.id,
          status: 0
        }).then(() =>{
          this.$toast.success('撤销成功!')
          this.advancedWorkloadListFn()
        })
      }).catch(()=>{})
    }
  }

}
</script>
