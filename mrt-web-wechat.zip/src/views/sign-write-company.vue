<template>
  <div class="about">
    <van-nav-bar title="选送单位信息" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        选送单位信息填写
      </div>
    </div>
    <div>
      <van-form ref="companyForm">
        <div style="text-align: center; color: orangered">温馨提示：填选时若无选送单位信息请联系临床教学部，电话：0851-86817477</div>
        <van-field readonly clickable required name="typeId" label="选送单位" :value="formData['unitName']"
                   placeholder="选择选送单位" @click="showUnitPicker = true"
                   :rules="[{ required: true, message: '请选择选送单位' }]"/>
        <van-popup v-model="showUnitPicker" round position="bottom">
          <Pager :list-prop="['unitName','unitId']" url="/advancedsignup/listAdvancedUnitByPage
" :params="{status: 1}" @check="checkFn($event,formData,'unitName','unitId','showUnitPicker')"></Pager>
        </van-popup>
        <van-field name="address" clickable required label="单位地址" v-model="formData.address" placeholder="请输入单位地址"
                   :rules="[{ required: true, message: '请输入单位地址' }]"
        />
        <van-field name="postcode" clickable required label="邮编" v-model="formData.postcode" placeholder="请输入邮编"
                   :rules="[{ required: true, message: '请输入邮编' }]"
        />

        <van-field readonly clickable required name="levelId" label="单位等级" :value="formData['levelName']"
                   placeholder="选择单位等级" @click="showUnitLevelPicker = true"
                   :rules="[{ required: true, message: '请选择单位等级' }]"/>
        <van-popup v-model="showUnitLevelPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams" code="UnitLevel" @cancel="showUnitLevelPicker = false"
                    @confirm="onConfirm($event,formData,'levelName','levelId','showUnitLevelPicker')"></m-picker>
        </van-popup>
        <van-field readonly clickable name="gradeId" label=" " :value="formData['gradeName']" placeholder="选择医院等级"
                   @click="showHospitalLevelPicker = true"
                   :rules="[{ required: true, message: '请医院等级' }]"/>
        <van-popup v-model="showHospitalLevelPicker" round position="bottom">
          <m-picker url="/dictionary/getByTypeCodeParams" code="hospitalLevel" @cancel="showHospitalLevelPicker = false"
                    @confirm="onConfirm($event,formData,'gradeName','gradeId','showHospitalLevelPicker')"></m-picker>
        </van-popup>

        <van-field readonly clickable required name="provinceId" label="所在省" :value="formData.provinceName"
                   placeholder="选择所在省" @click="showCityPicker = true"
                   :rules="[{ required: true, message: '请选择所在省' }]"/>
        <van-popup v-model="showCityPicker" round position="bottom">
          <van-picker :columns="cityColumns" :show-toolbar="true" @cancel="showCityPicker = false"
                      @confirm="onConfirm($event,formData,'provinceName','provinceId','showCityPicker',getCityFn)"
          />
        </van-popup>

        <van-field readonly clickable required name="typeId" label="所在市/州" :value="formData.cityName"
                   placeholder="选择所在市/州" @click="showMarketPicker = true"
                   :rules="[{ required: true, message: '请选择所在市/州' }]"/>
        <van-popup v-model="showMarketPicker" round position="bottom">
          <van-picker :columns="marketColumns" :show-toolbar="true" @cancel="showMarketPicker = false"
                      @confirm="onConfirm($event,formData,'cityName','cityId','showMarketPicker')"
          />
        </van-popup>

        <van-field name="deptName" clickable label="管理部门" v-model="formData.deptName" placeholder="请输入管理部门"
        />

        <van-field v-model="formData['deptPhone']" type="number" required label="管理部门电话"
                   :rules="[{ required: true, message: '请输入管理部门电话' }]"/>

        <van-field name="billingUnit" clickable required label="开票单位名称" v-model="formData.billingUnit"
                   placeholder="请输入开票单位名称" :rules="[{ required: true, message: '请输入开票单位名称' }]"
        />

        <van-field name="taxNo" clickable required label="开票单位统一信用代码" v-model="formData.taxNo"
                   placeholder="请输入开票单位统一信用代码" :rules="[{ required: true, message: '请输入开票单位统一信用代码' }]"
        />

      </van-form>
      <div style="margin: 16px;display: flex;">
        <van-button style="margin-bottom: 12px;" round block @click="goPre">
          上一步
        </van-button>
        <van-button round block color="#17d4b5" @click="attendAdd">
          下一步
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>

import {urlForPost} from "../http/apiMap";

import mPicker from '../components/m-picker'
import Pager from '../components/searchPager'

export default {
  name: 'company',
  components: {
    mPicker,
    Pager
  },
  data() {
    return {
      url: {
        city: '/area/listByPage',
        advancedSignup: '/advancedsignup/saveOrUpdateAdvancedSignup',
        updateUnit: '/advancedsignup/updateUnit'
      },
      params: {
        province: {
          pageSize: 999,
          pageNum: 1,
          province: 1
        },
        city: {
          pageSize: 999,
          pageNum: 1,
          city: ''
        },
      },
      formData: {},
      showUnitPicker: false,
      showUnitLevelPicker: false,
      showHospitalLevelPicker: false,
      showCityPicker: false,
      showMarketPicker: false,
      cityColumns: [],
      marketColumns: [],
      company: {}
    }
  },
  computed: {},
  methods: {

    onConfirm(value, target, name, id, show, cb) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (cb) {
        cb()
      }
    },
    goPre() {
      this.$router.push({
        path: '/sign-write-work'
      })
    },
    attendAdd() {
      this.$refs.companyForm.validate().then(() => {
        sessionStorage.setItem('companyData', JSON.stringify(this.formData))
        delete this.formData.majorId
        delete this.formData.sectionId
        delete this.formData.typeId
        delete this.formData.status
        urlForPost(this.url.updateUnit, this.formData).then(() => {
          this.formData.fromUnitId = this.formData.id
          this.formData.id = sessionStorage.getItem('signupId')
          this.formData.staffId = sessionStorage.getItem('staffId')
          // if (this.formData.hospitalId && this.formData.fromUnitId) {
            urlForPost(this.url.advancedSignup, this.formData).then(() => {
              this.$router.push({
                path: '/sign-write-application'
              })
            })
          // } else {
          //   this.$toast.fail('您的选送单位信息有缺失!请联系管理员后重试!')
          // }
        })
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },
    onDateConfirm(value, target, prop, show) {
      target[prop] = this.getNowFormatDate(value) + ' 00:00:00'
      this[show] = false;
    },
    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }

      return year + seperator1 + month + seperator1 + strDate;
    },
    // 获取picker数据格式
    getData(url, params, target, prop = 'name', propId = 'id') {
      urlForPost(url, params).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item[prop],
            value: item[propId]
          }
          optionArr.push(obj)
        })
        this[target] = optionArr
      })
    },
    getCityFn() {
      this.params.city.city = this.formData.provinceId
      this.getData(this.url.city, this.params.city, 'marketColumns')
    },
    checkFn(data, target, name, id, show) {
      target[id] = data.value
      target[name] = data.text
      target['id'] = data.id
      this[show] = false
      Object.assign(this.formData, data.row)
      let obj = {...this.formData}
      obj.billingUnit = obj.unitName || null
      obj.taxNo = obj.creditCode || null
      this.formData = {...obj}
    },
    getCompany(){
      let data = JSON.parse(sessionStorage.getItem('staffBatchInfo') || '{}')
      if(data.fromUnitId){
        urlForPost('/advancedsignup/getAdvancedSignupUnitById', {
          id: data.fromUnitId
        }).then(res => {
          let unit = res.data.data.list[0] || {}
          if(unit.id){
            unit.billingUnit = data.billingUnit
            unit.taxNo = data.taxNo
            unit.id = unit['unitId']
            this.$set(this,'formData',unit)
          }
        })
      }
    }
  },
  mounted() {
    let info = sessionStorage.getItem('companyData')
    if (info) {
      this.formData = {...JSON.parse(info)}
    } else {
      this.getCompany()
      let identifyNoInfo = JSON.parse(sessionStorage.getItem('identifyNoInfo') || '{}')
      let staffBatchInfo = {};
      let cardInfo = {};
      if (sessionStorage.getItem('staffBatchInfo') !== 'undefined') {
        staffBatchInfo = JSON.parse(sessionStorage.getItem('staffBatchInfo') || '{}')
      }
      if (sessionStorage.getItem('cardInfo') !== 'undefined') {
        cardInfo = JSON.parse(sessionStorage.getItem('cardInfo') || '{}')
      }
      let obj = {}
      if (identifyNoInfo.id || staffBatchInfo.id || cardInfo.id) {
        Object.assign(obj, staffBatchInfo)
        Object.assign(obj, identifyNoInfo)
        Object.assign(obj, cardInfo)
        obj = {...obj}
        this.formData.billingUnit = obj.billingUnit
        this.formData.taxNo = obj.taxNo
      } else {
        this.formData = {}
      }
    }
    this.getData(this.url.city, this.params.province, 'cityColumns')
  }
}
</script>
