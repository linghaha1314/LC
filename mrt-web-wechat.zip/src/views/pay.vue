<template>
  <div style="text-align: center">
    <van-popup :closeOnClickOverlay="false" v-model="show" style="width: 100vw;height: 50vh; padding: 30px 0;">
      <div>
        <div style="font-size: 20px; font-weight: bold; color: #333333; margin-bottom: 24px;">在线支付</div>
        <van-field
            v-model="idCard"
            name="username"
            label="身份证"
            placeholder="请输入身份证"
            required
            :rules="[{ pattern:pattern, message: '必须填写身份证' }]"
        />
        <div style="margin: 16px;">
          <van-button round block type="primary" @click="query">去支付</van-button>
        </div>
      </div>
    </van-popup>
    <div style="margin-top: -46px;margin-bottom: 60px;">
      <h3 style="font-size: 30px">报名信息</h3>
      <br>
      <van-cell :center="false" title="学生姓名:" :value="info.staffName||'无'"/>

      <van-cell :center="false" title="身份证:" :value="info['identifyNo']||'无'"/>
      <van-cell :center="false" title="进修批次:" :value="info['batchName']||'无'"/>
      <van-cell :center="false" title="选送单位:" :value="info['fromUnitName']||'无'"/>
      <van-cell :center="false" title="开票单位:" :value="info['billingUnit']||'无'"/>
      <van-cell :center="false" title="单位社会统一码:" :value="info['taxNo']||'无'"/>
      <van-cell :center="false" title="进修科室:" :value="info['sectionName']||'无'"/>
      <van-cell :center="false" title="进修专业:" :value="info['majorName']||'无'"/>
      <van-cell :center="false" title="进修期限:" :value="info['periodName']||'无'"/>
      <van-cell :center="false" title="进修类型:" :value="info['advancedType']||'无'"/>
      <van-cell :center="false" title="进修费用:" :value="(info['advancedFee']||0) + '元'"/>
      <van-cell :center="false" title="住宿费用:" :value="(info.lodgmentFee==='自行安排'? 0:info['lodgmentFee']) + '元'"/>
      <van-cell :center="false" title="工服费用:" :value="(info.clothingFee===null?0:info['clothingFee']) + '元'"/>
      <!--                <van-cell :center=false :title="`进修费用: ${info['advancedFee']||0}元`">-->
      <!--                  <template #right-icon>-->
      <!--                    <van-checkbox-->
      <!--                        :name="item"-->
      <!--                        v-model="info['advancedCheck']"-->
      <!--                    />-->
      <!--                  </template>-->
      <!--                </van-cell>-->
      <!--                <van-cell :center=false :title="`住宿费用: ${info.lodgmentFlag===false? info['lodgmentFee']:0}元`">-->
      <!--                  <template #right-icon>-->
      <!--                    <van-checkbox-->
      <!--                        :name="item"-->
      <!--                        v-model="info['lodgmentCheck']"-->
      <!--                    />-->
      <!--                  </template>-->
      <!--                </van-cell>-->
<!--      <van-cell :center="false" :title="'工装费:'">-->
<!--        <template #right-icon>-->
<!--          <van-radio-group v-model="info['clothingFee']" direction="horizontal"-->
<!--                           :disabled="!(!orderData.status || orderData.status===1 || orderData.status===3)">-->
<!--            <van-radio :name="0">自备</van-radio>-->
<!--            <van-radio :name="clothingFee">统一提供-->
<!--              <br/>-->
<!--              ({{ clothingFee }}元)-->
<!--            </van-radio>-->
<!--          </van-radio-group>-->
<!--          &lt;!&ndash;            <van-checkbox&ndash;&gt;-->
<!--          &lt;!&ndash;                :name="'clothingFee'"&ndash;&gt;-->
<!--          &lt;!&ndash;                v-model="info['clothingCheck']"&ndash;&gt;-->
<!--          &lt;!&ndash;                :disabled="!(!orderData.status || orderData.status === 1 || orderData.status === 3)"&ndash;&gt;-->
<!--          &lt;!&ndash;                @change="changeFee"&ndash;&gt;-->
<!--          &lt;!&ndash;            />&ndash;&gt;-->
<!--          &lt;!&ndash;            <van-checkbox&ndash;&gt;-->
<!--          &lt;!&ndash;                :name="'clothingFee'"&ndash;&gt;-->
<!--          &lt;!&ndash;                v-model="info['clothingCheck']"&ndash;&gt;-->
<!--          &lt;!&ndash;                :disabled="!(!orderData.status || orderData.status === 1 || orderData.status === 3)"&ndash;&gt;-->
<!--          &lt;!&ndash;                @change="changeFee"&ndash;&gt;-->
<!--          &lt;!&ndash;            />&ndash;&gt;-->
<!--        </template>-->
<!--      </van-cell>-->
      <van-cell :center="false" title="总计:"
                :value="parseFloat(info['advancedFee'])+parseFloat(info.lodgmentFlag===true? info['lodgmentFee']:'0')+parseFloat(info['clothingFee']) +'元'"/>
      <div v-if="info.status>6">
        <div v-if="orderData && orderData.orderNo" style="margin-top: 12px;">
          <h3 style="font-size: 30px">订单信息</h3>
          <van-cell v-if="orderData.status" title="支付状态">
            <template #default>
              <div v-if="orderData.status===2" style="color: #17D4B5">
                支付成功
              </div>
              <div v-else-if="orderData.status===1" style="color: #1a1aff">
                未支付
              </div>
              <div v-else-if="orderData.status===3" style="color: #ff3333">
                支付失败
              </div>
              <div v-else-if="orderData.status===4" style="color: #1a1aff">
                退款申请中
              </div>
              <div v-else-if="orderData.status===5" style="color: #17D4B5">
                退款成功
              </div>
              <div v-else-if="orderData.status===6" style="color: #ff3333">
                退款失败
              </div>
              <div v-else-if="orderData.status===7" style="color: #ff3333">
                等待临床教学部进行退款审核
              </div>
            </template>
          </van-cell>
          <van-cell title="订单号:" :value="orderData['orderNo']||'无'"/>
          <van-cell title="创建时间:" :value="orderData['created']||'无'"/>
        </div>
        <div v-if="orderData.status === 1" style="text-align: center; font-size: 16px; color: orangered;padding: 12px">
          你的缴费时间为{{ info['payStartDate'] }}——{{ info['payEndDate'] }}
        </div>
        <div v-if="orderData.status === 2" style="text-align: center; font-size: 16px; color: orangered;padding: 12px">
          (若已开票,则无法退款)如需退款,请在{{ backMoney(orderData['payDate']) }}之前!
        </div>
        <van-button v-if="!orderData.status || orderData.status === 1 || orderData.status === 3"
                    style="width: 30vw;height: 48px;font-size: 20px; margin: 12px" size="mini" round color="#3399ff"
                    :disabled="disabledSure"
                    @click="nextDone(info)">
          {{ doneTime }}
        </van-button>
        <van-button v-if="showPay" style="width: 30vw;height: 48px;font-size: 20px; margin: 12px" size="mini" round color="#17d4b5"
                    :disabled="disabledPay"
                    @click="payFn(orderData)">
          支付
        </van-button>
        <van-button v-if="orderData.status===2" style="width: 30vw;height: 48px;font-size: 20px; margin: 12px" size="mini" round color="#ff3333" :disabled="backFlag"
                    @click="invoicing(orderData, info, 'refund')">
          退款
        </van-button>
        <!--              <van-button v-if="orderData.status===4" style="width: 30vw; margin: 12px" size="mini" round color="#3399ff"-->
        <!--                          @click="queryOrder(orderData)">-->
        <!--                查询退款结果-->
        <!--              </van-button>-->
        <van-button v-if="orderData.status===2" style="width: 30vw;height: 48px;font-size: 20px; margin: 12px" size="mini" round color="#3399ff"
                    :disabled="invoicingFlag"
                    @click="invoicing(orderData, info)">
          {{ invoicingStr }}
        </van-button>
        <a :href="pdfUrl" v-if="pdfUrl!==''">
          <van-button style="width: 30vw;height: 48px;font-size: 20px; margin: 12px" size="mini" round color="#3399ff">
            查看发票
          </van-button>
        </a>
      </div>
      <div v-else style="text-align: center; font-size: 16px; color: orangered;padding: 12px">
        还未到支付阶段, 请在 在线报名 进度查询 菜单里面查询报名进度
      </div>
    </div>
  </div>
</template>
<script>
import {urlForPost} from '../http/apiMap.js'
import { Dialog } from 'vant';
export default {
  data() {
    return {
      pattern: /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/,
      idCard: '',
      orderData: {
        status: 0
      },
      invoicingStr: '申请开票',
      invoicingFlag: false,
      doneTime: '不在操作时间',
      disabled: false,
      disabledSure: true,
      info: {},
      disabledPay: false,
      show: true,
      showFour: false,
      showPay: false,
      queryData: {},
      clothingFee: 0,
      backFlag: false,
      pdfUrl: ''
    };
  },
  methods: {

    query() {
      if (this.idCard) {
        this.show = false
        urlForPost('/advancedsignup/queryProgressInfo', {
          identifyNo: this.idCard
        }).then(res => {
          if (res.data && res.data.data) {
            const data = res.data.data
            this.queryData = res.data.data
            urlForPost('/advancedsignup/getByBatchAndStaff', {
              identifyNo: data.identifyNo,
              batchId: data.batchId
            }).then(re => {
              this.info = re.data.data

              this.clothingFee = this.info.clothingFee
              this.isSurePay(this.info)

              // this.getSignupTimeFn()
              urlForPost('/advancedpayonline/mySignupOrderNo', {
                staffId: data.staffId,
                signupId: data.id
              }).then(d => {
                this.orderData = d.data.data || {}
                // if (this.orderData.clothingFee || this.orderData.clothingFee === 0) {
                //   this.info.clothingFee = this.orderData.clothingFee
                // }
                this.disabledPay = this.orderData.status === 2
                this.showPay = this.orderData.status === 2
                if (d.data.data.status === 2) {
                  this.info['clothingCheck'] = d.data.data['clothingFlag']
                  urlForPost('/advancedpayonline/toInvoiceDetails', {
                    orderNo: this.orderData.orderNo,
                    signupId: this.orderData.signupId,
                    staffId: this.orderData.staffId
                  }).then(data => {
                    if (data.data.data && data.data.data.status === 1) {
                      this.invoicingStr = '已开票至邮箱'
                      this.invoicingFlag = true
                      this.backFlag = true
                      this.pdfUrl = data.data.data['pdfurl']
                    }
                  })
                }
                if (this.orderData.status !== 1) {
                  urlForPost('/advancedpayonline/toPayBillDetails', {
                    orderNo: this.orderData.orderNo
                  }).then(res => {
                    this.orderData.bnkPyOrdrNo = res.data.data && res.data.data.bnkPyOrdrNo || null
                    if (this.orderData.status === 4 && this.orderData.bnkPyOrdrNo) {
                      urlForPost('/advancedpayonline/toPayReturnDetails', {
                        bnkPyOrdrNo: this.orderData.bnkPyOrdrNo,
                        orderNo: this.orderData.orderNo
                      }).then(re => {
                        urlForPost('/advancedpayonline/getReturnPayStatus', {
                          bnkPyOrdrNo: re.data.data.bnkPyOrdrNo,
                          rfndTrcNo: re.data.data.rfndTrcNo,
                          ittPartyJrnlNo: re.data.data.ittPartyJrnlNo,
                          orderNo: this.orderData.orderNo
                        }).then((r) => {
                          this.orderData.status = r.data.data.message === '退款成功' ? 5 : 6
                        })
                      })
                    }
                  })
                }

              })

              // if (this.info.status === 7) {
              //   this.getSignupTimeFn()
              //   urlForPost('/advancedpayonline/mySignupOrderNo', {
              //     staffId: data.staffId,
              //     signupId: data.id
              //   }).then(d => {
              //     this.orderData = d.data.data || {}
              //     this.disabledPay = this.orderData.status === 2
              //     this.showPay = this.orderData.status === 2
              //     if(d.data.data.status === 2){
              //       this.info['clothingCheck'] = d.data.data['clothingFlag']
              //       urlForPost('/advancedpayonline/toInvoiceDetails',{
              //         orderNo: this.orderData.orderNo,
              //         signupId: this.orderData.signupId,
              //         staffId: this.orderData.staffId
              //       }).then(data => {
              //         if(data.data.data && data.data.data.status === 1){
              //           this.invoicingStr = '已开票至邮箱'
              //           this.invoicingFlag = true
              //         }
              //       })
              //     }
              //     if(this.orderData.status!==1){
              //       urlForPost('/advancedpayonline/toPayBillDetails',{
              //         orderNo: this.orderData.orderNo
              //       }).then(res => {
              //         this.orderData.bnkPyOrdrNo = res.data.data && res.data.data.bnkPyOrdrNo || null
              //         if(this.orderData.status === 4 && this.orderData.bnkPyOrdrNo){
              //           urlForPost('/advancedpayonline/toPayReturnDetails',{
              //             bnkPyOrdrNo: this.orderData.bnkPyOrdrNo,
              //             orderNo: this.orderData.orderNo
              //           }).then(re => {
              //             urlForPost('/advancedpayonline/getReturnPayStatus', {
              //               bnkPyOrdrNo: re.data.data.bnkPyOrdrNo,
              //               rfndTrcNo: re.data.data.rfndTrcNo,
              //               ittPartyJrnlNo: re.data.data.ittPartyJrnlNo,
              //               orderNo: this.orderData.orderNo
              //             }).then((r)=>{
              //               this.orderData.status = r.data.data.message==='退款成功' ? 5 : 6
              //             })
              //           })
              //         }
              //       })
              //     }
              //
              //   })
              // }
            })
          } else {
            this.$toast.fail('无用身份证号! 请确认后重试')
            this.show = true
          }
        })
      } else {
        this.$toast.fail('请输入正确的身份证号')
      }

    },

    nextDone() {
      this.isSurePay(this.info, () => {
        if (this.disabledSure === false) {
          const staffId = this.queryData.staffId
          const signupId = this.queryData.id
          const advancedFee = parseFloat(this.info.advancedFee)
          const clothingFee = parseFloat(this.info.clothingFee)
          const lodgmentFee = parseFloat(this.info.lodgmentFlag ? this.info.lodgmentFee : 0.00)
          const param = {
            staffId,
            signupId,
            advancedFee: advancedFee,
            lodgmentFee: lodgmentFee,
            clothingFee: clothingFee,
            payFee: advancedFee + lodgmentFee + clothingFee,
            clothingFlag: clothingFee !== 0
          }
          if (this.orderData && this.orderData.id) {
            param.id = this.orderData.id
            param.orderNo = this.orderData.orderNo
          }
          urlForPost('/advancedpayonline/savePayOrderNo', {
            ...param
          }).then((re) => {
            if(re.data.success){
              this.orderData = re.data['reasons'].data
              // this.disabledPay = this.orderData.status === 2
              // this.showFour = true
              this.disabledSure = true
              this.disabledPay = false
              this.showPay = true
              // urlForPost('/advancedpayonline/mySignupOrderNo',{
              //   staffId, signupId
              // }).then(re => {
              //   this.currentData = re.data.data
              //   this.disabledPay = this.currentData === 1
              //   this.showFour = true
              // })
            }else {
              this.$toast.fail(re.data.message || '未知错误')
            }

          })
        } else {
          this.disabledSure = true
          this.doneTime = '不在操作时间'
        }
      })
    },

    payFn({orderNo, advancedFee, lodgmentFee, clothingFee}) {
      urlForPost('/advancedpayonline/toPayOnline', {
        orderNo,
        payFee: advancedFee + lodgmentFee + clothingFee
      }).then(res => {
        if (res.data.success) {
          this.disabledPay = true
          window.location.href = res.data.data['Py_URL']
        }else {
          this.$toast.fail(res.data.message || '未知错误')
        }
      })
    },

    invoicing(data, info, refund) {
      if(!refund){
        Dialog.confirm({
          title: '温馨提示:',
          message: '开票后将无法退款, 确认开票么!',
          confirmButtonColor: '#17d4b5'
        }).then(() => {
          this.$router.push({
            path: '/sign-progress-Invoicing',
            query: {
              ...info,
              ...data
            }
          })
        })
      } else {
        this.$router.push({
          path: '/sign-progress-refund',
          query: {
            ...info,
            ...data
          }
        })
      }
    },

    changeFee() {
      // if(!this.showPay){
      //   this.disabledPay = false
      // }
      if (this.doneTime === '确认信息') {
        this.disabledPay = true
        this.disabledSure = false
      }
    },

    isSurePay(data, cb) {
      const now = new Date().getTime()
      const q = new Date(data['payStartDate'].replace(/-/g, '/')).getTime()
      const o = new Date(data['payEndDate'].replace(/-/g, '/')).getTime()
      if (q < now && o > now) {
        this.disabledSure = false
        this.doneTime = '确认信息'
      }
      const lodgmentFee = parseFloat(this.info.lodgmentFlag ? this.info.lodgmentFee : 0.00)
      if(parseFloat(this.info.clothingFee) === 0 && parseFloat(this.info.advancedFee) === 0 && lodgmentFee === 0){
        Dialog.alert({
          title: '温馨提示:',
          message: '您无需缴费!',
        }).then(()=>{
          this.doneTime = '无需缴费'
          this.disabledSure = true
        });
      }
      if (cb) {
        cb()
      }
    },

    backMoney(date) {
      if (date) {
        const now = new Date().getTime()
        let s = new Date(date.replace(/-/g, '/')).getTime()
        s = s + 1000 * 60 * 60 * 24 * 3
        if(now>s){
          this.backFlag = true
        }
        return this.getDate(s)
      }else {
        return '无'
      }
    },

    getDate(str) {
      let now = new Date(str),
          y = now.getFullYear(),
          m = now.getMonth() + 1,
          d = now.getDate();
      return y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d) + " " + now.toTimeString().substr(0, 8);
    }
  },
  mounted() {

  }
};
</script>
<style lang="less">
.title {
  font-size: 20px;
}

.sub-title {
  font-size: 16px;
  color: rgb(203, 203, 203)
}

.mb20 {
  margin-bottom: 20px;
}

.custom-title {
  margin-right: 4px;
  vertical-align: middle;
  text-align: left;
}
</style>
