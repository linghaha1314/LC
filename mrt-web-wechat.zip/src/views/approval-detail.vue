<template>
  <div class="about">
    <van-nav-bar title="审批" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="margin: 16px;">
      <div>
        审批进度
      </div>
      <van-steps direction="vertical" :active="processNum">
        <van-step v-for="process in processData" :key="process.title">
          <div v-if="process['stepName']!=='申请人'">
            <div style="display: flex; align-items: center">
              <van-image round width="40px" height="40px" src="https://img.yzcdn.cn/vant/cat.jpeg" />
              <span style="margin: 0 16px; color: #3E3E3E; font-size: 14px">
                {{process['stepName'] || '无'}}: {{process.name || ''}}
              </span>
              <div>
                <van-tag style="text-align: center" v-if="process['deleteReason']==='completed' && process.status === '1'" type="success">已通过</van-tag>
                <van-tag style="text-align: center" v-if="process['deleteReason'] !== 'completed'" type="warning">待审批</van-tag>
                <van-tag style="text-align: center" v-if="process['deleteReason']==='completed' && process.status !== '1'" type="danger">已拒绝</van-tag>
              </div>
            </div>
            <div>审核意见: {{process.opinion || ''}}</div>
          </div>
        </van-step>
      </van-steps>
      <!--        <van-button round block color="#17d4b5" native-type="submit">-->
      <!--          提交申请-->
      <!--        </van-button>-->
    </div>
    <div style="margin: 16px;">
      当前审批人: {{msg}}
    </div>
  </div>
</template>
<script>
  import {getFlowData} from '../http/apiMap';
    export default {
        name: 'approval-detail',
        data(){
            return{
              processNum: -1,
              processData:[],
              msg:'',
              currentData: this.$route.query
            }
        },
        computed:{

        },
        methods:{
          // 获取审批进程
          getFlowDataFn(){
            let param = {
              "processInstanceId": this.currentData.processInstanceId,
              "businessId":this.currentData.id
            }
            getFlowData(param).then(res => {
              this.msg = res.data.data;
              this.processData = res.data.list
              this.getActionNum();
            })
          },
          // 获取审批步骤
          getActionNum(){
            for (let i = 0; i<this.processData.length;i++){
              if(this.processData[i]["deleteReason"] === 'completed'){
                this.processNum = i
              }
            }
          },
        },
        mounted() {
          this.getFlowDataFn()
        }
    }
</script>