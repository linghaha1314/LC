<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="activitiesForm">


      <van-field
          readonly
          clickable
          name="startDate"
          required
          label="报到年月"
          :value="formData.month"
          placeholder="选择报到年月"
          @click="showMonthPicker = true"
          :rules="[{ required: true, message: '请选择报到年月' }]"
      />
      <van-popup v-model="showMonthPicker" round position="bottom">
        <van-datetime-picker
            v-model="formData.monthValue"
            type="year-month"
            title="选择年月"
            @cancel="showMonthPicker = false"
            @confirm="onMonthConfirm"
        />
      </van-popup>
      <van-field
          readonly
          clickable
          name="startDate"
          required
          label="开始日期"
          :value="formData.startDate?formData.startDate.substring(0,10):''"
          placeholder="选择开始日期"
          @click="showDatePicker = true"
          :rules="[{ required: true, message: '请选择开始日期' }]"
      />
      <van-popup v-model="showDatePicker" round position="bottom">
        <van-datetime-picker
            v-model="formData.dateValue"
            type="date"
            title="选择年月日"
            @cancel="showDatePicker = false"
            @confirm="onDateConfirm"
        />
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field
          name="startTime"
          readonly
          clickable
          required
          label="开始时间"
          :value="formData.startTime"
          placeholder="选择开始时间"
          @click="showStartTimePicker = true"
          :rules="[{ required: true, message: '请选择开始时间' }]"
      />
      <van-popup v-model="showStartTimePicker" round position="bottom">
        <van-datetime-picker
            v-model="formData.startTime"
            type="time"
            title="选择时间"
            @cancel="showStartTimePicker = false"
            @confirm="onStartDateConfirm"
        />
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field
          v-model="formData.address"
          name="address"
          label="活动地址"
          required
          placeholder="填写活动地址"
          :rules="[{ required: true, message: '请填写活动地址' }]"
      />
      <div style="margin: 16px;">
        <van-button style="margin-bottom: 12px;" round block color="#17d4b5" @click="onSubmit">
          提交
        </van-button>
      </div>

    </van-form>

  </div>
</template>
<script>
import {
  urlForPost
} from '../http/apiMap';

export default {
  name: 'test',
  components: {},
  data() {
    return {
      formData: {
        month: '',
        address: '',
        dateValue: null,
        monthValue: null,
        startTime: '',
        startDate: '',
      },
      attachPath: [],
      currentData: {},
      showMonthPicker: false,
      showImgPicker: false,
      showImgFilePicker: false,
      seeImgUrl: '',
      showTypePicker: false,
      showDatePicker: false,
      showStartTimePicker: false,
      showEndTimePicker: false,

      action: 2,
      currentDate: new Date(),
      currentTime: '12:00',
      currentEndDate: '12:00',
      option1: [],
      role: '',
      userId: '',
      studentList: [],
      name: '活动详情',
      typePage: this.$route.query.typePage,
      fileList: [],
      showUpload: false,
      saveFile: [],
      currentSectionId: localStorage.getItem('currentSectionId')
    }
  },
  computed: {

    typeColumns() {
      let arr = []
      this.option1.map(item => {
        arr.push(item.text)
      })
      return arr;
    },
    isEdit() {
      return this.action === 3 || (this.action === 0 && this.userId === this.formData.userId);
    }
  },
  methods: {
    onSubmit() {
      this.$refs.activitiesForm.validate().then(() => {

        urlForPost('/prejobtrainingrecord/setprejobtrain',this.formData).then((res) => {
          // if (this.formData.attachPath) {
          //   let param = {
          //     "activityId": res.data.data.id,
          //     "attachPath": this.formData.attachPath
          //   }
          //   addAttachFile(param).then()
          // }
          this.$toast.success('添加成功!')
          setTimeout(() => {
            this.$router.go(-1)
          }, 1000)
        })
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },

    onDateConfirm(value) {
      this.formData.startDate = this.getNowFormatDate(value) + ' 00:00:00'
      this.showDatePicker = false;
    },
    onMonthConfirm(value) {
      this.formData.month = this.getNowFormatDate(value).substring(0,7)
      this.showMonthPicker = false;
    },
    // 开始时间
    onStartDateConfirm(value) {
      this.formData.startTime = value
      this.showStartTimePicker = false;
    },
    // 结束时间
    onEndDateConfirm(value) {
      this.formData.endTime = value
      this.showEndTimePicker = false;
    },

    getNowFormatDate(date) {
      let seperator1 = "-";
      let year = date.getFullYear();
      let month = date.getMonth() + 1;
      let strDate = date.getDate();
      if (month >= 1 && month <= 9) {
        month = "0" + month;
      }
      if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
      }

      return year + seperator1 + month + seperator1 + strDate;
    },




  },
  mounted() {
  }
}
</script>
