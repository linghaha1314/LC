<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form style="margin-bottom: 100px;">
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-cell-group>
        <van-cell :title="typeName[currentData.type]" :value="currentData.name"/>
        <van-cell title="创建日期:" :value="currentData['created'] && currentData['created'].substring(0,10)"/>
        <van-cell title="科室:" :value="currentData.sectionName||'无'"/>
        <van-cell title="专业:" :value="currentData.majorName||'无'"/>
        <van-cell title="状态:" :value="statusFn"/>

        <!--        <van-cell title="个人鉴定:">-->
        <!--          <template #label>-->
        <!--            <div>{{currentData.summary||'无'}}</div>-->
        <!--          </template>-->
        <!--        </van-cell>-->
        <!--        <van-cell style="width:100vw;" title="老师评语:">-->
        <!--          <template #label>-->
        <!--            <div style="max-width:340px;overflow-wrap:break-word;box-sizing: border-box;">{{currentData.teachOpinion||'无'}}</div>-->
        <!--          </template>-->
        <!--        </van-cell>-->
        <!--        <van-cell title="科室考评:">-->
        <!--          <template #label>-->
        <!--            <div>{{currentData['sectionOpinion']||'无'}}</div>-->
        <!--          </template>-->
        <!--        </van-cell>-->
        <!--        <van-cell title="部门考评:" :label="currentData['deptOpinion']||'无'" />-->
      </van-cell-group>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
    </van-form>
  </div>
</template>
<script>
import {getStudentDetailById} from '../http/apiMap'
import {Dialog} from 'vant';

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      currentData: this.$route.query,
      name: this.$route.name,
      typeName:{
        disease: '病种',
        disease_n: '诊断',
        disease_d: '日常工作项'
      }
    }
  },
  computed: {
    typeFn(){
      let row = this.currentData
      let education = "";
      let union = "";
      let support = "";
      if (row['educationFlag']==='true') {
        education = "普通进修"
      }
      if (row['unionsFlag']==='true') {
        union = "医联体"
      }
      if (row['supportFlag']==='true') {
        support = "对口帮扶"
      }
      return " " + education + " " + union + " " + support + " ";
    },
    statusFn(){
      return this.currentData.status === 'false' || this.currentData.status === '0' ? '启用' : '禁用'
    }
  },
  methods: {},
  mounted() {
    getStudentDetailById(this.currentData.studentId).then(res => {
      let data = res.data.data
      let target = Object.assign(this.currentData, data)
      this.$set(this, 'currentData', {...target})
    })
  }
}
</script>
