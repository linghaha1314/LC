<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="leaveForm">

      <van-field v-model="formData.summary" name="content" required label="自我鉴定" placeholder="请输入自我鉴定不少于500字"
                 type="textarea"
                 rows="5" maxlength="1000" show-word-limit :autosize="true"
                 :rules="[{ validator:(val)=>val.length>500, message: '请填写自我鉴定不少于500字'}]"
      />
      <div style="background: #cccccc;padding: 12px;" v-if="teacherInfo.length!==0">
        <div style="font-size: 16px;margin-bottom: 12px;">评价老师:</div>
        <div style="border-bottom: 1px solid #cccccc; margin-bottom: 12px;" v-for="item in teacherInfo" :key="item.id">
          <div style="font-size: 16px;padding: 12px;background: #ffffff;">老师: {{ item.teacherName }}</div>
          <van-field v-model="item.evaluateDetail" name="evaluateDetail" required label="评价老师"
                     placeholder="请输入评价不少于30字" type="textarea" rows="5" maxlength="100" show-word-limit :autosize="true"
                     :rules="[{ validator, message: '请填写评价不少于30字'}]"
          />
          <van-field name="vocationFlag" label="是否称职:" required :value="item['evaluateResult']"
                     :rules="[{ required: true, message: '请选择是否称职'}]">
            <template #input>
              <van-radio-group v-model="item['evaluateResult']" direction="horizontal">
                <van-radio style="width:50vw; margin-bottom: 12px" name="0">优秀</van-radio>
                <van-radio style="width:50vw; margin-bottom: 12px" name="1">称职</van-radio>
                <van-radio style="width:50vw; margin-bottom: 12px" name="2">基本称职</van-radio>
                <van-radio style="width:50vw; margin-bottom: 12px" name="3">不称职</van-radio>
              </van-radio-group>
            </template>
          </van-field>
        </div>
      </div>
      <div style="margin: 16px;">
        <van-button round block :disabled="formData.status && formData.status!=='0' && formData.status!=='1'"
                    color="#17d4b5" @click="onSubmit">
          {{ formData.status === 1 ? '重新提交' : '提交申请' }}
        </van-button>
      </div>
    </van-form>
  </div>
</template>
<script>
import {urlForPost, getApplyInfo, getTeacherInfo, updateEvaluateResult, urlForGet} from '../http/apiMap.js'
import {Dialog} from 'vant';

export default {
  name: 'test',
  data() {
    return {
      formData: {},
      studentInfo: {},
      disabled: false,
      teacherInfo: []
    }
  },
  computed: {
    name() {
      return this.$route.name
    }
  },
  methods: {
    // 提交数据
    onSubmit() {
      this.$refs.leaveForm.validate().then(() => {
        Dialog.confirm({
          title: '温馨提示:',
          message: '提交后不能修改, 确认提交么?'
        }).then(() => {
          if (!this.formData.id) {
            this.formData.studentId = this.studentInfo.studentId
            this.formData.teacherId = this.studentInfo.teacherId
            this.formData.sectionId = this.studentInfo.sectionId
          }
          updateEvaluateResult(this.teacherInfo).then()
          urlForPost(this.formData.id?'/advancedgraduation/update':'/advancedgraduation/create',this.formData).then(res => {
            this.$toast.success(res.data.msg || '操作成功!')
            this.$router.go(-1)
          })
        }).catch(() => {
          this.$toast.fail('已取消提交!')
        })

      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })

    },

    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb && cb()
      })
    },
    // 获取老师列表
    getTeacherInfoFn() {
      getTeacherInfo(this.studentInfo.studentId || this.formData.studentId).then(res => {
        if (res.data.data instanceof Array) {
          this.teacherInfo = res.data.data
        } else {
          this.$toast.fail(res.data.data.message)
        }
      })
    },
    validator(val) {
      return val.length > 30
    },
    // /surveyanswer/getGraduationSurvey
    getGraduation(){
      urlForGet('/surveyanswer/getGraduationSurvey').then(res => {
        if(!res.data.data){
          Dialog.alert({
            title: '提示:',
            message: '您还未填写问卷, 即将跳转问卷列表'
          }).then(()=>{
            this.$router.push({
              path: '/questionnaire'
            })
          })
        }
      })
    },
    getTest(){
      urlForGet('/examanswer/getExamInfoByStudentId').then(res => {
        if(!res.data.data){
          Dialog.alert({
            title: '提示:',
            message: '您还未进行结业考试!'
          }).then(()=>{
            this.$router.go(-1)
          })
        }
      })
    }
  },
  mounted() {
    let query = this.$route.query

    if (query.id) {
      this.formData = {...query}
      this.getTeacherInfoFn()
    } else {
      this.getApplyInfoFn(() => {
        this.getTeacherInfoFn()
      })
    }
    this.getTest()
    this.getGraduation()
  }
}
</script>
