<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>
    <div style="display: flex;justify-content: space-between;align-items: center; padding: 0 12px;">
      <van-search
          v-model="nameT"
          shape="round"
          placeholder="搜索考试"
          style="width: 100%"
          @change="examListFn"
      />
<!--      <router-link to="/my-test">-->
<!--        <div style="display: flex; flex-direction: column;align-items: center; color: #17d4b5">-->
<!--          <van-icon name="records" size="22"/>-->
<!--          <span style="font-size: 10px">我的考试</span>-->
<!--        </div>-->
<!--      </router-link>-->
    </div>
    <div style="background: #f6f6f6; padding: 12px;">
      <div style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
           v-for="data in testData" :key="data.title"
           @click="goTestDetail(data)"
      >
        <div style="font-size: 16px;">
          {{data.name}}
        </div>
        <van-divider />
        <div style="margin-bottom: 10px">
          <div style="color: #cccccc;margin-bottom: 4px;">医院名字:</div>
          <div>{{data['hospitalName']}}</div>
        </div>
        <div style="margin-bottom: 10px">
          <div style="color: #cccccc;margin-bottom: 4px;">考试时间:</div>
          <div>{{data.startDate}} 至 {{data.endDate}}</div>
        </div>
        <div>
          <div style="color: #cccccc;margin-bottom: 4px;">备注内容:</div>
          <div>{{data.remark}}</div>
        </div>
        <div style="position: absolute;right: -6px;top: -6px;" v-if="data.completed">
          <van-icon name="checked" color="#17d4b5" size="20"/>
        </div>
      </div>
      <div style="position: fixed;right: 26px;bottom: 60px" v-if="role==='sectionManager' || role==='superadmin' || role==='JXS_manager' || role==='headNurse'"
      >

        <router-link to="/test-add">
          <van-icon color="#ff0000" name="add" size="40"/>
        </router-link>
      </div>
    </div>
  </div>
</template>
<script>
  import {examList} from '../http/apiMap';
  export default {
      name: 'test',
      data(){
          return{
              value: '',
              testData: [],
              role:'',
              nameT: ''
          }
      },
      computed:{
          name(){
              return this.$route.name
          }
      },
      mounted() {
          this.role = localStorage.getItem('roleCode')
          this.examListFn()
      },
      methods:{
          goTestDetail(data){
              this.$router.push({
                  path: '/test-detail',
                  query: {
                      ...data
                  }
              })
          },
          examListFn(){
              examList({name: this.nameT}).then(res => {
                  this.testData = res.data.list
              })
          }

      }
  }
</script>