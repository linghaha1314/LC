<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <div style="width:100%; background: #f6f6f6;padding: 10px 12px;box-sizing: border-box;">
      <div style="border-left: 3px solid #17d4b5;padding: 0 4px">
        {{ name }}
      </div>
    </div>
    <van-form ref="basicInfoForm" style="padding: 0 12px">

        <van-field readonly clickable required name="typeId" label="科室" :value="basicInfo.sectionName"
                   placeholder="选择科室" @click="showSectionPicker=true"
                   :rules="[{ required: true, message: '请选择科室' }]"/>
        <van-popup v-model="showSectionPicker" round position="bottom">
          <div>
            <van-search v-model="sName" shape="round" @change="transferGet" placeholder="搜索"/>
          </div>
          <van-picker :columns="sectionColumns" :show-toolbar="true" @cancel="showSectionPicker = false"
                      @confirm="onConfirm($event,basicInfo,'sectionName','sectionId','showSectionPicker')"
          />
        </van-popup>
        <van-field
            name="staffName"
            readonly
            clickable
            required
            label="审核人"
            :value="basicInfo.staffName"
            placeholder="选择审核人"
            @click="showPicker = true"
            :rules="[{ required: true, message: '请选择审核人' }]"
        />
        <van-popup v-model="showPicker" round position="bottom">
          <Pager url="/staff/getListQueryByPage" :list-prop="['name','id']" @check="checkFn" :sectionId="basicInfo.sectionId"></Pager>
        </van-popup>
<!--        <van-field readonly clickable required name="typeId" label="专业" :value="basicInfo.majorName"-->
<!--                   placeholder="选择专业" @click="showMajorPicker = true"-->
<!--                   :rules="[{ required: true, message: '请选择专业' }]"/>-->
<!--        <van-popup v-model="showMajorPicker" round position="bottom">-->
<!--          <van-picker :columns="majorColumns" :show-toolbar="true" @cancel="showMajorPicker = false"-->
<!--                      @confirm="onConfirm($event,basicInfo,'majorName','majorId','showMajorPicker')"-->
<!--          />-->
<!--        </van-popup>-->

        <van-field name="status" label="是否启用" required :value="basicInfo.status" :rules="[{ required: true, message: '请选择是否启用' }]">
          <template #input>
            <van-radio-group v-model="basicInfo.status" direction="horizontal">
              <van-radio :name="0">启用</van-radio>
              <van-radio :name="1">禁用</van-radio>
            </van-radio-group>
          </template>
        </van-field>

      <div style="width:100%; height: 7px; background: #f6f6f6;margin-top: 40px;"></div>
        <van-button round block color="#17d4b5" @click="addWorkload">
          提交
        </van-button>
    </van-form>
  </div>
</template>
<script>
import {
  getTransferSchedule,
  submajorList,
  urlForPost
} from '../http/apiMap'
import Pager from '../components/searchPager'
export default {
  name: 'test',
  components: {
    Pager
  },
  data() {
    return {
      url: {
        save: '/advancedmajoraudit/insertNursingPersonnel',
        update: '/advancedmajoraudit/updateNursingPersonnel'
      },
      formData: {
      },
      basicInfo: {},
      attendInfo: {
        "affairDays": 0,
        "id": '',
        "illnessDays": 0,
        "skipWorkDays": 0,
        "workloadId": '',
      },
      attendListParam: {
        workloadId: '',
        pageSize: 999,
        pageNum: 1
      },
      userName: '',

      showPicker: false,
      showTypePicker: false,
      showDatePicker: false,
      showStartTimePicker: false,
      showSectionPicker: false,
      showMajorPicker: false,
      showEndTimePicker: false,
      currentWorkloadData: {},
      action_form: 0,
      sectionColumns: [],
      majorColumns: [],
      option1: [],
      sName: '',
    }
  },
  computed: {
    name() {
      return this.$route.name
    },
    typeColumns() {
      let arr = []
      this.option1.map(item => {
        arr.push(item.name)
      })
      return arr;
    },
    minDate() {
      let date = new Date()
      return new Date(date.getFullYear, date.getMonth - 1)
    }
  },
  methods: {
    // 添加工作量(基本信息)
    addWorkload() {
      this.$refs.basicInfoForm.validate().then(() => {
        urlForPost(this.basicInfo.id?this.url.update:this.url.save, this.basicInfo).then(res => {
          this.$toast.success({
            message: res.data.message,
            onClose:()=>{
              this.$router.go(-1)
            }
          })
        }).catch(()=>{})
      }).catch(() => {
        this.$toast.fail('请正确填写表单!')
      })
    },


    onConfirm(value, target, name, id, show) {
      target[name] = value.text
      target[id] = value.value
      this[show] = false;
      if (id === 'sectionId') {
        this.submajorListFn();
      }
    },
    // 获取科室信息
    transferGet() {
      getTransferSchedule({
        pageNum: 1,
        pageSize: 999,
        name: this.sName,
      }).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.sectionColumns = [...optionArr]
      })
    },
    // 获取专业列表
    submajorListFn() {
      let p = {};

      p = {
        pageSize: 999,
        pageNum: 1,
        sectionId: this.basicInfo.sectionId
      }

      submajorList(p).then(res => {
        let optionArr = []
        res.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.majorColumns = [...optionArr]
      })
    },

    checkFn(data) {
      this.basicInfo.staffId = data.value
      this.basicInfo.staffName = data.text
      this.showPicker = false
    },
  },
  mounted: function () {
    // 获取角色
    let data = this.$route.params
    if(data.id){
      this.$set(this,'basicInfo',data)
    }else{
      this.transferGet()
      this.submajorListFn()
    }
  }
}
</script>