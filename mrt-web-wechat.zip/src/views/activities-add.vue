<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span @click="$router.go(-1)" style="color: #17d4b5">返回</span>
      </template>
    </van-nav-bar>
    <van-form ref="activitiesForm" v-if="isEdit">
      <van-field
          v-model="formData.subject"
          name="subject"
          label="活动标题"
          required
          placeholder="请填写活动标题"
          :rules="[{ required: true, message: '请填写活动标题' }]"
      />

      <van-field
          name="teacherId"
          readonly
          clickable
          required
          label="主讲人"
          :value="formData.teacherName"
          placeholder="选择主讲人"
          @click="showPicker = true"
          :rules="[{ required: true, message: '请选择主讲人' }]"
      />
      <van-popup v-model="showPicker" round position="bottom">
        <Pager url="/teacher/listQueryTeacher" @check="checkFn" :sectionId="currentSectionId"></Pager>
      </van-popup>

      <van-field
          v-model="formData.location"
          name="location"
          label="活动地址"
          required
          placeholder="填写活动地址"
          :rules="[{ required: true, message: '请填写活动地址' }]"
      />

      <van-field
          readonly
          clickable
          name="startDate"
          required
          label="活动日期"
          :value="formData.startDate?formData.startDate.substring(0,10):''"
          placeholder="选择活动日期"
          @click="showDatePicker = true"
          :rules="[{ required: true, message: '请选择活动日期' }]"
      />
      <van-popup v-model="showDatePicker" round position="bottom">
        <van-datetime-picker
            v-model="formData.dateValue"
            type="date"
            title="选择年月日"
            @cancel="showDatePicker = false"
            @confirm="onDateConfirm"
            :min-date="minDate"
        />
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field
          name="startTime"
          readonly
          clickable
          required
          label="开始时间"
          :value="formData.startTime"
          placeholder="选择开始时间"
          @click="showStartTimePicker = true"
          :rules="[{ required: true, message: '请选择开始时间' }]"
      />
      <van-popup v-model="showStartTimePicker" round position="bottom">
        <van-datetime-picker
            v-model="formData.startTime"
            type="time"
            title="选择时间"
            @cancel="showStartTimePicker = false"
            @confirm="onStartDateConfirm"
        />
      </van-popup>
      <van-field
          name="endTime"
          readonly
          clickable
          required
          label="结束时间"
          :value="formData.endTime"
          placeholder="选择结束时间"
          @click="showEndTimePicker = true"
          :rules="[{ required: true, message: '请选择结束时间' }]"
      />
      <van-popup v-model="showEndTimePicker" round position="bottom">
        <van-datetime-picker
            v-model="formData.endTime"
            type="time"
            title="选择时间"
            @cancel="showEndTimePicker = false"
            @confirm="onEndDateConfirm"
        />
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>

      <van-field
          readonly
          clickable
          required
          name="type"
          label="活动类型"
          :value="currentData.typeName || formData.typeName"
          placeholder="选择活动类型"
          @click="showTypePickerFn"
          :rules="[{ required: true, message: '请选择活动类型' }]"
      />
      <van-popup v-model="showTypePicker" round position="bottom">
        <van-picker
            :columns="typeColumns"
            value-key="value"
            :show-toolbar="true"
            @cancel="showTypePicker = false"
            @confirm="onTypeConfirm"
        />
      </van-popup>
      <div style="width:100%; height: 7px; background: #f6f6f6"></div>
      <van-field
          v-model="formData.remark"
          name="remake"
          label="备注信息"
          placeholder="请填写备注信息"
      />
<!--      <van-field name="attachPath" label="附件上传" v-if="role !== 'StudentType_jxs' && formData.id">-->
<!--        <template #input>-->
<!--          <van-uploader accept=".doc,.docx,image/*,.pdf" v-model="attachPath" :after-read="afterRead"-->
<!--                        @delete="delFn"/>-->
<!--        </template>-->
<!--      </van-field>-->
      <van-cell title="已参加人数" v-if="role !== 'StudentType_jxs' && formData.id" :value="(studentList.length || 0)+'人'" is-link
                :to="{path: '/activities-detail',query: studentList}"/>
      <div style="margin: 16px;" v-if="action===3 && !formData.id">
        <van-button style="margin-bottom: 12px;" round block color="#17d4b5" @click="onSubmit">
          提交
        </van-button>
        <van-button round block type="danger" @click="removeA" v-if="formData.id">
          删除
        </van-button>
      </div>
      <div style="margin: 16px;" v-if="userId===formData.userId && formData.id">
        <van-button style="margin-bottom: 12px;" round block color="#17d4b5" @click="release">
          发布
        </van-button>
        <van-button round block type="danger" @click="removeA">
          删除
        </van-button>
      </div>
    </van-form>
    <div v-if="!isEdit">
      <van-cell title="活动标题" :value="formData.subject"/>
      <van-cell title="主讲人" :value="formData.teacherName"/>
      <van-cell title="活动地址" :value="formData.location"/>
      <van-cell title="活动日期" :value="formData.startDate?formData.startDate.substring(0,10):''"/>
      <van-cell title="开始时间" :value="formData.startTime"/>
      <van-cell title="结束时间" :value="formData.endTime"/>
      <van-cell title="活动类型" :value="currentData.typeName || formData.typeName"/>
      <van-cell title="备注信息" :value="formData.remark || '无'"/>
      <van-cell title="附件" is-link v-if="formData.attachList&&formData.attachList.length !== 0"
                @click="showImgPicker = true"/>
      <van-popup v-model="showImgPicker" round position="bottom">
        <div style="height: 60vh; font-size: 16px; font-weight: bold; padding: 24px; text-align: center;">
          <div style="margin:12px;" v-for="(item, index) in formData.attachList" :key="index">
            <div style="text-align: center; display: flex; flex-direction: column; align-items: center" v-if='item.attachPath'>
              <van-icon name="photo-o" size="30" @click="checkimgFn(item.attachPath)" v-if="item.attachPath.indexOf('jpg')>0 ||item.attachPath.indexOf('png')>0 "/>
              <a :href="item.attachPath" download="附件" v-else>
                <van-icon name="orders-o" size="30"/>
              </a>
              {{item.attachPath.split('/')[item.attachPath.split('/').length-1]}}
            </div>
          </div>
        </div>
      </van-popup>
      <van-popup v-model="showImgFilePicker" position="bottom">
        <img style="max-width:100vw;max-height:100vh" :src="seeImgUrl" alt="图片出问题了"/>
      </van-popup>
      <van-cell title="已参加人数" v-if="role !== 'StudentType_jxs'" :value="(studentList.length || 0)+'人'" is-link
                :to="{path: '/activities-detail',query: studentList}"/>

      <div style="margin: 16px;" v-if="userId===formData.userId && parseInt(formData.status)===1">

        <van-button round block type="warning" @click="activitiesOver(0)">
          撤回活动
        </van-button>
      </div>
      <div style="margin: 16px;" v-if="userId===formData.userId && parseInt(formData.status)===0">
        <van-button style="margin-bottom: 24px;" round block color="#17d4b5" @click="activitiesOver(1)">
          发布活动
        </van-button>
        <van-button round block type="danger" @click="activityDeleteFn">
          删除活动
        </van-button>
      </div>
      <div style="margin: 16px;" v-if="userId===formData.userId && parseInt(formData.status)===2">
        <van-button style="margin-bottom: 24px;" round block type="danger" @click="activitiesOver(3)">
          结束活动
        </van-button>

        <van-button round block type="danger" @click="activityDeleteFn">
          删除活动
        </van-button>
      </div>
    </div>
  </div>
</template>
<script>
  import Pager from '../components/searchPager'
  import {
    activityMember,
    addAttachFile,
    createTeachactivity,
    deleteAttachFile,
    getDictionaryType,
    removeTeachactivity,
    updateTeachactivity,
    uploadFile,
    // currentTeacher
  } from '../http/apiMap';

  export default {
    name: 'test',
    components: {
      Pager
    },
    data() {
      return {
        formData: {
          subject: '',
          location: '',
          teacherId: '',
          teacherName: '',
          dateValue: null,
          startTime: '',
          startDate: '',
          endTime: '',
          typeId: '',
          typeName: '',
          content: '',
          remark: '',
          attachPath: ''
        },
        attachPath: [],
        currentData: {},
        showPicker: false,
        showImgPicker: false,
        showImgFilePicker: false,
        seeImgUrl: '',
        showTypePicker: false,
        showDatePicker: false,
        showStartTimePicker: false,
        showEndTimePicker: false,

        action: 2,
        minDate: new Date(),
        maxDate: new Date(2025, 10, 1),
        currentDate: new Date(),
        currentTime: '12:00',
        currentEndDate: '12:00',
        option1: [],
        role: '',
        userId: '',
        studentList: [],
        name: '活动详情',
        typePage: this.$route.query.typePage,
        fileList: [],
        showUpload: false,
        saveFile:[],
        currentSectionId: localStorage.getItem('currentSectionId')
      }
    },
    computed: {

      typeColumns() {
        let arr = []
        this.option1.map(item => {
          arr.push(item.text)
        })
        return arr;
      },
      isEdit() {
        return this.action === 3 || (this.action === 0 && this.userId === this.formData.userId);
      }
    },
    methods: {
      onSubmit() {
        this.$refs.activitiesForm.validate().then(() => {
          let param = {
            "endTime": this.formData.endTime,
            "location": this.formData.location,
            "remark": this.formData.remark,
            "startDate": this.formData.startDate,
            "startTime": this.formData.startTime,
            "subject": this.formData.subject,
            "teacherId": this.formData.teacherId,
            "typeId": this.formData.typeId
          }
          createTeachactivity(param).then((res) => {
            this.formData.id = res.data.data.id
            this.showUpload = true;
            this.active = 0
            // if (this.formData.attachPath) {
            //   let param = {
            //     "activityId": res.data.data.id,
            //     "attachPath": this.formData.attachPath
            //   }
            //   addAttachFile(param).then()
            // }
            this.$toast.success('添加成功!')
            setTimeout(() => {
              this.$router.go(-1)
            }, 1000)
          })

        }).catch(() => {
          this.$toast.fail('请正确填写表单!')
        })
      },
      // 发布
      release() {
        let param = {
          "endTime": this.formData.endTime,
          "location": this.formData.location,
          "remark": this.formData.remark,
          "startDate": this.formData.startDate,
          "startTime": this.formData.startTime,
          "subject": this.formData.subject,
          "teacherId": this.formData.teacherId,
          "typeId": this.formData.typeId.value,
          id: this.currentData.id,
          status: 1
        }
        updateTeachactivity(param).then(() => {
          this.$toast.success('发布成功!')
          setTimeout(() => {
            this.$router.go(-1)
          }, 1000)
        })
      },
      // 删除活动
      removeA() {
        if(this.studentList.length!==0){
          this.$toast.fail('已有学员参加,请勿删除!')
          return false;
        }
        removeTeachactivity({
          id: this.formData.id,
          attachList: this.formData.attachList
        }).then(() => {
          this.$toast.success('删除成功!')
          setTimeout(() => {
            this.$router.go(-1)
          }, 1000)
        })
      },

      onTypeConfirm(value, index) {
        this.formData.typeId = this.option1[index].value;
        this.formData.typeName = value;
        this.showTypePicker = false;
      },

      onDateConfirm(value) {
        this.formData.startDate = this.getNowFormatDate(value) + ' 00:00:00'
        this.showDatePicker = false;
      },
      // 开始时间
      onStartDateConfirm(value) {
        this.formData.startTime = value
        this.showStartTimePicker = false;
      },
      // 结束时间
      onEndDateConfirm(value) {
        this.formData.endTime = value
        this.showEndTimePicker = false;
      },
      checkFn(data) {
        this.formData.teacherId = data.value
        this.formData.teacherName = data.text
        this.showPicker = false
      },
      // 获取类型
      getTypeList() {
        getDictionaryType('ActivityPlanContent').then(res => { // TeachActivityType
          let data = res.data.data
          let arr = []
          data.forEach(item => {
            if (item.name !== '入科教育') {
              let obj = {
                text: item.name,
                value: item.id
              }
              arr.push(obj)
            }
          })

          this.option1 = arr;
        })
      },
      // 结束活动
      activitiesOver(num) {
        let param = {
          id: this.currentData.id,
          status: num
        }
        updateTeachactivity(param).then(() => {
          this.$toast.success('操作成功!')
          setTimeout(() => {
            this.$router.go(-1)
          }, 1000)
        })
      },
      activityMemberFn() {
        activityMember({
          pageSize: 9999,
          pageNum: 1,
          "activityId": this.formData.id
        }).then(res => {
          this.studentList = res.data.list
        })
      },
      showTypePickerFn() {
        if (this.typePage === '1') {
          return false
        } else {
          this.showTypePicker = true
        }
      },
      activityDeleteFn() {
        removeTeachactivity({
          "id": this.formData.id
        }).then(() => {
          this.$toast.success('操作成功!')
          this.$router.go(-1)
        })
      },
      getNowFormatDate(date) {
        let seperator1 = "-";
        let year = date.getFullYear();
        let month = date.getMonth() + 1;
        let strDate = date.getDate();
        if (month >= 1 && month <= 9) {
          month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = "0" + strDate;
        }

        return year + seperator1 + month + seperator1 + strDate;
      },
      afterRead(file) {
        let data = new FormData()
        data.append('multipartFile', file.file)
        uploadFile(data).then(res => {
          this.formData.attachPath = res.data.path
          this.saveAttach()
        })
      },
      // 删除附件
      delFn(file) {
        let name = file.file.name
        let param = {}
        this.saveFile.forEach(item => {
          if(item.attachPath.indexOf(name)>0){
            param=item
          }
        })
        deleteAttachFile(param).then()
      },
      saveAttach(){
          let param = {
            "activityId": this.formData.id,
            "attachPath": this.formData.attachPath
          }
          addAttachFile(param).then(res=>{
            this.saveFile.push({
              id: res.data.data["reasons"].data.id,
              attachPath: this.formData.attachPath
            })
          })
      },
      checkimgFn(url){
        this.showImgFilePicker = true;
        this.seeImgUrl = url
      }
    },
    mounted() {
      this.role = localStorage.getItem('roleCode')
      this.userId = localStorage.getItem('userId')
      this.currentData = JSON.parse(localStorage.getItem('currentData') || "{}")
      let queryData = this.$route.query || {}
      if (!queryData.id || parseInt(queryData.status||'0') === 0) {
        this.action = 3
        if(parseInt(queryData.status||'0') === 0){
          this.formData = this.$route.query
        }
      } else {
        this.formData = this.$route.query
        this.action = queryData.status
        this.showUpload = true;
      }
      if (this.typePage === '1') {
        this.formData.typeId = '63e37fba-85df-11ea-8355-00163e0603fa'
        this.formData.typeName = '入科教育'
      }
      localStorage.setItem('currentData', '')
      this.getTypeList() // 获取类型
      if(this.formData.id){
        this.activityMemberFn(); // 获取参加学生
      }
    }
  }
</script>
