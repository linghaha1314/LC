<template>
  <div>
    <van-nav-bar :title="name" left-arrow>
      <template #left>
        <span style="color: #17d4b5" @click="$router.go(-1)">返回</span>
      </template>
    </van-nav-bar>

    <div>
      <van-dropdown-menu active-color="#17d4b5">
<!--        <van-dropdown-item title="年度" v-model="listParams['searchMonth']" @change="leaveListGet" :options="option1"/>-->
        <van-dropdown-item v-if="role === 'JXS_manager'" title="科室" v-model="listParams.sectionId" @change="sectionChange" :options="option2"/>
        <van-dropdown-item title="专业" v-model="listParams.majorId" @change="leaveListGet" :options="majorOption" />
<!--        <van-dropdown-item title="批次" v-model="listParams.batchId" @change="leaveListGet" :options="option3"/>-->
      </van-dropdown-menu>
    </div>

    <div style="background: #f6f6f6; padding: 12px;">
      <div>
        <van-search v-model="listParams.name" shape="round" @change="searchLeaveListGet" placeholder="搜索" />
      </div>
      <van-pull-refresh v-model="state.refreshing" :head-height="80" @refresh="onRefresh">
        <van-list
            v-model="state.loading"
            :finished="state.finished"
            finished-text="没有更多了"
            @load="onLoad"
        >
          <div
              style="background: #ffffff; padding: 10px 20px; border-radius: 4px; position: relative;margin-bottom: 12px"
              v-for="data in testData"
              :key="data.id">
<!--            <div style="font-size: 14px;display: flex;justify-content: space-between;">-->
<!--              {{ data.studentName }}-->
<!--              <van-tag style="text-align: center" :type="'success'" v-if="data.status===2" size="medium">-->
<!--                已结业-->
<!--              </van-tag>-->
<!--              <van-tag style="text-align: center" :type="'danger'" v-if="data.status===1" size="medium">提前结业-->
<!--              </van-tag>-->
<!--              <van-tag style="text-align: center" :type="'primary'" v-if="data.status===0" size="medium">-->
<!--                在训-->
<!--              </van-tag>-->
<!--              <van-tag style="text-align: center" :type="'warning'" v-if="data.status===3" size="medium">-->
<!--                结业中-->
<!--              </van-tag>-->
<!--            </div>-->
            <van-divider/>
            <div @click="goDetail(data)">
              <div style="margin-bottom: 10px">
                <div>{{ typeName[queryData.type] }}: {{ data['name'] || '无' }}</div>
              </div>
<!--              <div style="margin-bottom: 10px">-->
<!--                <div>时间: {{ data.created && data.created.substring(0, 10) }}</div>-->
<!--              </div>-->
              <div style="margin-bottom: 10px">
                <div>科室: {{ data.sectionName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>专业: {{ data.majorName || '无' }}</div>
              </div>
              <div style="margin-bottom: 10px">
                <div>状态: {{ data.status===0 || data.status===false?'启用':'禁用' }}</div>
              </div>
            </div>
            <div style="text-align: right;">
<!--              <van-button v-if="role !== 'StudentType_jxs' &&  data.status === 11 && !isMine"-->
<!--                          style="width: 50px; margin-right: 12px" type="warning" size="mini" @click="goProcess(data)">-->
<!--                去审核-->
<!--              </van-button>-->
              <van-button v-if="role === 'JXS_manager'"
                          style="width: 50px;
                          margin-right: 12px"
                          type="danger"
                          size="mini"
                          @click="delFn(data)">删除
              </van-button>
              <router-link :to="{path:'/disease-species-add',query:{...data,type: queryData.type}}">
                <van-button style="width: 50px; margin-right: 12px"
                            type="warning"
                            size="mini">修改
                </van-button>
              </router-link>
              <router-link :to="{path:'/disease-species-detail',query:{...data,type: queryData.type}}">
                <van-button style="width: 50px; margin-right: 12px"
                            type="primary"
                            size="mini">查看
                </van-button>
              </router-link>

<!--              <router-link v-if="data.status === 11" :to="{path:'/approval-detail',query:data}">-->
<!--                <van-button type="default" size="mini">查看审批进度</van-button>-->
<!--              </router-link>-->
            </div>
          </div>
        </van-list>
      </van-pull-refresh>
      <div style="position: fixed;right: 26px;bottom: 60px">
        <van-icon color="#ff0000" name="add" size="40" @click="addLeave"/>
      </div>
    </div>
  </div>
</template>
<script>
import {Dialog} from 'vant';
import {
  getApplyInfo,
  urlForPost,
  urlForGet
} from "../http/apiMap";

export default {
  name: 'test',
  components: {
    [Dialog.Component.name]: Dialog.Component,
  },
  data() {
    return {
      reason: '',
      show: false,
      listParams: {
        pageSize: 10,
        pageNum: 0,
        sectionId: '',
      },
      transferParams: {
        pageSize: 999,
        pageNum: 1,
      },
      option1: [],
      option2: [],
      option3: [
        {text: '全部', value: null},
        {text: '已拒绝', value: 1},
        {text: '已通过', value: 2},
        {text: '审核中', value: 11},
      ],
      majorOption: [],
      testData: [],
      role: '',
      isMine: false,
      notTarget: {},
      studentInfo: {},
      state: {
        loading: false,
        finished: false,
        refreshing: false
      },
      isLoading: false,
      count: 0,
      queryData: this.$route.query,
      typeName:{
        disease: '病种',
        disease_n: '诊断',
        disease_d: '日常工作项'
      }
    }
  },
  computed: {
    name() {
      if(this.queryData.type === 'disease'){
        return '病种管理'
      }else if(this.queryData.type === 'disease_n'){
        return '诊断管理'
      }else{
        return '日常工作项'
      }
    }
  },
  methods: {
    goDetail(data) {
      if (this.role === 'StudentType_jxs') {
        this.$router.push({
          path: '/three-mouths-add',
          query: data
        })
      }
    },
    searchLeaveListGet(){
      this.listParams.pageNum = 1
      this.leaveListGet()
    },
    // 获取列表
    leaveListGet(f) {
      let params = {
        ...this.listParams
      }
      let url = ''
      if(this.queryData.type === 'disease'){
        url = '/diseases/listByPage'
      }else if(this.queryData.type === 'disease_n'){
        url = '/advancedworkloaddiagnosis/listByPage'
      }else {
        url = '/advancedworkitem/listByPage'
      }
      urlForPost(url,params).then(res => {
        if (f === 'onLoad') {
          this.state.loading = false;
          if ( res.data.list.length === 0 || res.data.list.length<this.listParams.pageSize || res.data.total === res.data.list.length) {
            this.state.finished = true
          }
          if(res.data.total === 0){
            this.testData = []
          }else{
            this.testData = [...this.testData, ...res.data.list];
          }
        } else {
          this.testData = [...res.data.list];
        }
      })
    },
    getYear() {
      let date = new Date();
      let year = date.getFullYear();
      let arr = [
        {text: '全部', value: ''}
      ];
      for (let i = year; i > 1949; i--) {
        let obj = {
          text: i,
          value: i
        }
        arr.push(obj);
      }
      this.option1 = arr
    },
    // 获取科室信息
    transferGet() {
      urlForPost('/student/getSectionserListData',this.transferParams).then(res => {
        let optionArr = [
          {text: '全部', value: ''}
        ]
        res.data.data.list.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id
          }
          optionArr.push(obj)
        })
        this.option2 = [...optionArr]
      })
    },
    // 获取批次
    getBatch(){
      urlForPost('/backboneTraining/getBatchByPage',
          {
            "status":"",
            "pageNum":1,
            "pageSize":999
          }
      ).then((res)=>{
        let arr = [{
          text: '全部',
          value: ''
        }]
        let data = res.data.data.list
        data.forEach(item => {
          let obj = {
            text: item.name,
            value: item.id,
            ...item
          }
          arr.push(obj)
        })
        this.option3 = arr
      }).catch(()=>{})
    },

    // 判断是否有正在审核的申请
    addLeave() {
      this.$router.push({
        path: '/disease-species-add',
        query: {
          type: this.queryData.type
        }
      })
    },
    // 获取学员结业信息
    getApplyInfoFn(cb) {
      let studentId = localStorage.getItem('studentId') || ''
      getApplyInfo(studentId).then(res => {
        this.studentInfo = res.data
        cb()
      })
    },
    delFn(data) {
      Dialog.confirm({
        message: '确认删除么!'
      }).then(()=>{
        let url
        if(this.queryData.type === 'disease'){
          url = '/diseases/deleteById'
        }else if(this.queryData.type === 'disease_n'){
          url = '/advancedworkloaddiagnosis/remove'
        }else {
          url = 'advancedworkitem/deleteById'
        }
        urlForGet(url,data.id
        ).then(() => {
          this.$toast.success('操作成功!')
          this.leaveListGet() // 获取申请列表
        })
      }).catch(()=>{})

    },
    goProcess(data) {

      this.$router.push({
        path: '/three-mouths-process',
        query: data
      })
    },
    onRefresh() {
      // 清空列表数据
      this.state.finished = false;
      // 将 loading 设置为 true，表示处于加载状态
      this.state.loading = true;
      this.listParams.pageNum = 0
      this.onLoad();
    },
    onLoad() {
      let flag = 'onLoad'
      if (this.state.refreshing) {
        this.testData = [];
        this.state.refreshing = false;
      }
      this.listParams.pageNum++
      this.leaveListGet(flag)
    },
    // 获取专业
    getListMajor(){
      urlForPost('/submajor/getListQueryByPage',{
        pageSize: 999,
        sectionId: this.listParams.sectionId,
        pageNum: 1
      }).then(res => {
        let optionArr = [
          { text: '全部', value: '' }
        ]
        res.data.list.forEach(item => {
          let obj = {
            text: item.sectionName+' - '+item.name,
            value: item.id,
            ...item
          }
          optionArr.push(obj)
        })
        this.majorOption = [...optionArr]
      })
    },
    sectionChange(){
      this.getListMajor()
      this.leaveListGet()
    }
  },
  mounted() {
    // 获取角色
    this.role = localStorage.getItem('roleCode')
    let newData = JSON.parse(localStorage.getItem('addItem') || '{}')
    this.getYear()
    let len = Object.keys(newData).length
    if (len !== 0) {
      newData.status = 2
      this.testData.unshift(newData);
      localStorage.setItem('addItem', '')
    }
    this.transferGet() // 获取科室数据
    this.getBatch() // 获取批次数据
    this.getListMajor() // 获取专业
  },
}
</script>
