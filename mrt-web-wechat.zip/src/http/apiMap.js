import axios from './axios'

// 获取字典数据
export function getForCode(code) {
    return axios.post('/dictionary/getByTypeCode/' + code)
}

// 获取报名时间
export function getSignupTime(code) {
    return axios.get('/advancedsignup/getAdvancedSignupById/' + code)
}

// 查询老师的
export function getTeacherInfo(code) {
    return axios.get('/advancedgraduation/getTeacherInfoByStudentId/' + code)
}

// 根据身份证号查询人员信息
export function getStaffByIdentifyNo(code) {
    return axios.get('/advancedsignup/getStaffByIdentifyNo/' + code)
}

// 根据学生id查询老师
export function getApplyInfo(code) {
    return axios.get('/advancedgraduation/getApplyByStudentId/' + code)
}

// 根据id获取学生信息
export function getStudentDetail(code) {
    return axios.get('/advancedgraduation/getDetailById/' + code)
}

// 获取用户信息
export function getMyUserInfo() {
    return axios.get('/account/getMyUserInfo')
}

// 获取角色类型
export function getAuthType() {
    return axios.get('/advancedgraduation/getAuthType')
}

// 获取用户角色列表
export function getMyRoles() {
    return axios.get('/role/getMyRoles')
}

// 关于我们
export function aboutus() {
    return axios.get('/account/aboutus')
}

// 用户协议
// export function getUserAgreement() {
//     return axios.get('/account/getUserAgreement')
// }

// 隐私协议
// export function getPrivacyAgreement() {
//     return axios.get('/account/getPrivacyAgreement')
// }

// 隐私协议
export function courseWare(params) {
    return axios.get(`/courseware/getById/${params}`)
}

// 考试信息
export function examMsg(params) {
    return axios.get(`/examanswer/getEntityById/${params}`)
}

// 试卷信息
export function examPaperMsg(params) {
    return axios.get(`/examvolume/getById/${params}`)
}

// 试卷信息
export function questionnairePro(params) {
    return axios.get(`/surveyanswer/getQuestionAndOptionByVolumeId/${params}`)
}

// 传地址获取信息
export function urlForPost (url, params) {
    return axios.post(url, params)
}

// 通过code获取
export function urlForGet (url,code,name) {
    let id = name||'id'
    return axios.get(url+'?'+id+'='+code)
}

// 通过code获取
export function urlForGetCode (url,code) {
    return axios.get(url+'/'+code)
}

// 登录
export function getLogin (params) {
    return axios.post('/account/login', params)
}

// 请假列表
export function getLeaveList (params) {
    return axios.post('/leaverecord/getListByPage', params)
}

// 请假列表
export function getListProcess (params) {
    return axios.post('/leaverecord/listProcessByPage', params)
}

// 请假类型
export function getLeaveType (params) {
    return axios.post('/leavetype/getListQueryByPage', params)
}

// 添加请假
export function getMobileProcess (params) {
    return axios.post('/leaverecord/startMobileProcess', params)
}

// 查询科室(学生)
export function getTransferSchedule (params) {
    return axios.post('/section/getListByPage', params)
}

// 查询科室(注册)
export function getTransferSign(params) {
    return axios.post('/advancedsection/getListByPage', params)
}

// 查询科室(教师)
// export function getTransferAll (params) {
//     return axios.post('/section/listAuthQueryByPage', params)
// }

// 查询带教老师
export function getTeacher (params) {
    return axios.post('/teacher/listQueryTeacher', params)
}

// 查询销假列表
export function getLeaveReturn (params) {
    return axios.post('/leavereturn/getListByPage', params)
}

// 销假申请
// export function getLeaveReturnUpdate (params) {
//     return axios.post('/leavereturn/update', params)
// }

// 学生提交销假上报
export function getLeaveReturnStartProcess (params) {
    return axios.post('/leavereturn/startProcess', params)
}

// 上传文件
export function uploadFile (params) {
    return axios.post('/leaverecord/uploadfile', params, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    })
}

// 上传文件(注册)
export function uploadSignFile(params) {
    return axios.post('/advancedsignupattach/uploadfile', params, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    })
}

// 删除附件
export function deleteAttachFile(params) {
    return axios.post('/activityattach/deleteAttachFile', params)
}

// 教学活动添加附件
export function addAttachFile(params) {
    return axios.post('/activityattach/create', params)
}
// 上级接口
// 审批请假
export function getLeaveApprovalProcess (params) {
    return axios.post('/leaverecord/approvalProcess', params)
}

// 审批请假前提示信息
export function getLeaveVerification (params) {
    return axios.post('/leaverecord/verification', params)
}

// 获取销假列表
export function getLeavereturnList (params) {
    return axios.post('/leavereturn/listProcessByPage', params)
}

// 审批销假列表
export function getLeavereturnApprovalProcess (params) {
    return axios.post('/leavereturn/approvalProcess', params)
}

// 查询教学活动列表
export function getTeachactivity (params) {
    return axios.post('/teachactivity/getListAuthQueryByPage', params)
}

// 查询教学活动类型和层次
export function getDictionaryType (params) {
    return axios.post('/dictionary/getByTypeCode/'+params)
}

// 教学活动签到
export function getActivityMember (params) {
    return axios.post('/activitymember/create', params)
}


// 教学活动添加
export function createTeachactivity (params) {
    return axios.post('/teachactivity/create', params)
}

// 教学活动发布
export function updateTeachactivity (params) {
    return axios.post('/teachactivity/update', params)
}


// 教学活动删除
export function removeTeachactivity (params) {
    return axios.post('/teachactivity/remove', params)
}

// 教学活动填写核心知识点
export function updateActivitymember(params) {
    return axios.post('/activitymember/update', params)
}

// 修改密码
export function changePassword(params) {
    return axios.post('/account/changePassword', params)
}

// 修改用户头像
export function updateAvator(params) {
    return axios.post('/staff/updateAvator', params)
}

// 修改角色
export function changeRole(params) {
    return axios.post('/role/changeRole/'+params)
}

// 修改用户头像
export function getListQueryByPage(params) {
    return axios.post('/infos/getListQueryByPage', params)
}

// 获取病种列表
export function getListDiseases(params) {
    return axios.post('/diseases/getListQueryByPage', params)
}

//临床技能操作列表
export function advancedSkill(params) {
    return axios.post('/advancedskill/getListQueryByPage', params)
}

//临床技能操作列表(医技护理)
export function advancedSkillItem(params) {
    return axios.post('/advancedworkitem/getListByPage', params)
}

//工作量添加更新
export function advancedWorkload(params) {
    return axios.post('/advancedworkload/saveOrUpdate', params)
}

//工作量删除
export function advancedWorkloadRemove(params) {
    return axios.post('/advancedworkload/remove', params)
}

//出勤汇总添加更新
export function advancedWorkloadAttend(params) {
    return axios.post('/advancedworkloadattend/saveOrUpdate', params)
}

// 工作量主管病例列表
export function advancedWorkloadMr(params) {
    return axios.post('/advancedworkloadmr/listAdvancedWorkloadmrByPage', params)
}

// 工作量主管病例列表()
export function saveOrUpdateWorkloadWd(params) {
    return axios.post('/advancedworkloadwd/saveOrUpdateWorkloadWd', params)
}

// 主管病例添加更新()
export function advancedWorkloadMrSave(params) {
    return axios.post('/advancedworkloadmr/saveOrUpdateWorkloadMr', params)
}

// 删除工作量主管病例
export function removeMobileProcess(params) {
    return axios.post('/advancedworkloadmr/remove', params)
}

// 删除工作量医技
export function removeWd(params) {
    return axios.post('/advancedworkloadwd/remove', params)
}

// 删除工作量主管病例(门诊)
export function removeOutpatient(params) {
    return axios.post('/advancedworkloadoutpatient/removeWorkloadOutPatient', params)
}

// 工作量提交申请
export function startMobileProcess(params) {
    return axios.post('/advancedworkload/startMobileProcess', params)
}

// 工作量列表查询
export function advancedWorkloadList(params) {
    return axios.post('/advancedworkload/listQueryByPage', params)
}

// 工作量出勤汇总列表
export function advancedworkloadattendList(params) {
    return axios.post('/advancedworkloadattend/listQueryByPage', params)
}

// 上级审批工作量列表
export function advancedworkloadListProcess(params) {
    return axios.post('/advancedworkload/listProcessByPage', params)
}

// 上级审批工作量
export function advancedworkloadApprovalProcess(params) {
    return axios.post('/advancedworkload/approvalProcess', params)
}

// 我的功能菜单
export function getMyFunctions(params) {
    return axios.post('/approlefunction/getMyFunctions', params)
}

// 审批进程
export function getFlowData(params) {
    return axios.post('/workflows/getFlowData', params)
}

// 消息总数
export function getMyMessage() {
    return axios.post('/message/getMyMessage', {})
}

// 获取消息列表
export function getOneTypeMessages(params) {
    return axios.post('/message/getOneTypeMessages', params)
}

// 通知查看消息
export function updateBymessageId(params) {
    return axios.post('/messagelist/updateBymessageId', params)
}

// 系统消息查看
export function updateStatus(params) {
    return axios.post('/message/updateStatus', params)
}

// 岗前培训记录查询
export function preJobTrainingRecord(params) {
    return axios.post('/prejobtrainingrecord/listByPage', params)
}

// 岗前培训的签到
export function preJobTrainingUpdate(params) {
    return axios.post('/prejobtrainingrecord/update', params)
}

// 查询岗前活动打卡地点查询
export function signAddress(params) {
    return axios.post('/attendconfig/listByHospitalId', params)
}

// 我的课程
export function courseList(params) {
    return axios.post('/course/listByPage', params)
}

// 我的课程
export function courseTypeList(params) {
    return axios.post('/coursetype/getListQueryByPage', params)
}

// 获取课程详情
export function courseDetail(params) {
    return axios.post(`/course/getById/${params}`)
}

// 报名详情
export function memberDetail(params) {
    return axios.post(`/coursemember/listByObj`, params)
}

// 课程报名
export function memberCreate(params) {
    return axios.post(`/coursemember/create`, params)
}

// 添加人数
export function addCourseWareStudyNum(params) {
    return axios.post(`/courseware/addCourseWareStudyNum/${params}`)
}

// 课件进度创建
export function processCreate(params) {
    return axios.post(`/courseprocess/create`, params)
}

// 课件进度更新
export function processUpdate(params) {
    return axios.post(`/courseprocess/update`, params)
}

// 考试列表查询
export function examList(params) {
    return axios.post(`/examplan/getMyPlan`, params)
}

// 考试结果查询
export function examResult(params) {
    return axios.post(`/examvolumequestion/getActivityResult`, params)
}

// 考试试题获取
export function examQuestion(params) {
    return axios.post(`/examvolumequestion/getVNQ`, params)
}

// 上传开始时间
export function saveExamStartInfo(params) {
    return axios.post(`/examanswer/saveExamStartInfo`, params)
}

// 保存答案详情
export function saveAnswer(params) {
    return axios.post(`/examanswerresult/saveAnswer`, params)
}

// 考试交卷
export function examCompleted(params) {
    return axios.post(`/examanswer/completed`, params)
}

// // 试卷列表
// export function examLists(params) {
//     return axios.post(`/examvolume/listSomeVolume`, params)
// }

// 考试安排列表
export function examplanLists(params) {
    return axios.post(`/examplan/listByPage`, params)
}

// 筛选人员
export function staffLists(params) {
    return axios.post(`/staff/listByStaff`, params)
}

// 提交考试安排
export function createPlanAndUser(params) {
    return axios.post(`/examplan/createPlanAndUser`, params)
}

// 提交考试安排
export function updatePlanAndUser(params) {
    return axios.post(`/examplan/updatePlanAndUser`, params)
}

// 考试人员数据
export function examplanUser(params) {
    return axios.post(`/examplanuser/listStaffByPlan`, params)
}

// 入科列表获取
export function intoFamilyList(params) {
    return axios.post(`/transfercheckin/listCurrentSectionStudent`, params)
}

// 轮转列表获取
export function intoFamilySectionList(params) {
    return axios.post(`/transfercheckin/listPageBySection`, params)
}

// 确认入科人员
export function checkinIntoFamily(params) {
    return axios.post(`/transfercheckin/checkinAll`, params)
}

// 安排带教老师
export function checkinTeacher(params) {
    return axios.post(`/transfercheckin/allocationTeacher`, params)
}

// 上级出科申请列表
export function outFamilyProcessByPage(params) {
    return axios.post(`/transfercheckout/listProcessByPage`, params)
}

// 申请出科的科室
export function listMyCheckIn(params) {
    return axios.post(`/transfercheckin/listMyCheckIn`, params)
}

// 填写出科申请
// export function outFamilyProcess(params) {
//     return axios.post(`/transfercheckout/startMobileProcess`, params)
// }

// 出科申请查询列表
export function outFamilyListAuth(params) {
    return axios.post(`/transfercheckout/getListAuthQueryByPage`, params)
}
// 审核出科申请
export function outFamilyApprovalProcess(params) {
    return axios.post(`/transfercheckout/approvalProcess`, params)
}

// 轮转学员确认入科
export function outFamilyCreate(params) {
    return axios.post(`/transfercheckin/createAll`, params)
}

//我的轮转信息
export function myschedule(params) {
    return axios.post(`/transferschedule/myschedule`, params)
}

// 获取消息附件
export function msgFile(params) {
    return axios.post(`/messageattach/listByObj`, params)
}

// 我的学员
export function listStudentByPage(params) {
    return axios.post(`/student/listStudentByPage`, params)
}

// 专业列表
export function listMajor(params) {
    return axios.post(`/submajor/getListByPage`, params)
}

// 专业列表
export function listMajorAd(params) {
    return axios.post(`/advancedMajor/getListByPage`, params)
}

// 查询带教老师
export function currentTeacher(params) {
    return axios.post(`/studentteacher/getStudentCurrentTeacherByStudentId`, params)
}

// 获取请假天数
export function getlLeaveDay(params) {
    return axios.post(`/leavereturn/getlLeaveDaysByType`, params)
}

// 微信接口授权
export function getSignWx(params) {
    return axios.post(`/account/getWxData`, params)
}

// 教学活动参加人数
export function activityMember(params) {
    return axios.post(`/activitymember/getListByUser`, params)
}

// 获取word模板
export function wordtemplate(params) {
    return axios.post(`/student/getTemplateIdByType/` + params, )
}

// 获取申请书模板
export function getOneWordTemplateByObject(params) {
    return axios.post(`/wordtemplate/getOneWordTemplateByObject`,params)
}

// 下载文件
export function downFile(params) {
    return axios.post(`/wordtemplate/createWordDoc`, params, {responseType:'blob'})
}


// 考试详情
export function testDetail(params) {
    return axios.post(`/examanswer/getPersonAnalysis`, params)
}

// 工作人员类型
export function staffTypeWord(params) {
    return axios.post(`/dictionary/getByTypeCode/` + params, )
}

// 获取专业
export function submajorList(params) {
    return axios.post(`/submajor/getListByPage`, params)
}

// 医技获取列表
export function othersList(params) {
    return axios.post(`/advancedworkloadwd/listByWorkloadId`, params)
}

// 获取当前科室
// export function getCurrentSection() {
//     return axios.post(`/transfercheckin/getCurrentSection`)
// }

// 查询工作量列表详情列数
export function getDetailWorkload(params) {
    return axios.post(`/advancedworkload/getDetailById`, params)
}

// 查询教学活动附件
export function activityattachList(params) {
    return axios.post(`/activityattach/getListQueryByPage`, params)
}

// 保存医师门诊工作量
export function advancedworkloadoutpatient(params) {
    return axios.post(`/advancedworkloadoutpatient/saveOrUpdateWorkloadOutpatient`, params)
}


// 保存医师门诊工作量列表
export function advancedworkloadoutpatientList(params) {
    return axios.post(`/advancedworkloadoutpatient/listOutpatientByPage`, params)
}

// 科室目录
export function getCategory(params) {
    return axios.post(`/advancedsignup/listSectionCategoryByPage`, params)
}

// 提交结业申请
// export function upApply(params) {
//     return axios.post(`/advancedgraduation/create`, params)
// }

// 查询结业鉴定列表
export function getStudentApplyList(params) {
    return axios.post(`/advancedgraduation/listAdvancedgraduationByPage`, params)
}

// 删除结业记录
export function delApply(params) {
    return axios.post(`/advancedgraduation/remove`, params)
}

// 删除三个月考核记录
export function delThreemonthcheck(params) {
    return axios.post(`/threemonthcheck/remove`, params)
}

// 提交结业记录
export function upApplyProcess(params) {
    return axios.post(`/advancedgraduation/startProcess`, params)
}

// 提交三个月考核记录
export function threemonthProcess(params) {
    return axios.post(`/threemonthcheck/startProcess`, params)
}

// 结业审批列表

export function applyProcessList(params) {
    return axios.post(`/advancedgraduation/listProcessByPage`, params)
}

// 三个月考核审批列表

export function listProcessByPageThree(params) {
    return axios.post(`/threemonthcheck/listProcessByPage`, params)
}

// 结业审批
export function applyProcess(params) {
    return axios.post(`/advancedgraduation/approvalProcess`, params)
}

// 三个月审批
export function threemonthApproval(params) {
    return axios.post(`/threemonthcheck/approvalProcess`, params)
}

// 提交老师评价
export function updateEvaluateResult(params) {
    return axios.post(`/studentteacher/updateEvaluateResult`, params)
}

// 获取入科三个月考核理论成绩
export function getTheoryScoreByStudentId(params) {
    return axios.post(`/threemonthcheck/getTheoryScoreByStudentId`, params)
}

// 根据学生id查询轮转信息
export function getTransferscheduleCode(code) {
    return axios.post('/transferschedule/getCurrentSectionByStudentId/' + code)
}

// 删除学生请假
export function removeLeave(code) {
    return axios.post('/leaverecord/remove/' + code)
}

// 根据学生id查询轮转信息
export function getStudentInfo(code) {
    return axios.get('/student/getStudentDetailByStudentId/' + code)
}

// 根据学生id查询轮转信息
export function getCurrentTeacherInfo() {
    return axios.get('/threemonthcheck/getCurrentTeacherInfo/')
}

// 根据学生id查询三个考核信息
export function getStudentDetailById(code) {
    return axios.get('/threemonthcheck/getStudentDetailById/'+code)
}

// 根据学生id查询结业状态
export function getStudentById(code) {
    return axios.get('/student/getById/'+code)
}

// 查询字典信息
// export function getDictionaryInfo(code) {
//     return axios.post('/dictionary/getDictionaryDataByParams', code)
// }

// 查询证书信息
export function getCertificate(code) {
    return axios.post('/advancedsignupattach/getListQueryByPage', code)
}

// 查询证书信息
export function getCertificatesByStaff(code) {
    return axios.post('/advancedsignup/getCertificatesByStaff', code)
}

// 查询三个月考核列表
export function listThreeMonthCheckByPage(code) {
    return axios.post('/threemonthcheck/listThreeMonthCheckByPage', code)
}

// 查询学籍列表
export function studentsStatusList(code) {
    return axios.post('/student/studentsStatusList', code)
}

// 查询考勤信息
export function getThreemonthAttendance(code) {
    return axios.post('/threemonthattendance/listByPage', code)
}

// 更新考勤信息
export function updateThreemonthAttendance(code) {
    return axios.post('/threemonthattendance/update', code)
}

// 获取部门初审审批列表
export function advancedsignupList(code) {
    return axios.post('/advancedsignup/listQueryByPage', code)
}

// 骨干老师计划列表
export function plansList(code) {
    return axios.post('/plans/listPlansByPage', code)
}

// 骨干老师计划添加
export function plansCreate(code) {
    return axios.post('/plans/create', code)
}

// 培训阶段列表查询
export function plansummaryList(code) {
    return axios.post('/plansummary/listPlanSummaryByPage', code)
}

// 培训阶段审核列表查询
// export function plansummaryProcessList(code) {
//     return axios.post('/plansummary/listProcessByPage', code)
// }

// 问卷列表查询
// export function surveyanswerList(code) {
//     return axios.post('/surveyanswer/getMySurveyVolume', code)
// }

// 保存问卷答案
export function saveQuestionResult(code) {
    return axios.post('/surveyanswer/saveQuestionResult', code)
}

// 保存时间计划
// export function planscheduleCreate(code) {
//     return axios.post('/planschedule/create', code)
// }

// 搜索问卷答案
export function surveyAnswer(code) {
    return axios.post('/surveyanswer/listQueryByStaffIdAndVolumeId', code)
}

// 搜索问卷答案
export function planscheduleTimeList(code) {
        return axios.post('/planschedule/listPlanScheduleByPage', code)
}

// 查询学员信息
export function getStudentDetailDown(code) {
    return axios.post('/student/getDetailById', code)
}
