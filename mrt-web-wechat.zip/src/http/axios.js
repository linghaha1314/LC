import Axios from 'axios'
import {Toast} from 'vant';

let axios
if(process.env.NODE_ENV === 'production'){
    axios = Axios.create({
        timeout: 1000 * 60 * 2,
        // `headers` 是即将被发送的自定义请求头
    })
}else{
    axios = Axios.create({
        // baseURL: 'http://192.168.1.53:64007/', // 基本URL 地址，动态匹配
        // baseURL: 'http://118.116.119.169:64007/', // 基本URL 地址，动态匹配
        baseURL: 'http://192.168.11.6:64007/', // 基本URL 地址，动态匹配
        timeout: 1000 * 60 * 2,
    })
}
Toast.allowMultiple()
let toast1 = null
// 请求拦截器
axios.interceptors.request.use(config => {
    if (config.url !== "/courseprocess/update") {
        toast1 = Toast.loading({
            message: '请稍等...',
            duration: 0
        })
    }
    config.headers = {
        'Authorization': 'Bearer ' + localStorage.getItem('token') || ''
    }
    return config
}, error => {
    return Promise.reject(error)
})

// 返回结果拦截器
axios.interceptors.response.use(res => {
    Toast.clear(toast1)
    return res
}, error => {
    Toast.clear(toast1)
    return Promise.reject(error)
})

export default axios
