import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import {Toast} from 'vant';
// import store from "./store/page";

Vue.use(Toast)
Vue.use(Router)

const router = new Router({
    routes: [
        {
            path: '',
            redirect: '/home'
        },
        {
            path: '/home',
            component: Home,
            children: [
                {
                    path: '',
                    redirect: '/home/index'
                },
                {
                    path: 'index',
                    name: '首页',
                    component: () => import('./views/index.vue')
                },
                {
                    path: 'we',
                    name: '我的',
                    component: () => import('./views/we.vue')
                },
                {
                    path: 'study',
                    name: '课程',
                    component: () => import('./views/study.vue')
                },
                {
                    path: 'message',
                    name: '消息',
                    component: () => import('./views/message.vue')
                }
            ]
        },
        {
            path: '/login',
            name: '登录',
            component: () => import('./views/login.vue')
        },
        {
            path: '/sign-check',
            name: '注册选择',
            component: () => import('./views/sign-check.vue')
        },
        {
            path: '/test',
            name: '在线考试',
            component: () => import('./views/online-test.vue')
        },
        {
            path: '/examplan',
            name: '考试安排',
            component: () => import('./views/examplan.vue')
        },
        {
            path: '/my-test',
            name: '我的考试',
            component: () => import('./views/my-test.vue')
        },
        {
            path: '/we-student',
            name: '我的学员',
            component: () => import('./views/we-student.vue')
        },
        {
            path: '/test-detail',
            name: '考试详情',
            component: () => import('./views/test-detail.vue')
        },
        {
            path: '/test-submit',
            name: '考试提交',
            component: () => import('./views/test-submit.vue')
        },
        {
            path: '/test-add',
            name: '添加考试安排',
            component: () => import('./views/test-add.vue')
        },
        {
            path: '/workload',
            name: '工作量',
            component: () => import('./views/workload.vue')
        },
        {
            path: '/into-family-list',
            name: '入科报到',
            component: () => import('./views/into-family-list.vue')
        },
        {
            path: '/into-family-confirm',
            name: '入科详情',
            component: () => import('./views/into-family-confirm.vue')
        },
        {
            path: '/out-family-confirm',
            name: '申请填写',
            component: () => import('./views/out-family-confirm.vue')
        },
        {
            path: '/out-family-list',
            name: '出科申请',
            component: () => import('./views/out-family-list.vue')
        },
        {
            path: '/out-family-detail',
            name: '出科详情',
            component: () => import('./views/out-family-detail.vue')
        },
        {
            path: '/activities',
            name: '教学活动',
            component: () => import('./views/activities.vue')
        },
        {
            path: '/activities/:id',
            name: '入科教育',
            component: () => import('./views/activities.vue')
        },
        {
            path: '/activities-add',
            name: '添加活动',
            component: () => import('./views/activities-add.vue')
        },
        {
            path: '/workload-add',
            name: '添加工作量',
            component: () => import('./views/workload-add.vue')
        },
        {
            path: '/workload-clinical',
            name: '添加临床工作量',
            component: () => import('./views/workload-clinical.vue')
        },
        {
            path: '/workload-clinical-add',
            name: '添加临床工作量详情',
            component: () => import('./views/workload-clinical-add.vue')
        },
        {
            path: '/activities-sign',
            name: '活动签到',
            component: () => import('./views/activities-sign.vue')
        },
        {
            path: '/activities-record',
            name: '活动记录',
            component: () => import('./views/activities-record.vue')
        },
        {
            path: '/activities-write',
            name: '填写记录',
            component: () => import('./views/activities-write.vue')
        },
        {
            path: '/activities-detail',
            name: '参与人员',
            component: () => import('./views/activities-detail.vue')
        },
        {
            path: '/scan',
            name: '扫描二维码',
            component: () => import('./views/scan.vue')
        },
        {
            path: '/graduation',
            name: '结业管理',
            component: () => import('./views/graduation.vue')
        },
        {
            path: '/graduation-add',
            name: '结业申请',
            component: () => import('./views/graduation-add.vue')
        },
        {
            path: '/graduation-detail',
            name: '详情',
            component: () => import('./views/graduation-detail.vue')
        },
        {
            path: '/graduation-process',
            name: '审核',
            component: () => import('./views/graduation-process.vue')
        },
        {
            path: '/three-mouths',
            name: '入科三个月考核',
            component: () => import('./views/three-mouths.vue')
        },
        {
            path: '/three-mouths-add',
            name: '考核申请',
            component: () => import('./views/three-mouths-add.vue')
        },
        {
            path: '/three-mouths-detail',
            name: '考核详情',
            component: () => import('./views/three-mouths-detail.vue')
        },
        {
            path: '/three-mouths-process',
            name: '考核审核',
            component: () => import('./views/three-mouths-process.vue')
        },
        {
            path: '/leave-check',
            name: '请销假选择',
            component: () => import('./views/leave-check.vue')
        },
        {
            path: '/out-family-check',
            name: '轮转管理',
            component: () => import('./views/out-family-check.vue')
        },
        {
            path: '/praise',
            name: '表扬',
            component: () => import('./views/praise.vue')
        },
        {
            path: '/praise-add',
            name: '表扬添加',
            component: () => import('./views/praise-add.vue')
        },
        {
            path: '/praise-detail',
            name: '表扬详情',
            component: () => import('./views/praise-detail.vue')
        },
        {
            path: '/leave',
            name: '请假列表',
            component: () => import('./views/leave.vue')
        },
        {
            path: '/leave-bin',
            name: '销假列表',
            component: () => import('./views/leave-bin.vue')
        },
        {
            path: '/leave-add',
            name: '请假申请',
            component: () => import('./views/leave-add.vue')
        },
        {
            path: '/leave-detail',
            name: '请假详情',
            component: () => import('./views/leave-detail.vue')
        },
        {
            path: '/leave-binform',
            name: '销假申请',
            component: () => import('./views/leave-binform.vue')
        },
        {
            path: '/paper',
            name: '倒计时',
            component: () => import('./views/paper.vue')
        },
        {
            path: '/about',
            name: '关于我们',
            component: () => import('./views/About.vue')
        },
        {
            path: '/news',
            name: '新闻详情',
            component: () => import('./views/news.vue')
        },
        {
            path: '/we-role',
            name: '角色选择',
            component: () => import('./views/we-role.vue')
        },
        {
            path: '/we-rotary',
            name: '轮转信息',
            component: () => import('./views/we-rotary.vue')
        },
        {
            path: '/we-changePassword',
            name: '修改密码',
            component: () => import('./views/we-changePassword.vue')
        },
        {
            path: '/course',
            name: 'course',
            component: () => import('./views/course.vue')
        },
        {
            path: '/baiMap',
            name: 'baiMap',
            component: () => import('./views/baiMap.vue')
        },
        {
            path: '/questionnaire',
            name: '问卷列表',
            component: () => import('./views/questionnaire.vue')
        },
        {
            path: '/questionnaire-answer-detail',
            name: '问卷填写结果',
            component: () => import('./views/questionnaire-answer-detail.vue')
        },
        {
            path: '/questionnaire-evaluate',
            name: '评价查看',
            component: () => import('./views/questionnaire-evaluate.vue')
        },
        {
            path: '/questionnaire-evaluate-detail',
            name: '评价详情',
            component: () => import('./views/questionnaire-evaluate-detail.vue')
        },
        {
            path: '/questionnaire-check',
            name: '反馈选择',
            component: () => import('./views/questionnaire-check.vue')
        },
        {
            path: '/message-list',
            name: '消息列表',
            component: () => import('./views/message-list.vue')
        },
        {
            path: '/pre-service',
            name: '岗前培训',
            component: () => import('./views/pre-service.vue')
        },
        {
            path: '/pre-service-add',
            name: '岗前培训安排',
            component: () => import('./views/pre-service-add.vue')
        },
        {
            path: '/pre-service-detail',
            name: '岗前培训详情',
            component: () => import('./views/pre-service-detail.vue')
        },
        {
            path: '/study-detail',
            name: '课程详情',
            component: () => import('./views/study-detail.vue')
        },
        {
            path: '/study-play',
            name: '在线学习',
            component: () => import('./views/study-play.vue')
        },
        {
            path: '/message-detail',
            name: '消息详情',
            component: () => import('./views/message-detail.vue')
        },
        {
            path: '/download-page',
            name: '下载页面',
            component: () => import('./views/download-page.vue')
        },
        {
            path: '/upload-page',
            name: '上传页面',
            component: () => import('./views/upload-page.vue')
        },
        {
            path: '/sign-progress',
            name: '报名进度',
            component: () => import('./views/sign-progress.vue')
        },
        {
            path: '/sign-progress-Invoicing',
            name: '开发票',
            component: () => import('./views/sign-progress-Invoicing.vue')
        },
        {
            path: '/sign-progress-refund',
            name: '退款',
            component: () => import('./views/sign-progress-refund.vue')
        },
        {
            path: '/sign-phone',
            name: '报名',
            component: () => import('./views/sign-phone.vue')
        },
        {
            path: '/sign-write-tab',
            name: '专业科室信息',
            component: () => import('./views/sign-write-tab.vue')
        },
        {
            path: '/sign-write-info',
            name: '个人信息',
            component: () => import('./views/sign-write-info.vue')
        },
        {
            path: '/sign-write-contact',
            name: '联系方式',
            component: () => import('./views/sign-write-contact.vue')
        },
        {
            path: '/sign-write-certificate',
            name: '相关证书',
            component: () => import('./views/sign-write-certificate.vue')
        },
        {
            path: '/sign-write-education',
            name: '学历信息',
            component: () => import('./views/sign-write-education.vue')
        },
        {
            path: '/sign-write-education-add',
            name: '学历添加',
            component: () => import('./views/sign-write-education-add.vue')
        },
        {
            path: '/pay',
            name: '在线缴费',
            component: () => import('./views/pay.vue')
        },
        {
            path: '/sign-write-work',
            name: '工作信息',
            component: () => import('./views/sign-write-work.vue')
        },
        {
            path: '/sign-write-work-add',
            name: '工作添加',
            component: () => import('./views/sign-write-work-add.vue')
        },
        {
            path: '/sign-write-company',
            name: '选送单位信息',
            component: () => import('./views/sign-write-company.vue')
        },
        {
            path: '/sign-write-application',
            name: '进修申请表',
            component: () => import('./views/sign-write-application.vue')
        },
        {
            path: '/m-pdf',
            name: '预览',
            component: () => import('./components/m-pdf.vue')
        },
        {
            path: '/approval-detail',
            name: '审批',
            component: () => import('./views/approval-detail.vue')
        },
        {
            path: '/file-list',
            name: '附件',
            component: () => import('./views/file-list.vue')
        },
        {
            path: '/department-choice',
            name: '部门初选',
            component: () => import('./views/department-choice.vue')
        },
        {
            path: '/section-choice',
            name: '科室遴选',
            component: () => import('./views/section-choice.vue')
        },
        {
            path: '/tutor-choice',
            name: '导师遴选',
            component: () => import('./views/tutor-choice.vue')
        },
        {
            path: '/tutor-distribution',
            name: '导师分配',
            component: () => import('./views/tutor-distribution.vue')
        },
        {
            path: '/tutor-distribution-confirm',
            name: '导师分配确认',
            component: () => import('./views/tutor-distribution-confirm.vue')
        },
        {
            path: '/backbone-teachers',
            name: '骨干教师',
            component: () => import('./views/backbone-teachers.vue')
        },
        {
            path: '/backbone-student',
            name: '培训小结',
            component: () => import('./views/backbone-student.vue')
        },
        {
            path: '/backbone-time',
            name: '培训阶段时间安排',
            component: () => import('./views/backbone-time.vue')
        },
        {
            path: '/backbone-time-add',
            name: '添加阶段时间',
            component: () => import('./views/backbone-time-add.vue')
        },
        {
            path: '/backbone-teachers-add',
            name: '添加计划',
            component: () => import('./views/backbone-teachers-add.vue')
        },
        {
            path: '/backbone-student-process',
            name: '审核小结',
            component: () => import('./views/backbone-student-process.vue')
        },
        {
            path: '/backbone-student-add',
            name: '阶段小结',
            component: () => import('./views/backbone-student-add.vue')
        },
        {
            path: '/student-info',
            name: '结业随访',
            component: () => import('./views/student-info.vue')
        },
        {
            path: '/department-student-detail',
            name: '学员详情',
            component: () => import('./views/department-student-detail.vue')
        },
        {
            path: '/warning',
            name: '注册须知',
            component: () => import('./views/warning.vue')
        },
        {
            path: '/teachers',
            name: '带教老师',
            component: () => import('./views/teachers.vue')
        },
        {
            path: '/teachers-add',
            name: '带教老师申请',
            component: () => import('./views/teachers-add.vue')
        },
        {
            path: '/teachers-detail',
            name: 'teachersDetail',
            component: () => import('./views/teachers-detail.vue')
        },
        {
            path: '/teachers-process',
            name: 'teachersProcess',
            component: () => import('./views/teachers-process.vue')
        },
        {
            path: '/teachers-education',
            name: 'education',
            component: () => import('./views/teachers-education.vue')
        },
        {
            path: '/teachers-education-add',
            name: 'educationAdd',
            component: () => import('./views/teachers-education-add.vue')
        },
        {
            path: '/teachers-certificate',
            name: 'certificate',
            component: () => import('./views/teachers-certificate.vue')
        },
        {
            path: '/teachers-check',
            name: '师资管理选择',
            component: () => import('./views/teachers-check.vue')
        },
        {
            path: '/teachers-nursing',
            name: '护理师资审核',
            component: () => import('./views/teachers-nursing.vue')
        },
        {
            path: '/teachers-nursing-add',
            name: '护理师资审核添加',
            component: () => import('./views/teachers-nursing-add.vue')
        },
        {
            path: '/disease-species-check',
            name: '病种诊断管理',
            component: () => import('./views/disease-species-check.vue')
        },
        {
            path: '/disease-species',
            name: '病种管理',
            component: () => import('./views/disease-species.vue')
        },
        {
            path: '/disease-species-add',
            name: '病种添加',
            component: () => import('./views/disease-species-add.vue')
        },
        {
            path: '/disease-species-detail',
            name: '病种详情',
            component: () => import('./views/disease-species-detail.vue')
        },
        {
            path: '/student-status',
            name: '学籍管理',
            component: () => import('./views/student-status.vue')
        },
        {
            path: '/student-status-detail',
            name: '学籍详情',
            component: () => import('./views/student-status-detail.vue')
        },
        {
            path: '/data-upload-check',
            name: '资料管理',
            component: () => import('./views/data-upload-check.vue')
        },
        {
            path: '/data-upload-add',
            name: '资料管理',
            component: () => import('./views/data-upload-add.vue')
        },
        {
            path: '/data-upload',
            name: '资料查看',
            component: () => import('./views/data-upload.vue')
        },
        {
            path: '/try',
            name: '测试',
            component: () => import('./views/try.vue')
        },
    ]
})
//获取原型对象上的push函数
const originalPush = Router.prototype.push
//修改原型对象中的push方法
Router.prototype.push = function push(location) {
    // return originalPush.call(this, location).catch(err => err)
    return originalPush.call(this, location)
}
let loading = null
router.beforeEach((to, from, next) => {
    loading = Toast.loading({
        message: '加载中...',
        forbidClick: true,
    });
    let isLogin = localStorage.getItem('isLogin') || '0'
    let constraintFlag = localStorage.getItem('constraintFlag') || ''

    if (
        isLogin === '0'
        && to.path !== '/login'
        && to.path !== '/pay'
        && to.path !== '/activities-sign'
        && to.path !== '/sign-check'
        && to.path !== '/download-page'
        && to.path !== '/sign-progress'
        && to.path !== '/sign-progress-Invoicing'
        && to.path !== '/sign-progress-refund'
        && to.path !== '/sign-phone'
        && to.path !== '/sign-write-tab'
        && to.path !== '/sign-write-info'
        && to.path !== '/sign-write-contact'
        && to.path !== '/sign-write-certificate'
        && to.path !== '/sign-write-education'
        && to.path !== '/sign-write-education-add'
        && to.path !== '/sign-write-work'
        && to.path !== '/sign-write-work-add'
        && to.path !== '/sign-write-company'
        && to.path !== '/sign-write-application'
        && to.path !== '/download-page'
        && to.path !== '/upload-page'
        && to.path !== '/warning'
        && to.path !== '/try'
    ) {
        Toast.loading({
            message: '请先登录!!',
            forbidClick: true,
        });
        next({
            path: 'login'
        })
        if (constraintFlag !== 'false') {
            localStorage.setItem('isLogin', '');
            localStorage.setItem('token', '');
            sessionStorage.clear()
            next({
                path: 'login'
            })
        }
    } else {
        next()
    }
})
router.afterEach(() => {
    loading.clear()
})
export default router

