const config = {
    refUrl: "http://127.0.0.1:8080", //crud服务
    poolObj: {
        user: 'postgres', host: '127.0.0.1', database: 'postgres', password: '1234', port: 5433
    }
}
module.exports = config;

// const refUrl = "http://zyk.mrtcloud.com:8888";
// const refUrl = "http://127.0.0.1:8080";