module.exports = {
  // devServer.proxy适用于本地开发使用，
  // 生成环境请用第三方代理软件，如nginx。
  productionSourceMap: false,
  devServer: {
    port: 8080, // 本机端口号
    host: 'localhost', // 本机主机名
    https: false, // 协议
    open: true, // 启动服务器时自动打开浏览器访问
    proxy: {
      '/attachs': {
        target: 'http://localhost:3011',
        changOrigin: true // 开启代理
      },
      '/public': {
        target: 'http://localhost:3011',
        changOrigin: true // 开启代理
      }
    }
  }
}
