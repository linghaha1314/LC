import axios from 'axios'
import Cookies from 'js-cookie'
import router from '@/router'
import { ElMessage } from 'element-plus'

const service = axios.create({
  baseURL: process.env.VUE_APP_BASE_URL,
  timeout: 20000
})
// request interceptor
service.interceptors.request.use(
  (config) => {
    const token = Cookies.get('manage-token')
    if (config.headers!.Authorization === 'true' && token) {
      config.headers!.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

service.interceptors.response.use(
  (response) => {
    const res: any = response.data
    if (res.status === 401) {
      ElMessage({
        message: '登录超时，请重新登录',
        type: 'error',
        duration: 2 * 1000
      })
      router.push({ path: '/manage/login' }).then()
    }
    if (!res.success) {
      return Promise.reject(new Error(res.msg || 'Error'))
    } else {
      return res
    }
  },
  (error) => {
    return Promise.reject(error)
  }
)

export default service
