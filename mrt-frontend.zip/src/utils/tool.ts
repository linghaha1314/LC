import { Action, ElLoading, ElMessage, ElMessageBox } from 'element-plus'
import { Observable } from 'rxjs'
import service from '@/utils/manage-request'
import serviceClient from '@/utils/client-request'
import { read, utils, write } from 'xlsx'
import CryptoJS from 'crypto-js'

function post(url: string, data = {}, authFlag = true): Promise<any> {
  return new Promise((resolve, reject) => {
    service
      .post(url, data, {
        headers: { Authorization: String(authFlag) },
        timeout: 200 * 1000
      })
      .then(
        // service.post(url, data).then(
        (response) => {
          resolve(response)
        },
        (err) => {
          ElMessage({
            message: err,
            type: 'error',
            duration: 2 * 1000
          })
          // 报错一定要关闭loading
          removeLoading()
          reject(err)
        }
      )
  })
}

function get(url: string, params = {}, authFlag = true): Promise<any> {
  return new Promise((resolve, reject) => {
    service
      .get(url, {
        headers: { Authorization: String(authFlag) },
        params: params
      })
      .then((response) => {
        resolve(response)
      })
      .catch((err) => {
        reject(err)
        removeLoading()
      })
  })
}

function reverseData(data: string, fromSymbol = ',', toSymbol = '-') {
  const arr = data.split(fromSymbol)
  return arr.reverse().join(toSymbol)
}

function clientPost(url: string, data = {}): Promise<any> {
  return new Promise((resolve, reject) => {
    serviceClient.post(url, data, {
      timeout: 200 * 1000
    }).then(
      (response) => {
        resolve(response)
      },
      (err) => {
        reject(err)
      }
    )
  })
}

function clientGet(url: string, params = {}): Promise<any> {
  return new Promise((resolve, reject) => {
    serviceClient
      .get(url, {
        timeout: 200 * 1000,
        params: params
      })
      .then((response) => {
        resolve(response)
      })
      .catch((err) => {
        reject(err)
      })
  })
}

/**
 * @name msg
 * @desc 成功弹窗显示;错误弹窗，需要传入type=error
 * */
function msg(msg: string, type: any = 'success'): void {
  ElMessage({
    message: msg,
    type,
    duration: 2 * 1000
  })
}

function msgError(msg: string, duration = 2000): void {
  ElMessage.error({
    message: msg,
    duration
  })
}

function confirm(title = '温馨提示', msg = '确定删除？'): Promise<any> {
  return new Promise((resolve) => {
    ElMessageBox.confirm(msg, title, {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
      .then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
  })
}

/* upload验证 */
function alterConfirm(msg = '数据已存在!', title = '温馨提示', btns?) {
  ElMessageBox.alert(msg, title, {
    confirmButtonText: '覆盖',
    cancelButtonText: '跳过',
    callback: (action: Action) => {
      ElMessage({
        type: 'info',
        message: `action: ${action}`
      })
    }
  }).then()
}

async function getValueObjByHttp(path = '/major/getList', type = 'obj', params = {}, key = 'id', label = 'name') {
  const list = (await tools.get(path, params)).list || []
  const obj: any = {}
  list.forEach(res => {
    obj[res[label]] = res[key]
  })
  return {
    obj,
    list
  }
}

/**
 * @name formatTime
 * @desc 时间格式函数
 * * @param {Date | string} date -不传，默认当前时间；
 * * @param {string} format -不传，默认YY-MM-DD格式,传入举例:YY-MM-DD hh:mm:ss;YY年MM月DD日等等
 * */
function formatTime(date?: string | Date, format = 'YY-MM-DD'): string {
  if (typeof date === 'string') {
    date = date.replace(/\s+/, 'T')
  }
  date = date ? new Date(date) : new Date()
  const dateObj: any = {}
  dateObj.YY = date.getFullYear()
  dateObj.MM = date.getMonth() + 1
  dateObj.DD = date.getDate()
  dateObj.hh = date.getHours()
  dateObj.mm = date.getMinutes()
  dateObj.ss = date.getSeconds()
  const arr = aryJoinAry(
    format.match(/[a-zA-Z]{2}/g),
    format.match(/[^a-zA-Z]/g) || []
  )
  let result: any = ''
  arr.forEach((res) => {
    result += /[a-zA-Z]/g.test(res) ? addZero(dateObj[res]) : res
  })
  return result
}

function addZero(num) {
  if (num > 9) {
    return num
  } else {
    return `0${num}`
  }
}

function aryJoinAry(ary, ary2) {
  const itemAry: any = []
  let minLength
  if (ary.length > ary2.length) {
    minLength = ary2.length
  } else {
    minLength = ary.length
  }
  // eslint-disable-next-line prefer-rest-params
  const longAry =
    // eslint-disable-next-line prefer-rest-params
    arguments[0].length > arguments[1].length ? arguments[0] : arguments[1]
  for (let i = 0; i < minLength; i++) {
    itemAry.push(ary[i])
    itemAry.push(ary2[i])
  }
  return itemAry.concat(longAry.slice(minLength))
}

export const loadScript = (js: string): Observable<boolean> => {
  return new Observable((subscriber) => {
    const id = 'js' + js.replace(/\./g, '').replace(/\//g, '_')
    if (document.getElementById(id) != null) {
      subscriber.next(true)
      return
    }
    const node = document.createElement('script')
    node.id = id
    node.src = js
    node.type = 'text/javascript'
    document.getElementsByTagName('head')[0].appendChild(node).onload = () => {
      subscriber.next(true)
    }
  })
}

/**
 * @name deleteById
 * @desc 默认删除接口，传入删除得表名和id
 * */
function deleteById(
  tableName: string,
  value: string,
  pageParams: any,
  idKey = 'id',
  url?
): Promise<boolean> {
  return new Promise((resolve) => {
    confirm().then((r) => {
      if (r) {
        const loading = tools.showLoading('删除中...')
        post(url || `/${tableName}/deleteById`, { [idKey]: value }).then(
          (res) => {
            if (res.success) {
              msg(res.msg)
              pageParams.refresh = true
              resolve(true)
            } else {
              msgError(res.msg)
              resolve(false)
            }
            tools.closeLoading(loading)
          }
        )
      }
    })
  })
}

/**
 * @name delMultiple
 * @desc 根据id批量删除，传入section
 * */
function delMultiple(
  tableName: string,
  selection: any,
  pageParams: any,
  message = '请至少选择一条数据'
): Promise<boolean> {
  return new Promise((resolve) => {
    confirm().then((r) => {
      if (r) {
        let str = ''
        if (typeof selection !== 'string') {
          if (selection.length === 0) {
            tools.msgError(message)
            return
          }
          selection.forEach((res, index) => {
            str += index === selection.length - 1 ? res.id : res.id + ','
          })
        } else {
          str = selection
        }
        const loading = tools.showLoading('删除中...')
        tools.post(`/${tableName}/deleteMultiple`, { id: str }).then((res) => {
          tools.closeLoading(loading)
          if (res.success) {
            msg(res.msg)
            pageParams.refresh = true
            resolve(true)
          } else {
            msgError(res.msg)
            resolve(false)
          }
        })
      }
    })
  })
}

/**
 * @name deleteMultiCondition
 * @desc 根据多条件删除多条数据,可以替代deleteById
 * @param tableName 表名
 * @param data {type:'or',id:'xx',parentId:'xx'}条件对象,type不传默认为or
 * @param pageParams 主要是修改表单的refresh，删除后刷新列表
 * @param message 消息提示文本
 * */
function deleteMultiCondition(
  tableName: string,
  data: any,
  pageParams: any,
  message = '请至少选择一条数据'
): Promise<boolean> {
  return new Promise((resolve) => {
    confirm().then((r) => {
      if (r) {
        const loading = tools.showLoading('删除中...')
        tools.post(`/${tableName}/deleteMultiCondition`, data).then((res) => {
          tools.closeLoading(loading)
          if (res.success) {
            msg(res.msg)
            pageParams.refresh = true
            resolve(true)
          } else {
            msgError(res.msg)
            resolve(false)
          }
        })
      }
    })
  })
}

/**
 * @name openDrawer
 * @desc 抽屉新增或者修改执行;
 * */
function openDrawer(drawer, isEdit?, formList?, val?) {
  if (isEdit) {
    drawer.isEdit = true
    formList.forEach((res) => {
      res.value = val[res.key]
    })
  } else {
    drawer.isEdit = false
  }
  drawer.isDrawer = true
}

function imgError(src, val?) {
  // console.log('===>>>？？？src', src, val)
  if (val) {
    // let img: any = event.srcElement
    // img.src = require('../assets/images/client/err-default.jpg')
    // img.onerror = null //防止闪图
  }
}

// 解构list
function deconstructionList(list: any[]): any[] {
  let result: any = []
  list.forEach((res) => {
    if (res.children && res.children.length > 0) {
      result = result.concat(deconstructionList(res.children))
    } else {
      result.push(res)
    }
  })
  return result
}

function numberToLetter(value: number): string {
  return String.fromCharCode(64 + parseInt(String(value), 10))
}

function upload(
  type = 'file',
  defineProps: any = {},
  tableName?: string,
  pageParams: any = {},
  sections?: any
): any {
  const input = document.createElement('input')
  input.type = type === 'import' ? 'file' : type
  return new Promise((resolve) => {
    input.onchange = (e: any) => {
      const file = e.target.files[0]
      if (type === 'import') {
        const types = ['xlsx', 'xls']
        const arr = file.name.split('.')
        // 判断文件是否为excel文件
        if (!types.find((item) => item === arr[arr.length - 1])) {
          alert('请选择正确的文件类型')
          return
        }
        const reader = new FileReader()
        // 启动函数
        reader.readAsBinaryString(file)
        reader.onload = (e) => {
          // workbook存放excel的所有基本信息
          const workbook = read(e.target?.result, {
            type: 'binary',
            cellDates: true
          })
          // 定义sheetList中存放excel表格的sheet表，就是最下方的tab
          const sheetList = workbook.SheetNames
          // 读取文件内容，（第一个sheet里的内容）
          // range：设置从第几行开始读取内容
          const json = utils.sheet_to_json(workbook.Sheets[sheetList[0]], {
            range: 0
          })
          const list: any = []
          let errList: any = []
          json.forEach((res: any) => {
            const obj: any = Object.keys(defineProps).reduce((newData, key) => {
              const newKey = defineProps[key] || key
              newData[newKey] = res[key]
              return newData
            }, {})
            console.log('0000', defineProps, obj)
            if (obj.username) {
              obj.username = obj.username && obj.username.toString()
            }
            if (obj.jobNum) {
              obj.jobNum = obj.jobNum && obj.jobNum.toString()
            }
            if (obj.mobile) {
              obj.mobile = obj.mobile && obj.mobile.toString()
            }
            if (obj.parentId != null && sections[obj.parentId] == null) {
              obj.err = `未找到[${obj.parentId}]`
              errList.push(obj)
              return
            } else {
              obj.parentId = sections[obj.parentId]
            }
            list.push(obj)
          })
          const loading = ElLoading.service({
            lock: true,
            text: '正在导入'
          })
          tools.post(`/${tableName}/import`, list).then((r) => {
            loading.close()
            tools.msg(r.msg)
            pageParams.refresh = true
          }).catch(() => {
            tools.msgError('请按模板内容导入数据!')
          })
          errList = [...new Set(errList)]
          if (errList.length > 0) {
            writeFile(
              errList,
              {
                ...defineProps,
                错误信息: 'err'
              },
              'excel'
            )
          }
        }
      } else {
        const formData = new FormData()
        formData.append('file', file)
        tools.post('/public/upload', formData).then((r) => {
          resolve(r.data)
        })
      }
    }
    input.click()
  })
}

function importData(defineProps): Promise<any> {
  const input = document.createElement('input')
  input.type = 'file'
  return new Promise((resolve) => {
    input.onchange = (e: any) => {
      const loading = tools.showLoading()
      const file = e.target.files[0]
      const types = ['xlsx', 'xls']
      const arr = file.name.split('.')
      // 判断文件是否为excel文件
      if (!types.find((item) => item === arr[arr.length - 1])) {
        alert('请选择正确的文件类型')
        return
      }
      const reader = new FileReader()
      // 启动函数
      reader.readAsBinaryString(file)
      reader.onload = (e) => {
        const workbook = read(e.target?.result, {
          type: 'binary',
          cellDates: true
        })
        const sheetList = workbook.SheetNames
        const json = utils.sheet_to_json(workbook.Sheets[sheetList[0]], {
          range: 0
        })
        const list: any = []
        json.forEach((res: any) => {
          const obj: any = Object.keys(defineProps).reduce((newData, key) => {
            const newKey = defineProps[key] || key
            newData[newKey] = res[key]
            tools.closeLoading(loading)
            return newData
          }, {})
          list.push(obj)
        })
        resolve(list)
      }
    }
    input.click()
  })
}

// 找寻比对数组子元素
function findChildByIds(idArr, arr: any = [], len = 0) {
  const itemArr = arr.filter(rr => rr.id === idArr[len])
  if (len === idArr.length - 1) {
    return itemArr[0]
  } else {
    len++
    return findChildByIds(idArr, itemArr[0].children, len)
  }
}

// 下载文件
function writeFile(data, defineProps: any = {}, type = 'excel') {
  const arr: any = []
  data.forEach((res) => {
    const obj: any = {}
    for (const key in defineProps) {
      obj[key] = res[defineProps[`${key}`]]
    }
    arr.push(obj)
  })
  const sheet1 = utils.json_to_sheet(arr)
  // 创建一个新的空的workbook
  const wb = utils.book_new()
  utils.book_append_sheet(wb, sheet1, '部门统计')
  const workbookBlob = workbook2blob(wb)
  const blob = new Blob([workbookBlob], {
    type: `application/${type};charset=UTF-8` // 表示下载文档为pdf，如果是word则设置为msword，excel为excel
  })
  // 这里就是创建一个a标签，等下用来模拟点击事件
  const a = document.createElement('a')
  // 兼容webkix浏览器，处理webkit浏览器中href自动添加blob前缀，默认在浏览器打开而不是下载
  const URL = window.URL || window.webkitURL
  // 根据解析后的blob对象创建URL 对象
  const href = URL.createObjectURL(blob)
  // 下载链接
  a.href = href
  // 下载文件名,如果后端没有返回，可以自己写a.download = '文件.pdf'
  a.download = '文件.xlsx'
  document.body.appendChild(a)
  // 点击a标签，进行下载
  a.click()
  // 收尾工作，在内存中移除URL 对象
  document.body.removeChild(a)
  window.URL.revokeObjectURL(href)
}

// 导出
function exportExcel(arr, name = '文件', type = 'excel') {
  const sheet1 = utils.json_to_sheet(arr)
  // 创建一个新的空的workbook
  const wb = utils.book_new()
  utils.book_append_sheet(wb, sheet1, '部门统计')
  const workbookBlob = workbook2blob(wb)
  const blob = new Blob([workbookBlob], {
    type: `application/${type};charset=UTF-8` // 表示下载文档为pdf，如果是word则设置为msword，excel为excel
  })
  // 这里就是创建一个a标签，等下用来模拟点击事件
  const a = document.createElement('a')
  // 兼容webkix浏览器，处理webkit浏览器中href自动添加blob前缀，默认在浏览器打开而不是下载
  const URL = window.URL || window.webkitURL
  // 根据解析后的blob对象创建URL 对象
  const href = URL.createObjectURL(blob)
  // 下载链接
  a.href = href
  // 下载文件名,如果后端没有返回，可以自己写a.download = '文件.pdf'
  a.download = name + '.xlsx'
  document.body.appendChild(a)
  // 点击a标签，进行下载
  a.click()
  // 收尾工作，在内存中移除URL 对象
  document.body.removeChild(a)
  window.URL.revokeObjectURL(href)
}

// a标签下载
function aDown(downloadText = '文件.xlsx', hrefText = '') {
  const a = document.createElement('a')
  a.href = hrefText
  a.download = downloadText
  document.body.appendChild(a)
  a.click()
}

function workbook2blob(workbook) {
  const wbout = write(workbook, {
    bookType: 'xlsx',
    type: 'binary'
  })

  // 将字符串转ArrayBuffer
  function s2ab(s) {
    const buf = new ArrayBuffer(s.length)
    const view = new Uint8Array(buf)
    for (let i = 0; i !== s.length; ++i) view[i] = s.charCodeAt(i) & 0xff
    return buf
  }

  const buf = s2ab(wbout)
  const blob = new Blob([buf], {
    type: 'application/octet-stream'
  })
  return blob
}

function getDataTree(parentList, childList) {
  for (let i = 0; i < parentList.length; i++) {
    parentList[i].children = []
    for (let j = 0; j < childList.length; j++) {
      if (parentList[i].id === childList[j].parentId) {
        childList[j].parentName = parentList[i].name
        childList[j].hasParent = true
        parentList[i].children.push(childList[j])
      }
    }
  }
  childList = childList.filter((res) => !res.hasParent)
  // 一轮结束后，childList还存在，就再一次调用这个方法
  if (childList.length > 0) {
    for (let i = 0; i < parentList.length; i++) {
      getDataTree(parentList[i].children, childList)
    }
  }
}

// 路由跳转
function go(to: string, isTofileView = false) {
  if (isTofileView) {
    window.open(`/#/client/fileView?path=${to}`, '_blank')
    return
  }
  location.href = '/#' + to
}

async function pptConvertMp4(val) {
  const postfixArr = val.replace(/\?(.*)/, '').split('.')
  const postfix = postfixArr[postfixArr.length - 1]
  const videoRegExp = new RegExp(/(mp4|m3u8|mkv|avi|flv|mov)$/)
  const audioRegExp = new RegExp(/mp3$/)
  if (!videoRegExp.test(postfix) && !audioRegExp.test(postfix)) {
    try {
      const result = await tools.clientGet('/convertVideo', { url: val })
      return result?.url || val
    } catch (e) {
      console.error(e)
      return val
    }
  }
}

const isApply = (role) => {
  const arr = JSON.parse(
    sessionStorage.getItem('manageUserInfo') as string
  ).roles
  if (arr.length > 0) {
    let bol = false
    arr.forEach((item) => {
      role.forEach((ite) => {
        if (item.roleData.code === ite) {
          bol = true
        }
      })
    })
    return bol
  }
  return false
}

/**
 * @name getFileName
 * @desc 截取文件后缀日期，显示正确的文件名;
 * @param path 路径
 * */
const getFileName = (path) => {
  return path ? path.replace(/\/attachs\//, '').replace(/-[0-9]{14}/, '') : ''
}

const handleClose = (done: () => void) => {
  ElMessageBox.confirm('填写将被清空, 确认关闭么?', '提示: ', {
    confirmButtonText: '关闭',
    cancelButtonText: '取消',
    type: 'warning',
    center: true
  })
    .then(() => {
      done()
    })
    .catch(() => {
      // catch error
    })
}

function showLoading(text = '加载中...', background = 'rgba(0, 0, 0, 0.4)') {
  const loading = ElLoading.service({
    lock: true,
    text: text,
    background: background
  })
  return loading
}

// 关闭对应的loading
function closeLoading(loading) {
  loading.close()
}

// 彻底删除loading节点
function removeLoading() {
  const dom: any = document.querySelector('.el-loading-mask')
  if (dom) {
    dom.remove()
  }
}

function hms(time, studyTime = false) {
  const hour = parseInt(String(time / 3600))
  const minute = parseInt(String((time / 60) % 60))
  const second = Math.ceil(time % 60)
  if (studyTime) {
    return (hour ? hour + '小时' : '') + (minute ? minute + '分钟' : '') || 0
  }
  return addZero(hour) + ':' + addZero(minute) + ':' + addZero(second)
}

const childNo = (arr, target, cb?) => {
  arr.forEach((item) => {
    // console.log(item, 887)
    if (item.children && item.children.length !== 0) {
      target.push(item)
      childNo(item.children, target)
    } else {
      target.push(item)
    }
  })
  if (cb) {
    cb()
  }
}

function convertUrl(url, httpUrl = 'http://source.mrtcloud.com:8888') {
  if (!url) {
    return ''
  }
  const urlBefore = url.indexOf('http') > -1 ? '' : httpUrl
  return urlBefore + url
}

const validationRepeat = (data, label, key, table) => {
  const parma = {}
  parma[key] = data
  tools.post(`/${table}/getDataById`, {
    ...parma
  }).then(res => {
    if (res.data) {
      tools.msgError(label + '重复数据!')
    } else {
      if (data !== '') {
        tools.msg(label + '可以使用!')
      }
    }
  })
}

const tools = {
  post,
  get,
  clientPost,
  clientGet,
  msg,
  writeFile,
  msgError,
  convertUrl,
  getFileName,
  confirm,
  findChildByIds,
  formatTime,
  loadScript,
  deleteById,
  delMultiple,
  go,
  hms,
  upload,
  imgError,
  openDrawer,
  showLoading,
  closeLoading,
  getValueObjByHttp,
  deconstructionList,
  childNo,
  importData,
  removeLoading,
  exportExcel,
  pptConvertMp4,
  deleteMultiCondition,
  numberToLetter,
  isApply,
  aDown,
  handleClose,
  validationRepeat,
  limit: 20,
  props: {
    checkStrictly: true,
    label: 'name',
    value: 'id'
  }
}

export default tools
