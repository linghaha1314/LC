import axios from 'axios'
import Cookies from 'js-cookie'

const serviceClient = axios.create({
  baseURL: process.env.VUE_APP_BASE_URL,
  timeout: 20000
})
// request interceptor
serviceClient.interceptors.request.use(
  (config) => {
    const token = Cookies.get('client-token')
    if (token && config.url !== 'login') {
      config.headers!.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

serviceClient.interceptors.response.use(
  (response) => {
    const res: any = response.data
    if (res.status === 401) {
    }
    return res
    // if (!res.success) {
    //   return Promise.reject(new Error(res.msg || 'Error'))
    // } else {
    //   return res
    // }
  },
  (error) => {
    return Promise.reject(error)
  }
)

export default serviceClient
