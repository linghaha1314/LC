<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<script>
export default {
  data () {
    return {}
  },
  methods: {
    resize () {
      document.body.style.zoom = window.innerWidth / 1920
    }
  }
}
</script>
<style lang="less">
#app {
  height: 100vh;
  width: 100vw;
}

body {
  padding: 0;
  margin: 0;
  overflow: hidden;
}

body::-webkit-scrollbar {
  display: none !important;
}
</style>
