import { createStore } from 'vuex'
import { reactive } from 'vue'
import Cookies from 'js-cookie'
import tools from '@/utils/tool'
import store from '@/store/index'
import ManageRouter from '@/router/manage'
import router from '@/router'

export default createStore({
  state: reactive({
    manageToken: '',
    manageUserInfo:
      JSON.parse(sessionStorage.getItem('manageUserInfo') as string) || {},
    manageMenuList: [],
    manageHistoryList: <any>[],
    currentPath: '', // 获取当前路由的参数
    currentMenuId: null, // 获取当前路由的参数
    openMenuArr: [0],
    checkedNavName: 'home', // 选中的导航
    showLoginDialog: false, // 登录弹窗
    showWriteInfoDialog: false, // 填写个人信息
    clientToken: '',
    clientUserInfo: JSON.parse(
      sessionStorage.getItem('clientUserInfo') as string
    ),
    search: '', // 首页搜索
    isSelectRoleDialog: false
  }),
  mutations: {
    setManageToken (state, n) {
      state.manageToken = n
      Cookies.set('manage-token', n)
    },
    setManageCurrentPath (state, n) {
      state.currentPath = n
    },
    setManageMenuId (state, n) {
      state.currentMenuId = n
    },
    setManageOpenMenuArr (state, n) {
      state.openMenuArr = Array.from(new Set(state.openMenuArr.concat(n)))
    },
    setManageUserInfo (state, n) {
      state.manageUserInfo = n
      sessionStorage.setItem('manageUserInfo', JSON.stringify(n))
      state.manageHistoryList = []
    },
    setManageMenuList (state, n) {
      state.manageMenuList = n
    },
    setIsSelectRoleDialog (state, n) {
      state.isSelectRoleDialog = n
    },
    setManageHistory (state, n) {
      state.manageHistoryList = state.manageHistoryList.filter(
        (res) => res.code !== n.code
      )
      state.manageHistoryList.push(n)
    },
    deleteManageHistory (state, n) {
      state.manageHistoryList = state.manageHistoryList.filter(
        (res) => res.code !== n.code
      )
      // 如果是最后一个标签应该返回404；如果不是最后一个标签，应该跳转到上个页面
      if (state.manageHistoryList.length === 0) {
        state.currentPath = '404'
        state.currentMenuId = null
        router.push('/manage/welcome').then()
      } else {
        state.currentMenuId = (state.manageHistoryList[state.manageHistoryList.length - 1]).id
        state.currentPath = (state.manageHistoryList[state.manageHistoryList.length - 1]).path
        router.push((state.manageHistoryList[state.manageHistoryList.length - 1]).path).then()
      }
    },
    setClientShowLoginDialog (state, n) {
      state.showLoginDialog = n
    },
    setClientWriteInfoDialog (state, n) {
      state.showWriteInfoDialog = n
    },
    setClientUserInfo (state, n) {
      state.clientUserInfo = n
      if (!n) {
        sessionStorage.removeItem('clientUserInfo')
      }
      sessionStorage.setItem('clientUserInfo', JSON.stringify(n))
    },
    setClientToken (state, n) {
      state.clientToken = n
      if (!n) {
        Cookies.remove('client-token')
      }
      Cookies.set('client-token', n)
    },
    setSearch (state, n) {
      state.search = n
    }
  },
  actions: {
    getMenus ({ commit }, data = {}) {
      const loading = tools.showLoading()
      tools
        .post('/roleAuthority/getMenusByRoleId', {
          roleId:
            data?.roleId || (store.state.manageUserInfo.currentRole && store.state.manageUserInfo.currentRole?.roleId) || store.state.manageUserInfo.roles[0]?.roleId || ''
        })
        .then((r) => {
          store.commit('setManageMenuList', r.list)
          // 修改manage.ts里面的路由结构,给路由meta加上属性
          const menus = tools.deconstructionList(r.list)
          // 结构所有的list表单
          menus.forEach((rr) => {
            ManageRouter.children.forEach((res) => {
              if (rr.path === res.path) {
                (res.meta as any).show = true
              }
            })
          })
          tools.closeLoading(loading)
        })
    },
    getClientUserInfo ({ commit }, data) {
      tools.clientGet('getUserInfo', data).then((res) => {
        store.commit('setClientUserInfo', res.data)
        store.commit('setClientShowLoginDialog', false)
      })
    },
    getManageUserInfo ({ commit }, data) {
      return new Promise((resolve, reject) => {
        tools.get('getUserInfo', data).then((res) => {
          if (!res.data.currentRole && res.data.roles.length > 0) {
            tools.post('/api/rest/updateCurrentRole', {
              userId: res.data.id,
              roleId: res.data.roles[0].roleId
            }).then(rr => {
              if (rr.success) {
                store.dispatch('getManageUserInfo', { id: store.state.manageUserInfo.id }).then()
              }
            })
          }
          if (!res.data.currentRole && res.data.roles.length === 0) {
            Cookies.remove('manage-token')
            sessionStorage.removeItem('manageUserInfo')
            resolve(false)
          }
          store.commit('setManageUserInfo', res.data)
          resolve(true)
        })
      })
    }
  },
  modules: {}
})
