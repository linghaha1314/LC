<template>
  <audio-player height="360px"
                v-model:total-time="videoData.totalTime"
                :allowMaxSeek="videoData['maxTime']"
                :isAllowSeek="videoData['isRealCompleted']"
                @getCurrentTime="getCurrentTime"></audio-player>
</template>
<script lang="ts" setup>
import { reactive } from 'vue'
import AudioPlayer from '@/viewsClient/components/block/AudioPlayer.vue'

const videoData = reactive({
  isAudioPlay: true,
  totalTime: 0,
  maxTime: 10,
  isRealCompleted: false
})
</script>
