<template>
  <div class="all-course container">
    <!-- 筛选卡片 -->
    <section v-if="isShowClass" class="category-card-box">
      <el-card class="margin-bottom">
        <ul>
          <span class="nowrap" v-if="currentType?.name">
            {{ currentType.name }}：</span>
          <li v-for="(item, index) of classList" :key="index"
              :class="{ 'checked': currentCheckedId === item.id, 'font-bold': true }"
              @click="changeCurrentChecked(item, index)">
            {{ item.name }}
          </li>
        </ul>
      </el-card>
    </section>
    <section>
      <div class="flex">
        <div style="width: calc(100% - 280px)">
          <el-tabs v-model="searchInfo.sort" class="demo-tabs" @tab-click="handleClick($event)">
            <el-tab-pane class="flex flex-wrap align-center" label="全部" name="default">
            </el-tab-pane>
            <el-tab-pane class="flex flex-wrap align-center" label="热门" name="hot">
            </el-tab-pane>
            <el-tab-pane class="flex flex-wrap align-center" label="最新" name="date">
            </el-tab-pane>
          </el-tabs>
          <el-row class="course-module">
            <!--            <div class="course-block">-->
            <!--              <type-block v-for="dd in list" :key="dd" :img="dd.img" :width="224"-->
            <!--                          class="margin-bottom" @click="$tools.go(`/client/coursePlay/${dd.id}`)">-->
            <!--                <template v-slot:title><span class="font-bold" style="height: 45px;"><span-->
            <!--                  class="tag">{{ dd.typeData['typeName'] }}</span>&nbsp;{{ dd.name }}</span></template>-->
            <!--                <template v-slot:sub-title><p class="margin-bottom flex-->
            <!--             align-center">-->
            <!--                  <small>主讲人&nbsp;</small>-->
            <!--                </p></template>-->
            <!--                <template v-slot:content><small class="ellipsis">介绍</small>-->
            <!--                </template>-->
            <!--              </type-block>-->
            <!--              <type-block v-for="dd in [1,2,3]" :key="dd" :width="224" class="margin-bottom after-add">-->
            <!--              </type-block>-->
            <!--            </div>-->
            <list-block v-for="dd in list" :key="dd.id" :obj="dd" class="margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)"></list-block>
          </el-row>
          <div v-if="list.length === 0" class="flex align-center justify-content" style="min-height: 600px;">
            <null-back justify="flex-start"><span class="font-bold color666">很遗憾没有找到"<span class="primary-color">{{
                router.currentRoute.value.query.search
              }}"</span>相关数据</span>
            </null-back>
          </div>
        </div>
        <div class="margin-start" style="width: 280px">
          <el-card class="margin-top">
            <strip-title class="margin-bottom">推荐课程</strip-title>
            <type-block v-for="dd in dataList" :id="dd.courseId" :key="dd.courseId" :img="dd.img"
                        :type="2">
              <template v-slot:title>
                <span style="height:45px">{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <small v-if="dd['lectuereData']" class="color999">主讲人：{{
                    dd['lectuereData']['lectuereName']
                  }}</small>
              </template>
              <template v-slot:content>
                <small v-if="dd['watchData']['aggregateData']['staffStudyNum'] > 0" class="color999">
                  <Icon icon="UserFilled"></Icon>
                  <span class="primary-color font-bold">&nbsp;{{
                      dd['watchData']['aggregateData']['staffStudyNum']
                    }}</span>人观看
                </small>
                <small v-else class="color999">最新课程</small>
              </template>
            </type-block>
          </el-card>
        </div>
      </div>
    </section>
    <!-- 分页 -->
    <el-row v-if="total > 0" align="middle" justify="center" type="flex">
      <el-pagination :page-size="queryParams.limit" :page-sizes="[10, 20, 50, 100]" :total="total" background
                     layout="total,sizes,prev, pager, next,jumper" @size-change="handleSizeChange"
                     @current-change="handleCurrentChange">
      </el-pagination>
    </el-row>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted, reactive, toRefs } from 'vue'
import tools from '@/utils/tool'
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'
import StripTitle from '@/components/StripTitle.vue'
import router from '@/router'
import NullBack from '@/viewsClient/components/NullBack.vue'
import ListBlock from '@/viewsClient/components/block/ListBlock.vue'

export default defineComponent({
  name: '',
  components: {
    ListBlock,
    StripTitle,
    TypeBlock,
    NullBack
  },
  setup: () => {
    const state = reactive({
      currentCheckedId: '1',
      currentPage: 1,
      queryParams: {
        limit: 20,
        offset: 0
      },
      searchInfo: {
        sort: 'default',
        name: router.currentRoute.value.query.search || ''
      },
      isShowClass: false,
      list: [] as any[],
      dataList: [] as any[], // 推荐课程
      isList: false,
      classList: [] as any[],
      currentType: {} as any,
      searchOthers: {},
      value: '',
      total: 0
    })
    const getClass = () => {
      // 根据typeId获取对应的三级菜单！！
      tools.clientPost('/api/rest/courseType/getListByPage', {
        where: { parent_id: { _eq: router.currentRoute.value.query.typeId } },
        currentWhere: { id: { _eq: router.currentRoute.value.query.typeId } }
      }).then(r => {
        state.classList = r.data.list;
        (state.classList as any).unshift({
          name: '全部',
          id: '1'
        })
        state.currentType = r.data.currentType[0]
      })
    }

    const getList = () => {
      // 综合-全部,热门-看课人数排名,最新-根据时间排序
      tools.clientPost('/api/rest/course/getListByPage', { where: { status: { _eq: 1 } } }).then(r => {
        state.dataList = r.data.list.splice(0, 8) // 随机选
      })
    }

    const handleSizeChange = (val) => {
      state.queryParams.limit = val
      getAllCourse()
    }

    const handleClick = async (data) => {
      await getAllCourse()
    }

    const changeCurrentChecked = (val, index) => {
      const typeCode = val.name === '全部' ? state.currentType.code : val.code
      location.href = `/#/client/allCourse?typeId=${router.currentRoute.value.query.typeId}&subTypeId=${val.id}&typeCode=${(typeCode && typeCode !== undefined) ? typeCode : ''}`
    }

    const handleCurrentChange = (val) => {
      state.queryParams.offset = state.queryParams.limit * (val - 1)
      getAllCourse()
    }

    const getAllCourse = () => {
      const data: any = state.queryParams
      tools.clientPost('/courses/getAllListByPage', {
        ...data,
        ...state.searchInfo,
        typeCode: router.currentRoute.value.query.typeCode
      }).then(r => {
        const arr: any = []
        // 修改typeName(去重复！)
        r.list.forEach(res => {
          const list = res.typeName.split(',')
          res.typeNames = Array.from(new Set(list)).reverse().join('-')
          arr.push(res)
        })
        state.list = r.list
        state.total = r.total
      })
    }

    onMounted(() => {
      const dom: any = document.querySelector('#client')
      dom.scroll(0, 0)
      if (router.currentRoute.value.query.typeId) {
        state.isShowClass = true
      }
      state.currentCheckedId = router.currentRoute.value.query.subTypeId ? router.currentRoute.value.query.subTypeId as string : '1'
      getList()
      getClass()
      getAllCourse()
    })

    return {
      ...toRefs(state),
      router,
      handleSizeChange,
      handleClick,
      handleCurrentChange,
      changeCurrentChecked
    }
  }
})
</script>

<style lang="less" scoped>
@import (once) "~@/assets/css/client.less";

.all-course {
  padding: 20px 0 36px 0;

  .category-card-box {
    cursor: default;

    ul {
      display: flex;
      justify-content: flex-start;
      flex-flow: wrap;

      span {
        font-weight: bolder;
        font-size: 24px;
        display: flex;
        align-items: center;
        margin-right: 10px;
      }

      li {
        white-space: nowrap;
        border-radius: 16px;
        background: #f2f2f2;
        padding: 4px 16px;
        margin: 8px;
        color: #666666;
      }

      .checked {
        background: @color;
        color: #f2f2f2;
      }
    }
  }

  .lists-box {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;

    .list-item {
      //width: @containerWith;
      margin-bottom: 20px;
      margin-top: 0px;

      &:hover {
        // transform: scale(1.06);
        cursor: pointer;
      }
    }
  }
}

.course-module {
  margin-bottom: 24px;

  .big-title {
    margin-bottom: 24px;
  }
}

.course-block {
  width: 100%;
  margin-top: 20px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin-bottom: 16px;
}
</style>
