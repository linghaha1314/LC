<template>
  <div class="doctor-personal">
    <!-- banner -->
    <div class="banner-box">
      <img alt src="@/assets/images/doctor-center-banner.png"/>
      <div class="banner-content container">
        <div class="doctor-card container">
          <div class="head-img">
            <img :src="state.doctorObj['avatar'] || state.defaultImg"/>
          </div>
          <div class="right-box">
            <p>
              <span class="name">{{ state.doctorObj.name }}</span>
              <span class="position">
              {{ state.doctorObj['organizationName'] }}
              <img alt class="img-icon" src="@/assets/images/renzheng-icon.png"/>
             </span>
            </p>
            <p>
               <span class="organizationName">
              {{ state.doctorObj.majorName }}
                <img alt class="img-icon" src="@/assets/images/hospital-icon.png"/>
               </span>
              <span class="department">
               {{ state.doctorObj['positionName'] }}
                <img alt class="img-icon" src="@/assets/images/department-icon.png"/>
               </span>
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- 主体 -->
    <el-row class="container main" justify="center" type="flex">
      <div class="left-box">
        <el-card>
          <el-menu
            :default-active="state.activeIndex"
            class="el-menu-demo"
            mode="horizontal"
            @select="handleSelect"
          >
            <el-menu-item :class="{ active: state.activeIndex === '1' }" index="1"
            >个人中心
            </el-menu-item
            >
            <el-menu-item :class="{ active: state.activeIndex === '2' }" index="2"
            >基本资料
            </el-menu-item
            >
            <el-menu-item :class="{ active: state.activeIndex === '3'}" index="3"
            >视频空间
            </el-menu-item
            >
          </el-menu>
          <!-- 个人中心 -->
          <el-row v-show="state.activeIndex === '1'" class="content-box">
            <el-row class="main-content" v-html="state.doctorObj['introduce']">
            </el-row>
          </el-row>
          <!-- 基本资料 -->
          <el-row v-show="state.activeIndex ==='2'" class="content-box">
            <li>
              <div class="sub-title" style="font-weight: 600">
                {{ state.doctorObj.subTitle }}
              </div>
              <div
                v-if="state.doctorObj.details"
                class="details"
                v-html="state.doctorObj.details"
              ></div>
            </li>
            <null-back justity="center">暂无内容</null-back>
          </el-row>
          <!-- 视频空间 -->
          <el-row v-show="state.activeIndex === '3'" class="content-box">
            <type-block v-for="dd in courseList" :key="dd" :img="dd.img" :width="224"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <p><small>最新最全详解，打开医学大门</small></p>
                <p><small>侯老师</small></p>
              </template>
              <template v-slot:content>
                <el-row>
                  <el-col :span="12"><small>14看过</small></el-col>
                  <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>
                </el-row>
              </template>
            </type-block>
            <null-back v-if="courseList.length==0" justity="center">暂无内容</null-back>
          </el-row>
        </el-card>
        <el-card v-show="state.activeIndex == '1'">
          <sub-title
            :img="require('@/assets/images/tv-icon.png')"
            :title="state.doctorObj.name + '的精彩医术视频'"
            buttonText="查看更多>"
            style="margin-bottom: 20px"
          >
            <template v-slot:preIcon>
              <i
                class="iconfont iconcomputer font-green"
                style="font-size: 20px"
              ></i>
            </template>
          </sub-title>
          <div class="flex flex-wrap">
            <type-block v-for="dd in courseList.slice(0,8)" :key="dd" :img="dd.img" :width="224"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <p><small>最新最全详解，打开医学大门</small></p>
                <p><small>侯老师</small></p>
              </template>
              <template v-slot:content>
                <el-row>
                  <el-col :span="12"><small>14看过</small></el-col>
                  <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>
                </el-row>
              </template>
            </type-block>
          </div>
          <null-back v-if="courseList.length==0">暂无内容</null-back>
        </el-card>
      </div>
    </el-row>
  </div>
</template>

<script lang="ts" setup>
import SubTitle from '@/viewsClient/components/title/SubTitle.vue'
import { onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import router from '@/router'
import NullBack from '@/viewsClient/components/NullBack.vue'
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'

const courseList = ref([])

const state = reactive({
  doctorObj: {
    name: '老师'
  },
  defaultImg: require('@/assets/images/home-block.png'),
  activeIndex: '1'
})

const handleSelect = (val) => {
  state.activeIndex = val
}

onMounted(() => {
  // 根据用户id查找相关数据；查询主讲人id的所有课程
  tools.clientGet('/getUserInfo', {
    id: router.currentRoute.value.params.id
  }).then(r => {
    // state.doctorObj = { ...r.data.data[0], ...r.data.data[0].staffData }
    state.doctorObj = r.data
  })
  tools.clientGet('/courses/getListByPage', { lecturerId: router.currentRoute.value.params.id }).then(r => {
    courseList.value = r.list
  })
})
</script>

<style lang="less" scoped>
.doctor-personal {
  width: 100%;
  padding: 0 0 36px 0;

  .banner-box {
    margin: auto;
    width: 100%;
    height: 280px;
    position: relative;
    overflow: hidden;

    & > img {
      min-width: 100%;
      height: 280px;
      position: absolute;
      top: 0;
      left: 0;
    }

    .banner-content {
      margin: auto;
      display: inline-block;
      position: absolute;
      top: 50%;
      left: 0;
      width: 100%;
      transform: translateY(-50%);

      .doctor-card {
        display: flex;
        justify-content: flex-start;
        align-items: center;

        .head-img {
          height: 100px;
          width: 100px;
          border-radius: 50%;

          img {
            height: 100%;
            width: 100%;
            border-radius: 50%;
            object-fit: cover;
          }
        }

        .right-box {
          margin-left: 25px;
          color: #ffffff;

          .name {
            font-size: 24px;
            font-weight: 600;
            margin-right: 30px;
          }

          .position {
            font-size: 18px;
            font-weight: 500;
          }

          .belong,
          .department {
            font-weight: 400;
            margin-right: 20px;
          }
        }

        .img-icon {
          vertical-align: middle;
          margin-left: 2px;
        }
      }

      .card-inbanner-box {
        margin: auto;
        //width: @containerWith;
      }
    }
  }

  .main {
    margin: 0 auto;
    margin-top: 20px;

    .left-box {
      width: 100%;
      margin-right: 22px;

      .active {
        font-size: 18px;
        font-weight: 600;
      }

      & > .el-card {
        background: #ffffff;
        margin-bottom: 20px;

        &:first-child {
          font-size: 14px;
          font-weight: 400;

          .el-menu {
            margin: 0 30px;
          }

          .content-box {
            padding: 20px 28px 64px 28px;

            .none {
              height: 480px;
              line-height: 480px;
              text-align: center;
              display: block;
              margin: 0 auto;
              font-size: 22px;
              font-weight: 600;
              color: #cccccc;

              img {
                vertical-align: middle;
                margin-right: 18px;
              }
            }

            li {
              padding: 19px 30px 27px 30px;
              border-bottom: 1px solid #eeeeee;

              &:last-child {
                border: none;
              }

              .sub-title {
                font-size: 18px;
                font-weight: 500;
                margin-bottom: 16px;
              }

              .details {
                font-size: 14px;
                font-weight: 400;
              }
            }

            .basic-title-box {
              margin: 0 30px;
            }

            .main-content {
              font-size: 14px;
              margin: 0 30px;

              div {
                margin-bottom: 12px;
              }
            }
          }
        }

        &:last-child {
          padding: 24px 64px;

          .block-two {
            margin-bottom: 20px;
            margin-right: 10px;
          }
        }
      }
    }
  }
}

</style>
