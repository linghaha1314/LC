<!--<template>-->
<!--  &lt;!&ndash; 名师讲坛 &ndash;&gt;-->
<!--  <el-row class="teacher-lecture">-->
<!--    <el-card class="class-card">-->
<!--      <el-row class="class-screen">-->
<!--        <class-screening :classArr="classArr" title="专业"></class-screening>-->
<!--      </el-row>-->
<!--      <div class="comprehensive-screen">-->
<!--        <div class="select-box">-->
<!--          <select-option :options="options"></select-option>-->
<!--          <select-option :options="options"></select-option>-->
<!--        </div>-->
<!--      </div>-->
<!--    </el-card>-->
<!--    <el-card shadow="always" class="lecture-block-box">-->
<!--      <lecture-block-->
<!--        v-for="i in doctorList"-->
<!--        :key="i.id"-->
<!--        :obj="i"-->
<!--      ></lecture-block>-->
<!--    </el-card>-->
<!--    <el-row type="flex" justify="center">-->
<!--      <el-pagination-->
<!--        background-->
<!--        layout="prev, pager, next"-->
<!--        :total="total"-->
<!--        :page-size="pageSize"-->
<!--        @current-change="currentChange"-->
<!--      ></el-pagination>-->
<!--    </el-row>-->
<!--  </el-row>-->
<!--</template>-->
<!--<script>-->
<!--import LectureBlock from '@/viewsClient/components/block/LectureBlock'-->
<!--import SelectOption from '@/viewsClient/components/widget/SelectOption.vue'-->
<!--import ClassScreening from '@/viewsClient/components/block/ClassScreening.vue'-->
<!--import teacherLecture from '@/viewsClient/doctor/components/teacherLecture.js'-->

<!--export default {-->
<!--  mixins: [teacherLecture],-->
<!--  data () {-->
<!--    return {-->
<!--      options: [-->
<!--        {-->
<!--          value: '热门',-->
<!--          id: 1,-->
<!--          selected: true-->
<!--        },-->
<!--        {-->
<!--          value: '综合筛选',-->
<!--          id: 2,-->
<!--          selected: false-->
<!--        }-->
<!--      ]-->
<!--    }-->
<!--  },-->
<!--  components: {-->
<!--    LectureBlock,-->
<!--    'select-option': SelectOption,-->
<!--    'class-screening': ClassScreening-->
<!--  },-->
<!--  methods: {}-->
<!--}-->
<!--</script>-->
<!--<style lang="less" scoped>-->
<!--//.teacher-lecture {-->
<!--//  padding: 20px 0 36px 0;-->
<!--//-->
<!--//  .class-card {-->
<!--//    .comprehensive-screen {-->
<!--//      width: 100%;-->
<!--//      display: flex;-->
<!--//      justify-content: space-between;-->
<!--//      align-items: center;-->
<!--//    }-->
<!--//  }-->
<!--//-->
<!--//  .lecture-block-box {-->
<!--//    box-shadow: 0px 0px 15px 1px rgba(193, 193, 193, 0.32);-->
<!--//    padding: 0;-->
<!--//    margin-top: 32px;-->
<!--//    margin-bottom: 36px;-->
<!--//-->
<!--//    .lecture-block {-->
<!--//      max-width: 1380px;-->
<!--//      height: 190px;-->
<!--//      border-bottom: 1px solid #e5e5e5;-->
<!--//-->
<!--//      &:last-child {-->
<!--//        border: none;-->
<!--//      }-->
<!--//    }-->
<!--//  }-->
<!--//}-->
<!--</style>-->
