<template>
  考试哈哈哈哈
</template>

<script>
export default {
  name: 'CommenExam'
}
</script>

<style scoped>

</style>
