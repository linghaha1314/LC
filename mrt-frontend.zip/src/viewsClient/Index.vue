<template>
  <div id="client">
    <el-container>
      <el-affix v-if="!router.currentRoute.value.meta['isNotShowHead']" :offset="0" z-index="1002">
        <el-header style="background: #ffffff">
          <div class="container" style="height: 100%">
            <head-box></head-box>
          </div>
        </el-header>
      </el-affix>
      <el-main>
        <el-row>
          <router-view :key="$route.fullPath" />
        </el-row>
      </el-main>
      <el-footer v-if="!router.currentRoute.value.meta['isNotShowFooter']" class="container">
        <footer-box></footer-box>
      </el-footer>
    </el-container>
  </div>
</template>

<script lang="ts">
import HeadBox from '@/viewsClient/components/Head.vue'
import FooterBox from '@/viewsClient/components/Footer.vue'
import { defineComponent, onMounted, reactive, toRefs } from 'vue'
import router from '@/router'
import tools from '@/utils/tool'
import store from '@/store'

export default defineComponent({
  name: '',
  components: {
    HeadBox,
    FooterBox
  },
  setup: () => {
    const state = reactive({})
    onMounted(() => {
      tools.clientGet('getUserInfo', {}).then((res) => {
        if (res.token) {
          store.commit('setClientToken', res.token)
        }
        store.commit('setClientUserInfo', res.data)
      })
    })
    return {
      ...toRefs(state),
      router
    }
  }
})
</script>

<style lang="less">
@import (once) '~@/assets/css/client.less';
@import (once) '~@/assets/css/commen.less';

#client {
  overflow-y: auto;
  height: 100%;

  .el-header {
    height: 80px;
    line-height: 80px;
  }

  .el-main {
    background: #f9f9f9;
    overflow: inherit;
    padding: 0;
  }
}
</style>
