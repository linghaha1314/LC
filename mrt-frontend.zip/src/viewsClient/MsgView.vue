<template>
  <div class="container" v-html="data.content"></div>
</template>

<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import tools from '@/utils/tool'
import router from '@/router'

const data = ref({})
onMounted(() => {
  tools.clientPost('/msgPush/getDataById', { id: router.currentRoute.value.params.id }).then(r => {
    data.value = r.data
  })
})
</script>

<style scoped>

</style>
