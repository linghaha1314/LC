<template>
  <div class="home container">
    <section class="container">
      <el-row class="flex">
        <el-col :span="7">
          <strip-title class="padding-bottom padding-top">
            热点推送
          </strip-title>
          <el-carousel v-if="state.bannerList.length"
                       style="box-sizing: border-box;box-shadow: 0 0 10px 0 rgb(0 0 0 / 12%);" height="300px">
            <el-carousel-item v-for="item in state.bannerList" :key="item['id']" v-loading="!item.img">
              <img :src="item['img']" alt="" style="width: 100%;height: 100%;"
                   @click="$tools.go(`/client/coursePlay/${item.id || item.courseId}`)"/>
            </el-carousel-item>
          </el-carousel>
        </el-col>
        <el-col :span="1"></el-col>
        <el-col :span="16">
          <strip-title class="padding-bottom padding-top">最新推送</strip-title>
          <ul class="padding-start padding-end msg-ul" style="background: #ffffff;height: 300px;box-sizing: border-box">
            <li v-for="item of state.msgList" :key="item"
                class="flex align-center padding-top padding-bottom  li-hover justify-between">
              <!-- <a :href="item.img || `#/client/msgView/${item.id}`" target="_blank"> -->
              <a @click="$tools.go(`/client/coursePlay/${item.id || item.courseId}`)">
                <Icon icon="Collection"></Icon>
                <span class="font-bold color666">&nbsp;{{ item.name }}</span>
              </a>
              <span class="color999">[{{ $tools.formatTime(item.created) }}]</span>
            </li>
          </ul>
        </el-col>
      </el-row>
    </section>
    <section class="container"
             v-if="state.compulsoryList && state.compulsoryList.length > 0 && store.state.clientUserInfo.id">
      <strip-title class="padding-bottom padding-top">待看课程</strip-title>
      <div class="flex align-center grid-row padding-bottom margin-bottom">
        <simple-card v-for="dd in state.compulsoryList" :key="dd.name" :img="dd.courseImg"
                     @click="$tools.go(`/client/coursePlay/${dd.courseId}`)">
          <template v-slot:title>
            {{ dd.courseName }}
          </template>
          <template v-slot:sub-title>
            主讲人：
            <span class="color666" v-if="dd['lecturerName']">{{ dd['lecturerName'] }}</span>
            <span class="color666" v-if="!dd['lecturerName']">未知</span>
          </template>
        </simple-card>
      </div>
    </section>
    <section class="container" v-if="state.list && state.list.length > 0">
      <strip-title class="padding-bottom padding-top">课程推荐</strip-title>
      <div class="flex align-center grid-row padding-bottom margin-bottom">
        <simple-card v-for="dd in state.list" :key="dd.name" :img="dd.img"
                     @click="$tools.go(`/client/coursePlay/${dd.courseId}`)">
          <template v-slot:title>
            {{ dd.name }}
          </template>
          <template v-slot:sub-title>
            主讲人：
            <span class="color666" v-if="dd['lectuereData']">{{ dd['lectuereData']['lectuereName'] }}</span>
            <span class="color666" v-if="!dd['lectuereData']">未知</span>
          </template>
        </simple-card>
      </div>
    </section>
    <home-columns></home-columns>
  </div>
</template>

<script lang="ts" setup>
import { onBeforeMount, onMounted, reactive, ref, watch } from 'vue'
import StripTitle from '@/components/StripTitle.vue'
import tools from '@/utils/tool'
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'
import store from '@/store'
import SimpleCard from '@/viewsClient/components/block/SimpleCard.vue'
import HomeColumns from '@/viewsClient/components/HomeColumns.vue'

const homeColumns = ref([] as any[])

const getBannerList = async () => {
  const result = await tools.clientPost('/courses/getDataListByStaffNum', { limit: 3 })
  state.bannerList = result.list
}

const state = reactive({
  msgList: [] as any[],
  compulsoryList: [] as any[],
  bannerList: [] as any[],
  list: [] as any[],
  activeIndex: '0',
  teacherData: {},
  limit: 10
})

const getMsgList = () => {
  tools.clientPost('/api/rest/course/getListByPage', { limit: 5 }).then(r => {
    state.msgList = r.data.list
  })
}

const getCompulsoryList = () => {
  tools.clientPost('/staffCompulsoryCourses/getCourseByStaffId', {
    limit: 18,
    staffId: store.state.clientUserInfo?.id || null
  }).then(r => {
    state.compulsoryList = r.list
  })
}

const handleSelect = (data) => {
  console.log('select', data)
}

const findSubMenuTitle = (target) => {
  if (target === undefined) {
    return null
  }
  if (target.getAttribute('class') && target.getAttribute('class').indexOf('el-sub-menu__title') > -1) {
    return target
  }
  return findSubMenuTitle(target.parentNode)
}

const go = (path) => {
  location.href = path
}

const getAllCourse = async () => {
  const data = {
    limit: 9,
    where: {
      recommend_deadline: { _gt: tools.formatTime('') },
      status: { _eq: 1 }
    }
  }
  await tools.clientPost('/api/rest/course/getListByPage', data).then(r => {
    state.list = r.data.list
  })
}

onBeforeMount(() => {
  store.commit('setSearch', '')
})

onMounted(
  async () => {
    await getBannerList()
    await getAllCourse()
    getCompulsoryList()
    getMsgList()
    tools.clientGet('/api/rest/lecturer/getLecturerByPage', {}).then(r => {
      state.teacherData = r.data
    })
  }
)

watch(() => store.state.clientUserInfo, (val) => {
  if (val) {
    getAllCourse()
    getCompulsoryList()
  }
})
</script>

<style lang="less" scoped>
@import (once) '~@/assets/css/client.less';

.parent {
  overflow-x: scroll;
  white-space: nowrap;
  transition: all 2s ease-in-out;
}

.home {
  width: 100%;
}

.more-hover {
  color: @color;

  &:hover {
    color: #63b7cf;
    cursor: default;
  }
}

.msg-ul {
  border-radius: 4px;
  box-shadow: 0 0 10px 0 rgb(0 0 0 / 12%);

  // &:hover {
  border: 4px solid #842d4f;
  // }

  .li-hover {
    cursor: default;
    border-bottom: 1px dashed @color;

    &:hover {
      color: @color;

      span {
        color: @color;
      }
    }
  }
}

.arrow-wrapper {
  position: relative;

  .arrow {
    padding: 25px 10px;
    top: 50%;
    position: absolute;
    background: #f2f2f2;
    transform: translateY(-50%);
    color: #cccccc;
    border-radius: 4px;

    &:hover {
      color: #666666;
      background: @color;
    }
  }

  .arrow-left {
    left: -50px;
  }

  .arrow-right {
    right: -50px;
  }
}

.grid-row {
  width: 100%;
  display: grid;
  grid-template-columns: repeat(3, 32.3%);
  //grid-template-rows: repeat(3, 30%);
  grid-column-gap: 20px;
  grid-row-gap: 20px;
}
</style>
