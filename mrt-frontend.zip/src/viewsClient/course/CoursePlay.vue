<template>
  <div v-loading="false" style="width: 100%">
    <section class="padding-bottom padding-top" style="width: 100%;background: #ffffff">
      <el-row class="course-block container">
        <el-col :span="13" style="position: relative;min-width:300px;height: 100%">
          <audio-player v-if="isAudioPlay" height="360px"
                        :src="$tools.convertUrl(videoData?.path) || videoData?.video"
                        v-model:total-time="videoData.totalTime"
                        :cover="courseData.img"
                        :allowMaxSeek="videoData['maxTime']"
                        :isAllowSeek="videoData['isRealCompleted']"
                        @getCurrentTime="getCurrentTime"></audio-player>
          <ali-player ref="videoRef" v-if="isVideoPlay && (videoData?.path || videoData?.video)" v-loading="!isReady"
                      v-model:total-time="videoData.totalTime" :allowMaxSeek="videoData['maxTime']"
                      :autoplay="courseData.autoplay" :cover="courseData.img"
                      :isAllowSeek="videoData['isRealCompleted'] || videoData['completed']"
                      :isLive="false" :rePlay="false" :showBuffer="true"
                      :source="$tools.convertUrl(videoData?.path) || videoData?.video"
                      :useFlashPrism="false"
                      :useH5Prism="true"
                      controlBarVisibility="always" encryptType="1" height="100%" playauth="播放鉴权" showBarTime="5000"
                      vid="视频vid"
                      width="100%" @getCurrentTime="getCurrentTime" @ready="ready"></ali-player>
          <div v-if="!videoData?.path && !videoData?.video">
            <img src="../../assets/images/client/video-error.jpg"/>
          </div>
          <!-- 文件只显示封面-->
          <div v-if="isFilePlay" class="file-show-wrapper">
            <img :src="courseData.img"/>
            <div class="open-url-btn">
              <div class="color666"><small>链接地址：{{ videoData.path || videoData.video }}</small></div>
              <el-button size="small" type="primary" @click="openUrl(videoData.path || videoData.video)">跳转链接
              </el-button>
            </div>
          </div>
          <div class="edit-note" title="做笔记" @click="addNote">
            <Icon class="icon" icon="Edit"></Icon>
          </div>
        </el-col>
        <el-col :span="1"></el-col>
        <el-col :span="10" class="flex column justify-between">
          <div class="flex justify-between align-center ">
            <h1 style="font-size: 24px;margin:0">{{ courseData.name }}</h1>
            <div class="flex align-center">
              <!--<icon-font :name="'#icon-weixin'"></icon-font> &nbsp;-->
              <el-button v-if="collectData.status === 0" class="collect-btn" plain type="warning" @click="collect(1)">
                收藏课程
              </el-button>
              <el-button v-if="collectData.status === 1" class="collect-btn collected" plain title="取消收藏" type="warning"
                         @click="collect(-1)">已收藏
              </el-button>
            </div>
          </div>
          <div class="time-num">
            <p v-if="courseData.typeName">
              <Icon class="icon color999" icon="Ticket"></Icon>&nbsp;
              <span>课程类型：<span v-for="(ii,index) in courseData.classList" :key="index" class="color666"><span
                v-if="index!==0">-</span>{{
                  ii.courseTypeData.typeName
                }} </span>
               </span>
            </p>
            <p v-if="courseData.columnName">
              <Icon class="icon color999" icon="Menu"></Icon>&nbsp;
              <span>所属栏目：<span class="color666">{{ courseData.columnName }}</span></span>
            </p>
            <p v-if="store.state.clientUserInfo?.id && !staffLoading" class="flex align-center color999">
              <Icon class="icon" icon="Finished"></Icon>
              <small v-if="staffScore===0">&nbsp;课程评分：</small>
              <small v-else class="cursor-default">&nbsp;已评分：</small>
              <el-rate v-model="staffScore" :disabled="staffScore > 0" size="large"
                       disabled-void-color="rgb(201 200 200)"
                       @change="submitScore"/>
              <small v-if="staffScore>0">&nbsp;({{ staffScore }}分)</small>
            </p>
            <span class="primary-color font28 font-bold avg-score">{{ courseData.avgScore }}</span>
          </div>
          <div class="lately-study-num">学习总人数：{{ studyStaffNum || 0 }}人</div>
          <div style="min-height:40px;margin-bottom: 8px;">
            <el-button plain type="primary" @click="addNote">做笔记📒</el-button>
          </div>
        </el-col>
      </el-row>
    </section>
    <section class="container margin-bottom">
      <!-- 播放下面的横向菜单 -->
      <div class="catalog-comment-wrapper margin-top">
        <div class="left-box">
          <el-card style="height:100%">
            <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" @select="tabSelect">
              <el-menu-item :class="{ activated: activeIndex === '1' }" index="1">课程简介
              </el-menu-item>
              <el-menu-item :class="{ activated: activeIndex === '2' }" index="2">课程目录
              </el-menu-item>
              <el-menu-item :class="{ activated: activeIndex === '3' }" index="3">课程留言
              </el-menu-item>
              <el-menu-item :class="{ activated: activeIndex === '4' }" index="4">资料文件
              </el-menu-item>
              <el-menu-item v-if="store.state.clientUserInfo?.name" :class="{ activated: activeIndex === '5' }"
                            index="5">笔记
              </el-menu-item>
            </el-menu>
            <!-- 课程介绍 -->
            <div v-if="activeIndex === '1'" class="course-introduce content-wrapper">
              <div v-html="courseData['brief']"></div>
            </div>
            <!--  课程目录-->
            <div v-if="activeIndex === '2'" class="course-catalog content-wrapper">
              <catalog-list :chapters="chapters" :currentChapterId="videoData?.id"
                            @changeChapter="changeSource($event)">
              </catalog-list>
            </div>
            <!-- 课程留言 -->
            <div v-if="activeIndex === '3'" class="course-score content-wrapper">
              <course-comment v-if="commentUrl && courseData.id" :courseId="router.currentRoute.value.params.id"
                              :url="commentUrl"></course-comment>
              <el-row class="comment-score-box margin-top">
                <div class="card" shadow="none">
                  <div class="img-box">
                    <img :size="40"
                         :src="store.state.clientUserInfo?.avatar || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
                         style="width: 60px;height: 60px;border-radius: 50%"/>
                  </div>
                  <div class="content">
                    <div class="title-box">
                      <span v-if="store.state.clientUserInfo && store.state.clientUserInfo?.name" class="title">{{
                          store.state.clientUserInfo?.nickName || store.state.clientUserInfo?.name
                        }}</span>
                      <span v-else class="title">匿名用户</span>
                    </div>
                    <div class="comment-box">
                      <contenteditable v-model:content="comment.content" v-model:contentLen="comment.len"
                                       placeholder="请输入留言"></contenteditable>
                    </div>
                    <div class="btn-box">
                      <el-tooltip :content="comment.len > 320 ? '字符长度不超过320个，请重新编辑再提交' : '??'"
                                  :disabled="comment.len <= 320" placement="top">
                        <el-button type="primary" @click="sendComment">发送</el-button>
                      </el-tooltip>
                    </div>
                  </div>
                </div>
              </el-row>
            </div>
            <!-- 资料附件和考试-->
            <div v-if="activeIndex === '4'" class="course-score content-wrapper">
              <file-block v-for="i in files" :key="i" :data="i" class="margin-bottom" @click="download()"></file-block>
              <null-back v-if="files.length === 0" style="height:200px">暂无附件</null-back>
            </div>
            <!--  笔记 -->
            <div v-if="activeIndex === '5'" class="course-score content-wrapper">
              <el-timeline v-if="noteList.length > 0">
                <el-timeline-item v-for="item of noteList" :key="item.id"
                                  :timestamp="$tools.formatTime(item.created, 'YY-MM-DD hh:mm:ss')" placement="top">
                  <el-card class="note-timeline-card" @click="locate(item)">
                    <div class="head"><span class="font-bold">{{ item['courseName'] }}</span><span>-{{
                        item['chapterName']
                      }}</span>-<span>{{ $tools.hms(item.time) }}</span></div>
                    <div class="padding-top"><span class="font-bold color666">笔记：</span><span v-html="item.note"></span>
                    </div>
                  </el-card>
                </el-timeline-item>
              </el-timeline>
              <null-back v-if="noteList.length === 0" style="height: 200px">暂时没有任何关于你的笔记，快去学习吧</null-back>
            </div>
          </el-card>
        </div>
        <!-- 右边推荐-->
        <div class="right-box" v-if="relatedCourse && relatedCourse.length>1">
          <el-card v-if="courseData['lecturerId']" class="margin-bottom"
                   @click="$tools.go(`/client/doctorCenter/${courseData['lecturerId']}`)">
            <strip-title class="margin-bottom">讲师</strip-title>
            <el-row class="align-center">
              <el-avatar :size="60" src="https://empty">
                <img alt="" src="https://cube.elemecdn.com/e/fd/0fc7d20532fdaf769a25683617711png.png"/>
              </el-avatar>
              <div class="padding-start">
                <p class="font-bold">{{ courseData['lecturerName'] }}</p>
                <p class="color999">{{ courseData['organizationName'] }}<small>{{ courseData['positionName'] }}</small>
                </p>
              </div>
            </el-row>
          </el-card>
          <el-card>
            <strip-title class="margin-bottom">相关课程</strip-title>
            <type-block v-for="dd in relatedCourse" :id="dd.courseId" :key="dd.courseId" :img="dd.img" :type="2">
              <template v-slot:title>
                <span style="height:45px">{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <!--                <small class="color999">最新课程</small>-->
              </template>
              <template v-slot:content>
                <small class="color999">
                  <span v-if="dd['watchData']['aggregateData']['staffStudyNum']">
                    <Icon icon="UserFilled"></Icon>{{
                      dd['watchData']['aggregateData']['staffStudyNum']
                    }}人学习
                  </span>
                  <span v-else>最新课程</span>
                </small>
              </template>
            </type-block>
          </el-card>
        </div>
      </div>
    </section>
    <!-- 弹窗验证；播放状态并且isShowPopup为true-->
    <section>
      <el-dialog v-model="isShowPopup" :close-on-click-modal="false" :show-close="false" width="30%">
        <template #title>
          <span class="flex align-center justify-between">
            <span class="flex align-center">
              <img alt="" src="@/assets/images/verify-icon.png"/>&nbsp;答题验证
            </span>
            <span v-if="isAllowClosed" style="color:red;cursor: pointer;display:inline-block" @click="closePopup">
              <Icon icon="CircleCloseFilled" class="icon" style="padding-right: 2px;color:red;font-size:28px"></Icon>
            </span>
          </span>
        </template>
        <random-captcha v-if="currentVerify.typeCode === 'captcha' && isShowPopup" @rightClosed="closePopup">
        </random-captcha>
        <exam-block v-if="currentVerify.typeCode === 'byChapter' && isShowPopup" type="radio" :readonly="true"
                    v-model:result="currentVerify.examData" @hasChecked="hasChecked"></exam-block>
        <!-- 题目验证 -->
      </el-dialog>
    </section>
  </div>
  <section class="note-dialog">
    <el-dialog v-model="isShowNote" width="30%">
      <template v-slot:title>
        <div class="font-bold color666">笔记📒</div>
      </template>
      <div class="">{{ $tools.hms(noteObj.time) }}</div>
      <div class="note-wrapper" style="border:1px solid #cccccc">
        <contenteditable v-model:content="noteObj.note" placeholder="好记性不如烂笔头，赶快记录你的思考吧"></contenteditable>
      </div>
      <div class="flex padding-end padding-top" style="justify-content: flex-end">
        <el-button type="primary" @click="submitNote">确定</el-button>
      </div>
    </el-dialog>
  </section>
</template>

<script lang="ts">
import { defineComponent, nextTick, onMounted, reactive, ref, toRefs, watch } from 'vue'
import AliPlayer from '@/viewsClient/components/block/AliPlayer.vue'
import StripTitle from '@/components/StripTitle.vue'
import CourseComment from './components/CourseComment.vue'
import CatalogList from './components/CatalogList.vue'
import tools from '@/utils/tool'
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'
import store from '@/store'
import Contenteditable from '@/viewsClient/components/Contenteditable.vue'
import router from '@/router'
import FileBlock from '@/components/FileBlock.vue'
import RandomCaptcha from '@/components/RandomCaptcha.vue'
import NullBack from '@/viewsClient/components/NullBack.vue'
import AudioPlayer from '@/viewsClient/components/block/AudioPlayer.vue'
import ExamBlock from '@/components/ExamBlock.vue'

export default defineComponent({
  name: '',
  components: {
    ExamBlock,
    AudioPlayer,
    NullBack,
    RandomCaptcha,
    FileBlock,
    Contenteditable,
    TypeBlock,
    AliPlayer,
    StripTitle,
    CourseComment,
    CatalogList
  },
  setup: () => {
    const verify = ref()

    const state = reactive({
      isAudioPlay: false, // 音频播放
      isFilePlay: false,
      isReady: false,
      isAllowClosed: false,
      commentUrl: '/comment/getCommentListByPage',
      activeIndex: '1',
      currentTime: 1,
      currentVerify: {} as any,
      relatedCourse: [] as any[],
      isShowChapter: false,
      isShowNote: false,
      noteObj: {
        time: 1,
        note: ''
      },
      noteList: [] as any[],
      collectData: {
        status: -1,
        id: null
      },
      videoData: {
        path: '',
        video: '',
        totalTime: 0,
        maxTime: 0,
        id: '',
        studyTime: 0,
        completed: false,
        isRealCompleted: false
      },
      courseData: {} as any,
      studyStaffNum: 0,
      isVideoPlay: false,
      chapters: [],
      files: [],
      verifyList: [],
      comment: {
        content: '',
        len: 0
      },
      staffScore: 0,
      staffLoading: true,
      isShowPopup: false,
      userInfo: store.state.clientUserInfo
    })

    const videoRef = ref()

    const playVideo = () => {
      videoRef.value.play()
    }
    // 切换主菜单
    const tabSelect = (key) => {
      state.activeIndex = key
      switch (key) {
        case '1':
          break
        case '2':
          break
        case '3':
          break
        case '4':
          filesByCourseId()
          break
        case '5':
          getNotes()
          break
      }
    }
    const hasChecked = () => {
      state.isAllowClosed = true
    }
    // 获取当前人员当前课程的评分
    const getCourseScore = () => {
      tools.clientGet('/courseScore/getListByPage', {
        staffId: store.state.clientUserInfo?.id,
        courseId: router.currentRoute.value.params?.id
      }).then(r => {
        state.staffScore = r.list.length > 0 ? r.list[0].score : 0
        state.staffLoading = false
      })
    }

    // 添加笔记当前播放时间；笔记内容；必须是富文本的！！
    const addNote = () => {
      if (!store.state.clientUserInfo) {
        store.commit('setClientShowLoginDialog', true)
        return
      }
      state.isShowNote = true
      state.noteObj.time = state.currentTime
    }

    // 提交笔记
    const submitNote = () => {
      state.isShowNote = false
      const obj: any = {
        time: state.noteObj.time,
        note: state.noteObj.note,
        staffId: state.userInfo.id,
        courseId: router.currentRoute.value.params.id,
        chapterId: state.videoData.id
      }
      tools.clientPost('/note/create', obj).then(r => {
        if (r.success) {
          tools.msg('记录成功！')
        }
      })
    }

    // 提交评分
    const submitScore = () => {
      const obj: any = {
        score: state.staffScore,
        staffId: store.state.clientUserInfo?.id,
        courseId: router.currentRoute.value.params.id
      }
      tools.clientPost('/courseScore/create', obj).then(r => {
        if (r.success) {
          tools.msg('评分成功！')
          // 获取新的课程平均分
          getCourseScore()
        }
      })
    }

    // 获取章节信息
    const chapterList = async () => {
      const data = store.state.clientUserInfo?.id ? {
        courseId: router.currentRoute.value.params?.id,
        where: { staff_id: { _eq: store.state.clientUserInfo?.id } }
      } : { courseId: router.currentRoute.value.params.id }
      await tools.clientPost('/chapters/getListByCourseId', data).then(r => {
        state.chapters = r.list
        state.videoData = r.list[0]?.children[0] || r.list[0]// 没有登录的时候取用第一章节
        // getPlayType(state.videoData.path ? state.videoData.path : state.videoData.video)
        // 没有登录就应该没有观看记录！
        if (store.state.clientUserInfo?.id && r.list[0]?.recordChapter.length > 0) {
          state.videoData.studyTime = r.list[0].recordChapter[0].studyTime
          state.videoData.completed = r.list[0].recordChapter[0].isRealCompleted
        }
      })
    }

    // 获取课程信息
    const getCourseData = async () => {
      try {
        await tools.clientGet('/course/getCourseById', { id: router.currentRoute.value.params?.id }).then(r => {
          r.data.classList = r.data.classList.reverse()
          state.courseData = { ...r.data, ...r.classData, ...r.columnData }
        })
      } catch (e) {
        console.error(e)
      }
    }

    // 切换视频资源
    const changeSource = (item, time?) => {
      if (!store.state.clientUserInfo) {
        store.commit('setClientShowLoginDialog', true)
        return
      }
      const data: any = {
        staffId: store.state.clientUserInfo?.id || null,
        chapterId: item.id
      }
      if (!store.state.clientUserInfo || !store.state.clientUserInfo?.id) {
        delete data.staffId
      }
      tools.clientPost('/api/rest/chapter/getChapterById', data).then(r => {
        (state.videoData as any) = {}
        state.videoData = r.data.data[0]
        state.courseData.autoplay = true
        getPlayType(state.videoData?.path || state.videoData?.video)
        nextTick(async () => {
          if (!state.isVideoPlay && !state.isAudioPlay) {
            return
          }
          await getVerifyList()
          if (store.state.clientUserInfo?.id) {
            state.videoData.completed = r.data.data[0].recordChapter[0]?.completed || false
            state.videoData.studyTime = time || r.data.data[0].recordChapter[0]?.studyTime || 0
            state.videoData.maxTime = r.data.data[0].recordChapter[0]?.maxTime || 0
            state.videoData.isRealCompleted = r.data.data[0].recordChapter[0]?.isRealCompleted || false
          }
          setTimeout(() => {
            // 还未加载到videoRef
            if (state.videoData.path && state.videoData.path.indexOf('/attachs') < 0 && state.videoData.path.indexOf('http://') < 0) {
              state.videoData.path = 'http://source.mrtcloud.com:8888/' + state.videoData.path
            }
            if (state.isVideoPlay || state.isFilePlay) {
              videoRef.value.loadByUrl(state.videoData.path || state.videoData.video, time || state.videoData.studyTime)
              videoRef.value.play()
            }
          }, 200)
        })
      })
    }

    const openUrl = (url) => {
      // 如果不是文件，是没有后缀的链接
      let path = url
      if (url.indexOf('/attachs') > 0) {
        path = (window.location.protocol + '//' + window.location.host) + url
      }
      window.open(path, '_blank')
    }

    // 记录当前播放时间
    const getCurrentTime = (time) => {
      state.currentTime = time
      if (time === 2) {
        // 每次播放到二秒就查询看课人数
        getStaffNum()
      }
      state.verifyList.forEach((res: any) => {
        if (time === res.time && videoRef.value.getStatus() === 'playing') {
          // 如果是播放状态才做以下操作！！
          videoRef.value.pause()
          state.currentVerify = res
          state.isAllowClosed = false
          state.isShowPopup = true
        }
      })
      if (!store.state.clientUserInfo || time === 0) {
        return
      }
      const dom: any = document.querySelector('.prism-progress-played')
      state.videoData.maxTime = (state.videoData?.maxTime === undefined || !state.videoData?.maxTime) ? 0 : state.videoData.maxTime
      state.videoData.studyTime = state.videoData.studyTime ?? 0
      // console.log('--->>???allowMaxSeek', state.videoData?.maxTime, state.videoData?.maxTime + 3 < time, time, '222', state.videoData, (Math.ceil(state.videoData?.maxTime) !== 0 || (state.videoData.studyTime === 0 && Math.ceil(state.videoData?.maxTime) === 0)))
      const isCurrentChapterCompleted = state.videoData?.isRealCompleted || state.videoData?.completed
      // 章节没有完成&& 播放时间大于最大时间 但是最开始的进度条跳转不用提示(state.videoData.studyTime)
      if (!isCurrentChapterCompleted && state.videoData?.maxTime + 3 < time && (Math.ceil(state.videoData?.maxTime) !== 0 || (state.videoData.studyTime === 0 && Math.ceil(state.videoData?.maxTime) === 0))) {
        videoRef.value.seek(state.videoData?.maxTime)
        tools.msg('一步一个脚印，不要急于求成哦！', 'warning')
        return
      }
      tools.clientPost('/watchRecord/record', {
        staffId: store.state.clientUserInfo.id,
        staffName: store.state.clientUserInfo.name,
        courseName: state.courseData.name,
        majorName: store.state.clientUserInfo.majorName,
        courseId: router.currentRoute.value.params.id,
        chapterId: state.videoData.id || null,
        totalTime: state.videoData.totalTime,
        studyTime: time
      }).then(r => {
        if (r.id.list?.length === 0) {
          state.videoData.maxTime = 0
          return
        }
        state.videoData.maxTime = ((state.videoData?.maxTime || 0) < r.id.list[0].maxTime) ? r.id.list[0].maxTime : state.videoData?.maxTime
      })
    }

    // 取消收藏和收藏
    const collect = (status) => {
      if (status > 0) {
        if (!store.state.clientUserInfo) {
          store.commit('setClientShowLoginDialog', true)
          return
        }
        tools.clientPost('/collectCourse/create', {
          courseId: router.currentRoute.value.params.id,
          staffId: store.state.clientUserInfo?.id
        }).then(r => {
          if (r.success) {
            tools.msg('收藏成功！')
          }
        })
      } else {
        tools.clientPost('/collectCourse/deleteById', {
          id: state.collectData.id
        }).then(r => {
          if (r.success) {
            tools.msg('取消收藏！')
          }
        })
      }
      selectCourseIsCollected()
    }

    const download = () => {
      // store.commit('setClientShowLoginDialog', true)
    }

    // 视频准备播放
    const ready = () => {
      // 如果是笔记跳转的一定要显示笔记时间
      nextTick(() => {
        if (state.isVideoPlay && videoRef.value) {
          videoRef.value.seek(state.videoData.studyTime || 0)
        }
        state.isReady = true
      })
    }

    const getPlayType = (path: string) => {
      if (!path) {
        return
      }
      const postfixArr = path.replace(/\?(.*)/, '').split('.')
      const postfix = postfixArr[postfixArr.length - 1]
      const videoRegExp = new RegExp(/(mp4|m3u8|mkv|avi|flv|mov)$/)
      const audioRegExp = new RegExp(/mp3$/)
      state.isAudioPlay = false
      state.isFilePlay = false
      state.isVideoPlay = false
      nextTick(async () => {
        if (videoRegExp.test(postfix)) {
          // 如果是没有attachs,也没有http;补充链接！
          if (path.indexOf('/attachs') < 0 && path.indexOf('http://') < 0) {
            state.videoData.path = 'http://source.mrtcloud.com:8888/' + path
          }
          state.isVideoPlay = true
        } else if (audioRegExp.test(postfix)) {
          state.isAudioPlay = true
        } else {
          const mp4: string = await tools.pptConvertMp4(path)
          if (path.indexOf('/attachs') > -1 && mp4 !== path) {
            state.videoData.video = mp4
            state.isVideoPlay = true
            return
          }
          state.isFilePlay = true
        }
      })
    }

    // 收藏课程
    const selectCourseIsCollected = () => {
      if (!store.state.clientUserInfo?.id) {
        state.collectData.status = 0
        return
      }
      tools.clientGet('/collectCourse/getListByPage', {
        courseId: router.currentRoute.value.params.id,
        staffId: store.state.clientUserInfo?.id || null
      }).then(r => {
        state.collectData.status = r.list.length
        state.collectData.id = r.list[0]?.id || null
      })
    }

    // 发送评论
    const sendComment = () => {
      if (!store.state.clientUserInfo) {
        store.commit('setClientShowLoginDialog', true)
        return
      }
      if (!((state.comment.content || '').trim())) {
        tools.msg('留言不能为空', 'warning')
        return
      }
      if (state.comment.len > 320) {
        return
      }
      state.commentUrl = ''
      tools.post('/comment/create', {
        content: state.comment.content,
        staffId: store.state.clientUserInfo?.id,
        courseId: state.courseData.id,
        chapterId: state.videoData.id
      }).then((r) => {
        state.comment = {
          content: '',
          len: 0
        }
        state.commentUrl = '/comment/getCommentListByPage'
        if (r.success) {
          tools.msg('留言成功！')
        }
      })
    }

    // 获取右边推荐的课程，获取相同课程类型的课程，没有就随便获取四个！
    const getAllCourse = async () => {
      await tools.clientPost('/api/rest/course/getListByPage', {
        where: {
          status: { _eq: 1 },
          courseClass: { courseType: { code: { _like: state.courseData.typeCode ? (state.courseData.typeCode + '%') : '%%' } } }
        }
      }).then(r => {
        const list = (r.data.list || []).filter((rr: any) => rr.courseId !== state.courseData.id)
        const radomList: any = []
        if (list?.length > 8) {
          const arr: number[] = []
          while (arr.length < 8) {
            const num: number = Math.floor(Math.random() * list.length)
            if (arr.indexOf(num) === -1) {
              arr.push(num)
              radomList.push(list[num])
            }
          }
          state.relatedCourse = radomList
        }
      })
    }

    // 关闭验证弹窗，继续播放
    const closePopup = () => {
      state.isShowPopup = false
      videoRef.value.play()
    }

    // 获取课程附件
    const filesByCourseId = () => {
      tools.clientGet('/courseFiles/getListByPage', { courseId: router.currentRoute.value.params.id }).then(r => {
        state.files = r.list
      })
    }

    // 获取笔记
    const getNotes = () => {
      tools.clientPost('/note/getDataListByPage', {
        where: {
          course_id: { _eq: router.currentRoute.value.params.id },
          staff_id: { _eq: state.userInfo.id }
        }
      }).then(r => {
        state.noteList = r.list || []
      })
    }

    // 点击笔记，切换资源，定位到顶部，跳转到笔记播放的位置！
    const locate = (item) => {
      changeSource({ id: item.chapterId }, item.time)
      const dom: any = document.querySelector('#client')
      dom.scroll(0, 0)
    }

    // 获取学习的人数
    const getStaffNum = () => {
      tools.clientPost('/api/rest/watchRecord/getStaffNumByCourseId', { courseId: router.currentRoute.value.params.id }).then(r => {
        state.studyStaffNum = r.data.data.total.count
      })
    }

    const getVerifyList = async () => {
      await tools.clientPost('/verify/getListByChapterId', { chapterId: state.videoData?.id }).then(r => {
        state.verifyList = r.list
        // console.log('==>???', state.verifyList)
      })
    }

    // 已登录，获取最近播放的章节记录，只是修改videoData
    const getRecentPlayChapter = async () => {
      if (store.state.clientUserInfo?.id) {
        await tools.clientPost('/api/rest/watchRecord/getChapterOrderByDate', {
          staffId: store.state.clientUserInfo?.id,
          courseId: router.currentRoute.value.params?.id
        }).then(r => {
          if (r.data.data.length > 0) { // 从来没有播放记录是空，就取用没有登录的数据;
            state.videoData = { ...r.data.data[0], ...r.data.data[0]?.chapter[0] }
            state.videoData.id = state.videoData?.id ?? (state.videoData as any).chapterId
          }
        })
      }
    }

    onMounted(async () => {
      await chapterList()
      await getCourseData()
      await getAllCourse() // 获取推荐课程
      selectCourseIsCollected() // 查看课程是否被收藏
      getStaffNum() // 获取当前看课人员数
      getCourseScore() // 当前课程分数
      await getRecentPlayChapter() // 最近播放章节
      getPlayType((!state.videoData.path && state.videoData.video) ? state.videoData.video : state.videoData.path)
      nextTick(() => {
        const dom: any = document.querySelector('#client')
        dom.scroll(0, 0)
      })
      await getVerifyList()
      // 笔记操作
      if (router.currentRoute.value.query.noteTime) {
        const item = {
          chapterId: router.currentRoute.value.query.chapterId,
          time: router.currentRoute.value.query.noteTime
        }
        locate(item)
      }
      // console.log('===>>???mounted2', state.videoData)
    })

    watch(() => store.state.clientUserInfo, (val) => {
      chapterList() // 重新获取章节信息
    })

    return {
      videoRef,
      tabSelect,
      sendComment,
      filesByCourseId,
      chapterList,
      changeSource,
      getCurrentTime,
      collect,
      download,
      hasChecked,
      getStaffNum,
      locate,
      getNotes,
      submitNote,
      addNote,
      closePopup,
      playVideo,
      getCourseScore,
      ready,
      openUrl,
      submitScore,
      router,
      store,
      verify,
      selectCourseIsCollected,
      ...toRefs(state)
    }
  }
})
</script>

<style lang="less">
.note-dialog .el-dialog__body {
  padding-top: 0px !important;
}
</style>

<style lang="less" scoped>
@import (once) '~@/assets/css/client.less';

.file-show-wrapper {
  height: 100%;
  object-fit: cover;
  overflow: hidden;
  position: relative;

  img {
    height: 100%;
    width: 100%;
    object-fit: cover;
  }

  .open-url-btn {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
}

.course-block {
  display: flex;
  background: #ffffff;
  margin-bottom: 32px;
  overflow: hidden;
  height: 360px;
  overflow: hidden;

  .time-num {
    width: 100%;
    position: relative;
    background: #f5f5f5;
    font-weight: 500;
    padding: 8px 17px;
    box-sizing: border-box;

    .avg-score {
      position: absolute;
      right: 16px;
      top: 16px;
    }
  }

  .lately-study-num {
    font-weight: 400;
    color: #999999;
  }
}

.row-container {
  display: flex;
  height: 600px;
  width: 100%;
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  margin: 16px 0;
  box-shadow: -1px 4px 7px #888888;

  .el-header {
    display: flex;
    align-items: center;
    padding: 0;
    background: #ffffff;
    display: flex;
    justify-content: space-between;
    border-bottom: 2px solid #f2f2f2;
    padding: 0 16px;
  }

  .video-wrapper {
    flex: 1;
    background: #000000;

    .video-box {
      padding: 0;
      background: #000000;
      position: relative;
      display: flex;
      justify-content: space-between;

      .video-left {
        width: 100%;
        position: relative;
      }

      .right-slider-bar {
        display: flex;
        align-items: center;
        position: absolute;
        top: 50%;
        right: 0;
        transform: translate(0, -50%);
        cursor: default;

        .fold {
          padding: 16px 8px;
          background: #222629;
          color: #b4bbbf;
        }
      }

      .right-slider {
        display: flex;
        position: relative;
        padding: 8px;
        min-width: 298px;
        background-color: #ffffff;
        box-sizing: border-box;
      }

      .catalog-content {
        background: #666;
      }

      .main-box {
        overflow-y: auto;
      }
    }
  }
}

.activated {
  font-size: 18px;
  font-weight: bold;
}

.comment-score-box {
  margin-top: 40px;

  .card {
    box-sizing: border-box;
    padding: 12px 20px;
    width: 100%;
    display: flex;
    justify-content: flex-start;
    border: 1px solid #eeeeee;
    background: #ffffff;
    border-radius: 4px;

    .img-box {
      margin-right: 24px;
    }

    .content {
      width: 100%;
      margin-bottom: 10px;

      .title-box {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        margin-bottom: 20px;
        padding: 20px 0;

        .title {
          margin-right: 20px;
          font-weight: bold;
        }
      }

      .comment-box {
        position: relative;
        width: 100%;
        margin-bottom: 20px;
        border: 1px solid #eeeeee;
        border-radius: 2px;

        .input-comment {
          width: 100%;
          padding: 17px 10px 30px 10px;
        }

        span {
          position: absolute;
          bottom: 5px;
          left: 5px;
          height: 24px;
          line-height: 24px;
          width: 24px;
          border-radius: 50%;
          background: #ffb323;
          text-align: center;
        }

        i {
          color: #ffffff;
        }
      }

      .btn-box {
        width: 100%;
        justify-content: flex-end;
        display: flex;
      }
    }
  }
}

.catalog-comment-wrapper {
  margin-top: 20px;
  display: flex;

  .right-box {
    margin-left: 16px;
    width: 300px;
  }

  .left-box {
    flex: 1;

    .content-wrapper {
      padding: 16px;
    }
  }
}

.edit-note {
  background: transparent;
  color: @color;
  position: absolute;
  right: 0;
  top: 50%;
  cursor: pointer;
  padding: 6px 4px;
  border-radius: 2px 0px 0px 2px;

  .icon {
    width: 1.5em;
    height: 1.5em;

    &:hover {
      color: #1268ab;
    }
  }

}

.edit-note:hover:after {
  position: absolute;
  font-size: 12px;
  left: 35px;
  top: 10px;
  //background-color: #f2f2f2;
  //border-radius: 5px;
  color: #999999;
  content: attr(title);
  z-index: 2;
  white-space: nowrap;
  //width: auto;
}

.note-timeline-card {
  cursor: default;

  &:hover .head {
    color: @color;
  }

  &:hover {
    box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 12%);
  }
}
</style>
