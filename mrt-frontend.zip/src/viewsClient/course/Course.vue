<template>
  <div class="course">
    <el-row>
      <section class="container">
        <!-- 面包屑导航 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
          <el-breadcrumb-item :to="{ path: '/client/allCourse' }"
          >全部课程
          </el-breadcrumb-item
          >
          <el-breadcrumb-item :to="{ path: '/client/course/2' }"
          >护理课程
          </el-breadcrumb-item
          >
        </el-breadcrumb>
        <chapter-block :obj="chapterObj"></chapter-block>
      </section>
    </el-row>
    <!-- 主体 -->
    <el-row class="container main" justify="space-between" type="flex">
      <el-col class="left-box">
        <el-menu
          :default-active="activeIndex"
          class="el-menu-demo"
          mode="horizontal"
          @select="handleSelect"
        >
          <el-menu-item :class="{ actived: activeIndex == 1 }" index="1"
          >课程简介
          </el-menu-item
          >
          <el-menu-item :class="{ actived: activeIndex == 2 }" index="2"
          >课程目录
          </el-menu-item
          >
          <el-menu-item :class="{ actived: activeIndex == 3 }" index="3"
          >课程评价
          </el-menu-item
          >
        </el-menu>
        <!-- 课程介绍 -->
        <div v-show="activeIndex == 1" class="course-introd">
          <strip-title
            font="20px"
            name="课程简介"
            style="margin-top: 40px"
          ></strip-title>
          <div v-html="chapterObj.brief"></div>
        </div>
        <!--  课程目录-->
        <div v-show="activeIndex == 2" class="course-catalog">
          <sub-title
            :img="require('@/assets/images/catalog-icon.png')"
            style="margin-bottom: 20px; height: 54px; line-height: 54px"
            title="课程目录"
            @goMore="goMore"
          ></sub-title>
          <chapter-catalog
            v-for="(i, index) in chapterObj.chapterList"
            :key="i.id"
            :chapterNo="index"
            :obj="i"
          ></chapter-catalog>
        </div>
        <!-- 课程评分 -->
        <div v-if="activeIndex == 3" class="course-score">
          <div class="comment-top">
            <div class="all-score-box">
              <div class="font-green all-score">{{ percentage }}</div>
              <div>
                <small>好评度</small>
              </div>
            </div>
            <div class="radio-select">
              <el-button
                :class="{ 'active-score': evalType == -1 }"
                type="text"
                @click="changeScoreType(-1)"
              >全部({{
                  scoreList[0].num + scoreList[1].num + scoreList[2].num
                }})
              </el-button
              >
              <el-button
                v-for="(i, index) in scoreList"
                :key="index"
                :class="{ 'active-score': evalType == i.evalType }"
                type="text"
                @click="changeScoreType(i.evalType)"
              >
                <span>{{ i.name }}({{ i.num }})</span>
              </el-button>
            </div>
          </div>
          <div class="comment-box">
            <course-comment
              v-for="i in commentList"
              :key="i.id"
              :obj="i"
              class="comment-item"
            ></course-comment>
          </div>
          <el-row class="pages" justify="center" type="flex">
            <el-pagination
              :hide-on-single-page="true"
              :page-size="pageSize"
              :total="commentTotal"
              background
              layout="prev, pager, next"
              @current-change="handleCurrentChange"
            ></el-pagination>
          </el-row>
        </div>
      </el-col>
      <el-col class="right-box">
        <introd-block
          class="class-doctor"
          style="width: 358px"
          @click="toTeacherCenter"
        >
          <template v-slot:header>
            <sub-title
              style="margin-left: 24px"
              title="授课名师"
              @goMore="goMore"
            >
              <template v-slot:preIcon>
                <i class="iconfont iconbailing"></i>
              </template>
            </sub-title>
          </template>
          <template v-slot:main>
            <div class="main-content">
              <div class="img-box">
                <img :src="lecturer.img" alt/>
              </div>
              <div>
                <p>
                  <span class="doctor-name">{{ lecturer.name }}</span>
                  <span class="tag">{{ lecturer.majorName }}</span>
                </p>
                <p class="color999" style="font-size: 13px">
                  <span class="position">{{ lecturer.organizationName }}</span>
                  <span>{{ lecturer.organizationName }}</span>
                </p>
              </div>
            </div>
          </template>
        </introd-block>
        <div class style="height: 20px"></div>
        <introd-block style="width: 358px">
          <template v-slot:header>
            <sub-title
              style="margin-left: 24px"
              title="相关课程"
              @goMore="goMore"
            >
              <template v-slot:preIcon>
                <i class="iconfont iconyuangongpeixunjiludengji"></i>
              </template>
            </sub-title>
          </template>
          <template v-slot:main>
            <block-two
              v-for="(i, index) in relatedCourseList"
              v-show="index < 4"
              :key="i.courseId"
              :obj="i"
              class="block-two"
              flex="row"
              shadow="none"
              style="margin-bottom: 20px; border: none"
            ></block-two>
          </template>
        </introd-block>
      </el-col>
    </el-row>
    <!-- 评论 -->
    <el-row v-if="activeIndex == 3" class="container comment-score-box">
      <div class="card" shadow="none">
        <div class="img-box">
          <el-avatar :size="40" :src="clientUserObj.img"></el-avatar>
        </div>
        <div class="content">
          <div class="title-box">
            <span v-if="clientUserObj.name" class="title">{{
                clientUserObj.name
              }}</span>
            <span v-else class="title">匿名用户</span>
            <span>
              <el-rate v-model="score"></el-rate>
            </span>
          </div>
          <div class="comment-box">
            <div
              class="div-input input-comment"
              contenteditable
              placeholder="请输入内容"
            ></div>
            <span>
              <i class="iconfont iconicon_xiaolian_12x"></i>
            </span>
          </div>
          <div class="btn-box">
            <el-button type="primary" @click="sendComment">发送</el-button>
          </div>
        </div>
      </div>
    </el-row>
  </div>
</template>
<script>
import ChapterBlock from '@/viewsClient/components/block/ChapterBlock'
import ChapterCatalog from '@/viewsClient/components/block/ChapterCatalog'
import IntroduBlock from '@/viewsClient/components/block/IntroduBlock.vue'
import SubTitle from '@/viewsClient/components/title/SubTitle.vue'
import StripIconTitleVue from '@/components/common/StripIconTitle.vue'
import CourseCommentVue from './components/CourseComment.vue'
import course from '@/viewsClient/course/components/course.js'

export default {
  mixins: [course],
  data () {
    return {}
  },
  components: {
    'chapter-block': ChapterBlock,
    'chapter-catalog': ChapterCatalog,
    'introd-block': IntroduBlock,
    'sub-title': SubTitle,
    'strip-title': StripIconTitleVue,
    'course-comment': CourseCommentVue
  },
  mounted () {
    // this.getCommentList(); //评论
  },
  methods: {
    goMore () {
      //
    },
    handleSelect (key, keyPath) {
      this.activeIndex = key.toString()
      // 跳到对应的视频信息
    },
    handleCurrentChange (val) {
      this.pageNum = val
      this.getCommentList()
    },
    toTeacherCenter () {
      this.$router.push(`/client/doctorCenter/${this.chapterObj.lecturerId}`)
    }
  }
}
</script>
<style lang="less" scoped>
.course {
  & > .el-row {
    &:first-child {
      background: #ffffff;
      border-top: 1px solid #eeeeee;
      padding-left: 32px !important;

      .el-breadcrumb {
        height: 60px;
        line-height: 60px;

        /deep/ .el-breadcrumb__inner {
          color: #999999;
          font-weight: bold;
        }

        .el-breadcrumb__item {
          &:last-child {
            /deep/ .el-breadcrumb__inner {
              color: @color;
            }
          }
        }
      }
    }
  }

  .main {
    margin-top: 20px;
    margin-bottom: 58px;

    .el-col {
      padding: 16px 28px;

      &:first-child {
        background: #ffffff;
        max-width: 1020px;

        .actived {
          font-size: 18px;
          font-weight: bold;
        }

        .sub-title {
          border-bottom: 1px solid #eeeeee;
        }

        .comment-top {
          margin-top: 40px;
          padding: 0 40px;
          height: 70px;
          display: flex;
          justify-content: flex-start;
          align-items: center;
          background: #f7f7f7;

          .all-score-box {
            width: 65px;
            margin-right: 58px;

            .all-score {
              font-size: 30px;
            }

            div {
              text-align: center;
              margin-top: -4px;
            }
          }

          .radio-select {
            button {
              color: #222222;
              margin-right: 58px;
              font-size: 16px;
            }

            .active-score {
              color: @color;
            }
          }
        }

        .comment-box {
          padding: 30px 0;

          .comment-item {
            margin-bottom: 40px;
          }
        }
      }

      &:last-child {
        width: 358px;
        margin-left: 22px;
        padding: 0 !important;

        .class-doctor {
          /deep/ .header {
            height: 60px;
            line-height: 60px;
          }

          .main-content {
            display: flex;
            justify-content: flex-start;
            align-items: center;

            .img-box {
              height: 100px;
              width: 120px;
              margin-right: 15px;
              border-radius: 4px;
            }

            .doctor-name {
              font-size: 18px;
              font-weight: bold;
            }
          }
        }
      }
    }
  }

  .comment-score-box {
    margin-bottom: 20px;

    .card {
      box-sizing: border-box;
      padding: 12px 20px !important;
      width: 1020px;
      display: flex;
      justify-content: flex-start;
      border: 1px solid #eeeeee;
      background: #ffffff;
      border-radius: 4px;

      .img-box {
        margin-right: 24px;
      }

      .content {
        width: 100%;
        margin-bottom: 10px;

        .title-box {
          display: flex;
          justify-content: flex-start;
          align-items: center;
          margin-bottom: 20px;

          .title {
            margin-right: 20px;
            font-weight: bold;
          }
        }

        .comment-box {
          position: relative;
          width: 100%;
          margin-bottom: 20px;
          border: 1px solid #eeeeee;
          border-radius: 2px;

          .input-comment {
            width: 100%;
            padding: 17px 10px 30px 10px;
          }

          span {
            position: absolute;
            bottom: 5px;
            left: 5px;
            height: 24px;
            line-height: 24px;
            width: 24px;
            border-radius: 50%;
            background: #ffb323;
            text-align: center;
          }

          i {
            color: #ffffff;
          }
        }

        .btn-box {
          width: 100%;
          justify-content: flex-end;
          display: flex;

          button {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 108px;
            height: 36px;
            font-size: 16px;
          }
        }
      }
    }
  }
}
</style>
