<template>
  <section v-loading="!state.loadingEnd">
    <div v-for="(item,index) in state.list" :key="item.id" class="course-comment">
      <div class="head-img">
        <el-avatar :size="40" :src="item['staffAvatar']"></el-avatar>
      </div>
      <div class="right-box">
        <el-row>
          <span class="name">{{ item['nickName'] || item['staffName'] }}</span>
        </el-row>
        <p :id="'comment'+index" class="comment" v-html="item.content"></p>
        <!--        {{ isOverFlow(index) }}-->
        <!--        <div :id="'more'+index" class="primary-color padding-end more-wrapper"-->
        <!--             style="text-align: right">-->
        <!--          <small class="more-show" @click="showMore">更多</small>-->
        <!--        </div>-->
        <p class="date color999">
          <small>发表于&nbsp;&nbsp;{{ $tools.formatTime(item.created, 'YY-MM-DD hh:mm:ss') }}</small>
          <span><icon-font :name="'#icon-icon'"></icon-font></span>
        </p>
      </div>
    </div>
    <div class="flex justify-content margin-top">
      <el-pagination v-if="state.total>1" :page-size="state.limit" :page-sizes="[20,50,100]"
                     :total="state.total"
                     background
                     class="margin-top"
                     layout="total,sizes,prev, pager, next,jumper"
                     @size-change="handleSizeChange"
                     @current-change="currentChange"></el-pagination>
    </div>
  </section>
  <null-back v-if="state.loadingEnd && state.list?.length===0" style="height: 200px">暂时没有任何留言，抢个沙发吧～</null-back>
</template>

<script lang="ts" setup>
import { defineProps, nextTick, onMounted, reactive } from 'vue'
import tools from '@/utils/tool'
import IconFont from '@/components/IconFont.vue'
import NullBack from '@/viewsClient/components/NullBack.vue'

const props = defineProps(['url', 'courseId'])
const state = reactive({
  total: 1,
  limit: 50,
  offset: 0,
  list: [],
  loadingEnd: false
})

const initData = async () => {
  const result = await tools.clientPost(props.url, {
    limit: state.limit,
    offset: state.offset,
    where: { course_id: { _eq: props.courseId } }
  })
  state.total = result.total
  state.list = result.list
  state.loadingEnd = true
}

const handleSizeChange = (val) => {
  state.limit = val
  initData()
}

const showMore = (index) => {
  // 只显示应该显示的那部分
}

const currentChange = (val) => {
  state.offset = state.limit * (val - 1)
  initData()
}

const isOverFlow = async (index): Promise<boolean> => {
  const flag: any = await nextTick(() => {
    const dom: any = document.getElementById('comment' + index)
    // const moreDom: any = document.getElementById('show' + index)
    // console.log('===>>>moreDom', moreDom, dom.offsetHeight > 60)
    // moreDom.style.display = dom.offsetHeight > 60 ? 'block' : 'none'
    return dom.offsetHeight > 60
  })
  return flag
}

onMounted(() => {
  initData()
})
</script>

<style lang="less" scoped>
@import (once) "~@/assets/css/client.less";

.course-comment {
  width: 100%;
  display: flex;
  justify-content: flex-start;
  align-content: space-between;
  padding: 10px;

  .head-img {
    display: flex;
    justify-content: flex-start;
    align-items: flex-start;
    margin-right: 20px;
    box-sizing: border-box;
    margin-top: 8px;
  }

  .right-box {
    width: inherit;

    .name-box {
      margin: 0;
    }

    .name {
      font-size: 14px;
      font-weight: bold;
      margin-right: 15px;
    }

    .comment {
      font-size: 14px;
      //.ellipsis-num(3)
    }

    .more-show {
      cursor: default;

      &:hover {
        border-bottom: 1px sloid @color;
      }
    }

    .date {
      width: 100%;
      display: flex;
      justify-content: space-between;
    }
  }
}
</style>
