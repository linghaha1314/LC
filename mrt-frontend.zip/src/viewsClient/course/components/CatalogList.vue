<template>
  <div v-for="(i, index) in chapters" :key="i['id']" style="width:100%">
    <div v-if="i.children && i['children'].length > 0" class="chapter-title ellipsis">
      <strip-title>第{{ index + 1 }}章&nbsp;&nbsp;{{ i.name }}</strip-title>
    </div>
    <ul v-if="i.children.length > 0" class="padding-start">
      <li v-for="(dd, index) in i.children" :key="index"
          :class="{ 'active-li': dd.id === currentChapterId, 'completed': dd.isRealCompleted }"
          @click="changeSource(dd)">
        <div>{{ dd.name }}</div>
        <small class="color999">
          <span v-if="dd.completed">完成</span>
          <span v-else-if="!dd.completed">待学习</span>
          <span v-else>学习中{{ dd.completedRate }}%</span>
        </small>
      </li>
    </ul>
    <!--章节显示-->
    <ul v-if="!i.children || i.children.length === 0" class="padding-start">
      <li :class="{ 'active-li': i.id === currentChapterId }" @click="changeSource(i)">
        <div>{{ i.name }}</div>
        <small class="color999">
          <span v-if="i.completed">完成</span>
          <span v-else-if="!i.completed && i.completedRate">已学习{{ i.completedRate }}%</span>
          <span v-else>待学习</span>
        </small>
      </li>
    </ul>
  </div>
  <el-dialog v-model="isShowFiles" destroy-on-close custom-class="file-view-dialog">
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>附件查看</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <div>
      <iframe v-if="source" :src="source" style="width: 100%;height: 64vh" frameborder="0"></iframe>
    </div>
  </el-dialog>
</template>

<script lang="ts" setup="props,{emit}">
import { defineComponent, ref, defineEmits, defineProps } from 'vue'
import StripTitle from '@/components/StripTitle.vue'
import store from '@/store'
import { Buffer } from 'buffer'
import tools from '@/utils/tool'

defineComponent({
  StripTitle
})
defineProps({
  chapters: {
    type: Array as unknown as any,
    default: () => [] as any[]
  },
  currentChapterId: {
    type: [String],
    default: ''
  }
})

const isShowFiles = ref(false)

const source: any = ref('')

const emit = defineEmits(['changeChapter'])
const changeSource = async (val: any) => {
  if (!store.state.clientUserInfo) {
    store.commit('setClientShowLoginDialog', true)
    return
  }
  const dom: any = document.querySelector('#client')
  dom.scroll(0, 0)
  emit('changeChapter', val)
}
</script>

<style lang="less" scoped>
@import (once) "~@/assets/css/client.less";

li {
  margin: 16px 0;
  padding: 10px 16px;
  background: #f2f2f2;
  border-radius: 20px;
  box-sizing: border-box;
  display: flex;
  cursor: default;
  justify-content: space-between;
}

.active-li {
  background: @color;
  color: #ffffff;
}

.completed {
  background: #34b68c;
  color: #ffffff;
}
</style>
<style lang="less">
.file-view-dialog {
  width: 80%;
  margin-top: 10vh;
  padding: 0px;

  .el-dialog__body {
    padding: 0;
  }
}
</style>
