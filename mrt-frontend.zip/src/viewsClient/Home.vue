<template>
  <div class="home">
    <section>
      <el-carousel v-loading="state.bannerList.length===0">
        <el-carousel-item v-for="item in state.bannerList" :key="item['id']">
          <img :onerror="$tools.imgError(item['link'])"
               :src="item['link']" alt="" style="width: 100%;height: 100%;object-fit: cover"/>
        </el-carousel-item>
      </el-carousel>
    </section>
    <div class="container margin-bottom">
      <section>
        <strip-title class="margin-top margin-bottom">热点推送
          <!--          <template v-slot:right>-->
          <!--            <span class="color666 font-bold padding-end more-hover" @click="goMore"><small>更多>></small></span>-->
          <!--          </template>-->
        </strip-title>
        <el-tabs v-model="activeName" class="demo-tabs" @tab-click="changeActiveName">
          <el-tab-pane class="flex flex-wrap align-center" label="疫情防控" name="1">
            <type-block v-for="dd in state.basicList" :key="dd.id" :img="dd.img" :width="220"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title><p class="margin-bottom"><small>最新最全详解，打开医学大门</small></p></template>
              <template v-slot:content>
                <small>高品质教学资源,独家精品课程在线观看（禁止分享）</small>
              </template>
            </type-block>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="热门名师" name="2">
            <teacher-card v-for="item of state.teacherData['list']" :key="item"
                          :teacher="{...item,...item['staffData']}"
                          class="margin-start margin-bottom"
                          @click="$tools.go(`/client/doctorCenter/${item.id}`)"></teacher-card>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="大家都在看" name="3">
            <type-block v-for="dd in state.scoreList" :key="dd" :img="dd.img" :width="224"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <p><small>最新最全详解，打开医学大门</small></p>
                <p><small>侯老师</small></p>
              </template>
              <template v-slot:content>
                <el-row>
                  <el-col :span="12"><small>14看过</small></el-col>
                  <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>
                </el-row>
              </template>
            </type-block>
          </el-tab-pane>
        </el-tabs>
      </section>
      <!--      <section>-->
      <!--        <el-card class="margin-top">-->
      <!--          <ul class="flex">-->
      <!--            <li class="font-bold flex align-center nowrap">合作机构 <span class="color999">&nbsp;-->
      <!--            </span></li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/beijing-university.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/nanjin.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/zhejiang.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/wuhan.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/beijing-university.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/nanjin.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--            <li class="margin-start margin-end" style="height: 30px;">-->
      <!--              <img-->
      <!--                alt=""-->
      <!--                src="../assets/images/client/zhejiang.png"-->
      <!--                style="height: 100%;"/>-->
      <!--            </li>-->
      <!--          </ul>-->
      <!--        </el-card>-->
      <!--      </section>-->
      <!--      <section>-->
      <!--        <strip-title class="margin-top margin-bottom">名师推荐</strip-title>-->
      <!--        <div class="flex flex-wrap">-->
      <!--          <teacher-card v-for="item of state.teacherData['list']" :key="item" :teacher="{...item,...item['staffData']}"-->
      <!--                        class="margin-start margin-bottom"-->
      <!--                        @click="$tools.go(`/client/doctorCenter/${item.id}`)"></teacher-card>-->
      <!--        </div>-->
      <!--      </section>-->
      <section>
        <strip-title class="margin-top margin-bottom">热门排行榜</strip-title>
        <div class="flex justify-between">
          <rankings-block v-for="item in [1,2,3]" :key="item" :list="state.rankingList"
                          class="margin-start">
            <span v-if="item===1">
                          热🔥门排行榜<small>&nbsp;TOP50</small>
            </span> <span v-if="item===2">
            新课排行榜<small>&nbsp;TOP50</small>
            </span> <span v-if="item===3">
                          五星好评榜
            </span>
          </rankings-block>
        </div>
      </section>
      <section>
        <strip-title class="margin-top margin-bottom">教育/培训</strip-title>
        <el-tabs v-model="activeName" class="demo-tabs" @tab-click="changeActiveName">
          <el-tab-pane class="flex flex-wrap align-center" label="职工教育" name="1">
            <type-block v-for="dd in state.basicList" :key="dd.id" :img="dd.img" :width="220"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title><p class="margin-bottom"><small>最新最全详解，打开医学大门</small></p></template>
              <template v-slot:content>
                <small>高品质教学资源,独家精品课程在线观看（禁止分享）</small>
              </template>
            </type-block>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="郑医党校" name="2">
            <teacher-card v-for="item of state.teacherData['list']" :key="item"
                          :teacher="{...item,...item['staffData']}"
                          class="margin-start margin-bottom"
                          @click="$tools.go(`/client/doctorCenter/${item.id}`)"></teacher-card>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="郑医团校" name="3">
            <type-block v-for="dd in state.scoreList" :key="dd" :img="dd.img" :width="224"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <p><small>最新最全详解，打开医学大门</small></p>
                <p><small>侯老师</small></p>
              </template>
              <template v-slot:content>
                <el-row>
                  <el-col :span="12"><small>14看过</small></el-col>
                  <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>
                </el-row>
              </template>
            </type-block>
          </el-tab-pane>
        </el-tabs>
      </section>
      <section>
        <strip-title class="margin-top margin-bottom">学员教育</strip-title>
        <el-tabs v-model="activeName" class="demo-tabs" @tab-click="changeActiveName">
          <el-tab-pane class="flex flex-wrap align-center" label="师资培训" name="1">
            <type-block v-for="dd in state.basicList" :key="dd.id" :img="dd.img" :width="220"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title><p class="margin-bottom"><small>最新最全详解，打开医学大门</small></p></template>
              <template v-slot:content>
                <small>高品质教学资源,独家精品课程在线观看（禁止分享）</small>
              </template>
            </type-block>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="郑医党校" name="2">
            <teacher-card v-for="item of state.teacherData['list']" :key="item"
                          :teacher="{...item,...item['staffData']}"
                          class="margin-start margin-bottom"
                          @click="$tools.go(`/client/doctorCenter/${item.id}`)"></teacher-card>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="郑医团校" name="3">
            <type-block v-for="dd in state.scoreList" :key="dd" :img="dd.img" :width="224"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <p><small>最新最全详解，打开医学大门</small></p>
                <p><small>侯老师</small></p>
              </template>
              <template v-slot:content>
                <el-row>
                  <el-col :span="12"><small>14看过</small></el-col>
                  <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>
                </el-row>
              </template>
            </type-block>
          </el-tab-pane>
        </el-tabs>
      </section>
      <section>
        <strip-title class="margin-top margin-bottom">成长中心</strip-title>
        <el-tabs v-model="activeName" class="demo-tabs" @tab-click="changeActiveName">
          <el-tab-pane class="flex flex-wrap align-center" label="基础课程" name="1">
            <type-block v-for="dd in state.basicList" :key="dd.id" :img="dd.img" :width="220"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title><p class="margin-bottom"><small>最新最全详解，打开医学大门</small></p></template>
              <template v-slot:content>
                <small>高品质教学资源,独家精品课程在线观看（禁止分享）</small>
              </template>
            </type-block>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="热门名师" name="2">
            <teacher-card v-for="item of state.teacherData['list']" :key="item"
                          :teacher="{...item,...item['staffData']}"
                          class="margin-start margin-bottom"
                          @click="$tools.go(`/client/doctorCenter/${item.id}`)"></teacher-card>
          </el-tab-pane>
          <el-tab-pane class="flex flex-wrap align-center" label="学分必修" name="3">
            <type-block v-for="dd in state.scoreList" :key="dd" :img="dd.img" :width="224"
                        class="margin-start margin-bottom"
                        @click="$tools.go(`/client/coursePlay/${dd.id}`)">
              <template v-slot:title>
                <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>
              </template>
              <template v-slot:sub-title>
                <p><small>最新最全详解，打开医学大门</small></p>
                <p><small>侯老师</small></p>
              </template>
              <template v-slot:content>
                <el-row>
                  <el-col :span="12"><small>14看过</small></el-col>
                  <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>
                </el-row>
              </template>
            </type-block>
          </el-tab-pane>
        </el-tabs>
      </section>
      <!--      <section>-->
      <!--        <strip-title class="margin-top margin-bottom">编辑推荐</strip-title>-->
      <!--        <div class="flex flex-wrap align-center">-->
      <!--          <type-block v-for="dd in state.list" :key="dd.id" :img="dd.img" :width="220"-->
      <!--                      class="margin-start margin-bottom"-->
      <!--                      @click="$tools.go(`/client/coursePlay/${dd.id}`)">-->
      <!--            <template v-slot:title>-->
      <!--              <span style="height:45px"><span class="tag">中医文科</span>&nbsp;{{ dd.name }}</span>-->
      <!--            </template>-->
      <!--            <template v-slot:sub-title>-->
      <!--              <p><small>经验丰富名师讲学，学习永无止境</small></p>-->
      <!--              <p><small>侯老师</small></p>-->
      <!--            </template>-->
      <!--            <template v-slot:content>-->
      <!--              <el-row>-->
      <!--                <el-col :span="12"><small>14看过</small></el-col>-->
      <!--                <el-col :span="12" style="text-align: right"><small>123参加</small></el-col>-->
      <!--              </el-row>-->
      <!--            </template>-->
      <!--          </type-block>-->
      <!--        </div>-->
      <!--      </section>-->
    </div>
  </div>
</template>
<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import StripTitle from '@/components/StripTitle.vue'
import TeacherCard from '@/viewsClient/components/block/TeacherCard.vue'
import RankingsBlock from '@/viewsClient/components/block/RankingsBlock.vue'
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'
import tools from '@/utils/tool'
import type { TabsPaneContext } from 'element-plus'

const activeName = ref('1')
const getBannerList = async () => {
  const result = await tools.clientGet('/swiper/getListByPage')
  state.bannerList = result.list
}
const state = reactive({
  bannerList: [],
  list: [],
  hotList: [],
  basicList: [],
  scoreList: [],
  rankingList: [],
  teacherData: {}
})
const changeActiveName = (tab: TabsPaneContext, event: Event) => {
  console.log(state.list)
}
const goMore = () => {
  //
}
const getAllCourse = () => {
  tools.clientGet('/api/rest/course/getListByPage').then(r => {
    state.hotList = r.data.list
    state.list = r.data.list.slice(0, 15)
    state.basicList = r.data.list.slice(0, 5)
    state.scoreList = r.data.list.slice(0, 4)
    state.rankingList = r.data.list
  })
}

onMounted(
  () => {
    getBannerList()
    getAllCourse()
    tools.clientGet('/api/rest/lecturer/getLecturerByPage', {}).then(r => {
      state.teacherData = r.data
    })
  }
)
</script>
<style lang="less">
.home {
  width: 100%;
}

.more-hover {
  color: #1edfaf;

  &:hover {
    color: #63b7cf;
    cursor: default;
  }
}
</style>
