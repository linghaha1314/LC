<template>
  <iframe :src="source.src" style="width: 100%;height: 100vh" frameborder="0"></iframe>
</template>
<script  lang="ts" setup>
import { defineProps, reactive } from 'vue'
import { Buffer } from 'buffer'
import router from '@/router'
defineProps({
  src: {
    type: String,
    default: router.currentRoute.value.query.path
  }
})
const initData = () => {
  const url = (window.location.protocol + '//' + window.location.host) || 'http://117.159.24.46:3001'
  console.log(url + router.currentRoute.value.query.path)

  return 'http://116.63.185.184:8012/onlinePreview?url=' + encodeURIComponent(Buffer.from(url + router.currentRoute.value.query.path).toString('base64'))
}

const source: any = reactive({ src: initData() })

</script>
<style>
</style>
