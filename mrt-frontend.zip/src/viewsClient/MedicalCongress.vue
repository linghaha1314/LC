<template>
  <!-- 医学会议 -->
  <el-container class="medical-congress">
    <el-main>
      <el-row type="flex" justify="space-between" align="middle">
        <medical-block v-for="i in 6" :key="i"></medical-block>
      </el-row>
    </el-main>
    <el-footer>
      <el-row type="flex" justify="center" align="middle">
        <el-pagination background layout="prev, pager, next" :total="1000"></el-pagination>
      </el-row>
    </el-footer>
  </el-container>
</template>
<script>
import MedicalBlock from '@/viewsClient/components/block/MedicalBlock'
export default {
  data () {
    return {}
  },
  components: {
    MedicalBlock
  }
}
</script>
<style lang="less" scoped>
.medical-congress {
  padding-bottom: 44px;
  .el-main {
    background: #ffffff;
    padding: 20px 68px;
    margin: 20px 0 30px 0;
    .el-row {
      flex-wrap: wrap;
      .medical-block {
        margin-top: 20px;
      }
    }
  }
}
</style>
