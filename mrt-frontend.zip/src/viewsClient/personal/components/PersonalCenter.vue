<template>
  <div class="personal-center">
    <div class="personal-message">
      <p class="font-bold font20">个人信息</p>
      <el-card class="card-box" shadow="hover">
        <div
          class="personal-row flex align-center back-fff"
          style="height:180px;"
        >
          <div class="margin-end">
            <img :onerror="$tools.imgError(store.state.clientUserInfo['avatar'])"
                 :src="store.state.clientUserInfo['avatar'] || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
                 alt
                 style="height: 80px;width: 80px;border-radius: 50%"/>
          </div>
          <div class="nick-name margin-start">
            <p style="font-weight:500;font-size:16px">{{
                state.userInfo['nickName'] || state.userInfo['name']
              }}<small>（{{ state.userInfo['name'] }}）</small><span>&nbsp;{{ state.userInfo['organizationName'] }}</span>
            </p>
            <p style="font-weight:500;font-size:16px;display:flex;align-items:center;">
              <span>{{ state.userInfo['staffTypeName'] }}</span>
              <img alt src="@/assets/images/member-icon.png"/>
              <span>{{ state.userInfo['positionName'] }}</span>
            </p>
          </div>
          <!--          <div><p>姓名：{{ state.userInfo['name'] }}</p>-->
          <!--            <p>姓名：{{ state.userInfo['name'] }}</p></div>-->
        </div>
      </el-card>
    </div>
    <div class="study-data">
      <p class="font-bold font20">学习数据</p>
      <el-row align="middle" class="content-box" justify="start" type="flex">
        <el-col :span="11">
          <el-card class="card-box" shadow="hover">
            <ul>
              <li>
                <p>观看课程</p>
                <p>
                  <span class="font-green font28">{{ state.studyData.watchNumber }}</span>
                  <small>节</small>
                </p>
              </li>
              <li>
                <p>观看时长</p>
                <p>
                  <span v-if="getHm(state.studyData['totalTime']).h"><span class="font-green font28">{{
                      getHm(state.studyData['totalTime']).h
                    }}</span><small>时</small></span>
                  <span v-if="getHm(state.studyData['totalTime']).m || !getHm(state.studyData['totalTime']).h">
                    <span class="font-green font28">{{
                        getHm(state.studyData['totalTime']).m
                      }}</span><small>分</small></span>
                </p>
              </li>
              <li>
                <p>已留言</p>
                <p>
                  <span class="font-green font28">{{ state.studyData.commentNumber }}</span>
                  <small>条</small>
                </p>
              </li>
            </ul>
          </el-card>
        </el-col>
        <el-col :span="2"></el-col>
        <el-col :span="11">
          <el-card class="card-box" shadow="hover">
            <ul>
              <li>
                <p>今日学习</p>
                <p>
                  <span class="font-green font28">{{ state.studyData['todayTime'] }}</span>
                  <small>分钟</small>
                </p>
              </li>
              <li>
                <p>坚持学习</p>
                <p>
                  <span v-if="getHm(state.studyData['totalTime']).h"><span class="font-green font28">{{
                      getHm(state.studyData['totalTime']).h
                    }}</span><small>时</small></span>
                  <span v-if="getHm(state.studyData['totalTime']).m || !getHm(state.studyData['totalTime']).h">
                    <span class="font-green font28">{{
                        getHm(state.studyData['totalTime']).m
                      }}</span><small>分</small></span>
                </p>
              </li>
              <li>
                <p>累计学分</p>
                <p>
                  <span class="font-green font28">{{ state.credits || 0 }}</span>
                  <small>分</small>
                </p>
              </li>
            </ul>
          </el-card>
        </el-col>
      </el-row>
    </div>
    <div class="phone">
      <p class="font-bold font20">我的证书</p>
      <el-card v-loading="state.certLoading" class="card-box" shadow="hover">
        <p class="font-green">学习证书发放 <small style="color:#c5c5c5">（完成课程获取证书）</small></p>
        <p v-for="item in state.certList" :key="item.id" class="inline-block margin-start">
          <el-button type="primary" @click="downloadCert(item)">{{ item['courseName'] }}</el-button>
        </p>
        <p v-if="state.certList.length===0" class="margin-bottom padding-bottom">
          <null-back justify="flex-start">暂无证书,赶快去学习吧</null-back>
        </p>
      </el-card>
    </div>
    <div class="phone">
      <p class="font-bold font20">手机号码</p>
      <el-card class="card-box" shadow="hover">
        <p class="font-green">暂无绑定手机号码</p>
        <p>
          <small style="color:#c5c5c5">*您的手机号码有助于我们后续通过短信方式及时反馈您课程信息，未经授权不会公开，请放心</small>
        </p>
        <el-button size="small" type="primary">新增</el-button>
      </el-card>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from 'vue'
import store from '@/store'
import tools from '@/utils/tool'
import NullBack from '@/viewsClient/components/NullBack.vue'

declare global {
  interface Window {
    PizZipUtils: any;
    PizZip: any;
    docxtemplater: any;
  }
}

const state = reactive({
  userInfo: store.state.clientUserInfo,
  credits: 0,
  checked: true,
  certList: [],
  certLoading: false,
  certPath: '',
  studyData: {
    watchNumber: 0,
    todayTime: 0,
    totalTime: 0,
    commentNumber: 0
  }
})

// const loadFile = (url, callback) => {
//   tools.loadScript('https://unpkg.com/pizzip@3.1.1/dist/pizzip-utils.js').subscribe(r => {
//     if (r) {
//       window.PizZipUtils.getBinaryContent(url, callback)
//     }
//   })
// }

// const downloadCert = (item: any) => {
//   // 下载证书
//   const loading = tools.showLoading()
//   try {
//     tools.loadScript('https://unpkg.com/pizzip@3.1.1/dist/pizzip.js').subscribe(r => {
//       if (r) {
//         tools.loadScript('http://cdn.kbmrt.cn/resourceJs/docxtemplater.min.js').subscribe(rr => {
//           if (rr) {
//             loadFile(
//               state.certPath,
//               (error, content) => {
//                 if (error) {
//                   throw error
//                 }
//                 const zip = new window.PizZip(content)
//                 let doc: any
//                 try {
//                   // eslint-disable-next-line new-cap
//                   doc = new window.docxtemplater(zip, {
//                     paragraphLoop: true,
//                     linebreaks: true
//                   })
//                 } catch (e) {
//                   tools.msgError(e)
//                   tools.closeLoading(loading)
//                 }
//                 doc.render({
//                   name: store.state.clientUserInfo.name,
//                   title: item.courseName,
//                   typeName: item.name || '未定义',
//                   date: tools.formatTime(item.created)
//                 })
//                 const out = doc.getZip().generate({
//                   type: 'blob',
//                   mimeType:
//                     'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
//                   compression: 'DEFLATE'
//                 })
//                 const downloadElement = document.createElement('a')
//                 // 创建下载的链接
//                 const href = window.URL.createObjectURL(out)
//                 downloadElement.href = href
//                 console.log('--->>??href', out) // 存储成后端文件
//                 // // 下载后文件名
//                 // downloadElement.download = item.courseName || '证书'
//                 // document.body.appendChild(downloadElement)
//                 // // 点击下载
//                 // downloadElement.click()
//                 // // 下载完成移除元素
//                 // document.body.removeChild(downloadElement)
//                 // // 释放掉blob对象
//                 // window.URL.revokeObjectURL(href)
//                 // tools.closeLoading(loading)
//               })
//           }
//         })
//       }
//     })
//   } catch (e) {
//     tools.msgError(e)
//     tools.closeLoading(loading)
//   }
// }

const downloadCert = (item) => {
  const downloadElement = document.createElement('a')
  downloadElement.href = item.path
  downloadElement.download = item.courseName + '学习证书.doc' || '证书.doc'
  document.body.appendChild(downloadElement)
  downloadElement.click()
  document.body.removeChild(downloadElement)
}

const getCredits = () => {
  state.certLoading = true
  tools.clientGet('/staffCredits/getCreditsRecordByStaffId', {
    limit: 20,
    offset: 0,
    staffId: store.state.clientUserInfo.id
  }).then(r => {
    let sum = 0
    r.list.forEach(res => {
      sum += res.credits
    })
    state.credits = sum
    state.certList = r.list
    state.certLoading = false
  })
}

const getCert = async () => {
  await tools.clientGet('/cert/getListByPage', { sort: 'sequence desc,status desc' }).then(r => {
    state.certPath = r.list[0].path
  })
}

const getHm = (time) => {
  const h = Math.floor(time / 60)
  const m = Math.ceil(time % 60)
  return {
    h,
    m
  }
}

onMounted(async () => {
  tools.loadScript('https://unpkg.com/pizzip@3.1.1/dist/pizzip.js').subscribe(r => {
    if (r) {
      //
    }
  })
  getCredits()

  await getCert()

  const date = tools.formatTime('')

  tools.clientPost('/api/rest/watchRecord/getStudyTime', {
    staffId: store.state.clientUserInfo.id,
    date: date
  }).then(r => {
    const data = r.data
    state.studyData.todayTime = Math.ceil((data.todayData.aggregate.sum.studyTime || 0) / 60) || 0
    state.studyData.totalTime = Math.round((data.totalData.aggregate.sum.studyTime || 0) / 60) || 0
  })

  tools.clientPost('/watchRecord/getStaffWatchListByPage', {
    limit: 20,
    offset: 0,
    where: { staff_id: { _eq: store.state.clientUserInfo.id } }
  }).then(r => {
    state.studyData.watchNumber = r.total
  })

  tools.clientPost('/comment/getCommentListByPage', {
    limit: 20,
    offset: 0,
    where: { staff_id: { _eq: store.state.clientUserInfo.id } }
  }).then(r => {
    state.studyData.commentNumber = r.total
  })
})

</script>

<style lang="less" scoped>
.personal-center {
  .font20 {
    font-size: 20px;
  }

  .personal-message {
    .card-box {
      padding-left: 30px;

      .personal-row {
      }
    }
  }

  .study-data {
    .card-box {
      ul {
        height: 180px;
        display: flex;
        justify-content: center;
        align-items: center;

        li {
          min-width: 120px;
        }
      }
    }
  }

  .phone {
    .card-box {
      padding: 0 40px;
    }
  }

  .el-dialog {
    color: #010101;

    .item-box {
      padding: 15px 0;

      span {
        &:first-child {
          font-weight: 500;
          white-space: nowrap;
        }

        &:last-child {
          color: #999999;
          margin-left: 30px;
          font-size: 14px;
        }
      }
    }

    .member-type {
      display: flex;
      justify-content: flex-start;

      .buy-card-box {
        display: flex;
        justify-content: space-between;
        align-items: center;

        .buy-card {
          margin-right: 16px;

          &:last-child {
            margin: 0;
          }
        }
      }
    }

    .scan-code-pay {
      display: flex;
      justify-content: center;
      align-items: center;
      max-width: 470px;
      margin: 0 auto;
      padding: 18px;
      border: 1px solid #eeeeee;

      .img-code {
        height: 120px;
        width: 120px;
        border-radius: 4px;
        border: 1px solid #eeeeee;
        padding: 10px;
        box-sizing: border-box;
        margin-right: 25px;

        img {
          object-fit: cover;
        }
      }

      .price {
        font-size: 28px;
      }
    }
  }

  .pay-after {
    display: flex;
    justify-content: center;
    align-items: center;
  }
}
</style>
