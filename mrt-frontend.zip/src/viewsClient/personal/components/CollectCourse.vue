<template>
  <div class="collect-course">
    <p class="font-bold">我收藏的课程
      <el-input v-model="state.queryParams.name" placeholder="课程名搜索" size="small" :suffix-icon="Search"
                style="width: 200px;margin-right: 16px" @input="search" clearable></el-input>
    </p>
    <div v-loading="loading" class="block-box flex" style="min-height:200px">
      <type-block v-for="dd in list" :key="dd" :img="dd.img" :width="186"
                  class="margin-start margin-end margin-bottom"
                  @click="$tools.go(`/client/coursePlay/${dd.courseId}`)">
        <template v-slot:title>
          <span class="flex title">
            <span class="tag" v-if="dd['typeName']">
              {{ dd['typeName'] }}
            </span>{{ dd.name }}
          </span>
        </template>
        <template v-slot:sub-title><small>
          <span v-if="dd['columnName']" class="color666">栏目：{{ dd['columnName'] }}</span>
        </small></template>
        <!--        <template v-slot:content>-->
        <!--          <small v-html="dd.introduce"></small>-->
        <!--        </template>-->
      </type-block>
    </div>

    <div v-if="state.total>0" class="padding-top padding-bottom align-center flex justify-content margin-top">
      <el-pagination
        :current-page="state.currentPage"
        :page-size="state.queryParams.limit"
        :page-sizes="[10,20,50,100]"
        :total="state.total"
        background
        layout="total,sizes,prev, pager, next,jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <null-back v-if="!loading && list.length===0" justify="center">暂无课程，赶快去收藏吧</null-back>
  </div>
</template>
<script lang="ts" setup>
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'
import { onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import NullBack from '@/viewsClient/components/NullBack.vue'
import { Search } from '@element-plus/icons-vue'

const state = reactive({
  currentPage: 1,
  searchData: '',
  queryParams: {
    limit: 20,
    offset: 0,
    name: ''
  },
  percentage: 20,
  customColor: '#409eff',
  total: 0,
  status: '2',
  list: []
})

const list = ref([])

const loading = ref(true)

const initData = async () => {
  const result = await tools.clientGet('/collectCourse/getDataListByPage', {
    staffId: store.state.clientUserInfo.id,
    ...state.queryParams,
    name: '%' + state.queryParams.name + '%'
  })
  loading.value = false
  list.value = result.list
  state.total = result.total
}

const handleSizeChange = (val) => {
  state.queryParams.limit = val
  initData()
}

const handleCurrentChange = (val) => {
  state.queryParams.offset = state.queryParams.limit * (val - 1)
  state.currentPage = val
  initData()
}

const search = (val) => {
  initData()
}
onMounted(() => {
  initData()
})
</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/commen.less";

.collect-course {
  .title {
    .ellipsis-num(2)
  }

  .font-bold {
    font-size: 20px;
    font-weight: bold;
  }

  .block-box {
    width: 892px;
    display: flex;
    flex-wrap: wrap;

    .block-two {
      width: 280px;
      margin-bottom: 26px;
    }
  }
}
</style>
