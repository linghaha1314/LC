<template>
  <div class="my-score-record">
    <p class="font-bold">我的学分</p>
    <div v-loading="loading" style="min-height:400px">
      <el-card v-for="i in state.list" :key="i.id" class="margin-bottom" shadow="none">
        <el-row class="tr-body">
          <el-col :span="6" class="img-desc flex column align-center"
                  @click="$tools.go(`/client/coursePlay/${i.courseId}`)">
            <!--            <img :src="i.courseData?.courseCover" alt style="width: 100%"/>-->
            <div class="font-bold padding-top padding-bottom">{{ i.courseData?.courseName }}</div>
          </el-col>
          <el-col :span="8">
            <el-divider direction="vertical"></el-divider>
            <span class="padding-start">{{ $tools.formatTime(i['created'], 'YY年MM月DD日hh:mm') }}</span>
          </el-col>
          <el-col :span="6">
            <el-divider direction="vertical"></el-divider>
            <span class="desc-text padding-start padding-end">获得学分
              <span class="font-bold primary-color" style="font-size: 18px">&nbsp;{{ i.credits }}&nbsp;</span>分
            </span>
          </el-col>
        </el-row>
      </el-card>
      <!-- 分页 -->
      <div class="flex justify-content margin-top margin-bottom padding-top" v-if="state.total>0">
        <el-pagination
          :current-page="state.currentPage"
          :page-size="queryParams.limit"
          :page-sizes="[10,20,50,100]"
          :total="state.total"
          background
          layout="total,sizes,prev, pager, next,jumper"
          @size-change="handleSizeChange"
          @current-change="currentChange"
        ></el-pagination>
      </div>
      <null-back style="min-height:300px" v-if="!loading && state.list.length===0" justify="center">暂无学分记录，赶快去学习吧
      </null-back>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import NullBack from '@/viewsClient/components/NullBack.vue'

const loading = ref(true)

const state = reactive({
  currentPage: 1,
  list: [],
  total: 0
})

const queryParams = reactive({
  limit: 20,
  offset: 0
})

const handleSizeChange = (val) => {
  queryParams.limit = val
  initData()
}

const currentChange = (val) => {
  queryParams.offset = queryParams.limit * (val - 1)
  state.currentPage = val
  initData()
}

const initData = () => {
  tools.clientPost('/api/rest/staffCredits/getDataByStaffId', {
    staffId: store.state.clientUserInfo.id,
    limit: queryParams.limit,
    offset: queryParams.offset
  }).then(r => {
    state.list = r.data.list
    state.total = r.data.totalData.total.count
    loading.value = false
  })
}

onMounted(() => {
  initData()
})
</script>

<style lang="less" scoped>
.tr-body {
  height: auto;
  align-items: center;

  .el-col {
    //border-right: 1px solid #eeeeee;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 14px;

    &:last-child {
      border: none;
    }
  }

  .el-divider--vertical {
    height: 40px;
  }

  .img-desc {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 140px;

    &:hover {
      box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 12%);
    }

    img {
      width: 100%;
      height: 90px;
      border-radius: 4px 4px 0 0;
    }

    .desc-text {
      padding: 0 44px 0 24px;
      font-size: 16px;
      //.ellipsis-num(2);
    }
  }
}
</style>
