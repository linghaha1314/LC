<template>
  <!--  我的笔记显示，课程显示，可以跳转到课程-->
  <el-table :data="list" style="width: 100%">
    <el-table-column type="expand">
      <template #default="scope">
        <div class="padding-start margin-start">
          <el-timeline>
            <el-timeline-item v-for="dd of scope.row.noteList" :key="dd.id"
                              :timestamp="$tools.formatTime(dd.created,'YY-MM-DD hh:mm:ss')"
                              placement="top">
              <el-card class="note-timeline-card" style="cursor: default" @click="locate(scope.row,dd)">
                <div class="head"><span class="font-bold">{{
                    dd['chapterData']['chapterName']
                  }}</span>-<span>{{ $tools.hms(dd.time) }}</span></div>
                <div class="padding-top"><span class="font-bold color666">笔记：</span><span v-html="dd.note"></span>
                </div>
              </el-card>
            </el-timeline-item>
          </el-timeline>
        </div>
      </template>
    </el-table-column>
    <el-table-column label="课程" prop="courseName"/>
    <el-table-column label="笔记数目">
      <template #default="scope">
        {{ scope.row.noteList.length }}条
      </template>
    </el-table-column>
  </el-table>
  <div v-if="state.total>0" class="padding-top padding-bottom align-center flex justify-content margin-top">
    <el-pagination
      :current-page="state.currentPage"
      :page-size="state.queryParams.limit"
      :page-sizes="[10,20,50,100]"
      :total="state.total"
      background
      layout="total,sizes,prev, pager, next,jumper"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    ></el-pagination>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import router from '@/router'

const activeName = ref('1')

const list = ref([])

const state = reactive({
  queryParams: {
    limit: tools.limit,
    offset: 0
  },
  currentPage: 1,
  total: 0
})

const getList = async () => {
  await tools.post('/api/rest/note/getCourseList', {
    where: {
      course_note: {
        course_id: { _is_null: false },
        staff_id: { _eq: store.state.clientUserInfo.id }
      }
    }
  }).then(r => {
    list.value = r.data.list
    state.total = r.data.totalData.aggregate.count
    activeName.value = r.data.list[0].courseId
  })
}

const locate = (item, dd) => {
  console.log(item, dd)
  router.push(`/client/coursePlay/${item.courseId}?chapterId=${dd.chapterId}&noteTime=${dd.time}`)
}

const handleSizeChange = (val) => {
  state.queryParams.limit = val
  getList()
}

const currentChange = (val) => {
  state.queryParams.offset = state.queryParams.limit * (val - 1)
  state.currentPage = val
  getList()
}
onMounted(() => {
  getList()
})
</script>
<style lang="less" scoped>
.note-timeline-card {
  cursor: default;

  &:hover .head {
    color: #842d4f;
  }

  &:hover {
    box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 12%);
  }
}
</style>
