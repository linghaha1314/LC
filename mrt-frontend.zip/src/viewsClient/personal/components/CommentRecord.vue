<template>
  <div class="my-order">
    <p class="font-bold">我的评论</p>
    <div v-loading="loading" style="min-height:400px">
      <el-card v-for="i in state.list" :key="i.id" class="margin-bottom" shadow="none">
        <div class="tr-body">
          <div class="img-desc flex column align-center"
               @click="$tools.go(`/client/coursePlay/${i.courseId}`)">
            <img :src="i['cover']" alt style="width: 100%"/>
            <div class="font-bold padding-top padding-bottom">{{ i['courseName'] }}</div>
          </div>
          <div class="content-wrapper">
            <el-divider direction="vertical"></el-divider>
            <div class="padding-start">
              <div class="desc-text padding-start padding-end" v-html="i.content"></div>
              <p class="padding-start color999"><small>发表于：{{
                  $tools.formatTime(i['created'], 'YY年MM月DD日hh:mm')
                }}</small></p>
            </div>
          </div>
        </div>
      </el-card>
      <!-- 分页 -->
      <div class="flex justify-content margin-top margin-bottom padding-top" v-if="state.total>0">
        <el-pagination
          :page-size="queryParams.limit"
          :page-sizes="[10,20,50,100]"
          :total="state.total"
          background
          layout="total,sizes,prev, pager, next,jumper"
          @size-change="handleSizeChange"
          @current-change="currentChange"
        ></el-pagination>
      </div>
      <null-back style="min-height:300px" v-if="!loading && state.total===0" justify="center">暂无留言记录，赶快去学习吧
      </null-back>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import NullBack from '@/viewsClient/components/NullBack.vue'

const loading = ref(true)

const state = reactive({
  list: [],
  total: 0
})

const queryParams = reactive({
  limit: 20,
  offset: 0
})

const handleSizeChange = (val) => {
  queryParams.limit = val
}

const currentChange = (val) => {
  queryParams.offset = queryParams.limit * (val - 1)
}

onMounted(() => {
  tools.clientPost('/comment/getCommentListByPage', {
    limit: 20,
    offset: 0,
    where: { staff_id: { _eq: store.state.clientUserInfo.id } }
  }).then(r => {
    state.list = r.list
    state.total = r.total
    loading.value = false
  })
})
</script>

<style lang="less" scoped>
.tr-body {
  height: auto;
  display: flex;
  align-items: center;

  .el-divider--vertical {
    height: 40px;
  }

  .img-desc {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 160px;

    &:hover {
      box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 12%);
    }

    img {
      width: 100%;
      height: 90px;
      border-radius: 4px 4px 0 0;
    }

    .desc-text {
      padding: 0 44px 0 24px;
      font-size: 16px;
      //.ellipsis-num(2);
    }
  }

  .content-wrapper {
    flex: 1;
    display: flex;
    align-items: center;
    padding: 0 16px;
  }
}
</style>
