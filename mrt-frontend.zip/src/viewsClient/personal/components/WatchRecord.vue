<template>
  <div class="watch-record">
    <p class="font-bold">观看记录</p>
    <el-tabs v-model="state.status" class="demo-tabs" @tab-click="handleClick($event)">
      <el-tab-pane class="flex flex-wrap align-center color666" label="全部" name="2">
      </el-tab-pane>
      <el-tab-pane class="flex flex-wrap align-center color666" label="未完成" name="0">
      </el-tab-pane>
      <el-tab-pane class="flex flex-wrap align-center color666" label="已完成" name="1">
      </el-tab-pane>
    </el-tabs>
    <ul v-loading="loading" style="min-height:150px">
      <li v-for="i in state.list" :key="i.id">
        <el-card :style="{backgroundImage:'url('+i.img+')'}" shadow="none" @click="goCourse(i)">
          <div class="content-box back-black">
            <div class="top font-bold">
              {{ i.name }}
            </div>
            <div class="hover-show">{{ $tools.formatTime(i['start_date'], 'YY-MM-DD hh:mm') }}</div>
            <div class="bottom flex align-center">
              <span class="inline-block" style="width: 140px"><el-progress
                :percentage="i['completedRate']" :show-text="false"
                :stroke-width="20"
                class="margin-end"
                style="width: auto;"/></span>
              <span>
                <span class="primary-color" :class="{'font-green':i['completedRate']===100}"
                      style="font-size: 28px">{{
                    i.completedRate
                  }}%</span>
              </span>
            </div>
          </div>
        </el-card>
      </li>
      <!--      <el-card v-for="i in state.list" :key="i.id" class="margin-bottom" shadow="none"-->
      <!--               @click="$tools.go(`/client/coursePlay/${i.courseId}`)">-->
      <!--        <el-row class="tr-body">-->
      <!--          <el-col :span="6" class="img-desc flex column align-center padding-start padding-end">-->
      <!--            <img :onerror="$tools.imgError(i.cover)"-->
      <!--                 :src="i.cover" alt style="width: 100%"/>-->
      <!--            <div class="font-bold margin-top">{{ i['courseName'] }}</div>-->
      <!--          </el-col>-->
      <!--          <el-col :span="8">-->
      <!--            <span class="desc-text padding-start padding-end">{{ i.content }}</span>-->
      <!--            <el-divider direction="vertical"></el-divider>-->
      <!--          </el-col>-->
      <!--          <el-col :span="6">-->
      <!--            <el-divider direction="vertical"></el-divider>-->
      <!--            <el-rate v-model="i.score" :texts="['十分失望', '失望', '一般', '很好', '非常好']" class="margin-start" disabled-->
      <!--                     show-text></el-rate>-->
      <!--          </el-col>-->
      <!--        </el-row>-->
      <!--      </el-card>-->
    </ul>
    <div v-if="state.total>0" class="padding-top padding-bottom align-center flex justify-content margin-top">
      <el-pagination
        :current-page="state.currentPage"
        :page-size="state.queryParams.limit"
        :page-sizes="[10,20,50,100]"
        :total="state.total"
        background
        layout="total,sizes,prev, pager, next,jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      ></el-pagination>
    </div>
    <null-back v-if="!loading && state.list.length===0">暂无观看记录，赶快去学习吧</null-back>
  </div>
</template>
<script>
</script>
<script lang="ts" setup>
import { reactive, ref, onMounted } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import NullBack from '@/viewsClient/components/NullBack.vue'

const loading = ref(true)
const state = reactive({
  currentPage: 1,
  queryParams: {
    limit: 20,
    offset: 0
  },
  percentage: 20,
  customColor: '#409eff',
  total: 0,
  status: '2',
  list: []
})
const goCourse = (i) => {
  location.href = '/#' + `/client/coursePlay/${i.course_id}`
}

const handleClick = (val) => {
  getDataList()
}

const getDataList = () => {
  const where = state.status === '1' ? {
    staff_id: { _eq: store.state.clientUserInfo.id },
    course_completed: { _eq: true }
  } : (state.status === '0' ? {
    staff_id: { _eq: store.state.clientUserInfo.id },
    course_completed: { _eq: false }
  } : {
    staff_id: { _eq: store.state.clientUserInfo.id }
  })
  tools.clientPost('/watchRecord/getStaffWatchListByPage', {
    limit: state.queryParams.limit,
    offset: state.queryParams.offset,
    where
  }).then(r => {
    loading.value = false
    state.list = r.list
    state.total = r.total
  })
}

const handleSizeChange = (val) => {
  state.queryParams.limit = val
  getDataList()
}

const handleCurrentChange = (val) => {
  state.queryParams.offset = state.queryParams.limit * (val - 1)
  state.currentPage = val
  getDataList()
}

onMounted(() => {
  getDataList()
})
</script>
<style lang="less" scoped>
@import (once) '~@/assets/css/commen.less';
@import (once) '~@/assets/css/client.less';

ul {
  width: 100%;

  li {
    margin-left: 30px;
    margin-bottom: 24px;
    display: inline-block;

    .el-card {
      --el-card-padding: 0px;
      background: url(../../../assets/images/client/err-default.jpg) rgba(0, 0, 0, 0.1) center no-repeat;

      &:hover {
        background: url(../../../assets/images/client/personal-watch-back.png) center no-repeat;
        background-size: 142%;
      }

      .content-box {
        color: #fff;
        background: rgba(94, 89, 89, 0.5);
        padding: 30px 15px 10px 15px;
        box-sizing: border-box;
        display: flex;
        width: 220px;
        height: 140px;
        flex-direction: column;
        justify-content: space-between;

        .hover-show {
          display: none;
        }
      }
    }

    .el-card:hover .hover-show {
      display: block;
    }

    .el-card:hover .bottom {
      display: none;
    }

    .back-black {
      background: rgba(0, 0, 0, 0.3);
    }

    .el-card:hover .back-black {
      background: rgba(0, 0, 0, 0);
    }
  }
}
</style>
