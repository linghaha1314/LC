<template>
  <div class="account-setting">
    <el-tabs v-model="state.activeName" @tab-click="handleClick">
      <el-tab-pane class="data-setting" label="资料设置" name="first">
        <el-form
          ref="formRef"
          :model="state.accountForm"
          :rules="state.rules"
          label-position="left"
          label-width="100px"
        >
          <li style="margin-left:30px">
            <el-form-item label="头像">
              <div class="img-box" @click="editAvatar">
                <img :onerror="$tools.imgError(store.state.clientUserInfo['avatar'])"
                     :src="store.state.clientUserInfo['avatar'] || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
                     alt/>
                <span class="edit-avatar">编辑头像</span>
              </div>
            </el-form-item>
            <el-form-item label="账号">
              <span class="color999">{{ state.accountForm.username }}</span>
            </el-form-item>
            <el-form-item label="昵称" prop="nickName">
              <el-input v-model="state.accountForm.nickName" clearable></el-input>
            </el-form-item>
            <el-form-item label="联系电话" prop="mobile">
              <el-input v-model="state.accountForm.mobile" clearable></el-input>
            </el-form-item>
            <el-form-item label="个人简介">
              <el-input v-model="state.accountForm.introduce" rows="2" style="width:360px" type="textarea"></el-input>
            </el-form-item>
          </li>
          <li style="margin-left:30px">
            <el-form-item>
              <el-button type="primary" @click="submitForm(formRef)">保存</el-button>
              <el-button>取消</el-button>
            </el-form-item>
          </li>
        </el-form>
      </el-tab-pane>
      <!--      <el-tab-pane label="账号设置" name="second">-->
      <!--        <div class="color999">绝不会以任何形式向第三方透露你的身份信息</div>-->
      <!--        <div class="item-box top">-->
      <!--          <div class="title">手机账号</div>-->
      <!--          <div class="right-box">-->
      <!--            <el-avatar-->
      <!--              :size="80"-->
      <!--              src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"-->
      <!--            ></el-avatar>-->
      <!--            <div class="account-name">-->
      <!--              <div>StanMOwang(微信账号)</div>-->
      <!--              <small class="color999" style="font-size:13px">观看记录以当前登录账号为准</small>-->
      <!--            </div>-->
      <!--          </div>-->
      <!--        </div>-->
      <!--        <div class="item-box" style="margin-top:45px">-->
      <!--          <div class="title">当前登录账号</div>-->
      <!--          <div class="right-box">-->
      <!--            <small class="color999">绑定手机后可使用该手机号直接登录当前账户</small>-->
      <!--            <p>-->
      <!--              <el-button size="small" type="primary" @click="bindMobile">绑定手机</el-button>-->
      <!--              <el-button size="small" @click="setPass">设置登陆密码</el-button>-->
      <!--              <el-button size="small" @click="changePass">密码修改</el-button>-->
      <!--            </p>-->
      <!--            <p>-->
      <!--              <small style="color:red;font-size:12px">您还未绑定手机号码，请先绑定</small>-->
      <!--            </p>-->
      <!--          </div>-->
      <!--        </div>-->
      <!--        <div class="item-box" style="margin-bottom:30px">-->
      <!--          <div class="title">第三方账号</div>-->
      <!--          <div class="right-box">-->
      <!--            <p class="color999" style="font-size:13px">绑定后可使用以下账号直接登录当前账户</p>-->
      <!--            <p>-->
      <!--              <img alt src/>-->
      <!--              微信/未绑定-->
      <!--            </p>-->
      <!--          </div>-->
      <!--        </div>-->
      <!--        <el-button type="primary">保存</el-button>-->
      <!--      </el-tab-pane>-->
    </el-tabs>
    <!-- 绑定手机号 -->
    <el-dialog
      v-model="state.isBindMobile"
      :destroy-on-close="false"
      :fullscreen="false"
      :modal-append-to-body="true"
      class="dialog"
      title="绑定手机号"
      width="600px"
    >
      <el-form
        ref="bindMobileForm"
        :model="state.bindMobileForm"
        :rules="state.bindMobileRules"
        label-position="right"
        label-width="120px"
      >
        <el-form-item label="手机号" prop="mobile">
          <el-input v-model="state.bindMobileForm.mobile" placeholder="请输入手机号" style="width:320px"></el-input>
        </el-form-item>
        <el-form-item label="验证码" prop="replacePass">
          <el-input v-model="state.bindMobileForm.replacePass" placeholder="请输入验证码" style="width:100px"></el-input>&nbsp;&nbsp;&nbsp;
          <el-button size="small" type="primary">发送验证码</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 修改密码 -->
    <!--    <el-dialog-->
    <!--      v-if="state.isChangePass"-->
    <!--      v-model="state.isChangePass"-->
    <!--      :destroy-on-close="false"-->
    <!--      :fullscreen="false"-->
    <!--      :modal-append-to-body="true"-->
    <!--      class="dialog"-->
    <!--      title="修改用户密码"-->
    <!--      width="600px"-->
    <!--    >-->
    <!--      <el-form-->
    <!--        ref="changePassForm"-->
    <!--        :model="state.changePassForm"-->
    <!--        :rules="state.changePassRules"-->
    <!--        label-position="right"-->
    <!--        label-width="120px"-->
    <!--      >-->
    <!--        <el-form-item label="旧密码" prop="oldPass">-->
    <!--          <el-input v-model="state.changePassForm.oldPass" placeholder="请输入旧密码" style="width:320px"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="新密码" prop="newPass">-->
    <!--          <el-input v-model="state.changePassForm.newPass" placeholder="请输入旧密码" style="width:320px"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="重复新密码" prop="replacePass">-->
    <!--          <el-input v-model="state.changePassForm.replacePass" placeholder="请输入旧密码" style="width:320px"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <p style="text-align:center">-->
    <!--          <el-button style="width:120px" type="primary" @click="submitForm('changePassForm')">确定</el-button>-->
    <!--        </p>-->
    <!--        <p style="text-align:center">-->
    <!--          <small>已忘记旧密码？试试</small>-->
    <!--          <span class="font-green">重置密码</span>-->
    <!--        </p>-->
    <!--      </el-form>-->
    <!--    </el-dialog>-->
  </div>

</template>
<script lang="ts" setup>
import { onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import { ElForm } from 'element-plus'

const formRef = ref(ElForm)
const state = reactive({
  value: '',
  isBindMobile: false, // 是否绑定手机号
  isChangePass: false, // 修改密码
  activeName: 'first',
  accountForm: {
    nickName: '',
    avatar: '',
    mobile: '',
    introduce: ''
  },
  bindMobileForm: {
    mobile: '',
    code: ''
  },
  changePassForm: {
    oldPass: '',
    newPass: '',
    replacePass: ''
  },
  bindMobileRules: {
    mobile: [
      {
        required: true,
        message: '请输入电话号码',
        trigger: 'blur'
      },
      {
        required: true,
        trigger: 'blur'
      }
    ],
    code: [{
      required: true,
      message: '请输入电话号码',
      trigger: 'blur'
    }]
  },
  changePassRules: {
    oldPass: [{
      required: true,
      message: '请输入昵称',
      trigger: 'blur'
    }],
    newPass: [{
      required: true,
      message: '请输入昵称',
      trigger: 'blur'
    }],
    replacePass: [
      {
        required: true,
        message: '请输入昵称',
        trigger: 'blur'
      }
    ]
  },
  searchOthers: {},
  rules: {
    nickName: [
      {
        required: true,
        message: '请输入昵称',
        trigger: 'blur'
      },
      {
        required: true,
        trigger: 'blur'
      }
    ],
    name: [
      {
        required: true,
        message: '请输入真实姓名',
        trigger: 'blur'
      },
      {
        required: true,
        trigger: 'blur'
      }
    ],
    mobile: [
      {
        required: true,
        message: '请输入电话号码',
        trigger: 'blur'
      },
      {
        required: true,
        trigger: 'blur'
      }
    ]
  },
  options: [
    {
      value: '选项1',
      label: '黄金糕'
    }
  ]
})
const submitForm = (formRef) => {
  if (!formRef) return
  formRef.validate((valid: any, fields: any) => {
    if (valid) {
      const data = JSON.parse(JSON.stringify(state.accountForm))
      delete data.avatar
      tools.clientPost('/user/updateUserById', {
        id: store.state.clientUserInfo.id,
        nickName: data.nickName,
        mobile: data.mobile,
        introduce: data.introduce
      }).then(async res => {
        if (res.success) {
          tools.msg('更新数据成功')
          await store.dispatch('getClientUserInfo', { id: store.state.clientUserInfo.id })
        }
      })
    } else {
      const data: any = Object.values(fields)[0]
      tools.msg(data[0].message, 'warning')
      // 定位到找个位置的输入
    }
  })
}
const bindMobile = () => {
  state.isBindMobile = true
}
const changePass = () => {
  state.isChangePass = true
}
const setPass = () => {
  state.isChangePass = true
}
const handleClick = (val) => {
  console.log(val)
}
const editAvatar = async () => {
  const result: any = await tools.upload()
  tools.clientPost('/user/updateUserById', {
    id: store.state.clientUserInfo.id,
    avatar: result.path
  }).then(async res => {
    if (res.success) {
      tools.msg('修改头像成功')
      state.accountForm.avatar = result.path
      await store.dispatch('getClientUserInfo', { id: store.state.clientUserInfo.id })
    }
  })
}
onMounted(() => {
  state.accountForm = store.state.clientUserInfo
})

</script>
<style lang="less" scoped>
.account-setting {
  padding: 0 30px;
  padding-top: 20px;
  background: #ffffff;

  /deep/ .el-tabs__item {
    width: auto;
  }

  /deep/ .el-tabs__nav {
    background: transparent;
    border: none;
    height: auto;
  }

  /deep/ .el-tabs__active-bar {
    display: block;
  }

  /deep/ .el-form-item__label {
    font-size: 16px;
    font-weight: bold;
  }

  .el-form {
    .el-form-item {
      .el-input {
        width: 320px;
      }
    }
  }

  .item-box {
    display: flex;
    justify-content: flex-start;
    align-items: center;

    .title {
      font-weight: bold;
      width: 100px;
      margin-right: 16px;
    }

    .right-box {
      margin-left: 30px;
    }
  }

  .top {
    border-bottom: 2px solid #eeeeee;
    height: 200px;
    box-sizing: border-box;

    .right-box {
      display: flex;
      justify-content: flex-start;
      align-items: center;

      .account-name {
        margin-left: 15px;
      }
    }
  }

  .data-setting {
    .img-box {
      position: relative;
      height: 100px;
      width: 100px;
      border-radius: 50%;
      overflow: hidden;
      cursor: default;

      img {
        height: 100%;
        width: 100%;
        border-radius: 50%;
        object-fit: cover;
        overflow: hidden;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 9;
      }

      .edit-avatar {
        width: 100%;
        height: 26px;
        line-height: 26px;
        position: absolute;
        bottom: 0;
        left: 0;
        overflow: hidden;
        color: #ffffff;
        background: #000000;
        z-index: 99;
        opacity: 0.7;
        text-align: center;
      }
    }

    /deep/ .el-form-item__error {
      left: 100px;
    }
  }

  .dialog {
    /deep/ .el-form-item__error {
      left: 120px;
    }
  }
}
</style>
