<template>
  <div class="feed-back">
    <p class="font-bold">意见反馈</p>
    <div class="content-box">
      <el-form ref="questionForm" :model="questionForm" :rules="rules" label-width="100px">
        <el-form-item label="内容" prop="content">
          <el-input
            v-model="questionForm.content"
            :autosize="{ minRows: 2, maxRows: 6}"
            placeholder="请输入内容"
            style="width:412px"
            type="textarea"
          />
        </el-form-item>
        <el-form-item label="上传图片">
          <el-upload
            :on-preview="handlePictureCardPreview"
            :on-remove="handleRemove"
            action="/public/upload"
            list-type="picture-card"
            :on-success="successUpload"
          >
            <Icon icon="Plus" class="icon"></Icon>
          </el-upload>
          <el-dialog v-model:visible="dialogVisible">
            <img :src="dialogImageUrl" alt width="100%"/>
          </el-dialog>
          <p class="color999" style="font-size:14px">只能上传jpg/png文件，且不超过1M</p>
        </el-form-item>
        <p>
          <el-button type="primary" @click="submitForm('questionForm')">提交</el-button>
        </p>
      </el-form>
    </div>
  </div>
</template>
<script>
import { Plus } from '@element-plus/icons-vue'
import tools from '@/utils/tool'
import store from '@/store'

export default {
  data () {
    return {
      dialogImageUrl: '',
      dialogVisible: false,
      Plus: Plus,
      questionForm: {
        content: ''
      },
      files: [],
      rules: {
        content: [{
          required: true,
          message: '请输入意见',
          trigger: 'blur'
        }]
      }
    }
  },
  methods: {
    submitForm (formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          tools.confirm('温馨提示', '确定提交意见反馈？').then((rr) => {
            if (rr) {
              tools.clientPost('/feedback/create', {
                staffId: store.state.clientUserInfo.id,
                content: this.questionForm.content,
                paths: JSON.stringify(this.files)
              }).then(r => {
                tools.msg('上传成功！')
                // 清空所有的数据
                this.$refs[formName].reset()
              })
            }
          })
        } else {
          return false
        }
      })
    },
    handleRemove (file) {
      const data = file.response.data
      this.files = this.files.filter(rr => rr.path !== data.path)
    },
    successUpload (file) {
      this.files.push({
        ...file.data,
        staffId: store.state.clientUserInfo.id
      })
    },
    handlePictureCardPreview (file) {
      this.dialogVisible = true
      this.dialogImageUrl = file.url
    }
  }
}
</script>
<style lang="less" scoped>
.feed-back {
  .content-box {
    background: #ffffff;
    padding: 40px;
    border: 1px solid #eeeeee;
    border-radius: 4px;
  }

  /deep/ .el-upload--picture-card {
    height: 100px;
    width: 100px;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  /deep/ .el-form-item__label {
    text-align: left;
    font-size: 16px;
    font-weight: bold;
  }

  /deep/ .el-form-item__error {
    left: 100px;
  }
}
</style>
