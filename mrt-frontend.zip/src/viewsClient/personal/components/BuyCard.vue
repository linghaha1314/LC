<template>
  <div :class="{'back-green':currentIndex==obj.name}" class="buy-card">
    <div class="title">{{ obj.name }}</div>
    <div class="content">
      <div class>
        ￥
        <span class="price">{{ obj.price }}</span>
        /{{ obj.unit }}
      </div>
      <del>￥{{ obj.originalPrice }}/{{ obj.unit }}</del>
      <div class="tag">低至￥{{ obj.quarterPrice }}/季</div>
    </div>
    <div v-show="currentIndex==obj.name" class="icon-check-box">
      <i class="el-icon-check"></i>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: ['obj', 'currentIndex']
}
</script>
<style lang="less" scoped>
.buy-card {
  padding: 12px 16px;
  position: relative;
  box-sizing: border-box;
  border: 1px solid #eeeeee;
  border-radius: 4px;
  width: 146px;
  height: 122px;
  color: #010101;

  &:hover {
    cursor: pointer;
  }

  .title {
    font-weight: bold;
    font-size: 14px;
  }

  .content {
    .price {
      font-weight: bold;
      font-size: 28px;
    }

    del {
      color: #999999;
    }

    .tag {
      margin-top: 5px;
      //background: @color;
      white-space: nowrap;
      color: #ffffff;
      width: 82px;
      text-align: center;
      border-radius: 20px 0 20px 0;
    }
  }

  .icon-check-box {
    text-align: center;
    position: absolute;
    right: -1px;
    bottom: -1px;
    height: 20px;
    width: 20px;
    color: #ffffff;
    //background: @color;
    border-radius: 100% 0 4px 0;

    i {
      position: absolute;
      bottom: 8%;
      right: 8%;
    }
  }
}

.back-green {
  background: #f7fffd;
}
</style>
