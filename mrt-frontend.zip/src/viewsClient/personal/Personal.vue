<template>
  <div class="personal container">
    <section>
      <el-tabs v-model:activeIndex="state.activeIndex" tab-position="left"
               @tab-click="tabClick">
        <el-tab-pane
          v-for="item in state.navList"
          :key="item.name"
          :label="item.name"
          class="el-tab-box"
        >
        </el-tab-pane>
      </el-tabs>
    </section>
    <el-card style="width: 100%;">
      <personal-center v-if="state.activeIndex===0"></personal-center>
      <comment-record v-if="state.activeIndex===1"></comment-record>
      <watch-record v-if="state.activeIndex===2"></watch-record>
      <collect-course v-if="state.activeIndex===3"></collect-course>
      <my-score-record v-if="state.activeIndex===4"></my-score-record>
      <my-course-score v-if="state.activeIndex===5"></my-course-score>
      <my-note v-if="state.activeIndex===6"></my-note>
      <account-setting v-if="state.activeIndex===7"></account-setting>
      <feed-back v-if="state.activeIndex===8"></feed-back>
    </el-card>
  </div>
</template>
<script lang="ts" setup>
import { defineAsyncComponent, reactive } from 'vue'
import PersonalCenter from '@/viewsClient/personal/components/PersonalCenter.vue'
import CommentRecord from '@/viewsClient/personal/components/CommentRecord.vue'
import CollectCourse from '@/viewsClient/personal/components/CollectCourse.vue'
import WatchRecord from '@/viewsClient/personal/components/WatchRecord.vue'
import AccountSetting from '@/viewsClient/personal/components/AccountSetting.vue'
import FeedBack from '@/viewsClient/personal/components/FeedBack.vue'
import MyScoreRecord from '@/viewsClient/personal/components/MyScoreRecord.vue'
import MyCourseScore from '@/viewsClient/personal/components/MyCourseScore.vue'
import MyNote from '@/viewsClient/personal/components/MyNote.vue'

const state = reactive({
  watchRecordList: [],
  navList: [
    {
      id: 1,
      name: '个人中心',
      component: defineAsyncComponent(() => import('./components/PersonalCenter.vue'))
    },
    {
      id: 2,
      name: '已留言',
      component: defineAsyncComponent(() => import('./components/CommentRecord.vue'))
    },
    {
      id: 3,
      name: '观看记录',
      component: defineAsyncComponent(() => import('./components/WatchRecord.vue'))
    },
    {
      id: 4,
      name: '我收藏的课程',
      component: defineAsyncComponent(() => import('./components/CollectCourse.vue'))
    }, {
      id: 5,
      name: '我的学分记录',
      component: defineAsyncComponent(() => import('./components/MyScoreRecord.vue'))
    }, {
      id: 6,
      name: '我的评分记录',
      component: defineAsyncComponent(() => import('./components/MyCourseScore.vue'))
    },
    {
      id: 7,
      name: '我的笔记',
      component: defineAsyncComponent(() => import('./components/MyNote.vue'))
    },
    {
      id: 8,
      name: '账号设置',
      component: defineAsyncComponent(() => import('./components/AccountSetting.vue'))
    },
    {
      id: 9,
      name: '意见反馈',
      component: defineAsyncComponent(() => import('./components/FeedBack.vue'))
    }
  ],
  activeIndex: 0
})

const tabClick = (val) => {
  state.activeIndex = Number(val.index)
}
</script>
<style lang="less" scoped>

.personal {
  padding: 20px 0 36px 0;
  display: flex;
  min-height: calc(100vh - 400px);

  /deep/ .el-tabs__item {
    text-align: center;
    width: 200px;
    height: 45px;
    font-weight: bold;
    font-size: 16px;

    .el-tabs__nav {
      background: #ffffff;
      border: 1px solid #eeeeee;
      height: 638px;
    }
  }

  ///deep/.el-tabs__active-bar {
  //  display: none;
  //}
  ///deep/.el-tabs__content {
  //  padding-bottom: 40px;
  //}
  /deep/ .el-tabs--left .el-tabs__header.is-left {
    margin-right: 41px;
  }
}
</style>
