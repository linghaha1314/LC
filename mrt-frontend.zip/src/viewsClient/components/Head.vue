<template>
  <div class="head-wrapper">
    <div class="left flex align-center">
      <img alt="" src="../../assets/images/head-logo.png"/>
      <img alt="" src="../../assets/images/zx.png" style="height: 20px;"/>
      <router-link :to="{ name: 'home' }" class="padding-start padding-end">首页</router-link>
      <div class="channel-panel-parent">医疗教育
        <div class="channel-panel">
          <div class="channel-panel__indicator"></div>
          <div class="channel-panel__indicator-shadow"></div>
          <div class="channel-panel__content">
            <section v-for="item in typeList" :key="item.id" class="channel-panel__section">
              <h5 class="channel-panel__type" @click="goAllCourse(item)" style="cursor: default">{{ item.name }}
              </h5>
              <div class="channel-panel__items">
                <div v-for="dd in item.children" :key="dd.id" class="channel-panel__item" @click="goAllCourse(dd)">
                  <p>{{ dd.name }}</p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
    <div v-if="router.currentRoute.value.meta['isShowSearch']" class="flex align-center padding-end"
         style="flex: 1;justify-content: flex-end">
      <div class="search-wrapper">
        <input v-model="store.state.search" placeholder="搜索" @keyup.enter="goSearch"/>
        <div class="icon-search-box" @click="goSearch">
          <Icon class="icon-search" icon="Search"></Icon>
        </div>
      </div>
    </div>
    <div v-if="!userInfo || !userInfo.name" class="flex align-center login-sign">
      <span @click="login(0)">&nbsp;登录</span>&nbsp;
    </div>
    <div v-else class="flex align-center login-sign">
      <el-dropdown>
        <span class="el-dropdown-link flex align-center">
          <img :onerror="$tools.imgError(store.state.clientUserInfo['avatar'])"
               :src="store.state.clientUserInfo['avatar'] || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
               style="height:42px;width: 42px;border-radius: 50%"/>
          &nbsp;&nbsp;&nbsp;{{ userInfo.nickName || userInfo.name }}
        </span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item v-for="i in options" :key="i.id" @click="goUrl(i)">{{ i.value }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
  <login-dialog v-if="store.state.showLoginDialog"></login-dialog>
  <el-dialog v-if="store.state.showWriteInfoDialog" v-model="store.state.showWriteInfoDialog"
             :close-on-click-modal="false" :show-close="false" class="info-dialog" width="400px">
    <template v-slot:title>
      <strip-title style="height:40px">完善个人信息</strip-title>
    </template>
    <div style="margin:-66px 0 10px 16px"><small>注意⚠️：一旦提交无法更改，请按照自身实际情况填写</small></div>
    <el-form ref="ruleFormRef" :model="ruleForm" :rules="rules" label-width="100px">
      <el-form-item prop="avatar">
        <div class="img-box" @click="editAvatar">
          <img :src="ruleForm['avatar']" alt=""/>
          <span class="edit-avatar">上传头像</span>
        </div>
      </el-form-item>
      <el-form-item label="帐号" prop="name">
        <el-input v-model="ruleForm.username" style="width: 200px"></el-input>
      </el-form-item>
      <el-form-item label="昵称" prop="nickName">
        <el-input v-model="ruleForm.nickName" style="width: 200px"></el-input>
      </el-form-item>
      <el-form-item label="出生年月">
        <el-date-picker v-model="ruleForm.bornDate" placeholder="选择日期" style="width: 200px" type="date">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="性别" prop="resource">
        <el-radio-group v-model="ruleForm.gender">
          <el-radio label="男">男
          </el-radio>
          <el-radio label="女">女</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="科室" prop="sectionId">
        <el-select v-model="ruleForm.sectionId" :loading="sectionLoading" :remote-method="getSection" filterable
                   placeholder="搜索相关科室" remote>
          <el-option v-for="item in sectionList" :key="item.id" :label="item.name" :value="item.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="人员类别" prop="staffTypeId">
        <el-select v-model="ruleForm.staffTypeId" placeholder="请选择人员类别">
          <el-option v-for="dd of staffType" :key="dd.id" :label="dd.name" :value="dd.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="职称" prop="positionNameId">
        <el-select v-model="ruleForm.positionNameId" placeholder="请选择科室">
          <el-option v-for="dd of positionNames" :key="dd.id" :label="dd.name" :value="dd.id"></el-option>
        </el-select>
      </el-form-item>
      <div class="flex justify-content align-center">
        <el-button style="width: 320px" type="primary" @click="submit(ruleFormRef)">提交</el-button>
      </div>
    </el-form>
  </el-dialog>
</template>

<script lang="ts">
import { computed, defineComponent, onMounted, reactive, ref, toRefs } from 'vue'
import LoginDialog from '@/viewsClient/components/LoginDialog.vue'
import store from '@/store'
import router from '@/router'
import Cookies from 'js-cookie'
import tools from '@/utils/tool'
import StripTitle from '@/components/StripTitle.vue'
import { ElForm } from 'element-plus'

export default defineComponent({
  components: {
    StripTitle,
    LoginDialog
  },
  setup: () => {
    const ruleFormRef = ref(ElForm)

    const state = reactive({
      search: '',
      flag: false,
      typeList: [] as any[],
      sectionLoading: false,
      staffType: [] as any[],
      sectionList: [] as any[],
      positionNames: [],
      options: [
        {
          id: 0,
          value: '个人中心',
          path: '/client/personal'
        },
        {
          id: 4,
          value: '退出登录',
          path: '/login'
        }
      ],
      ruleForm: {
        avatar: store.state.clientUserInfo?.avatar || '',
        nickName: store.state.clientUserInfo?.nickName || store.state.clientUserInfo?.name,
        username: store.state.clientUserInfo?.username,
        sectionId: store.state.clientUserInfo?.sectionId,
        bornDate: store.state.clientUserInfo?.bornDate,
        gender: store.state.clientUserInfo?.gender || '男',
        staffTypeId: store.state.clientUserInfo?.staffTypeId,
        positionNameId: store.state.clientUserInfo?.positionNameId
      },
      rules: {
        nickName: [
          {
            required: true,
            message: '昵称必填',
            trigger: 'blur'
          },
          {
            min: 1,
            max: 8,
            message: '长度在 1 到 8 个字符',
            trigger: 'blur'
          }
        ],
        username: [
          {
            required: true
          }
        ],
        sectionId: [
          {
            required: true,
            message: '请选择科室',
            trigger: 'change'
          }
        ],
        bornDate: [
          {
            required: false,
            message: '出生年月',
            trigger: 'change'
          }
        ],
        staffTypeId: [
          {
            required: true,
            message: '请选择人员类别',
            trigger: 'change'
          }
        ],
        positionNameId: [
          {
            required: true,
            message: '请选择职称',
            trigger: 'change'
          }
        ]
      }
    })

    const userInfo = computed(() => {
      return store.state.clientUserInfo || {}
    })

    const goSearch = () => {
      console.log('====>>>????', store.state.search)
      router.push({
        path: 'allCourse',
        query: { search: store.state.search }
      })
    }

    const login = (val) => {
      console.log(val)
      store.commit('setClientShowLoginDialog', true)
    }

    const editAvatar = async () => {
      const result: any = await tools.upload()
      tools.clientPost('/user/updateUserById', {
        id: store.state.clientUserInfo.id,
        avatar: result.path
      }).then(async res => {
        if (res.success) {
          tools.msg('修改头像成功')
          state.ruleForm.avatar = result.path
          await store.dispatch('getClientUserInfo', { id: store.state.clientUserInfo.id })
        }
      })
    }

    const submit = (formRef) => {
      // 更新用户信息
      // 提示一旦选择无法更改，请按照自身实际情况填写
      if (!formRef) return
      formRef.validate((valid: any, fields: any) => {
        if (valid) {
          tools.confirm('提交后不可轻易修改', '确定提交？').then(rr => {
            if (rr) {
              tools.clientPost('/user/updateById', {
                ...state.ruleForm,
                id: userInfo.value.id
              }).then(r => {
                if (r.success) {
                  tools.msg('更新个人信息成功')
                  store.dispatch('getClientUserInfo', { id: store.state.clientUserInfo.id })
                } else {
                  tools.msgError(r.msg)
                }
                store.commit('setClientWriteInfoDialog', false)
              })
            }
          })
        } else {
          console.log('===>>>', formRef, state.ruleForm)
        }
      })
    }

    const courseType = () => {
      tools.clientGet('/courseType/getListByPage', {
        limit: 1000,
        sort: 'sequence asc'
      }).then(r => {
        state.typeList = r.list
      })
    }

    const goUrl = (to) => {
      if (to.value === '退出登录') {
        store.commit('setClientToken', '')
        store.commit('setClientUserInfo', '')
        router.push('/client/home')
        Cookies.remove('client-token')
        return
      }
      router.push('/client/personal')
    }

    const goAllCourse = (item) => {
      // 筛选所有课程的类型id是这个的所有课程；并且获取类型子目录
      router.push({
        path: '/client/allCourse',
        query: {
          typeId: item.id,
          typeCode: item.code,
          firstTypeName: item.parentName ?? item.name
        }
      })
    }

    const getSection = (query: string) => {
      state.sectionLoading = true
      try {
        tools.clientGet('/section/getListByPage', { name: query }).then(r => {
          state.sectionList = r.list
          state.sectionLoading = false
        })
      } catch (e) {
        state.sectionLoading = false
      }
    }

    const getType = () => {
      tools.clientPost('/dictionaryData/getByTypeCode', { typeCode: 'staffType' }).then(r => {
        state.staffType = r.list
      })
    }

    const getPositionName = () => {
      tools.clientPost('/dictionaryData/getByTypeCode', { typeCode: 'positionName' }).then(r => {
        state.positionNames = r.list
      })
    }

    const handleAvatarSuccess = (res, file) => {
      // state.imageUrl = URL.createObjectURL(file.raw)
    }

    const beforeAvatarUpload = (file) => {
      // const isJPG = file.type === 'image/jpeg'
      // const isLt2M = file.size / 1024 / 1024 < 2
      //
      // if (!isJPG) {
      //   this.$message.error('上传头像图片只能是 JPG 格式!')
      // }
      // if (!isLt2M) {
      //   this.$message.error('上传头像图片大小不能超过 2MB!')
      // }
      // return isJPG && isLt2M
    }

    onMounted(() => {
      courseType()
      if (store.state.clientUserInfo?.name && !store.state.clientUserInfo?.bornDate) {
        store.commit('setClientWriteInfoDialog', true)
        getPositionName()
        getType()
        getSection('%%')
      }
    })

    return {
      userInfo,
      store,
      ...toRefs(state),
      goUrl,
      getSection,
      getType,
      getPositionName,
      handleAvatarSuccess,
      beforeAvatarUpload,
      submit,
      ruleFormRef,
      goSearch,
      router,
      editAvatar,
      courseType,
      goAllCourse,
      login
    }
  }
})
</script>

<style lang="less" scoped>
@import (once) '~@/assets/css/client.less';

.search-wrapper {
  border: 1px solid @color;
  width: 250px;
  height: 32px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 16px;
  overflow: hidden;

  input {
    flex: 1;
    padding: 0 0 0 16px;
    border: none;
    height: 100%;
    box-sizing: border-box;
    outline: none;

    &:focus {
      outline: none;
    }
  }

  .icon-search-box {
    height: 100%;
    background: @color;
    display: flex;
    align-items: center;
    justify-content: center;

    .icon-search {
      font-size: 24px;
      padding: 0 8px;
      color: #ffffff;
    }
  }
}

.head-wrapper {
  display: flex;
  justify-content: space-between;
  align-content: center;
  height: 100%;

  img {
    height: 95%;
    margin-right: 16px;
  }

  .channel-panel-parent {
    position: relative;
    padding: 0 20px 0 40px;

    &::after {
      content: '';
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      right: 0;
      width: 0;
      height: 0;
      border: 4px solid transparent;
      border-width: 6px 5px 0 5px;
      border-top-color: #c6c6c6;
      -webkit-transition: all .3s;
      transition: all .3s;
      cursor: pointer;
    }

    &:hover {
      text-decoration: none;
      cursor: pointer;

      .channel-panel {
        display: block;
      }
    }

    .channel-panel {
      display: none;
      position: absolute;
      top: 100%;
      left: -55%;
      z-index: 2500;
      cursor: auto;

      .channel-panel__indicator {
        position: absolute;
        top: -24px;
        left: 100px;

        &::before {
          content: '';
          width: 0;
          height: 0;
          border: 1px solid transparent;
          border-width: 0 14px 14px 14px;
          border-bottom-color: #fff;
          position: absolute;
          top: 10px;
        }
      }

      .channel-panel__indicator-shadow {
        width: 0;
        height: 0;
        border: 1px solid transparent;
        border-width: 0 14px 14px 14px;
        border-bottom-color: #fff;
        position: absolute;
        top: -5px;
        left: 99px;
        border-width: 16px;
        -webkit-transform: rotate(45deg);
        transform: rotate(45deg);
        -webkit-box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 12%);
        box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 12%);
        z-index: -1;
      }

      .channel-panel__content {
        width: 662px;
        max-height: 441px;
        padding: 16px 32px 32px 32px;
        border-radius: 4px;
        -webkit-box-shadow: 0px 0px 10px 1px rgb(0 0 0 / 12%);
        box-shadow: 0px 0px 10px 1px rgb(0 0 0 / 12%);
        background-color: #fff;
        font-size: 14px;
        overflow-y: auto;

        .channel-panel__type {
          height: 22px;
          line-height: 22px;
          font-size: 16px;
          font-weight: 600;
          color: #333333;
          margin-bottom: 0;
        }

        .channel-panel__items {
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -webkit-box-orient: horizontal;
          -webkit-box-direction: normal;
          -ms-flex-flow: row wrap;
          flex-flow: row wrap;
          -webkit-box-pack: start;
          -ms-flex-pack: start;
          justify-content: flex-start;
        }

        .channel-panel__item {
          -webkit-box-sizing: border-box;
          box-sizing: border-box;
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -webkit-box-pack: center;
          -ms-flex-pack: center;
          justify-content: center;
          -webkit-box-align: center;
          -ms-flex-align: center;
          align-items: center;
          min-width: 110px;
          height: 32px;
          padding: 0 10px;
          margin: 9px 12px 2px 0;
          border-radius: 16px;
          line-height: 32px;
          font-size: 14px;
          color: #333333;
          text-align: center;
          background-color: rgba(0, 0, 0, 0.04);
          cursor: pointer;
        }

        .channel-panel__item:hover {
          color: #ffffff;
          background-color: @color;
        }
      }
    }
  }
}

.img-box {
  position: relative;
  height: 100px;
  width: 100px;
  border-radius: 50%;
  overflow: hidden;
  cursor: default;
  margin-top: -30px;
  margin-left: 28px;

  img {
    height: 100%;
    width: 100%;
    border-radius: 50%;
    object-fit: cover;
    overflow: hidden;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 9;
  }

  .edit-avatar {
    width: 100%;
    height: 26px;
    line-height: 26px;
    position: absolute;
    bottom: 0;
    left: 0;
    overflow: hidden;
    color: #ffffff;
    background: #000000;
    z-index: 99;
    opacity: 0.7;
    text-align: center;
  }
}

.login-sign {
  cursor: default;
}
</style>
