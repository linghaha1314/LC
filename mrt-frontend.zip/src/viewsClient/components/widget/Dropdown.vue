<template>
  <div class="drop-down">
    <div @mouseover="dorpDown($event)" @mouseout="dorpUp($event)" class="box">
      <div>蔬菜 v</div>
      <div class="options-box">
        <ul>
          <li v-for="sc in scs" :key="sc.name">
            <a href>{{sc.name}}</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      options: [
        { name: '土豆' },
        { name: '白菜' },
        { name: '豆芽' },
        { name: '花菜' }
      ]
    }
  },
  methods: {
    dorpDown (event) {
      let secondnav1 = event.currentTarget.childNodes[1]
      $('.oprions-box').style.display = 'block'
    },
    dorpUp (event) {
      let secondnav1 = event.currentTarget.childNodes[1]
      $('.oprions-box').style.display = 'block'
    }
  }
}
</script>
<style lang="less" scoped>
.drop-down {
}
</style>
