<template>
  <div class="select-option">
    <button>
      <span :class="{ 'active-back': ischangeValue }">
        <span>{{ selectVal }}</span>
        <i class="el-icon-caret-bottom"></i>
      </span>
    </button>
    <!-- 选项 -->
    <div class="options-box">
      <p
        v-for="item in options"
        :key="item.id"
        :class="{ configure: item.selected, hover: true }"
        @click="changSelect(item)"
      >
        {{ item.value }}
      </p>
    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      ischangeValue: false,
      isShowOptions: false,
      selectVal: ''
    }
  },
  props: ['options'],
  mounted () {
    this.selectVal = this.options[0].value
  },
  methods: {
    changSelect (item) {
      this.selected = item.value
      this.selectVal = item.value
      this.ischangeValue = true
      this.options.map((res) => {
        res.selected = false
        if (item.id === res.id) {
          res.selected = true
        }
      })
      this.$emit('changSelect', item)
    }
  },
  watch: {}
}
</script>
<style lang="less" scoped>
.select-option {
  font-size: 14px;
  position: relative;
  height: 100%;

  button {
    white-space: nowrap;
    display: inline-block;
    height: 100%;

    span {
      font-size: 14px;
      white-space: nowrap;
    }
  }

  &:hover .options-box {
    display: block;
  }

  .options-box {
    display: none;
    position: absolute;
    top: 16px;
    left: 0;
    border: 1px solid #eeeeee;
    z-index: 9;
    background: #ffffff;
    transform: translateY(10%);
    border-radius: 4px;

    p {
      padding: 0 15px;
      font-weight: 500;
      border-bottom: 1px solid #eeeeee;
      margin: 0;
      line-height: 40px;
      white-space: nowrap;
      text-align: left;

      &:last-child {
        border: none;
      }
    }
  }
}

.active-back {
  //color: @color;
}

.hover:hover {
  //color: @color;
}
</style>
