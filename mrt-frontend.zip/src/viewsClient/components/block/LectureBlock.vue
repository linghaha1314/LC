<template>
  <el-row class="lecture-block" @click="goDoctorCenter">
    <el-col :span="4">
      <img :src="obj.img" alt/>
    </el-col>
    <el-col :span="8" class="doctor-detail">
      <div>
        <span class="teacher-name">{{ obj.teacherName }}</span>
        <el-tag class="tag" v-if="obj.majorName">{{ obj.majorName }}</el-tag>
      </div>
      <div>
        <span>{{ obj.titleName }}</span>
        <span>{{ obj.organizationName }}</span>
      </div>
    </el-col>
    <el-col :span="6">
      <div class="intro-box">
        {{ obj.brief }}
      </div>
    </el-col>
    <el-col :span="6">
      <button type="primary" plain>名师主页</button>
    </el-col>
  </el-row>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: ['obj'],
  methods: {
    goDoctorCenter () {
      this.$router.push(`/client/doctorCenter/${this.obj.id}`)
    }
  }
}
</script>
<style lang="less" scoped>

.lecture-block {
  width: 100%;
  padding: 26px 28px;

  .el-col {
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;

    &:first-child {
      height: 140px;
      width: 160px;

      img {
        height: 100%;
        width: 100%;
      }
    }

    &:nth-child(2) {
      margin-left: 27px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;

      div {
        &:last-child {
          font-size: 14px;
          font-weight: 400;
          opacity: 0.8;
          margin-top: 13px;
        }
      }
    }

    &:nth-child(3) {
      .intro-box {
        //.ellipsis-num(7);
        font-size: 12px;
        color: #999999;
        line-height: 16px;
        font-weight: 400;
      }
    }

    &:last-child {
      text-align: center;

      button {
        //border: 1px solid @color;
        //color: @color;
        font-size: 20px;
        border-radius: 20px;
        width: 160px;
        height: 40px;
        background: #ffffff;
      }
    }
  }
}
</style>
