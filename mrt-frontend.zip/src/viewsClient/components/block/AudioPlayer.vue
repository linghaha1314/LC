<template>
  <div :style="{height:height,background:'#f2f2f2'}" class="flex column justify-between">
    <img style="height:calc(100% - 50px)" :src="cover"/>
    <audio ref="audioRef"
           :defaultPlaybackRate="1.0"
           style="width: 100%;" preload="auto" controls @timeupdate="getCurrentTime"
           :draggable="false"
           @seeking="seekStart"
           @seeked="seekEnd"
           @oncanplay="oncanplay"
           controlslist="nodownload noremoteplayback">
      <source :src="src" type="audio/mp3">
    </audio>
  </div>
</template>

<script lang="ts" setup>
import { defineProps, nextTick, defineEmits, onMounted, reactive, ref, watch } from 'vue'
import { start } from '@popperjs/core'

const audioRef = ref()

const duration = ref(0)

const audioData = reactive({
  startSeekTime: 0,
  endSeekTime: 0,
  currentTime: 0
})

const props = defineProps({
  height: {
    type: String,
    default: '360px'
  },
  cover: {
    type: String,
    default: require('../../../assets/images/video-course.png')
  },
  src: {
    type: String,
    default: require('../../../assets/test.mp3')
  },
  allowMaxSeek: {
    type: Number,
    default: 0
  }
})

const emit = defineEmits(['getCurrentTime', 'update:totalTime'])

const getCurrentTime = (val) => {
  if (audioData.currentTime !== Math.ceil(val.target.currentTime) && props.allowMaxSeek !== Math.ceil(val.target.currentTime)) {
    console.log('currentIMe', audioData.currentTime, Math.ceil(val.target.currentTime))
    emit('getCurrentTime', Math.ceil(val.target.currentTime))
  }
}

const seekStart = (val) => {
  audioData.startSeekTime = val.target.currentTime
  console.log('???--start', val.target.currentTime)
}

const seekEnd = (val) => {
  audioData.endSeekTime = val.target.currentTime
  console.log('???--seekEnd', val.target.currentTime)
}
// audioRef.value.addEventListener('timeupdate', (val) => {
//   console.log('The currentTime attribute has been updated. Again.', val)
// })
// const audio = ref(null)
// audio.addEventListener('timeupdate', () => {
//
// })
// 一样要记录时间和跳转时间！！后期修改
onMounted(() => {
  nextTick(() => {
    audioRef.value.controlslist = 'nodownload noremoteplayback'
    audioRef.value.oncanplay = () => {
      if (duration.value === 0) {
        duration.value = audioRef.value.duration
        emit('update:totalTime', duration.value)
      }
    }
  })
})
watch(() => props.allowMaxSeek, (val) => {
  if (val && audioRef.value.currentTime === 0) {
    console.log('val', val)
    audioRef.value.currentTime = props.allowMaxSeek
  }
})
</script>

<style scoped>

</style>
