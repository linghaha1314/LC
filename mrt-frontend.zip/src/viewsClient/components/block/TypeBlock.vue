<template>
  <!-- 卡片类型一 图片在上；自上而下-->
  <el-card v-if="type === 1" :body-style="{ padding: '0px' }" :style="{ width: width + 'px' }" class="card"
    shadow="hover">
    <el-row class="img-box">
      <img @error="$tools.imgError(img)" :src="img || require('../../../assets/images/client/err-default.jpg')" />
      <!--      <img @error="$tools.imgError(img,require('../../../assets/images/client/err-default.jpg'))"-->
      <!--           :src="img"-->
      <!--           alt/>-->
    </el-row>
    <el-row class="content-wrapper">
      <div class="flex font-bold details" style="height:45px">
        <slot name="title"></slot>
      </div>
      <div class="sub-title">
        <span>
          <slot name="sub-title"></slot>
        </span>
      </div>
      <div class="details">
        <slot name="content"></slot>
      </div>
    </el-row>
    <span class="left-top-tag">
      <slot name="leftTopTag"></slot>
      <span v-if="leftTopTag" v-html="leftTopTag"></span>
    </span>
    <span class="right-top-tag">
      <span class="right-top-text">
        <slot name="rightTopTag"></slot>
        <span v-if="rightTopTag" v-html="leftTopTag"></span>
      </span>
    </span>
  </el-card>
  <!-- 卡片类型二；图片在左，水平排列-->
  <div v-else-if="type === 2" id="recommend-block" @click="$tools.go(`/client/coursePlay/${id}`)">
    <div :style="{ height: imgHeight + 'px' }" class="img-wrapper">
      <img :onerror="$tools.imgError(img, '../../../assets/images/client/err-default.jpg')"
        :src="img || require('../../../assets/images/client/err-default.jpg')" />
    </div>
    <div class="right-wrapper">
      <div>
        <p class="title no-margin details">
          <span class="font-bold" v-html="title"></span>
          <slot name="title"></slot>
        </p>
        <p class="sub-title no-margin">
          <span v-html="subTitle"></span>
          <slot name="sub-title"></slot>
        </p>
      </div>
      <p class="content no-margin">
        <span v-html="content"></span>
        <slot name="content"></slot>
      </p>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { defineProps } from 'vue'

const props = defineProps({
  width: {
    type: Number,
    default: () => {
      return 224
    }
  },
  id: {
    type: String,
    default: ''
  },
  type: {
    type: Number,
    default: 1
  },
  imgHeight: {
    type: Number,
    default: 80
  },
  title: {
    type: String,
    default: ''
  },
  subTitle: {
    type: String,
    default: ''
  },
  content: {
    type: String,
    default: ''
  },
  img: {
    type: String,
    default: require('../../../assets/images/client/err-default.jpg')
  },
  leftTopTag: {
    type: String,
    default: ''
  },
  rightTopTag: {
    type: String,
    default: ''
  }
})
</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/commen.less";

.card {
  border-radius: 8px;
  overflow: hidden;
  position: relative;
  cursor: default;

  &:hover {
    box-shadow: 0 4px 16px 0 rgb(0 0 0 / 12%);
  }

  .content-wrapper {
    padding: 8px;

    &>div {
      width: 100%;
    }

    .details {
      .ellipsis-num(2)
    }
  }

  .img-box {
    height: 126px;
    width: 100%;
    object-fit: cover;
  }

  .left-top-tag {
    position: absolute;
    background: rgb(203, 162, 101);
    border-radius: 0 0 6px 0;
    color: #ffffff;
    top: 0;
    left: 0;
    font-size: 12px;
  }

  .right-top-tag {
    position: absolute;
    background: rgb(203, 162, 101);
    border-radius: 0 6px 0px 6px;
    color: #ffffff;
    top: 0;
    right: 0;
    //padding: 2px 8px;
    font-size: 12px;
    cursor: default;
  }
}

#recommend-block {
  display: flex;
  cursor: default;
  box-sizing: border-box;
  padding: 8px;

  &:hover {
    box-shadow: 0 4px 16px 0 rgb(0 0 0 / 12%);
  }

  .img-wrapper {
    width: 100%;
    flex: 2;
    height: auto;

    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 4px;
    }
  }

  .right-wrapper {
    flex: 3;
    padding: 0 0 0 8px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .title {
      font-size: 13px;
      .ellipsis-num(2)
    }
  }
}
</style>
