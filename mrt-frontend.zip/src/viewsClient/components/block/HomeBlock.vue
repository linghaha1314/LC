<template>
  <el-card shadow="hover" @click="go" class="card-box" v-if="obj">
    <el-row></el-row>
    <el-row>
      <img src="@/assets/images/home-block.png" alt/>
    </el-row>
    <el-row class="title">{{ obj.name }}</el-row>
    <el-row class="introd">{{ obj.introd }}</el-row>
  </el-card>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: ['obj']
}
</script>
<style lang="less" scoped>
//.el-card {
//  color: #999999;
//  background: #ffffff;
//  display: flex;
//  flex-direction: column;
//  justify-content: center;
//  align-items: center;
//  text-align: center;
//  border: none;
//
//  &:hover {
//    // transform: scale(1.04);
//  }
//
//  .title {
//    font-size: 24px;
//    font-weight: 600;
//    color: #222222;
//    margin-top: 17px;
//    margin-bottom: 14px;
//  }
//
//  .introd {
//    margin: 0 auto;
//    text-align: center;
//    width: 50%;
//    font-size: 12px;
//    font-weight: 400;
//    .ellipsis-num(2);
//  }
//}
</style>
