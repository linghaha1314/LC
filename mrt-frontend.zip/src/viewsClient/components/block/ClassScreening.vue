<template>
  <div class="class-screening">
    <el-col class="class-type">{{ title }}:</el-col>
    <span :class="{ 'active-selected': !selectedId }" @click="changeScreen(-1)"
    >不限</span
    >
    <span
      :class="{ 'active-selected': selectedId == item.id }"
      v-for="item in classArr"
      :key="item.id"
      @click="changeScreen(item)"
    >{{ item.name }}</span
    >
  </div>
</template>
<script>
export default {
  data () {
    return {
      selectedId: ''
    }
  },
  props: ['classArr', 'title'],
  methods: {
    changeScreen (item) {
      if (!item) {
        this.selectedId = ''
      } else {
        this.selectedId = item.id
      }
    }
  }
}
</script>
<style lang="less" scoped>
.class-screening {
  width: 100%;
  line-height: 44px;
  cursor: default;

  .el-col {
    display: inline-block;
    width: auto;
  }

  .class-type {
    font-size: 18px;
    font-weight: bold;
    margin-right: 20px;
  }

  span {
    border-radius: 4px;
    display: inline-block;
    padding: 0 13px;
    height: 26px;
    line-height: 26px;

    &.active-selected {
      //background: @color;
      color: #ffffff;
    }
  }
}
</style>
