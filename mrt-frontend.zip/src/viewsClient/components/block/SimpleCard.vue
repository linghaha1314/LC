<template>
  <el-card body-style="padding:0px 10px" shadow="hover" class="simple-card">
    <div class="simple-wrapper">
      <div class="img-wrapper">
        <img :onerror="$tools.imgError(img, '../../../assets/images/client/err-default.jpg')"
             :src="img || require('../../../assets/images/client/err-default.jpg')"/>
      </div>
      <div class="right-wrapper">
        <div class="font-bold" style="width: 100%;white-space: pre-wrap;height:42px;margin-top:10px">
          <small>
            <slot name="title"></slot>
          </small>
        </div>
        <div style="margin-bottom:10px"><small>
          <slot name="sub-title"></slot>
        </small></div>
      </div>
    </div>
  </el-card>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'

const props = defineProps({
  width: {
    type: Number,
    default: () => {
      return 224
    }
  },
  img: {
    type: String,
    default: ''
  }
})
</script>

<style scoped lang="less">
@import (once) "~@/assets/css/commen.less";

.simple-card {
  cursor: pointer;
}

.simple-wrapper {
  display: flex;
  align-items: center;
  width: 360px;

  .img-wrapper {
    img {
      height: 60px;
      width: 60px;
      border-radius: 50%;
    }
  }

  .right-wrapper {
    margin-left: 8px;
  }
}
</style>
