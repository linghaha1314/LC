<template>
  <div class="ranking-wrapper">
    <div class="top flex align-center padding-top padding-bottom ranking-head">
      <span>
        <img class="king margin-start margin-end" src="../../../assets/images/client/home-king.png">
      </span>
      <span class="colorOrange" style="font-size: 24px;">
        <slot></slot>
      </span>
    </div>
    <el-carousel height="514px" indicator-position="outside">
      <el-carousel-item v-for="item in 4" :key="item">
        <ul>
          <li v-for="(dd,index) of list.slice(item-1,item+4)" :key="dd" class="flex margin-bottom"
              @click="$tools.go(`/client/coursePlay/${dd.id}`)">
            <div class="font-bold top-font" style="min-width: 54px;text-align: center">
              {{ index + 1 + ((item - 1) * 5) }}
            </div>
            <div class="flex align-center"><img :onerror="$tools.imgError(dd.img)" :src="dd.img" class="cover"/></div>
            <div class="flex column justify-between">
              <div class="font-bold title">{{ dd.name }}</div>
              <div><small>四川大学华西医院</small></div>
              <div><small>45163人参加</small></div>
            </div>
          </li>
        </ul>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'

const props = defineProps({
  list: {
    type: Array,
    default: () => {
      return []
    }
  }
})
</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/commen.less";

.ranking-wrapper {
  width: 360px;
  background: #ffffff;
  border-radius: 12px;

  .title {
    .ellipsis-num(2)
  }

  .ranking-head {
    background: linear-gradient(to bottom, #fcf8ed, #fefbf5, #fff);
  }

  .king {
    height: 20px;
    width: 20px;
  }

  .cover {
    margin: 0 8px;
    width: 112px;
    height: 90px;
    border-radius: 12px;
  }

  .colorOrange {
    color: #d1802b;
  }

  ul {
    li {
      cursor: default;

      .top-font {
        font-size: 20px;
        color: #b8b8b8;
        font-family: Helvetica-BoldOblique, Helvetica;
        padding-top: 8px;
      }

      &:nth-child(1) {
        .top-font {
          color: #FA5055;
        }
      }

      &:nth-child(2) {
        .top-font {
          color: #FF7130;
        }
      }

      &:nth-child(3) {
        .top-font {
          color: #FFB425;
        }
      }
    }
  }
}
</style>
