<template>
  <div class="list-block">
    <div class="img-box">
      <img :onerror="$tools.imgError(obj.img,'../../../assets/images/client/err-default.jpg')"
           :src="obj.img || require('../../../assets/images/client/err-default.jpg')"
           alt/>
      <!--      <span class="duration-tag">0:30:25</span>-->
    </div>
    <div class="right-box">
      <div class="title font-bold">{{ obj.name }}
        <span v-if="obj.typeNames" style="height:45px"><span
          class="tag">{{
            obj.typeNames
          }}</span></span>
      </div>
      <div v-if="obj['lecturerName']" class="color999"><small>主讲人：{{ obj['lecturerName'] }}</small>
      </div>
      <div v-if="obj['majorName']" class="color999"><small>所属专业：{{ obj['majorName'] }}</small>
      </div>
      <div v-if="obj['sectionName']" class="color999"><small>所属科室：{{ obj['sectionName'] }}</small>
      </div>
      <!--      <p class="name-study-box color999"><small>最新最全详解，打开医学大门,高品质教学资源,独家精品课程在线观看（禁止分享）</small></p>-->
      <div class="name-study-box color999">
         <span class="study-person">
          已经有
          <span class="font-orange">{{ obj['staffNum'] || 0 }}</span>
          人参加
       </span>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { defineProps } from 'vue'
import tools from '../../../utils/tool'

const props = defineProps({
  obj: {
    type: Object,
    default: () => {
      return {}
    }
  }
})

</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/commen.less";

.list-block {
  box-sizing: border-box;
  height: 180px;
  background: #ffffff;
  border: 1px solid #eeeeee;
  border-radius: 4px;
  padding: 20px 37px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  width: 100%;
  cursor: default;

  &:hover .title {
    color: @color;
  }

  &:hover {
    box-shadow: 0 4px 16px 0 rgb(0 0 0 / 12%);
  }

  &:hover .img-box {
    transform: scale(1.1);
  }

  .img-box {
    margin-right: 40px;
    width: 246px;
    height: 140px;
    border-radius: 4px;
    margin-top: 0;
    position: relative;

    img {
      border-radius: 4px;
      width: 100%;
      height: 100%;
    }

    .duration-tag {
      position: absolute;
      display: inline-block;
      text-align: center;
      height: 27px;
      line-height: 27px;
      width: 70px;
      right: 0;
      bottom: 0;
      background: #000000;
      color: #ffffff;
      font-size: 14px;
      opacity: 0.5;
    }
  }

  .right-box {
    height: 100%;
    width: calc(100% - 246px - 40px);
    display: flex;
    flex-direction: column;
    justify-content: space-between;

    .title {
      font-weight: bold;
      font-size: 16px;
    }

    .name-study-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
</style>
