<template>
  <div class="ali-player">
    <div :id="playerId" :style="playStyle" class="prism-player" @click="playSet($event)"></div>
  </div>
</template>

<script lang="ts">
import { defineComponent, nextTick, onMounted, reactive, toRefs, watch } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'
import { Element } from 'zrender/index'
import router from '@/router'

export default defineComponent({
  name: 'AliPlayer',
  props: {
    playStyle: {
      type: String,
      default: ''
    },
    autoplay: {
      type: Boolean,
      default: false
    },
    isLive: {
      type: Boolean,
      default: false
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '320px'
    },
    controlBarVisibility: {
      type: String,
      default: 'always'
    },
    useH5Prism: {
      type: Boolean,
      default: false
    },
    useFlashPrism: {
      type: Boolean,
      default: false
    },
    vid: {
      type: String,
      default: ''
    },
    playauth: {
      type: String,
      default: ''
    },
    source: {
      type: String,
      default: ''
    },
    cover: {
      type: String,
      default: '/attachs/home-banner.png'
    },
    format: {
      type: String,
      default: 'm3u8'
    },
    skinLayout: {
      type: Array,
      default: function () {
        return []
      }
    },
    autoPlayDelay: {
      type: Number,
      default: 0
    },
    totalTime: {
      type: [String, Number],
      default: 0
    },
    isAllowSeek: {
      type: [Boolean],
      default: false
    },
    allowMaxSeek: {
      type: Number,
      default: 0
    }
  },
  emits: ['play', 'getCurrentTime', 'getStatus', 'update:totalTime', 'ready'],
  setup: (props: any, ctx) => {
    const state = reactive({
      startSecond: 0, // 初始的播放秒
      sliderTime: 0, // 当前播放时间
      duration: 0, // 总时间
      lastTime: 0, // 最近一次播放时间
      // 播放id
      playerId: 'aliplayer_' + Math.random().toString(36).substr(2),
      scriptTagStatus: 0,
      isReload: false,
      instance: {} as any,
      playSkin: [
        {
          name: 'H5Loading',
          align: 'blabs',
          x: 300,
          y: 180
        },
        {
          name: 'errorDisplay',
          align: 'tlabs',
          x: 0,
          y: 0
        },
        { name: 'infoDisplay' },
        {
          name: 'tooltip',
          align: 'blabs',
          x: 0,
          y: 56
        },
        { name: 'thumbnail' },
        {
          name: 'bigPlayButton',
          align: 'blabs',
          x: 30,
          y: 80
        },
        {
          name: 'controlBar',
          align: 'blabs',
          x: 0,
          y: 0,
          children: [
            {
              name: 'progress',
              align: 'tlabs',
              x: 0,
              y: 0
            },
            {
              name: 'playButton',
              align: 'tl',
              x: 15,
              y: 26
            },
            {
              name: 'nextButton',
              align: 'tl',
              x: 10,
              y: 26
            },
            {
              name: 'timeDisplay',
              align: 'tl',
              x: 10,
              y: 24
            },
            {
              name: 'fullScreenButton',
              align: 'tr',
              x: 10,
              y: 25
            },
            {
              name: 'streamButton',
              align: 'tr',
              x: 10,
              y: 23
            },
            {
              name: 'volume',
              align: 'tr',
              x: 10,
              y: 25
            }
          ]
        },
        {
          name: 'fullControlBar',
          align: 'tlabs',
          x: 0,
          y: 0,
          children: [
            {
              name: 'fullTitle',
              align: 'tl',
              x: 25,
              y: 6
            },
            {
              name: 'fullNormalScreenButton',
              align: 'tr',
              x: 24,
              y: 13
            },
            {
              name: 'fullTimeDisplay',
              align: 'tr',
              x: 10,
              y: 12
            },
            {
              name: 'fullZoom',
              align: 'cc'
            }
          ]
        }
      ],
      startSeekTime: 0,
      endSeekTime: 0
    })
    const insertScriptTag = () => {
      tools.loadScript('https://g.alicdn.com/de/prismplayer/2.12.1/aliplayer-min.js').subscribe(r => {
        if (r) {
          initAliPlayer()
        }
      })
    }
    const initAliPlayer = () => {
      nextTick(() => {
        state.instance = window.Aliplayer({
          id: state.playerId,
          autoplay: false,
          playsinline: false,
          format: props.format,
          width: props.width,
          height: props.height,
          controlBarVisibility: props.controlBarVisibility,
          useH5Prism: true, // 指定使用h5
          useFlashPrism: props.useFlashPrism, // 使用flash
          // vid: props.vid, // vid才支持选择视频格式！！
          playauth: props.playauth,
          source: props.source.indexOf('http') > -1 ? props.source : (window.location.protocol + '//' + window.location.host + props.source),
          cover: props.cover, // 封面
          skinLayout: state.playSkin, // 皮肤定制
          x5_video_position: 'top',
          x5_type: 'h5',
          x5_fullscreen: false,
          x5_orientation: 2,
          autoPlayDelay: props.autoPlayDelay,
          autoPlayDelayDisplayText: ''
        })
        // 绑定事件，当 AliPlayer 初始化完成后，将编辑器实例通过自定义的 ready 事件交出去
        state.instance.on('ready', () => {
          state.duration = getDuration() // 获取总时长
          ctx.emit('update:totalTime', state.duration)
          ctx.emit('ready', true)
        })
        state.instance.on('play', () => {
          if (!store.state.clientUserInfo) {
            store.commit('setClientShowLoginDialog', true)
            pause()
            return
          }
          ctx.emit('play', state.instance)
        })
        state.instance.on('pause', () => {
          // state.$emit('pause', state.instance)
        })
        state.instance.on('ended', () => {
          // state.$emit('ended', state.instance)
        })
        state.instance.on('seek', () => {
          console.log('????==>>>', state.instance)
        })
        state.instance.on('startSeek', (startTime) => {
          // console.log('startTime1-----1', state.startSeekTime)
          state.startSeekTime = Math.floor(startTime.paramData)
          // console.log('startTime11', state.startSeekTime)
        })
        state.instance.on('completeSeek', (endTime) => {
          state.endSeekTime = Math.floor(endTime.paramData)
          /* 不允许快进；父传子一个值，如果这个值为false,则不能拖动 */
          if (!props.isAllowSeek && state.endSeekTime - state.startSeekTime > 1 && props.allowMaxSeek < state.endSeekTime) {
            // seek(state.startSeekTime)
            // tools.msg('一步一个脚印，不要急于求成哦！', 'warning')
          }
        })
        // 再次播放会触发！！
        state.instance.on('playing', () => {
          // state.$emit('playing', state.instance)
        })
        state.instance.on('liveStreamStop', () => {
          // state.$emit('liveStreamStop', state.instance)
        })
        state.instance.on('m3u8Retry', () => {
          // state.$emit('m3u8Retry', state.instance)
        })
        state.instance.on('hideBar', () => {
          // state.$emit('hideBar', state.instance)
        })
        state.instance.on('waiting', () => {
          // state.$emit('waiting', state.instance)
        })
        state.instance.on('snapshoted', () => {
          // state.$emit('snapshoted', state.instance)
        })
        // 获取实时播放的时间
        state.instance.on('timeupdate', () => {
          // 计算sliderTime
          getCurrentTime()
          if (getCurrentTime()) {
            state.sliderTime = parseInt(
              String((getCurrentTime() / state.duration) * 100)
            )
          }
          if (state.startSecond !== parseInt(getCurrentTime())) {
            if (state.startSecond > 0 && getCurrentTime() === 0) {
              return
            }
            state.startSecond = parseInt(getCurrentTime())
            ctx.emit('getCurrentTime', state.startSecond)
            state.lastTime = state.startSecond
            return parseInt(String(state.startSecond))
          }
        })
        state.instance.on('requestFullScreen', () => {
          // state.$emit('requestFullScreen', state.instance)
        })
        state.instance.on('cancelFullScreen', () => {
          // state.$emit('cancelFullScreen', state.instance)
        })
        state.instance.on('error', (e) => {
          const dom: any = document.querySelector('.prism-button-orange')
          const iPUrl = window.location.protocol + '//' + window.location.host
          if (iPUrl.indexOf('http://117.159.24.46') < 0) {
            const noticeDom: any = document.querySelector('.prism-error-content')
            noticeDom.innerHTML = '<p style="color:#f2f2f2">链接被限制🚫，请访问手机端或者外网地址</p>'
          }
          dom.innerHTML = '查看链接'
          dom.setAttribute('href', props.source)
          console.log('error', e.paramData, state.instance)
        })
      })
    }
    const playSet = (event) => {
      if (event.path[0] === document.querySelector('video')) {
        if (getStatus() === 'playing') {
          pause()
        } else if (getStatus() === 'ready') {
          play()
        } else if (getStatus() === 'pause') {
          play()
        }
      }
    }
    /**
     * 播放视频;开始才会触发
     */
    const play = () => {
      state.instance.play()
    }
    /**
     * 暂停视频
     */
    const pause = () => {
      state.instance.pause()
    }
    /**
     * 重播视频
     */
    const replay = () => {
      state.instance.replay()
    }
    /**
     * 跳转到某个时刻进行播放
     * @argument time 的单位为秒
     */
    const seek = (time) => {
      setTimeout(() => {
        console.log('===>>>跳转到时间点', time)
        state.instance.seek(time)
      }, 200)
    }
    const startSeek = (time) => {
      console.log('--->>Jump to a time to start', time)
    }
    const completeSeek = (time) => {
      console.log('--->>Jump to a time to complete', time)
    }
    /**
     *播放状态
     */
    const getStatus = () => {
      ctx.emit('getStatus', state.instance.getStatus())
      return state.instance.getStatus()
    }
    /**
     * 获取当前时间 单位秒
     */
    const getCurrentTime = () => {
      return state.instance.getCurrentTime()
    }
    /**
     *获取视频总时长，返回的单位为秒
     * 返回的单位为秒
     */
    const getDuration = () => {
      return state.instance.getDuration()
    }
    /**
     获取当前的音量，返回值为0-1的实数ios和部分android会失效
     */
    const getVolume = () => {
      return state.instance.getVolume()
    }
    /**
     设置音量，vol为0-1的实数，ios和部分android会失效
     */
    const setVolume = (vol) => {
      state.instance.setVolume(vol)
    }
    /**
     *直接播放视频url，time为可选值（单位秒）目前只支持同种格式（mp4/flv/m3u8）之间切换暂不支持直播rtmp流切换
     *@argument url 视频地址
     *@argument time 跳转到多少秒
     */
    const loadByUrl = (url, time) => {
      state.instance.loadByUrl(url, time)
    }
    /**
     * 设置播放速度
     *@argument speed 速度
     */
    const setSpeed = (speed) => {
      state.instance.setSpeed(speed)
    }
    /**
     * 设置播放器大小w,h可分别为400px像素或60%百分比chrome浏览器下flash播放器分别不能小于397x297
     *@argument w 播放器宽度
     *@argument h 播放器高度
     */
    const setPlayerSize = (w, h) => {
      state.instance.setPlayerSize(w, h)
    }

    const reloadPlayer = () => {
      state.isReload = true
      initAliPlayer()
      state.isReload = false
    }

    onMounted(() => {
      if (window.Aliplayer !== undefined) {
        // 如果全局对象存在，说明编辑器代码已经初始化完成，直接加载编辑器
        state.scriptTagStatus = 2
        initAliPlayer()
      } else {
        insertScriptTag()
      }
    })

    return {
      ...toRefs(state),
      insertScriptTag,
      initAliPlayer,
      playSet,
      play,
      pause,
      replay,
      seek,
      startSeek,
      reloadPlayer,
      getCurrentTime,
      setPlayerSize,
      setSpeed,
      loadByUrl,
      setVolume,
      getVolume,
      getDuration,
      completeSeek,
      getStatus
    }
  }
})
</script>

<style lang="less">
@import url("https://g.alicdn.com/de/prismplayer/2.8.1/skins/default/aliplayer-min.css");

.error-ui {
  position: absolute;
  top: 0;
  left: 0;
  background: pink;
  z-index: 9999;
}

.prism-controlbar {
  bottom: 20px !important;
}

.prism-cover {
  background-repeat: no-repeat !important;
  background-size: 100% 100% !important;
}

.ali-player {
  position: relative;
  height: 100%;
}

.prism-player .prism-volume-control {
  z-index: 99 !important;
}
</style>
