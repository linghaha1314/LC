<template>
  <div class="medical-block">
    <img src="@/assets/images/home-block2.png" alt />
    <el-row class="mantle"></el-row>
    <el-row class="content-box">
      <div class="logo-name">
        <span>logo</span>
        <span>四川省华西医院分年会</span>
      </div>
      <el-row class="center-box">
        <el-col class="course-name">2019年华西医院病毒峰会年度总结(换届选举会)</el-col>
        <el-col class="course-time">2019年10月21日 14:00---17:00</el-col>
      </el-row>
      <el-row class="foot-el" type="flex" justify="space-between" align="middle">
        <p>开播时间：2020.09.15</p>
        <p>
          <i>tu</i>正在进行
        </p>
      </el-row>
    </el-row>
  </div>
</template>
<script>
export default {
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
.medical-block {
  position: relative;
  height: 240px;
  width: 400px;
  img {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
  }
  .content-box {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    .logo-name {
      padding-top: 20px;
      padding-left: 20px;
      text-align: left;
      font-size: 14px;
      font-family: ADZongYi-A001;
      font-weight: normal;
      color: #ffffff;
    }
    .center-box {
      position: relative;
      margin-top: 40px;
      padding: 0 20px;
      text-align: center;

      .course-name {
        font-size: 22px;
        font-family: ADZongYi-A001;
        font-weight: normal;
        color: #ffffff;
        margin-bottom: 19px;
      }
      .course-time {
        background: #ffffff;
        border-radius: 11px;
        padding: 0 17px;
        height: 21px;
        font-family: FZCuHeiSongS-B-GB;
        font-weight: 400;
        color: #1069af;
      }
    }
    .foot-el {
      position: absolute;
      height: 40px;
      line-height: 40px;
      width: 100%;
      bottom: 0;
      p {
        height: 100%;
        color: #ffffff;
        margin: 0;
        font-weight: 400;
        text-align: center;

        &:first-child {
          width: 71%;
          background: #000000;
          font-size: 17px;
          opacity: 0.5;
        }
        &:last-child {
          width: 29%;
          background: @color;
        }
      }
    }
  }
  .mantle {
    background: linear-gradient(0deg, #63b7cf, #1268ab);
    opacity: 0.51;
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
}
</style>
