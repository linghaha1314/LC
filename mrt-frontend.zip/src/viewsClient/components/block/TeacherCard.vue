<template>
  <el-card>
    <el-row>
      <el-col :span="8" class="flex align-center justify-content">
        <img :onerror="$tools.imgError(teacher['avatar'])" :src="teacher['avatar'] || state.defaultImg"
             alt
             style="height: 40px;width:40px;border-radius: 4px;object-fit: cover"/>
      </el-col>
      <el-col :span="1"></el-col>
      <el-col :span="15">
        <div style="padding-top: 8px"><small>{{ teacher['organizationName'] }}</small></div>
        <div style="padding-top: 8px">
          实践技能
        </div>
      </el-col>
    </el-row>
    <el-row class="padding-top">
      <el-col :span="8" class="nowrap font-bold flex justify-content">{{ teacher.name }}</el-col>
      <el-col :span="1"></el-col>
      <el-col :span="15">
        <div><span class="tag-gray">善于总结</span><span class="tag-gray">幽默风趣</span></div>
      </el-col>
    </el-row>
  </el-card>
</template>

<script lang="ts" setup>
import { defineProps, reactive } from 'vue'

const state = reactive({ defaultImg: require('../../../assets/images/home-block.png') })
const props = defineProps({
  teacher: {
    type: Object,
    default: () => {
      return {}
    }
  }
}
)
</script>

<style lang="less" scoped>
.el-card {
  width: 250px;

  .avatar {
    height: 54px;
    width: 54px;
    border-radius: 50%;
  }

}
</style>
