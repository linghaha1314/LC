<template>
  <!-- 三段式卡片 -->
  <el-card class="card">
    <el-row class="header">
      <slot name="header"></slot>
    </el-row>
    <el-row class="main">
      <slot name="main"></slot>
    </el-row>
    <el-row class="footer">
      <slot name="footer"></slot>
    </el-row>
  </el-card>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: {
    content: {
      type: String,
      default: ''
    }
  },

  methods: {
    goMore () {
      console.log(111)
    }
  }
}
</script>
<style lang="less" scoped>
.card {
  background: #ffffff;
  box-sizing: border-box;
  position: relative;
  padding-bottom: 30px;

  & > .el-row {
    width: 100%;
  }

  .header {
    height: 74px;
    line-height: 74px;
  }

  .main {
    color: #222222;
    height: 100%;
    font-weight: 400;
    padding: 15px 24px;

    .none {
      height: 300px;
      line-height: 200px;
      font-weight: 400;
      color: #999999;
      text-align: center;
    }
  }

  .footer {
    width: 100%;
    line-height: 46px;
    text-align: center;
    color: #999999;
    position: absolute;
    bottom: 0;
    left: 0;
    border-top: 1px solid #eeeeee;
  }
}
</style>
