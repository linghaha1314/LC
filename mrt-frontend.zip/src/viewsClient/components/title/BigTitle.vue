<template>
  <el-row class="clr" type="flex" justify="space-between">
    <el-col>
      <div class="box-tag"></div>
      <div class="title-name">{{ title }}</div>
      <div class="detail" v-if="introd">{{ introd }}</div>
    </el-col>
    <el-col class="getmore">
      <slot></slot>
    </el-col>
  </el-row>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: ['title', 'introd']
}
</script>
<style lang="less" scoped>
//.el-row {
//  line-height: 26px;
//  white-space: nowrap;
//
//  .el-col {
//    &:first-child {
//      white-space: nowrap;
//      div {
//        float: left;
//        &.box-tag {
//          width: 4px;
//          height: 26px;
//          background: @color;
//        }
//        &.title-name {
//          font-size: 20px;
//          font-weight: 600;
//          margin-left: 10px;
//          margin-right: 15px;
//        }
//        &.detail {
//          font-size: 20px;
//          font-weight: 600;
//          color: #999999;
//          @media screen and (max-width: 480px) {
//            display: none;
//          }
//        }
//      }
//    }
//    &:last-child {
//      text-align: right;
//      white-space: nowrap;
//    }
//  }
//}
</style>
