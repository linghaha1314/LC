<template>
  <el-row
    class="course-title"
    type="flex"
    justify="space-between"
    align="middle"
  >
    <el-col :span="18">
      <el-row type="flex" justify="start" align="middle">
        <i
          class="el-icon-arrow-left"
          @click="goBackCourse"
          style="font-size: 24px; font-weight: bolder"
        ></i>
        <div class="title">
          <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item @click="goHome">首页</el-breadcrumb-item>
            <el-breadcrumb-item @click="goBackCourse">{{
                courseHead.categoryName
              }}
            </el-breadcrumb-item>
            <el-breadcrumb-item>{{ courseHead.name }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>
      </el-row>
    </el-col>
    <el-col :span="6">
      <div class="login-box" v-if="!clientUserObj.name" @click="login">
        <i class="el-icon-user"></i>
        <span>[登录]</span>
      </div>
      <div class="personal" v-else>
        <el-avatar
          icon="el-icon-user-solid"
          :src="clientUserObj.img"
          :size="40"
          fit="cover"
        ></el-avatar>
        <span>{{ clientUserObj.name }}</span>
      </div>
    </el-col>
    <!-- 登录 -->
    <login-poup></login-poup>
  </el-row>
</template>
<script>
import Login from '@/viewsClient/components/LoginDialog.vue'

export default {
  data () {
    return {
      clientUserObj: {}
    }
  },
  components: {
    'login-poup': Login
  },
  mounted () {
    if (window.localStorage.getItem('clientUserObj')) {
      this.clientUserObj = JSON.parse(
        window.localStorage.getItem('clientUserObj')
      )
    }
  },
  props: ['courseHead'],
  methods: {
    goBackCourse () {
      this.$emit('outPoup', `/client/course/${this.$route.query.courseId}`)
    },
    goHome () {
      this.$emit('outPoup', `/client/home`)
    },
    login () {
      this.$store.commit('$_setShowLoginPopover', true)
    }
  }
}
</script>
<style lang="less" scoped>
.course-title {
  height: 60px;
  padding: 0 20px;
  font-weight: bold;

  .el-col {
    padding-right: 20px;

    &:first-child {
      i {
        margin-right: 20px;
      }

      .title {
        margin-right: 40px;
      }
    }

    &:last-child {
      font-size: 14px;
      font-weight: 400px;
      text-align: right;
      display: flex;
      justify-content: flex-end;

      .login-box {
        width: 55px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;

        &:hover {
          cursor: pointer;
        }
      }

      .personal {
        display: flex;
        justify-content: center;
        align-content: center;
        cursor: default;

        span {
          margin-right: 10px;
          display: inline-block;
          line-height: 40px;
        }
      }
    }
  }
}
</style>
