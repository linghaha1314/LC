<template>
  <el-row type="flex" justify="space-between" align="middle" class="sub-title">
    <div class="left-box">
      <!-- <img :src="img" alt /> -->
      <span class="pre-icon">
        <slot name="preIcon"></slot>
      </span>
      <span>{{ title }}</span>
    </div>
    <div class="right-box">
      <slot name="right"></slot>
    </div>
  </el-row>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: {
    img: {},
    title: {
      type: String
    },
    buttonText: {
      type: String,
      default: ''
    }
  },
  methods: {
    goMore () {
      this.$emit('goMore')
    }
  }
}
</script>
<style lang="less" scoped>
.sub-title {
  display: flex;
  justify-content: space-between;
  align-items: center;

  .left-box {
    font-size: 18px;
    font-weight: bold;
    display: flex;
    justify-content: flex-start;
    align-items: center;

    .pre-icon {
      margin-right: 6px;
      color: pink;

      .iconfont {
        font-size: 20px;
      }
    }

    img {
      height: 20px;
      vertical-align: sub;
    }
  }

  .right-box {
    font-size: 16px;
    font-weight: 400;
    color: #999999;
  }
}
</style>
