<template>
  <div :style="{'justify-content':justify}" class="none">
    <img :src="img" alt/>
    <slot></slot>
  </div>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'

const props = defineProps({
  img: {
    type: String,
    default: require('@/assets/images/sad.png')
  },
  justify: {
    type: String,
    default: 'center'
  }
})
</script>

<style lang="less" scoped>
.none {
  height: 100%;
  text-align: center;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  font-size: 22px;
  font-weight: 600;
  color: #cccccc;

  img {
    vertical-align: middle;
    margin-right: 18px;
  }

}
</style>
