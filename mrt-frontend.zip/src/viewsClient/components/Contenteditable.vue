<template>
  <div :class="{ 'content-div': true, color999: contentText === placeholder }" :style="{ 'min-height': minHeight }"
    contenteditable="true" @blur="blur" @focus="focus" @input="inputFn($event)" v-html="contentText"></div>
</template>

<script lang="ts" setup>
import { defineEmits, defineProps, ref, watch } from 'vue'

const props = defineProps({
  content: {
    type: [String],
    default: ''
  },
  contentLen: {
    type: Number,
    default: 0
  },
  minHeight: {
    type: String,
    default: '180px'
  },
  placeholder: {
    type: String,
    default: '请输入内容'
  }
})

const contentText = ref(props.placeholder)

const emit = defineEmits(['update:content', 'update:contentLen'])

const inputFn = (val) => {
  if (val.target.innerHTML.indexOf(props.placeholder) > -1) {
    return
  }
  emit('update:content', val.target.innerHTML)
  emit('update:contentLen', val.target.innerText.length)
}

const focus = () => {
  contentText.value = ''
}

const blur = () => {
  if (!props.content.trim() || !props.content) {
    contentText.value = props.placeholder
  }
}

watch(() => props.content, (val) => {
  if (!val) {
    const dom: any = document.querySelector('.content-div')
    dom.innerHTML = ''
  }
})
</script>

<style scoped>
.content-div {
  min-height: 240px;
  padding: 16px;
}
</style>
