export default{
  data () {
    return {

    }
  },
  mounted () {
    if (this.$route.meta.isNav) {
      window.addEventListener('scroll', this.handleScroll) // 监听滚动事件，然后用handleScroll这个方法进行相应的处理
    } else {
      this.isFixedHead = true
    }
  },
  // 页面销毁
  destroy () {
    window.removeEventListener('scroll', this.handleScroll)
  },
  watch: {
    // 路由回到顶部
    $route: function (to, from) {
      document.body.scrollTop = 0
      document.documentElement.scrollTop = 0
    }
  }
}
