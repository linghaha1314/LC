<template>
  <template v-for="item in list" :key="item.id">
    <el-sub-menu :index="item.code" v-if="item.children.length>0">
      <template #title>{{ item.name }}</template>
      <home-menu :list="item['children']"></home-menu>
    </el-sub-menu>
    <el-menu-item :index="item.code" v-else>
      <span>{{ item.name }}</span>
    </el-menu-item>
  </template>
</template>
<script lang="ts" setup>
import { reactive, defineProps } from 'vue'
import tools from '@/utils/tool'

const props = defineProps({
  list: {
    type: Array,
    default: () => {
      return []
    }
  }
})
</script>

<style lang="less">
@import (once) '~@/assets/css/client.less';

</style>
