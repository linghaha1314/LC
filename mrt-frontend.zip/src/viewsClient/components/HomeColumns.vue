<template>
  <section class="container padding-top padding-start padding-end">
    <div class="flex justify-content padding-top "
         :style="{height,overflow:'hidden'}">
      <div style="width: 220px;border-radius: 6px 0 0 6px;height: 100%;overflow-y: auto"
           class="padding-start padding-top padding-bottom menu-wrapper">
        <el-tree :default-checked-keys="state.currentChecked" ref="tree" accordion :data="state.list"
                 :props="state.defaultProps" @node-click="handleNodeClick"/>
      </div>
      <div style="width:calc(100% - 220px);background: #e4d2aa" v-loading="state.loading"
           class="padding-bottom padding-top padding-start padding-end">
        <div class="flex flex-wrap align-center arrow-wrapper">
          <type-block v-for="course in state.courseList" :key="course.id"
                      :img="course['courseCover']" :width="200" class="margin-start margin-bottom"
                      @click="$tools.go(`/client/coursePlay/${course.id}`)">
            <template v-slot:title>
                <span style="height:45px">
                  <span v-if="course['typeName']" class="tag">{{ course.typeName }}</span>&nbsp;{{ course.courseName }}</span>
            </template>
            <template v-slot:sub-title>
              <p><small class="color666">主讲人：
                <span v-if="course['lecturerName']">{{
                    course['lecturerName']
                  }}</span>
                <small v-else class="color666">未知</small>
              </small>
              </p>
            </template>
            <template v-slot:content>
              <el-row>
                <small v-if="course['staffStudyNum'] > 0"><span class="primary-color font-bold">{{
                    course['staffStudyNum']
                  }}</span>&nbsp;人看过</small>
                <small v-else class="color666">最新课程</small>
              </el-row>
            </template>
          </type-block>
        </div>
        <div v-if="state.total > state.limit"
             class="flex justify-content align-center padding-top padding-bottom">
          <el-pagination :current-page="state['currentPage'] || 1" :page-size="state.limit" small background
                         layout="prev, pager, next" :total="state.total || 0" class="mt-4"
                         @current-change="currentPageChange"/>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts" setup>
import { onMounted, defineProps, reactive, ref } from 'vue'
import tools from '@/utils/tool'
import TypeBlock from '@/viewsClient/components/block/TypeBlock.vue'

const props = defineProps({
  height: {
    type: String,
    default: '712px'
  }
})
const tree: any = ref(null)
const state = reactive({
  currentChecked: [] as any[],
  defaultProps: {
    children: 'children',
    label: 'name',
    class: 'home-tree'
  },
  loading: false,
  currentCode: 'educate',
  currentPage: 1,
  limit: 8,
  total: 0,
  courseList: [],
  list: []
})

const homeColumns = async () => {
  await tools.get('homeColumns/getListByPage', {
    limit: 10000,
    sort: 'sequence asc'
  }).then(r => {
    state.list = r.list
  })
}
const getCourseList = async () => {
  state.loading = true
  await tools.clientGet('/homeColumns/getCourseByColumnCode', {
    code: state.currentCode ? (state.currentCode + '%') : '%%',
    limit: state.limit,
    offset: state.limit * (state.currentPage - 1)
  }).then(async r => {
    state.loading = false
    state.courseList = r.list
    state.total = r.total
  })
}

const currentPageChange = async (val) => {
  state.currentPage = val
  await getCourseList()
}

const handleNodeClick = async (data) => {
  if (data.children.length === 0 && !data.parentId) {
    for (let i = 0; i < tree.value.store._getAllNodes().length; i++) {
      tree.value.store._getAllNodes()[i].expanded = false
    }
  }
  state.currentCode = data.code
  state.currentPage = 1
  await getCourseList()
}

onMounted(async () => {
  await homeColumns()
  await getCourseList()
})
</script>

<style lang="less" scoped>
@import (once) '~@/assets/css/client.less';

.menu-wrapper {
  background: @color;
}

.arrow-wrapper {
  position: relative;

  .arrow {
    padding: 25px 10px;
    top: 50%;
    position: absolute;
    background: #f2f2f2;
    transform: translateY(-50%);
    color: #cccccc;
    border-radius: 4px;

    &:hover {
      color: #666666;
      background: @color;
    }
  }

  .arrow-left {
    left: -50px;
  }

  .arrow-right {
    right: -50px;
  }
}

/deep/ .el-tree {
  background: @color;
  color: #ffffff;

}

/deep/ .el-tree-node:focus > .el-tree-node__content {
  background: #e4d2aa;
}

/deep/ .el-tree-node:hover > .el-tree-node__content {
  background: #e4d2aa;
}

/deep/ .el-tree-node__content {
  padding: 10px 0;
}
</style>
