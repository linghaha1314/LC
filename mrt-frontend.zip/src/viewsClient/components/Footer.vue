<template>
  <div class="flex align-center" style="flex-direction: column;font-size: 12px;padding: 20px 0">
    <p class="nowrap">地址：郑州市黄河路33号（黄河路与文化路交叉口）</p>
    <p class="nowrap">电话：0371-67077777 急诊急救电话：0371-63945120 24小时电话：400-111-6707</p>
    <p class="nowrap">Copyright © 郑州人民医院 版权所有 All Rights Reserved.</p>
  </div>
  <!--    <div>-->
  <!--      <div class="qrcode-box">-->
  <!--        <img alt class="margin-bottom" src="@/assets/images/qrcode.png"/>-->
  <!--        <p class="nowrap">扫一扫关注公众号</p>-->
  <!--      </div>-->
  <!--    </div>-->
</template>
<script>
export default {
  data () {
    return {}
  }
}
</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/client.less";

.footer {
  background: #ffffff;
  box-sizing: border-box;
  color: #222222;
  height: auto;
  padding: 50px 0 20px 0;
  width: 100%;
  display: flex;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-content: center;

  .img-box {
    width: 400px;
    height: auto;

    img {
      width: 100%;
      height: auto;
      object-fit: cover;
    }
  }

  .qrcode-box {
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
  }
}
</style>
