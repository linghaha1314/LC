<template>
  <el-dialog
    v-model="store.state.showLoginDialog"
    :append-to-body="true"
    :before-close="handleClose"
    custom-class="login-dialog"
    width="800px"
  >
    <div class="dialog-content">
      <div class="left-box">
        <div class="font-bold" style="font-size: 30px;margin-bottom: 30px;">
          欢迎登录三知教育
        </div>
        <div class="img-box" style="margin-bottom: 120px">
          <img alt src="@/assets/images/client/login-back.png"/>
        </div>
      </div>
      <div class="right-box">
        <!--        <div class="head-close">-->
        <!--          <i class="el-icon-circle-close" @click="closeDialog('form')"></i>-->
        <!--        </div>-->
        <!-- 用户登录 -->
        <div v-if="tabActive === '机构人员'" class="login-wrapper">
          <el-form
            ref="formRef"
            :model="form"
            :rules="rules"
            status-icon
          >
            <el-form-item class="user-from" prop="username">
              <el-input
                v-model="form.username"
                placeholder="请输入账号"
                @keyup.enter="submitForm"
              >
              </el-input>
            </el-form-item>
            <el-form-item class="pass" prop="password">
              <el-input
                v-model="form.password" placeholder="请输入密码"
                type="password" @keyup.enter="submitForm">
              </el-input>
            </el-form-item>
            <el-form-item prop="code">
              <div style="display: flex;align-items: center;">
                <el-input
                  v-model="form.code"
                  autocomplete="off"
                  placeholder="验证码"
                  style="width:160px"
                  type="text" name="" oninput="value=value.replace(/[^\d]/g,'')"
                  maxlength="4"
                  @keydown.enter="submitForm()"
                ></el-input>
                <span style="margin-left: 20px" @click="getVerify" v-html="svg"></span>
              </div>
            </el-form-item>
          </el-form>
          <el-row justify="space-between" style="align-items: center" type="flex">
            <el-checkbox>记住密码</el-checkbox>
            <span>忘记密码</span>
          </el-row>
          <el-row>
            <el-button
              class
              style="
                        width: 360px;
                        height: 45px;
                        margin-top: 40px;
                        font-size: 20px;
                      "
              type="primary"
              @click="submitForm"
            >登录
            </el-button>
          </el-row>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script lang="ts" setup>
import store from '@/store'
import { onMounted, ref } from 'vue'
import { ElForm } from 'element-plus'
import tools from '@/utils/tool'
import CryptoJS from 'crypto-js'

const tabActive = ref('机构人员')

const svgCode = ref()
const svg = ref()

const validateCode = (rule, value, callback) => {
  if (form.value.code.toLowerCase() !== svgCode.value.toLowerCase()) {
    callback(new Error('请输入正确的验证码'))
  } else {
    callback()
  }
}

const rules = ref({
  username: [{
    required: true,
    message: '请输入帐号',
    trigger: 'blur'
  }],
  password: [{
    required: true,
    message: '请输入密码',
    trigger: 'blur'
  }],
  code: [{
    required: true,
    message: '请输入验证码',
    trigger: 'blur'
  }, {
    validator: validateCode,
    trigger: 'blur'
  }]
})

const form = ref({
  username: null,
  password: null,
  code: ''
})

const formRef = ref(ElForm)

const getVerify = () => {
  tools.get('/public/getCode').then(r => {
    svg.value = r.data
    svgCode.value = r.text
  })
}

const submitForm = () => {
  formRef.value.validate(async (valid) => {
    if (valid) {
      const data = JSON.parse(JSON.stringify(form.value))
      data.password = CryptoJS.AES.encrypt(data.password, 'kb12315').toString()
      const loading = tools.showLoading('登录中...')
      const loginResult = await tools.clientPost('login', data)
      if (loginResult.success) {
        store.commit('setClientToken', loginResult.token)
        await store.dispatch('getClientUserInfo', { id: loginResult.id })
      } else {
        tools.msgError(loginResult.msg)
      }
      tools.closeLoading(loading)
    }
  })
}

onMounted(() => {
  getVerify()
})
const handleClose = () => {
  store.commit('setClientShowLoginDialog', false)
}
</script>

<style lang="less">
@import (once) "~@/assets/css/commen.less";

.login-dialog {
  .el-dialog__header {
    padding-bottom: 30px;
  }

  .dialog-content {
    display: flex;

    .left-box {
      padding-right: 16px;
      flex: 1;
      border-right: 2px solid #f2f2f2;
    }

    .right-box {
      display: flex;
      float: right;
      width: 340px;

      .login-wrapper {
        width: 320px;
        padding: 0 32px;
        box-sizing: border-box;
      }
    }
  }
}

</style>
