<template>
  <template v-if="!menu.children || menu.children.length === 0">
    <el-menu-item :index="keyValue" @click="selectMenu(keyValue,menu)">
      <template #title>{{ menu.name }}</template>
    </el-menu-item>
  </template>
  <template v-else>
    <el-sub-menu :index="keyValue.toString()">
      <template #title>
        <span @click="selectMenu(keyValue,menu)">{{ menu.name }}</span>
      </template>
      <menu-item v-for="(dd,ii) in menu['children']" :key="dd.id"
                 :key-value="(keyValue?(keyValue+'-'):keyValue)+(ii+1).toString()"
                 :menu="dd"
                 @changeList="selectMenuEmit"></menu-item>
    </el-sub-menu>
  </template>
</template>

<script lang="ts" setup>
import { defineEmits, defineProps, onMounted } from 'vue'
import MenuItem from '@/viewsClient/components/MenuItem.vue'

const props = defineProps({
  menu: { // 不能为空不然要报错
    type: Object,
    default: () => {
      return {}
    }
  },
  keyValue: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['changeList'])

const handleOpen = (keyValue: number, keyValuePath: string): void => {
  // console.log('？？？9u', keyValue, keyValuePath)
  // store.commit('setManageOpenMenuArr', keyValue)
}

const handleClose = (keyValue: number, keyValuePath: string): void => {
  // console.log(keyValue, keyValuePath)
  // store.commit('setManageOpenMenuArr', -keyValue)
}

const selectMenu = (keyValue, item: any): void => {
  emit('changeList', { ...item, currentIndex: keyValue })
}
const selectMenuEmit = (item) => {
  emit('changeList', item)
}
onMounted(() => {
  // if (store.state.currentPath !== router.currentRoute.value.name) {
  //   store.commit('setManageCurrentPath', router.currentRoute.value.name)
  // }
})
</script>

<style scoped>

</style>
