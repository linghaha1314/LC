<!--<template>-->
<!--  <el-dialog-->
<!--    class="dialog-box"-->
<!--    v-if="isShowPoup"-->
<!--    v-model:visible="isShowPoup"-->
<!--    :show-close="false"-->
<!--    :fullscreen="false"-->
<!--    :modal="false"-->
<!--    width="50%"-->
<!--    :close-on-click-modal="false"-->
<!--    :modal-append-to-body="false"-->
<!--    :append-to-body="false"-->
<!--  >-->
<!--    <slot></slot>-->
<!--  </el-dialog>-->
<!--</template>-->
<!--<script>-->
<!--export default {-->
<!--  data () {-->
<!--    return {}-->
<!--  },-->
<!--  props: {-->
<!--    isShowPoup: {-->
<!--      type: Boolean,-->
<!--      default: false-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->
<!--<style lang="less" scoped>-->
<!--.el-dialog__wrapper {-->
<!--  position: absolute !important;-->
<!--  top: 50%;-->
<!--  height: 100%;-->
<!--  width: 100% !important;-->
<!--  left: 0 !important;-->
<!--  transform: translateX(-50%);-->
<!--  transform: translateY(-50%);-->
<!--  box-sizing: border-box;-->
<!--  border-radius: 4px;-->
<!--  //遮罩改不了，div v-model都是基于body的-->
<!--  /deep/.el-dialog {-->
<!--    // height: 200px;-->
<!--    margin-top: 0 !important;-->
<!--    top: 50% !important;-->
<!--    transform: translateY(-50%);-->
<!--  }-->
<!--  /deep/.el-dialog__header {-->
<!--    display: none;-->
<!--  }-->
<!--  /deep/.el-dialog__body {-->
<!--    // padding: 30px 20px;-->
<!--    padding: 10px 20px;-->
<!--  }-->
<!--}-->
<!--</style>-->
