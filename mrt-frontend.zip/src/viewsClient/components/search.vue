<template>
  <div class="search-wrapper">
    <input v-model="state.search" placeholder="搜索"/>
    <div class="icon-search-box" @click="goSearch">
      <Icon class="icon-search" icon="Search"></Icon>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { defineEmits, reactive } from 'vue'

const emit = defineEmits(['goSearch'])
const state = reactive({
  search: ''
})
const goSearch = () => {
  emit('goSearch', state.search)
}
</script>

<style lang="less" scoped>
@import (once) "~@/assets/css/client.less";

.search-wrapper {
  border: 1px solid @color;
  width: 250px;
  height: 32px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-radius: 16px;
  overflow: hidden;

  input {
    flex: 1;
    padding: 0 0 0 16px;
    border: none;
    height: 100%;
    box-sizing: border-box;
    outline: none;

    &:focus {
      outline: none;
    }
  }

  .icon-search-box {
    height: 100%;
    background: @color;
    display: flex;
    align-items: center;
    justify-content: center;

    .icon-search {
      font-size: 24px;
      padding: 0 8px;
      color: #ffffff;
    }
  }
}
</style>
