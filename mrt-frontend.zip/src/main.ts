import { createApp, createVNode } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import './assets/css/index.scss'
import ElementPlus from 'element-plus'
import tools from './utils/tool'
import * as Icons from '@element-plus/icons-vue'
import zhCn from 'element-plus/es/locale/lang/zh-cn'

const app = createApp(App)
app.config.globalProperties.$tools = tools
app.config.globalProperties.$store = store

const Icon = (props: { icon: string }) => {
  const { icon } = props
  return createVNode(Icons[icon as keyof typeof Icons])
}
app.component('Icon', Icon)
app.use(ElementPlus, {
  locale: zhCn
})
app.use(store).use(router).mount('#app')

router.beforeEach((to, from, next) => {
  if (to.path.indexOf('manage') < 0) {
    next() // client
  } else if (
    !store.state.manageUserInfo?.id &&
    to.path.indexOf('/manage/login') < 0
  ) {
    next({ path: '/manage/login' })
  } else if (
    to.path.indexOf('login') > -1 ||
    to.path === '/' ||
    to.path === '/manage/404' ||
    to.path === '/manage/welcome' ||
    to.meta.show
  ) {
    next()
  } else if (to.path.indexOf('/manage/') > -1) {
    // 凡是/manage/*都刷新自己的页面
    next({ path: '/manage/welcome' })
  } else {
    next({ path: '/' })
  }
})
/* 全局的指令 */
// app.directive('preventReClick', {
//   mounted (el: any, binding: any) {
//     el.addEventListener('click', () => {
//       if (!el.disabled) {
//         el.disabled = true
//         setTimeout(() => {
//           el.disabled = false
//           // console.log('不可以点击按钮')
//         }, binding.value || 2000)
//       }
//     })
//   }
// })
