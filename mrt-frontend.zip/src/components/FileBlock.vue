<template>
  <div class="file-wrapper flex align-center justify-between" style="height: auto">
    <div class="flex align-center" style="cursor: pointer;" @click="tools.go(data.path, true)">
      <Icon icon="Document" class="icon" style="padding-right: 2px;color:#842d4f;font-size:28px"></Icon> &nbsp;
      <div class="name">{{ data.name }}</div>
    </div>
    <div class="opera">
      <a :download="data.name" :href="data.path" target="_blank">
        <el-button size="small" type="primary">下载</el-button>
      </a>
    </div>
  </div>
</template>

<script lang="ts" setup>
import tools from '@/utils/tool'
import { defineProps } from 'vue'

const props = defineProps({
  data: {
    type: Object,
    default: () => {
      return {
        name: '默认附件名'
      }
    }
  }
})
</script>

<style lang="less" scoped>
.file-wrapper {
  background: #f2f2f2;
  padding: 8px 16px;
  height: auto;
}

a {
  color: inherit;
}
</style>
