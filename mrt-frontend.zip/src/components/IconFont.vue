<template>
  <svg :style="{'font-size':fontSize }" aria-hidden="true" class="icon">
    <use :fill="color" v-bind:xlink:href="props.name"></use>
  </svg>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'

const props = defineProps({
  name: String, // 需要添加的字体图标类
  color: {
    // 图标颜色
    type: String,
    default: '#444'
  },
  fontSize: {
    // 图标大小
    type: [String, Number],
    default: '24px'
  }
})
</script>
<style scoped>
.icon {

  margin: 0 4px !important;
}
</style>
