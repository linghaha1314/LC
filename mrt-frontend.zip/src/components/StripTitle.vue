<template>
  <div class="flex justify-between">
    <div class="strip-icon-box">
      <p :style="{'background':backColor}" class="primary-back"></p>
      <span :style="{'font-size':font+'px'}">
      <slot>{{ name }}</slot></span>
    </div>
    <div class="flex align-center">
      <slot name="right"></slot>
    </div>
  </div>

</template>
<script>

export default {
  props: {
    backColor: {
      type: String,
      default: '#842d4f'
    },
    font: {
      type: String,
      default: '18'
    },
    name: {
      type: String,
      default: ''
    }
  }
}
</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/client.less";
@import (once) "~@/assets/css/manage.less";

.strip-icon-box {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  height: 100%;
  padding: 4px 0;
  position: relative;

  p {
    width: 5px;
    height: 50%;
    position: absolute;
    left: 0;
    margin: 0;
    top: 50%;
    min-height: 20px;
    transform: translateY(-50%);
    box-sizing: border-box;
  }

  span {
    margin-left: 12px;
    font-weight: bold;
    font-size: 16px;
  }
}
</style>
