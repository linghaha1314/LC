<template>
  <div>
    <div class="flex align-center margin-bottom">
      <div class="code" @click="createCode(4)">{{ state.showCode }}</div>
      <span @click="createCode(4)">看不清换一张</span>
    </div>
    <el-input v-model="state.code" placeholder="请输入验证码" @keydown.enter="validateCode"/>
    <el-button class="margin-top" type="primary" @click="validateCode">确定</el-button>
  </div>
</template>

<script lang="ts" setup>
import { defineEmits, onMounted, reactive } from 'vue'
import tools from '@/utils/tool'

const state = reactive({
  code: '',
  showCode: ''
})
const emit = defineEmits(['rightClosed'])
const createCode = (length) => {
  let code = ''
  const codeLength = parseInt(length) // 验证码的长度
  const codeChars = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
  // 循环组成验证码的字符串
  for (let i = 0; i < codeLength; i++) {
    // 获取随机验证码下标
    const charNum = Math.floor(Math.random() * 62)
    // 组合成指定字符验证码
    code += codeChars[charNum]
  }
  state.showCode = code
}
const validateCode = () => {
  if (state.code.length <= 0) {
    tools.msg('请输入验证码', 'info')
  } else if (state.code.toUpperCase() !== state.showCode.toUpperCase()) {
    tools.msg('请输入正确的验证码', 'error')
  } else {
    state.code = ''
    emit('rightClosed', true)
  }
}
onMounted(() => {
  createCode(4)
})
</script>

<style scoped>
.code {
  font-family: Arial;
  font-style: italic;
  color: blue;
  font-size: 30px;
  border: 0;
  padding: 2px 3px;
  letter-spacing: 3px;
  font-weight: bolder;
  float: left;
  cursor: pointer;
  width: 150px;
  height: 50px;
  line-height: 60px;
  text-align: center;
  vertical-align: middle;
  background-color: #D8B7E3;
  border-radius: 8px;
}

span {
  text-decoration: none;
  font-size: 12px;
  color: #288bc4;
  padding-left: 10px;
}

span:hover {
  text-decoration: underline;
  cursor: pointer;
}

</style>
