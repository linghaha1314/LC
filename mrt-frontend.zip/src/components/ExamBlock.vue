<template>
  <div id="exam-block-wrapper">
    <div style="display:flex;align-items: center;" v-if="!readonly">
      <span style="white-space: nowrap;color:#666;font-weight:bolder">题目：</span>
      <el-input v-if="!isTitleBlur || !data.title" style="display:inline-block;margin-bottom:16px;color:#666"
        v-model="data.title" placeholder='请输入题目标题' type="textarea" @blur="inputBlur(data.title, 'title')"
        @change="emitData">
      </el-input>
      <div v-if="isTitleBlur && data.title" @click="isTitleBlur = false" style="color:#666;padding:20px 0">
        {{
            data.title
        }}
      </div>
    </div>
    <div v-if="readonly" style="color:#666;font-weight:bold">
      {{ data.title }}
      <span v-if="isShowAnswer">
        <span>
          <span v-if="!isAnswerFlag" class="error">回答错误❌</span>
          <span v-if="isAnswerFlag" class="right">回答正确</span>
        </span>
        <div v-if="!isAnswerFlag"><span class="right-answer">正确答案：{{
            result.rightAnswer
        }}</span></div>
      </span>
    </div>
    <div class="options-style">
      <el-radio-group v-model="radioResult" v-if="data.typeCode === 'radio'"
        @change="changeResultOption($event, 'radio')" style="display:flex;flex-direction:column;">
        <el-radio v-for="(dd, index) in data.options" :key="index" :label="index"
          style="margin:12px 0;white-space: pre-wrap;">
          <div class="option-input">
            <el-input v-if="!dd.isBlur || !dd.name" type="textarea" placeholder="请输入选项" v-model="dd.name"
              @blur="inputBlur(dd)" @change="emitData">
            </el-input>
            <div v-if="dd.isBlur && dd.name" @click="readonly ? dd.isBlur = true : dd.isBlur = false">
              <span style="font-weight:bold;">{{
                  tools.numberToLetter(index + 1)
              }}. &nbsp;
              </span>
              {{ dd.name }}
            </div>
            <div v-if="!readonly">
              <el-button v-if="index !== data.options.length - 1" style="margin-left:12px" size="small" type="info"
                :icon="Delete" @click="deleteOptions(index)" circle />
              <el-button v-if="index === data.options.length - 1" @click.stop="addNewOptions(index)"
                style="margin-left:12px" size="small" type="primary" :icon="Plus" circle />
            </div>
          </div>
        </el-radio>
      </el-radio-group>

      <el-checkbox-group v-model="checkboxResult" v-if="data.typeCode === 'checkbox'"
        @change="changeResultOption($event, 'checkbox')" style="display:flex;flex-direction:column;">
        <el-checkbox v-for="(dd, index) in data.options" :key="index" :label="index"
          style="margin:12px 0;white-space: pre-wrap;">
          <div class="option-input">
            <el-input v-if="!dd.isBlur || !dd.name" type="textarea" placeholder="请输入选项" v-model="dd.name"
              @change="emitData" @blur="inputBlur(dd)"></el-input>
            <div v-if="dd.isBlur && dd.name" @click="readonly ? dd.isBlur = true : dd.isBlur = false">
              <span style="font-weight:bold;">{{
                  tools.numberToLetter(index + 1)
              }}. &nbsp;
              </span>
              {{ dd.name }}
            </div>
            <el-button v-if="index !== data.options.length - 1" style="margin-left:12px" size="small" type="info"
              :icon="Delete" circle @click="deleteOptions(index)" />
            <el-button v-if="index === data.options.length - 1" style="margin-left:12px" size="small" type="primary"
              :icon="Plus" circle @click.stop="addNewOptions(index)" />
          </div>
        </el-checkbox>
      </el-checkbox-group>
    </div>
    <div class="foot" v-if="!readonly">
      <el-select v-model="data.typeCode" placeholder="Select" size="small" @change="selectChange" style="width:80px">
        <el-option v-for="item in typeOptions" :key="item.code" :label="item.name" :value="item.code" />
      </el-select>
      <div class="right-result">正确答案：<span v-if="showRightAnswer">{{ showRightAnswer }}</span></div>
    </div>
    <div class="foot" v-if="readonly">
      <el-button type="primary" size="small" @click="checkAnswer">确定</el-button>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { ref, defineProps, defineEmits, computed, reactive } from 'vue'
import { Plus, Delete } from '@element-plus/icons'
import tools from '@/utils/tool'
const props = defineProps({
  result: {
    type: Object,
    default: () => {
      return {
        title: '',
        id: null,
        options: [{ id: null, name: '' }],
        typeCode: 'radio',
        rightAnswer: ''
      }
    }
  },
  readonly: {
    type: Boolean,
    default: false
  }
})
const emit = defineEmits(['update:result', 'hasChecked'])

const letterToNumber = (val: string, isCheckbox = false) => {
  if (isCheckbox) {
    const arr = val.split('')
    const list: any = []
    arr.forEach((rr: string) => {
      list.push(rr.charCodeAt(0) - 65)
    })
    return list
  }
  return val.charCodeAt(0) - 65
}

const radioResult = ref(letterToNumber(props.result?.rightAnswer))
const isTitleBlur = ref(false)
const isAnswerFlag = ref(false)
const isShowAnswer = ref(false)
const typeOptions = ref([{ id: 1, name: '单选', code: 'radio' }, { id: 2, name: '多选', code: 'checkbox' }] as any)
const checkboxResult = ref(letterToNumber(props.result?.rightAnswer, true))
const showRightAnswer = computed(() => {
  let right = ''
  if (data.value.typeCode === 'radio') {
    right = radioResult.value || radioResult.value === 0 ? tools.numberToLetter(radioResult.value + 1) : '无'
  } else {
    right = ''
    const numArr = (checkboxResult.value as any).sort() || []
    numArr.forEach(rr => {
      right += tools.numberToLetter(rr + 1)
    })
  }
  return right
})
const data = ref(props.result)

const changeResultOption = (e: any, type: string) => {
  emitData()
}

const addNewOptions = (index: number) => {
  data.value.options.push({ id: index + 1 })
}

const emitData = () => {
  if (props.readonly) {
    return
  }
  data.value.rightAnswer = showRightAnswer
  emit('update:result', data)
}

const inputBlur = (dd: any, type?: any) => {
  if (type) {
    isTitleBlur.value = true
    return
  }
  dd.isBlur = true
}

const checkAnswer = () => {
  isAnswerFlag.value = showRightAnswer.value === props.result.rightAnswer
  isShowAnswer.value = true
  emit('hasChecked', true)
}

const deleteOptions = (index: any) => {
  data.value.options.splice(index, 1)
}

const selectChange = () => {
  emitData()
}

</script>
<style lang="less">
@import (once) '~@/assets/css/manage.less';

#exam-block-wrapper {
  width: 100%;

  .option-input {
    display: flex;
    width: fit-content;
    align-items: center;
  }

  .options-style {
    padding: 12px 0 0 24px;
  }

  .error {
    font-weight: bold;
    color: red !important;
  }

  .right {
    font-weight: bold;
    color: @greenColor  !important;
  }

  .right-answer {
    font-size: 28px;
    font-weight: bold;
    color: @greenColor;
  }

  .foot {
    padding: 12px 0;
    display: flex;
    align-items: center;
    flex-direction: row-reverse;
    border-bottom: 2px solid #666;

    .right-result {
      color: @primaryColor;
      margin-right: 20px;
    }
  }
}
</style>
