<template>
  <el-container id="manage">
    <el-aside
      :width="!isCollapse ? '280px' : '64px'"
      style="transition: all 0.5s; overflow: auto"
    >
      <div class="head-img">
        <img src="../../../src/assets/images/head-logo.png"/>
      </div>
      <div class="menu-wrapper">
        <menu-list :isCollapse="isCollapse" :menus="menus"></menu-list>
      </div>
    </el-aside>
    <el-container>
      <el-header>
        <menu-header
          :isCollapse="isCollapse"
          @changeIsCollapse="changeIsCollapse"
        ></menu-header>
      </el-header>
      <el-main style="background: #f2f2f2">
        <el-row v-if="tags.length > 0" style="border-bottom: 2px solid #f2f2f2">
          <el-tag
            v-for="dd in tags"
            :key="dd.code"
            :disable-transitions="true"
            class="tag"
            closable
            :effect="store.state.currentPath === dd.code ? 'dark' : 'light'"
            size="large"
            @click="onChange(dd)"
            @close="close(dd)"
          >
            {{ dd.name }}
          </el-tag>
        </el-row>
        <div class="main-content">
          <router-view/>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script lang="ts">
import {
  computed,
  defineComponent,
  onMounted,
  reactive,
  toRefs,
  watch
} from 'vue'
import MenuHeader from './components/MenuHeader.vue'
import store from '@/store'
import router from '@/router'
import MenuList from '@/viewsManage/Index/components/MenuList.vue'

export default defineComponent({
  name: '',
  components: {
    MenuHeader,
    MenuList
  },
  setup: () => {
    const state = reactive({
      isCollapse: false
    })

    const tags = computed(() => {
      return store.state.manageHistoryList
    })

    const changeIsCollapse = () => {
      state.isCollapse = !state.isCollapse
    }

    const close = (item) => {
      store.commit('deleteManageHistory', item)
    }

    const onChange = (item) => {
      router.push({
        path: '/manage/' + item.path,
        query: { code: item.code }
      })
      store.commit('setManageMenuId', item.id)
      store.commit('setManageCurrentPath', item.code)
    }

    const menus = computed(() => {
      return store.state.manageMenuList
    })

    watch(
      () => store.state.manageUserInfo.currentRole,
      (val) => {
        if (val) {
          store.dispatch('getMenus').then()
        }
      }
    )

    onMounted(() => {
      if (store.state.manageUserInfo?.currentRole) {
        store.dispatch('getMenus').then()
      }
      const menusArr = store.state.manageMenuList
      if (menusArr.length === 0) {
        store.dispatch('getMenus').then()
      }
    })
    return {
      tags,
      menus,
      store,
      ...toRefs(state),
      close,
      onChange,
      changeIsCollapse
    }
  }
})
</script>

<style lang="less">
@import (once) '~@/assets/css/commen.less';
@import (once) '~@/assets/css/manage.less';

.head-img {
  overflow: hidden;
  height: 60px;
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;

  img {
    height: 100%;
  }
}

.menu-wrapper {
  height: calc(100vh - 60px);
  background-color: var(--color);
}

.el-container {
  height: 100vh;
}

.el-aside {
  background: @menuBg;
  overflow: inherit;
}

.main-content {
  background: #ffffff;
  border-radius: 4px;
  padding: 10px 30px;
  min-height: calc(100vh - 150px);
  min-width: 500px;
  position: relative;
  box-sizing: border-box;
}

.el-tag {
  margin: 8px;
  cursor: default;
}
</style>
