<template>
  <div class="header-wrapper">
    <div style="display: flex; align-items: center">
      <Icon
        class="icon"
        icon="Expand"
        style="padding-left: 16px"
        @click="changeIsCollapse"
      ></Icon>
    </div>
    <div class="header-end">
      <el-dropdown>
        <span style="cursor: pointer"
        >{{
            store.state.manageUserInfo.name
          }}<span
          >({{ store.state.manageUserInfo.currentRole?.roleData.name }})</span
          ></span
        >
        <i class="el-icon-arrow-down el-icon--right"></i>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item v-for="i in options" :key="i.id" @click="goUrl(i)"
            >{{ i.value }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
  </div>
  <el-dialog
    v-model="store.state.isSelectRoleDialog"
    destroy-on-close
    title="切换角色"
    width="40%"
  >
    <el-radio-group
      v-if="store.state.isSelectRoleDialog"
      v-model="currentRoleId"
      @change="changeCurrentRole(currentRoleId)"
    >
      <el-radio
        v-for="i in store.state.manageUserInfo.roles"
        :key="i.roleId"
        :label="i.roleId"
      >{{ i['roleData'].name }}
      </el-radio>
    </el-radio-group>
  </el-dialog>
  <el-drawer
    v-model="pageParams.isDrawer"
    :append-to-body="false"
    :destroy-on-close="true"
    direction="rtl"
    size="40%"
    title="详细信息"
  >
    <form-list
      :isEdit="pageParams.isEdit"
      :list="formList"
      @submit="submit"
    ></form-list>
  </el-drawer>
  <el-drawer
    v-model="pageParams.isPsw"
    :append-to-body="false"
    :destroy-on-close="true"
    direction="rtl"
    size="40%"
    title="修改密码"
  >
    <div style="text-align: center; color: orangered">
      请填写8位以上包含大小写字母 数字 特殊符号任意三种规则的密码
    </div>
    <form-list
      :isEdit="pageParams.isEdit"
      :list="pswList"
      @submit="submit"
    ></form-list>
  </el-drawer>
  <el-drawer
    v-model="pageParams.changeSteam"
    :append-to-body="false"
    :destroy-on-close="true"
    direction="rtl"
    size="40%"
    title="系统切换"
  >
    <div class="flexC ardCtr colorW flexW g-box" style="height: 500px;padding: 10px;align-items: center">
      <a style="width: 45%;color: #ffffff;" :href="urlArr.study[currentNet]" target="_blank">
        <el-button class="btn-shd"
                   style="width: 100%;min-height: 102px;border-radius:16px;font-size: 20px;margin: 0;color: #ffffff"
                   color="#852c4f" size="large">在线学习
        </el-button>
      </a>
      <a style="width: 45%;color: #ffffff;" :href="urlArr.exam[currentNet]" target="_blank">
        <el-button class="btn-shd"
                   style="width: 100%;min-height: 102px;border-radius:16px;font-size: 20px;margin: 0;color: #ffffff"
                   color="#d4b981" size="large" @click="goLogin">在线考试管理系统
        </el-button>
      </a>
      <el-button class="btn-shd"
                 style="width: 100%;
                       min-height: 102px;
                       border-radius:16px;
                       font-size: 20px;
                       margin: 0;"
                 type="primary"
                 size="large"
                 @click="linksInto"
      >科研管理系统
      </el-button>
      <!--            <a style="width: 45%;color: #ffffff;" href="http://172.16.10.79/userAction!to_login.action" target="_blank">-->
      <!--              -->
      <!--            </a>-->
      <a style="width: 45%;color: #ffffff !important;" :href="urlArr.zhuPei[currentNet]" target="_blank">
        <el-button class="btn-shd"
                   style="width: 100%;color: #ffffff;min-height: 102px;border-radius:16px;font-size: 20px;margin: 0;text-wrap: normal"
                   color="#00cc00" size="large">住院医师规范化
          <br>
          培训管理系统
        </el-button>
      </a>
    </div>
  </el-drawer>
</template>

<script lang="ts">
import { defineComponent, onMounted, reactive, toRefs, watch } from 'vue'
import router from '@/router/index'
import store from '@/store'
import Cookies from 'js-cookie'
import FormList from '@/viewsManage/components/FormList.vue'
import tools from '@/utils/tool'
import CryptoJS from 'crypto-js'

export default defineComponent({
  name: '',
  props: {
    isCollapse: {
      type: Boolean,
      default: true
    }
  },
  emits: ['changeIsCollapse'],
  components: {
    FormList
  },
  setup: (props, { emit }) => {
    const urlArr = {
      study: {
        out: 'http://117.159.24.46:3001/#/client/home',
        into: 'http://172.16.10.53:3001/#/client/home'
      },
      zhuPei: {
        out: 'http://117.159.24.46:64001/',
        into: 'http://172.16.10.53:64001'
      },
      exam: {
        out: 'http://117.159.24.46:8201',
        into: 'http://172.16.10.53:8201'
      }
    }
    const options = [
      {
        id: 0,
        value: '个人中心',
        path: '/client/personal'
      },
      {
        id: 1,
        value: '切换角色',
        path: ''
      },
      {
        id: 2,
        value: '修改密码',
        path: '/'
      },
      {
        id: 3,
        value: '系统切换',
        path: '/'
      },
      {
        id: 4,
        value: '退出登录',
        path: 'login'
      }
    ]

    const userInfo: any = store.state.manageUserInfo || {}

    const state = reactive({
      currentRoleId: store.state.manageUserInfo
        ? store.state.manageUserInfo.currentRole?.roleId || ''
        : '',
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false,
        isPsw: false,
        changeSteam: false
      },
      currentNet: 'into',
      formList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '工号',
          key: 'jobNum',
          width: '',
          value: null,
          required: true,
          defaultValue: '',
          disabled: true
        },
        {
          type: 'input',
          label: '姓名',
          key: 'name',
          width: '',
          value: null,
          defaultValue: '',
          required: true,
          disabled: true
        },
        {
          type: 'input',
          label: '昵称',
          key: 'nickName',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'select',
          multiple: true,
          label: '角色',
          key: 'roles',
          width: '',
          url: '/roles/getListByPage',
          value: null,
          defaultValue: '',
          required: true,
          disabled: true
        },
        {
          type: 'input',
          label: '机构',
          key: 'organizationName',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'select',
          label: '专业',
          key: 'majorId',
          url: '/major/getListByPage',
          width: '',
          value: null,
          defaultValue: null
        },
        {
          type: 'select',
          url: '/section/getListByPage',
          label: '科室',
          key: 'sectionId',
          width: '',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '岗位',
          key: 'post',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '职务',
          key: 'duties',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '院区',
          key: 'hospital',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '职位',
          key: 'position',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '职称',
          key: 'positionTitle',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '手机号码',
          key: 'mobile',
          width: '',
          value: '',
          defaultValue: null
        },
        {
          type: 'input',
          label: '邮箱',
          key: 'email',
          width: '',
          value: null,
          defaultValue: ''
        }
      ],
      pswList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '旧密码',
          key: 'password',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '新密码',
          key: 'passwordN',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '新密码',
          key: 'passwordNR',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }
      ],
      userInfo: {
        id: '',
        password: '',
        roles: []
      }
    })

    state.userInfo = store.state.manageUserInfo

    const logOut = () => {
      sessionStorage.removeItem('manageUserInfo')
      router.push({ path: '/manage/login' })
    }

    const changeCurrentRole = async (val) => {
      const loading = tools.showLoading('切换中...')
      await tools.post('/userRole/updateCurrentRole', {
        staffId: store.state.manageUserInfo?.id,
        currentRoleId: val
      })
      await store.dispatch('getManageUserInfo', {
        id: store.state.manageUserInfo.id
      })
      // await store.dispatch('getMenus', { roleId: val })
      tools.msg('切换成功！')
      tools.closeLoading(loading)
      store.commit('setIsSelectRoleDialog', false)
      store.commit('setManageMenuId', null)
      await router.push({ path: '/manage/welcome' })
    }

    const changeIsCollapse = () => {
      emit('changeIsCollapse', true)
    }

    const el: any = document.querySelector('html')

    el.setAttribute(
      'class',
      localStorage.getItem('v3-element-plus-style') || 'base'
    )

    const tabStyle = (co: any) => {
      localStorage.setItem('v3-element-plus-style', co.value)
      el.setAttribute('class', co.value)
    }

    const goUrl = (i) => {
      switch (i.value) {
        case '切换角色': {
          store.commit('setIsSelectRoleDialog', true)
          break
        }
        case '个人中心': {
          state.formList.forEach((res) => {
            if (res.key === 'roles') {
              const arr: any = []
              state.userInfo.roles.forEach((item: any) => {
                arr.push(item.roleId)
              })
              res.value = arr
            } else {
              res.value = state.userInfo[res.key]
            }
          })
          state.pageParams.isEdit = true
          state.pageParams.isDrawer = true
          break
        }
        case '修改密码': {
          showRole()
          break
        }
        case '系统切换': {
          state.pageParams.changeSteam = true
          break
        }
        case '退出登录': {
          Cookies.remove('manage-token')
          sessionStorage.removeItem('manageUserInfo')
          router.push({ path: '/manage/login' })
          break
        }
      }
    }

    const showRole = () => {
      state.pageParams.isPsw = true
      state.pageParams.isEdit = true
      state.pswList.forEach((res) => {
        if (res.key === 'roles') {
          const arr: any = []
          state.userInfo.roles.forEach((item: any) => {
            arr.push(item.roleId)
          })
          res.value = arr
        } else if (res.key === 'password') {
          res.value = null
        } else {
          res.value = state.userInfo[res.key]
        }
      })
    }

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        if (state.pageParams.isPsw) {
          // if (state.userInfo.password !== data.password) {
          //   tools.msgError('旧密码错误!')
          //   return
          // } else
          if (data.passwordN !== data.passwordNR) {
            tools.msgError('两次新密码不一致!')
            return
          } else if (!validator(data.passwordN)) {
            tools.msgError('新密码不符合规则!')
            return
          } else {
            const arr: any = []
            state.userInfo.roles.forEach((item: any) => {
              arr.push(item.roleId)
            })
            data.password = data.passwordN
            data.roles = arr
            delete data.passwordN
            delete data.passwordNR
          }
        }
        data.password = CryptoJS.AES.encrypt(
          data.password,
          'kb12315'
        ).toString()
        tools.post('/user/updateUserById', data).then((res) => {
          if (res.success) {
            state.pageParams.isPsw = false
            state.pageParams.isDrawer = false
            state.pageParams.refresh = true
            tools.msg(res.msg)
            tools.get('getUserInfo', { id: state.userInfo.id }).then((res) => {
              res.data.currentRole = res.data.roles[0]
              store.commit('setManageUserInfo', res.data)
              state.userInfo = res.data
            })
          }
        })
        return
      }
      delete data.id
      tools.post('/user/createUser', data).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const validator = (str) => {
      let modes = 0
      const val = str
      if (val.length < 7) return false
      if (/\d/.test(val)) modes++ // 数字
      if (/[a-z]/.test(val)) modes++ // 小写
      if (/[A-Z]/.test(val)) modes++ // 大写
      if (/\W/.test(val)) modes++ // 特殊字符
      return modes > 2
    }
    const linksInto = () => {
      if (state.currentNet === 'into') {
        const url = 'http://172.16.10.53:8083/login?service=http%3A%2F%2F172.16.10.79%2FuserAction%21do_casLogin.action'
        window.open(url, '_blank')
      } else {
        tools.msgError('请使用医院内网才能访问科研管理系统!')
      }
    }
    watch(
      () => store.state.manageUserInfo,
      (val) => {
        state.userInfo = val
      }
    )

    onMounted(() => {
      state.currentNet = window.location.hostname === '117.159.24.46' ? 'out' : 'into'
      if (store.state.manageUserInfo.roles.length === 0) {
        tools.msgError('未检测到角色信息，请练习管理员分配角色！', 4000)
        router.replace({ path: '/manage/login' }).then()
        tools.removeLoading()
      }
    })

    return {
      changeIsCollapse,
      logOut,
      ...toRefs(state),
      changeCurrentRole,
      store,
      options,
      userInfo,
      goUrl,
      linksInto,
      submit,
      urlArr,
      tabStyle
    }
  }
})
</script>

<style lang="scss" scoped>
.header-wrapper {
  height: 100%;
  //box-shadow: 24px 4px 29px #ccc;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-end {
  padding-right: 16px;
}

.el-icon-s-fold,
.el-icon-s-unfold {
  cursor: pointer;
  font-size: 30px;
  padding: 15px;
}
</style>
