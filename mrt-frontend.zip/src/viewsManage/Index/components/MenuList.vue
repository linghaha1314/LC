<template>
  <el-menu
    :collapse="isCollapse"
    :default-active="store.state.currentMenuId"
    :default-openeds="store.state.openMenuArr"
    :mode="mode"
    :unique-opened="true"
    active-text-color="var(--menuActiveTextColor)"
    background-color="var(--menuBg)"
    text-color="var(--menuTextColor)"
    @close="handleClose"
    @open="handleOpen"
  >
    <template v-for="(menu, index) in menus" :key="menu.id">
      <!-- 不存在子节点 -->
      <template v-if="!menu.children || menu.children.length === 0">
        <el-menu-item
          style="padding-left: 40px !important"
          :index="menu.id"
          @click="selectMenu(key, menu)"
        >
          <Icon
            v-if="menu.icon"
            :icon="menu.icon"
            class="icon"
            style="padding-right: 2px"
          ></Icon>
          <template #title>
            {{ menu.name }}
          </template>
        </el-menu-item>
      </template>
      <!-- 存在多个子节点 -->
      <el-sub-menu :popper-offset="40" v-else :index="menu.id">
        <template #title>
          <Icon
            v-if="menu.icon"
            :icon="menu.icon"
            class="icon"
            style="padding-right: 2px"
          ></Icon>
          <span>{{ menu.name }}</span>
        </template>
        <menu-list
          :key="index"
          :is-collapse="false"
          :menus="menu.children"
        ></menu-list>
      </el-sub-menu>
    </template>
  </el-menu>
</template>

<script lang="ts" setup>
import { defineProps, onMounted, PropType } from 'vue'
import store from '@/store'
import router from '@/router'
type menu = {
  id: string
  children: any[]
  icon: string
  name: string
}
const props = defineProps({
  menus: {
    type: Array as unknown as PropType<[menu]>,
    default: () => []
  },
  isCollapse: {
    type: Boolean,
    default: true
  },
  key: {
    type: Number,
    default: 0
  },
  mode: {
    type: String,
    default: 'vertical'
  }
})
// const emit = defineEmits(['update:currentPath'])
const handleOpen = (key: number, keyPath: string): void => {
  // store.commit('setManageOpenMenuArr', key)
}
const handleClose = (key: number, keyPath: string): void => {
  // store.commit('setManageOpenMenuArr', -key)
}
const selectMenu = (key, item: any): void => {
  if (item.id === store.state.currentMenuId) {
    return
  }
  store.commit('setManageCurrentPath', item.code)
  store.commit('setManageMenuId', item.id)
  store.commit('setManageHistory', item)
  router.push({
    path: '/manage/' + item.path,
    query: { code: item.code }
  })
}
onMounted(() => {
  if (store.state.currentPath !== router.currentRoute.value.name) {
    store.commit('setManageCurrentPath', router.currentRoute.value.name)
  }
})
</script>

<style scoped></style>
