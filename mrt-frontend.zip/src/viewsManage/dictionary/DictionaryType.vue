<template>
  <div class="dictionary-type">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="tools.openDrawer(pageParams)"
        >新增
        </el-button>
        <el-button plain size="small" type="danger" @click="tools.delMultiple('user',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns" :query-data="searchInfo"
                url="/dictionaryType/getListByPage">
      <template v-slot="scope">
        <el-button size="small" type="primary" @click="tools.openDrawer(pageParams,true,formList,scope.row)"
        >查看/修改
        </el-button>
        <el-button
          size="small"
          type="danger"
          @click="tools.deleteById('dictionaryType', scope.row.id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="40%"
      title="字典类型设置"
    >
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        name: ''
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '名称',
          width: 140
        },
        {
          valueKey: 'code',
          label: '编码',
          width: 160
        }, {
          valueKey: 'remark',
          width: 120,
          label: '备注'
        },
        {
          valueKey: 'created',
          label: '创建时间',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // }
      ], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '名称',
        key: 'name',
        width: '',
        value: null,
        required: true,
        change: (data) => {
          tools.validationRepeat(data, '名称', 'name', 'dictionaryType')
        },
        defaultValue: ''
      }, {
        type: 'input',
        label: '编码',
        key: 'code',
        width: '',
        value: null,
        defaultValue: '',
        change: (data) => {
          tools.validationRepeat(data, '编码', 'code', 'dictionaryType')
        },
        required: true
      }, {
        type: 'input',
        label: '备注',
        key: 'remark',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'switch',
        label: '状态',
        key: 'status',
        width: '',
        value: '',
        defaultValue: null
      }]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
          // tools.openDrawer(state.pageParams)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/dictionaryType/updateById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/dictionaryType/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      }).catch(() => {
        tools.msgError('请按要求填写!')
      })
    }
    const search = (searchInfo) => {
      searchInfo.name && (state.searchInfo.name = searchInfo.name.indexOf('undefined') > -1 ? null : searchInfo.name.substring(1, searchInfo.name.length - 1))
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }
    return {
      searchData,
      ...toRefs(state),
      submit,
      search,
      tools
    }
  }
})
</script>
