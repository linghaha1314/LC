<template>
  <div class="dictionary-type">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search" :is-show-export-btn="true" @exportAll="exportFn">
      <template v-slot:left-btn>
        <el-button class="background-btn" plain size="small" type="primary" @click="tools.openDrawer(pageParams)">新增
        </el-button>
        <el-button plain size="small" type="danger" @click="tools.delMultiple('dictionaryData', selection, pageParams)">
          删除
        </el-button>
        <import-file model-file="./xlsx/字典数据添加模板.xlsx" model-name="字典数据添加模板.xlsx" :config="data"
                     :changeData="changeData" table-name="dictionaryData"
                     v-model:refresh="pageParams.refresh"></import-file>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
                :query-data="searchInfo" url="/dictionaryData/getListByPage">
      <template v-slot="scope">
        <el-button size="small" type="text" @click="tools.openDrawer(pageParams, true, formList, scope.row)">查看/修改
        </el-button>
        <el-button class="font-red" size="small" type="text"
                   @click="tools.deleteById('dictionaryData', scope.row.id, pageParams)">删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer v-model="pageParams.isDrawer" :append-to-body="false" :destroy-on-close="true" direction="rtl" size="40%"
               title="字典数据设置">
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import ImportFile from '@/viewsManage/components/import-file.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList,
    ImportFile
  },
  setup: () => {
    const state = reactive({
      data: [
        {
          field: 'name',
          text: '名称',
          editor: {
            type: 'string',
            require: true,
            noRepeat: true
          }
        },
        {
          field: 'code',
          text: '编码',
          editor: {
            type: 'string',
            require: true,
            noRepeat: true
          }
        },
        {
          field: 'typeId',
          text: '类型',
          editor: {
            type: 'combo',
            valueKey: 'name',
            require: true,
            url: '/dictionaryType/getListByPage'
          }
        },
        {
          field: 'remark',
          text: '备注',
          editor: {
            type: 'string'
          }
        }
      ],
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        name: '',
        typeId: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '名称',
          width: 120
        },
        {
          valueKey: 'code',
          label: '编码',
          width: 120
        },
        {
          valueKey: 'typeId',
          label: '类型',
          list: []
        },
        {
          valueKey: 'remark',
          width: 160,
          label: '备注'
        },
        {
          valueKey: 'created',
          label: '创建时间',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '类型',
          value: 'typeId', // 返回值的名称
          placeholder: '请选择选择类型',
          options: [
            {
              id: '',
              name: ''
            }
          ]
        }
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // }
      ], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '名称',
        key: 'name',
        width: '',
        value: null,
        required: true,
        defaultValue: ''
      }, {
        type: 'input',
        label: '编码',
        key: 'code',
        width: '',
        value: null,
        defaultValue: '',
        required: true
      }, {
        type: 'select',
        label: '类型',
        key: 'typeId',
        url: '/dictionaryType/getListByPage',
        optionsLabel: 'name',
        optionsValue: 'id',
        searchKey: 'name',
        width: '',
        value: null,
        defaultValue: '',
        required: true
      }, {
        type: 'textarea',
        label: '备注',
        key: 'remark',
        width: '',
        value: '',
        defaultValue: null
      }, {
        id: 1,
        type: 'switch',
        label: '状态',
        key: 'status',
        width: '',
        value: '',
        defaultValue: null
      }],
      typeMap: {}
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          // tools.openDrawer(state.pageParams)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const getRoles = async () => {
      const result = await tools.get('/dictionaryType/getListByPage')
      state.tableColumns[3].list = result.list
      const obj = {}
      result.list.forEach(item => {
        obj[item.id] = item.name
      })
      state.typeMap = obj
      state.searchInit[0].options = [
        {
          id: '',
          name: '全部'
        },
        ...result.list
      ]
    }
    getRoles()
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/dictionaryData/updateById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/dictionaryData/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.name = (searchInfo.name && searchInfo.name.substring(1, searchInfo.name.length - 1)) || ''
      if (searchInfo.typeId === '') {
        state.searchInfo.typeId = null
      } else {
        state.searchInfo.typeId = searchInfo.typeId
      }
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }
    const exportFn = () => {
      const defineProps: any = {}
      state.data.forEach(ite => {
        defineProps[ite.text] = ite.field
      })
      const param: any = { ...state.searchInfo }
      delete param.limit
      tools.get('/dictionaryData/getListByPage', {
        limit: 9999,
        ...param
      }).then(res => {
        if (res.success) {
          const data = res.list
          data.forEach(item => {
            item.typeId = state.typeMap[item.typeId]
          })
          tools.writeFile(data, defineProps)
        }
      })
    }

    const changeData = async (data) => {
      const typeObj: any = (await tools.getValueObjByHttp('/dictionaryType/getList')).obj
      data.forEach(item => {
        item.typeId = typeObj[item.typeId] || null
      })
      return {
        uniqueKey: 'code',
        list: data
      }
    }
    return {
      searchData,
      ...toRefs(state),
      submit,
      search,
      exportFn,
      changeData,
      tools
    }
  }
})
</script>
