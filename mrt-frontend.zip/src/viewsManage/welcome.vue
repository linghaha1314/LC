<template>
  <div style="
      display: flex;
      height: calc(100vh - 150px);
      justify-content: center;
      align-items: center;
      font-size: 70px;
      font-weight: bold;
      font-family: 'Arial Black';
      color: #9b536f;
    ">
    欢迎使用！
  </div>
</template>

<script setup lang="ts">
</script>

<style scoped>
</style>
