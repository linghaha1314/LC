<template>
  <div class="nav-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" @search="search">
      <template v-slot:right-btn>
        <el-button
          class="backgreen-btn"
          @click="addNew"
          type="primary"
          plain
          size="small"
        >添加导航
        </el-button
        >
        <el-button type="danger" size="small" plain>删除</el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <el-table
      :data="tableData"
      style="width: 100%"
      row-key="id"
      current-row-key="id"
      :default-expand-all="false"
      :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column prop="name" label="导航名称"></el-table-column>
      <el-table-column label="是否启用">
        <template v-slot="scope">
          <el-switch
            v-model="scope.row.status"
            active-color="#1edfaf"
            inactive-color="#e7e9ee"
          ></el-switch>
        </template>
      </el-table-column>
      <el-table-column prop="path" label="地址" width="220"></el-table-column>
      <el-table-column prop="level" label="分类等级"></el-table-column>
      <el-table-column prop="sequence" label="排序"></el-table-column>
      <el-table-column prop="opera" label="操作">
        <template v-slot="scope">
          <el-button
            @click="editNav(scope.row.id)"
            type="text"
            size="small"
            class="font-green"
          >编辑
          </el-button
          >
          <el-button
            type="text"
            class="font-red"
            size="small"
            @click="del(scope.row.id)"
          >删除
          </el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="page-box">
      <!-- <el-pagination background layout="prev, pager, next" :total="tableData.length" page-size="10"></el-pagination> -->
    </div>
    <!-- 编辑 -->
    <el-dialog
      class="dialog"
      title="新增用户等级"
      v-if="isAddNew"
      :destroy-on-close="true"
      v-model:visible="isAddNew"
      :fullscreen="false"
      :modal-append-to-body="true"
    >
      <el-form ref="form" v-model="navForm" label-width="80px">
        <el-form-item label="导航名称">
          <el-input
            v-model="navForm.name"
            placeholder="请输入等级名称"
            style="width: 320px"
          ></el-input>
        </el-form-item>
        <el-form-item label="父级导航">
          <select-tree
            :props="props"
            :options="options"
            :value="navForm.parentId"
            @getValue="getValue($event)"
          ></select-tree>
        </el-form-item>
        <el-form-item label="状态">
          <radio-group
            :radioList="['启用', '禁用']"
            :startRadio="navForm.status == 1 ? '启用' : '禁用'"
            @changeRadio="changeStatus"
          ></radio-group>
        </el-form-item>
        <el-form-item label="排序级别">
          <el-input
            v-model="navForm.sequence"
            style="width: 120px"
            placeholder="请输"
          ></el-input>
        </el-form-item>
        <el-form-item label="地址">
          <el-input
            v-model="navForm.path"
            style="width: 120px"
            placeholder="请输入地址"
            type="url"
          ></el-input>
        </el-form-item>
        <el-form-item style="text-align: center; width: 50%; margin-top: 50px">
          <el-button type="primary" @click="save" v-if="!navForm.id"
          >保存
          </el-button
          >
          <el-button type="primary" @click="update" v-else>修改</el-button>
          <el-button type @click="cancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, toRefs, reactive } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    SearchClass
    // FormList,
    // TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'avatar',
          label: '头像',
          type: 'avatar',
          width: 100
        },
        {
          valueKey: 'name',
          label: '姓名'
        },
        {
          valueKey: 'username',
          label: '帐号'
        }, {
          valueKey: 'mobile',
          width: 120,
          label: '手机号'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ], // 筛选条件项
      formList: [{
        id: 1,
        type: 'none',
        label: '账号',
        placeholder: '请输入帐号',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: 'xxxx'
      }, {
        id: 1,
        type: 'input',
        label: '账号',
        placeholder: '请输入帐号',
        key: 'username',
        width: '',
        value: null,
        required: true,
        defaultValue: ''
      }, {
        id: 1,
        type: 'input',
        label: '名称',
        placeholder: '请输入名称',
        key: 'name',
        width: '',
        value: null,
        defaultValue: '',
        required: true
      }, {
        id: 1,
        type: 'input',
        label: '手机号码',
        placeholder: '请输入手机号码',
        key: 'mobile',
        width: '',
        value: '',
        defaultValue: null
      }]
    })
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        username: data.username,
        mobile: data.mobile
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/user/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/user/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      console.log(searchInfo)
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }
    return {
      ...toRefs(state),
      submit,
      search
    }
  }
})
</script>
<style lang="less" scoped>
.dictionary-type {
}
</style>
