<template>
  <div class="column-setting">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search"
                  :is-show-export-btn="true" @exportAll="exportAll">
      <template v-slot:left-btn>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="$tools.openDrawer(pageParams)"
        >添加栏目
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <el-tree
      :data="list"
      :expand-on-click-node="false"
      :props="{
            children: 'children',
            label: 'name',
          }"
      default-expand-all
      node-key="id"
      show-checkbox
    >
      <template #default="{ node, data }">
        <span class="custom-tree-node">
          <span>{{ node.label }}</span>
          <span>
             <el-button size="small" type="text" @click="openDrawer(data)"
             >查看/修改</el-button>
            <el-button class="font-red" size="small" type="text" v-if="true"
                       @click="$tools.deleteById('homeColumns',data.id,pageParams)"
            >删除节点</el-button>
          </span>
        </span>
      </template>
    </el-tree>
    <!-- 编辑弹窗 -->
    <el-dialog
      v-model="pageParams.isDrawer"
      destroy-on-close
      title="栏目设置"
      width="40%">
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, nextTick, onMounted, reactive, toRefs, watch } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass
  },
  setup: () => {
    const state = reactive({
      list: [],
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      isMenuTypeSetDialog: false,
      currentColumnId: null,
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      isSetMenu: true,
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // }
      ], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        value: null
      }, {
        type: 'input',
        label: '栏目名称',
        key: 'name',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'cascade',
        label: '父级栏目',
        key: 'parentId',
        width: '',
        value: null,
        url: '/homeColumns/getListByPage',
        queryParams: {
          limit: 10000,
          sort: 'sequence asc'
        },
        defaultValue: ''
      }, {
        type: 'input',
        label: '栏目code',
        key: 'code',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'number',
        label: '排序级别',
        key: 'sequence',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'switch',
        label: '做为副标题',
        key: 'isSubTitle',
        activeValue: true,
        inactiveValue: false,
        value: false,
        defaultValue: false
      }, {
        type: 'switch',
        label: '状态',
        key: 'status',
        width: '',
        value: '',
        defaultValue: null
      }]
    })

    const getDataList = () => {
      tools.get('/homeColumns/getListByPage', {
        sort: 'sequence asc',
        limit: 1000
      }).then(r => {
        state.list = r.list
      })
    }

    const submit = async (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.parentId = data.parentId ? (typeof data.parentId === 'string' ? data.parentId : data.parentId[data.parentId.length - 1]) : null
      const loading = tools.showLoading('提交中...')
      if (state.pageParams.isEdit) {
        tools.post('/homeColumns/updateById', data).then(res => {
          tools.closeLoading(loading)
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      // if (data.parentId) {
      //   const currentParent = await tools.clientPost('/homeColumns/getDataById', { id: data.parentId })
      //   data.code = currentParent.code
      // }
      tools.post('/homeColumns/create', data).then(res => {
        tools.closeLoading(loading)
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      console.log(searchInfo)
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }

    const recursionArr = (list: any = [], arr: any = [], defineProps, parentItem: any = {}) => {
      arr.forEach((res) => {
        const obj: any = {}
        for (const key in defineProps) {
          obj[key] = res[defineProps[`${key}`]]
        }
        if (res.parentId) {
          obj['父级'] = parentItem.name
          obj['父级编码'] = parentItem.code
        }
        list.push(obj)
        if (res.children && res.children.length > 0) {
          recursionArr(list, res.children, defineProps, res)
        }
      })
    }

    const exportAll = () => {
      const defineProps = {
        名称: 'name',
        编码: 'code'
      }
      const arr: any = []
      recursionArr(arr, state.list, defineProps)
      tools.exportExcel(arr, '栏目类型')
    }

    const openDrawer = (data) => {
      state.pageParams.isDrawer = true
      state.pageParams.isEdit = true
      state.formList.forEach((res) => {
        res.value = data[res.key]
      })
    }

    const openMenuTypeSet = (val) => {
      state.isMenuTypeSetDialog = true
      state.currentColumnId = val.id
      nextTick(() => {
        const dom: any = document.querySelector('.main-content>.el-overlay')
        dom.style.position = 'absolute'
        dom.style.height = '100%'
      })
    }

    onMounted(() => {
      getDataList()
    })

    watch(
      () => state.pageParams.refresh,
      async (newVal) => {
        if (newVal) {
          await getDataList()
          state.pageParams.refresh = false
        }
      }
    )

    return {
      ...toRefs(state),
      exportAll,
      openMenuTypeSet,
      openDrawer,
      getDataList,
      submit,
      search
    }
  }
})
</script>

<style lang="less">
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
</style>
