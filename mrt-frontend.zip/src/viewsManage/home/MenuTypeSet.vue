<template>
  <div class="menu-type-set">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="$tools.openDrawer(pageParams)"
        >添加菜单
        </el-button>
        <el-button plain size="small" type="danger" @click="$tools.delMultiple('homeColumnMenu',selection,pageParams)">
          删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
                :isShowPage="false" :queryData="{columnId:currentColumnId,sort:'sequence asc',limit:1000}"
                :url="tableListUrl">
      <template v-slot="scope">
        <el-button size="small" type="text" @click="$tools.openDrawer(pageParams,true,formList,scope.row)"
        >查看/修改
        </el-button>
        <el-button
          class="font-red"
          size="small"
          type="text"
          @click="$tools.deleteById('homeColumnMenu', scope.row.id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="40%"
      title="首页栏目设置"
    >
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    TableList,
    SearchClass
  },
  props: {
    currentColumnId: {
      default: null,
      type: String
    }
  },
  setup: (props) => {
    const state = reactive({
      tableListUrl: '/homeColumnMenu/getListByPage',
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      isSetMenu: true,
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'name',
          label: '菜单名称',
          type: 'input',
          width: 200
        }, {
          valueKey: 'code',
          label: '课程类型',
          type: 'input',
          width: 140
        },
        {
          valueKey: 'sequence',
          label: '排序',
          width: 100
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        value: null
      }, {
        type: 'none',
        key: 'column_id',
        value: null
      }, {
        type: 'input',
        label: '名称',
        key: 'name',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'cascade',
        label: '父级菜单',
        key: 'parentId',
        width: '',
        value: null,
        url: '/homeColumnMenu/getListByPage',
        queryParams: {
          limit: 10000,
          columnId: props.currentColumnId,
          sort: 'sequence asc'
        },
        defaultValue: ''
      }, {
        type: 'select',
        label: '对应课程类型',
        key: 'typeId',
        width: '',
        value: null,
        url: '/dictionaryData/getByTypeCode',
        queryParams: {
          typeCode: 'homeColumn',
          limit: 10000
        },
        httpType: 'post',
        defaultValue: null
      }, {
        type: 'number',
        label: '排序级别',
        key: 'sequence',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'switch',
        label: '状态',
        key: 'status',
        width: '',
        value: '',
        defaultValue: null
      }]
    })

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.parentId = data.parentId ? (data.parentId.length === 1 ? data.parentId[0] : data.parentId[data.parentId.length - 1]) : null
      data.columnId = props.currentColumnId
      const loading = tools.showLoading('提交中...')
      if (state.pageParams.isEdit) {
        tools.post('/homeColumnMenu/updateById', data).then(res => {
          tools.closeLoading(loading)
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/homeColumnMenu/create', data).then(res => {
        tools.closeLoading(loading)
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      console.log(searchInfo)
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }

    return {
      ...toRefs(state),
      submit,
      search
    }
  }
})
</script>
<style lang="less" scoped>
.menu-type-set {
  min-height: 100%
}
</style>
