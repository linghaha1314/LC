<template>
  <div class="msg-push">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="$tools.openDrawer(pageParams)"
        >添加
        </el-button>
        <el-button plain size="small" type="danger" @click="$tools.delMultiple('swiper',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
                url="/msgPush/getListByPage">
      <template v-slot="scope">
        <el-button size="small" type="text" @click="$tools.openDrawer(pageParams,true,formList,scope.row)"
        >查看/修改
        </el-button>
        <el-button
          class="font-red"
          size="small"
          type="text"
          @click="$tools.deleteById('msgPush', scope.row.id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-dialog
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="40%"
      title="消息推送设置"
    >
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    TableList,
    SearchClass
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'title',
          label: '标题',
          width: 100
        },
        {
          valueKey: 'link',
          label: '链接地址'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        value: null
      }, {
        type: 'input',
        label: '标题',
        key: 'title',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '链接',
        key: 'link',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'richText',
        label: '课程简介',
        key: 'content',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'switch',
        label: '状态',
        key: 'status',
        width: '',
        value: '',
        defaultValue: null
      }]
    })
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/msgPush/updateById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/msgPush/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      console.log(searchInfo)
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }
    return {
      ...toRefs(state),
      submit,
      search
    }
  }
})
</script>
