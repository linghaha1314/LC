<template>
  <div>
    <search-class v-model:refresh="refresh" :isShowSearchInput="false">
      <template v-slot:left-btn>
        <el-button class="background-btn" plain size="small" type="primary" @click="openDialog">
          修改推荐课程
        </el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="refresh" :columns="columns" :query-data="tableQuery" httpType="post"
      v-model:list="list" url="/courses/getDataListByPage" operaWidth="280px" operaFixed="right">
      <template v-slot:status="data">
        <span v-if="data.row.status === -1" class="font-warning font-bold">未提交</span>
        <span v-if="data.row.status === 0" class="font-red font-bold">审核驳回</span>
        <span v-if="data.row.status === 2" class="font-red font-bold">禁用</span>
        <span v-if="data.row.status === 11" class="font-warning font-bold">待审核</span>
        <span v-if="data.row.status === 1" class="font-green font-bold">启用</span>
      </template>
      <template v-slot="scope">
        <div style="white-space: nowrap">
          <el-tooltip content="取消推荐" placement="bottom">
            <el-button :icon="CircleCloseFilled" circle size="small" type="info" @click="cancel(scope.row)" />
          </el-tooltip>
        </div>
      </template>
    </table-list>
    <el-dialog v-model="isDialog" title="设置首页推荐课程">
      <form-list v-if="isDialog" :isEdit="true" :list="formList" @submit="submit">
      </form-list>
    </el-dialog>
  </div>
</template>
<script lang="ts" setup>
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import {
  CircleCloseFilled
} from '@element-plus/icons'
import { ref, reactive, computed, watch } from 'vue'

const list = ref([])

const defaultList: any = ref([])

const convertStringArr = (arr: any) => {
  const list: any = []
  arr.forEach((rr: any) => {
    list.push(rr.id)
  })
  return list
}

const formList = reactive([{
  type: 'remote-select',
  multiple: true,
  label: '推荐课程',
  key: 'list',
  width: '',
  url: '/courses/getListByPage',
  value: null,
  queryParams: {
    limit: 20,
    status: 1
  },
  defaultValue: defaultList,
  required: true
}
])

const isDialog = ref(false)
const tableQuery = ref({
  where: {
    is_recommend: { _eq: true }
  }
})
const refresh = ref(false)

const columns = ref([
  {
    valueKey: 'selection',
    label: '',
    type: 'selection'
  }, {
    valueKey: 'name',
    label: '课程名称'
  },
  {
    valueKey: 'majorName',
    label: '所属专业'
  },
  {
    valueKey: 'staffName',
    label: '发布人'
  },
  {
    valueKey: 'credits',
    label: '学分'
  },
  {
    valueKey: 'status',
    type: 'slot',
    label: '状态',
    width: '80px'
  },
  {
    valueKey: 'created',
    label: '创建日期',
    type: 'time'
  }])
const submit = (val: any) => {
  // 存储到课程推荐表，关联课程表
  const loading = tools.showLoading('提交中...')
  tools.post('/recommend/createUpdate', { list: val.list }).then(res => {
    if (res.success) {
      refresh.value = true
      isDialog.value = false
    }
    tools.closeLoading(loading)
  })
}

const cancel = (val: any) => {
  const loading = tools.showLoading('提交中...')
  tools.post('/courses/updateById', { id: val.id, isRecommend: false }).then(r => {
    tools.closeLoading(loading)
    if (r.success) {
      refresh.value = true
      tools.msg('成功取消!')
    }
  })
}

const openDialog = () => {
  isDialog.value = true
}

watch(() => list.value, (val) => {
  if (val.length !== defaultList.value.length) {
    defaultList.value = convertStringArr(val)
  }
})
</script>
