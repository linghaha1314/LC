<template>
  <el-card v-if="state.form['sequence']===props.currentIndex">
    <el-form
      ref="ruleFormRef"
      :model="state.form">
      <el-form-item prop="desc">
        <div class="flex">
          <span class="font-bold">{{ state.form['sequence'] + 1 }}.</span>
          <el-input v-model="state.form.name" placeholder="输入题目" style="margin-left:8px"></el-input>
          <span class="font-bold" style="margin-left: 16px;white-space: nowrap">
             (分值：
          <el-input v-model="state.form['score']" :min="0" placeholder="分值"
                    style="width: 100px;" type="number"></el-input>
          ）
          </span>
        </div>
      </el-form-item>
      <el-form-item v-if="state.form['type']==='radio'" prop="resource">
        <el-radio-group v-model="state.form['resultOption']" @change="changeResultOption($event,'radio')">
          <el-radio v-for="(i,index) in state.form['options']" :key="index" :label="i.name">
            <el-input v-model="i.name"></el-input>
            <div class="inline-block opera-buttons">
              <el-button :icon="Plus" size="small" title="复制" type="primary" @click="addOption(i,index)"/>
              <el-button :icon="Delete" size="small" title="删除" type="danger" @click="deleteOption(i,index)"/>
            </div>
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item v-if="state.form['type']==='checkbox'" prop="type">
        <el-checkbox-group v-model="state.form['resultOption']" @change="changeResultOption($event,'checkbox')">
          <el-checkbox v-for="(i,index) in state.form['options']" :key="index" :label="i.name"
                       name="type">
            <el-input v-model="i.name"></el-input>
            <div class="inline-block opera-buttons">
              <el-button :icon="Plus" size="small" title="复制" type="primary"
                         @click="addOption(i,index)"/>
              <el-button :icon="Delete" size="small" title="删除" type="danger"
                         @click="deleteOption(i,index)"/>
            </div>
          </el-checkbox>
        </el-checkbox-group>
      </el-form-item>
    </el-form>
    <div class="card-footer">
      <el-select v-model="state.form['type']" class="m-2" @change="changeType($event)">
        <el-option
          v-for="item in state.options"
          :key="item.code"
          :label="item.name"
          :value="item.code"
        />
      </el-select>
      <slot></slot>
    </div>
  </el-card>
  <div v-else style="margin-left: 16px" @click="changeCurrentIndex(state.form['sequence'])">
    <div>
      <span class="font-bold">{{ state.form['sequence'] + 1 }}.</span>
      <span v-if="state.form['type']==='checkbox'" class="color666">（多选题）</span>
      <span v-if="state.form['type']==='radio'" class="color666">（单选题）</span>
      <span v-html="state.form.name"></span>
      <span>（分值：{{ state.form['score'] }}）</span>
    </div>
    <ul v-if="state.form['type']==='checkbox' ||  state.form['type']==='radio'">
      <li v-for="(dd,key) in state.form['options']" :key="key">
        <span class="font-bold">
          {{ $tools.numberToLetter(key + 1) }}.
        </span>
        &nbsp;&nbsp;{{ dd.name }}
        <span v-if="dd.isRight">正确答案</span>
      </li>
    </ul>
  </div>
</template>

<script lang="ts" setup>
import { defineEmits, defineProps, reactive } from 'vue'
import { Delete, Plus } from '@element-plus/icons-vue'
// 设置一个接口数据格式
const props = defineProps({
  form: {
    type: Object,
    default: () => {
      return {}
    }
  },
  currentIndex: {
    type: Number,
    default: 0
  }
})
const emits = defineEmits(['update:currentIndex', 'update:form'])
const state = reactive({
  closeCircleSharp: 'close-circle-sharp',
  form: props.form,
  options: [{
    name: '多选',
    code: 'checkbox'
  }, {
    name: '单选',
    code: 'radio'
  }]
})
const addOption = (item, index) => {
  const data = JSON.parse(JSON.stringify(item))
  data.key = index
  state.form.options.splice(index, 0, data)
}
const deleteOption = (item, index) => {
  if (state.form.options.length > 1) {
    state.form.options.splice(index, 1)
  }
}
const changeCurrentIndex = (sequence) => {
  emits('update:form', state.form)
  emits('update:currentIndex', sequence)
}
const changeType = (val) => {
  if (val === 'checkbox') {
    state.form.resultOption = []
  } else {
    state.form.resultOption = null
  }
}
const changeResultOption = (val, type) => {
  if (type === 'radio') {
    state.form.options.forEach(rr => {
      rr.isRight = false
      if (rr.name === val) {
        rr.isRight = true
      }
    })
  } else {
    // val是一个【】
    val.forEach(res => {
      state.form.options.forEach(rr => {
        if (res.name === rr.name) {
          rr.isRight = true
        }
      })
    })
  }
}
</script>

<style lang="less" scoped>
@import (once) '~@/assets/css/commen.less';

.el-header {
  display: flex;
  flex-direction: row-reverse;
}

.question-title {
  //display: inline-block;
  //border: none;

  textarea {
    border: none !important;
  }
}

.el-card {
  margin: 16px;
}

.block {
  display: flex;
}

.el-radio, .el-checkbox {
  display: block;
  margin: 8px 0;
}

.card-footer {
  display: flex;
  flex-direction: row-reverse;
}

.opera-buttons {
  margin: 0 16px;
}

ul {
  padding: 16px;

  li {
    margin: 16px 0;
  }
}

.content-div {
  height: auto;
  margin-left: 16px;
  width: 100%;
}
</style>
