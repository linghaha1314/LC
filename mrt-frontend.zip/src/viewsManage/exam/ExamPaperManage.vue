<!--<template>-->
<!--  <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">-->
<!--    <template v-slot:left-btn>-->
<!--      <el-button-->
<!--        class="background-btn"-->
<!--        plain-->
<!--        size="small"-->
<!--        type="primary">-->
<!--        <router-link target="_blank" to="/manage/examCreate">新增</router-link>-->
<!--      </el-button>-->
<!--      <el-button plain size="small" type="danger" @click="$tools.delMultiple('examPaper',selection,pageParams)">删除-->
<!--      </el-button>-->
<!--    </template>-->
<!--  </search-class>-->
<!--  <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="columns"-->
<!--              url="/examPaper/getListByPage">-->
<!--    <template v-slot="scope">-->
<!--      <el-button size="small" type="text"-->
<!--      >-->
<!--        <router-link :to="'/manage/examCreate?paperId='+scope.row.id" target="_blank">查看/修改</router-link>-->
<!--      </el-button>-->
<!--      <el-button-->
<!--        class="font-red"-->
<!--        size="small"-->
<!--        type="text"-->
<!--        @click="$tools.deleteById('courses', scope.row.id,pageParams)"-->
<!--      >删除-->
<!--      </el-button>-->
<!--    </template>-->
<!--  </table-list>-->
<!--  &lt;!&ndash;  <el-dialog&ndash;&gt;-->
<!--  &lt;!&ndash;    v-model="pageParams.isDrawer"&ndash;&gt;-->
<!--  &lt;!&ndash;    custom-class="course-manage-dialog-content-wrapper"&ndash;&gt;-->
<!--  &lt;!&ndash;    destroy-on-close&ndash;&gt;-->
<!--  &lt;!&ndash;    title="考试设计"&ndash;&gt;-->
<!--  &lt;!&ndash;    top="0vh"&ndash;&gt;-->
<!--  &lt;!&ndash;    width="100%">&ndash;&gt;-->
<!--  &lt;!&ndash;    <el-button color="primary" @click="create('radio')">单选</el-button>&ndash;&gt;-->
<!--  &lt;!&ndash;    <el-button color="success" @click="create('checkbox')">多选</el-button>&ndash;&gt;-->
<!--  &lt;!&ndash;    <question-module v-for="i in questionList" :key="i"></question-module>&ndash;&gt;-->
<!--  &lt;!&ndash;  </el-dialog>&ndash;&gt;-->
<!--</template>-->

<!--<script lang="ts">-->
<!--import { defineComponent, reactive, toRefs } from 'vue'-->
<!--import tools from '@/utils/tool'-->
<!--import TableList from '@/viewsManage/components/TableList.vue'-->
<!--import SearchClass from '@/viewsManage/components/SearchClass.vue'-->

<!--export default defineComponent({-->
<!--  components: {-->
<!--    TableList,-->
<!--    SearchClass-->
<!--  },-->
<!--  setup: () => {-->
<!--    const state = reactive({-->
<!--      pageParams: {-->
<!--        isEdit: false,-->
<!--        isDrawer: false,-->
<!--        refresh: false-->
<!--      },-->
<!--      courseTypeList: [],-->
<!--      selection: [],-->
<!--      tagList: [],-->
<!--      columns: [-->
<!--        {-->
<!--          valueKey: 'selection',-->
<!--          label: '',-->
<!--          type: 'selection'-->
<!--        }, {-->
<!--          valueKey: 'name',-->
<!--          label: '试卷'-->
<!--        },-->
<!--        {-->
<!--          valueKey: 'number',-->
<!--          label: '题目数'-->
<!--        }, {-->
<!--          valueKey: 'totalScore',-->
<!--          label: '总分'-->
<!--        }, {-->
<!--          valueKey: 'remark',-->
<!--          label: '备注'-->
<!--        },-->
<!--        {-->
<!--          valueKey: 'created',-->
<!--          label: '创建日期',-->
<!--          type: 'time'-->
<!--        }],-->
<!--      lecturerList: [], // 主讲人列表-->
<!--      searchInfo: {},-->
<!--      searchInit: [-->
<!--        {-->
<!--          name: 'isSearch',-->
<!--          desc: '关键词',-->
<!--          placeholder: '请输入内容',-->
<!--          value: 'search'-->
<!--        },-->
<!--        {-->
<!--          name: 'isTime',-->
<!--          desc: '日期',-->
<!--          placeholder: '选择日期',-->
<!--          value: 'time'-->
<!--        }-->
<!--      ], // 筛选条件项-->
<!--      formList: [{-->
<!--        type: 'none',-->
<!--        key: 'id',-->
<!--        width: '',-->
<!--        value: null,-->
<!--        required: true,-->
<!--        defaultValue: null-->
<!--      }, {-->
<!--        type: 'input',-->
<!--        label: '课程名',-->
<!--        key: 'name',-->
<!--        width: '',-->
<!--        value: null,-->
<!--        required: true,-->
<!--        defaultValue: ''-->
<!--      }, {-->
<!--        type: 'cascade',-->
<!--        label: '课程类型',-->
<!--        key: 'typeId',-->
<!--        width: '',-->
<!--        value: null,-->
<!--        url: '/courseType/getListByPage',-->
<!--        queryParams: { limit: 1000 },-->
<!--        defaultValue: '',-->
<!--        required: true-->
<!--      }, {-->
<!--        type: 'select',-->
<!--        label: '主讲人',-->
<!--        url: '/user/getListByPage',-->
<!--        queryparams: {-->
<!--          roleType: ''-->
<!--        },-->
<!--        key: 'lecturerId',-->
<!--        width: '',-->
<!--        value: null,-->
<!--        defaultValue: null-->
<!--      }, {-->
<!--        type: 'uploadImg',-->
<!--        label: '课程封面',-->
<!--        key: 'img',-->
<!--        width: '',-->
<!--        value: null,-->
<!--        required: true,-->
<!--        defaultValue: ''-->
<!--      }, {-->
<!--        type: 'textarea',-->
<!--        label: '课程介绍',-->
<!--        key: 'introduce',-->
<!--        width: '100',-->
<!--        value: null,-->
<!--        defaultValue: ''-->
<!--      }, {-->
<!--        type: 'richText',-->
<!--        label: '课程简介',-->
<!--        key: 'brief',-->
<!--        width: '',-->
<!--        value: '',-->
<!--        defaultValue: null-->
<!--      }, {-->
<!--        type: 'number',-->
<!--        label: '课程学分',-->
<!--        key: 'credits',-->
<!--        width: '',-->
<!--        value: '',-->
<!--        defaultValue: null-->
<!--      }, {-->
<!--        type: 'number',-->
<!--        label: '排序',-->
<!--        key: 'sequence',-->
<!--        width: '',-->
<!--        value: '',-->
<!--        defaultValue: 5-->
<!--      }]-->
<!--    })-->
<!--    const search = (searchInfo) => {-->
<!--      // state.queryParams = { ...state.queryParams, ...searchInfo }-->
<!--    }-->
<!--    const submit = (val) => {-->
<!--      const data = JSON.parse(JSON.stringify(val))-->
<!--      delete data.sequence-->
<!--      if (state.pageParams.isEdit) {-->
<!--        tools.post('/courses/updateById', data).then(res => {-->
<!--          if (res.success) {-->
<!--            state.pageParams.isDrawer = false-->
<!--            tools.msg(res.msg)-->
<!--            state.pageParams.refresh = true-->
<!--          }-->
<!--        })-->
<!--        return-->
<!--      }-->
<!--      delete data.id-->
<!--      tools.post('/courses/create', data).then(res => {-->
<!--        if (res.success) {-->
<!--          state.pageParams.isDrawer = false-->
<!--          tools.msg(res.msg)-->
<!--          state.pageParams.refresh = true-->
<!--        }-->
<!--      })-->
<!--    }-->
<!--    return {-->
<!--      ...toRefs(state),-->
<!--      search,-->
<!--      submit-->
<!--    }-->
<!--  }-->
<!--})-->
<!--</script>-->

<!--<style lang="less">-->
<!--.course-manage-dialog-content-wrapper {-->
<!--  height: 100%;-->
<!--  margin: 0;-->
<!--}-->
<!--</style>-->
