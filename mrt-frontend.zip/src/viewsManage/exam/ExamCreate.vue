<template>
  <el-container>
    <el-header>
      <el-row class="mb-4">
        <el-button type="primary" @click="create('radio')">单选</el-button>
        <el-button type="success" @click="create('checkbox')">多选</el-button>
        <el-button type="info">预览试卷</el-button>
        <el-button type="warning" @click="save()">保存</el-button>
      </el-row>
    </el-header>
    <el-main>
      <div style="margin-bottom: 24px;width:50%;transform: translate(50%,0)">
        <el-input v-model="state.examPaper.name" clearable placeholder="请输入试卷名"/>
      </div>
      <question-module v-for="(i,index) in state.questionList" :key="i" v-model:currentIndex="state.currentIndex"
                       :form="i">
        <el-button class="opera-buttons" plain size="small" title="复制" type="primary" @click="addQuestion(i,index)">复制
        </el-button>
        <el-button class="opera-buttons" plain size="small" title="删除" type="danger" @click="deleteQuestion(i,index)">删除
        </el-button>
      </question-module>
    </el-main>
  </el-container>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from 'vue'
import QuestionModule from '@/viewsManage/exam/QuestionModule.vue'
import tools from '@/utils/tool'
import router from '@/router'

const questionList: any[] = []
const state = reactive({
  questionList: questionList,
  examPaper: {
    name: '',
    number: 0,
    totalScore: 0
  },
  currentIndex: 0
})
const create = (type) => {
  const form: any = {
    name: '',
    sequence: state.questionList.length || 0,
    resultOption: type === 'radio' ? null : [],
    score: 0,
    options: [{
      key: 1,
      name: '',
      isRight: false
    }],
    type: type
  }
  state.currentIndex = state.questionList.length || 0
  state.questionList.push(form)
}
const addQuestion = (item, index) => {
  const data = JSON.parse(JSON.stringify(item))
  data.sequence += 1
  state.currentIndex = data.sequence
  state.questionList.splice(index + 1, 0, data)
}
const deleteQuestion = (item, index) => {
  // 重新拍讯
  state.questionList.splice(index, 1)
  state.questionList.forEach((res, ii) => {
    res.sequence = ii
  })
}
const save = () => {
  state.examPaper.totalScore = 0
  state.examPaper.number = state.questionList.length
  state.questionList.forEach(res => {
    state.examPaper.totalScore += Number(res.score)
  })
  tools.post('/exam/insert', {
    ...state.examPaper,
    questionList: state.questionList
  }).then(r => {
    console.log(r)
  })
}
const getPaper = (id) => {
  tools.post('/examPaper/getDataById', { id }).then(r => {
    state.examPaper = r.data
  })
}
const getQuestionList = (id) => {
  tools.post('/exam/getQuestionList', { paperId: id }).then(r => {
    state.questionList = r.list
    state.currentIndex = -1
  })
}
onMounted(() => {
  const id = router.currentRoute.value.query.paperId
  if (id) {
    getPaper(id)
    getQuestionList(id)
  }
})
</script>

<style lang="less" scoped>
.el-header {
  background: #295354;
  display: flex;
  align-items: center;
}

.opera-buttons {
  margin: 0 16px;
}
</style>
