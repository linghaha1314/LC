<template>
  <div class="bread-crumb">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item v-for="i in obj.breadcrumb" :key="i.id" :to="{ path:i.path}">{{i.name}}</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- <div class="subTitle" v-if="obj.breadcrumb">{{obj.breadcrumb[obj.breadcrumb.length-1].name}}</div>
    <div class="nav-box">
      <span v-for="i in 2" :key="i" :class="{'font-green':activeId==i}" @click="changeUsers(i)">个人用户</span>
    </div>-->
  </div>
</template>
<script>
export default {
  data () {
    return {
      activeId: 1
    }
  },
  props: ['obj'],
  methods: {
    changeUsers (id) {
      this.activeId = id
      // 改变父组件的选择id
      this.$emit('changeUser', id)
    }
  }
}
</script>
<style lang="less" scoped>
@import (once) "~@/assets/css/manage.less";

.bread-crumb {
  .subTitle {
    font-size: 20px;
    font-weight: bold;
    margin-top: 20px;
  }
  .nav-box {
    margin-top: 20px;
    font-weight: 400;
    span {
      margin-right: 20px;
    }
  }
}
</style>
