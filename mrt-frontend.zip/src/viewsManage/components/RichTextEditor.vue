<template>
  <div ref='editor'></div>
</template>

<script>
import { onMounted, onBeforeUnmount, ref } from 'vue'
import WangEditor from 'wangeditor'

export default {
  name: 'app',
  props: ['value', 'disabled'],
  emits: ['update:value'],
  setup (props, { emit }) {
    const editor = ref()
    let instance
    onMounted(() => {
      instance = new WangEditor(editor.value)
      // 配置 server 接口地址
      instance.config.uploadImgServer = '/public/uploadEditor'
      instance.config.uploadImgHeaders = {
        contentType: 'application/json; charset=utf-8'
      }
      instance.config.uploadFileName = 'file'
      Object.assign(instance.config, {
        onchange () {
          emit('update:value', instance.txt.html())
        }
      })
      instance.create()
      if (props.value) {
        instance.txt.html(props.value)
      }
      if (props.disabled) {
        instance.disable()
      }
    })

    onBeforeUnmount(() => {
      instance.destroy()
      instance = null
    })

    return {
      editor
    }
  }
}
</script>
