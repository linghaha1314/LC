<template>
  <div class="flex card">
    <div class="card-wrapper left-wrapper">
      <div class="card-title">
        <el-checkbox v-model="left.checkedAll" label="全选" size="small"
                     @change="($event)=>{handleCheckAllChange($event,'left')}"/>
        <small>{{ left.checkedList.length }}/{{ left.list.length }}</small>
      </div>
      <div class="card-content" v-loading="left.loading">
        <el-input
          size="small"
          v-model="left.search"
          class="w-50 m-2"
          placeholder="搜索"
          :suffix-icon="Search"
          clearable
          @input="($event)=>{changeSearch($event,'left')}"
        />
        <el-checkbox-group v-model="left.checkedList" style="display:flex;flex-direction:column;">
          <el-checkbox v-for="i in left.list" :key="i.id" size="small" :disabled="i['disabled']" :label="i.id">
              <span v-if="!i.disabled">{{ i.name }}
              <small class="color999">-{{ i.username }}</small></span>
            <span v-else class="del-text">{{ i.name }} -{{ i.username }}</span>
          </el-checkbox>
        </el-checkbox-group>
      </div>
      <div class="card-footer">
        <el-pagination small layout="prev, pager, next" :pager-count="5" :total="left.total"
                       :page-size="left.limit"
                       @current-change="($event)=>{currentChange($event,'left')}"/>
      </div>
    </div>
    <div style="margin:0 16px;" class="flex align-center">
      <div>
        <el-button type="primary" :disabled="left.checkedList.length===0" @click="convert('left')"
                   style="margin: 0 16px 16px 0">移至右边
        </el-button>
        <br>
        <el-button type="secondary" :disabled="right.checkedList.length===0" @click="convert('right')"
                   style="margin: 0 0 0 16px">移至左边
        </el-button>
      </div>
    </div>
    <div class="card-wrapper right-wrapper">
      <div class="card-title">
        <el-checkbox v-model="right.checkedAll" label="全选" size="small"
                     @change="($event)=>{handleCheckAllChange($event,'right')}"/>
        <small>{{ right.checkedList.length }}/{{ right.list.length }}</small>
      </div>
      <div class="card-content" v-loading="right.loading">
        <el-input
          size="small"
          v-model="right.search"
          class="w-50 m-2"
          clearable
          placeholder="搜索"
          :suffix-icon="Search"
          @input="($event)=>{changeSearch($event,'right')}"
        />
        <el-checkbox-group v-model="right.checkedList" style="display:flex;flex-direction:column;">
          <el-checkbox v-for="i in rightList" :key="i.id" size="small" :label="i.id">{{
              i.name
            }}<small class="color999">-{{ i.username }}</small>
          </el-checkbox>
        </el-checkbox-group>
      </div>
      <div class="card-footer">
        <el-button type="primary" @click="save" size="small">保存</el-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, onMounted, defineProps, reactive, defineEmits, ref, watch } from 'vue'
import tools from '@/utils/tool'
import { Search } from '@element-plus/icons-vue'

const props = defineProps({
  leftUrl: {
    type: String,
    default: ''
  },
  rightUrl: {
    type: String,
    default: ''
  },
  queryDataRight: {
    type: String,
    default: '{}'
  },
  queryDataLeft: {
    type: String,
    default: '{}'
  },
  refresh: {
    type: Boolean,
    default: false
  }
})
const emit = defineEmits(['saveData', 'update:refresh'])

const left = reactive({
  isIndeterminate: false,
  loading: false,
  list: [],
  checkedList: [] as any[],
  total: 0,
  search: '',
  limit: 20,
  offset: 0,
  checkedAll: false
})

const right = reactive({
  checkedAll: false,
  isIndeterminate: false,
  loading: false,
  list: [] as any[],
  cacheList: [] as any[],
  checkedList: [] as any[],
  search: '',
  total: 0
})

const rightList = computed(() => {
  return right.list.filter(rr => !rr.hide)
})

const initData = async () => {
  left.loading = true
  await tools.post(props.leftUrl, {
    limit: left.limit,
    offset: left.offset,
    ...(JSON.parse(props.queryDataLeft?.replace('search', left.search)))
  }).then(r => {
    left.total = r.total
    right.list.forEach((res: any) => {
      r.list.forEach((dd: any) => {
        if (res.id === dd.id) {
          dd.disabled = true
        }
      })
    })
    emit('update:refresh', false)
    left.list = r.list
    left.loading = false
  })
}

const handleCheckAllChange = (val, type) => {
  if (type === 'left') {
    left.isIndeterminate = !left.isIndeterminate
    const cache: any = {}
    if (left.isIndeterminate) {
      left.list.forEach((rr: any) => {
        cache[rr.id] = true
      })
    }
    left.checkedList = Object.keys(cache)
  } else {
    right.isIndeterminate = !right.isIndeterminate
    const cache: any = {}
    if (right.isIndeterminate) {
      right.list.forEach((rr: any) => {
        cache[rr.id] = true
      })
    }
    right.checkedList = Object.keys(cache)
  }
}

const convert = (type = 'left') => {
  const mapList = new Map()
  if (type === 'right') {
    right.checkedList.forEach((res, index) => {
      mapList.set(res, index)
      right.list = right.list.filter(rr => rr.id !== res)
    })
    // 当前页面的数据要清空
    left.list.forEach((rr: any) => {
      if (mapList.has(rr.id)) {
        rr.disabled = false
      }
    })
    left.checkedList = []
    right.checkedList = []
    right.checkedAll = false
    right.isIndeterminate = false
    return
  }
  left.checkedList.forEach((res, index) => {
    mapList.set(res, index)
  })
  const arr: any = []
  left.list.forEach((rr: any) => {
    if (mapList.has(rr.id)) {
      rr.disabled = true
      arr.push(rr)
    }
  })
  left.checkedList = []
  right.list = [...right.list, ...arr]
  left.checkedAll = false
  left.isIndeterminate = false
}

const rightData = async () => {
  right.loading = true
  await tools.post(props.rightUrl, {
    ...(JSON.parse(props.queryDataRight?.replace('search', left.search))),
    limit: 10000
  }).then(r => {
    right.list = r.list
    right.total = r.total
    right.loading = false
  })
}

const currentChange = (val, type) => {
  left.offset = left.limit * (val - 1)
  left.checkedList = []
  left.isIndeterminate = false
  left.checkedAll = false
  initData()
}

const changeSearch = async (val, type) => {
  if (type === 'left') {
    left.search = val
    await initData()
  } else {
    if (!val) {
      right.list.forEach(res => {
        res.hide = false
      })
    } else {
      right.list.forEach(res => {
        res.hide = true
        if (res.name.indexOf(val) > -1) {
          res.hide = false
        }
      })
    }
  }
}

const save = () => {
  emit('saveData', right.list)
}

onMounted(async () => {
  await rightData()
  await initData()
  right.cacheList = right.list
})

watch(() => props.refresh, (val) => {
  if (val) {
    initData()
  }
})

</script>

<style lang="less" scoped>

.card {
  padding: 16px;
  background: #ffffff;
  border-radius: 8px;
  margin: 16px;
  display: flex;
  justify-content: center;
}

.del-text {
  text-decoration: line-through;
  text-decoration-color: #000000;
  text-decoration-style: double;
}

.card-wrapper {
  border-radius: 4px;
  box-shadow: #999999;
  width: 240px;
  border: 1px solid #f2f2f2;
  background: #ffffff;

  .card-title {
    background: #f2f2f2;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    color: #999999;
  }

  .card-content {
    padding: 16px;
    height: 300px;
    overflow-y: scroll;
    overflow-x: hidden;
  }

  .card-footer {
    padding: 8px;
    border-top: 1px solid #f2f2f2;
    text-align: right;
    overflow: hidden;
  }
}

.left-wrapper {
}

.right-wrapper {

}

</style>
