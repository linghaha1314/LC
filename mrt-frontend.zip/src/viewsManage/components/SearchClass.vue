<template>
  <div class="search-class-ul">
    <div v-for="(i, index) in searchInit" :key="index" class="class-box">
      <!-- 时间选择器 -->
      <div v-if="i['name'] === 'isTime'" class="time-choose-box">
        <span>{{ i['desc'] }}：</span>
        <el-date-picker v-if="!i['daterange']" v-model="state.searchInfo[i['value']]" :placeholder="i['placeholder']"
                        size="small" type="date"></el-date-picker>
        <el-date-picker v-else v-model="state.searchInfo[i['value']]" :picker-options="pickerOptions" align="right"
                        end-placeholder="结束日期" range-separator="至" size="small" start-placeholder="开始日期" type="derange"
                        unlink-panels>
        </el-date-picker>
      </div>
      <!--  选择器-->
      <div v-else-if="i['name'] === 'isSelect'" class="select-box">
        <span>{{ i['desc'] }}：</span>
        <el-select v-model="state.searchInfo[i['value']]" :loading="remoteLoading" :placeholder="i['placeholder']"
                   :remote-method="(query) => { selectRemoteMethod(query, i) }" filterable remote
                   :clearable="!i['isNotClearable']" size="small" @change="search" @focus="selectFocus(i)">
          <el-option v-for="item in i['options']" :key="item.id" :label="item[i['labelKey']] || item.name"
                     :value="item[i['valueKey']] || item.id"></el-option>
        </el-select>
      </div>
      <!-- 树状选择器 -->
      <div v-else-if="i['name'] === 'isSelectTree'" class="el-select-tree-box">
        <span>{{ i['desc'] }}：</span>
        <el-select v-model="state.searchInfo[i['value']]" :placeholder="i['placeholder']">
          <el-option :label="categoryName" :value="i['categoryId']" style="height: auto; padding: 0">
            <el-tree ref="tree" :data="i.options" :node-key="i.id" :props="i['formatProps']" highlight-current
                     @node-click="handleNodeClick($event, i)"></el-tree>
          </el-option>
        </el-select>
      </div>
      <!--层级选择器-->
      <div v-else-if="i['name'] === 'isCascader'" class="el-select-tree-box">
        <span>{{ i['desc'] }}：</span>
        <el-cascader v-model="state.searchInfo[i['value']]" :disabled="i.disabled" :options="i.list"
                     :placeholder="i.placeholder" :props="i.props || defaultProps" :show-all-levels="false" clearable
                     @change="($event)=>{search($event,i)}"/>
      </div>
      <!-- 选择时间范围-->
      <div v-else-if="i['name'] === 'daterange'" class="demo-date-picker" style="margin:10px">
        <div class="block">
          <span class="demonstration">选择周期：</span>
          <el-date-picker
            v-model="state.searchInfo[i['value']]"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            size="small"
            unlink-panels
            :picker-options="endDatePicker(i.maxDate)"
            @change="($event)=>{search($event,i)}"
          />
        </div>
      </div>
    </div>
    <el-button size="small" type="primary" plain @click="reset" v-if="isShowReset">重置</el-button>
    <!-- 查询 -->
    <div class="opera-buttons" v-if="!isHideRight">
      <div class="">
        <slot name="left-btn"></slot>
      </div>
      <div>
        <el-input v-if="isShowSearchInput" v-model="state.searchInfo[searchKey]" :placeholder="placeholder" size="small"
                  style="width: 200px;margin-right: 16px" @input="search" clearable></el-input>
        <el-button-group class="ml-4" size="small">
          <el-button :icon="Refresh" @click="clickRefresh"></el-button>
          <el-button :icon="Menu" @click="openCheckbox" style="position: relative;">
            <div style="position: absolute;top:-20%;left:0;visibility: hidden;">
              <el-cascader
                popper-class="table-column-list-choose"
                v-model="state.cascadeChecked"
                ref="cascadeRef"
                :options="tableColumns"
                :props="{value:'valueKey',multiple: true }"
                collapse-tags
                @change="cascadeChange"
              />
            </div>
          </el-button>
          <el-button v-if="isShowExportBtn" @click="exportAll">
            导出EXCEL
          </el-button>
          <slot name="right-group-btn"></slot>
        </el-button-group>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { Refresh, Menu } from '@element-plus/icons-vue'
import { defineEmits, defineProps, onMounted, reactive, ref } from 'vue'
import tools from '@/utils/tool'

const remoteLoading = ref(false)

const props = defineProps({
  searchInit: {
    type: Object,
    default: () => {
      return []
    }
  },
  searchInfo: {
    type: Object,
    default: () => {
      return {}
    }
  },
  tableName: {
    type: Object,
    default: () => {
      return {}
    }
  },
  refresh: {
    type: Boolean,
    default: false
  },
  isHideRight: {
    type: Boolean,
    default: false
  },
  isShowReset: {
    type: Boolean,
    default: false
  },
  searchKey: {
    type: String,
    default: 'name'
  },
  isShowSearchInput: {
    type: Boolean,
    default: true
  },
  list: {
    type: Array,
    default: () => {
      return []
    }
  },
  tableColumns: {
    type: Array,
    default: () => {
      return [] as any[]
    }
  },
  placeholder: {
    type: String,
    default: '搜索'
  },
  isShowExportBtn: {
    type: Boolean,
    default: false
  }
})

const cascadeRef: any = ref(null)

const emit = defineEmits(['exportAll', 'update:refresh', 'update:tableColumns', 'update:searchInfo', 'search'])

const reset = () => {
  state.searchInfo = {}
  emit('update:searchInfo', {})
  emit('search', {})
  emit('update:refresh', true)
}

const selectRemoteMethod = (query, res) => {
  if (query && res.url) {
    remoteLoading.value = true
    const search: any = {}
    if (res.isInWhereName && query) {
      res.queryParams.where.name = { _like: query }
    } else {
      search[res.searchKey || 'name'] = query
    }
    tools[res.httpType || 'get'](res.url, { ...res.queryParams, ...search } || {}).then((r) => {
      remoteLoading.value = false
      res.options = r.list
    })
  } else {
    res.options = []
  }
}

const endDatePicker = (endDate, startDate?) => {
  return {
    disabledDate (time) {
      endDate = endDate === 'today' ? tools.formatTime('') : endDate
      if (endDate && endDate) {
        // 时间要控制在一个范围内时
      } else if (endDate) {
        return new Date(endDate).getTime() > time.getTime()
      } else {
        // return new Date(startDate).getTime < time.getTime()
      }
    }
  }
}

const exportAll = () => {
  emit('exportAll')
}

const defaultProps = reactive({
  checkStrictly: true,
  label: 'name',
  value: 'id'
})

const state = reactive({
  inputSearch: '',
  cascadeChecked: (() => {
    const list: any = []
    props.tableColumns.forEach((rr: any) => {
      if (!rr.isHide) {
        list.push([rr.valueKey])
      }
    })
    return list
  })(),
  pickerOptions: {
    shortcuts: [
      {
        text: '最近一周',
        onClick: (picker) => {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
          picker.$emit('pick', [start, end])
        }
      },
      {
        text: '最近一个月',
        onClick: (picker) => {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
          picker.$emit('pick', [start, end])
        }
      },
      {
        text: '最近三个月',
        onClick: (picker) => {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
          picker.$emit('pick', [start, end])
        }
      }
    ]
  },
  searchInfo: {},
  categoryName: '',
  Refresh: Refresh
})

const search = (val, i?) => {
  const data: any = JSON.parse(JSON.stringify(state.searchInfo)) // bug:当子数据是数组或者对象的时候，是Object
  if (data[props.searchKey]) {
    data[props.searchKey] = '%' + (data[props.searchKey] as string).trim() + '%'
  } else {
    delete data[props.searchKey]
  }
  emit('update:searchInfo', data)
  emit('search', data)
  emit('update:refresh', true)
}

const selectFocus = (val) => {
  if (val.url) {
    selectRemoteMethod('%%', val)
  }
}

const clickRefresh = () => {
  emit('update:refresh', true)
}

const handleNodeClick = (data, i) => {
  state.categoryName = data.name
  state.searchInfo[i.value] = data.name
  emit('search', { [i.value]: data.id })
  emit('update:refresh', true)
}

const cascadeChange = (val) => {
  const list: any = []
  const mapList = new Map(JSON.parse(JSON.stringify(state.cascadeChecked)))
  props.tableColumns.forEach((rr: any) => {
    rr.isHide = !mapList.has(rr.valueKey)
    list.push(rr)
  })
  emit('update:tableColumns', list)
}

const openCheckbox = () => {
  console.log('==>>??', cascadeRef.value)
  cascadeRef.value.popperVisible = true
}

onMounted(() => {
  (props.searchInit || []).forEach(res => {
    if (res.defaultValue) {
      state.searchInfo[res.value] = res.defaultValue
    }
  })
})
</script>

<style lang="less">
.table-column-list-choose {
  .el-cascader-menu__wrap.el-scrollbar__wrap {
    height: auto;
  }
}
</style>

<style lang="less" scoped>
@import (once) "~@/assets/css/manage.less";

/deep/ .el-cascader__tags {
  display: none !important;
}

.search-class-ul {
  & > div {
    display: inline-block;
    margin-right: 15px;
    margin-top: 10px;
    margin-bottom: 10px;

    &:last-child {
      margin-right: 0;
    }
  }

  .opera-buttons {
    display: flex;
    justify-content: space-between;
  }
}
</style>
