<template>
  <el-form id="form-list" ref="formRef" :model="state.form" :rules="rules" label-position="right" label-width="auto"
           style="padding: 16px">
    <li v-for="(dd, index) in list" :key="dd.key">
      <el-form-item
        v-if="dd.type === 'input' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-input v-if="!isReadOnly" v-model="state.form[dd.key]" :disabled="isReadOnly || dd.disabled"
                  :maxlength='dd.maxlength' :placeholder="'请输入' + dd.label" class="form-input"
                  @blur="dd.change(state.form[dd.key])"></el-input>
        <div v-if="isReadOnly"
             style="color:#666;background:#f5f7fa;border:1px solid #cccccc;padding:0px 12px;border-radius: 4px;min-width:172px;width:fit-content">
          {{
            state.form[dd.key]
          }}
        </div>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'textarea' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-input v-model="state.form[dd.key]" :autosize="{ minRows: dd.minRows || 2 }"
                  :disabled="isReadOnly || dd.disabled" :placeholder="'请输入' + dd.label"
                  :style="`width: ${dd.width || '100%'};`"
                  class="form-input" type="textarea">
        </el-input>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'number' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-input v-model="state.form[dd.key]" :disabled="isReadOnly || dd.disabled" :min="0"
                  :placeholder="'请输入' + dd.label" class="form-input" type="number" @blur="dd.change(state.form[dd.key])"
        ></el-input>
      </el-form-item>
      <div
        v-if="dd.type === 'slot' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))">
        <slot :name="dd.name"></slot>
      </div>
      <el-form-item
        v-if="dd.type === 'switch' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-switch v-model="state.form[dd.key]" :active-value="dd.activeValue || 1"
                   :disabled="isReadOnly || dd.disabled" :inactive-value="dd.inactiveValue || 0" active-color="#13ce66"
                   class="ml-2"/>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'remote-select' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <div class="flex">
          <el-select v-model="state.form[dd.key]" filterable remote reserve-keyword
                     :clearable="dd.clearable"
                     :disabled="isReadOnly || dd.disabled"
                     :multiple="dd.multiple" :placeholder="dd.placeholder || '输入关键字搜索'"
                     :remote-method="($event) => { remoteSelect($event, dd) }">
            <el-option v-for="item in dd.options" :key="item[dd.optionsValue || 'id']"
                       :label="item[dd.optionsLabel] || item.label || item.name"
                       :value="item[dd.optionsValue] || item.value || item.id"/>
          </el-select>
          <div v-if="dd.addBtn">&nbsp;
            <el-button type="primary" :icon="CirclePlusFilled" circle size="small" @click="dd.isShowAdd=!dd.isShowAdd"/>
          </div>
        </div>
        <div v-if="dd.addBtn && dd.isShowAdd" style="padding: 16px 0 0 0">
          <el-input v-model="dd.lecturerName" :placeholder="dd.addPlaceholder" style="max-width:200px"></el-input>&nbsp;
          <el-button type="primary" size="small" @click="addBtn(dd)" plain>新增确定</el-button>
        </div>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'select' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <div class="flex">
          <el-select v-model="state.form[dd.key]" :disabled="isReadOnly || dd.disabled" :loading="loading"
                     :multiple="dd.multiple" :placeholder="'请输入' + dd.label" filterable remote reserve-keyword
                     @change="dd.change">
            <el-option v-for="item in dd.options" :key="item.value"
                       :label="item[dd.optionsLabel] || item.label || item.name"
                       :value="item[dd.optionsValue] || item.value || item.id">
            </el-option>
          </el-select>
          <div v-if="dd.addBtn">
            <el-button type="primary" :icon="CirclePlusFilled" circle size="small" @click="dd.isShowAdd=!dd.isShowAdd"/>
          </div>
        </div>
        <div v-if="dd.addBtn && dd.isShowAdd" style="padding: 16px 0 0 0">
          <el-input v-model="dd.lecturerName" :placeholder="dd.addPlaceholder" style="max-width:200px"></el-input>&nbsp;
          <el-button type="primary" size="small" @click="addBtn(dd)" plain>新增确定</el-button>
        </div>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'radio' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-radio v-for="item in dd.options" :key="item.value" v-model="state.form[dd.key]"
                  :disabled="isReadOnly || dd.disabled" :label="item.value" border>{{ item.label || item.name }}
        </el-radio>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'cascade' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-cascader v-model="state.form[dd.key]" :disabled="isReadOnly || dd.disabled" :options="dd.list"
                     :placeholder="'选择' + dd.label" :props="dd.props || defaultProps" :show-all-levels="false" clearable
                     @change="($event)=>{ cascaderChange($event,dd)}"
        ></el-cascader>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'datePiker' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">

        <el-date-picker v-model="state.form[dd.key]" :disabled="isReadOnly || dd.disabled" :shortcuts="shortcuts"
                        :type="dd.pikerType || 'datetime'" placeholder="选择时间"/>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'richText' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <rich-text-editor style="z-index: 0" ref="richText" v-model:value="state.form[dd.key]"
                          :disabled="isReadOnly || dd.disabled"></rich-text-editor>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'uploadImg' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-upload :disabled="isReadOnly || dd.disabled" :drag="true" :on-success="
          (...event) => {
            handleAvatarSuccess(event, dd, index)
          }
        " :show-file-list="false" action="/public/upload" class="avatar-uploader img-upload">
          <img v-if="state.form[dd.key]" :onerror="tools.imgError(state.form[dd.key])" :src="state.form[dd.key]" alt=""
               style="height: 100%; width: inherit"/>
          <div class="upload-plus">+</div>
          <div class="el-upload__tip">
            {{ dd.placeholder || '只能上传jpg/png文件，且不超过1M' }}{{ state.form[dd.key] }}
          </div>
        </el-upload>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'radioButton' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-radio-group v-model="dd['modelValue']" size="small"
                        @change="($event) => { radioChange($event, 'modelValue') }">
          <el-radio-button v-for="ii of dd.list" :key="ii.label" :label="ii.value">{{ ii.label }}</el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'uploadFile' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-upload ref="uploadFileRef" :file-list="dd.fileList" :limit="dd.limit" class="file-list-style"
                   :on-exceed="($event) => { handleExceed($event, dd) }" :on-remove="removeVideo"
                   :on-success="($event) => { handleFileSuccess($event, dd) }" action="/public/upload">
          <el-button plain type="primary">{{ dd.buttonText || '上传本地视频' }}</el-button>
          <template #tip>
            <div v-if="dd.limit" class="el-upload__tip text-red">
              ⚠️*最多上传{{ dd.limit }}个文件,再次上传文件将被替换*
            </div>
          </template>
        </el-upload>
      </el-form-item>
      <el-form-item
        v-if="dd.type === 'uploadFileMul' && (!dd.if || (dd['ifValue'] && state.form[dd.if] === dd['ifValue']) || (!dd['ifValue'] && state.form[dd.if]))"
        :label="dd.label" :prop="dd.key">
        <el-upload ref="uploadFileRef" :auto-upload="true" :file-list="isReadOnly || dd.fileList" :limit="dd.limit"
                   :on-change="(uploadFile, uploadFiles) => changeFile(uploadFile, uploadFiles, dd)"
                   :on-preview="previewFile"
                   :on-remove="(uploadFile, uploadFiles) => changeFile(uploadFile, uploadFiles, dd)"
                   :on-success="($event) => { handleFileSuccessFn($event, dd) }" action="/public/upload">
          <el-button plain type="primary">{{ dd.buttonText || '上传本地视频' }}</el-button>
          <template #tip>
            <div v-if="dd.limit" class="el-upload__tip text-red">
              ⚠️*最多上传{{ dd.limit }}个文件,再次上传文件将被替换*
            </div>
          </template>
        </el-upload>
      </el-form-item>
    </li>
    <div class="btn" v-if="!isReadOnly">
      <el-button plain type="primary" @click="submit(formRef)">{{ submitText }}
      </el-button>
    </div>
  </el-form>
</template>

<script lang="ts" setup>
import { computed, defineEmits, defineProps, reactive, ref } from 'vue'
import { ElForm } from 'element-plus'
import tools from '@/utils/tool'
import { CirclePlusFilled } from '@element-plus/icons-vue'
import RichTextEditor from '@/viewsManage/components/RichTextEditor.vue'

const props: any = defineProps({
  list: {
    type: Array as any,
    default: () => []
  },
  isEdit: {
    type: Boolean,
    default: false
  },
  isReadOnly: {
    type: Boolean,
    default: false
  },
  submitText: {
    type: String,
    default: '保存'
  }
})

const defaultProps = reactive({
  checkStrictly: true,
  label: 'name',
  value: 'id'
})

const loading = ref(false)

const emit = defineEmits(['submit', 'update', 'addBtn'])

const formRef = ref(ElForm)

const rules = computed(() => {
  const ruleObj: any = {}
  props.list.forEach((res) => {
    if (res.required) {
      ruleObj[res.key] = [
        {
          required: true,
          message: '请输入' + res.label,
          trigger: 'blur'
        }
      ]
    }
  })
  return ruleObj
})

const remoteSelect = async (data, dd) => {
  if (dd.url) {
    let search: any = {}
    if (dd.isInWhere) {
      dd.queryParams.where.name = { _like: '%' + data + '%' }
    } else {
      search[dd.searchKey || 'name'] = '%' + data + '%'
    }
    if (dd.queryParams) {
      search = { ...search, ...dd.queryParams }
    }
    const result = await tools[dd.httpType || 'get'](dd.url, search)
    dd.options = result.list
  }
}

const shortcuts = [
  {
    text: '今天',
    value: new Date()
  },
  {
    text: '昨天',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24)
      return date
    }
  },
  {
    text: '一个星期前',
    value: () => {
      const date = new Date()
      date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
      return date
    }
  }
]

const initData = () => {
  const obj: any = {}
  props.list.forEach((res) => {
    obj[res.key] = !props.isEdit
      ? res.defaultValue
      : (res.value || res.defaultValue)
    if (res.type === 'cascade' && res.url) {
      tools[res.httpType || 'get'](res.url, res.queryParams).then((r) => {
        res.list = r.list
      })
    } else if (res.type === 'select' && res.url) {
      tools[res.httpType || 'get'](res.url, res.queryParams).then((r) => {
        res.options = r.list || r.data
      })
    } else if (res.type === 'remote-select' && res.url) {
      remoteSelect('', res)
    } else if (res.type === 'uploadFile' && !props.isEdit) {
      res.fileList = [] // 非编辑状态，默认附件列表为空
    } else if (res.type === 'uploadFileMul') {
      res.fileList = []
      // 修改的时候
      if (props.isEdit && res.value) {
        res.value.split(',').forEach(item => {
          (res.fileList || []).push({
            path: item,
            name: tools.getFileName(item)
          })
        })
      }
    }
  })
  return obj
}

const state: any = reactive({ form: initData() })

const submit = (formRef) => {
  if (!formRef) return
  formRef.validate((valid: any, fields: any) => {
    if (valid) {
      emit('submit', state.form)
    } else {
      const data: any = Object.values(fields)[0]
      tools.msg(data[0].message, 'warning')
      // 定位到找个位置的输入
    }
  })
}

const addBtn = (val) => {
  emit('addBtn', val)
}

const handleAvatarSuccess = (event, dd, index) => {
  // eslint-disable-next-line vue/no-mutating-props
  props.list[index].cover = URL.createObjectURL(event[1].raw)
  state.form[dd.key] = event[0].data.path
}

const handleFileSuccess = (data, dd) => {
  // (videoList.value as any).push(data.data)
  state.form[dd.key] = data.data.path
}

const uploadFileRef = ref()

const handleExceed = async (files, dd) => {
  // 删除前一个附件，上传当前附件！
  const formData = new FormData()
  formData.append('file', files[0])
  const loading = tools.showLoading('上传中...')
  await tools.post('/public/upload', formData).then((r) => {
    dd.fileList = [r.data]
    state.form[dd.key] = r.data.path
  })
  tools.closeLoading(loading)
}

const handleFileSuccessFn = (data, dd) => {
  console.log(data, dd, 87887)
}

const previewFile = (data) => {
  const imgSrc = data.path || data.response.data.path
  // const src = `${imgSrc}?t=${new Date().getTime()}`
  // var myBlob = new Blob();
  // const href = URL.createObjectURL(myBlob)
  const a = document.createElement('a')
  a.href = imgSrc
  a.download = data.name
  a.click()
  a.remove()
}

const changeFile = (data, dataS, dd) => {
  const arr: any = []
  dataS.forEach(item => {
    if (item.status === 'success') {
      arr.push(item.path || item.response.data.path)
    }
  })
  state.form[dd.key] = arr.join(',')
}

const removeVideo = (files) => {
  console.log('====>>>delete', files)
}

const radioChange = (data, key) => {
  state.form[key] = data
}

const cascaderChange = async (data, dd: any) => {
  if (dd.extraValueKey) {
    const result = tools.findChildByIds(data, dd.list)
    let types = { data: { list: [] } }
    if (state.form[dd.toExtraValueObjName]) {
      types = await tools.post('/api/rest/getTypeByImg', { img: state.form[dd.toExtraValueObjName] })
    }
    console.log('types', types)
    console.log('img', state.form[dd.toExtraValueObjName])
    if (!state.form[dd.toExtraValueObjName] || types.data?.list.length > 0) {
      state.form[dd.toExtraValueObjName] = result[dd.extraValueKey]
    }
  }
}

</script>

<style lang="less">
#form-list {
  .form-input {
    width: 240px;
  }

  .btn {
    margin: 16px;
  }

  .img-upload {
    position: relative;

    .upload-plus {
      padding: 0 8px 8px 8px;
      position: absolute;
      color: #ffffff;
      font-weight: bolder;
      font-size: 42px;
      border: 2px dashed;
      transform: translate(-50%, -50%);
      left: 50%;
      top: 50%;
      border-radius: 4px;
    }
  }
}

.file-list-style {
  a.el-upload-list__item-name {
    white-space: pre-wrap;
  }
}
</style>
