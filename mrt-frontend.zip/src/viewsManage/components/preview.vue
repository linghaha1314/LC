<template>
  <div class="preview" style="padding-top: 28px;display: inline;margin-left: 10px;">
    <el-button
      type="primary"
      size="small"
      @click="previewFn"
    >
      预览
    </el-button>
    <el-dialog
      v-model="previewShow"
      :show-close="true"
      class="info-dialog"
      :destroy-on-close="true"
      width="80%">
      <div v-if="!isTeacher" style="border-bottom: 1px dashed #ccc;padding: 0 40px 36px;">
        <div class="textCnr fs18">{{ previewData.name }}</div>
        <div class="textCnr" style="margin: 14px 0;font-size: 13px">来源：
          {{ `${previewData.source}  ${previewData.author}` }} 时间：{{ tools.formatTime(previewData.time, 'YY-MM-DD') }}
        </div>
        <p class="ind" v-html="previewData.content">
        </p>
        <div v-if="previewData['path']" style="font-size: 12px; margin-top: 30px;">
          <div v-for="item in previewData['path'].split(',')" :key="item">
            附件:
            <a :href="item" target="_blank" style="font-size: 12px"
               :download="item.split('/')[item.split('/').length-1]">
              {{ item && item.split('/')[item.split('/').length - 1] || '无' }}
            </a>
          </div>
        </div>
        <file-view v-if="false" :src="previewData[keyStr]"></file-view>
        <iframe v-if="showPdf(previewData, keyStr)" :src="previewData[keyStr]+'#toolbar=0'" frameborder="0" width="100%"
                height="650px"></iframe>
      </div>
      <div v-else style="position: relative; height: 500px; overflow: auto">
        <el-col :span="24" style="padding: 14px;margin-bottom: 20px;" class="flexC betCtr">
          <div v-if="previewData['photo'] && previewData['photo']!==''"
               style="width: 198px;height: 268px;border: 1px solid #cccccc">
            <img style="width: 198px;height: 268px;vertical-align: middle;"
                 :src="previewData['photo']||'../assets/images/fc1.jpg'" alt="image">
          </div>
          <div class="flex1" style="padding: 18px;line-height: 20px;margin-left: 12px; position: relative">
            <h3 class="fs18" style="font-weight: normal;">{{ previewData.name }}</h3>
            <p class="flexC" style="margin: 14px 0 14px;color: #333333;align-items: center">
          <span>
            {{ previewData['title'] }}
          </span>
              <span style="margin-left: 24px;">
            {{ previewData['hospital'] }}
          </span>
            </p>
            <!--            <p style="color: #9B536F;font-size: 12px; margin-bottom: 20px">-->
            <!--              擅长：贫血、血液系统肿瘤、出血性疾病等常规病例及疑难重症的诊断与治疗-->
            <!--            </p>-->
            <p class="ind bg242" style="line-height: 20px;padding: 10px 12px;margin-bottom: 26px;">
              {{ previewData['content'] }}
            </p>
            <!--            <div style="font-size: 14px;color: #9B536F; position:absolute;top: 10px;right: 10px;">-->
            <!--              分享到:-->
            <!--              <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;"-->
            <!--                   src="../assets/images/u34.png"-->
            <!--                   alt="image">-->
            <!--              <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;"-->
            <!--                   src="../assets/images/u35.png"-->
            <!--                   alt="image">-->
            <!--              <img class="cur" style="width: 22px;height: 22px;vertical-align: middle;margin: 0 6px;"-->
            <!--                   src="../assets/images/u36.png"-->
            <!--                   alt="image">-->
            <!--            </div>-->
          </div>

        </el-col>
        <el-col :span="24" style="padding: 0 40px 36px;">
          <!--      <div class="textCnr fs18">中国人民大学培训学院第十九期医院管理高级研修班第三期课程培训在都江堰开班</div>-->
          <div v-html="previewData['detail']">
          </div>
        </el-col>
        <file-view v-if="false" :src="previewData[keyStr]"></file-view>
        <iframe v-if="showPdf(previewData, keyStr)" :src="previewData[keyStr]+'#toolbar=0'" frameborder="0" width="100%"
                height="650px"></iframe>
      </div>
    </el-dialog>

    <!--    <el-col :span="24" style="padding-top: 22px;font-size: 14px">-->
    <!--      <div style="margin: 8px;"  v-if="nextBefore[0]" @click="dataClick(nextBefore[0])">-->
    <!--        {{(nextBefore.length === 1 && data['sequence'] > nextBefore[0]['sequence']) ? '下一篇:' : '上一篇:'}}-->
    <!--        <span style="margin-left: 8px;" class="cur">-->
    <!--          {{nextBefore[0]['name'] || '无'}}-->
    <!--        </span>-->
    <!--      </div>-->
    <!--      <div style="margin: 8px;" v-if="nextBefore[1]" @click="dataClick(nextBefore[1])">-->
    <!--        下一篇:-->
    <!--        <span style="margin-left: 8px;" class="cur">-->
    <!--          {{nextBefore[1]['name'] || '无'}}-->
    <!--        </span>-->
    <!--      </div>-->
    <!--    </el-col>-->
  </div>
</template>

<script>
import tools from '@/utils/tool'
import { reactive, toRefs } from 'vue'
import FileView from '@/viewsClient/FileView.vue'

export default {
  name: 'preview',
  props: {
    data: {
      type: Object
    },
    dataOk: {
      type: Object
    },
    okData: {
      type: Object
    },
    isTeacher: {
      type: Boolean,
      default: false
    },
    keyStr: {
      type: String
    }
  },
  components: {
    FileView
  },
  setup (props) {
    const state = reactive({
      previewShow: false,
      previewData: {}
    })
    const previewFn = () => {
      state.previewShow = true
      if (props.dataOk) {
        state.previewData = props.dataOk.objectData
      } else if (props.okData) {
        state.previewData = props.okData
      } else {
        const dataOrigin = {}
        props.data.forEach(item => {
          dataOrigin[item.key] = item.value
        })
        state.previewData = dataOrigin
      }
    }
    const showPdf = (data, key) => {
      const file = data[key] ? data[key].split(',') : []
      return file.length === 1 && file[0].search('.pdf') > -1
    }
    return {
      ...toRefs(state),
      previewFn,
      showPdf,
      tools
    }
  }
}
</script>

<style scoped>
.textCnr {
  text-align: center;
}

.fs18 {
  font-size: 18px;
}

.ind {
  text-indent: 2em;
  font-weight: 250;
  font-style: normal;
  font-size: 14px;
  line-height: 37px;
}

.flex1 {
  flex: 1;
}

.flexC {
  display: flex;
  flex-wrap: wrap;
}

.betCtr {
  justify-content: space-between;
  align-items: center;
}

.fs18 {
  font-size: 18px;
}

.bg242 {
  background: rgb(242, 242, 242);
}

.el-overlay {
  z-index: 222222 !important;
}
</style>
