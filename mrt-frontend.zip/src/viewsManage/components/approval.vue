<template>
  <div style="display: inline; margin-left: 10px;">
    <el-dialog
      v-model="isApprovalDialog"
      destroy-on-close>
      <template v-slot:title>
        <div class="flex align-center">
          <strip-title>审批进度查看</strip-title>&nbsp;&nbsp;
        </div>
      </template>
      <el-timeline>
        <el-timeline-item v-for="dd in approvalList" :key="dd.id"
                          placement="bottom"
                          size="large"
                          type="primary">
          {{ dd['roleName'] }}
          <div style="margin-top: 8px">
            <p style="color: #666666;margin-bottom: 8px">
              <span v-if="dd.status===11" class="font-orange font-bold">待审核</span>
              <span v-if="dd.status===1" class="font-green font-bold">通过✅</span>
              <span v-if="dd.status===0" class="font-red font-bold">驳回❌</span>
              <small
                class="padding-start">{{ dd['approvalDate'] }}</small></p>
            <p v-if="dd.remark" style="color: #666666;margin-bottom: 8px">审批意见：{{ dd.remark }}</p>
          </div>
        </el-timeline-item>
      </el-timeline>
      <div style="margin:16px 0" v-if="data.row.status===0">
        <el-button @click="submitApproval(data.row)" type="warning">重新提交审核</el-button>
      </div>
    </el-dialog>
    <el-button
      v-if="data.row.status===-1"
      size="small"
      type="danger"
      @click="submitApproval(data.row)"
    >
      提交审批
    </el-button>
    <el-button
      v-if="data.row.status===11 ||data.row.status===0"
      size="small"
      type="success"
      @click="checkApprovalProcess(data.row)"
    >
      审批进度
    </el-button>
  </div>
</template>

<script>
import { reactive, toRefs } from 'vue'
import tools from '@/utils/tool'
import store from '@/store'

export default {
  name: 'approval',
  props: {
    data: {
      type: Object
    },
    param: {
      type: Object
    },
    typeCode: {
      type: String
    },
    tableName: {
      type: String
    }
  },
  setup: (props, { emit }) => {
    const state = reactive({
      approvalProcessId: null,
      isApprovalDialog: false, // 审批进度查看
      approvalList: []
    })
    // const emit = defineEmits(['update:refresh', 'approval'])
    const getApprovalProcessIdByDictionaryCode = async () => {
      await tools.post('/api/rest/getApprovalProcessIdByTypeCode', {
        assignedRoleId: store.state.manageUserInfo.currentRole.roleId,
        typeCode: props.typeCode
      }).then(r => {
        const list = (r.data.listByAssignedRoleId.length > 0 ? r.data.listByAssignedRoleId : r.data.listByTypeCode) || []
        state.approvalProcessId = list.length > 0 ? list[0].id : null
      }).catch(() => {
        tools.msgError('您无权此操作！')
      })
    }
    const submitApproval = (val) => {
      if (state.approvalProcessId === null) {
        getApprovalProcessIdByDictionaryCode()
      }
      // 做一个下拉选择！
      tools.confirm('温馨提示', '确定提交审批？').then(r => {
        if (!r) {
          return
        }
        // 选对应的审批流程；approvalProcessId
        // 记录当前的审批流程；不做工作流；记录提交人，审批流Id,courseId
        const loading = tools.showLoading('提交中...')
        val.staffId = store.state.manageUserInfo.id
        val.approvalProcessId = state.approvalProcessId
        tools.post('/workflow/createProcess', {
          staffId: store.state.manageUserInfo.id,
          objectId: val.id,
          approvalProcessId: state.approvalProcessId,
          tableName: props.tableName
        }).then(r => {
          if (r.success) {
            tools.msg(r.msg)
            emit('approval', val)
          }
          tools.closeLoading(loading)
        }).catch(() => {
          tools.msgError('您无权此操作！')
        })
      })
    }
    const checkApprovalProcess = (val) => {
      if (state.approvalProcessId === null) {
        getApprovalProcessIdByDictionaryCode()
      }
      state.isApprovalDialog = true
      tools.post('/workflowStart/getStepDetailList', {
        // workflowId: null,
        // approvalProcessId: null
        workflowId: val.workflowId,
        approvalProcessId: val.approvalProcessId
      }).then(r => {
        state.approvalList = r.list
      })
    }
    return {
      ...toRefs(state),
      submitApproval,
      checkApprovalProcess,
      tools
    }
  }
}
</script>

<style scoped>

</style>
