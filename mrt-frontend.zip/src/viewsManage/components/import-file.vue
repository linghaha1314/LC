<template>
  <div style="display: inline-block; margin: 0 12px;">
    <el-button plain size="small" type="success" @click="tools.aDown(modelName, modelFile)">
      模板下载
    </el-button>
    <el-button class="background-btn" plain size="small" type="warning"
               @click="showTable">导入
    </el-button>
  </div>
  <el-dialog
    v-if="showImp"
    v-model="showImp"
    :append-to-body="false"
    :destroy-on-close="false"
    :close-on-click-modal="false"
    class="import-dialog"
    title="数据导入"
    width="80%"
  >
    <div style="height: 60vh;overflow: hidden">
      <el-table :data="tableData" border style="width: 100%;" height="100%">
        <el-table-column v-for="(item,index) in config" :key="item.field" :prop="item.field" :label="item.text"
                         :fixed="index===0">
          <template #header>
            <span style="color: red" v-if="item?.require">*</span>
            {{ item.text }}
          </template>
          <template #default="scope">
            <el-popover
              placement="bottom"
              :width="300"
              trigger="click"
            >
              <template #reference>
                <div style="display: flex; align-items: center" @dblclick="setValue(scope.row, item, scope.$index)">
                  <span v-if="!scope.row[item.field]" style="margin-left: 10px; color: red">空值</span>
                  <span v-else-if="item?.type === 'combo'" style="margin-left: 10px">
                    <span v-if="returnCombo(item, scope.row[item.field], scope.row).search('未设置')>-1"
                          style="color: red">
                      [ {{ scope.row[item.field] }} ]值未设置
                    </span>
                    <span v-else>{{ returnCombo(item, scope.row[item.field], scope.row) }}</span>
                  </span>
                  <span style="margin-left: 10px">{{ scope.row[item.field] }}</span>
                </div>
              </template>
              <el-input v-if="item?.type === 'string'" v-model="scope.row[item.field]" placeholder="请输入"
                        clearable/>
              <el-select v-else-if="item?.type === 'combo'" v-model="scope.row[item.field]" placeholder="请选择"
                         size="large">
                <el-option
                  v-for="ite in item.list"
                  :key="ite.id"
                  :label="ite.name"
                  :value="ite[item.valueKey]"
                />
              </el-select>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <template #footer>
      <div style="text-align: right">
        <el-button plain size="small" type="success" @click="okFn">
          确认导入
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script>
import { ElLoading } from 'element-plus'
import { onBeforeMount, reactive, toRefs } from 'vue'
import tools from '@/utils/tool'

export default {
  name: 'import-file',
  props: {
    modelName: String,
    modelFile: String,
    tableName: String,
    config: Object,
    changeData: {
      type: Function,
      default: (data) => ({
        list: data,
        uniqueKey: 'code'
      })
    },
    refresh: {
      type: Boolean,
      default: false
    }
  },
  emits: ['upload', 'update:refresh'],
  setup: (props, ctx) => {
    const state = reactive({
      showImp: false,
      showInput: false,
      input: '',
      inputOrn: null,
      tableData: [],
      mistake: 0
    })

    const showTable = async () => {
      const arr = {}
      props.config.forEach(item => {
        arr[item.text] = item.field
      })
      const tableData = await tools.importData(arr)
      state.showImp = true
      state.tableData = tableData
    }

    const returnCombo = (data, target) => {
      let str = '该值未设置'
      data.list.forEach(item => {
        if (item.name === target) {
          str = target
        }
      })
      return str
    }

    const setValue = (target) => {
      target.showInput = true
    }

    const okFn = async () => {
      const data = [...state.tableData]
      props.config.forEach(item => {
        if (item.require) {
          data.forEach(ite => {
            if (!ite[item.field]) {
              tools.msgError(`有[${item.text}]信息未填! 请检查`)
              throw new Error(`有[${item.text}]信息未填! 请检查`)
            }
          })
        }
        if (item.noRepeat) {
          const arr = []
          data.forEach(ite => {
            arr.push(ite[item.field])
          })
          if (arr.length !== [...new Set(arr)].length) {
            tools.msgError(`有[${item.text}]信息重复! 请检查`)
            throw new Error(`有[${item.text}]信息重复! 请检查`)
          }
        }
        if (item.type === 'combo') {
          data.forEach(ite => {
            ite[item.field] = item.nameMap[ite[item.field]]
          })
        }
      })
      // 检查数据是否有重复，是否有错误！
      if (props.tableName) {
        const loading = ElLoading.service({
          lock: true,
          text: '正在导入'
        })
        const url = `/${props.tableName}/import`
        tools.post(url, await props.changeData(data)).then((r) => {
          loading.close()
          tools.msg(r.msg)
          state.showImp = false
          ctx.emit('update:refresh', true)
        }).catch(() => {
          tools.msgError('重名数据未添加!')
          loading.close()
          state.showImp = false
        })
      } else {
        ctx.emit('upload', data)
      }
    }

    onBeforeMount(() => {
      props.config.forEach(item => {
        if (item?.type === 'combo' && !item?.list) {
          tools.get(item?.url).then(res => {
            item.list = res.list
            const nameMap = {}
            res.list.forEach(item => {
              nameMap[item.name] = item.id
            })
            item.nameMap = nameMap
          })
        }
      })
    })

    return {
      ...toRefs(state),
      showTable,
      returnCombo,
      setValue,
      okFn,
      tools
    }
  }
}
</script>

<style scoped>
.import-dialog {
  padding: 10px;
}
</style>
