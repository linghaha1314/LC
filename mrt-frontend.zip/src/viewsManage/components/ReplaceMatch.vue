<template>
  <p v-for="(item,index) of arr" :key="index">
    <el-tag class="ml-2" type="info">{{ item[defineProps.label] }}</el-tag>
  </p>
</template>

<script lang="ts" setup>
import { computed, defineProps } from 'vue'

const props = defineProps({
  list: {
    type: Array,
    default: () => {
      return []
    }
  },
  data: {
    type: [Array, String]
  },
  defineProps: {
    type: Object,
    default: () => {
      return {
        label: 'name',
        value: 'id'
      }
    }
  }
})
const arr = computed(() => {
  const result: any = []
  const dataArr: any[] = props.data ? (typeof props.data === 'string' ? [props.data] : props.data) : []
  if (props.list.length === 0) return
  dataArr.forEach(res => {
    props.list.forEach((rr: any) => {
      if (res === rr[props.defineProps.value]) {
        result.push(rr)
      }
    })
  })
  return result
})
</script>
