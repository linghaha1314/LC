<template>
  <div>
    <!-- 列表数据 -->
    <el-table v-loading="loading" :data="tableData" :default-expand-all="false"
              :tree-props="{ children: 'children', hasChildren: 'childNum' }" row-key="id"
              @selection-change="selectionChange"
              style="width: 100%">
      <template v-for="dd in tableColumns" :key="dd.valueKey">
        <el-table-column v-if="dd.type === 'selection'" :width="dd.width || 55" type="selection"></el-table-column>
        <el-table-column v-else-if="dd.type === 'time'" :label="dd.label" :width="dd.width || 220">
          <template v-slot="scope">
            {{ proxy.$tools.formatTime(scope.row[dd.valueKey], 'YY-MM-DD hh:mm:ss') }}
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.type === 'avatar'" :label="dd.label" :width="dd.width || 220">
          <template v-slot="scope">
            <img :onerror="$tools.imgError(scope.row['avatar'])"
                 :src="scope.row['avatar'] || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
                 style="width: 60px;height: 60px;border-radius: 50%;object-fit: cover"/>
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.type === 'img'" :label="dd.label" :width="dd.width || 220">
          <template v-slot="scope">
            <img :onerror="tools.imgError(scope.row[dd.valueKey])" :src="scope.row[dd.valueKey]" style="height:32px"/>
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.type==='stringList'" :label="dd.label" width="180">
          <template v-slot="scope">
            <span v-for="(ii,index) in dd.list" :key="ii">{{ ii }}<span
              v-if="index!==dd.list.length-1">,</span></span>
          </template>
        </el-table-column>
        <el-table-column v-else-if="!refresh && dd.list" :label="dd.label" width="180">
          <template v-slot="scope">
            <replace-match :data="scope.row[dd.valueKey]" :defineProps="dd.defineProps" :list="dd.list">
            </replace-match>
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.isEllipsis" :label="dd.label" :width="dd.width" sortable>
          <template v-slot="scope">
            <!--           鼠标一上去就要显示一个详情的弹窗 -->
            <div class="ellipsis" v-html="scope.row[dd.valueKey]"></div>
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.type === 'sequence'" :label="dd.label" :width="dd.width" sortable>
          <template v-slot="scope">
            <div v-if="scope.row.parentId">
              {{ scope.row.sequence }}-{{ scope.row.sequence }}
            </div>
            <div v-else>
              {{ scope.row.sequence }}
            </div>
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.type === 'slot'" :label="dd.label" :width="dd.width" sortable>
          <template v-slot="scope">
            <slot :name="dd.valueKey" :row="scope.row"></slot>
          </template>
        </el-table-column>
        <el-table-column v-else-if="dd.valueKey === 'status'" :label="dd.label" :width="dd.width || 220">
          <template v-slot="scope">
            <div>
              {{ dd.flag === true ? dd.statusLabel[scope.row[dd.valueKey]] : scope.row[dd.valueKey] }}
            </div>
          </template>
        </el-table-column>
        <el-table-column v-else-if="!dd.list" :label="dd.label" :prop="dd.valueKey" :width="dd.width" sortable>
        </el-table-column>
      </template>
      <el-table-column v-if="!noOpera && !operaFixed" label="操作" prop="opera">
        <template v-slot="scope">
          <slot :row="scope.row"></slot>
        </template>
      </el-table-column>
      <el-table-column v-if="!noOpera && operaFixed" :fixed="operaFixed" label="操作" prop="opera" :width="operaWidth">
        <template v-slot="scope">
          <slot :row="scope.row"></slot>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <!-- 分页 -->
  <div v-if="total > 0 && isShowPage" class="page-box">
    <el-pagination :current-page="currentPage" :page-size="queryParams.limit"
                   :page-sizes="[10, 20, 50, 100]"
                   :total="total" background layout="total,sizes,prev, pager, next,jumper"
                   @size-change="handleSizeChange"
                   @current-change="currentChange"></el-pagination>
  </div>

</template>

<script lang="ts">
import { computed, defineComponent, getCurrentInstance, onMounted, reactive, ref, toRefs, watch } from 'vue'
import tools from '@/utils/tool'
import ReplaceMatch from '@/viewsManage/components/ReplaceMatch.vue'

export default defineComponent({
  components: {
    ReplaceMatch
  },

  props: {
    operaWidth: {
      type: String,
      default: '120px'
    },
    operaFixed: {
      type: [String, Boolean],
      default: false
    },
    columns: {
      type: Array as any,
      default: () => {
        return []
      }
    },
    tableType: {
      type: String,
      default: () => {
        return 'default'
      }
    },
    selection: {
      type: Array,
      default: () => {
        return []
      }
    },
    list: {
      type: Array,
      default: () => {
        return []
      }
    },
    refresh: {
      type: Boolean,
      default: () => {
        return false
      }
    },
    url: {
      type: String,
      default: ''
    },
    isLimit: {
      type: Boolean,
      default: true
    },
    limit: {
      type: Number,
      default: tools.limit
    },
    httpType: {
      type: String,
      default: 'get'
    },
    noOpera: {
      type: Boolean,
      default: false
    },
    isShowPage: {
      type: Boolean,
      default: true
    },
    queryData: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },

  emits: ['update:selection', 'update:refresh', 'update:list'],

  setup: (props, { emit }) => {
    const tableColumns = computed(() => {
      const list: any = []
      props.columns.forEach((column: any) => {
        if (!column.isHide) {
          list.push(column)
        }
      })
      return list
    })

    const { proxy }: any = getCurrentInstance()

    const loading = ref(true)

    const state = reactive({
      queryParams: {
        limit: props.limit,
        offset: 0
      },
      currentPage: 1,
      total: 0,
      tableName: props.url.replace(/([^/])*$/, '').replace(/\//g, ''),
      tableData: [] as any[]
    })

    const handleSizeChange = (val) => {
      state.queryParams.limit = val
      getList()
    }

    const currentChange = (val) => {
      state.queryParams.offset = state.queryParams.limit * (val - 1)
      state.currentPage = val
      getList()
    }

    const getList = () => {
      loading.value = true
      if (!props.url) {
        state.tableData = props.list
        setTimeout(() => {
          loading.value = false
        })
        return
      }
      tools[props.httpType](props.url, props.isLimit ? { ...state.queryParams, ...props.queryData } : props.queryData).then(r => {
        loading.value = false
        state.tableData = r.list
        state.total = r.total
        emit('update:refresh', false)
        emit('update:list', r.list)
      })
    }

    const selectionChange = (val) => {
      emit('update:selection', val)
    }

    onMounted(() => {
      getList()
    })

    watch(
      () => props.refresh,
      (newVal) => {
        if (newVal) {
          // state.queryParams.offset = 0
          // state.currentPage = 1
          getList()
        }
      }
    )

    return {
      proxy,
      tools,
      loading,
      tableColumns,
      selectionChange,
      handleSizeChange,
      currentChange,
      ...toRefs(state)
    }
  }
})
</script>

<style lang="less" scoped>
@import (once) "~@/assets/css/commen.less";

/deep/ .el-table__cell {
  &:last-child {
    .cell {
      button {
        margin-right: 4px;
        margin-bottom: 4px;
      }
    }
  }
}

// style="width:100%;display:grid;grid-row-gap: 20px;"
// .ellipsis {
//   .ellipsis-num(3)
// }

///deep/ .el-table{overflow: unset}
// /deep/ .el-table__body-wrapper {
//   overflow: unset
// }

// /deep/ .el-table .cell {
//   overflow: unset
// }
</style>
