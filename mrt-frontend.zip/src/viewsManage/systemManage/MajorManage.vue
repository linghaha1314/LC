<template>
  <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
    <template v-slot:left-btn>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="primary"
        @click="tools.openDrawer(pageParams)"
      >新增
      </el-button>
      <el-button plain size="small" type="success" @click="tools.aDown('专业添加模板.xlsx','./xlsx/专业添加模板.xlsx')">
        模板下载
      </el-button>
      <el-button plain size="small" type="danger" @click="tools.delMultiple('major',selection,pageParams)">删除
      </el-button>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="warning"
        @click="tools.upload('import',defineProps,'major',pageParams,majors)"
      >导入
      </el-button>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="primary"
        @click="tools.writeFile(list,defineProps)"
      >导出
      </el-button>
    </template>
  </search-class>

  <table-list v-model:list="list" v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns" :query-data="searchInfo"
              url="/major/getListByPage">
    <template v-slot="scope">
      <el-button size="small" type="primary" @click="tools.openDrawer(pageParams,true,formList,scope.row)"
      >查看/修改
      </el-button>
      <el-button
        size="small"
        type="danger"
        @click="tools.deleteById('major', scope.row.id,pageParams)"
      >删除
      </el-button>
    </template>
  </table-list>

  <el-drawer
    v-model="pageParams.isDrawer"
    :append-to-body="false"
    direction="rtl"
    :destroy-on-close="true"
    title="科室信息设置"
    width="30%"
  >
    <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
  </el-drawer>
</template>
<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      majors: {},
      list: [],
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      defineProps: {
        // 父级专业: 'parentId',
        专业名称: 'name',
        // 专业代码: 'code',
        // 专业类型: 'type',
        描述: 'remark'
      }, // 上传模板字段
      searchInfo: {
        name: ''
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '专业',
          width: 120
        },
        {
          valueKey: 'remark',
          width: 120,
          label: '描述',
          // 匹配数据
          list: []
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '专业',
        key: 'name',
        width: '',
        value: null,
        required: true,
        defaultValue: '',
        change: (data) => {
          tools.validationRepeat(data, '专业', 'name', 'major')
        }
      }, {
        type: 'input',
        label: '备注',
        key: 'remark',
        width: '',
        value: '',
        defaultValue: null
      }]
    })
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/major/updateById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/major/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      }).catch(() => {
        tools.msgError('专业名重复!')
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.name = searchInfo.name.substring(1, searchInfo.name.length - 1)
    }
    return {
      ...toRefs(state),
      submit,
      search,
      tools
    }
  }
})
</script>
