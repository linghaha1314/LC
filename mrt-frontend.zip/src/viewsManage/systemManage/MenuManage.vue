<template>
  <div class="menu-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="addNew"
        >新增
        </el-button>
<!--        <el-button-->
<!--          class="background-btn"-->
<!--          plain-->
<!--          size="small"-->
<!--          type="warning"-->
<!--          @click="$tools.upload('import',{姓名:'name',帐号:'username'},'user')"-->
<!--        >导入-->
<!--        </el-button>-->
<!--        <el-button-->
<!--          class="background-btn"-->
<!--          plain-->
<!--          size="small"-->
<!--          type="primary"-->
<!--          @click="$tools.writeFile([{姓名:'张三',帐号:'123'}])"-->
<!--        >导出-->
<!--        </el-button>-->
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
                :isLimit="false"
                url="/menu/list">
      <template v-slot="scope">
        <el-button size="small" type="primary" @click="edit(scope.row)"
        >编辑
        </el-button>
        <el-button
          size="small"
          type="danger"
          @click="deleteMenuById(scope.row)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑菜单 -->
    <el-drawer
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="40%"
      title="菜单详情">
      <el-scrollbar>
        <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
      </el-scrollbar>
    </el-drawer>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import store from '@/store'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  components: {
    SearchClass,
    TableList,
    FormList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        refresh: false,
        isEdit: false,
        isDrawer: false
      },
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'name',
          label: '名称',
          width: 180
        },
        {
          valueKey: 'icon',
          label: '图标',
          width: 180
        },
        {
          valueKey: 'code',
          label: '编码',
          width: 160
        }, {
          valueKey: 'path',
          width: 160,
          label: '路径'
        }, {
          valueKey: 'mobile',
          width: 120,
          label: '状态'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // }
      ], // 筛选条件项
      formList: [
        {
          label: '名称',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '名称',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '编码',
          key: 'code',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'input',
          label: '路径',
          key: 'path',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        }, {
          type: 'input',
          label: '图标',
          key: 'icon',
          width: '',
          value: '',
          defaultValue: null
        },
        {
          type: 'cascade',
          label: '父级菜单',
          key: 'parentId',
          url: '/menu/list',
          list: [],
          width: '',
          value: '',
          queryParams: {
            limit: 99
          },
          props: {
            checkStrictly: true,
            label: 'name',
            value: 'id'
          },
          typeList: [],
          defaultValue: ''
        },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          defaultValue: null
        }, {
          type: 'switch',
          label: '状态',
          placeholder: '请输入图标code',
          key: 'status',
          width: '',
          value: '',
          defaultValue: 1
        }]
    })

    const exportFile = () => {
      tools.post('/attachs/toJson', {
        status: 1
      }).then(res => {
        console.log(res)
      })
    }

    const deleteMenuById = (data) => {
      tools.deleteById('menus', data.id, state.pageParams).then(r => {
        store.dispatch('getMenus')
      })
    }

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        icon: data.icon,
        code: data.code,
        parentId: data.parentId ? (typeof data.parentId === 'string' ? data.parentId : data.parentId[0]) : null,
        status: data.status,
        sequence: data.sequence,
        path: data.path
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/menus/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
            store.dispatch('getMenus')
          }
        })
        return
      }
      tools.post('/menus/create', obj).then(res => {
        if (res.success) {
          state.pageParams.isDrawer = false
          tools.msg(res.msg)
          state.pageParams.refresh = true
          store.dispatch('getMenus')
        }
      })
    }

    const search = (searchInfo) => {
      // console.log(searchInfo)
    }

    const addNew = () => {
      state.pageParams.isDrawer = true
      state.pageParams.isEdit = false
    }

    const edit = (val) => {
      state.pageParams.isDrawer = true
      state.pageParams.isEdit = true
      state.formList.forEach(res => {
        res.value = val[res.key]
      })
    }

    const del = (val) => {
      // tools.deleteById('menus', val.id, {}).then(() => {
      //   state.refresh = true
      // })
    }

    return {
      ...toRefs(state),
      addNew,
      deleteMenuById,
      exportFile,
      del,
      edit,
      submit,
      search
    }
  }
})
</script>
<style lang="less" scoped>
</style>
