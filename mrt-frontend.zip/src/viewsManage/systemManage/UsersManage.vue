<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" placeholder="输入姓名或帐号搜索" :isShowPage="false"
                  :searchInit="searchInit" @search="search" v-model:tableColumns="tableColumns"
                  :is-show-export-btn="true" @exportAll="exportFn">
      <template v-slot:left-btn>
        <el-button class="background-btn" plain size="small" type="primary" @click="$tools.openDrawer(pageParams)">新增用户
        </el-button>
        <import-file model-file="./xlsx/人员数据信息模板.xlsx" model-name="人员数据信息模板.xlsx" :config="definePropsArr"
                     :changeData="changeData" table-name="user" v-model:refresh="pageParams.refresh"></import-file>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="exportFn"
        >全部导出
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:list="list" v-model:refresh="pageParams.refresh" v-model:selection="selection"
                v-model:columns="tableColumns" httpType="post" :queryData="searchInfo" url="/user/getUserListByPage">
      <template v-slot="scope">
        <el-button size="small" type="primary" @click="$tools.openDrawer(pageParams, true, formList, scope.row)">查看/修改
        </el-button>
        <el-button size="small" type="warning" @click="setRole(scope.row)">角色
        </el-button>
        <!--        v-if="tools.isApply(roles)"-->
        <el-button size="small" type="info" @click="resetPass(scope.row)">重置密码
        </el-button>
        <el-button v-if="scope.row.locked" size="small" type="warning" @click="unLocked(scope.row)">解锁
        </el-button>
        <el-button size="small" type="danger"
                   @click="tools.deleteById('user', scope.row.id, pageParams, 'id', '/user/deleteUserById')">删除
        </el-button>
      </template>
    </table-list>

    <!-- 角色设置弹窗 -->
    <el-dialog v-if="isSetRole" v-model="isSetRole" :append-to-body="false" :destroy-on-close="true" title="角色设置"
               width="30%">
      <form-list :isEdit="true" :list="roleList" @submit="roleSubmit">
        <template v-slot:title>
          <strip-title class="margin-bottom">基本</strip-title>
        </template>
      </form-list>
    </el-dialog>

    <!-- 用户详细信息 -->
    <el-drawer v-else v-model="pageParams.isDrawer" :append-to-body="false" :destroy-on-close="true" direction="rtl"
               size="40%" title="用户详细信息">
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit">
        <template v-slot:title>
          <strip-title class="margin-bottom">基本</strip-title>
        </template>
      </form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted, reactive, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import StripTitle from '@/components/StripTitle.vue'
import { ElMessage } from 'element-plus'
import store from '@/store'
import CryptoJS from 'crypto-js'
import ImportFile from '@/viewsManage/components/import-file.vue'

export default defineComponent({
  name: '',
  components: {
    ImportFile,
    StripTitle,
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const getRoles = async () => {
      const result = await tools.get('/roles/getListByPage', { limit: 1000 })
      state.tableColumns[5].list = result.list
    }

    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      isSetRole: false,
      definePropsArr: [
        {
          field: 'name',
          text: '姓名',
          require: true
        }, {
          field: 'jobNum',
          text: '工号',
          require: true
        }, {
          field: 'username',
          text: '账号',
          require: true
        }, {
          field: 'sex',
          text: '性别'
        }, {
          field: 'education',
          text: '学历'
        }, {
          field: 'positionTitle',
          text: '医生职称'
        }, {
          field: 'post',
          text: '岗位'
        }, {
          field: 'duties',
          text: '职位'
        }, {
          field: 'sectionId',
          text: '所属科室'
        }, {
          field: 'majorId',
          text: '所属专业'
        }, {
          field: 'hospital',
          text: '院区'
        }, {
          field: 'mobile',
          text: '手机号码'
        }, {
          field: 'email',
          text: '邮箱'
        }, {
          field: 'personnelType',
          text: '人员类型'
        }, {
          field: 'department',
          text: '所属部门'
        }
      ],
      defineProps: {
        姓名: 'name',
        性别: 'sex',
        账号: 'username',
        工号: 'jobNum',
        学历: 'education',
        人员类型: 'personnelType',
        所属部门: 'department',
        所属科室: 'sectionId',
        所属专业: 'majorId',
        岗位: 'post',
        职务: 'duties',
        院区: 'hospital',
        医生职称: 'positionTitle',
        手机号码: 'mobile',
        邮箱: 'email'
      },
      list: [],
      searchInfo: {
        where: {
          name: {
            _like: '%%'
          }
        }
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'avatar',
          label: '头像',
          type: 'avatar',
          width: 100
        },
        {
          valueKey: 'name',
          label: '姓名',
          width: 120
        },
        {
          valueKey: 'sectionName',
          label: '科室',
          width: 120
        },
        {
          valueKey: 'username',
          label: '帐号',
          width: 120
        }, {
          valueKey: 'roles',
          width: 120,
          label: '角色',
          list: []
        }, {
          valueKey: 'mobile',
          width: 120,
          label: '手机号'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [{
        name: 'isSelect',
        desc: '角色',
        searchKey: 'name',
        placeholder: '选择角色',
        value: 'role_id',
        url: '/roles/getListByPage',
        queryParams: { limit: 1000 }
      }, {
        name: 'isSelect',
        desc: '科室',
        url: '/section/getListByPage',
        placeholder: '选择科室',
        value: 'section_id'
      }], // 筛选条件项
      formList: [
        {
          type: 'slot',
          name: 'title'
        },
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '账号',
          key: 'username',
          width: '',
          value: null,
          required: true,
          defaultValue: '',
          change: (data) => {
            tools.validationRepeat(data, '账号', 'username', 'user')
          }
        },
        {
          type: 'input',
          label: '姓名',
          key: 'name',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'number',
          label: '工号',
          key: 'jobNum',
          width: '',
          value: null,
          defaultValue: '',
          change: (data) => {
            tools.validationRepeat(data, '工号', 'jobNum', 'user')
          },
          required: true
        },
        {
          type: 'select',
          label: '所属专业',
          key: 'majorId',
          width: '',
          url: '/major/getList',
          searchKey: 'search',
          value: null,
          defaultValue: null
        },
        {
          type: 'remote-select',
          url: '/section/getListByPage',
          label: '科室',
          key: 'sectionId',
          width: '',
          value: null,
          options: [],
          defaultValue: null
        },
        // {
        //   type: 'select',
        //   label: '专业',
        //   key: 'majorId',
        //   url: '/major/getListByPage',
        //   width: '',
        //   value: null,
        //   defaultValue: null
        // },
        {
          type: 'input',
          label: '手机号码',
          key: 'mobile',
          width: '',
          value: '',
          defaultValue: null
        },
        {
          type: 'select',
          label: '性别',
          key: 'sex',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'sex'
          },
          optionsValue: 'name',
          httpType: 'post',
          required: true,
          defaultValue: []
        },
        {
          type: 'input',
          label: '学历',
          key: 'education',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'select',
          label: '人员类别',
          key: 'personnelType',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'staffType'
          },
          optionsValue: 'name',
          httpType: 'post',
          required: true,
          defaultValue: []
        },
        {
          type: 'input',
          label: '所属部门',
          key: 'department',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '岗位',
          key: 'post',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '职务',
          key: 'duties',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '院区',
          key: 'hospital',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'select',
          label: '职称',
          key: 'positionTitle',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'positionName'
          },
          optionsValue: 'name',
          httpType: 'post',
          defaultValue: []
        },
        {
          type: 'input',
          label: '邮箱',
          key: 'email',
          width: '',
          value: null,
          defaultValue: ''
        }
        // {
        //   type: 'select',
        //   multiple: true,
        //   label: '角色',
        //   key: 'roles',
        //   width: '',
        //   url: '/roles/getListByPage',
        //   value: null,
        //   defaultValue: '',
        //   required: true
        // },
        // {
        //   type: 'input',
        //   label: '机构',
        //   key: 'organizationName',
        //   width: '',
        //   value: null,
        //   defaultValue: ''
        // },
        // {
        //   type: 'select',
        //   label: '专业',
        //   key: 'majorId',
        //   url: '/major/getListByPage',
        //   width: '',
        //   value: null,
        //   defaultValue: null
        // }
      ],
      roleList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'select',
          multiple: true,
          label: '角色',
          key: 'roles',
          width: '',
          url: '/roles/getListByPage',
          value: null,
          queryParams: {
            limit: 10000
          },
          defaultValue: '',
          required: true
        }
      ],
      // roles: [
      //   'superadmin',
      //   'supermanage',
      //   'ColumnAdministrator',
      //   'PlatformAdministrator'
      // ],
      currentRow: {
        username: ''
      },
      sections: {},
      majors: {},
      sectionsIds: {},
      majorsIds: {},
      rules: [
        {
          title: 'sectionId',
          arr: []
        },
        {
          title: 'majorId',
          arr: []
        }
      ]
    })

    const resetPass = (val) => {
      tools.confirm('温馨提示:', '确认重置密码为: zzrm1111 吗?').then((res) => {
        if (res) {
          tools.post('/user/resetPass', { id: val.id }).then((res) => {
            if (res.success) {
              tools.msg(res.msg)
            }
          })
        } else {
          return false
        }
      })
      // let flag = false
      // val.roleList.forEach(res => {
      //   if (res.roleCode === 'superadmin') {
      //     flag = true
      //   }
      // })
      // if (flag) {
      //   tools.msgError('不能重置超级管理员的密码')
      //   return
      // }
      // 不能重置超级管理员的密码;应该是可以重置自己的密码
    }

    const unLocked = (val) => {
      const loading = tools.showLoading('解锁中...')
      tools.post('/user/updateById', {
        errorNum: 5,
        locked: false,
        id: val.id
      }).then((res) => {
        tools.closeLoading(loading)
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.refresh = true
        }
      })
    }

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/user/updateUserById', data).then(res => {
          if (res.success) {
            ElMessage({
              message: res.msg,
              type: 'success',
              duration: 2 * 1000,
              onClose: () => {
                state.pageParams.isDrawer = false
                state.pageParams.refresh = true
              }
            })
          }
        })
        return
      }
      delete data.id
      data.password = CryptoJS.AES.encrypt('zzrm1111', 'kb12315').toString()
      tools.post('/user/createUser', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const roleSubmit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const loading = tools.showLoading('提交中...')
      tools.post('/userRole/createUpdate', data).then(res => {
        tools.closeLoading(loading)
        if (res.success) {
          state.isSetRole = false
          state.pageParams.refresh = true
          store.dispatch('getManageUserInfo', { id: store.state.manageUserInfo.id }).then()
        }
      })
    }

    const setRole = (val) => {
      state.roleList.forEach((res) => {
        res.value = val[res.key]
      })
      state.isSetRole = true
    }

    onMounted(() => {
      getRoles()
    })

    const search = (searchInfo) => {
      const data: any = { where: {} }
      for (const [key, value] of Object.entries(searchInfo)) {
        let obj: any = {}
        obj = key === 'name' ? { _like: value } : { _eq: value }
        if (value) {
          if (key === 'name') {
            data.where[/^[0-9]*$/.test((value as string).replace(/%/g, '')) ? 'username' : 'name'] = obj
          } else if (key === 'role_id') {
            data.where.roles = { [key]: { ...obj } }
          } else {
            data.where[key] = obj
          }
        }
      }
      state.searchInfo = data
    }

    const getSection = () => {
      tools.get('/section/getListByPage', {
        limit: 999
      }).then(res => {
        const arr = []
        tools.childNo(res.list, arr)
        arr.forEach((s: any) => {
          state.sections[s.name] = s.id
          state.sectionsIds[s.id] = s.name
        })
      })
    }

    const getMajor = () => {
      tools.get('/major/getListByPage', {
        limit: 999
      }).then(res => {
        const arr = []
        tools.childNo(res.list, arr)
        arr.forEach((s: any) => {
          state.majors[s.name] = s.id
          state.majorsIds[s.id] = s.name
        })
      })
    }

    const exportFn = () => {
      tools.get('/user/getList').then(res => {
        const list = res.list
        const arr: any = [...list]
        arr.forEach(item => {
          item.sectionId = state.sectionsIds[item.sectionId]
          item.majorId = state.majorsIds[item.majorId]
        })
        tools.writeFile(arr, state.defineProps)
      })
    }

    const changeData = async (data) => {
      const majorObj: any = (await tools.getValueObjByHttp('/major/getList')).obj
      const sectionObj: any = (await tools.getValueObjByHttp('/section/getList')).obj
      data.forEach(res => {
        res.majorId = majorObj[res.majorId] || null
        res.sectionId = sectionObj[res.sectionId] || null
      })
      return {
        list: data,
        uniqueKey: 'username'
      }
    }

    getMajor()

    getSection()

    return {
      tools,
      ...toRefs(state),
      roleSubmit,
      resetPass,
      getRoles,
      unLocked,
      changeData,
      submit,
      search,
      setRole,
      exportFn
    }
  }
})
</script>
