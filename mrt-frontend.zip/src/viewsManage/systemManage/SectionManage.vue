<template>
  <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
    <template v-slot:left-btn>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="primary"
        @click="tools.openDrawer(pageParams)"
      >新增
      </el-button>
      <el-button plain size="small" type="danger" @click="tools.delMultiple('section',selection,pageParams)">删除
      </el-button>
      <import-file model-file="./xlsx/科室添加模板.xlsx" model-name="科室添加模板.xlsx" :config="definePropsArr"
                   :change-data="changeData" table-name="section" v-model:refresh="pageParams.refresh"></import-file>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="primary"
        @click="tools.writeFile(list,defineProps)"
      >导出
      </el-button>
    </template>
  </search-class>

  <table-list v-model:list="list" v-model:refresh="pageParams.refresh" v-model:selection="selection"
              :columns="tableColumns" :query-data="searchInfo"
              url="/section/getListByPage">
    <template v-slot="scope">
      <el-button size="small" type="primary" @click="tools.openDrawer(pageParams,true,formList,scope.row)"
      >查看/修改
      </el-button>
      <el-button
        size="small"
        type="danger"
        @click="tools.deleteById('section', scope.row.id,pageParams)"
      >删除
      </el-button>
    </template>
  </table-list>

  <el-dialog
    v-model="pageParams.isDrawer"
    :append-to-body="false"
    :destroy-on-close="true"
    direction="rtl"
    height="auto"
    title="科室信息设置"
    width="30%"
  >
    <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import ImportFile from '@/viewsManage/components/import-file.vue'

export default defineComponent({
  name: '',
  components: {
    ImportFile,
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      sections: {},
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      definePropsArr: [{
        field: 'parentId',
        text: '父级科室'
      }, {
        field: 'name',
        text: '科室名称',
        require: true
      }, {
        field: 'code',
        text: '科室代码',
        require: true
      }, {
        field: 'describe',
        text: '描述'
      }],
      defineProps: {
        父级科室: 'parentId',
        科室名称: 'name',
        科室代码: 'code',
        科室类型: 'type',
        描述: 'describe'
      }, // 上传模板字段
      list: [],
      searchInfo: {
        name: ''
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '科室'
        },
        {
          valueKey: 'code',
          label: '科室代码'
        },
        {
          valueKey: 'type',
          label: '科室类型'
        },
        {
          valueKey: 'describe',
          label: '描述'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [], // 筛选条件项
      formList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '科室名字',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: '',
          change: (data) => {
            tools.validationRepeat(data, '名字', 'name', 'section')
          }
        },
        {
          type: 'select',
          label: '科室类型',
          key: 'type',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'Section-type'
          },
          optionsValue: 'name',
          httpType: 'post',
          defaultValue: []
        },
        {
          type: 'input',
          label: '科室代码',
          key: 'code',
          width: '',
          value: '',
          defaultValue: null,
          required: true,
          change: (data) => {
            tools.validationRepeat(data, '代码', 'code', 'section')
          }
        },
        {
          type: 'cascade',
          label: '父级科室',
          key: 'parentId',
          url: '/section/getListByPage',
          list: [],
          width: '',
          value: '',
          queryParams: {
            limit: 999
          },
          props: {
            checkStrictly: true,
            label: 'name',
            value: 'id'
          },
          typeList: [],
          defaultValue: ''
        },
        // {
        //   type: 'input',
        //   label: '颜色',
        //   key: 'describe',
        //   width: '',
        //   value: '',
        //   defaultValue: null
        // },
        // {
        //   type: 'number',
        //   label: '科室容量',
        //   key: 'capacity',
        //   width: '',
        //   value: '',
        //   defaultValue: null
        // },
        {
          type: 'input',
          label: '描述',
          key: 'describe',
          width: '',
          value: '',
          defaultValue: null
        }
      ]
    })
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.parentId = data.parentId ? (typeof data.parentId === 'string' ? data.parentId : data.parentId[data.parentId.length - 1]) : null
      if (state.pageParams.isEdit) {
        tools.post('/section/updateById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/section/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      }).catch(() => {
        tools.msgError('科室名或者科室代码重复!')
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.name = (searchInfo.name && searchInfo.name.substring(1, searchInfo.name.length - 1)) || ''
    }
    const getSection = () => {
      tools.get('/section/getListByPage', {
        limit: 999
      }).then(res => {
        const arr = []
        tools.childNo(res.list, arr)
        arr.forEach((s: any) => {
          state.sections[s.name] = s.id
        })
      })
    }
    getSection()
    const changeData = async (data) => {
      const obj: any = (await tools.getValueObjByHttp('/section/getList')).obj
      data.forEach(res => {
        res.parentId = obj[res.parentId] || null
      })
      return {
        list: data,
        uniqueKey: 'code'
      }
    }
    const upload = async () => {
      const list = await tools.importData(state.defineProps)
      tools.post('/section/import', {
        uniqueKey: 'code',
        list
      }).then(r => {
        //
      })
    }
    return {
      ...toRefs(state),
      submit,
      changeData,
      upload,
      search,
      tools
    }
  }
})
</script>
