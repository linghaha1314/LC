<template>
  <!-- 筛选条件 -->
  <search-class v-model:refresh="state.refresh" v-model:searchData="state.searchData"
                :searchInit="state.searchInit"
                @search="search">
    <template v-slot:left-btn>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="primary"
        @click="openDialog('isAdd')"
      >新增
      </el-button>
      <el-button plain size="small" type="danger" @click="deleteById(props.row)">删除
      </el-button>
    </template>
  </search-class>
  <!-- 列表数据 -->
  <el-table
    :data="state.tableList"
    style="width: 100%">
    <el-table-column type="expand">
      <template v-slot="props">
        <el-steps :active="2" align-center>
          <el-step v-for="(item,index) of props.row.children" :key="item.id" :description="index+1+'级审批人'"
                   :title="item['roleName']"></el-step>
        </el-steps>
      </template>
    </el-table-column>
    <el-table-column v-for="obj of state.tableColumns" :key="obj.label"
                     :label="obj.label"
                     :prop="obj.valueKey">
    </el-table-column>
    <el-table-column label="操作" prop="opera">
      <template v-slot="props">
        <el-button size="small" type="text" @click="openDialog(props.row)"
        >查看/修改
        </el-button>
        <el-button
          class="font-red"
          size="small"
          type="text"
          @click="deleteById(props.row)"
        >删除
        </el-button>
      </template>
    </el-table-column>
  </el-table>
  <div class="page-box">
    <el-pagination
      :page-size="state.queryParams.limit"
      :page-sizes="[10,20,50,100]"
      :total="state.total"
      background
      layout="total,sizes,prev, pager, next,jumper"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    ></el-pagination>
  </div>
  <el-dialog
    v-model="state.pageParams.isDrawer"
    title="设置审批流程"
  >
    <el-form class="padding-start padding-end" ref="ruleFormRef"
             :model="ruleForm"
             :rules="rules">
      <el-timeline>
        <el-timeline-item placement="top"
                          size="large"
                          timestamp="审批名称&审批类型"
                          type="primary">
          <el-card>
            <el-form-item label="审批名称" prop="name">
              <el-input v-model="ruleForm.name" placeholder="请输入审批流程名"
                        style="width: 200px;"></el-input>
            </el-form-item>
            <el-form-item label="审批类型" prop="typeId">
              <el-select
                v-model="ruleForm.typeId"
                placeholder="选择审批类型"
                filterable
                reserve-keyword
              >
                <el-option
                  v-for="item in state.approvalTypeList"
                  :key="item.id"
                  :label="item.name"
                  :value="item.id">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="指定提交人">
              <el-select
                v-model="ruleForm['assignedRoleId']"
                filterable
                remote
                reserve-keyword
                placeholder="输入角色名"
                :remote-method="remoteMethod"
                :loading="loading"
              >
                <el-option
                  v-for="item in assignedList"
                  :key="item['id']"
                  :label="item.name"
                  :value="item['id']"
                />
              </el-select>
            </el-form-item>
          </el-card>
        </el-timeline-item>
        <el-timeline-item
          v-for="(item, index) in state.approvalList"
          :key="index"
          :color="item.color"
          :timestamp="index+1+'级审批人'"
          placement="top"
          size="large"
          type="primary">
          <el-select
            v-model="item.roleId"
            filterable
            remote
            clearable
            reserve-keyword
            placeholder="输入角色名"
            :remote-method="remoteMethod"
            :loading="loading"
          >
            <el-option
              v-for="item in assignedList"
              :key="item['id']"
              :label="item.name"
              :value="item['id']"
            />
          </el-select>
        </el-timeline-item>
        <el-timeline-item
          v-if="state.approvalList.length<3"
          placement="top"
          size="large"
          timestamp="新增下级审批人，最多3级" type="primary">
          <el-button plain size="small" type="warning" @click="addApprovalItem">新增</el-button>
        </el-timeline-item>
      </el-timeline>
      <div class="flex" style="flex-direction: row-reverse;margin-right: 20px">
        <el-button type="primary" @click="submit()">保存</el-button>
      </div>
    </el-form>
  </el-dialog>
</template>

<script lang="ts" setup>
import { onMounted, reactive, ref, watch } from 'vue'
import tools from '@/utils/tool'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import { ElForm } from 'element-plus/es'

const assignedList = ref([])
const options = ref([])
const value = ref<string[]>([])
const loading = ref(false)

const state = reactive({
  pageParams: {
    isEdit: false,
    isDrawer: false
  },
  refresh: false,
  queryParams: {
    limit: 20,
    offset: 0,
    where: {
      parent_id: { _is_null: true },
      name: { _like: '%%' }
    }
  },
  list: [],
  roles: [],
  approvalType: null,
  approvalTypeList: [],
  approvalId: null,
  approvalList: [{
    content: '支持使用图标',
    size: 'large',
    roleId: null,
    type: 'primary'
  }],
  options: [],
  value: '',
  total: 0,
  searchData: {}, // 定义搜索条件
  selection: [], // 选项数组
  tableList: [],
  tableColumns: [{
    label: '名称',
    valueKey: 'name'
  }, {
    label: '审批类型',
    valueKey: 'typeName'
  }],
  searchInit: [
    {
      name: 'isSelect',
      desc: '专业',
      value: 'searchProfession', // 返回值的名称
      placeholder: '请选择选择专业',
      options: []
    },
    {
      name: 'isSelect',
      desc: '科室',
      value: 'searchDepartment',
      placeholder: '请选择选择科室',
      options: []
    }
  ] // 筛选条件项
})

const ruleFormRef = ref(ElForm)

const ruleForm = reactive({
  name: null,
  typeId: null,
  assignedRoleId: null
})

const rules = reactive({
  name: [
    {
      required: true,
      message: '请输入审批名',
      trigger: 'blur'
    }
  ],
  typeId: [
    {
      required: true,
      message: '请选择审批类型',
      trigger: 'blur'
    }
  ]
})
const search = (val) => {
  state.queryParams.where.name._like = val.name
  state.queryParams = { ...state.queryParams }
}
const getRoles = () => {
  tools.get('/roles/getListByPage', { limit: 200 }).then(r => {
    state.roles = r.list
  })
}

const remoteMethod = async (query: string) => {
  loading.value = true
  const data = await tools.get('/roles/getListByPage', {
    limit: 100,
    name: query
  })
  loading.value = false
  assignedList.value = data.list
}

const submit = () => {
  if (!ruleFormRef.value.validate()) return
  let flag = false
  state.approvalList.forEach(res => {
    if (res.roleId) {
      flag = true
    }
  })
  if (!flag) {
    tools.msgError('请至少选择一个审批人')
    return
  }
  const loading = tools.showLoading('提交中...')
  tools.post('/approvalProcessSet/createUpdateData', {
    id: state.approvalId,
    name: ruleForm.name,
    typeId: ruleForm.typeId,
    assignedRoleId: ruleForm.assignedRoleId,
    list: state.approvalList
  }).then(r => {
    tools.closeLoading(loading)
    if (r.success) {
      getList()
      state.pageParams.isDrawer = false
      tools.msg(r.msg)
    }
  })
}

const getApprovalTypeList = () => {
  tools.post('/dictionaryData/getByTypeCode', {
    typeCode: 'approvalType'
  }).then(r => {
    if (r.success) {
      state.approvalTypeList = r.list
    }
  })
}

const handleSizeChange = (val) => {
  state.queryParams.limit = val
  getList()
}

const currentChange = (val) => {
  state.queryParams.offset = state.queryParams.limit * (val - 1)
  getList()
}

const deleteById = async (val) => {
  const isDelete = await tools.confirm()
  if (!isDelete) {
    return
  }
  tools.post('/approvalProcess/delete', { id: val.id }).then(r => {
    getList()
  })
}

const openDialog = (val) => {
  if (val === 'isAdd') {
    state.approvalId = null
    state.approvalList = [{
      content: '支持使用图标',
      size: 'large',
      roleId: null,
      type: 'primary'
    }]
    state.pageParams.isDrawer = true
    ruleForm.assignedRoleId = null
    try {
      ruleFormRef.value.resetFields()
    } catch (e) {
      console.log(e)
    }
    return
  }
  state.pageParams.isDrawer = true
  ruleForm.name = val.name
  ruleForm.typeId = val.typeId || null
  ruleForm.assignedRoleId = val.assignedRoleId || null
  state.approvalId = val.id
  state.approvalList = JSON.parse(JSON.stringify(val.children))
}

const getList = () => {
  tools.post('/approvalProcessSet/getDataListByPage', {
    ...state.queryParams
  }).then(r => {
    state.tableList = r.list
    state.total = r.total
  })
}

const addApprovalItem = () => {
  if (state.approvalList.length >= 4) {
    tools.msg('温馨提示：最多三级审批人！', 'warning')
    return
  }
  (state.approvalList as any).push(
    {
      content: state.approvalList.length + '级审批人',
      size: 'large',
      roleId: null,
      if: 'select'
    }
  )
}

onMounted(() => {
  getRoles()
  getList()
  remoteMethod('')
  getApprovalTypeList()
})

watch(
  () => state.refresh,
  (newVal) => {
    if (newVal) {
      getList()
      state.refresh = false
    }
  }
)
</script>

<style scoped>

</style>
