<template>
  <div class="course-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="$tools.openDrawer(pageParams)"
        >新增
        </el-button>
        <el-button plain size="small" type="danger" @click="$tools.delMultiple('roles',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
                :query-data="searchInfo"
                url="/roles/getListByPage">
      <template v-slot="scope">
        <el-button size="small" type="primary" @click="$tools.openDrawer(pageParams,true,formList,scope.row)"
        >查看/修改
        </el-button>
        <el-button
          size="small"
          type="success"
          @click="openDialog(scope.row,'menus')"
        >后台菜单授权
        </el-button>
        <el-button
          size="small"
          type="success"
          @click="openDialog(scope.row,'columns')"
        >门户栏目授权
        </el-button>
        <el-button
          size="small"
          type="warning"
          @click="openDialog(scope.row,'homeColumns')"
        >首页栏目授权
        </el-button>
        <el-button
          size="small"
          type="danger"
          @click="$tools.deleteById('roles', scope.row.id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <el-drawer
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="40%"
      title="角色设置"
    >
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-drawer>
  </div>
  <el-dialog v-model="isDialog" center destroy-on-close
             :title="currentDialogType==='menus'?'菜单授权':(currentDialogType==='homeColumns'?'首页栏目授权':'门户栏目授权')"
             width="40%">
    <div style="height: 50vh;overflow-y: auto;">
      <el-tree
        ref="treeRef"
        :data="menusList"
        :default-checked-keys="checkedKeys"
        :default-expand-all="true"
        :props="{children: 'children',label: 'name'}"
        node-key="id"
        show-checkbox
      />
    </div>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="setRoleMenus"
        >确定
        </el-button>
      </div>
    </template>
  </el-dialog>
  <el-dialog v-model="isDialogColumn" center destroy-on-close title="菜单授权" width="40%">
    <div style="height: 50vh;overflow-y: auto;">
      <el-tree
        ref="treeRef"
        :data="column"
        :default-checked-keys="checkedKeys"
        :default-expand-all="true"
        :props="{children: 'children',label: 'name'}"
        node-key="id"
        show-checkbox
      />
    </div>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="setRoleCol"
        >确定
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, getCurrentInstance, onMounted, reactive, ref, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import { ElTree } from 'element-plus'
import store from '@/store'

export default defineComponent({
  components: {
    TableList,
    SearchClass,
    FormList
  },
  setup: () => {
    const { proxy }: any = getCurrentInstance()

    const treeRef = ref<InstanceType<typeof ElTree>>()

    const state = reactive({
      columns: [],
      homeColumns: [],
      menus: [],
      menusList: [],
      lastKeys: [],
      checkedKeys: [],
      currentDialogType: 'menus',
      isDialog: false,
      currentRoleId: '',
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false,
        isDialog: false
      },
      searchInfo: {
        name: ''
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '名字',
          width: 120
        },
        {
          valueKey: 'code',
          label: '编码',
          width: 120
        }, {
          valueKey: 'status',
          width: 120,
          label: '状态'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // }
      ], // 筛选条件项
      formList: [{
        type: 'none',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '名字',
        key: 'name',
        width: '',
        value: null,
        required: true,
        defaultValue: ''
      }, {
        type: 'input',
        label: '编码',
        key: 'code',
        width: '',
        value: null,
        defaultValue: '',
        required: true
      }, {
        type: 'textarea',
        label: '描述',
        key: 'remark',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'switch',
        label: '状态',
        key: 'status',
        width: '',
        value: '',
        defaultValue: null
      }]
    })

    const getMenus = () => {
      tools.get('/menu/list').then(r => {
        state.menus = r.list
      })
    }

    const getColumn = () => {
      tools.get('/ps_menus/getListByPage', {
        limit: 99
      }).then(r => {
        state.columns = r.list
      })
    }

    const getHomeColumns = () => {
      tools.get('/homeColumns/getListByPage', {
        limit: 1000
      }).then(r => {
        state.homeColumns = r.list
      })
    }

    const submit = (val) => {
      // const lod = tools.showLoading('正在处理...')
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/roles/updateById', data).then(res => {
          if (res.success) {
            // tools.closeLoading(lod)
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/roles/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      state.searchInfo = searchInfo
    }

    const openDialog = (val, type = 'menus') => {
      state.currentDialogType = type
      state.menusList = state[type]
      const list: any = []
      const url = type === 'menus' ? '/roleAuthority/getListByPage' : (type === 'columns' ? '/roleColumn/getListByPage' : '/roleHomeColumn/getListByPage')
      tools.get(url, {
        roleId: val.id,
        limit: 1000
      }).then(r => {
        state.lastKeys = r.list
        r.list.forEach((res: any) => {
          list.push(res.menuId)
          list.push(res.menuId || res.columnId)
        })
        const listArr: any = []
        const mapList = []
        tools.childNo(state[type], mapList, () => {
          mapList.forEach((item: any) => {
            list.forEach(ite => {
              if (item.id === ite && (item.parentId || item.children.length === 0)) {
                listArr.push(ite)
              }
            })
          })
        })
        state.checkedKeys = listArr
        state.isDialog = true
        state.currentRoleId = val.id
      })
    }

    const setRoleMenus = () => {
      const keys = treeRef.value!.getCheckedKeys(false)
      const keysH = treeRef.value!.getHalfCheckedKeys()
      const loading = tools.showLoading('提交中...')
      const tableName = state.currentDialogType === 'menus' ? 'roleAuthority' : (state.currentDialogType === 'homeColumns' ? 'roleAuthorityHomeColumn' : 'roleColumn')
      tools.post(`/${tableName}/update`, {
        roleId: state.currentRoleId,
        menuIds: [...keys, ...keysH]
      }).then(r => {
        if (r.success) {
          tools.msg(r.msg)
          state.isDialog = false
          if (state.currentDialogType === 'menus') {
            store.dispatch('getMenus')
          }
        }
        tools.closeLoading(loading)
      })
    }

    onMounted(() => {
      getMenus()
      getHomeColumns()
      getColumn()
    })

    return {
      proxy,
      treeRef,
      ...toRefs(state),
      search,
      openDialog,
      getColumn,
      getHomeColumns,
      setRoleMenus,
      submit
    }
  }
})
</script>

<style lang="less">
.dialog-footer {
  display: flex;
  flex-direction: row-reverse;
}
</style>
