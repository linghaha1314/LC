<template>
  <div class="menu-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button class="background-btn" plain size="small" type="primary" @click="addNew">新增
        </el-button>
        <el-button class="background-btn" plain size="small" type="primary" @click="importData">导入
        </el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
                url="/user/getUserListByPage" http-type="post" :queryData="queryData">
      <template v-slot="scope">
        <el-button color="primary" size="small" type="text" @click="edit(scope.row)">编辑
        </el-button>
        <el-button size="small" type="danger"
                   @click="$tools.deleteById('user', scope.row.id, pageParams, 'id', '/user/deleteUserById')">删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑菜单 -->
    <el-drawer v-model="pageParams.isDrawer" :append-to-body="false" :destroy-on-close="true" direction="rtl" size="40%"
               title="菜单详情">
      <el-scrollbar>
        <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
      </el-scrollbar>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
// 名师管理；可以从现有的人员里面选择，没有也可以添加；添加的同时会向数据库插入用户，为；主要老师的基本介绍和科室，专业，职务，照片，履历；相关的课程；
export default defineComponent({
  components: {
    SearchClass,
    TableList,
    FormList
  },
  setup: () => {
    // const userList = async () => {
    //   await tools.get('/user/getList').then(r => {
    //     state.tableColumns[0].list = r.list
    //   })
    // }
    const importData = async () => {
      const list: any = await tools.importData({
        讲师姓名: 'name',
        帐号: 'username'
      })
      const loading = tools.showLoading('加载中...')
      for (const rr of list) {
        let result: any = {}
        const lecturerData = await tools.post('/api/rest/user/getLecturerByUserName', { where: { name: { _eq: rr.name } } })
        if (lecturerData.data.list.length > 0 && lecturerData.data.list[0].roles.length > 0) {
          const isExit = await tools.confirm('温馨提示', '数据库里面已经存在了该讲师，是否还要继续添加？')
          if (isExit) {
            result = await tools.post('/user/createNewLecturer', {
              name: rr.name,
              username: rr.username || null
            })
          } else {
            result = { success: true }
          }
        } else {
          result = await tools.post('/user/createNewLecturer', {
            name: rr.name,
            username: rr.username || null
          })
        }
        if (!result.success) {
          tools.msgError(rr.name + '导入出错-' + result.msg)
          return
        }
      }
      tools.closeLoading(loading)
      state.pageParams.refresh = true
    }

    const state = reactive({
      queryData: {
        where: { roles: { kb_role: { code: { _eq: 'lecturer' } } } }
      },
      pageParams: {
        refresh: false,
        isEdit: false,
        isDrawer: false
      },
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'avatar',
          label: '头像',
          type: 'avatar',
          width: 100
        },
        {
          valueKey: 'name',
          label: '姓名',
          width: 180
        },
        {
          valueKey: 'username',
          label: '帐号',
          width: 180
        },
        // {
        //   valueKey: 'positionTitle',
        //   label: '职称',
        //   width: 160
        // }, {
        //   valueKey: 'position',
        //   width: 160,
        //   label: '职务'
        // }, {
        //   valueKey: 'major',
        //   width: 120,
        //   label: '专业'
        // }, {
        //   valueKey: 'organizationName',
        //   width: 120,
        //   label: '机构'
        // }, {
        //   valueKey: 'introduce',
        //   width: 120,
        //   label: '基本资料',
        //   isEllipsis: true
        // }, {
        //   valueKey: 'related',
        //   width: 120,
        //   label: '相关课程'
        // },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ], // 筛选条件项
      formList: [
        {
          type: 'input',
          // type: 'select', // 可以选择，也可以手动输入；输入的需要保存到用户里面
          label: '姓名',
          key: 'name',
          // url: '/user/getList',
          // searchKey: 'search',
          value: null,
          required: true, // 选择之后填充其他的信息
          defaultValue: null
        },
        {
          type: 'input',
          label: '帐号',
          key: 'username',
          width: '',
          value: null,
          defaultValue: ''
        }
        // {
        //   type: 'uploadImg',
        //   label: '头像',
        //   key: 'avatar',
        //   width: '',
        //   value: null,
        //   defaultValue: null
        // }, {
        //   type: 'input',
        //   label: '机构',
        //   key: 'organizationName',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // }, {
        //   type: 'input',
        //   label: '职称',
        //   key: 'positionTitle',
        //   width: '',
        //   value: null,
        //   defaultValue: '',
        //   required: true
        // }, {
        //   type: 'input',
        //   label: '职位',
        //   key: 'position',
        //   width: '',
        //   value: '',
        //   defaultValue: null
        // }, {
        //   type: 'select',
        //   label: '专业',
        //   key: 'majorId',
        //   width: '',
        //   value: '',
        //   defaultValue: null
        // }, {
        //   type: 'richText',
        //   label: '介绍',
        //   key: 'introduce',
        //   width: '',
        //   value: '',
        //   defaultValue: null
        // }, {
        //   type: 'select',
        //   label: '相关课程',
        //   multiple: true,
        //   key: 'related',
        //   width: '',
        //   value: '',
        //   defaultValue: null
        // }, {
        //   type: 'switch',
        //   label: '状态',
        //   placeholder: '请输入图标code',
        //   key: 'status',
        //   width: '',
        //   value: '',
        //   defaultValue: 1
        // }
      ]
    })

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      delete data.related
      if (state.pageParams.isEdit) {
        tools.post('/user/updateUserById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/user/createNewLecturer', data).then(res => {
        if (res.success) {
          state.pageParams.isDrawer = false
          tools.msg(res.msg)
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      console.log(searchInfo)
    }
    const addNew = () => {
      state.pageParams.isDrawer = true
      state.pageParams.isEdit = false
    }
    const edit = (val) => {
      state.pageParams.isDrawer = true
      state.pageParams.isEdit = true
      state.formList.forEach(res => {
        res.value = val[res.key]
      })
    }

    const del = (val) => {
      // tools.deleteById('menus', val.id, {}).then(() => {
      //   state.refresh = true
      // })
    }
    return {
      importData,
      ...toRefs(state),
      addNew,
      del,
      edit,
      submit,
      search
    }
  }
})
</script>

<style lang="less" scoped>
</style>
