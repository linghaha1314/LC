<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" @search="search">
      <template v-slot:left-btn>
<!--        <el-button-->
<!--          @click="setFn()"-->
<!--          class="background-btn"-->
<!--          size="small"-->
<!--          type="primary"-->
<!--          plain-->
<!--        >新增-->
<!--        </el-button>-->
        <el-button type="danger" plain size="small" @click="tools.delMultiple('leave_msg',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" url="/leave_msg/getListByPage" :query-data="searchInfo"
                v-model:refresh="pageParams.refresh">
      <template v-slot="scope">
        <el-button type="primary" size="small" @click="setFn(scope)"
        >查看/修改
        </el-button>
        <el-button
          type="danger"
          size="small"
          @click="tools.deleteById('leave_msg', scope['row'].id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-dialog
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" :submitText="submitText" @submit="pageParams.isDrawer = false"></form-list>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '姓名',
          width: 180
        },
        {
          valueKey: 'mobile',
          label: '电话'
        },
        {
          valueKey: 'email',
          label: '邮箱'
        },
        {
          valueKey: 'content',
          label: '留言内容'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '状态',
        //   value: 'status',
        //   placeholder: '请选择选择状态',
        //   options: [
        //     {
        //       id: 0,
        //       name: '未审核',
        //       value: 0
        //     },
        //     {
        //       id: 1,
        //       name: '已审核',
        //       value: 1
        //     }
        //   ]
        // }
      ], // 筛选条件项
      apply: false,
      formList: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '姓名',
          key: 'name',
          width: '',
          value: null,
          defaultValue: null,
          disabled: true
        },
        {
          type: 'input',
          label: '电话',
          key: 'mobile',
          width: '',
          value: null,
          defaultValue: null,
          disabled: true
        },
        {
          type: 'input',
          label: '邮箱',
          key: 'email',
          width: '',
          value: null,
          defaultValue: null,
          disabled: true
        },
        {
          type: 'textarea',
          label: '留言内容',
          key: 'content',
          width: '',
          value: null,
          defaultValue: null,
          disabled: true
        },
        {
          type: 'datePiker',
          label: '创建日期',
          key: 'created',
          width: '',
          value: null,
          defaultValue: null,
          disabled: true
        }
      ],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ],
      submitText: '关闭'
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const resetPass = (val) => {
      tools.post('/leave_msg/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        source: data.source,
        time: data.time,
        author: data.author,
        content: data.content,
        typeId: data.typeId,
        path: data.path,
        code: data.code || '',
        status: data.status || 0,
        sequence: data.sequence
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/leave_msg/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/leave_msg/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.name = (searchInfo.name && searchInfo.name.substring(1, searchInfo.name.length - 1)) || ''
    }
    // const applyFn = (scope) => {
    //   state.apply = false
    //   tools.openDrawer(state.pageParams, true, state.applyParam, scope.row)
    // }
    const setFn = (scope) => {
      state.apply = true
      if (scope) {
        tools.openDrawer(state.pageParams, true, state.formList, scope.row)
      } else {
        tools.openDrawer(state.pageParams)
      }
    }
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      // applyFn,
      setFn,
      tools
    }
  }
})
</script>
