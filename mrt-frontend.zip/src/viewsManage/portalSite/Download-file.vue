<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" isShowExportBtn="false" @search="search">
      <template v-slot:left-btn>
        <el-button
          @click="setFn()"
          class="background-btn"
          size="small"
          type="primary"
          plain
          v-show="authorization === 'add'"
        >添加资料
        </el-button>
        <el-button type="danger" plain size="small" @click="tools.delMultiple('file',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" url="/file/getListByPage" :query-data="searchInfo"
                v-model:refresh="pageParams.refresh">
      <template v-slot:status="data">
        <span v-if="data.row.status===-1" class="font-warning font-bold">未提交</span>
        <span v-if="data.row.status===0" class="font-red font-bold">审核驳回</span>
        <span v-if="data.row.status===2" class="font-red font-bold">禁用</span>
        <span v-if="data.row.status===11" class="font-warning font-bold">待审核</span>
        <span v-if="data.row.status===1" class="font-green font-bold">启用</span>
      </template>
      <template v-slot="scope">
        <el-button v-show="authorization === 'add'" type="primary" size="small" @click="setFn(scope)"
        >查看/修改
        </el-button>
<!--        <el-button type="warning" size="small" @click="applyFn(scope)"-->
<!--        >审核-->
<!--        </el-button>-->
        <el-button
          type="danger"
          size="small"
          @click="tools.deleteById('file', scope['row'].id,pageParams)"
        >删除
        </el-button>
        <Preview :ok-data="scope['row']"></Preview>
        <Approval :data="scope" v-model:refresh="pageParams.refresh" table-name="file" type-code="file" @approval="approvalFn"></Approval>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-if="apply"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-else
    >
      <form-list :list="applyParam" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref, watch, onBeforeMount } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import Preview from '@/viewsManage/components/preview.vue'
import Approval from '@/viewsManage/components/approval.vue'
import router from '@/router'
import { useRoute } from 'vue-router'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList,
    Preview,
    Approval
  },
  setup: () => {
    const state = reactive({
      authorization: '',
      nowRow: {
        sequence: null,
        id: null
      },
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '标题',
          width: 180
        },
        {
          valueKey: 'content',
          label: '描述'
        },
        {
          valueKey: 'typeId',
          label: '栏目类型',
          list: []
        },
        {
          valueKey: 'path',
          label: '文件',
          width: 180
        },
        // {
        //   valueKey: 'sequence',
        //   label: '排序',
        //   width: 140
        // },
        {
          valueKey: 'status',
          width: 120,
          label: '状态',
          type: 'slot'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '状态',
          placeholder: '选择状态',
          value: 'status',
          valueKey: 'status',
          defaultValue: null,
          options: [{
            status: null,
            name: '不限制'
          }, {
            status: '-1',
            name: '未提交'
          }, {
            status: '11',
            name: '待审核'
          }, {
            status: '0',
            name: '驳回'
          }, {
            status: '1',
            name: '启用'
          }, {
            status: '2',
            name: '禁用'
          }]
        }
      ], // 筛选条件项
      formList: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '文件名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '来源',
          key: 'source',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'datePiker',
          label: '时间',
          key: 'time',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '发布人',
          key: 'author',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'textarea',
          label: '描述',
          key: 'content',
          width: '',
          value: null,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        // {
        //   type: 'input',
        //   label: '顺序',
        //   placeholder: '请输入顺序',
        //   key: 'sequence',
        //   width: '',
        //   value: '',
        //   required: true,
        //   defaultValue: null
        // },
        {
          type: 'uploadFileMul',
          label: '文件',
          placeholder: '请上传文件',
          key: 'path',
          buttonText: '上传文件',
          width: '',
          value: '',
          defaultValue: '',
          required: true
        },
        {
          type: 'select',
          label: '栏目类型',
          key: 'typeId',
          width: '',
          value: null,
          url: '/ps_menus/getDataByIdMore',
          queryParams: {
            parentId: '2f9e8411-2de4-4ffc-8c4a-346f98859632'
          },
          httpType: 'post',
          defaultValue: '',
          required: true
        },
        {
          type: 'radio',
          label: '附件可否下载',
          placeholder: '请审核',
          key: 'isDownload',
          width: '',
          value: '',
          options: [
            {
              name: '同意',
              value: 1
            },
            {
              name: '不同意',
              value: 0
            }
          ]
        }
      ],
      apply: false,
      applyParam: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '文件名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '来源',
          key: 'source',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'datePiker',
          label: '时间',
          key: 'time',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '发布人',
          key: 'author',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'textarea',
          label: '描述',
          key: 'content',
          width: '',
          value: null,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        // {
        //   type: 'input',
        //   label: '顺序',
        //   placeholder: '请输入顺序',
        //   key: 'sequence',
        //   width: '',
        //   value: '',
        //   required: true,
        //   defaultValue: null
        // },
        {
          type: 'uploadFileMul',
          label: '文件',
          buttonText: '上传文件',
          placeholder: '请上传',
          key: 'path',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'select',
          label: '栏目类型',
          key: 'typeId',
          width: '',
          value: null,
          url: '/ps_menus/getDataByIdMore',
          queryParams: {
            parentId: '2f9e8411-2de4-4ffc-8c4a-346f98859632'
          },
          httpType: 'post',
          defaultValue: '',
          required: true
        },
        {
          type: 'radio',
          label: '审核',
          placeholder: '请审核',
          key: 'status',
          width: '',
          value: '',
          required: true,
          options: [
            {
              name: '同意',
              value: 1
            },
            {
              name: '不同意',
              value: 0
            }
          ]
        }
      ],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
          // tools.openDrawer(state.pageParams)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    watch(() => router.currentRoute.value.query, (newValue: any) => {
      state.authorization = newValue.code
    })
    const getType = async (num) => {
      const result = await tools.post('/ps_menus/getDataByIdMore', {
        parentId: '2f9e8411-2de4-4ffc-8c4a-346f98859632'
      })
      state.tableColumns[num].list = result.data
    }
    getType(3)

    const resetPass = (val) => {
      tools.post('/file/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        source: data.source,
        time: data.time,
        author: data.author,
        content: data.content,
        code: data.code || '',
        status: data.status || -1,
        path: data.path,
        typeId: data.typeId,
        isDownload: data.isDownload,
        sequence: state.nowRow.id ? state.nowRow.sequence : new Date().getTime()
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/file/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/file/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.status = searchInfo.status
      searchInfo.name && (state.searchInfo.name = searchInfo.name.indexOf('undefined') > -1 || searchInfo.name.length === 2 ? null : searchInfo.name.substring(1, searchInfo.name.length - 1))
    }

    const applyFn = (scope) => {
      state.apply = false
      tools.openDrawer(state.pageParams, true, state.applyParam, scope.row)
    }
    const setFn = (scope) => {
      state.apply = true
      if (scope) {
        state.nowRow = {
          ...scope.row
        }
        tools.openDrawer(state.pageParams, true, state.formList, scope.row)
      } else {
        state.nowRow = {
          sequence: null,
          id: null
        }
        tools.openDrawer(state.pageParams)
      }
    }
    const approvalFn = () => {
      state.pageParams.refresh = true
    }
    onBeforeMount(() => {
      const route = useRoute()
      const parma: any = route.query
      state.authorization = parma.code || ''
    })
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      applyFn,
      setFn,
      approvalFn,
      tools
    }
  }
})
</script>
