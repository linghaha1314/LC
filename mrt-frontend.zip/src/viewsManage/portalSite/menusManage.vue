<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" @search="search">
      <template v-slot:left-btn>
        <el-button
          @click="tools.openDrawer(pageParams)"
          class="background-btn"
          size="small"
          type="primary"
          plain
        >新增栏目
        </el-button>
        <el-button type="danger" plain size="small" @click="tools.delMultiple('ps_menus',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" :isShowPage="false" :query-data="searchInfo" url="/ps_menus/getListByPage"
                  v-model:refresh="pageParams.refresh">
        <template v-slot="scope">
          <el-button type="primary" size="small" @click="tools.openDrawer(pageParams,true,formList,scope['row'])"
          >查看/修改
          </el-button>
          <el-button
            type="danger"
            size="small"
            @click="tools.deleteById('ps_menus', scope['row'].id,pageParams)"
          >删除
          </el-button>
        </template>
      </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        limit: 900,
        sort: 'sequence asc',
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '名称',
          width: 180
        },
        {
          valueKey: 'path',
          label: 'code码',
          width: 180
        },
        {
          valueKey: 'sequence',
          label: '排序',
          width: 140
        }, {
          valueKey: 'status',
          width: 120,
          label: '状态'
        }], // tableColumns
      searchInit: [
      ], // 筛选条件项
      formList: [
        {
          label: '名称',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '名称',
          key: 'name',
          maxlength: 10,
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: 'code码',
          key: 'path',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'number',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: 5
        },
        {
          type: 'cascade',
          label: '上级栏目',
          key: 'parentId',
          url: '/ps_menus/getListByPage',
          list: [],
          width: '',
          value: '',
          queryParams: {
            limit: 99
          },
          props: {
            checkStrictly: true,
            label: 'name',
            value: 'id'
          },
          typeList: [],
          defaultValue: ''
        },
        {
          type: 'switch',
          label: '状态',
          placeholder: '请输入图标code',
          key: 'status',
          width: '',
          value: '',
          defaultValue: 1
        }
      ]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const resetPass = (val) => {
      tools.post('/ps_menus/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      console.log(data, 889)
      const obj: any = {
        name: data.name,
        // icon: data.icon,
        code: data.code || '',
        status: data.status || 0,
        sequence: parseInt(data.sequence),
        parentId: typeof data.parentId === 'object' ? data.parentId[data.parentId.length - 1] : data.parentId,
        path: data.path
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/ps_menus/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/ps_menus/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.status = searchInfo.status
      state.searchInfo.name = searchInfo.name.substring(1, searchInfo.name.length - 1)
    }
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      tools
    }
  }
})
</script>
