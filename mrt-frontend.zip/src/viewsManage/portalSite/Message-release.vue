<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" @search="search">
      <template v-slot:left-btn>
        <el-button
          @click="setFn()"
          class="background-btn"
          size="small"
          type="primary"
          plain
        >新增信息
        </el-button>
        <el-button type="danger" plain size="small" @click="tools.delMultiple('message',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" url="/message/getListByPage"
                :query-data="searchInfo"
                v-model:refresh="pageParams.refresh">
      <template v-slot="scope">
        <el-button type="primary" size="small" @click="setFn(scope)"
        >查看/修改
        </el-button>
        <el-button v-if="tools.isApply(roles)" type="warning" size="small" @click="applyFn(scope)"
        >审核
        </el-button>
        <el-button
          type="danger"
          size="small"
          @click="tools.deleteById('message', scope['row'].id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-if="apply"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-else
    >
      <form-list :list="applyParam" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref, onBeforeMount } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      tableData: [],
      typeData: [],
      searchInfo: {
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '题目',
          width: 180
        },
        {
          valueKey: 'img',
          label: '图片',
          width: 180
        },
        {
          valueKey: 'sequence',
          label: '排序',
          width: 140
        },
        {
          valueKey: 'typeId',
          label: '类型',
          width: 140,
          list: []
        },
        {
          valueKey: 'status',
          width: 120,
          label: '状态',
          flag: true,
          statusLabel: [
            '未审核',
            '已审核'
          ]
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '状态',
          value: 'status',
          placeholder: '请选择选择状态',
          options: [
            {
              id: 0,
              name: '未审核',
              value: 0
            },
            {
              id: 1,
              name: '已审核',
              value: 1
            }
          ]
        }
      ], // 筛选条件项
      apply: false,
      applyParam: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '标题',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '来源',
          key: 'source',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'datePiker',
          label: '时间',
          key: 'time',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '作者',
          key: 'author',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'richText',
          label: '内容',
          key: 'content',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'select',
          label: '消息类型',
          key: 'typeId',
          url: '/message_type/getListByPage',
          optionsLabel: 'name',
          optionsValue: 'id',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        }, {
          type: 'uploadImg',
          label: '附件',
          placeholder: '请上传图片',
          key: 'img',
          width: '',
          value: '',
          defaultValue: ''
        },
        {
          type: 'radio',
          label: '审核',
          placeholder: '请输入图标code',
          key: 'status',
          width: '',
          value: '',
          defaultValue: 1,
          required: true,
          options: [
            {
              name: '同意',
              value: 1
            },
            {
              name: '不同意',
              value: 0
            }
          ]
        }
      ],
      formList: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '标题',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '来源',
          key: 'source',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'datePiker',
          label: '时间',
          key: 'time',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '作者',
          key: 'author',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'richText',
          label: '内容',
          key: 'content',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'select',
          label: '消息类型',
          key: 'typeId',
          url: '/message_type/getListByPage',
          optionsLabel: 'name',
          optionsValue: 'id',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        }, {
          type: 'uploadImg',
          label: '附件',
          placeholder: '请上传图片',
          key: 'img',
          width: '',
          value: '',
          defaultValue: ''
        }],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const getType = async (num, code) => {
      const result = await tools.get(code)
      state.tableColumns[num].list = result.list
    }
    getType(5, '/message_type/getListByPage')
    const resetPass = (val) => {
      tools.post('/message/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        source: data.source,
        time: data.time,
        author: data.author,
        content: data.content,
        code: data.code || '',
        status: data.status || 0,
        typeId: data.typeId,
        sequence: data.sequence,
        path: '',
        img: data.img
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/message/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/message/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.status = searchInfo.status
      state.searchInfo.name = searchInfo.name.substring(1, searchInfo.name.length - 1)
    }
    const applyFn = (scope) => {
      state.apply = false
      tools.openDrawer(state.pageParams, true, state.applyParam, scope.row)
    }
    const setFn = (scope) => {
      state.apply = true
      if (scope) {
        tools.openDrawer(state.pageParams, true, state.formList, scope.row)
      } else {
        tools.openDrawer(state.pageParams)
      }
    }
    const getData = (url, data, cb?) => {
      tools.get(url, {
        limit: 10,
        offset: 1
      }).then(res => {
        state[data] = res.list
        if (cb) {
          cb()
        }
      })
    }
    const changeType = () => {
      state.tableData.forEach((item: any) => {
        state.typeData.forEach((ite: any) => {
          if (item.typeId.indexOf(ite.id) !== -1) {
            item.typeName = ite.name
          }
        })
      })
    }
    onBeforeMount(() => {
      getData('/message/getListByPage', 'tableData', () => {
        getData('/message_type/getListByPage', 'typeData', changeType)
      })
    })
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      applyFn,
      setFn,
      tools
    }
  }
})
</script>
