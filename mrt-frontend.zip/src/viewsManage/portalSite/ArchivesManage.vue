<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" v-model:searchData="searchData" :searchInit="searchInit"
                  @search="search"
                  :is-show-export-btn="true"
                  v-model:tableColumns="tableColumns"
                  @exportAll="exportFn"
    >
      <template v-slot:left-btn>
        <el-button
          v-show="showPage"
          class="background-btn"
          plain
          size="small"
          type="primary"
          @click="newAdd"
        >新增档案
        </el-button>
        <!--        <el-button plain size="small" type="success" @click="tools.aDown('人员数据信息模板.xlsx','./xlsx/人员数据信息模板.xlsx')">-->
        <!--          模板下载-->
        <!--        </el-button>-->
        <!--        <el-button-->
        <!--          class="background-btn"-->
        <!--          plain-->
        <!--          size="small"-->
        <!--          type="warning"-->
        <!--          @click="$tools.upload('import',defineProps,'user',pageParams)"-->
        <!--        >导入-->
        <!--        </el-button>-->
        <!--        <el-button-->
        <!--          class="background-btn"-->
        <!--          plain-->
        <!--          size="small"-->
        <!--          type="primary"-->
        <!--          @click="$tools.writeFile(list,defineProps)"-->
        <!--        >导出-->
        <!--        </el-button>-->
        <el-button size="small" type="danger" @click="tools.delMultiple('user',selection,pageParams)">删除
        </el-button>
        <import-file model-file="./xlsx/人员数据信息模板.xlsx" model-name="人员数据信息模板.xlsx" :config="definePropsArr"
                     :changeData="changeData" table-name="user" v-model:refresh="pageParams.refresh"></import-file>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:list="list" v-model:refresh="pageParams.refresh" v-model:selection="selection"
                :columns="tableColumns"
                httpType="post"
                :is-show-page="showPage"
                :queryData="searchInfo" url="/user/getUserListByPage">
      <template v-slot="scope">
        <el-button size="small" type="warning" @click="setRow(scope, false)"
        >完善信息
        </el-button>
        <el-button size="small" type="primary" @click="setRow(scope, true)"
        >查看
        </el-button>
      </template>
    </table-list>
    <!-- 用户详细信息 -->
    <el-drawer
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="60%"
      title="档案信息"
    >
      <el-tabs v-model="activeName" class="demo-tabs" @tab-click="handleClick">
        <el-tab-pane label="基本信息" name="first">
          <form-list v-if="!isLook" :isEdit="pageParams.isEdit" :list="formList" @submit="submit">
            <template v-slot:title>
              <strip-title class="margin-bottom">基本信息</strip-title>
            </template>
          </form-list>
          <el-descriptions v-else title="基本信息" border>
            <template v-for="item in formList" :key="item['key']">
              <el-descriptions-item v-if="item['value'] && item['key']!=='id' && item['key']!=='sectionId'"
                                    :label="item['label']">
                {{ item['value'] }}
              </el-descriptions-item>
            </template>
          </el-descriptions>
        </el-tab-pane>
        <el-tab-pane :disabled="formList[1].value===''||formList[1].value===null" label="工作经历" name="second">
          <form-list v-if="!isLook" :isEdit="pageParams.isEdit" :list="workList" @submit="submitWork">
            <template v-slot:title>
              <strip-title class="margin-bottom">工作经历信息</strip-title>
            </template>
          </form-list>
          <el-table :data="workData" stripe border height="300" style="width: 100%">
            <el-table-column prop="unit" label="工作单位"/>
            <el-table-column prop="job" label="工作职务"/>
            <el-table-column prop="content" label="工作内容"/>
            <el-table-column label="开始时间">
              <template #default="scope">
                <div>
                  {{ tools.formatTime(scope.row.startTime) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column label="结束时间">
              <template #default="scope">
                <div>
                  {{ tools.formatTime(scope.row.endTime) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column v-if="!isLook" label="操作">
              <template #default="scope">
                <el-button
                  size="small"
                  type="danger"
                  @click="wordDelete(scope.row,'user_work')"
                >删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane :disabled="formList[1].value===''||formList[1].value===null" label="培训学习" name="third">
          <form-list v-if="!isLook" :isEdit="pageParams.isEdit" :list="studyList" @submit="submitStudy">
            <template v-slot:title>
              <strip-title class="margin-bottom">培训学习信息</strip-title>
            </template>
          </form-list>
          <el-table :data="studyData" stripe border height="300" style="width: 100%">
            <el-table-column prop="school" label="学习机构"/>
            <el-table-column prop="content" label="学习内容"/>
            <el-table-column label="开始时间">
              <template #default="scope">
                <div>
                  {{ tools.formatTime(scope.row.startTime) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column label="结束时间">
              <template #default="scope">
                <div>
                  {{ tools.formatTime(scope.row.endTime) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column v-if="!isLook" label="操作">
              <template #default="scope">
                <el-button
                  size="small"
                  type="danger"
                  @click="wordDelete(scope.row, 'user_study', 1)"
                >删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane :disabled="formList[1].value===''||formList[1].value===null" label="证书信息" name="fourth">
          <form-list v-if="!isLook" :isEdit="pageParams.isEdit" :list="docList" @submit="submitDoc">
            <template v-slot:title>
              <strip-title class="margin-bottom">证书信息</strip-title>
            </template>
          </form-list>
          <el-table :data="docData" stripe border height="300" style="width: 100%">
            <el-table-column prop="name" label="证书名字"/>
            <el-table-column prop="number" label="证书号码"/>
            <el-table-column label="签发时间">
              <template #default="scope">
                <div>
                  {{ tools.formatTime(scope.row.startTime) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column label="证件照片">
              <template #default="scope">
                <div>
                  <img :src="scope.row['img'] || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png'"
                       style="width: 60px;height: 60px;object-fit: cover"/>
                </div>
              </template>
            </el-table-column>
            <el-table-column v-if="!isLook" label="操作">
              <template #default="scope">
                <el-button
                  size="small"
                  type="danger"
                  @click="wordDelete(scope.row, 'user_certificate', 2)"
                >删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane :disabled="formList[1].value===''||formList[1].value===null" label="家庭成员关系" name="fifth">
          <form-list v-if="!isLook" :isEdit="pageParams.isEdit" :list="familyList" @submit="submitFamily">
            <template v-slot:title>
              <strip-title class="margin-bottom">培训学习信息</strip-title>
            </template>
          </form-list>
          <el-table :data="familyData" stripe border height="300" style="width: 100%">
            <el-table-column prop="name" label="家属名字"/>
            <el-table-column prop="relationship" label="家属关系"/>
            <el-table-column prop="politic" label="政治面貌"/>
            <el-table-column prop="company" label="所在单位"/>
            <el-table-column prop="position" label="单位职务"/>
            <el-table-column label="生日">
              <template #default="scope">
                <div>
                  {{ tools.formatTime(scope.row.startTime) }}
                </div>
              </template>
            </el-table-column>
            <el-table-column v-if="!isLook" label="操作">
              <template #default="scope">
                <el-button
                  size="small"
                  type="danger"
                  @click="wordDelete(scope.row, 'user_study', 3)"
                >删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>

    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, onBeforeMount, reactive, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import StripTitle from '@/components/StripTitle.vue'
import { ElMessage } from 'element-plus'
import store from '@/store'
import ImportFile from '@/viewsManage/components/import-file.vue'

export default defineComponent({
  name: '',
  components: {
    ImportFile,
    StripTitle,
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    // const getRoles = async () => {
    //   const result = await tools.get('/roles/getListByPage')
    //   state.tableColumns[4].list = result.list
    // }

    const state = reactive({
      showPage: true,
      isLook: false,
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      activeName: 'first',
      roleSet: false,
      // 国家地区、性别 sex、籍贯、出生年月、民族、政治面貌、证件类型、证件号码、健康情况、文化程度 education、专长、爱好
      definePropsArr: [
        {
          field: 'name',
          text: '姓名',
          require: true
        }, {
          field: 'jobNum',
          text: '工号',
          require: true
        }, {
          field: 'username',
          text: '账号',
          require: true
        }, {
          field: 'sex',
          text: '性别'
        }, {
          field: 'education',
          text: '学历'
        }, {
          field: 'positionTitle',
          text: '医生职称'
        }, {
          field: 'post',
          text: '岗位'
        }, {
          field: 'duties',
          text: '职位'
        }, {
          field: 'sectionId',
          text: '所属科室'
        }, {
          field: 'majorId',
          text: '所属专业'
        }, {
          field: 'hospital',
          text: '院区'
        }, {
          field: 'mobile',
          text: '手机号码'
        }, {
          field: 'email',
          text: '邮箱'
        }, {
          field: 'personnelType',
          text: '人员类型'
        }, {
          field: 'department',
          text: '所属部门'
        }
      ],
      defineProps: {
        姓名: 'name',
        性别: 'sex',
        账号: 'username',
        工号: 'jobNum',
        学历: 'education',
        人员类型: 'personnelType',
        所属部门: 'department',
        所属科室: 'sectionId',
        所属专业: 'majorId',
        岗位: 'post',
        职务: 'duties',
        院区: 'hospital',
        医生职称: 'positionTitle',
        手机号码: 'mobile',
        邮箱: 'email'
      },
      list: [],
      searchInfo: {
        where: {
          name: {
            _like: '%%'
          }
        }
      }, // 定义搜索条件
      searchData: {}, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'avatar',
          label: '头像',
          type: 'avatar',
          width: 100
        },
        {
          valueKey: 'name',
          label: '姓名',
          width: 120
        },
        {
          valueKey: 'username',
          label: '帐号',
          width: 120
        },
        // {
        //   valueKey: 'roles',
        //   width: 120,
        //   label: '角色',
        //   list: []
        // },
        {
          valueKey: 'mobile',
          width: 120,
          label: '手机号'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // }
      ], // 筛选条件项
      formList: [
        {
          type: 'slot',
          name: 'title'
        },
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '账号',
          key: 'username',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '姓名',
          key: 'name',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'input',
          label: '手机号码',
          key: 'mobile',
          width: '',
          value: '',
          defaultValue: null,
          required: true
        },
        {
          type: 'number',
          label: '职工编号',
          key: 'jobNum',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'select',
          label: '性别',
          key: 'sex',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'sex'
          },
          optionsValue: 'name',
          httpType: 'post',
          defaultValue: []
        },
        {
          type: 'input',
          label: '学历',
          key: 'education',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '国家',
          key: 'country',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '籍贯',
          key: 'native',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '民族',
          key: 'nation',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '政治面貌',
          key: 'politic',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '证件类型',
          key: 'documentType',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '证件号码',
          key: 'documentNum',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '健康情况',
          key: 'healthy',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '专长',
          key: 'expertise',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '爱好',
          key: 'hobby',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'datePiker',
          label: '生日',
          key: 'bornDate',
          width: '',
          value: null,
          defaultValue: '',
          pikerType: 'date'
        },
        {
          type: 'input',
          label: '人员类型',
          key: 'personnelType',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '所属部门',
          key: 'department',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'select',
          url: '/section/getListByPage',
          label: '科室',
          key: 'sectionId',
          width: '',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '岗位',
          key: 'post',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '职务',
          key: 'duties',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '院区',
          key: 'hospital',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '职称',
          key: 'positionTitle',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '邮箱',
          key: 'email',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'datePiker',
          label: '入院年月',
          key: 'intoDate',
          width: '',
          value: null,
          defaultValue: '',
          pikerType: 'date'
        },
        {
          type: 'input',
          label: '教学任务分类',
          key: 'teachingType',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'radio',
          label: '是否职业医师',
          placeholder: '请输入是否职业医师',
          key: 'isPhysician',
          width: '',
          value: '',
          defaultValue: null,
          options: [
            {
              name: '是',
              value: 1
            },
            {
              name: '否',
              value: 0
            }
          ]
        },
        {
          type: 'select',
          label: '专业',
          key: 'majorId',
          url: '/major/getListByPage',
          width: '',
          value: null,
          defaultValue: null
        }
        // {
        //   type: 'select',
        //   multiple: true,
        //   label: '角色',
        //   key: 'roles',
        //   width: '',
        //   url: '/roles/getListByPage',
        //   value: null,
        //   defaultValue: '',
        //   required: true
        // },
        // {
        //   type: 'input',
        //   label: '机构',
        //   key: 'organizationName',
        //   width: '',
        //   value: null,
        //   defaultValue: ''
        // },
        // {
        //   type: 'select',
        //   label: '专业',
        //   key: 'majorId',
        //   url: '/major/getListByPage',
        //   width: '',
        //   value: null,
        //   defaultValue: null
        // }
      ],
      workList: [
        {
          type: 'slot',
          name: 'title'
        },
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'none',
          key: 'userId',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '工作单位',
          key: 'unit',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '工作职位',
          key: 'job',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '工作内容',
          key: 'content',
          width: '',
          value: null,
          defaultValue: ''
        },
        {
          type: 'datePiker',
          label: '开始时间',
          key: 'startTime',
          pikerType: 'date',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'datePiker',
          label: '结束时间',
          key: 'endTime',
          pikerType: 'date',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        }
      ],
      studyList: [
        {
          type: 'slot',
          name: 'title'
        },
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'none',
          key: 'userId',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '学习机构',
          key: 'school',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '学习内容',
          key: 'content',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'datePiker',
          label: '开始时间',
          key: 'startTime',
          pikerType: 'date',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'datePiker',
          label: '结束时间',
          key: 'endTime',
          pikerType: 'date',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        }
      ],
      docList: [
        {
          type: 'slot',
          name: 'title'
        },
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'none',
          key: 'userId',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '证书名字',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '证书号码',
          key: 'number',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'datePiker',
          label: '签发时间',
          key: 'startTime',
          pikerType: 'date',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'uploadImg',
          label: '证件照片',
          key: 'img',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }
      ],
      familyList: [
        {
          type: 'slot',
          name: 'title'
        },
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'none',
          key: 'userId',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '家属名字',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '家属关系',
          key: 'relationship',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'datePiker',
          label: '生日',
          key: 'birthday',
          pikerType: 'date',
          width: '',
          value: null,
          defaultValue: '',
          required: true
        },
        {
          type: 'input',
          label: '政治面貌',
          key: 'politic',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '所在单位',
          key: 'company',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        },
        {
          type: 'input',
          label: '单位职务',
          key: 'position',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }
      ],
      workData: [],
      studyData: [],
      docData: [],
      familyData: [],
      roleList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'select',
          multiple: true,
          label: '角色',
          key: 'roles',
          width: '',
          url: '/roles/getListByPage',
          value: null,
          defaultValue: '',
          required: true
        }
      ],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ],
      currentRow: {
        username: ''
      },
      sections: {},
      majors: {},
      sectionsIds: {},
      majorsIds: {}
    })

    const resetPass = (val) => {
      let flag = false
      val.roleList.forEach(res => {
        if (res.roleCode === 'superadmin') {
          flag = true
        }
      })
      if (flag) {
        tools.msgError('不能重置超级管理员的密码')
        return
      }
      // 不能重置超级管理员的密码;应该是可以重置自己的密码
      tools.post('/user/resetPass', { id: val.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }

    const unLocked = (val) => {
      const loading = tools.showLoading('解锁中...')
      tools.post('/user/updateById', {
        errorNum: 5,
        locked: false,
        id: val.id
      }).then((res) => {
        tools.closeLoading(loading)
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.refresh = true
        }
      })
    }

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.roleSet) {
        data.username = state.currentRow.username
      }
      if (data.bornDate === '') {
        data.bornDate = null
      }
      if (data.intoDate === '') {
        data.intoDate = null
      }
      if (state.pageParams.isEdit) {
        tools.post('/user/updateUserById', data).then(res => {
          if (res.success) {
            ElMessage({
              message: res.msg,
              type: 'success',
              duration: 2 * 1000
            })
            state.pageParams.refresh = true
            state.activeName = 'second'
          }
        })
        return
      }
      delete data.id
      tools.post('/user/createUser', data).then(res => {
        if (res.id.rows) {
          tools.msg(res.msg)
          state.formList[1].value = res.id.rows[0].id
          state.pageParams.refresh = true
          state.activeName = 'second'
        } else {
          tools.msgError('添加失败!')
        }
      })
    }

    const submitWork = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.userId = state.formList[1].value
      delete data.id
      tools.post('/user_work/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          getWorkData()
        }
      })
    }

    const submitStudy = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.userId = state.formList[1].value
      delete data.id
      tools.post('/user_study/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          getStudyData()
        }
      })
    }

    const submitFamily = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.userId = state.formList[1].value
      delete data.id
      tools.post('/user_family/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          getFamilyData()
        }
      })
    }

    const submitDoc = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.userId = state.formList[1].value
      delete data.id
      tools.post('/user_certificate/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          getCertificateData()
        }
      })
    }

    const changeData = async (data) => {
      const majorObj: any = (await tools.getValueObjByHttp('/major/getList')).obj
      const sectionObj: any = (await tools.getValueObjByHttp('/section/getList')).obj
      data.forEach(res => {
        res.majorId = majorObj[res.majorId] || null
        res.sectionId = sectionObj[res.sectionId] || null
      })
      return {
        list: data,
        uniqueKey: 'username'
      }
    }

    const setRole = (row) => {
      state.roleSet = true
      state.currentRow = row
      tools.openDrawer(state.pageParams, true, state.roleList, row)
    }
    const getWorkData = () => {
      tools.post('/user_work/getDataByIdMore', { userId: state.formList[1].value }).then(res => {
        state.workData = res.data
      })
    }
    const getStudyData = () => {
      tools.post('/user_study/getDataByIdMore', { userId: state.formList[1].value }).then(res => {
        state.studyData = res.data
      })
    }
    const getFamilyData = () => {
      tools.post('/user_family/getDataByIdMore', { userId: state.formList[1].value }).then(res => {
        state.familyData = res.data
      })
    }
    const getCertificateData = () => {
      tools.post('/user_certificate/getDataByIdMore', { userId: state.formList[1].value }).then(res => {
        state.docData = res.data
      })
    }
    const handleClick = (data) => {
      if (data.props.label === '工作经历') {
        getWorkData()
      } else if (data.props.label === '培训学习') {
        getStudyData()
      } else if (data.props.label === '证书信息') {
        getCertificateData()
      }
      // 获取数据
    }
    const wordDelete = (data, table, isStudy?) => {
      tools.deleteById(table, data.id, state.pageParams).then(() => {
        if (isStudy === 1) {
          getStudyData()
        } else if (isStudy === 2) {
          getCertificateData()
        } else if (isStudy === 3) {
          getFamilyData()
        } else {
          getWorkData()
        }
      })
    }
    const newAdd = () => {
      state.formList[1].value = null
      state.activeName = 'first'
      state.isLook = false
      tools.openDrawer(state.pageParams)
    }
    const setRow = (scope, bol) => {
      state.activeName = 'first'
      state.isLook = bol
      tools.openDrawer(state.pageParams, true, state.formList, scope.row)
    }
    onBeforeMount(() => {
      const userInfo = store.state.manageUserInfo
      let data: any = {
        where: {}
      }
      if (userInfo.currentRole.roleData.code === 'student') {
        data = {
          where: {
            id: { _eq: userInfo.id }
          }
        }
        state.searchInfo = data
        state.showPage = false
      }
    })
    const search = (searchInfo) => {
      // if (!searchInfo.name) {
      //   state.searchInfo.where.name._like = '%%'
      //   state.pageParams.refresh = true
      // } else {
      //   state.searchInfo.where.name._like = searchInfo.name
      // }
      const data: any = { where: {} }
      for (const [key, value] of Object.entries(searchInfo)) {
        let obj: any = {}
        obj = key === 'name' ? { _like: value } : { _eq: value }
        data.where[key] = obj
      }
      state.searchInfo = data
    }
    const exportFn = () => {
      const arr: any = [...state.list]
      arr.forEach(item => {
        item.sectionId = state.sectionsIds[item.sectionId]
        item.majorId = state.majorsIds[item.majorId]
      })
      tools.writeFile(arr, state.defineProps)
    }

    const getSection = () => {
      tools.get('/section/getListByPage', {
        limit: 999
      }).then(res => {
        const arr = []
        tools.childNo(res.list, arr)
        arr.forEach((s: any) => {
          state.sections[s.name] = s.id
          state.sectionsIds[s.id] = s.name
        })
      })
    }
    const getMajor = () => {
      tools.get('/major/getListByPage', {
        limit: 999
      }).then(res => {
        const arr = []
        tools.childNo(res.list, arr)
        arr.forEach((s: any) => {
          state.majors[s.name] = s.id
          state.majorsIds[s.id] = s.name
        })
      })
    }
    getSection()
    getMajor()

    return {
      ...toRefs(state),
      resetPass,
      // getRoles,
      unLocked,
      submit,
      submitWork,
      submitStudy,
      submitFamily,
      submitDoc,
      search,
      setRole,
      newAdd,
      handleClick,
      wordDelete,
      setRow,
      exportFn,
      changeData,
      tools
    }
  }
})
</script>
