<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" @search="search">
      <template v-slot:left-btn>
        <el-button
          @click="setFn()"
          class="background-btn"
          size="small"
          type="primary"
          plain
        >新增
        </el-button>
        <el-button type="danger" plain size="small" @click="tools.delMultiple('curriculum',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" url="/curriculum/getListByPage" :query-data="searchInfo"
                v-model:refresh="pageParams.refresh">
      <template v-slot="scope">
        <el-button type="text" size="small" @click="setFn(scope)"
        >查看/修改
        </el-button>
        <el-button v-if="tools.isApply(roles)" type="text" size="small" @click="applyFn(scope)"
        >审核
        </el-button>
        <el-button
          type="text"
          size="small"
          @click="tools.deleteById('curriculum', scope['row'].id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-if="apply"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-else
    >
      <form-list :list="applyParam" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '标题',
          width: 180
        },
        {
          valueKey: 'content',
          label: '内容',
          isEllipsis: true
        },
        {
          valueKey: 'teacher',
          label: '讲课人',
          width: 180
        },
        {
          valueKey: 'sequence',
          label: '排序',
          width: 140
        },
        {
          valueKey: 'status',
          width: 120,
          label: '状态',
          flag: true,
          statusLabel: [
            '未审核',
            '已审核'
          ]
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        {
          name: 'isSelect',
          desc: '状态',
          value: 'status',
          placeholder: '请选择选择状态',
          options: [
            {
              id: 0,
              name: '未审核',
              value: 0
            },
            {
              id: 1,
              name: '已审核',
              value: 1
            }
          ]
        }
      ], // 筛选条件项
      apply: false,
      applyParam: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '标题',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '讲课人',
          key: 'teacher',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'textarea',
          label: '内容',
          key: 'content',
          width: '400px',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'uploadImg',
          label: '封面图面',
          placeholder: '请上传图片',
          key: 'cover',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'radio',
          label: '审核',
          placeholder: '请输入图标code',
          key: 'status',
          width: '',
          value: '',
          defaultValue: 1,
          required: true,
          options: [
            {
              name: '同意',
              value: 1
            },
            {
              name: '不同意',
              value: 0
            }
          ]
        }
      ],
      formList: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        }, {
          type: 'input',
          label: '标题',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '讲课人',
          key: 'teacher',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'textarea',
          label: '内容',
          key: 'content',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'uploadImg',
          label: '封面图面',
          placeholder: '请上传图片',
          key: 'cover',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        }
      ],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const resetPass = (val) => {
      tools.post('/curriculum/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        teacher: data.teacher,
        content: data.content,
        code: data.code || '',
        status: data.status || 0,
        typeId: data.typeId,
        cover: data.cover,
        sequence: data.sequence
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/curriculum/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/curriculum/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.status = searchInfo.status
      state.searchInfo.name = searchInfo.name.substring(1, searchInfo.name.length - 1)
    }
    const applyFn = (scope) => {
      state.apply = false
      tools.openDrawer(state.pageParams, true, state.applyParam, scope.row)
    }
    const setFn = (scope) => {
      state.apply = true
      if (scope) {
        tools.openDrawer(state.pageParams, true, state.formList, scope.row)
      } else {
        tools.openDrawer(state.pageParams)
      }
    }
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      applyFn,
      setFn,
      tools
    }
  }
})
</script>
