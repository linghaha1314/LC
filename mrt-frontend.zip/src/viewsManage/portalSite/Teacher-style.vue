<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" @search="search">
      <template v-slot:left-btn>
        <el-button
          @click="setFn()"
          class="background-btn"
          size="small"
          type="primary"
          plain
          v-show="authorization === 'add'"
        >新增老师
        </el-button>
        <el-button type="danger" plain size="small" @click="tools.delMultiple('teacher_style',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" url="/teacher_style/getListByPage" :query-data="searchInfo"
                v-model:refresh="pageParams.refresh">
      <template v-slot:status="data">
        <span v-if="data.row.status===-1" class="font-warning font-bold">未提交</span>
        <span v-if="data.row.status===0" class="font-red font-bold">审核驳回</span>
        <span v-if="data.row.status===2" class="font-red font-bold">禁用</span>
        <span v-if="data.row.status===11" class="font-warning font-bold">待审核</span>
        <span v-if="data.row.status===1" class="font-green font-bold">启用</span>
      </template>
      <template v-slot="scope">
        <el-button v-show="authorization === 'add'" type="primary" size="small" @click="setFn(scope)"
        >查看/修改
        </el-button>
<!--        <el-button type="warning" size="small" @click="applyFn(scope)"-->
<!--        >审核-->
<!--        </el-button>-->
        <Preview :ok-data="scope['row']" is-teacher></Preview>

        <el-button
          type="danger"
          size="small"
          style="margin-left: 10px;"
          @click="tools.deleteById('teacher_style', scope['row'].id,pageParams)"
        >删除
        </el-button>
        <Approval :data="scope" v-model:refresh="pageParams.refresh" table-name="teacher_style" type-code="teacher_style" @approval="approvalFn"></Approval>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-if="apply"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
<!--      <Preview :data="formList" is-teacher></Preview>-->
    </el-drawer>
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-else
    >
      <form-list :list="applyParam" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref, watch, onBeforeMount } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import Preview from '@/viewsManage/components/preview.vue'
import Approval from '@/viewsManage/components/approval.vue'
import router from '@/router'
import { useRoute } from 'vue-router'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList,
    Preview,
    Approval
  },
  setup: () => {
    const state = reactive({
      authorization: '',
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '医生姓名'
        },
        {
          valueKey: 'title',
          label: '职位'
        },
        {
          valueKey: 'typeId',
          label: '栏目类型',
          list: []
        },
        // {
        //   valueKey: 'sectionId',
        //   label: '科室',
        //   list: []
        // },
        {
          valueKey: 'hospital',
          label: '医院'
        },
        // {
        //   valueKey: 'content',
        //   label: '简介',
        //   width: 180,
        //   isEllipsis: true
        // },
        // {
        //   valueKey: 'sequence',
        //   label: '排序',
        //   width: 140
        // },
        {
          valueKey: 'status',
          width: 120,
          label: '状态',
          type: 'slot'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // },
        {
          name: 'isSelect',
          desc: '状态',
          placeholder: '选择状态',
          value: 'status',
          valueKey: 'status',
          defaultValue: null,
          options: [{
            status: null,
            name: '不限制'
          }, {
            status: '-1',
            name: '未提交'
          }, {
            status: '11',
            name: '待审核'
          }, {
            status: '0',
            name: '驳回'
          }, {
            status: '1',
            name: '启用'
          }, {
            status: '2',
            name: '禁用'
          }]
        }
      ], // 筛选条件项
      apply: false,
      applyParam: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '老师姓名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '职位',
          key: 'title',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '医院名字',
          key: 'hospital',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'cascade',
          label: '科室',
          key: 'sectionId',
          width: '',
          value: null,
          url: '/section/getListByPage',
          list: [],
          queryParams: {
            limit: 999
          },
          props: {
            checkStrictly: true,
            label: 'name',
            value: 'id'
          },
          typeList: [],
          defaultValue: ''
        },
        {
          type: 'textarea',
          label: '老师简介',
          key: 'content',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'richText',
          label: '经典事迹',
          placeholder: '请编辑内容',
          key: 'detail',
          url: 'http://localhost:3001/public/upload',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'uploadImg',
          label: '个人照片',
          placeholder: '请上传',
          key: 'photo',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'select',
          label: '栏目类型',
          key: 'typeId',
          width: '',
          value: null,
          url: '/ps_menus/getDataByIdMore',
          queryParams: {
            parentId: '7236f649-bc27-4ce5-82e0-9dbdc388c357'
          },
          httpType: 'post',
          defaultValue: '',
          required: true
        },
        {
          type: 'radio',
          label: '审核',
          placeholder: '请输入图标code',
          key: 'status',
          width: '',
          value: '',
          defaultValue: 1,
          required: true,
          options: [
            {
              name: '同意',
              value: 1
            },
            {
              name: '不同意',
              value: 0
            }
          ]
        }
      ],
      formList: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '老师姓名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '职位',
          key: 'title',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '医院名字',
          key: 'hospital',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'select',
          label: '科室',
          key: 'sectionId',
          width: '',
          value: null,
          url: '/section/getListByPage',
          list: [],
          queryParams: {
            limit: 999
          },
          props: {
            checkStrictly: true,
            label: 'name',
            value: 'id'
          },
          typeList: [],
          defaultValue: ''
        },
        {
          type: 'textarea',
          label: '老师简介',
          key: 'content',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'richText',
          label: '经典事迹',
          placeholder: '请编辑内容',
          key: 'detail',
          url: 'http://localhost:3001/public/upload',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'uploadImg',
          label: '个人照片',
          placeholder: '请上传',
          key: 'photo',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'select',
          label: '栏目类型',
          key: 'typeId',
          width: '',
          value: null,
          url: '/ps_menus/getDataByIdMore',
          queryParams: {
            parentId: '7236f649-bc27-4ce5-82e0-9dbdc388c357'
          },
          httpType: 'post',
          defaultValue: '',
          required: true
        }
      ],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    watch(() => router.currentRoute.value.query, (newValue: any) => {
      state.authorization = newValue.code
    })
    const getType = async (num) => {
      const result = await tools.post('/ps_menus/getDataByIdMore', {
        parentId: '7236f649-bc27-4ce5-82e0-9dbdc388c357'
      })
      state.tableColumns[num].list = result.data
    }
    // const getSection = async (num) => {
    //   const result = await tools.get('/section/getListByPage', {
    //     limit: 999
    //   })
    //   state.tableColumns[num].list = result.list
    // }
    // getSection(4)
    getType(3)
    const resetPass = (val) => {
      tools.post('/teacher_style/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        content: data.content,
        code: data.code || '',
        status: data.status || -1,
        detail: data.detail,
        title: data.title,
        hospital: data.hospital,
        photo: data.photo,
        typeId: data.typeId,
        sectionId: data.sectionId,
        sequence: data.sequence
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/teacher_style/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/teacher_style/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.status = searchInfo.status
      searchInfo.name && (state.searchInfo.name = searchInfo.name.indexOf('undefined') > -1 || searchInfo.name.length === 2 ? null : searchInfo.name.substring(1, searchInfo.name.length - 1))
    }
    const applyFn = (scope) => {
      state.apply = false
      tools.openDrawer(state.pageParams, true, state.applyParam, scope.row)
    }
    const setFn = (scope) => {
      state.apply = true
      if (scope) {
        tools.openDrawer(state.pageParams, true, state.formList, scope.row)
      } else {
        tools.openDrawer(state.pageParams)
      }
    }
    const approvalFn = () => {
      state.pageParams.refresh = true
    }
    onBeforeMount(() => {
      const route = useRoute()
      const parma: any = route.query
      state.authorization = parma.code || ''
    })
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      applyFn,
      setFn,
      approvalFn,
      tools
    }
  }
})
</script>
