<template>
  <div class="users-manage">
    <!-- 筛选条件 -->
    <search-class :searchInit="searchInit" v-model:refresh="pageParams.refresh" @search="search">
      <template v-slot:left-btn>
        <el-button
          @click="setFn()"
          class="background-btn"
          size="small"
          type="primary"
          plain
        >新增
        </el-button>
        <el-button type="danger" plain size="small" @click="tools.delMultiple('image_set',selection,pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:selection="selection" :columns="tableColumns" url="/image_set/getListByPage" :query-data="searchInfo"
                v-model:refresh="pageParams.refresh">
      <template v-slot="scope">
        <el-button type="primary" size="small" @click="setFn(scope)"
        >查看/修改
        </el-button>
<!--        <el-button v-if="tools.isApply(roles)" type="text" size="small" @click="applyFn(scope)"-->
<!--        >审核-->
<!--        </el-button>-->
        <el-button
          type="danger"
          size="small"
          @click="tools.deleteById('image_set', scope['row'].id,pageParams)"
        >删除
        </el-button>
      </template>
    </table-list>
    <!-- 编辑弹窗 -->
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-if="apply"
    >
      <form-list :list="formList" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
    <el-drawer
      title="详细信息"
      v-model="pageParams.isDrawer"
      direction="rtl"
      :append-to-body="false"
      :destroy-on-close="true"
      size="40%"
      v-else
    >
      <form-list :list="applyParam" :isEdit="pageParams.isEdit" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, toRefs, reactive, ref } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    FormList,
    SearchClass,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {
        status: null,
        name: null
      }, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '图片',
          width: 180
        },
        {
          valueKey: 'path',
          label: '路径'
        },
        {
          valueKey: 'typeId',
          label: '栏目类型',
          list: []
        },
        {
          valueKey: 'sequence',
          label: '排序',
          width: 140
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [
        // {
        //   name: 'isSelect',
        //   desc: '专业',
        //   value: 'searchProfession', // 返回值的名称
        //   placeholder: '请选择选择专业',
        //   options: []
        // },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   value: 'searchDepartment',
        //   placeholder: '请选择选择科室',
        //   options: []
        // },
        {
          name: 'isSelect',
          desc: '状态',
          value: 'status',
          placeholder: '请选择选择状态',
          options: [
            {
              id: 0,
              name: '未审核',
              value: 0
            },
            {
              id: 1,
              name: '已审核',
              value: 1
            }
          ]
        }
      ], // 筛选条件项
      apply: false,
      applyParam: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '老师姓名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '职位',
          key: 'title',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'input',
          label: '医院名字',
          key: 'hospital',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        {
          type: 'textarea',
          label: '老师简介',
          key: 'content',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },
        // {
        //   type: 'input',
        //   label: '编码',
        //   key: 'code',
        //   width: '',
        //   value: null,
        //   required: true,
        //   defaultValue: ''
        // },
        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'richText',
          label: '经典事迹',
          placeholder: '请编辑内容',
          key: 'detail',
          url: 'http://localhost:3001/public/upload',
          width: '',
          value: '',
          required: true,
          defaultValue: ''
        },
        {
          type: 'uploadImg',
          label: '个人照片',
          placeholder: '请上传',
          key: 'photo',
          width: '',
          value: '',
          defaultValue: ''
        },
        {
          type: 'select',
          label: '栏目类型',
          key: 'typeId',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'Image-set'
          },
          httpType: 'post',
          defaultValue: '',
          required: true
        },
        {
          type: 'radio',
          label: '审核',
          placeholder: '请输入图标code',
          key: 'status',
          width: '',
          value: '',
          defaultValue: 1,
          required: true,
          options: [
            {
              name: '同意',
              value: 1
            },
            {
              name: '不同意',
              value: 0
            }
          ]
        }
      ],
      formList: [
        {
          label: '索引',
          key: 'id',
          value: null,
          defaultValue: null
        },
        {
          type: 'input',
          label: '图片名字',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        },

        {
          type: 'input',
          label: '顺序',
          placeholder: '请输入顺序',
          key: 'sequence',
          width: '',
          value: '',
          required: true,
          defaultValue: null
        },
        {
          type: 'uploadImg',
          label: '图片文件',
          placeholder: '请上传',
          key: 'path',
          width: '',
          value: '',
          defaultValue: '',
          required: true
        },
        {
          type: 'select',
          label: '栏目类型',
          key: 'typeId',
          width: '',
          value: null,
          url: '/dictionaryData/getByTypeCode',
          queryParams: {
            typeCode: 'Image-set'
          },
          httpType: 'post',
          defaultValue: '',
          required: true
        },
        {
          type: 'input',
          label: '跳转地址',
          key: 'url',
          width: '',
          value: null,
          defaultValue: null
        }
      ],
      roles: [
        'superadmin',
        'ColumnAdministrator',
        'PlatformAdministrator'
      ]
    })
    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          console.log(111111)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })
    const getType = async (num, code) => {
      const result = await tools.post('/dictionaryData/getByTypeCode', {
        typeCode: code
      })
      state.tableColumns[num].list = result.list
    }
    getType(3, 'Image-set')
    const resetPass = (val) => {
      tools.post('/image_set/resetPass', { id: val.data.id }).then((res) => {
        if (res.success) {
          tools.msg(res.msg)
        }
      })
    }
    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        // status: data.status || 0,
        typeId: data.typeId,
        path: data.path,
        url: data.url || '',
        sequence: data.sequence
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/image_set/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      tools.post('/image_set/create', obj).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }
    const search = (searchInfo) => {
      state.searchInfo.status = searchInfo.status
      state.searchInfo.name = (searchInfo.name && searchInfo.name.substring(1, searchInfo.name.length - 1)) || ''
    }
    const applyFn = (scope) => {
      state.apply = false
      tools.openDrawer(state.pageParams, true, state.applyParam, scope.row)
    }
    const setFn = (scope) => {
      state.apply = true
      if (scope) {
        tools.openDrawer(state.pageParams, true, state.formList, scope.row)
      } else {
        tools.openDrawer(state.pageParams)
      }
    }
    return {
      searchData,
      ...toRefs(state),
      resetPass,
      submit,
      search,
      applyFn,
      setFn,
      tools
    }
  }
})
</script>
