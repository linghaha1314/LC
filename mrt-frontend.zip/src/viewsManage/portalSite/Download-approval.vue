<template>
  <div class="course-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <!--        <el-button plain size="small" type="danger">批量审批-->
        <!--        </el-button>-->
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="columns" http-type="post"
                :queryData="queryData"
                url="/process/getCourseByRoleId">
      <template v-slot:courseStatus="data">
        <span v-if="data.row['courseStatus']===-1" class="font-warning font-bold">未提交</span>
        <span v-if="data.row['courseStatus']===0" class="font-red font-bold">审核驳回</span>
        <span v-if="data.row['courseStatus']===11" class="font-warning font-bold">待审核</span>
        <span v-if="data.row['courseStatus']===1" class="font-green font-bold">审核通过</span>
      </template>
      <template v-slot="scope">
        <el-button type="warning" size="small" @click="openApprovalDialog(scope.row)"
        >审核
        </el-button>
<!--        <el-tooltip content="审批" placement="bottom">-->
<!--          <el-button-->
<!--            :icon="Reading"-->
<!--            circle-->
<!--            size="small"-->
<!--            type="warning"-->
<!--            @click="openApprovalDialog(scope.row)"-->
<!--          >-->
<!--          </el-button>-->
<!--        </el-tooltip>-->
      </template>
      <template v-slot:status="scope">
        <span v-if="scope.row.status===0" class="font-red font-bold">已驳回</span>
        <span v-if="scope.row.status===11" class="font-warning font-bold">待审核</span>
        <span v-if="scope.row.status===1" class="font-green font-bold">已同意</span>
      </template>
    </table-list>
  </div>
  <el-dialog
    v-model="isApprovalDialog"
    destroy-on-close top="10vh">
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>审批</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <div m="4">
      <Preview :data-ok="currentCourse"></Preview>
      <strip-title class="margin-bottom">课程审批进度</strip-title>
      <div>
        <el-steps align-center>
          <el-step v-for="item of approvalList" :key="item.id"
                   :description="item.status===11?'待审核':(item.status===1?'通过✅':'驳回❌')"
                   :title="item['roleName']"></el-step>
        </el-steps>
      </div>
      <strip-title class="margin-bottom" v-if="currentCourse.status===11">审批意见</strip-title>
      <p class="padding-end padding-start" v-if="currentCourse.status===11">
        <el-input
          v-model="remark"
          :rows="3"
          placeholder="请输入审批意见"
          type="textarea"
        />
      </p>
    </div>
    <div v-if="currentCourse.status===11">
      <el-button class="margin-start" type="danger" @click="agree(0)">不同意</el-button>
      <el-button class="margin-end" type="success" @click="agree(1)">同意</el-button>
    </div>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, getCurrentInstance, onMounted, reactive, ref, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import { ElForm } from 'element-plus'
import TableList from '@/viewsManage/components/TableList.vue'
import StripTitle from '@/components/StripTitle.vue'
import Preview from '@/viewsManage/components/preview.vue'
import { Finished, Reading, Tools, View } from '@element-plus/icons'
import store from '@/store'
import { Check, Delete, Edit } from '@element-plus/icons-vue'

export default defineComponent({
  components: {
    TableList,
    SearchClass,
    StripTitle,
    Preview
  },
  setup: () => {
    const { proxy }: any = getCurrentInstance()

    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      queryData: {
        roleId: store.state.manageUserInfo.currentRole.roleId,
        status: 11,
        typeCode: 'file',
        staffId: store.state.manageUserInfo.id,
        name: ''
      },
      remark: '', // 审批意见
      approvalList: [], // 审批进度
      fileList: [], // 文件
      courseTypeList: [],
      selection: [],
      tagList: [],
      currentCourse: {},
      source: null,
      isApprovalDialog: false, // 审批进度查看
      isVerifyDialog: false,
      lecturerList: [], // 主讲人列表
      searchInfo: {},
      searchInit: [
        {
          name: 'isSearch',
          desc: '关键词',
          placeholder: '请输入内容',
          value: 'search'
        }, {
          name: 'isSelect',
          desc: '状态',
          placeholder: '选择状态',
          value: 'status',
          valueKey: 'status',
          defaultValue: '11',
          isNotClearable: true,
          options: [{
            status: '11',
            name: '待审核'
          }, {
            status: '0',
            name: '驳回'
          }, {
            status: '1',
            name: '已经审核'
          }
          ]
        }
      ], // 筛选条件项
      verifyList: [],
      columns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'objectName',
          label: '内容名称'
        },
        {
          valueKey: 'created',
          label: '申请时间',
          type: 'time'
        }, {
          valueKey: 'status',
          type: 'slot',
          label: '状态' // 显示课程正在审核状态,未提交状态！
        }],
      formList: [{
        type: 'slot',
        name: 'basic'
      }, {
        type: 'none',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '课程名',
        key: 'courseName',
        width: '',
        value: null,
        required: true,
        defaultValue: ''
      }, {
        type: 'cascade',
        label: '课程类型',
        key: 'typeId',
        width: '',
        value: null,
        url: '/courseType/getListByPage',
        queryParams: { limit: 1000 },
        defaultValue: [],
        required: true
      }, {
        type: 'cascade',
        label: '课程栏目',
        key: 'columnId',
        width: '',
        value: null,
        list: [],
        defaultValue: [],
        required: true
      }, {
        type: 'select',
        label: '主讲人',
        url: '/user/getListByPage',
        searchKey: 'name',
        // queryParams: {
        //   roleType: ''
        // },
        key: 'lecturerId',
        width: '',
        value: null,
        defaultValue: null
      }, {
        type: 'uploadImg',
        label: '课程封面',
        key: 'img',
        width: '',
        value: null,
        required: true,
        defaultValue: ''
      }, {
        type: 'textarea',
        label: '课程介绍',
        key: 'introduce',
        width: '100',
        value: null,
        defaultValue: ''
      }, {
        type: 'richText',
        label: '课程简介',
        key: 'brief',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'number',
        label: '课程学分',
        key: 'credits',
        width: '',
        value: '',
        defaultValue: null
      }, {
        type: 'slot',
        name: 'files'
      }, {
        type: 'slot',
        name: 'verify'
      }],
      verifyRadioList: []
    })

    const formRef = ref(ElForm)

    const rules = reactive({
      name: [
        {
          required: true,
          message: '请输入课程名称',
          trigger: 'blur'
        }
      ]
    })

    const agree = async (status) => {
      // 修改当前审批流程的人员
      const obj = {
        approvalProcessId: (state.currentCourse as any).approvalProcessId,
        status,
        remark: state.remark,
        approvalStaffId: store.state.manageUserInfo.id,
        roleId: store.state.manageUserInfo.currentRole.roleId,
        workflowId: (state.currentCourse as any).workflowId,
        objectId: (state.currentCourse as any).objectId,
        tableName: 'file'
      }
      tools.post('/process/agree', obj).then(r => {
        if (r.success) {
          tools.msg(r.msg)
          state.isApprovalDialog = false
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      state.queryData = {
        ...state.queryData,
        status: searchInfo.status || 11,
        name: searchInfo.name
      }
    }

    const changeSource = (val) => {
      state.source = val.path || val.video
    }

    const checkApprovalProcess = (val) => {
      state.isApprovalDialog = true
      // 获取审批进度列表；
      tools.post('/workflowStart/getStepDetailList', {
        workflowId: val.workflowId,
        approvalProcessId: val.approvalProcessId
      }).then(r => {
        state.approvalList = r.list
      })
    }

    const openApprovalDialog = (val) => {
      state.currentCourse = val.status === 11 ? val : val.objectData
      // state.source = val.objectData?.path || val.objectData?.video || ''
      state.isApprovalDialog = true
      checkApprovalProcess(val)
      // tools.get('/courseVerify/getListByPage', {
      //   courseId: val.id,
      //   sort: 'time asc'
      // }).then(r => {
      //   state.verifyList = r.list
      //   state.isVerifyDialog = true
      // })
    }

    const getCourseType = () => {
      tools.get('/courseType/getListByPage', { limit: 1000 }).then(r => {
        state.courseTypeList = r.list
      })
    }

    const getHomeColumns = async () => {
      await tools.get('/homeColumns/getDataList', {}).then(r => {
        state.formList[4].list = r.list
      })
    }

    onMounted(async () => {
      getCourseType()
      await getHomeColumns()
      tools.post('/dictionaryData/getByTypeCode', { typeCode: 'videoVerify' }).then(r => {
        state.verifyRadioList = r.list
      })
    })

    return {
      rules,
      formRef,
      proxy,
      store,
      Check,
      Delete,
      Edit,
      Finished,
      View,
      Reading,
      Tools,
      ...toRefs(state),
      search,
      agree,
      getCourseType,
      changeSource,
      getHomeColumns,
      openApprovalDialog,
      checkApprovalProcess
    }
  }
})
</script>

<style lang="less">
.course-manage-dialog-content-wrapper {
  height: 100% !important;
  margin: 0 !important;
  overflow-y: auto;
}
</style>
