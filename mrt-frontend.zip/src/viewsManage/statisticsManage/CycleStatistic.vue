<template>
  <div v-loading="state.loading">
    <div class="flex align-center">
      <search-class :is-show-export-btn="true"
                    :isShowReset="true"
                    :isHideRight="true"
                    :searchInit="state.searchInit" @search="search">
      </search-class>
    </div>
    <el-row>
      <el-col :span="8" class="flex justify-content align-center column">
        <p>学习人数(人)</p>
        <p class="font-bold">{{ state.rangeData.staffNum }}</p>
      </el-col>
      <el-col :span="8" class="flex justify-content align-center column">
        <p>学习总时长(时)</p>
        <p class="font-bold">{{ state.rangeData.studyTime }}</p>
      </el-col>
      <el-col :span="8" class="flex justify-content align-center column">
        <p>学习课程数(门)</p>
        <p class="font-bold">{{ state.rangeData.courseNum }}</p>
      </el-col>
    </el-row>
    <!--折线图-->
    <div class="flex ">
      <div style="flex:1;height: 700px">
        <div id="courses" style="height: 600px" v-loading="state.byStudyTimeX || state.byCreditsDataX"></div>
      </div>
      <!--      <div style="flex:1;height: 600px">-->
      <!--        <div id="date-range-line" style="flex:1;height: 500px"></div>-->
      <!--      </div>-->
    </div>
    <div class="flex">
      <div style="flex:1;height: 400px" id="sections" v-loading="state.byStudyTimeX || state.byCreditsDataX"></div>
      <div style="flex:1;height: 400px" id="staffs" v-loading="state.byStudyTimeX || state.byCreditsDataX"></div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { onMounted, reactive } from 'vue'
import * as echarts from 'echarts'
import tools from '@/utils/tool'
import SearchClass from '@/viewsManage/components/SearchClass.vue'

const searchInfo: any = reactive({
  sectionId: '',
  dateSelect: ''
})

const getCourse = async () => {
  await tools.post('/courseStatistic/getCourseStatistic', { limit: state.limit }).then(r => {
    const obj = {
      courses: [],
      collect: [],
      playRate: [],
      completeRate: [],
      comments: []
    }
    r.list.forEach(res => {
      obj.courses.push(res.name)
      obj.collect.push(res.collect)
      obj.comments.push(res.comment)
      obj.playRate.push(res.studyStaffNum)
      obj.completeRate.push(res.completeStaffNum)
    })
    data.courses.yData = obj.courses.reverse()
    data.courses.series = [{
      name: '收藏数',
      type: 'bar',
      data: obj.collect.reverse()
    }, {
      name: '评论数',
      type: 'bar',
      data: obj.comments.reverse()
    }, {
      name: '播放数',
      type: 'bar',
      data: obj.playRate.reverse()
    }, {
      name: '完播数',
      type: 'bar',
      data: obj.completeRate.reverse()
    }]
  })
}

const data: any = reactive({
  dateLine: {
    id: 'date-range-line',
    type: 'line',
    title: '周期趋势学习',
    xData: [],
    series: [{
      data: [],
      type: 'line'
    }]
  },
  courses: {
    id: 'courses',
    type: 'bar',
    title: '热门课程',
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      nameTextStyle: {
        padding: [30, 0, 0, -10]
      },
      type: 'value',
      boundaryGap: [0, 0.01]
    },
    xData: [],
    yData: [],
    series: []
  },
  sections: {
    id: 'sections',
    type: 'bar',
    title: '部门学习情况',
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      nameTextStyle: {
        padding: [30, 0, 0, -10]
      },
      type: 'value',
      boundaryGap: [0, 0.01]
    },
    xData: [],
    yData: [],
    series: [{
      name: '看课数',
      type: 'bar',
      data: []
    }, {
      name: '学分',
      type: 'bar',
      data: []
    }, {
      name: '时长(时)',
      type: 'bar',
      data: []
    }
    ]
  },
  staffs: {
    id: 'staffs',
    type: 'bar',
    title: '学员学习情况',
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      nameTextStyle: {
        padding: [30, 0, 0, -10]
      },
      type: 'value',
      boundaryGap: [0, 0.01]
    },
    xData: [],
    yData: [],
    series: [{
      name: '看课数',
      type: 'bar',
      data: []
    }, {
      name: '学分',
      type: 'bar',
      data: []
    }]
  }
})

const state = reactive({
  sections: [],
  sectionList: [],
  time: '', // 时间duration
  activeType: 'week',
  byType: 'byStudyTime',
  value1: '',
  searchInit: [
    {
      name: 'isSelect',
      desc: '科室',
      placeholder: '输入远程搜索科室',
      url: '/section/getListByPage',
      queryParams: { limit: 100 },
      value: 'sectionId'
    }, {
      name: 'daterange',
      desc: '时间周期',
      placeholder: '选择时间',
      value: 'time'
    }
  ],
  rangeData: {} as any,
  byCreditsDataX: [] as string[],
  byStudyTimeX: [] as string[],
  byCreditsDataY: [] as number[],
  byStudyTimeY: [] as number[],
  searchInfo: {
    searchMonth: '',
    searchName: '',
    select: '',
    search: ''
  }, // 查询结果
  loading: true,
  limit: 10
})

const getStaffs = async () => {
  await tools.post('/staff/getStudyListByPage', {
    limit: state.limit
  }).then(r => {
    const courseNum = []
    const credits = []
    const studyTotalTime = []
    const staffs = []
    r.list.forEach(res => {
      staffs.push(res.staffName)
      courseNum.push(res.watchNum)
      credits.push(res.credits)
      studyTotalTime.push(res.studyTotalTime)
    })
    data.staffs.yData = staffs.reverse()
    data.staffs.series = [{
      name: '看课数',
      type: 'bar',
      data: courseNum.reverse()
    }, {
      name: '学分',
      type: 'bar',
      data: credits.reverse()
    }, {
      name: '时长(时)',
      type: 'bar',
      data: studyTotalTime.reverse()
    }
    ]
  })
}

const getSections = async () => {
  await tools.post('/sectionStatistic/getTableList', { limit: 10 }).then(r => {
    state.sections = r.list.slice(0, 10)
    // 修改数据；排序
    const obj = {
      sections: [],
      courseNum: [],
      credits: [],
      time: []
    }
    state.sections.forEach(res => {
      obj.sections.push(res.name)
      obj.courseNum.push(res.courseNum)
      obj.credits.push(res.creditsNum)
      obj.time.push(res.studyTimeNum)
    })
    data.sections.yData = obj.sections.reverse()
    data.sections.series = [{
      name: '看课数',
      type: 'bar',
      data: obj.courseNum.reverse()
    }, {
      name: '学分',
      type: 'bar',
      data: obj.credits.reverse()
    }, {
      name: '时长(时)',
      type: 'bar',
      data: obj.time.reverse()
    }
    ]
  })
}

const getData = async () => {
  state.loading = true
  await tools.get('/staff/getStatistic', { limit: state.limit }).then(r => {
    r.byCredits.forEach((res: any) => {
      state.byCreditsDataX.push(res.name)
      state.byCreditsDataY.push(res.credits)
    })
    r.byStudyTime.forEach((res: any) => {
      state.byStudyTimeX.push(res.name)
      state.byStudyTimeY.push(res.studyTime)
    })
  })
}

const search = (e) => {
  const where = {}
  if (e.sectionId) {
    where.user = {
      section_id: {
        _eq: e.sectionId
      }
    }
  }
  if (e.time && e.time.length > 0) {
    where.date = {
      _gte: tools.formatTime(e.time[0]),
      _lte: tools.formatTime(e.time[1])
    }
  }
  getDateRangeData(where)
}

const getDateRangeData = async (where = {}) => {
  await tools.post('/todayStudy/getDateRangeData', { where: where }).then(r => {
    state.rangeData = r.data
    data.dateLine.xData = r.data.timeList
    data.dateLine.series = [
      //   {
      //   name: '学习课程数',
      //   type: 'line',
      //   stack: 'Total',
      //   data: r.data.courseList
      // },
      {
        name: '学习人数',
        type: 'line',
        stack: 'Total',
        data: r.data.staffList
      }]
    initData()
  })
}

const getStudyNumArr = (data) => {
  const list = []
  const nums = []
  let sum = 0
  if (data.length === 0) {
    return {
      list,
      nums
    }
  }
  let lastDate = data[0].date
  data.forEach(res => {
    if (res.date !== lastDate) {
      lastDate = res.date
      list.push(res.date)
      nums.push(sum)
      sum = 0
    } else {
      sum++
    }
  })
  return {
    list,
    nums
  }
}

const setDateXArr = (dateArr) => {
  const startDays = new Date(dateArr[0]).getTime()
  const endDays = new Date(dateArr[1]).getTime()
  const arr: any = [tools.formatTime(new Date(dateArr[0]))]
  for (let i = 1; i < 10; i++) {
    const date = tools.formatTime(new Date(new Date(dateArr[0]).getTime() + ((endDays - startDays) / 9) * i))
    arr.push(date)
  }
  return arr
}

const getPie = () => {
  // 根据时间周期，平均分配时间节点！
  const dom: any = document.getElementById('echarts')
  const myChart = echarts.init(dom)
  // 绘制折线图
  myChart.setOption({
    title: {
      text: '折线图堆叠'
    },
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      color: ['green', 'blue'],
      data: [
        {
          name: '个人用户',
          icon: 'circle'
        },
        {
          name: '机构用户',
          icon: 'circle'
        }
      ]
    },
    grid: {
      // 图表的靠左靠右
      left: '4%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    toolbox: {
      feature: {
        saveAsImage: {}
      }
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: ['11-1', '11-3', '11-4', '11-5', '11-6', '11-7', '11-8']
    },
    yAxis: {
      type: 'value'
    },
    series: [
      {
        name: '个人用户',
        type: 'line',
        stack: '总量',
        data: [120, 132, 101, 134, 90, 230, 210]
      },
      {
        name: '机构用户',
        type: 'line',
        stack: '总量',
        data: [220, 182, 191, 234, 290, 330, 310]
      }
    ]
  })
}

const setBar = (data) => {
  const chartDom = document.getElementById(data.id)!
  const myChart = echarts.init(chartDom)

  const option = {
    title: {
      text: data.title
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {},
    grid: data.grid,
    xAxis: data.xAxis,
    yAxis: {
      type: 'category',
      data: data.yData
    },
    series: data.series
  }
  option && myChart.setOption(option)
}

const setLine = (data) => {
  const chartDom = document.getElementById(data.id)!
  const myChart = echarts.init(chartDom)
  const option = {
    title: {
      text: data.title,
      left: 'center'
    },
    xAxis: {
      type: 'category',
      data: data.xData,
      boundaryGap: false
    },
    yAxis: {
      type: 'value'
    },
    tooltip: {
      trigger: 'axis'
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    series: data.series
  }
  option && myChart.setOption(option)
}

const initData = () => {
  Object.values(data).forEach((res: any) => {
    if (res.type === 'bar') {
      setBar(res)
    } else {
      // setLine(res)
    }
  })
}

onMounted(async () => {
  await getDateRangeData()
  await getSections()
  await getStaffs()
  await getData()
  await getCourse()
  initData()
  state.loading = false
})
</script>

<style lang="less" scoped>
.users-statistic {
  .cards-box {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .card {
      flex: 1;

      &:last-child {
        flex: 2;
      }
    }
  }

  .echarts-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 20px 0;
  }
}
</style>
