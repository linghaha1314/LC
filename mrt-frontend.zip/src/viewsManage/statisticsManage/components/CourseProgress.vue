<template>
  <div class="course-progress">
    <div class="sort-num">
      <p>1</p>
    </div>
    <div class="course-name">《zuixiuasf》</div>
    <div class="progress-box">
      <el-progress :percentage="50" color="#1edfaf"></el-progress>
    </div>
    <div class="data-box" :style="{ color: color }">354</div>
  </div>
</template>
<script>
export default {
  data () {
    return {
      color: 'red'
    }
  }
}
</script>
<style lang="less" scoped>
.course-progress {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  .sort-num {
    flex: 2;
    p {
      width: 14px;
      height: 14px;
      color: #ffffff;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  }
  .course-name {
    flex: 8;
  }
  .progress-box {
    flex: 7;
  }
  .data-box {
    flex: 2;
  }
}
</style>
