<template>
  <el-card class="stastic-card">
    <div class="title">
      <slot name="top"></slot>
    </div>
    <div class="content">
      <slot name="content"></slot>
    </div>
    <div class="bottom" v-if="isShowBottom">
      <div class="bottom-inner">
        <slot name="bottom"></slot>
      </div>
    </div>
  </el-card>
</template>
<script>
export default {
  data () {
    return {}
  },
  props: {
    isShowBottom: {
      type: Boolean,
      default: true
    }
  }
}
</script>
<style lang="less" scoped>
@import "~@/assets/css/manage.less";
// @import (once) "~@/assets/css/manage.less";

.stastic-card {
  flex: 1;
  margin: 0 10px;
  height: 165px;
  padding: 20px 20px 0px 20px;
  position: relative;
  /deep/.el-card__body {
    width: 100%;
  }
  .title {
    display: flex;
    justify-content: space-between;
    font-weight: bold;
    color: #666;
    height: 30px;
  }
  .content {
    height: 110px;
    font-size: 30px;
    font-weight: bold;
  }
  .bottom {
    height: 30px;
    line-height: 30px;
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
    padding: 0 20px;
    box-sizing: border-box;
    margin-bottom: 5px;
    .bottom-inner {
      height: 100%;
      width: 100%;
      border-top: 2px solid #eeeeee;
    }
  }
}
</style>
