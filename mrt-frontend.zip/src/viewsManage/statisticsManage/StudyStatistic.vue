<template>
  <div class="study-statistic">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="queryParams.refresh"
                  :is-show-export-btn="true"
                  @exportAll="exportAll"
                  :isShowReset="true"
                  :searchInit="searchInit" @search="search"
                  v-model:tableColumns="tableColumns" :list="dataList" placeholder="搜索学生姓名">
      <template v-slot:left-btn>
        <el-button size="small" type="primary" @click="exportCurrentPage">导出当页</el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="queryParams.refresh" v-model:columns="tableColumns"
                http-type="post"
                v-model:list="dataList" :queryData="queryData"
                url="/staff/getStudyListByPage">
      <template v-slot:mustBeNum="scope">
        <span style="text-decoration: underline;" class="cursor-point"
              @click="showMustBeCourseList(scope.row,'mustBeNum')">{{
            scope.row.mustBeCourseList.length || 0
          }}</span>
      </template>
      <template v-slot:completeNum="scope">
        <span style="text-decoration: underline;" class="cursor-point"
              @click="showMustBeCourseList(scope.row,'completeNum')">{{
            scope.row.completeNum
          }}</span>
      </template>
      <template v-slot:watchNum="scope">
        <span style="text-decoration: underline;" class="cursor-point"
              @click="showMustBeCourseList(scope.row,'watchNum')">{{
            scope.row.watchNum
          }}</span>
      </template>
    </table-list>
  </div>
  <el-dialog v-model="isShowMustBe" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>应学习课程</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <li class="margin-bottom" v-for="(item,index) in currentMustBe.mustBeCourseList" :key="item.id">{{
      index + 1
      }}.{{ item.name }}---
      <span v-if="item.isCompleted" class="font-green">已完成</span>
      <span v-else class="font-orange">未完成</span>
    </li>
  </el-dialog>
  <el-dialog v-model="isShowWatch" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>观看记录</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <li class="margin-bottom" v-for="(item,index) in currentMustBe" :key="item.course_id">{{
      index + 1
      }}.{{ item.watchData.name }}---
      <span v-if="item.course_completed" class="font-green">已完成</span>
      <span v-else class="font-orange">未完成</span>
    </li>
  </el-dialog>
  <el-dialog v-model="isShowCompleteCourse" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>已完成课程</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <li class="margin-bottom" v-for="(item,index) in currentMustBe" :key="item.id">{{
      index + 1
      }}.{{ item.name }}---
      <span class="font-green">已完成</span>
    </li>
  </el-dialog>
</template>

<script lang="ts">
import tools from '@/utils/tool'
import { defineComponent, onMounted, reactive, toRefs } from 'vue'
import TableList from '@/viewsManage/components/TableList.vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'

export default defineComponent({
  components: {
    TableList,
    SearchClass
  },
  setup: () => {
    const state = reactive({
      dataList: [],
      currentMustBe: {},
      isShowCompleteCourse: false,
      isShowMustBe: false,
      isShowWatch: false,
      tableColumns: [
        {
          valueKey: 'staffName',
          label: '学生'
        },
        {
          valueKey: 'jobNum',
          label: '工号'
        },
        {
          valueKey: 'positionTitle',
          label: '职称'
        },
        {
          valueKey: 'sectionName',
          label: '科室'
        },
        {
          valueKey: 'mustBeNum',
          label: '应完成课程数',
          type: 'slot'
        },
        {
          valueKey: 'completeNum',
          label: '已完成课程数',
          type: 'slot'
        }, {
          valueKey: 'watchNum',
          label: '总看课数',
          type: 'slot'
        },
        {
          type: 'studyTime',
          valueKey: 'todayStudyTime',
          label: '周期学习总时长（时）'
        }, {
          type: 'studyTime',
          valueKey: 'studyTotalTime',
          label: '学习总时长（时）'
        },
        {
          valueKey: 'credits',
          label: '获取学分'
        }],
      queryParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      queryData: {
        where: {
          name: { _like: '%%' }
        }
      } as any,
      searchInfo: {},
      searchInit: [
        {
          name: 'isSearch',
          desc: '关键词',
          placeholder: '请输入内容',
          value: 'name'
        },
        {
          name: 'isSelect',
          desc: '科室',
          placeholder: '输入远程搜索科室',
          url: '/section/getListByPage',
          queryParams: { limit: 100 },
          value: 'sectionId'
        },
        // {
        //   name: 'isSelect',
        //   desc: '职称',
        //   placeholder: '远程搜索人员职称',
        //   queryParams: { limit: 100 },
        //   value: 'majorId'
        // },
        {
          name: 'isSelect',
          desc: '参与课程',
          placeholder: '输入远程搜索参与的课程',
          value: 'courseId',
          httpType: 'post',
          searchKey: 'name',
          isInWhereName: true,
          url: '/courses/getDataListByPage',
          queryParams: {
            limit: 100,
            where: {
              status: { _eq: 1 }
            }
          }
        }, {
          name: 'daterange',
          desc: '时间周期',
          placeholder: '选择时间',
          value: 'time'
        }
      ]
    })

    const search = (searchInfo) => {
      state.queryData.where = {
        name: { _like: '%%' }
      }
      if (searchInfo.name) {
        state.queryData.where.name = { _like: searchInfo.name }
      }

      if (searchInfo.time && searchInfo.time.length > 0) {
        state.queryData.where.today_study = {
          date: {
            _gte: tools.formatTime(searchInfo.time[0]),
            _lte: tools.formatTime(searchInfo.time[1])
          }
        }
        state.queryData.todayWhere = {
          date: {
            _gte: tools.formatTime(searchInfo.time[0]),
            _lte: tools.formatTime(searchInfo.time[1])
          }
        }
      }

      if (searchInfo.courseId) {
        state.queryData.where.kb_watch_records = {
          course_id: { _eq: searchInfo.courseId }
        }
        state.queryParams.refresh = true
      }
      if (searchInfo.sectionId) {
        state.queryData.where.section_id = {
          _eq: searchInfo.sectionId
        }
      }
    }

    const showMustBeCourseList = (val, type) => {
      if (type === 'mustBeNum' && val.mustBeCourseList.length > 0) {
        state.isShowMustBe = true
        state.currentMustBe = val
      } else if (type === 'watchNum' && val.nodes.length > 0) {
        state.isShowWatch = true
        state.currentMustBe = val.nodes
      } else if (type === 'completeNum') {
        tools.post('/watchRecord/getStaffWatchListByPage', {
          where: {
            staff_id: { _eq: val.id },
            course_completed: { _eq: true }
          },
          limit: 1000
        }).then(r => {
          state.currentMustBe = r.list
          if (r.list.length === 0) {
            tools.msg('暂无数据', 'info')
          } else {
            state.isShowCompleteCourse = true
          }
        })
      } else {
        tools.msg('暂无数据', 'info')
      }
    }

    const insertScriptTag = () => {
      tools.loadScript('https://cdn.jsdelivr.net/npm/chart.js').subscribe(r => {
        if (r) {
          console.log(r)
        }
      })
    }

    const exportCurrentPage = () => {
      const arr: any = []
      state.dataList.forEach(res => {
        const obj: any = {}
        state.tableColumns.forEach((rr: any) => {
          if (!rr.isHide) {
            obj[rr.label] = res[rr.valueKey]
          }
        })
        arr.push(obj)
      })
      tools.exportExcel(arr, '人员学习统计')
    }

    const exportAll = () => {
      const arr: any = []
      const loading = tools.showLoading('加载中,请耐心等待...')
      tools.post('/staff/getStudyListByPage', { limit: 100000 }).then(r => {
        r.list.forEach((res: any) => {
          const obj: any = {}
          state.tableColumns.forEach((rr: any) => {
            if (!rr.isHide) {
              obj[rr.label] = res[rr.valueKey]
            }
          })
          arr.push(obj)
        })
        // 获取所有的列表！没有考虑父级问题
        tools.exportExcel(arr, '人员学习统计')
        tools.closeLoading(loading)
      })
    }

    onMounted(() => {
      insertScriptTag()
    })

    return {
      ...toRefs(state),
      search,
      exportAll,
      showMustBeCourseList,
      exportCurrentPage,
      insertScriptTag
    }
  }
})

</script>

<style lang="less" scoped>
.order-statistic {
  .el-container {
    width: 100%;
  }

  .aside-box {
    width: 60% !important;
    background: #ffffff !important;

    .cards-box {
      display: flex;
      justify-content: center;

      .card {
      }
    }
  }

  .main-box {
    padding: 20px;
  }
}
</style>
