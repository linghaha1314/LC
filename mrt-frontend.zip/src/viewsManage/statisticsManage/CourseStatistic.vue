<template>
  <div class="study-statistic">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="queryParams.refresh"
                  :isShowReset="true"
                  :searchInit="searchInit" @search="search" :is-show-export-btn="true" @exportAll="exportAll"
                  v-model:tableColumns="tableColumns" :list="dataList" placeholder="课程名搜索">
      <template v-slot:left-btn>
        <el-button size="small" type="primary" @click="exportCurrentPage">导出当页</el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="queryParams.refresh" v-model:columns="tableColumns" :queryData="queryData"
                http-type="post"
                v-model:list="dataList"
                url="/courseStatistic/getCourseStatistic">
      <template v-slot:compulsoryStaffs="scope">
        <ul style="padding: 12px 0 0 12px">
          <li v-if="scope.row.compulsoryStaffs?.length===0">无</li>
          <el-collapse v-else v-model="activeNames" style="border:none" class="collapse-wrapper-common">
            <el-collapse-item :title="scope.row.compulsoryStaffs?.length+'人'" :name="'c'+scope.row.id">
              <span v-for="(ii,index) in scope.row.compulsoryStaffs" :key="ii.id"><span v-if="index!==0">，</span>{{
                  ii.name
                }}</span>
            </el-collapse-item>
          </el-collapse>
        </ul>
      </template>
      <template v-slot:watchStaffs="scope" style="display: flex;align-items: flex-start">
        <ul style="padding: 12px 0 0 12px">
          <li v-if="scope.row.watchStaffs?.length===0">无</li>
          <el-collapse v-else v-model="activeNames" style="border:none" class="collapse-wrapper-common">
            <el-collapse-item :title="scope.row.watchStaffs?.length+'人'" :name="scope.row.id">
              <span v-for="(ii,index) in scope.row.watchStaffs" :key="ii.id"><span v-if="index!==0">，</span>{{
                  ii.name
                }}</span>
            </el-collapse-item>
          </el-collapse>
        </ul>
      </template>
    </table-list>
  </div>
</template>

<script lang="ts">
import tools from '@/utils/tool'
import { defineComponent, onMounted, reactive, ref, toRefs } from 'vue'
import TableList from '@/viewsManage/components/TableList.vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import { View } from '@element-plus/icons-vue'

export default defineComponent({
  components: {
    TableList,
    SearchClass
  },
  setup: () => {
    const state = reactive({
      activeNames: 1,
      dataList: [],
      queryParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      queryData: {
        where: {
          name: { _like: '%%' },
          status: { _eq: 1 }
        }
      } as any,
      tableColumns: [
        {
          valueKey: 'name',
          label: '课程',
          width: 120
        },
        {
          valueKey: 'lecturerName',
          label: '主讲人',
          width: 120
        },
        {
          valueKey: 'publishStaffName',
          label: '发布人',
          width: 120
        },
        {
          valueKey: 'sectionName',
          label: '所属科室',
          width: 120
        },
        {
          valueKey: 'expectStudyNum',
          label: '应学习人数',
          width: 120
        }, {
          type: 'slot',
          valueKey: 'compulsoryStaffs',
          label: '指定学习人员',
          width: 140
        }, {
          type: 'slot',
          valueKey: 'watchStaffs',
          label: '参与人员',
          width: 160
        }, {
          valueKey: 'actualStudyNum',
          label: '实际学习人数',
          width: 150
        }, {
          valueKey: 'completeStaffNum',
          label: '学习完成人数',
          width: 150
        }, {
          valueKey: 'notCompleteStaffNum',
          label: '学习未完成人数',
          width: 150
        },
        {
          valueKey: 'score',
          label: '评分（十分制）',
          width: 150
        },
        {
          valueKey: 'collect',
          label: '收藏人数',
          width: 120
        },
        {
          valueKey: 'studyStaffNum',
          label: '观看人数',
          width: 120,
          isHide: true
        },
        {
          valueKey: 'completeStaff',
          label: '点击数',
          width: 120,
          isHide: true
        },
        {
          valueKey: 'positionTitleRate',
          label: '复播率',
          width: 120,
          isHide: true
        },
        {
          valueKey: 'studyTime',
          label: '观看时长(时)',
          width: 120,
          isHide: true
        },
        {
          valueKey: 'completeStaff',
          label: '已完成人数(人)',
          width: 120,
          isHide: true
        },
        {
          valueKey: 'comment',
          label: '评论/条',
          isHide: true
        },
        {
          valueKey: 'positionTitleRate',
          label: '各职称参与率',
          width: 120,
          isHide: true
        }, {
          valueKey: 'levelTitleRate',
          label: '各层级参与率',
          width: 120,
          isHide: true
        },
        // {
        //   valueKey: 'studyEngageRate',
        //   label: '学习参与率',
        //   width: 120,
        //   isHide: true
        // },
        {
          valueKey: 'completeEngageRate',
          label: '学习完成人率',
          width: 120,
          isHide: true
        }, {
          valueKey: 'notCompleteEngageRate',
          label: '学习未完成人率',
          width: 120,
          isHide: true
        }],
      searchInfo: {},
      searchInit: [
        {
          name: 'isSearch',
          desc: '关键词',
          placeholder: '请输入内容',
          value: 'name'
        },
        // {
        //   name: 'isSelect',
        //   desc: '科室',
        //   url: '/section/getListByPage',
        //   queryParams: { limit: 100 },
        //   placeholder: '输入科室名远程搜索',
        //   value: 'sectionId'
        // },
        {
          name: 'isSelect',
          desc: '主讲人',
          placeholder: '远程搜索主讲人',
          httpType: 'post',
          isInWhereName: true,
          url: '/user/getUserListByPage',
          queryParams: {
            limit: 100,
            where: {}
          },
          value: 'lecturer_id'
        }, {
          name: 'isSelect',
          desc: '指定人员',
          searchKey: 'name',
          placeholder: '远程搜索指定人员',
          queryParams: { limit: 100 },
          url: '/user/getListByPage',
          value: 'staff_id'
        }
        // {
        //   name: 'daterange',
        //   desc: '时间周期',
        //   placeholder: '选择时间',
        //   value: 'time'
        // }
      ]
    })

    const search = (searchInfo) => {
      state.queryData.where = { status: { _eq: 1 } }
      if (searchInfo.name) {
        state.queryData.where.name = { _like: searchInfo.name }
      }
      if (searchInfo.lecturer_id) {
        state.queryData.where.lecturer_id = { _eq: searchInfo.lecturer_id }
      }
      if (searchInfo.staff_id) {
        state.queryData.where.staffcompulsoryCourses = { staff_id: { _eq: searchInfo.staff_id } }
      }
      state.queryParams.refresh = true
    }

    const insertScriptTag = () => {
      tools.loadScript('https://cdn.jsdelivr.net/npm/chart.js').subscribe(r => {
        if (r) {
          console.log(r)
        }
      })
    }

    const viewStaffDetail = (val) => {
      //
    }

    const exportCurrentPage = () => {
      const arr: any = []
      state.dataList.forEach(res => {
        const obj: any = {}
        state.tableColumns.forEach(rr => {
          if (!rr.isHide) {
            let string = ''
            if (rr.valueKey === 'compulsoryStaffs' || rr.valueKey === 'watchStaffs') {
              for (let i = 0; i < (res[rr.valueKey] as any).length; i++) {
                string += ((i === 0 ? '' : ',') + (res[rr.valueKey][i] as any).name)
              }
            }
            obj[rr.label] = (rr.valueKey === 'compulsoryStaffs' || rr.valueKey === 'watchStaffs') ? string : res[rr.valueKey]
          }
        })
        arr.push(obj)
      })
      tools.exportExcel(arr, '课程统计')
    }

    const exportAll = () => {
      const arr: any = []
      const loading = tools.showLoading('加载中,请耐心等待...')
      tools.post('/courseStatistic/getCourseStatistic', { limit: 100000 }).then(r => {
        r.list.forEach((res: any) => {
          const obj: any = {}
          state.tableColumns.forEach((rr: any) => {
            if (!rr.isHide) {
              let string = ''
              if (rr.valueKey === 'compulsoryStaffs' || rr.valueKey === 'watchStaffs') {
                for (let i = 0; i < (res[rr.valueKey] as any).length; i++) {
                  string += ((i === 0 ? '' : ',') + (res[rr.valueKey][i] as any).name)
                }
              }
              obj[rr.label] = (rr.valueKey === 'compulsoryStaffs' || rr.valueKey === 'watchStaffs') ? string : res[rr.valueKey]
            }
          })
          arr.push(obj)
        })
        // 获取所有的列表！没有考虑父级问题
        tools.exportExcel(arr, '课程观看统计')
        tools.closeLoading(loading)
      })
    }

    onMounted(() => {
      insertScriptTag()
    })

    return {
      View,
      ...toRefs(state),
      search,
      exportAll,
      viewStaffDetail,
      exportCurrentPage,
      insertScriptTag
    }
  }
})

</script>

<style lang="less" scoped>
.collapse-wrapper-common {
  /deep/ .el-collapse-item__arrow {
    margin: 0 0 0 8px !important;
  }
}

.collapse-wrapper {
  padding: 10px;
  --el-collapse-header-height: auto;
  border: none;
}

.order-statistic {
  .el-container {
    width: 100%;
  }

  .aside-box {
    width: 60% !important;
    background: #ffffff !important;

    .cards-box {
      display: flex;
      justify-content: center;

      .card {
      }
    }
  }

  .main-box {
    padding: 20px;
  }
}
</style>
