<template>
  <search-class v-model:refresh="state.queryParams.refresh"
                :isShowReset="true"
                :searchInit="state.searchInit" @search="search" :is-show-export-btn="true" @exportAll="exportAll"
                v-model:tableColumns="state.columns" :list="state.dataList" placeholder="搜索部门名称">
  </search-class>
  <!--  <el-row>-->
  <!--    <el-col :span="8" class="flex justify-content align-center column">-->
  <!--      <p>学习人数(人)</p>-->
  <!--      <p class="font-bold">{{ state.totalData.staffTotal }}</p>-->
  <!--    </el-col>-->
  <!--    <el-col :span="8" class="flex justify-content align-center column">-->
  <!--      <p>学习总时长(时)</p>-->
  <!--      <p class="font-bold">{{ state.totalData.timeTotal }}</p>-->
  <!--    </el-col>-->
  <!--    <el-col :span="8" class="flex justify-content align-center column">-->
  <!--      <p>学习课程数(门)</p>-->
  <!--      <p class="font-bold">{{ state.totalData.courseTotal }}</p>-->
  <!--    </el-col>-->
  <!--  </el-row>-->
  <table-list v-model:refresh="state.queryParams.refresh"
              v-model:columns="state.columns"
              v-model:list="state.dataList"
              url='/sectionStatistic/getTableList'
              http-type="post"
              :no-opera="true"
              :queryData="state.queryData">
  </table-list>
  <!--  <el-dialog v-model="state.isViewStaffDetail" custom-class="appoint-staff-dialog" destroy-on-close>-->
  <!--    <template v-slot:title>-->
  <!--      <div class="flex align-center">-->
  <!--        <strip-title>人员学习情况详情</strip-title>&nbsp;&nbsp;-->
  <!--      </div>-->
  <!--    </template>-->
  <!--    <div style="height: 60vh;overflow-y: scroll">-->
  <!--      <search-class v-model:refresh="state.queryParams.refresh"-->
  <!--                    @search="search" @exportAll="exportAll"-->
  <!--                    v-model:tableColumns="state.columns" :list="state.dataList">-->
  <!--      </search-class>-->
  <!--      <table-list v-model:refresh="state.queryParams.refresh"-->
  <!--                  v-model:columns="state.columns"-->
  <!--                  v-model:list="state.dataList"-->
  <!--                  url='/sectionStatistic/getTableList'-->
  <!--                  http-type="post"-->
  <!--                  :no-opera="true"-->
  <!--                  :queryData="state.queryData">-->
  <!--      </table-list>-->
  <!--    </div>-->
  <!--  </el-dialog>-->
</template>
<script lang="ts" setup>
import { onMounted, reactive, watch } from 'vue'
import TableList from '@/viewsManage/components/TableList.vue'
import tools from '@/utils/tool'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import { View } from '@element-plus/icons-vue'

const state = reactive({
  queryParams: {
    isEdit: false,
    isDrawer: false,
    refresh: false
  },
  isViewStaffDetail: false,
  totalData: {},
  dataList: [],
  queryData: {
    startDate: null,
    endDate: null
  },
  searchInit: [
    {
      name: 'isSearch',
      desc: '关键词',
      placeholder: '请输入内容',
      value: 'name'
    },
    {
      name: 'isSelect',
      desc: '科室',
      url: '/section/getListByPage',
      placeholder: '选择科室',
      value: 'sectionId'
    },
    // {
    //   name: 'isSelect',
    //   desc: '主讲人',
    //   placeholder: '选择主讲人',
    //   httpType: 'post',
    //   isInWhereName: true,
    //   url: '/user/getUserListByPage',
    //   queryParams: {
    //     limit: 50,
    //     where: {
    //       roles: {
    //         kb_role: { code: { _eq: 'lecturer' } }
    //       }
    //     }
    //   },
    //   value: 'lecturer_id'
    // }, {
    //   name: 'isSelect',
    //   desc: '指定人员',
    //   searchKey: 'name',
    //   placeholder: '选择指定人员',
    //   url: '/user/getListByPage',
    //   value: 'staff_id'
    // },
    {
      name: 'daterange',
      desc: '时间周期',
      placeholder: '选择时间',
      maxDate: 'today',
      value: 'time'
    }
  ],
  columns: [
    {
      valueKey: 'name',
      label: '部门'
    },
    {
      valueKey: 'sectionStaffNum',
      label: '学员人数',
      showViewBtn: true
    }, {
      valueKey: 'courseNum',
      label: '学习总课程数目（门）'
    }, {
      type: 'studyTime',
      valueKey: 'studyTimeNum',
      label: '学习总时长（时）'
    }, {
      valueKey: 'creditsNum',
      label: '获取总学分'
    }, {
      valueKey: 'completedRate',
      label: '指定课程完成率'// 必须课程分类选择科室，所有科室关联的课程指定的所有人员观看完成率；
    }]
})

const getData = () => {
  tools.post('/sectionStatistic/getTotalData', state.queryData).then(r => {
    state.totalData = r.data
  })
}

const viewSectionStaffTable = (item) => {
  state.isViewStaffDetail = true
}

const search = (val) => {
  state.queryData = {
    startDate: null,
    endDate: null
  }
  state.queryData = val
  if (val.time) {
    const time: any = {
      startDate: tools.formatTime(val.time[0]),
      endDate: tools.formatTime(val.time[1])
    }
    state.queryData.startDate = time.startDate
    state.queryData.endDate = time.endDate
    delete val.time
  }
  state.queryParams.refresh = true
}

onMounted(() => {
  getData()
})

watch(() => state.queryParams.refresh, (val) => {
  if (val) {
    getData()
  }
})

const exportAll = () => {
  const arr: any = []
  state.dataList.forEach((res: any) => {
    const obj: any = {}
    state.columns.forEach((rr: any) => {
      if (!rr.isHide) {
        obj[rr.label] = res[rr.valueKey]
      }
    })
    arr.push(obj)
  })
  // 获取所有的列表！没有考虑父级问题
  tools.exportExcel(arr, '部门学习数据表')
}
</script>
