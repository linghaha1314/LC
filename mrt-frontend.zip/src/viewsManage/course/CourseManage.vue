<template>
  <div class="course-manage">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search"
                  v-model:tableColumns="columns">
      <template v-slot:left-btn>
        <el-button class="background-btn" plain size="small" type="primary" @click="$tools.openDrawer(pageParams)">添加新课程
        </el-button>
        <el-button v-if="store.state.manageUserInfo?.currentRole?.roleData?.code.indexOf('admin')>-1" plain size="small"
                   type="success" @click="$tools.aDown('课程导入模版.xlsx', './xlsx/课程导入模版.xlsx')">
          模板下载
        </el-button>
        <el-button v-if="store.state.manageUserInfo?.currentRole?.roleData?.code.indexOf('admin')>-1"
                   class="background-btn" plain size="small" type="warning" @click="importMulti">批量导入
        </el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="columns"
                :query-data="tableQueryData" httpType="post" url="/courses/getDataListByPage" operaWidth="220px"
                operaFixed="right">
      <template v-slot:status="data">
        <span v-if="data.row.status === -1" class="font-warning font-bold">未提交</span>
        <span v-if="data.row.status === 0" class="font-red font-bold">审核驳回</span>
        <span v-if="data.row.status === 2" class="font-red font-bold">禁用</span>
        <span v-if="data.row.status === 11" class="font-warning font-bold">待审核</span>
        <span v-if="data.row.status === 1" class="font-green font-bold">启用</span>
      </template>
      <template v-slot="scope">
        <div>
          <el-tooltip content="查看/修改" placement="bottom">
            <el-button :icon="Edit" circle size="small" type="primary" @click="edit(scope.row)"/>
          </el-tooltip>
          <el-tooltip content="章节维护" placement="bottom">
            <el-button :icon="Tools" circle size="small" type="primary" @click="chapterEdit(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip content="课件管理" placement="bottom">
            <el-button :icon="Files" circle color="#9095e1" size="small" @click="openFilesDialog(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip
            v-if="store.state.manageUserInfo?.currentRole?.roleData?.code === 'superadmin' && scope.row.status === 1"
            content="撤销课程" placement="bottom">
            <el-button :icon="ArrowLeft" circle size="small" type="warning" @click="changeStatus(scope.row)"/>
          </el-tooltip>
          <el-tooltip v-if="scope.row.status === -1" content="提交审批" placement="bottom">
            <el-button :icon="Check" circle size="small" type="danger" @click="submitApproval(scope.row)"></el-button>
          </el-tooltip>
          <el-tooltip v-if="scope.row.status === 11 || scope.row.status === 0" content="查看审批进度" placement="bottom">
            <el-button :icon="Finished" circle size="small" type="success" @click="checkApprovalProcess(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip
            v-if="scope.row.status === 1 && (scope.row['recommendStatus']===-1 || !scope.row['recommendStatus'])"
            content="设置为推荐课程"
            placement="bottom">
            <el-button :icon="HomeFilled" circle size="small" type="warning" @click="setRecommendCourse(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip
            v-if="scope.row['recommendStatus']===11"
            content="查看推荐审批进度"
            placement="bottom">
            <el-button :icon="HomeFilled" circle size="small" type="success" @click="getRecommendProcess(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip v-if="scope.row.status === 1" content="禁用" placement="bottom">
            <el-button :icon="CircleCloseFilled" circle size="small" type="info" @click="isDisableCourse(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip v-if="scope.row.status === 2" content="启用" placement="bottom">
            <el-button :icon="CircleCheckFilled" circle size="small" type="success" @click="isDisableCourse(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip v-if="store.state.manageUserInfo?.currentRole?.roleData?.code.indexOf('admin')>-1" content="删除"
                      placement="bottom">
            <el-button :icon="Delete" circle size="small" type="danger" @click="deleteCourseById(scope.row)">
            </el-button>
          </el-tooltip>
          <el-tooltip v-if="scope.row.status === 1" content="指定人员" placement="bottom">
            <el-button :icon="Avatar" circle size="small" color="#9095e1" @click="appointStaff(scope.row)">
            </el-button>
          </el-tooltip>
        </div>
      </template>
    </table-list>
    <el-drawer v-model="pageParams.isDrawer" :append-to-body="false" :destroy-on-close="true" direction="rtl" size="40%"
               title="课程设置">
      <!-- 驳回和未提交都可以修改-->
      <form-list v-if="isShowFormList" :isEdit="pageParams.isEdit" :list="formList" @submit="submit"
                 @addBtn="addNewLecturer"
                 :is-read-only="
      (store.state.manageUserInfo.currentRole?.roleData.code.indexOf('admin') < 0 &&
         (currentCourse.staffId !== store.state.manageUserInfo.id
        || (currentCourse.status === 11 && currentCourse.staffId === store.state.manageUserInfo.id))) && pageParams.isEdit">
        <template v-slot:basic>
          <strip-title class="margin-bottom">基础信息</strip-title>
        </template>
      </form-list>
    </el-drawer>
  </div>
  <!-- 章节列表-->
  <el-dialog v-if="isDialog" v-model="isDialog" custom-class="course-manage-wrapper" destroy-on-close
             title="章节列表" top="15vh" width="70%" @close="closeChapter">
    <chapter-page v-if="isDialog" :courseId="currentCourseId" :courseStatus="currentCourse.status"
                  :is-read-only="currentCourse.status === 11 && store.state.manageUserInfo.currentRole?.roleData.code.indexOf('admin') < 0"></chapter-page>
  </el-dialog>
  <el-dialog v-model="isVerifyDialog" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>验证设置</strip-title>&nbsp;&nbsp;
        <el-button class="margin-start" size="small" type="warning" @click="addVerify">新增弹窗</el-button>
      </div>
    </template>
    <div style="max-height: 490px;overflow-y: auto">
      <el-card v-for="(item, index) in verifyList" :key="index" style="margin:0 0 20px 0">
        <template #header>
          <div class="card-header flex justify-between">
            <span>{{ index + 1 }}.设置弹窗验证</span>
            <el-icon color="red" @click="deleteVerify(item, index)">
              <delete-filled/>
            </el-icon>
          </div>
        </template>
        <div class="el-form-item flex align-center">
          <span>弹窗验证时间&nbsp;&nbsp;</span>
          <el-input v-model="item.time" style="width: 180px" type="number"/>
        </div>
        <div class="el-form-item flex align-center">
          <span>弹窗验证类型&nbsp;&nbsp;</span>
          <el-radio-group v-model="item.typeId">
            <el-radio v-for="dd in verifyRadioList" :key="dd.id" :label="dd.id">{{ dd.name }}</el-radio>
          </el-radio-group>
        </div>
      </el-card>
    </div>
    <div class="flex" style="flex-direction: row-reverse;padding: 20px 20px 0 0">
      <el-button type="primary" @click="verifySubmit()">保存</el-button>
    </div>
  </el-dialog>
  <!--  课件管理弹窗-->
  <el-dialog v-model="isFilesDialog" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>课件管理</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <div style="max-height: 490px;overflow-y: auto">
      <el-upload :file-list="fileList" :on-remove="deleteFile" :on-success="uploadSuccess" action="/public/upload"
                 multiple>
        <el-button type="warning">新增课件</el-button>
        <template #file="item">
          <div style="padding: 5px;display: flex;justify-content: space-between;align-items: center;">
            <div>
              {{ item.file.name }}
              <select v-model="item.file.typeId" style="margin-left: 16px" @change="selectType(item.file)">
                <option :value=null selected>无</option>
                <option v-for="dd in courseTypeSelect" :key="dd.id" :value="dd.id">{{ dd.name }}</option>
              </select>
            </div>
            <Icon class="font-red" icon="Delete" style="float: right;" @click="deleteFile(item.file)"></Icon>
          </div>
          <el-progress v-if="item.file.percentage" style="top:28px" :percentage="item.file.percentage"
                       :color="customColor"></el-progress>
        </template>
      </el-upload>
    </div>
    <div class="flex" style="flex-direction: row-reverse;padding: 20px 20px 0 0">
      <el-button type="primary" @click="filesSubmit()">保存</el-button>
    </div>
  </el-dialog>
  <!--  审批进度弹窗-->
  <el-dialog v-model="isApprovalDialog" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>审批进度查看</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <el-timeline>
      <el-timeline-item v-for="dd in approvalList" :key="dd.id" placement="bottom" size="large" type="primary">
        {{ dd['roleName'] }}
        <div style="margin-top: 8px">
          <p style="color: #666666;margin-bottom: 8px">
            <span v-if="dd.status === 11" class="font-orange font-bold">待审核</span>
            <span v-if="dd.status === 1" class="font-green font-bold">通过✅</span>
            <span v-if="dd.status === 0" class="font-red font-bold">驳回❌</span>
            <small class="padding-start">{{ dd['approvalDate'] }}</small>
          </p>
          <p v-if="dd.remark" style="color: #666666;margin-bottom: 8px">审批意见：{{ dd.remark }}</p>
        </div>
      </el-timeline-item>
    </el-timeline>
    <div style="margin:16px 0" v-if="currentCourse.status === 0">
      <el-button @click="submitApproval(currentCourse)" type="warning">重新提交审核</el-button>
    </div>
  </el-dialog>
  <!--课程推荐审批进度-->
  <el-dialog v-model="isRecommendApprovalDialog" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>首页推荐课程审批进度查看</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <el-timeline>
      <el-timeline-item v-for="dd in recommendApprovalList" :key="dd.id" placement="bottom" size="large" type="primary">
        {{ dd['roleName'] }}
        <div style="margin-top: 8px">
          <p style="color: #666666;margin-bottom: 8px">
            <span v-if="dd.status === 11" class="font-orange font-bold">待审核</span>
            <span v-if="dd.status === 1" class="font-green font-bold">通过✅</span>
            <span v-if="dd.status === 0" class="font-red font-bold">驳回❌</span>
            <small class="padding-start">{{ dd['approvalDate'] }}</small>
          </p>
          <p v-if="dd.remark" style="color: #666666;margin-bottom: 8px">审批意见：{{ dd.remark }}</p>
        </div>
      </el-timeline-item>
    </el-timeline>
    <div style="margin:16px 0" v-if="currentCourse.status === 0">
      <el-button @click="submitApproval(currentCourse)" type="warning">重新提交审核</el-button>
    </div>
  </el-dialog>
  <!-- 指定人员 -->
  <el-dialog v-model="isAppointStaffDialog" custom-class="appoint-staff-dialog" destroy-on-close>
    <template v-slot:title>
      <div class="flex align-center">
        <strip-title>指定人员必学</strip-title>&nbsp;&nbsp;
      </div>
    </template>
    <search-class :isShowReset="true"
                  :isHideRight="true"
                  :searchInit="transferData.searchInit" @search="transferSearch">
    </search-class>
    <transfer-frame
      v-if="isAppointStaffDialog"
      leftUrl="/user/getUserListByPage"
      rightUrl="/staffCompulsoryCourses/getDatalistByPage"
      v-model:refresh="transferData.refresh"
      :queryDataRight="transferData.queryDataRight"
      :queryDataLeft="transferData.queryDataLeft"
      @saveData="saveAppointStaff">
    </transfer-frame>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, getCurrentInstance, nextTick, onMounted, reactive, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import ChapterPage from './components/Chapter.vue'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import StripTitle from '@/components/StripTitle.vue'
import {
  CircleCheckFilled,
  CircleCloseFilled,
  Delete,
  HomeFilled,
  DeleteFilled,
  ArrowLeft,
  Files,
  Avatar,
  Finished,
  Reading,
  Tools
} from '@element-plus/icons'
import store from '@/store'
import { Check, Edit } from '@element-plus/icons-vue'
import TransferFrame from '@/viewsManage/components/TransferFrame.vue'

export default defineComponent({
  components: {
    TransferFrame,
    DeleteFilled,
    TableList,
    SearchClass,
    FormList,
    StripTitle,
    ChapterPage
  },
  setup: () => {
    const { proxy }: any = getCurrentInstance()

    const state = reactive({
      isShowFormList: true,
      customColor: '#67c23a',
      transferData: {
        searchInit: [
          {
            name: 'isSelect',
            desc: '科室',
            url: '/section/getListByPage',
            placeholder: '选择科室',
            value: 'section_id'
          }, {
            name: 'isSelect',
            desc: '角色',
            searchKey: 'name',
            placeholder: '选择角色',
            value: 'role_id',
            url: '/roles/getListByPage',
            queryParams: { limit: 1000 }
          }
        ],
        refresh: false,
        queryDataLeft: '{}',
        queryDataRight: '{}'
      },
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      tableQueryData: {
        where: {
          name: { _like: '%%' },
          staff_id: store.state.manageUserInfo.currentRole.roleData.code.indexOf('admin') > -1 ? {} : { _eq: store.state.manageUserInfo.id },
          staff_role_id: store.state.manageUserInfo.currentRole.roleData.code.indexOf('admin') > -1 ? {} : { _eq: store.state.manageUserInfo.currentRole.roleId }
        }
      },
      approvalList: [] as any[], // 审批进度
      recommendApprovalList: [], // 课程推荐审批进度
      fileList: [], // 文件
      courseTypeSelect: [] as any[],
      courseTypeList: [],
      selection: [],
      currentCourse: {} as any,
      currentCourseId: '0', // 展开章节
      isChapterModify: false, // 修改章节
      isFilesDialog: false, // 课件管理
      isDialog: false, // 章节页面列表显示
      isApprovalDialog: false, // 审批进度查看
      isAppointStaffDialog: false,
      isRecommendApprovalDialog: false,
      isVerifyDialog: false,
      examPaperValue: '',
      approvalProcessId: null,
      searchInfo: {},
      searchInit: [
        {
          name: 'isSearch',
          desc: '关键词',
          placeholder: '请输入内容',
          value: 'search'
        },
        {
          name: 'isSelect',
          desc: '状态',
          placeholder: '选择状态',
          value: 'status',
          valueKey: 'status',
          defaultValue: null,
          options: [{
            status: null,
            name: '不限制'
          }, {
            status: '-1',
            name: '未提交'
          }, {
            status: '11',
            name: '待审核'
          }, {
            status: '0',
            name: '驳回'
          }, {
            status: '1',
            name: '启用'
          }, {
            status: '2',
            name: '禁用'
          }]
        }, {
          name: 'isSelect',
          desc: '所属专业',
          searchKey: 'name',
          placeholder: '远程搜索专业',
          queryParams: { limit: 100 },
          value: 'major_id',
          url: '/major/getListByPage'
        }, {
          name: 'isCascader',
          desc: '课程类型',
          searchKey: 'name',
          placeholder: '选择课程类型',
          value: 'type_id',
          list: []
        }, {
          name: 'isCascader',
          desc: '课程栏目',
          searchKey: 'name',
          placeholder: '选择课程栏目',
          value: 'column_id',
          list: []
        }
      ], // 筛选条件项
      verifyList: [] as any[],
      columns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'name',
          label: '课程名称'
        },
        {
          valueKey: 'majorName',
          label: '所属专业'
        },
        {
          valueKey: 'sectionName',
          label: '所属科室'
        },
        {
          valueKey: 'staffName',
          label: '发布人'
        },
        {
          valueKey: 'credits',
          label: '学分'
        },
        {
          valueKey: 'status',
          type: 'slot',
          label: '状态',
          width: '80px'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }],
      formList: [
        {
          type: 'slot',
          name: 'basic'
        }, {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '课程名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'cascade',
          label: '课程类型',
          key: 'typeId',
          width: '',
          value: null,
          extraValueKey: 'img',
          toExtraValueObjName: 'img',
          url: '/courseType/getListByPage',
          queryParams: { limit: 1000 },
          defaultValue: [],
          required: true
        }, {
          type: 'cascade',
          label: '课程栏目',
          key: 'columnId',
          width: '',
          value: null,
          list: [],
          defaultValue: [],
          required: true
        }, {
          type: 'select',
          label: '所属专业',
          key: 'majorId',
          width: '',
          url: '/major/getList',
          searchKey: 'search',
          value: null,
          defaultValue: null
        }, {
          type: 'select',
          label: '所属科室',
          key: 'sectionId',
          width: '',
          url: '/section/getList',
          searchKey: 'search',
          value: null,
          defaultValue: null
        }, {
          type: 'remote-select',
          label: '主讲人',
          url: '/user/getUserListByPage',
          httpType: 'post',
          addBtn: 'lecturer',
          addPlaceholder: '请输入新增主讲人',
          isShowAdd: false,
          lecturerName: '',
          isInWhere: true,
          searchKey: 'name',
          clearable: true,
          key: 'lecturerId',
          queryParams: {
            limit: 200,
            where: {}
          },
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'uploadImg',
          label: '课程封面',
          key: 'img',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'textarea',
          label: '课程介绍',
          key: 'introduce',
          width: '100',
          value: null,
          defaultValue: ''
        }, {
          type: 'richText',
          label: '课程简介',
          key: 'brief',
          width: '',
          value: '',
          defaultValue: null
        }, {
          type: 'number',
          label: '课程学分',
          key: 'credits',
          width: '',
          value: '',
          defaultValue: null
        }, {
          type: 'slot',
          name: 'verify'
        }],
      verifyRadioList: [] as any[],
      courseTypeListNoChildren: [],
      majorObj: {},
      lecturerObj: {}
    })

    const getHomeColumns = async () => {
      const data = await tools.get('/homeColumns/getDataList', {})
      state.searchInit[4].list = data.list
      const startData = JSON.parse(JSON.stringify(data))
      setDisableList(startData.list, true)
      const ableData = await tools.get('/roleHomeColumn/getListByPage', {
        roleId: store.state.manageUserInfo.currentRole.roleId,
        limit: 1000
      })
      ableData.list.forEach((res: any) => {
        setDisableList(startData.list, false, res.columnId)
      })
      state.formList[4].list = startData.list
    }

    const setDisableList = (list = [], isTrue = false, id = '') => {
      if (isTrue) {
        // 设置所有的子选项都禁用
        list.forEach((rr: any) => {
          rr.disabled = true
          setDisableList(rr.children, true)
        })
        return
      }
      list.forEach((rr: any) => {
        if (id === rr.id) {
          rr.disabled = false
        }
        if (rr.children && rr.children.length > 0 && rr.id !== id) {
          setDisableList(rr.children, false, id)
        }
      })
    }

    const search = (searchInfo: any) => {
      delete (state.tableQueryData.where as any).status
      state.tableQueryData.where.name = { _like: '%%' }
      const data: any = {
        where: {},
        name: { _like: '%%' }
      }
      for (const [key, value] of Object.entries(searchInfo)) {
        switch (key) {
          case 'name':
            data.where.name = value ? { _like: value } : { _like: '%%' }
            break
          case 'status':
            if (value) {
              data.where.status = { _eq: value }
            }
            break
          case 'column_id':
            if (!value) {
              delete (state.tableQueryData.where as any)?.course_column
            } else {
              data.where.course_column = { [key]: { _eq: (value as any)[(value as any[]).length - 1] } }
            }
            break
          case 'type_id':
            if (!value) {
              delete (state.tableQueryData.where as any)?.courseClass
            } else {
              data.where.courseClass = { [key]: { _eq: (value as any)[0] } }
            }
            break
          case 'major_id':
            if (!value) {
              delete (state.tableQueryData.where as any)?.major_id
            } else {
              data.where[key] = { _eq: value }
            }
            break
          default:
            break
        }
      }
      (state.tableQueryData as any) = { where: { ...state.tableQueryData.where, ...data.where } }
    }

    const chapterEdit = (val) => {
      state.isDialog = true
      state.currentCourseId = val.id
      state.currentCourse = val
      nextTick(() => {
        // const dom: any = document.querySelector('.main-content>.el-overlay')
        // dom.style.position = 'absolute'
        // dom.style.height = '100%'
        // const wrapperDom: any = document.querySelector('.el-main')
        // wrapperDom.scroll(0, 0)
      })
    }

    const closeChapter = () => {
      state.pageParams.refresh = true
    }

    const setRecommendCourse = async (val) => {
      // 是否确定，走一个审批流程！设置一个启动流程
      // 可以查看审批进度
      // 成功以后呢，显示是否是推荐课程，驳回之后可以再调用上传
      const approvalData = await tools.post('/api/rest/getApprovalProcessIdByTypeCode', {
        typeCode: 'home_recommend'
      })
      await tools.confirm('温馨提示', '确定要设置当前课程为推荐课程？').then(async r => {
        if (r) {
          // 走审批流程，记录课程id,startId,processId
          const loading = tools.showLoading('提交中...')
          tools.post('/workflow/createProcess', {
            staffId: store.state.manageUserInfo.id,
            objectId: val.id, // courseId
            approvalProcessId: approvalData.data?.listByTypeCode[0].id,
            typeCode: 'home_recommend'
          }).then(r => {
            state.isApprovalDialog = false
            tools.closeLoading(loading)
            if (r.success) {
              state.pageParams.refresh = true
              tools.msg(r.msg)
            }
          })
        }
      })
    }

    const getRecommendProcess = async (val) => {
      const loading = tools.showLoading('加载中...')
      await tools.post('/workflowStart/getStepDetailList', {
        workflowId: val.recommendWorkflowId,
        approvalProcessId: val.recommendApprovalProcessId
      }).then(r => {
        tools.closeLoading(loading)
        if (r.success) {
          state.isRecommendApprovalDialog = true
          state.recommendApprovalList = r.list
        }
      })
    }

    const openFilesDialog = async (val) => {
      state.currentCourse = val
      state.currentCourseId = val.id
      await tools.get('/courseFiles/getListByPage', { courseId: val.id }).then(r => {
        state.fileList = r.list
      })
      state.isFilesDialog = true
    }

    const changeStatus = async (val) => {
      tools.confirm('温馨提示', '确定要撤销当前课程为未发布状态？').then(async r => {
        if (r) {
          await tools.post('/courses/updateById', {
            id: val.id,
            status: -1
          }).then(r => {
            if (r.success) {
              tools.msg('撤销成功！')
              state.pageParams.refresh = true
            }
          })
        }
      })
    }

    const openVerify = (val) => {
      state.currentCourseId = val.id
      tools.get('/courseVerify/getListByPage', {
        courseId: val.id,
        sort: 'time asc'
      }).then(r => {
        state.verifyList = r.list
        state.isVerifyDialog = true
      })
    }

    const isDisableCourse = (val) => {
      const msg = val.status === 2 ? '确认启用该课程？' : '确认禁用该课程?'
      tools.confirm('温馨提示', msg).then(async r => {
        if (r) {
          // 改变课程的status，2是禁用
          const loading = tools.showLoading('设置中...')
          await tools.post('/courses/updateById', {
            status: val.status === 2 ? 1 : 2,
            id: val.id
          }).then(rr => {
            if (rr.success) {
              state.pageParams.refresh = true
              tools.msg(val.status === 2 ? '启用成功！' : '课程已被禁用！')
            }
          })
          tools.closeLoading(loading)
        }
      })
    }

    const getApprovalProcessIdByDictionaryCode = async () => {
      await tools.post('/api/rest/getApprovalProcessIdByTypeCode', {
        assignedRoleId: store.state.manageUserInfo.currentRole.roleId,
        typeCode: 'course_approval'
      }).then(r => {
        const list = (r.data.listByAssignedRoleId.length > 0 ? r.data.listByAssignedRoleId : r.data.listByTypeCode) || []
        state.approvalProcessId = list.length > 0 ? list[0].id : null
      })
    }

    const addNewLecturer = (val) => {
      // tools.confirm('温馨提示', '人员表已存在"xxxxx"是否将此人设置为讲师？').then(r => {
      //
      // })
      // 确定数据库是否有这个名字！，有就询问是否设置数据库里面的这个人员为讲师！是，否，且添加新的讲师
      // 没有就直接添加人员为讲师！同时数据库添加
      state.isShowFormList = false
      tools.post('/user/createNewLecturer', { name: val.lecturerName }).then(res => {
        state.isShowFormList = true
        if (res.success) {
          tools.msg(res.msg)
          val.isShowAdd = false
          val.lecturerName = ''
        }
      })
      // 刷新链接
      // 设置一个弹窗，新增主讲人；名字，工号自动生成，角色设置为讲师
    }

    const submitApproval = (val) => {
      // 做一个下拉选择！
      tools.confirm('温馨提示', '确定提交课程审批？').then(async r => {
        if (!r) {
          return
        }
        // 选对应的审批流程；approvalProcessId
        // 记录当前的审批流程；不做工作流；记录提交人，审批流Id,courseId
        const loading = tools.showLoading('提交中...')
        const result = await createCourseProcess(val)
        state.isApprovalDialog = false
        if (result.success) {
          state.pageParams.refresh = true
          tools.msg(result.msg)
        }
        tools.closeLoading(loading)
      })
    }

    const createCourseProcess = async (val) => {
      // 如果已经存在有流程没有审批完，全部status==3 //失效，不限时；始终以最新为审批流程
      const result = await tools.post('/workflow/createProcess', {
        staffId: store.state.manageUserInfo.id,
        objectId: val.id,
        approvalProcessId: state.approvalProcessId
      })
      return result
    }

    const checkApprovalProcess = (val) => {
      state.currentCourse = val
      state.isApprovalDialog = true
      tools.post('/workflowStart/getStepDetailList', {
        workflowId: val.workflowId,
        approvalProcessId: val.approvalProcessId
      }).then(r => {
        state.approvalList = r.list
      })
    }

    const getCourseType = () => {
      tools.get('/courseType/getListByPage', { limit: 1000 }).then(r => {
        state.courseTypeList = r.list
        state.searchInit[3].list = r.list
      })
    }

    const edit = (val) => {
      state.currentCourse = val
      tools.openDrawer(state.pageParams, true, state.formList, val)
    }

    const selectType = (val: any) => {
      state.fileList.forEach((res: any, index: number) => {
        if (val.path === res.path) {
          (state.fileList[index] as any).typeId = val.typeId
        }
      })
    }

    const uploadSuccess = (data: any) => {
      (state.fileList as any).push(data.data)
    }

    const deleteFile = (data: any) => {
      state.fileList = state.fileList.filter((res: any) => res.path !== data.path)
    }

    const addVerify = () => {
      (state.verifyList as any).push({
        time: 10,
        typeId: 1
      })
    }

    const deleteVerify = (item, index) => {
      state.verifyList.splice(index, 1)
    }

    const deleteCourseById = async (item) => {
      const isDelete = await tools.confirm()
      if (isDelete) {
        tools.post('/courses/deleteAllById', { id: item.id }).then(r => {
          if (r.success) {
            tools.msg(r.msg)
            state.pageParams.refresh = true
          }
        })
      }
    }

    const verifySubmit = async () => {
      if (state.verifyList) {
        await tools.post('/courseVerify/update', {
          courseId: state.currentCourseId,
          verifyList: state.verifyList
        }).then(r => {
          state.isVerifyDialog = false
          if (r.success) {
            tools.msg(r.msg)
          }
        })
      }
    }

    const filesSubmit = async () => {
      const list: any = []
      state.fileList.forEach((res: any) => {
        list.push({
          name: res.name,
          path: res.path,
          typeId: res.typeId || null
        })
      })
      if (state.fileList) {
        const loading = tools.showLoading('提交中..')
        await tools.post('/courseFiles/createUpdateById', {
          id: state.currentCourseId,
          idKey: 'courseId',
          list
        }).then(r => {
          tools.closeLoading(loading)
          if (r.success) {
            tools.msg(r.msg)
          }
        })
      }
      state.isFilesDialog = false
    }

    const submit = async (val) => {
      const data = JSON.parse(JSON.stringify(val))
      delete data.sequence
      // 存在columId;先把columId数组存进course_columnId表里面！！
      data.columnId = val.columnId ? (typeof val.columId === 'string' ? [val.columnId] : val.columnId) : null
      if (!state.currentCourse.staffId) {
        data.staffId = store.state.manageUserInfo.id
        data.staffRoleId = store.state.manageUserInfo.currentRole.roleId
      }
      data.sequence = 99
      const isFlag = (data.id && data.status !== -1) ? await tools.confirm('温馨提示', '修改后课程将变为未提交状态，需要重新提交审核才能启用，确定要修改当前课程？') : true
      data.status = (data.id && isFlag) ? -1 : data.status
      if (isFlag) {
        await createUpdateCourse(data)
        state.pageParams.refresh = true
      }
    }

    const createUpdateCourse = async (data) => {
      const loading = tools.showLoading('提交中...')
      const result = await tools.post('/courses/createUpdate', data)
      if (result.success) {
        state.pageParams.isDrawer = false
        tools.msg(result.msg)
        state.pageParams.refresh = true
        tools.closeLoading(loading)
      }
    }

    const appointStaff = async (val) => {
      state.currentCourseId = val.id
      state.currentCourse = val
      state.transferData.queryDataRight = JSON.stringify({
        where: {
          staffs: { name: { _like: '%search%' } },
          course_id: {
            _eq: val.id
          }
        }
      })
      state.transferData.queryDataLeft = JSON.stringify({ where: { name: { _like: '%search%' } } })
      state.isAppointStaffDialog = true
    }

    const getValueObj = async (path = '/major/getList', type = 'obj', params = {}, key = 'id', label = 'name') => {
      const list = (await tools.get(path, params)).list || []
      const obj: any = {}
      list.forEach(res => {
        obj[res[label]] = res[key]
      })
      return {
        obj,
        list
      }
    }

    // 批量导入
    const importMulti = async () => {
      const loading1 = tools.showLoading('导入中，请耐心等待...')
      // const lecturerObj: any = (await getValueObj('/user/getListByPage', 'obj', {user}, 'id', 'username')).obj
      const majorObj: any = (await getValueObj('/major/getList')).obj
      const courseType: any = await getValueObj('/courseType/getList', 'list', { isNotSetList: true }, 'code')
      const homeColumns: any = await getValueObj('/homeColumns/getList', 'list', { isNotSetList: true }, 'code')
      const list: any = await tools.importData({
        序号: 'index',
        课程名称: 'name',
        章节: 'chapter',
        课程类型: 'type',
        课程类型编码: 'typeCode',
        课程栏目: 'columnName',
        课程栏目编码: 'columnCode',
        专业: 'majorName',
        主讲人: 'lecturerName',
        主讲人帐号: 'lecturerNo',
        视频路径: 'path',
        课程简介: 'brief',
        课程封面: 'img',
        课程介绍: 'introduce',
        课程学分: 'credits',
        课程排序: 'sequence'
      })
      const result: any = []
      let currentName = ''
      let parentId = 0
      let obj: any = {}
      for (const rr of list) {
        if (rr.name !== currentName) {
          parentId++
          currentName = rr.name
          let lecturerId: any = null
          if (rr.lecturerNo) {
            const lecturerData = await tools.post('/api/rest/user/getLecturerByUserName', { where: { username: { _eq: rr.lecturerNo } } })
            if (lecturerData.data.list.length > 0 && lecturerData.data.list[0].id && lecturerData.data.list[0].roles.length === 0) { // 如果是讲师直接取ID,如果不是讲师好要给她添加一个角色为讲师
              await tools.post('/userRole/create', {
                userId: lecturerData.data.list[0].id,
                roleId: lecturerData.data.lecturerList[0].id
              })
            } else {
              lecturerId = lecturerData.data.list.length > 0 ? lecturerData.data.list[0].id : null
            }
          } else {
            const lecturerData = await tools.post('/api/rest/user/getLecturerByUserName', { where: { name: { _eq: rr.lecturerName } } })
            if (lecturerData.data.list.length > 0 && lecturerData.data.list[0].roles.length > 0) {
              lecturerId = lecturerData.data.list[0].id
            } else {
              const addData = await tools.post('/user/createNewLecturer', { name: rr.lecturerName })
              lecturerId = addData?.data.userId
            }
          }
          const typeIds = matchingCode(rr.typeCode, courseType.list)
          const typeImg = (await tools.post('/courseType/getDataById', { id: typeIds[typeIds.length - 1] })).data.img
          obj = {
            status: 1,
            name: rr.name || null,
            columnId: matchingCode(rr.columnCode, homeColumns.list) || null,
            typeId: matchingCode(rr.typeCode, courseType.list) || null,
            majorId: majorObj[rr.majorName] || null,
            lecturerId,
            brief: rr.brief || null,
            introduce: rr.introduce || null,
            credits: rr.credits || null,
            img: rr.img || typeImg || null,
            sequence: rr.sequence || 1,
            children: [{
              name: rr.chapter || null,
              path: rr.path || null
            }]
          }
          if (obj.name) {
            result.push(obj)
          }
        } else {
          (obj.children || []).push({
            name: rr.chapter || null,
            path: rr.path || null
          })
        }
      }
      // 导入课程
      const resultdata = await tools.post('/courses/multiImport', {
        list: result,
        staff: {
          staffId: store.state.manageUserInfo.id,
          staffRoleId: store.state.manageUserInfo.currentRole.roleId
        }
      })
      if (resultdata.success) {
        tools.msg('导入成功！')
      }
      tools.closeLoading(loading1)
      state.pageParams.refresh = true
    }

    const matchingCode = (data, matchingList) => {
      const list = data ? data.split('_') : []
      const arr: any = []
      let code = ''
      list.forEach((res, index) => {
        code += (index === 0 ? res : '_' + res)
        arr.push((matchingList.filter((rr: any) => rr.code === code))[0]?.id || null)
      })
      return arr
    }

    const goExam = (e: any, val: any) => {
      // 阻止事件冒泡
      window.open(val)
    }

    const saveAppointStaff = (val: any) => {
      const list: any = []
      val.forEach(rr => {
        const obj = {
          staffId: rr.staffId || rr.id,
          courseId: state.currentCourse.id
        }
        list.push(obj)
      })
      const loading = tools.showLoading('提交中..')
      tools.post('/staffCompulsoryCourses/createUpdateByList', {
        deleteKey: 'courseId',
        id: state.currentCourse.id,
        list
      }).then(r => {
        tools.closeLoading(loading)
        if (r.success) {
          tools.msg('保存成功！')
          state.isAppointStaffDialog = false
        }
      })
    }

    const transferSearch = async (val) => {
      const data: any = { where: { name: { _like: '%search%' } } }
      for (const [key, value] of Object.entries(val)) {
        let obj: any = {}
        obj = key === 'name' ? { _like: value } : { _eq: value }
        if (value) {
          if (key === 'role_id') {
            data.where.roles = { [key]: { ...obj } }
          } else {
            data.where[key] = obj
          }
        }
      }
      state.transferData.queryDataLeft = JSON.stringify(data)
      state.transferData.refresh = true
    }

    onMounted(async () => {
      getCourseType()
      await getApprovalProcessIdByDictionaryCode()
      await getHomeColumns()
      tools.post('/dictionaryData/getByTypeCode', { typeCode: 'videoVerify' }).then(r => {
        state.verifyRadioList = r.list
      })
      tools.post('/dictionaryData/getByTypeCode', { typeCode: 'courseFileType' }).then(r => {
        state.courseTypeSelect = r.list
      })
    })

    return {
      proxy,
      Check,
      Delete,
      HomeFilled,
      Edit,
      Finished,
      Reading,
      Tools,
      Files,
      store,
      Avatar,
      CircleCheckFilled,
      CircleCloseFilled,
      ArrowLeft,
      transferSearch,
      changeStatus,
      ...toRefs(state),
      edit,
      search,
      goExam,
      submit,
      closeChapter,
      addNewLecturer,
      appointStaff,
      getCourseType,
      saveAppointStaff,
      setRecommendCourse,
      importMulti,
      getRecommendProcess,
      deleteCourseById,
      selectType,
      addVerify,
      openVerify,
      deleteFile,
      chapterEdit,
      filesSubmit,
      verifySubmit,
      deleteVerify,
      uploadSuccess,
      getHomeColumns,
      submitApproval,
      openFilesDialog,
      isDisableCourse,
      checkApprovalProcess
    }
  }
})
</script>

<style lang="less">
@import (once) "~@/assets/css/manage.less";

.appoint-staff-dialog {
  min-width: 730px;
}

.course-manage-wrapper {

  .el-dialog__headerbtn .el-dialog__close {
    color: @primaryColor
  }
}

.el-table__cell:last-child .cell button {
  margin-right: 4px;
  margin-bottom: 6px;
  margin-left: 10px;
}
</style>
