<template>
  <!-- 筛选条件 -->
  <search-class v-model:refresh="pageParams.refresh" v-model:searchData="searchData" :searchInit="searchInit"
                @search="search">
    <template v-slot:left-btn>
      <el-button
        class="background-btn"
        plain
        size="small"
        type="primary"
        @click="tools.openDrawer(pageParams)"
      >新增
      </el-button>
    </template>
  </search-class>
  <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="tableColumns"
              :query-data="{ sort: 'sequence desc,status desc' }" url="/cert/getListByPage">
    <template v-slot:status="data">
      <span v-if="data.row['status']===1" class="font-success font-bold">启用</span>
      <span v-if="data.row['status']===0" class="font-bold">关闭</span>
    </template>
    <template v-slot="scope">
      <el-button size="small" type="text" @click="openDrawer(scope.row)"
      >查看/修改
      </el-button>
      <el-button
        class="font-orange"
        size="small"
        type="text"
        @click="tools.deleteById('cert', scope.row.id,pageParams)"
      >删除
      </el-button>
      <el-button
        size="small"
        type="text"
        @click="tools.aDown(tools.getFileName(scope.row.path), scope.row.path)"
      >下载
      </el-button>
    </template>
  </table-list>
  <el-dialog
    v-model="pageParams.isDrawer"
    :append-to-body="false"
    :destroy-on-close="true"
    title="证书设置"
  >
    <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit">
    </form-list>
  </el-dialog>
</template>

<script lang="ts">
import { defineComponent, reactive, toRefs } from 'vue'
import TableList from '@/viewsManage/components/TableList.vue'
import tools from '@/utils/tool'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import FormList from '@/viewsManage/components/FormList.vue'

export default defineComponent({
  name: '',
  components: {
    TableList,
    FormList,
    SearchClass
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInit: [], // 筛选条件项
      searchData: {}, // 定义搜索条件
      selection: [], // 选项数组
      formList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '证书',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'uploadFile',
          label: '证书模版',
          limit: 1,
          key: 'path',
          width: '',
          buttonText: '上传模版',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'switch',
          label: '启用',
          key: 'status',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }],
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '证书',
          width: 220
        },
        {
          valueKey: 'status',
          label: '状态',
          type: 'slot'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }]
    })

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/cert/updateById', data).then(res => {
          if (res.success) {
            tools.msg(res.success)
            state.pageParams.isDrawer = false
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/cert/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const openDrawer = (val) => {
      state.formList.forEach((res: any) => {
        if (res.type === 'uploadFile') {
          res.fileList = [{
            name: val.path,
            url: val.path
          }]
          res.value = val.path
        } else {
          res.value = val[res.key]
        }
      })
      state.pageParams.isEdit = true
      state.pageParams.isDrawer = true
    }
    return {
      ...toRefs(state),
      submit,
      openDrawer,
      tools
    }
  }
})
</script>
