<template>
  <Icon :icon="iconName"></Icon>
</template>
<script setup>
const iconName = 'Search'
</script>
