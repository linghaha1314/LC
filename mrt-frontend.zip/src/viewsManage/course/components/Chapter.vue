<template>
  <div style="height:60vh;overflow-y: scroll">
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button v-if="!isReadOnly" class="background-btn" plain size="small" type="primary"
                   @click="tools.openDrawer(pageParams)">新增
        </el-button>
        <el-button v-if="!isReadOnly" plain size="small" type="danger"
                   @click="tools.delMultiple('chapters', selection, pageParams)">删除
        </el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="columns"
                :queryData="queryData" url="/chapters/getListByPage" :limit="5">
      <template v-slot="scope">
        <el-button size="small" type="text" @click="openDrawer(scope.row)">
          {{ isReadOnly ? '查看' : '查看/修改' }}
        </el-button>
        <el-tooltip content="验证弹窗" placement="bottom">
          <el-button :icon="Reading" circle size="small" type="warning" @click="openVerify(scope.row)">
          </el-button>
        </el-tooltip>
        <el-button class="font-orange" size="small" type="text"
                   @click="tools.deleteById('chapters', scope.row.id, pageParams)">删除
        </el-button>
      </template>
    </table-list>
    <el-drawer v-model="pageParams.isDrawer" :append-to-body="false" :destroy-on-close="true" direction="rtl" size="40%"
               title="章节设置">
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit" :is-read-only="isReadOnly">
      </form-list>
    </el-drawer>
    <el-dialog v-model="pageParams.isDrawerMultiple" :append-to-body="false" :destroy-on-close="true" direction="rtl"
               size="40%" title="本地批量上传章节">
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-dialog>
    <!-- 弹窗设置 -->
    <el-dialog v-model="isVerifyDialog" destroy-on-close>
      <template v-slot:title>
        <div class="flex align-center">
          <strip-title>验证设置</strip-title>&nbsp;&nbsp;
          <el-button class="margin-start" size="small" type="warning" @click="addVerify">新增弹窗</el-button>
        </div>
      </template>
      <div style="max-height: 60vh;overflow-y: auto">
        <el-card v-for="(item, index) in verifyList" :key="index" style="margin:0 0 20px 0">
          <template #header>
            <div class="card-header flex justify-between">
              <span>{{ index + 1 }}.设置弹窗验证</span>
              <el-icon color="red" @click="deleteVerify(item, index)">
                <delete-filled/>
              </el-icon>
            </div>
          </template>
          <div class="el-form-item flex align-center">
            <span>弹窗验证时间&nbsp;&nbsp;</span>
            <el-input v-model="item.time" style="width: 180px" type="number"/>
          </div>
          <div class="el-form-item flex align-center">
            <span>弹窗验证类型&nbsp;&nbsp;</span>
            <el-radio-group v-model="item.typeId">
              <el-radio v-for="dd in verifyRadioList" :key="dd.id" :label="dd.id" @change="($event) => {
                verifyRadioChange($event, dd, item)
              }">{{ dd.name }}
              </el-radio>
            </el-radio-group>
          </div>
          <div v-if="item.typeCode === 'byChapter'" style="background:#f6e4d7;padding:12px">
            <exam-block type="radio" v-model:result="item.examData"></exam-block>
          </div>
        </el-card>
      </div>
      <div class="flex" style="flex-direction: row-reverse;padding: 20px 20px 0 0">
        <el-button type="primary" @click="verifySubmit()">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted, reactive, toRefs, watch } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import ExamBlock from '@/components/ExamBlock.vue'

import {
  Reading,
  DeleteFilled
} from '@element-plus/icons'

export default defineComponent({
  components: {
    DeleteFilled,
    TableList,
    SearchClass,
    ExamBlock,
    FormList
  },
  props: {
    courseId: {
      type: String
    },
    courseStatus: {
      type: Number,
      default: -1
    },
    isReadOnly: {
      type: Boolean,
      default: false
    }
  },
  setup: (props) => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false,
        isDrawerMultiple: false
      } as any,
      queryData: {
        courseId: props.courseId,
        name: '%%',
        sort: 'sequence asc'
      },
      examResult: {},
      columns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'name',
          label: '章节名称'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }],
      currentChapterId: null,
      isVerifyDialog: false,
      parentChapters: [], // 父章节
      checkAll: false,
      isIndeterminate: true,
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      verifyList: [] as any[],
      verifyRadioList: [] as any[],
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'avatar',
          label: '头像',
          type: 'avatar',
          width: 100
        },
        {
          valueKey: 'name',
          label: '姓名',
          width: 120
        },
        {
          valueKey: 'username',
          label: '帐号',
          width: 120
        }, {
          valueKey: 'mobile',
          width: 120,
          label: '手机号'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }], // tableColumns
      searchInit: [], // 筛选条件项
      formList: [
        {
          type: 'none',
          key: 'id',
          width: '',
          value: null,
          required: true,
          defaultValue: null
        }, {
          type: 'input',
          label: '章节名',
          key: 'name',
          width: '',
          value: null,
          required: true,
          defaultValue: ''
        }, {
          type: 'radioButton',
          key: 'modelValue',
          modelValue: '1',
          list: [{
            label: '视频链接',
            value: '1'
          }, {
            label: '本地视频上传',
            value: '2'
          }],
          defaultValue: '1'
        },
        {
          type: 'textarea',
          label: '视频链接',
          if: 'modelValue',
          ifValue: '1',
          minRows: 4,
          key: 'path',
          width: '',
          value: null,
          defaultValue: ''
        }, {
          type: 'uploadFile',
          label: '上传本地视频',
          fileList: [],
          limit: 1,
          if: 'modelValue',
          ifValue: '2',
          key: 'video',
          width: '',
          value: null,
          defaultValue: ''
        }, {
          type: 'number',
          label: '排序',
          key: 'sequence',
          width: '',
          value: null,
          required: true,
          defaultValue: 1
        }
        // {
        //   type: 'remote-select',
        //   label: '章节试卷',
        //   key: 'volumnId',
        //   placeholder: '输入试卷名搜索',
        //   url: '',
        //   width: '',
        //   value: null,
        //   defaultValue: ''
        // }
      ]
    })

    const search = (searchInfo) => {
      state.queryData.name = '%%'
      state.queryData = { ...state.queryData, ...searchInfo }
    }

    const openDrawer = async (val) => {
      state.formList.forEach((res: any) => {
        if (res?.type === 'radioButton') {
          res.defaultValue = val.path ? '1' : '2'
          res.value = val.path ? '1' : '2'
          res.modelValue = val.path ? '1' : '2'
        } else if (res?.type === 'uploadFile') {
          res.fileList = val.path ? [] : [{
            name: val.video,
            url: val.video
          }]
          res.value = val.path || val.video
        } else {
          res.value = val[res.key]
        }
      })
      state.pageParams.isEdit = true
      state.pageParams.isDrawer = true
    }

    const getChapters = () => {
      tools.post('/chapters/getDataById', { courseId: props.courseId }).then(r => {
        state.parentChapters = r.data
      })
    }

    const submit = async (val) => {
      const data = JSON.parse(JSON.stringify(val))
      data.courseId = props.courseId
      delete data.modelValue
      data.parentId = val.parentId ? (typeof val.parentId === 'string' ? val.parentId : val.parentId[0]) : null
      // 先判断当前课程的状态，如果不是待提交，都要提示会走一个新的流程！
      const noticeResult = props.courseStatus !== -1 ? await tools.confirm('温馨提示', '修改和新增章节都将使课程变为未提交状态，需要重新提交审核才能启用，确定要修改当前课程章节？') : true
      if (!noticeResult) {
        return
      }
      const loading = tools.showLoading('提交中...')
      try {
        if (state.pageParams.isEdit) {
          const res = await tools.post('/chapters/updateById', data)
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
            // 更新章节必须删除当前的章节的观看记录；传入staffId,chapterId
            await tools.post('/watchRecord/deleteById', { chapterId: val.id })
          }
        } else {
          delete data.id
          const rr = await tools.post('/chapters/create', data)
          if (rr.success) {
            state.pageParams.isDrawer = false
            tools.msg(rr.msg)
            state.pageParams.refresh = true
          }
        }
        // 检测章节是否是ppt/pptx是就默认转换ppt
        pptConvert(data.video)
        const courseResult = (props.courseStatus !== -1 && noticeResult) ? await tools.post('/courses/updateById', {
          id: props.courseId,
          status: -1
        }) : {}
        tools.closeLoading(loading)
        // 改变课程状态！
      } catch (e) {
        tools.closeLoading(loading)
      }
    }

    const openVerify = (val) => {
      state.currentChapterId = val.id
      tools.post('/verify/getListByChapterId', {
        chapterId: val.id
      }).then(r => {
        state.verifyList = r.list
        state.isVerifyDialog = true
      })
    }

    const addVerify = () => {
      (state.verifyList as any).push({
        time: 10,
        typeId: 1
      })
    }

    const pptConvert = (path) => {
      const postfixArr = path.replace(/\?(.*)/, '').split('.')
      const postfix = postfixArr[postfixArr.length - 1]
      const pptExp = new RegExp(/(pppt|pptx)$/)
      if (pptExp.test(postfix)) {
        try {
          tools.get('/convertVideo', { url: path })
        } catch (e) {
          console.error(e)
        }
      }
    }

    const deleteVerify = (item, index) => {
      state.verifyList.splice(index, 1)
      item.examData = {}
    }

    const verifySubmit = async () => {
      // 验证是否有标题没写的，或者没有选择正确答案的！
      for (let i = 0; i < state.verifyList.length; i++) {
        const res = state.verifyList[i]
        if (res.typeCode === 'byChapter' && res.examData?.options.length === 0) {
          tools.msgError('选项不能为空！')
          return
        } else if (res.typeCode === 'byChapter' && !res.examData?.title) {
          tools.msgError('标题不能为空！')
          return
        } else if (res.typeCode === 'byChapter' && (!res.examData?.rightAnswer || res.examData?.rightAnswer === '无')) {
          tools.msgError('请设置正确答案！')
          return
        }
      }
      if (state.verifyList) {
        await tools.post('/courseVerify/update', {
          chapterId: state.currentChapterId,
          verifyList: state.verifyList
        }).then(r => {
          if (r.success) {
            tools.msg(r.msg)
            state.isVerifyDialog = false
            state.pageParams = true
          }
        })
      }
    }

    const verifyRadioChange = (e: any, dd: any, item: any) => {
      item.typeCode = dd.code
    }

    onMounted(() => {
      getChapters()
      tools.post('/dictionaryData/getByTypeCode', { typeCode: 'videoVerify' }).then(r => {
        state.verifyRadioList = r.list
      })
    })

    watch(() => props.isReadOnly, (newVal) => {
      console.log('===>', newVal)
    })

    return {
      tools,
      verifySubmit,
      ...toRefs(state),
      Reading,
      addVerify,
      deleteVerify,
      verifyRadioChange,
      openVerify,
      openDrawer,
      submit,
      search
    }
  }
})

</script>
