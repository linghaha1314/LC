<template>
  <div class="course-manage-class">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search">
      <template v-slot:left-btn>
        <el-button
          plain
          size="small"
          type="primary"
          @click="$tools.openDrawer(pageParams)"
        >新增
        </el-button>
        <el-button plain size="small" type="success" @click="$tools.aDown('课程分类导入模版.xlsx','./xlsx/课程分类导入.xlsx')">
          模板下载
        </el-button>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="warning"
          @click="importMulti"
        >批量导入
        </el-button>
        <el-button
          class="background-btn"
          plain
          size="small"
          type="warning"
          @click="exportMulti"
        >批量导出
        </el-button>
      </template>
    </search-class>
    <table-list v-model:refresh="pageParams.refresh" v-model:selection="selection" :columns="columns"
                v-model:list="tableList"
                url="/courseType/getListByPage" :query-data="{limit:1000,sort:'sequence asc'}">
      <template v-slot="scope">
        <el-button size="small" type="text" @click="$tools.openDrawer(pageParams,true,formList,scope.row)"
        >查看/修改
        </el-button>
        <el-button
          class="font-red"
          size="small"
          type="text"
          @click="deleteData(scope.row)"
        >删除
        </el-button>
      </template>
    </table-list>
    <el-drawer
      v-model="pageParams.isDrawer"
      :append-to-body="false"
      :destroy-on-close="true"
      direction="rtl"
      size="40%"
      title="课程类型设置"
    >
      <form-list :isEdit="pageParams.isEdit" :list="formList" @submit="submit"></form-list>
    </el-drawer>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, toRefs } from 'vue'
import SearchClass from '../components/SearchClass.vue'
import tools from '@/utils/tool'
import { ElForm } from 'element-plus'
import TableList from '@/viewsManage/components/TableList.vue'
import FormList from '@/viewsManage/components/FormList.vue'
import img from 'wangeditor/src/menus/img'

export default defineComponent({
  components: {
    SearchClass,
    FormList,
    TableList
  },
  setup: () => {
    const state = reactive({
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      tableList: [],
      selection: [],
      columns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        }, {
          valueKey: 'name',
          label: '分类名称'
        },
        {
          valueKey: 'code',
          label: '编码'
        },
        {
          valueKey: 'created',
          label: '创建日期',
          type: 'time'
        }],
      formList: [{
        type: 'none',
        key: 'id',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '类别名称',
        key: 'name',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'input',
        label: '编码',
        key: 'code',
        width: '',
        value: null,
        required: true,
        defaultValue: null
      }, {
        type: 'cascade',
        label: '父级分类',
        key: 'parentId',
        width: '',
        value: null,
        url: '/courseType/getListByPage',
        queryParams: { limit: 1000 },
        defaultValue: ''
      }, {
        type: 'number',
        label: '排序',
        key: 'sequence',
        width: '60',
        value: '',
        defaultValue: null
      }, {
        type: 'uploadImg',
        label: '课程封面',
        key: 'img',
        width: '',
        value: null,
        defaultValue: ''
      }],
      searchInfo: {}, // 筛选条件
      searchInit: [
        {
          name: 'isSearch',
          value: 'search',
          desc: '关键词',
          placeholder: '请输入内容'
        },
        {
          name: 'isTime',
          value: 'time',
          desc: '日期',
          placeholder: '选择日期'
        }
      ], // 筛选条件项
      typeList: [],
      courseTypeProps: {
        value: 'id',
        label: 'name',
        children: 'children'
      } // 格式规范
    })

    const formRef = ref(ElForm)

    const rules = reactive({
      name: [
        {
          required: true,
          message: '请输入类别名称',
          trigger: 'blur'
        }
      ],
      code: [
        {
          required: true,
          message: '请输入类别编码',
          trigger: 'blur'
        }
      ]
    })

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      const obj: any = {
        name: data.name,
        icon: data.icon,
        code: data.code,
        parentId: data.parentId ? (typeof data.parentId === 'string' ? data.parentId : data.parentId[data.parentId.length - 1]) : null,
        status: data.status,
        sequence: data.sequence,
        path: data.path,
        img: data.img
      }
      if (state.pageParams.isEdit) {
        obj.id = data.id
        tools.post('/courseType/updateById', obj).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
            if (data.img) { // 给对应的课程类型没有封面的课程加上封面！
              tools.post('/api/rest/courses/updateCouresImgByTypeId', {
                typeId: data.id,
                img: data.img
              })
            }
          }
        })
        return
      }
      tools.post('/courseType/create', obj).then(res => {
        if (res.success) {
          state.pageParams.isDrawer = false
          tools.msg(res.msg)
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }

    const deleteData = (val) => {
      tools.deleteMultiCondition('courseType', {
        code: val.code + '%'
      }, state.pageParams)
    }

    const importMulti = async () => {
      const list: any = await tools.importData({
        一级名称: 'name',
        一级编码: 'code',
        二级名称: 'childName',
        二级编码: 'childCode',
        三级级名称: 'ThreeName',
        三级编码: 'ThreeCode'
      })
      const arr: any = []
      let index = -1
      list.forEach(r => {
        if (index === -1 || arr[index].code !== r.code) {
          const obj = (r.childName || r.childName !== undefined) ? {
            name: r.name,
            code: r.code,
            children: [{
              name: r.childName,
              code: r.childCode
            }]
          } : {
            name: r.name,
            code: r.code
          }
          arr.push(obj)
          index++
        } else {
          arr[index].children.push({
            name: r.childName,
            code: r.childCode
          })
        }
      })
      const loading = tools.showLoading('导入中...')
      for (const res of arr) {
        res.index = arr.indexOf(res)
        await createData(res)
      }
      tools.closeLoading(loading)
      state.pageParams.refresh = true
      tools.msg('导入成功！')
    }

    const recursionArr = (list: any = [], arr: any = [], defineProps, parentItem: any = {}) => {
      arr.forEach((res) => {
        const obj: any = {}
        for (const key in defineProps) {
          obj[key] = res[defineProps[`${key}`]]
        }
        if (res.parentId) {
          obj['父级'] = parentItem.name
          obj['父级编码'] = parentItem.code
        }
        list.push(obj)
        if (res.children && res.children.length > 0) {
          recursionArr(list, res.children, defineProps, res)
        }
      })
    }

    const exportMulti = async () => {
      const defineProps = {
        名称: 'name',
        编码: 'code'
      }
      const arr: any = []
      recursionArr(arr, state.tableList, defineProps)
      tools.exportExcel(arr, '课程分类')
    }

    const createData = async (item) => {
      const result = (await tools.post('/courseType/create', {
        name: item.name,
        code: item.code,
        parentId: item.parentId || null,
        sequence: item.index + 1 || null
      })).id.rows[0]
      if (item.children && item.children.length > 0) {
        for (const res of item.children) {
          await createData({
            ...res,
            parentId: result.id,
            code: result.code + '_' + res.code,
            sequence: item.children.indexOf(res) + 1 || null
          })
        }
      }
    }

    return {
      ...toRefs(state),
      rules,
      formRef,
      deleteData,
      exportMulti,
      importMulti,
      submit,
      search
    }
  }
})
</script>

<style lang="less" scoped>
</style>
