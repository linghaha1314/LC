<template>
  课程审批
  //接口查询-根据aprroval_process_id=课程&&code==当前角色&&科室==当前人员；查询workflow=>整个工作流的进度！
</template>

<script lang="ts" setup>
import { onMounted } from 'vue'
import tools from '@/utils/tool'

onMounted(() => {
  const loading = tools.showLoading()
})
</script>

<style scoped>

</style>
