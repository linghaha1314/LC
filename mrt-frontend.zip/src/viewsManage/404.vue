<template>
  <div style="display: flex;justify-content: center;align-items: center; height: calc(100vh - 150px)">
    <img src="../assets/images/404.png">
  </div>
</template>

<script>
export default {
  name: '404.vue'
}
</script>

<style scoped>

</style>
