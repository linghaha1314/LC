<template>
  <div class="dictionary-type">
    <!-- 筛选条件 -->
    <search-class v-model:refresh="pageParams.refresh" :searchInit="searchInit" @search="search" :is-show-export-btn="true" @exportAll="exportFn">
    </search-class>
    <!-- 列表数据 -->
    <table-list v-model:list="list" v-model:refresh="pageParams.refresh" v-model:selection="selection"
                :columns="tableColumns"
                http-type="post"
                :query-data="searchInfo" url="/feedback/getDataListByPage">
      <template v-slot="scope">
        <el-button size="small" type="text" @click="showDialog(scope.row)">查看
        </el-button>
      </template>
    </table-list>
    <el-dialog v-model="isShowDialog">
      <template v-slot:title>
        <strip-title style="height:40px">查看详情</strip-title>
      </template>
      <div class="text item">
        内容：{{ currentItem.content }}
      </div>
      <div class="text item">
        提交人：{{ currentItem.staffName }}
      </div>
      <div class="text item">
        图片：
        <div v-for="img in currentItem.paths" :key="img.id" style="display: inline-block;">
          <img :src="img.path" style="border-radius: 4px;width: 100px;height:100px;margin: 8px"/>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref, toRefs } from 'vue'
import SearchClass from '@/viewsManage/components/SearchClass.vue'
import tools from '@/utils/tool'
import TableList from '@/viewsManage/components/TableList.vue'
import StripTitle from '@/components/StripTitle.vue'

export default defineComponent({
  name: '',
  components: {
    SearchClass,
    StripTitle,
    TableList
  },
  setup: () => {
    const state = reactive({
      list: [],
      currentItem: {} as any,
      isShowDialog: false,
      pageParams: {
        isEdit: false,
        isDrawer: false,
        refresh: false
      },
      searchInfo: {}, // 定义搜索条件
      selection: [], // 选项数组
      tableColumns: [
        {
          valueKey: 'selection',
          label: '',
          type: 'selection'
        },
        {
          valueKey: 'content',
          label: '内容',
          width: 120
        },
        {
          valueKey: 'staffName',
          label: '人员',
          width: 120
        },
        {
          valueKey: 'created',
          label: '创建时间',
          type: 'time'
        }],
      defineProps: {
        内容: 'content',
        提交人: 'staffName',
        时间: 'created'
      },
      searchInit: [] // 筛选条件项
    })

    const searchData = ref({
      searchInfo: {}, // 定义搜索条件
      searchInit: [
        {
          name: 'isSelect',
          desc: '专业',
          value: 'searchProfession', // 返回值的名称
          placeholder: '请选择选择专业',
          options: []
        },
        {
          name: 'isSelect',
          desc: '科室',
          value: 'searchDepartment',
          placeholder: '请选择选择科室',
          options: []
        }
      ],
      leftBtn: [{
        name: '添加',
        fn: () => {
          // tools.openDrawer(state.pageParams)
        }
      }, {
        name: '删除',
        type: 'danger'
      }]
    })

    const submit = (val) => {
      const data = JSON.parse(JSON.stringify(val))
      if (state.pageParams.isEdit) {
        tools.post('/dictionaryData/updateById', data).then(res => {
          if (res.success) {
            state.pageParams.isDrawer = false
            tools.msg(res.msg)
            state.pageParams.refresh = true
          }
        })
        return
      }
      delete data.id
      tools.post('/dictionaryData/create', data).then(res => {
        if (res.success) {
          tools.msg(res.msg)
          state.pageParams.isDrawer = false
          state.pageParams.refresh = true
        }
      })
    }

    const search = (searchInfo) => {
      // state.queryParams = { ...state.queryParams, ...searchInfo }
    }

    const showDialog = (item) => {
      state.currentItem.paths = JSON.parse(item?.paths)
      state.currentItem.content = item.content
      state.currentItem.staffName = item.staffName
      state.isShowDialog = true
    }

    const exportFn = () => {
      // 导出全部，导出当前页面！
      const arr: any = [...state.list]
      // arr.forEach(item => {
      //   item.sectionId = state.sectionsIds[item.sectionId]
      //   item.majorId = state.majorsIds[item.majorId]
      // })
      tools.writeFile(arr, state.defineProps)
    }
    return {
      searchData,
      ...toRefs(state),
      submit,
      showDialog,
      search,
      exportFn,
      tools
    }
  }
})
</script>
