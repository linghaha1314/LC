<template>
  <div class="login-head">
    <span class="title">三知教育管理平台</span>
    <a href="http://117.159.24.46:3002/#/Index">
      <el-button type="warning" style="height: 44px;">返回首页</el-button>
    </a>
  </div>
  <div class="login-box">
    <div class="login">
      <el-row class="header-box">
        <img
          alt
          src="@/assets/images/head-logo.png"
          style="height: 100%; margin: 10px 0 0 58px"
        />
      </el-row>
      <el-row class="form-box">
        <el-form
          ref="ruleForm"
          :model="ruleForm"
          :rules="rules"
          class="demo-ruleForm"
          label-position="top"
          label-width="100px"
          status-icon
        >
          <!-- 用户 -->
          <el-form-item class="user-from" label="用户" prop="username">
            <i class="el-icon-user-solid"></i>
            <el-input
              v-model="ruleForm.username"
              :clearable="false"
              placeholder="请输入账号"
              type="text"
            ></el-input>
          </el-form-item>
          <!-- 密码 -->
          <el-form-item label="密码" prop="password">
            <i class="el-icon-user"></i>
            <el-input
              v-model="ruleForm.password"
              autocomplete="off"
              placeholder="请输入密码"
              type="password"
            ></el-input>
          </el-form-item>
          <el-form-item prop="code">
            <div style="display: flex;align-items: center;">
              <el-input
                v-model="ruleForm.code"
                autocomplete="off"
                placeholder="验证码"
                style="width:160px"
                type="text" name="" oninput="value=value.replace(/[^\d]/g,'')"
                @keydown.enter="submitForm()"
              ></el-input>
              <span style="margin-left: 20px" @click="getVerify" v-html="svg"></span>
            </div>
          </el-form-item>
        </el-form>
        <el-row class="auto-login" justify="start" type="flex">
          <el-checkbox v-model="checked">下次自动登录</el-checkbox>
        </el-row>
        <el-button
          style="width: 360px; height: 46px; font-size: 20px"
          type="primary"
          @click="submitForm()"
        >立即登录
        </el-button>
      </el-row>
    </div>
  </div>
</template>

<script>
import tools from '@/utils/tool'
import CryptoJS from 'crypto-js'
import store from '@/store'

export default {
  data() {
    const validateUser = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入账号'))
      } else {
        callback()
      }
    }
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.ruleForm.password !== '') {
          this.$refs.ruleForm.validateField('password')
        }
        callback()
      }
    }
    const validateCode = (rule, value, callback) => {
      if (value === '' || this.ruleForm.code.toLowerCase() !== this.svgCode.toLowerCase()) {
        callback(new Error('请输入正确的验证码'))
      } else {
        this.$refs.ruleForm.validateField('code')
        callback()
      }
    }
    return {
      svg: '',
      svgCode: '',
      checked: true,
      ruleForm: {
        username: '',
        password: '',
        code: ''
      },
      rules: {
        username: [{
          validator: validatePass,
          trigger: 'blur'
        }],
        password: [{
          validator: validateUser,
          trigger: 'blur'
        }],
        code: [{
          validator: validateCode,
          trigger: 'blur'
        }]
      }
    }
  },
  methods: {
    submitForm() {
      this.$refs.ruleForm.validate(async (valid) => {
        if (valid) {
          const loading = tools.showLoading('登录中...')
          const data = JSON.parse(JSON.stringify(this.ruleForm))
          data.password = CryptoJS.AES.encrypt(data.password, 'kb12315').toString()
          try {
            const loginResult = await this.$tools.post('login', data, false)
            tools.closeLoading(loading)
            if (loginResult.success) {
              store.commit('setManageToken', loginResult.token)
              await store.dispatch('getManageUserInfo', { id: loginResult.id }).then(r => {
                store.commit('setManageMenuId', null)
                this.$router.push('/manage/welcome')
                if (store.state.manageUserInfo.roles.length > 1) {
                  store.commit('setIsSelectRoleDialog', true)
                }
              })
            } else {
              tools.msgError(loginResult.msg)
            }
          } catch (e) {
            tools.closeLoading(loading)
          }
        }
      })
    },
    getVerify() {
      tools.get('/public/getCode').then(r => {
        this.svg = r.data
        this.svgCode = r.text
      })
    }
  },
  mounted() {
    this.getVerify()
  }
}

</script>

<style lang="less" scoped>
@import (once) "~@/assets/css/manage.less";

.login-head {
  background: #ffffff;
  height: 80px;
  display: flex;
  padding: 0 32px;
  justify-content: space-between;
  align-items: center;

  & > .title {
    color: @primaryColor;
    font-size: 42px;
    font-weight: bolder;
    margin-left: 40px;
    display: flex;
  }
}

.login-box {
  height: 100vh;
  width: 100vw;
  background: url(../assets/images/manage/login-back.jpg) center no-repeat;
  background-size: 100% 100%;
  position: relative;

  .login {
    background: #ffffff;
    position: absolute;
    border-radius: 4px;
    top: 50%;
    left: 60%;
    transform: translateY(-50%);

    .header-box {
      text-align: left;
      height: 90px;

      .el-icon-close {
        font-size: 20px;
        position: absolute;
        top: 0;
        right: 0;
        color: #999999;
      }
    }

    .form-box {
      padding: 30px 65px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: flex-start;

      .el-form {
        .el-form-item {
          position: relative;

          i {
            position: absolute;
            top: 50%;
            left: 0;
            font-size: 20px;
            transform: translateY(-50%);
            width: 40px;
            z-index: 99;
            text-align: center;
          }

          .el-input {
            width: 360px;
            height: 45px;
          }
        }
      }

      .auto-login {
        width: 100%;
        font-size: 16px;
        font-weight: 400;
        line-height: 24px;
        color: #bdbdbd;
        margin-bottom: 25px;
      }
    }
  }
}
</style>
