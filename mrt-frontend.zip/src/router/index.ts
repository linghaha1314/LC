import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'
import ManageRouter from './manage'
import ClientRouter from './client'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/manage/login',
    component: () => import('../viewsManage/Login.vue')
  },
  {
    path: '/',
    redirect: '/client/home' // 重定向
  },
  {
    path: '/:pathMatch(manage.*)',
    redirect: '/manage/404'
  },
  {
    path: '/manage/examCreate',
    name: 'examCreate',
    component: () => import('@/viewsManage/exam/ExamCreate.vue'),
    meta: {
      title: '试卷创建'
    }
  },
  {
    path: '/client/exam',
    name: 'exam',
    component: () => import('@/viewsClient/Test.vue'),
    meta: {
      title: '考试'
    }
  },
  ClientRouter,
  ManageRouter
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes,
  scrollBehavior () {
    return { left: 0, top: 0 }
  }
})

export default router
