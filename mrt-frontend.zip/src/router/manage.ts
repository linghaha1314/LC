const ManageRouter = {
  path: '/manage',
  name: 'manageIndex',
  component: () => import('../viewsManage/Index/Index.vue'),
  redirect: '/manage/menuManage',
  meta: {
    title: '系统管理'
  },
  children: [
    {
      path: '404',
      component: () => import('../viewsManage/404.vue'),
      meta: {
        title: 'not found'
      }
    },
    {
      path: 'welcome',
      component: () => import('../viewsManage/welcome.vue'),
      meta: {
        title: '欢迎'
      }
    },
    {
      path: 'usersManage',
      name: 'usersManage',
      component: () => import('@/viewsManage/systemManage/UsersManage.vue'),
      meta: {
        title: '用户管理'
      }
    },
    {
      path: 'usersPortal',
      name: 'usersPortal',
      component: () => import('@/viewsManage/systemManage/UsersManage.vue'),
      meta: {
        title: '用户管理'
      }
    },
    {
      path: 'menuManage',
      name: 'menuManage',
      component: () => import('@/viewsManage/systemManage/MenuManage.vue'),
      meta: {
        title: '菜单管理'
      }
    },
    {
      path: 'famousTeacher',
      name: 'famousTeacher',
      component: () => import('@/viewsManage/systemManage/FamousTeacher.vue'),
      meta: {
        title: '讲师管理'
      }
    },
    {
      path: 'majorManage',
      name: 'majorManage',
      component: () => import('@/viewsManage/systemManage/MajorManage.vue'),
      meta: {
        title: '专业管理'
      }
    },
    {
      path: 'sectionManage',
      name: 'sectionManage',
      component: () => import('@/viewsManage/systemManage/SectionManage.vue'),
      meta: {
        title: '科室管理'
      }
    },
    {
      path: 'approvalProcess',
      name: 'approvalProcess',
      component: () => import('@/viewsManage/systemManage/ApprovalProcess.vue'),
      meta: {
        title: '审批流程管理'
      }
    },
    {
      path: 'courseManage',
      name: 'courseManage',
      component: () => import('@/viewsManage/course/CourseManage.vue'),
      meta: {
        isNoPadding: true,
        title: '课程管理'
      }
    },
    {
      path: 'coursePermission',
      name: 'coursePermission',
      component: () => import('@/viewsManage/course/CoursePermission.vue'),
      meta: {
        title: '课程权限'
      }
    },
    {
      path: 'videoManage',
      name: 'videoManage',
      component: () => import('@/viewsManage/course/VideoManage.vue'),
      meta: {
        title: '视频管理'
      }
    },
    {
      path: 'courseType',
      name: 'courseType',
      component: () => import('@/viewsManage/course/CourseType.vue'),
      meta: {
        title: '课程分类'
      }
    },
    {
      path: 'courseApproval',
      name: 'courseApproval',
      component: () => import('@/viewsManage/course/CourseApproval.vue'),
      meta: {
        title: '课程审批'
      }
    },
    {
      path: 'recommendCourseApproval',
      name: 'recommendCourseApproval',
      component: () => import('@/viewsManage/course/RecommendCourseApproval.vue'),
      meta: {
        title: '首页课程推荐审批'
      }
    },
    {
      path: 'recommmend',
      name: 'recommmend',
      component: () => import('@/viewsManage/home/Recommend.vue'),
      meta: {
        title: '推荐管理'
      }
    },
    {
      path: 'certManage',
      name: 'certManage',
      component: () => import('@/viewsManage/course/CertManage.vue'),
      meta: {
        title: '证书管理'
      }
    },
    {
      path: 'roleManage',
      name: 'roleManage',
      component: () => import('@/viewsManage/systemManage/RoleManage.vue'),
      meta: {
        title: '角色管理'
      }
    },
    {
      path: 'swiperManage',
      name: 'swiperManage',
      component: () => import('@/viewsManage/home/SwiperManage.vue'),
      meta: {
        title: '轮播图'
      }
    },
    {
      path: 'msgPush',
      name: 'msgPush',
      component: () => import('@/viewsManage/home/MsgPush.vue'),
      meta: {
        title: '消息推送'
      }
    },
    {
      path: 'navManage',
      name: 'navManage',
      component: () => import('@/viewsManage/home/NavManage.vue'),
      meta: {
        title: '导航管理'
      }
    },
    {
      path: 'columnSetting',
      name: 'columnSetting',
      component: () => import('@/viewsManage/home/ColumnSetting.vue'),
      meta: {
        title: '栏目管理'
      }
    },
    {
      path: 'examPaperManage',
      name: 'examPaperManage',
      component: () => import('@/viewsManage/exam/ExamPaperManage.vue'),
      meta: {
        title: '试卷管理'
      }
    },
    {
      path: 'usersStatistic',
      name: 'usersStatistic',
      component: () =>
        import('@/viewsManage/statisticsManage/UsersStatistic.vue'),
      meta: {
        title: '用户统计'
      }
    }, {
      path: 'cycleStatistic',
      name: 'cycleStatistic',
      component: () =>
        import('@/viewsManage/statisticsManage/CycleStatistic.vue'),
      meta: {
        title: '周期数据统计'
      }
    },
    {
      path: 'studyStatistic',
      name: 'studyStatistic',
      component: () =>
        import('@/viewsManage/statisticsManage/StudyStatistic.vue'),
      meta: {
        title: '学习统计'
      }
    },
    {
      path: 'courseStatistic',
      name: 'courseStatistic',
      component: () =>
        import('@/viewsManage/statisticsManage/CourseStatistic.vue'),
      meta: {
        title: '课程统计'
      }
    },
    {
      path: 'dictionaryType',
      name: 'dictionaryType',
      component: () => import('@/viewsManage/dictionary/DictionaryType.vue'),
      meta: {
        title: '字典类型'
      }
    },
    {
      path: 'dictionaryData',
      name: 'dictionaryData',
      component: () => import('@/viewsManage/dictionary/DictionaryData.vue'),
      meta: {
        title: '字典数据'
      }
    },
    {
      path: 'portalSite',
      name: 'portalSite',
      component: () => import('@/viewsManage/portalSite/menusManage.vue'),
      meta: {
        title: '门户菜单管理'
      }
    },
    {
      path: 'secondaryColumn',
      name: 'secondaryColumn',
      component: () => import('@/viewsManage/portalSite/DictionaryData.vue'),
      meta: {
        title: '二级栏目管理'
      }
    },
    {
      path: 'Message-type',
      name: 'Message-type',
      component: () => import('@/viewsManage/portalSite/Message-type.vue'),
      meta: {
        title: '消息类型'
      }
    },
    {
      path: 'Message-release',
      name: 'Message-release',
      component: () => import('@/viewsManage/portalSite/Message-release.vue'),
      meta: {
        title: '消息发布'
      }
    },
    {
      path: 'Message-common',
      name: 'Message-common',
      component: () => import('@/viewsManage/portalSite/Message-common.vue'),
      meta: {
        title: '通用消息发布'
      }
    },
    {
      path: 'Message-approval',
      name: 'Message-approval',
      component: () => import('@/viewsManage/portalSite/Message-approval.vue'),
      meta: {
        title: '通用消息审核'
      }
    },
    {
      path: 'Rules-approval',
      name: 'Rules-approval',
      component: () => import('@/viewsManage/portalSite/Rules-approval.vue'),
      meta: {
        title: '规章制度审核'
      }
    },
    {
      path: 'Teaching-approval',
      name: 'Teaching-approval',
      component: () => import('@/viewsManage/portalSite/Teaching-approval.vue'),
      meta: {
        title: '教学动态审核'
      }
    },
    {
      path: 'Teacher-approval',
      name: 'Teacher-approval',
      component: () => import('@/viewsManage/portalSite/Teacher-approval.vue'),
      meta: {
        title: '教师风采审核'
      }
    },
    {
      path: 'Download-approval',
      name: 'Download-approval',
      component: () => import('@/viewsManage/portalSite/Download-approval.vue'),
      meta: {
        title: '资料下载审核'
      }
    },
    {
      path: 'Enrollment-approval',
      name: 'Enrollment-approval',
      component: () =>
        import('@/viewsManage/portalSite/Enrollment-approval.vue'),
      meta: {
        title: '培训招聘审核'
      }
    },
    {
      path: 'Rules-regulations',
      name: 'Rules-regulations',
      component: () => import('@/viewsManage/portalSite/Rules-regulations.vue'),
      meta: {
        title: '规章制度'
      }
    },
    {
      path: 'Leave-msg',
      name: 'Leave-msg',
      component: () => import('@/viewsManage/portalSite/Leave-msg.vue'),
      meta: {
        title: '在线留言'
      }
    },
    {
      path: 'log',
      name: 'log',
      component: () => import('@/viewsManage/systemManage/log.vue'),
      meta: {
        title: '在线留言'
      }
    },
    {
      path: 'Teacher-style',
      name: 'Teacher-style',
      component: () => import('@/viewsManage/portalSite/Teacher-style.vue'),
      meta: {
        title: '教师风采'
      }
    },
    {
      path: 'Image-set',
      name: 'Image-set',
      component: () => import('@/viewsManage/portalSite/Image-set.vue'),
      meta: {
        title: '图片设置'
      }
    },
    {
      path: 'Links',
      name: 'Links',
      component: () => import('@/viewsManage/portalSite/Links.vue'),
      meta: {
        title: '友情链接'
      }
    },
    {
      path: 'Teaching',
      name: 'Teaching',
      component: () => import('@/viewsManage/portalSite/Teaching.vue'),
      meta: {
        title: '教学动态'
      }
    },
    {
      path: 'Enrollment-training',
      name: 'Enrollment-training',
      component: () =>
        import('@/viewsManage/portalSite/Enrollment-training.vue'),
      meta: {
        title: '招生培训'
      }
    },
    // {
    //   path: 'Online-courses',
    //   name: 'Online-courses',
    //   component: () => import('@/viewsManage/portalSite/Online-courses.vue'),
    //   meta: {
    //     title: '在线课程'
    //   }
    // },
    {
      path: 'ArchivesManage',
      name: 'ArchivesManage',
      component: () => import('@/viewsManage/portalSite/ArchivesManage.vue'),
      meta: {
        title: '在线课程-课时'
      }
    },
    {
      path: 'Download-file',
      name: 'Download-file',
      component: () => import('@/viewsManage/portalSite/Download-file.vue'),
      meta: {
        title: '资料下载'
      }
    },
    {
      path: 'Test',
      name: 'Test',
      component: () => import('@/viewsManage/portalSite/Test.vue'),
      meta: {
        title: '测试页面'
      }
    }, {
      path: 'FeedbackManage',
      name: 'TestF',
      component: () => import('@/viewsManage/FeedbackManage.vue'),
      meta: {
        title: '意见反馈'
      }
    }
  ]
}
export default ManageRouter
