const ClientRouter = {
  path: '/client',
  name: 'client',
  component: () => import('@/viewsClient/Index.vue'),
  redirect: '/client/home',
  meta: {
    title: '系统管理'
  },
  children: [
    {
      path: 'home',
      name: 'home',
      component: () => import('@/viewsClient/newHome.vue'),
      meta: {
        title: '首页',
        isShowSearch: true
      }
    },
    {
      path: 'coursePlay/:id',
      name: 'coursePlay',
      component: () => import('@/viewsClient/course/CoursePlay.vue'),
      meta: {
        title: '视频播放'
      }
    },
    {
      path: 'teacherLecture',
      name: 'teacherLecture',
      component: () => import('@/viewsClient/doctor/TeacherLecture.vue'),
      meta: {
        title: '名师讲坛'
      }
    },
    {
      path: 'doctorCenter/:id',
      name: 'doctorCenter',
      component: () => import('@/viewsClient/doctor/DoctorCenter.vue'),
      meta: {
        title: '医生主页'
      }
    },
    {
      path: 'personal',
      name: 'personal',
      component: () => import('@/viewsClient/personal/Personal.vue'),
      meta: {
        title: '个人主页'
      }
    },
    {
      path: 'allCourse',
      name: 'allCourse',
      component: () => import('@/viewsClient/AllCourse.vue'),
      meta: {
        title: '全部课程',
        isShowSearch: true
      }
    },
    {
      path: 'msgView/:id',
      name: 'msgView',
      component: () => import('@/viewsClient/MsgView.vue'),
      meta: {
        title: '消息推送',
        isNotShowHead: true,
        isNotShowFooter: true
      }
    },
    {
      path: 'fileView',
      name: 'fileView',
      component: () => import('@/viewsClient/FileView.vue'),
      meta: {
        title: '文件预览',
        isNotShowHead: true,
        isNotShowFooter: true
      }
    },
    {
      path: 'test',
      name: 'test',
      component: () => import('@/viewsClient/Test.vue'),
      meta: {
        title: '测试'
      }
    }
    // /* 找寻密码 */
    // {
    //   path: 'findPass',
    //   name: 'findPass',
    //   component: () => import('@/viewsClient/pass/FindPass'),
    //   meta: {
    //     isContainer: true
    //   }
    // },
    // /* 设置密码 */
    // {
    //   path: 'setPass',
    //   name: 'setPass',
    //   component: () => import('@/viewsClient/pass/SetPass'),
    //   meta: {
    //     isContainer: true
    //   }
    // },
  ]
}
export default ClientRouter
