module.exports = {
  root: true,
  env: {
    node: true
  },
  extends: [
    'plugin:vue/vue3-essential',
    '@vue/standard',
    '@vue/typescript/recommended'
  ],
  parserOptions: {
    ecmaVersion: 2020
  },
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    'space-before-function-paren': 0, // 方法名和刮号之间需要有一格空格 - 关闭
    '@typescript-eslint/explicit-module-boundary-types': 'off',
    'vue/no-unused-vars': 'off',
    'eslint space-before-function-paren': 'off'
  }
}
