class UserInfo {
  Map<String, dynamic> accounts;
  Map<String, dynamic> roles;
  Map<String, dynamic> role;
  Map<String, dynamic> staff;

  toMap() {
    return {
      "accounts": accounts,
      "roles": roles,
      "role": role,
      "staff": staff,
    };
  }
}
