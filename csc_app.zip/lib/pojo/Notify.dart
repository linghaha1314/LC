import 'dart:convert';

class Notify {
  String route;
  String data;

  Notify(this.route, this.data);

  Notify.fromMap(Map<String, dynamic> map) {
    route = map["route"];
    data = map["data"];
  }

  String toJsonString() {
    return jsonEncode({"route": route, "data": data});
  }
}
