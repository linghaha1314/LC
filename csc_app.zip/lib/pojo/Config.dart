final String tableConfig = 'kb_config';
final String columnId = 'id';
final String columnValue = 'value';

class Config {
  String id;
  String value;

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      columnValue: value,
    };
    if (id != null) {
      map[columnId] = id;
    }
    return map;
  }

  Config(this.id, this.value);

  Config.fromMap(Map<String, dynamic> map) {
    id = map[columnId];
    value = map[columnValue];
  }
}
