import 'dart:convert';

class SendMessage {
  String title;
  String content;
  String senderId;
  String senderName;
  int status;
  String receiverIds;
  String chatType;
  String groupIds;
  String hospitalId;
  int sort;

  SendMessage(this.title, this.content, this.senderId, this.senderName, this.status,
      this.receiverIds, this.chatType, this.groupIds, this.hospitalId, this.sort);

  SendMessage.fromMap(Map<String, dynamic> map) {
    title = map["title"];
    content = map["content"];
    senderId = map["senderId"];
    senderName = map["senderName"];
    status = map["status"];
    receiverIds = map["receiverIds"];
    chatType = map["chatType"];
    groupIds = map["groupIds"];
    hospitalId = map["hospitalId"];
    sort = map["sort"];
  }

  Map<String, dynamic> toMap() {
    Map<String, dynamic> map = {};
    map["title"] = this.title;
    map["content"] = this.content;
    map["senderId"] = this.senderId;
    map["senderName"] = this.senderName;
    map["status"] = this.status;
    map["receiverIds"] = this.receiverIds;
    map["chatType"] = this.chatType;
    map["groupIds"] = this.groupIds;
    map["hospitalId"] = this.hospitalId;
    map["sort"] = this.sort;
    return map;
  }

  String toJsonString() {
    return jsonEncode(this.toMap());
  }
}
