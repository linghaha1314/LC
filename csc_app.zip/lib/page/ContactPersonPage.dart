import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import '../ThemeColor.dart';

class ContactPersonPage extends StatefulWidget {
  @override
  ContactPersonPageState createState() => new ContactPersonPageState();
}

class ContactPersonPageState extends State<ContactPersonPage> {
  String url;

  List<Map<String, dynamic>> list = [];

  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  ContactPersonPageState() {
    getHttpPath().then((path) {
      url = path;
    });
  }

  @override
  void initState() {
    super.initState();
    contactPersonPageState = this;
  }

  refresh() {
    _refreshController.requestRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Text("通讯录"),
      ),
      body: RefreshList(
        controller: _refreshController,
        searchText: "请输入姓名搜索",
        url: "/staff/listQueryByPage",
        buildItem: (dynamic row, int i) {
          return _buildRow(row);
        },
      ),
    );
  }

  final _biggerFont = const TextStyle(fontSize: 18.0);

  Widget _buildRow(dynamic row) {
    String t = (row['name']).toString().substring(0, 1);
    String avatar = "";
    if (row["avator"] != null) {
      avatar = url + row["avator"];
    }
    return ListTile(
      leading: CircleAvatar(
        child: CircularProfileAvatar(
          avatar,
          initialsText: Text(
            t,
            style: TextStyle(color: ThemeColor.getColor("fontColor")),
          ),
          borderColor: ThemeColor.getColor("content"),
          backgroundColor: ThemeColor.getColor("content"),
        ),
      ),
      title: Text(
        '${row['name']}',
        style: _biggerFont,
      ),
      subtitle: Text("${showString(row["sectionName"])}(${showString(row["typeName"])})"),
      trailing: Icon(Icons.arrow_forward),
      onTap: () {
        Navigator.of(context).pushNamed('chatDetailPage', arguments: {
          "name": row["name"],
          "senderId": row["id"],
          "avator": row["avator"]
        });
      },
    );
  }

  @override
  void dispose() {
    contactPersonPageState = null;
    super.dispose();
  }
}
