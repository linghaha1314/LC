import 'dart:convert';
import 'dart:ui';

import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/page/login/RegisterPage.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../HomePage.dart';
import 'bezierContainer.dart';
import 'SelectHospital.dart';

class LoginPage extends BaseApp {
  LoginPage({Key key, this.title}) : super();

  final String title;

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends BaseAppPage<LoginPage> {
  ConfigService configService = ConfigService();

  dynamic _hospital = {"name": "请选择医院"};

  String _username;

  String _password;

  TextEditingController _userCtrl;

  TextEditingController _pwdCtrl;

  bool _back = false;

  _LoginPageState() {
    barFlag = false;
    empty = false;
  }

  Widget _backButton() {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
              child: Icon(Icons.keyboard_arrow_left,
                  color: ThemeColor.getColor("fontColor")),
            ),
            Text('返回',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500))
          ],
        ),
      ),
    );
  }

  Widget _entryField(String title,
      {bool isPassword = false, bool isHospital = false}) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
          ),
          SizedBox(
            height: 10,
          ),
          isHospital
              ? Container(
                  child: MaterialButton(
                    padding: EdgeInsets.all(5.0),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: Text(
                        _hospital["name"],
                        textAlign: TextAlign.left,
                        style: TextStyle(fontSize: 16.0),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SelectHospital(),
                        ),
                      ).then((value) {
                        if (value != null) {
                          setState(() {
                            _hospital = value;
                          });
                          configService
                              .update(Config("baseUrl", value["url"]))
                              .then((value) {
                            getHttpPath(refresh: true).then((v) {});
                          });
                        }
                      });
                    },
                  ),
                  decoration: BoxDecoration(
                    color: ThemeColor.getColor("active"),
                  ),
                )
              : TextField(
                  obscureText: isPassword,
                  controller: title == "用户名" ? _userCtrl : _pwdCtrl,
                  onChanged: (v) {
                    if (title == "用户名") {
                      _username = v;
                    } else {
                      _password = v;
                    }
                  },
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    fillColor: ThemeColor.getColor("active"),
                    filled: true,
                  ),
                )
        ],
      ),
    );
  }

  Widget _submitButton() {
    return InkWell(
      onTap: _login,
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(vertical: 15),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(5)),
          boxShadow: <BoxShadow>[
            BoxShadow(
                color: Colors.grey.shade200,
                offset: Offset(2, 4),
                blurRadius: 5,
                spreadRadius: 2)
          ],
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [Color(0xfffbb448), Color(0xfff7892b)],
          ),
        ),
        child: Text(
          '登录',
          style: TextStyle(fontSize: 20, color: Colors.white),
        ),
      ),
    );
  }

  // Widget _divider() {
  //   return Container(
  //     margin: EdgeInsets.symmetric(vertical: 10),
  //     child: Row(
  //       children: <Widget>[
  //         SizedBox(
  //           width: 20,
  //         ),
  //         Expanded(
  //           child: Padding(
  //             padding: EdgeInsets.symmetric(horizontal: 10),
  //             child: Divider(
  //               thickness: 1,
  //             ),
  //           ),
  //         ),
  //         Text('或者'),
  //         Expanded(
  //           child: Padding(
  //             padding: EdgeInsets.symmetric(horizontal: 10),
  //             child: Divider(
  //               thickness: 1,
  //             ),
  //           ),
  //         ),
  //         SizedBox(
  //           width: 20,
  //         ),
  //       ],
  //     ),
  //   );
  // }

  Widget _title() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
          text: '',
          style: TextStyle(color: ThemeColor.getColor("focus")),
          children: [
            TextSpan(
              text: '华创医学模拟中心智慧管理平台',
              style: TextStyle(
                  color: ThemeColor.getColor("fontColor"), fontSize: 30),
            ),
            TextSpan(
              text: 'App',
              style:
                  TextStyle(color: ThemeColor.getColor("active"), fontSize: 30),
            ),
          ]),
    );
  }

  Widget _userNamePasswordWidget() {
    return Column(
      children: <Widget>[
        _entryField("医院", isHospital: true),
        _entryField("用户名"),
        _entryField("密码", isPassword: true),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    initToastContent(context);
    judgmentLogin().then((v) {
      if (v) {
        setState(() {
          _back = true;
        });
      }
    });
    configService.getConfig("account").then((v) {
      if (v == null) return;
      var data = jsonDecode(v);
      if (data["hospitalId"] == null) {
        showErrorToast("请重新选择医院!");
        return;
      }
      setState(() {
        _hospital = {"id": data["hospitalId"], "name": data["hospitalName"]};
        _username = data["username"];
        _password = data["password"];
        _userCtrl = TextEditingController(text: _username);
        _pwdCtrl = TextEditingController(text: _password);
      });
    });
  }

  @override
  Widget getBody(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
        body: Container(
      height: height,
      child: Stack(
        children: <Widget>[
          Positioned(
              top: -height * .15,
              right: -MediaQuery.of(context).size.width * .4,
              child: BezierContainer()),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(height: height * .15),
                  _title(),
                  SizedBox(height: 40),
                  _userNamePasswordWidget(),
                  SizedBox(height: 20),
                  _submitButton(),
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RegisterPage(),
                          ),
                        );
                      },
                      child: Text('注册',
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w500)),
                    ),
                  ),
//                  _divider(),
                  SizedBox(height: height * .055),
                ],
              ),
            ),
          ),
          Positioned(
            top: 40,
            left: 0,
            child: Visibility(
              child: _backButton(),
              visible: _back,
            ),
          ),
        ],
      ),
    ));
  }

  _login() {
    if (_hospital == null || _hospital["id"] == null) {
      showErrorAlert("请选择医院");
      return;
    }
    if (_username == null || _username.trim().length == 0) {
      showErrorAlert("请输入用户名");
      return;
    }
    if (_password == null || _password.trim().length == 0) {
      showErrorAlert("请输入密码");
      return;
    }
    setState(() {
      loading = true;
    });
    postNoAuth(
      "/login",
      {
        "username": _username,
        "password": _password,
        "hospitalId": _hospital["id"]
      },
      options: Options(
        headers: {
          "hospitalId": _hospital["id"],
        },
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
      ),
    ).then((value) {
      setAuth(value["token"]);
      showSuccessToast("登录成功!");
      configService
          .update(Config(
        "account",
        jsonEncode({
          "username": _username,
          "password": _password,
          "hospitalId": _hospital["id"],
          "hospitalName": _hospital["name"]
        }),
      ))
          .then((v) {
        configService.update(Config("auth", value["token"])).then((v) {
          configService.delete("userInfo").then((r) {
            refreshUserInfo().then((user) {
              configService
                  .update(Config("userInfo", jsonEncode(user.toMap())))
                  .then((value) {
                setState(() {
                  loading = false;
                });
                Navigator.of(context).pushAndRemoveUntil(
                  new MaterialPageRoute(
                    builder: (context) => Home(),
                  ),
                  (route) => route == null,
                );
              });
            });
          });
        });
      });
    }).catchError((err) {
      print(err);
      showErrorAlert(err["msg"]);
      setState(() {
        loading = false;
      });
    });
  }
}
