import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class RegisterPage extends BaseApp {
  @override
  _RegisterPageState createState() => new _RegisterPageState();
}

class _RegisterPageState extends BaseAppPage<RegisterPage> {
  TextEditingController _username;
  TextEditingController _password;

  _RegisterPageState() {
    title = "注册账号";
    empty = false;
    loading = true;
  }

  ConfigService configService = ConfigService();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _username = TextEditingController();
    _password = TextEditingController();
    var dio = Dio();
    dio
        .get(
            "http://116.63.181.221/root/config-data/raw/master/%E4%B8%B4%E5%BA%8A%E6%8A%80%E8%83%BD%E4%B8%AD%E5%BF%83%E9%85%8D%E7%BD%AE.json")
        .then((value) {
      var list = jsonDecode(value.toString());
      list.forEach((v) {
        if (v['id'] == 'csyy') {
          configService
              .update(Config("baseUrl", v["url"] as String))
              .then((value) {
            getHttpPath(refresh: true).then((v) {
              setState(() {
                loading = false;
              });
            });
          });
        }
      });
    });
  }

  @override
  Widget getBody(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "注册",
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w600,
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(20.0, .0, 20.0, .0),
            child: TextFormField(
              controller: _username,
              decoration: InputDecoration(
                hintText: '输入用户名',
                contentPadding: const EdgeInsets.symmetric(vertical: 10.0),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, .0),
            child: TextFormField(
              controller: _password,
              obscureText: true,
              decoration: InputDecoration(
                hintText: '输入密码',
                contentPadding: const EdgeInsets.symmetric(vertical: 10.0),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, .0),
            child: OutlinedButton(
              child: Text(
                "注册账号",
                style: TextStyle(fontSize: 20.0),
              ),
              onPressed: register,
            ),
          ),
        ],
      ),
    );
  }

  register() {
    if (_username.text.isEmpty) {
      showErrorToast("请输入用户名");
      return;
    }
    if (_password.text.isEmpty) {
      showErrorToast("请输入密码");
      return;
    }
    setState(() {
      loading = true;
    });
    postNoAuth("/staff/createdStaff",
        {"username": _username.text, "password": _password.text}).then((res) {
      print(res);
      if (res["success"]) {
        showSuccessAlert("注册成功,请退出登录!");
      }
    }).catchError((error) {
      showErrorAlert(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }
}
