import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:csc_exam_info/page/HomePage.dart' as info;
import 'package:csc_exam_grade/Login.dart' as grade;
import 'package:csc_exam_volume/page/LoginPage.dart' as volume;
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

import '../HomePage.dart';

class EntrancePage extends BaseApp {
  @override
  _EntrancePageState createState() => new _EntrancePageState();
}

class _EntrancePageState extends BaseAppPage<EntrancePage> {
  ConfigService configService = ConfigService();

  dynamic _hospital = {"name": "csyy", "id": "csyy"};

  String _username = "yk";

  String _password = "123456";

  _EntrancePageState() {
    title = '欢迎';
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return Center(
      child: Column(
        children: [
          Container(
            height: 300.0,
            child: Image.asset("assets/images/app.png"),
          ),
          Expanded(
            flex: 1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextButton(
                  child: Text(
                    "游客模式",
                    style: TextStyle(
                      fontSize: 30.0,
                    ),
                  ),
                  style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all(
                    Colors.blueAccent,
                  )),
                  onPressed: () {
                    loginCustom();
                  },
                ),
                SizedBox(height: 50.0),
                TextButton(
                  child: Text(
                    "注册/登录",
                    style: TextStyle(
                      fontSize: 25.0,
                    ),
                  ),
                  onPressed: () {
                    showLogin();
                  },
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(.0, 10.0, .0, 30.0),
            child: TextButton(
              child: Text(
                "考试设备",
                style: TextStyle(
                  fontSize: 25.0,
                ),
              ),
              onPressed: () {
                List<Widget> list = [
                  ListTile(
                    title: Text("信息机"),
                    onTap: () {
                      Navigator.of(context).pop();
                      Navigator.of(context).push(new MaterialPageRoute(
                        builder: (context) => info.HomePage(),
                      ));
                    },
                  ),
                  ListTile(
                    title: Text("考官评分"),
                    onTap: () {
                      Navigator.of(context).pop();
                      Navigator.of(context).push(new MaterialPageRoute(
                        builder: (context) => grade.Login(),
                      ));
                    },
                  ),
                  ListTile(
                    title: Text("理论试卷"),
                    onTap: () {
                      Navigator.of(context).pop();
                      Navigator.of(context).push(new MaterialPageRoute(
                        builder: (context) => volume.LoginPage(),
                      ));
                    },
                  ),
                ];
                showBarModalBottomSheet(
                  context: context,
                  builder: (context) => Material(
                    child: SafeArea(
                      top: false,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: list,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  loginCustom() {
    setState(() {
      loading = false;
    });
    postNoAuth(
      "/login",
      {
        "username": _username,
        "password": _password,
        "hospitalId": _hospital["id"]
      },
      options: Options(
        headers: {
          "hospitalId": _hospital["id"],
        },
        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
      ),
    ).then((value) {
      setAuth(value["token"]);
      configService
          .update(Config(
        "account",
        jsonEncode({
          "username": _username,
          "password": _password,
          "hospitalId": _hospital["id"],
          "hospitalName": _hospital["name"]
        }),
      ))
          .then((v) {
        configService.update(Config("auth", value["token"])).then((v) {
          configService.delete("userInfo").then((r) {
            refreshUserInfo().then((user) {
              configService
                  .update(Config("userInfo", jsonEncode(user.toMap())))
                  .then((value) {
                setState(() {
                  loading = false;
                });
                showHome();
              });
            });
          });
        });
      });
    });
  }

  showLogin() {
    Navigator.pushNamed(context, 'login').then((v) {
      // 登录成功
      if (v) {
        showHome();
      }
    });
  }

  showHome() {
    Navigator.of(context).pushAndRemoveUntil(
      new MaterialPageRoute(
        builder: (context) => Home(),
      ),
      (route) => route == null,
    );
  }
}
