import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class SelectHospital extends BaseApp {
  @override
  _SelectHospitalState createState() => _SelectHospitalState();
}

class _SelectHospitalState extends BaseAppPage<SelectHospital> {
  List<dynamic> items = [
    {
      "id": "c77e18b0-1ffa-11e7-b036-00163e0603fa",
      "name": "华西医院",
      "url": "http://simulationcenter.wchscu.cn/gl"
    },
    {
      "id": "c77e18b0-1ffa-11e7-b036-00163e0603fa",
      "name": "华西医院内网",
      "url": "http://192.168.221.217:8300/gl"
    },
    {
      "id": "c77e18b0-1ffa-11e7-b036-00163e0603fa",
      "name": "云服务器",
      "url": "http://116.63.181.221:8300"
    }
  ];

  _SelectHospitalState() {
    title = "选择医院";
    loading = true;
  }

  @override
  void initState() {
    super.initState();
    getDio().then((dio) {
      dio.get("http://gitlab.kbmrt.cn/root/config-data/raw/master/%E4%B8%B4%E5%BA%8A%E6%8A%80%E8%83%BD%E4%B8%AD%E5%BF%83%E9%85%8D%E7%BD%AE.json")
          .then((value) {
        setState(() {
          items = jsonDecode(value.toString());
          empty = false;
          loading = false;
        });
      }).catchError((err) {
        setState(() {
          empty = false;
          loading = false;
        });
        showErrorAlert("网络错误,重新选择医院");
        print(err.toString());
      });
    });
  }

  @override
  Widget getBody(BuildContext context) {
    return items.length > 0
        ? ListView.separated(
            itemBuilder: (BuildContext context, int i) {
              return ListTile(
                title: Text(items[i]["name"]),
                onTap: () {
                  Navigator.pop(context, items[i]);
                },
              );
            },
            separatorBuilder: (BuildContext context, int i) {
              return Divider();
            },
            itemCount: items.length,
          )
        : emptyWidget;
  }
}
