import 'dart:convert';

import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class ApprovePage extends BaseApp {
  final String data;
  final String prefix;
  final String todoId;

  ApprovePage(this.data, this.prefix, this.todoId);

  @override
  _ApprovePageState createState() =>
      new _ApprovePageState(this.data, this.prefix, this.todoId);
}

class _ApprovePageState extends BaseAppPage<ApprovePage> {
  TextEditingController _controller;
  dynamic data;
  String _status = "0";
  String prefix;
  String todoId;

  _ApprovePageState(String d, String e, String id) {
    data = jsonDecode(d);
    todoId = id;
    prefix = e;
    title = '审批';
    empty = false;
  }

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.check),
        tooltip: "不想看到这条数据",
        onPressed: () {
          print(data);
          showConfirmAlert("确认将这条待办数据完成吗?").then((v) {
            if (v) {
              setState(() {
                loading = true;
              });
              post("/todotask/completeTask", {"id": todoId})
                  .then((value) {
                if (value["success"]) {
                  setState(() {
                    loading = false;
                  });
                  Navigator.pop(context, true);
                }
              });
            }
          });
        },
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Card(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            margin: EdgeInsets.all(10.0),
            child: Row(
              children: [
                Text("是否同意"),
                Expanded(
                  flex: 1,
                  child: FormBuilderRadioGroup(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                    ),
                    options: [
                      {"name": "同意", "id": "0"},
                      {"name": "不同意", "id": "1"},
                    ].map((lang) {
                      return FormBuilderFieldOption(
                        value: lang["id"],
                        child: Text(lang["name"]),
                      );
                    }).toList(growable: false),
                    initialValue: _status,
                    name: 'status',
                    onChanged: (v) {
                      setState(() {
                        _status = v;
                      });
                    },
                  ),
                )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(10.0, .0, 10.0, 10.0),
            child: TextField(
              minLines: 10,
              maxLines: 30,
              controller: _controller,
              decoration: new InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ThemeColor.getColor("border")),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: ThemeColor.getColor("border")),
                ),
                hintText: '请输入审核意见,500字以内',
              ),
              inputFormatters: <TextInputFormatter>[
                LengthLimitingTextInputFormatter(500)
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
            width: MediaQuery.of(context).size.width,
            child: ElevatedButton.icon(
              label: Text("提交"),
              icon: Icon(MdiIcons.checkCircle),
              onPressed: () {
                data["processInstanceId"] = data["instanceId"];
                data["status"] = _status;
                data["opinion"] = _controller.text;
                showConfirmAlert("确认提交吗?").then((value) {
                  if (value) {
                    setState(() {
                      loading = true;
                    });
                    post("/$prefix/approveList", [data]).then((res) {
                      setState(() {
                        loading = false;
                      });
                      if (res['success']) {
                        showSuccessToast("审核成功!");
                        Navigator.pop(context, true);
                      }
                    }).catchError((err) {
                      setState(() {
                        loading = false;
                      });
                      showErrorAlert(err['msg']);
                    });
                  }
                });
              },
            ),
          ),
        ],
      ),
    );
  }
}
