import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class DevicesPage extends BaseApp {
  @override
  _DevicesPageState createState() => new _DevicesPageState();
}

class _DevicesPageState extends BaseAppPage<DevicesPage>
    with SingleTickerProviderStateMixin {
  RefreshController _controller1 = RefreshController(initialRefresh: true);
  RefreshController _controller2 = RefreshController(initialRefresh: true);
  TabController tabController;
  String deviceId;
  String staffId;

  _DevicesPageState() {
    title = '解绑设备';
  }

  @override
  initRouteSuccess() async {
    ConfigService configService = ConfigService();
    deviceId = await configService.getConfig("pushId");
    var a = await getCurrentAccount();
    staffId = a.staff["id"];
    empty = false;
    setState(() {});
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: [
        RefreshList(
          controller: _controller1,
          searchText: "请输入名称进行搜索",
          url: "/appdevice/listQueryByPage",
          queryParams: {"register": deviceId},
          buildItem: (dynamic row, int i) {
            return ListTile(
              title: Text("${row["name"]}"),
              trailing: Text("${row["staffName"]}"),
              subtitle: Text("${row["created"]}"),
              onTap: () {
                showConfirmAlert("解绑后不在获取推送消息,是否解绑当前设备?").then((value) {
                  if (value) {
                    setState(() {
                      loading = true;
                    });
                    post("/appdevice/delete", {"id": row["id"]}).then((res) {
                      setState(() {
                        loading = false;
                      });
                      if (res["success"]) {
                        showSuccessToast("解绑成功!");
                        _controller1.requestRefresh();
                      }
                    });
                  }
                });
              },
            );
          },
        ),
        RefreshList(
          controller: _controller2,
          searchText: "请输入名称进行搜索",
          queryParams: {"staffId": staffId},
          url: "/appdevice/listQueryByPage",
          buildItem: (dynamic row, int i) {
            return ListTile(
              title: Text("${row["name"]}"),
              trailing: Text("${row["staffName"]}"),
              subtitle: Text("${row["created"]}"),
              onTap: () {
                showConfirmAlert("解绑后不在获取推送消息,是否解绑当前设备?").then((value) {
                  if (value) {
                    setState(() {
                      loading = true;
                    });
                    post("/appdevice/delete", {"id": row["id"]}).then((res) {
                      setState(() {
                        loading = false;
                      });
                      if (res["success"]) {
                        showSuccessToast("解绑成功!");
                        _controller2.requestRefresh();
                      }
                    });
                  }
                });
              },
            );
          },
        ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    this.initTabController();
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
          controller: this.tabController,
          tabs: <Tab>[
            Tab(text: '当前设备'),
            Tab(text: '当前账号'),
          ],
        ),
      ),
      body: empty
          ? emptyWidget
          : getBody(context),
    );
  }

  initTabController() {
    tabController = TabController(
      vsync: this, // 动画效果的异步处理
      length: 2, // tab 个数
      initialIndex: 0, // 起始位置
    );
  }
}
