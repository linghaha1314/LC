import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../ThemeColor.dart';

class WebViewPage extends BaseApp {
  final String url;
  final String title;

  WebViewPage({@required this.url, this.title});

  @override
  _WebViewPageState createState() =>
      new _WebViewPageState(this.url, this.title);
}

class _WebViewPageState extends BaseAppPage<WebViewPage> {
  String url;
  var load = true;
  InAppWebViewController _webView;
  String _url;
  double _progress = 0.0;
  final CookieManager cookieManager = CookieManager.instance();

  _WebViewPageState(String url, String title) {
    if (title != null)
      this.title = title;
    else
      this.title = "加载中...";
    _url = url;
  }

  _changeUrlParams() async {
    var _path = await getHttpPath();
    if (_url.startsWith(_path)) {
      if (_url.indexOf("?") > -1) {
        _url = _url + "&theme=" + ThemeColor.getBaseTheme();
      } else {
        _url = _url + "?theme=" + ThemeColor.getBaseTheme();
      }
    }
    cookieManager.deleteAllCookies();
    cookieManager.setCookie(
        url: Uri.parse(_path), name: "jwt", value: getAuth());
    setState(() {
      empty = false;
      url = _url;
    });
  }

  @override
  void initState() {
    super.initState();
    if (kIsWeb == true) {
      setState(() {
        empty = false;
      });
      return;
    }
    _changeUrlParams();
  }

  @override
  Widget getAppBar(BuildContext context) {
    return AppBar(
      title: getTitle(context),
      actions: getActions(context),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (await _webView?.canGoBack()) {
          _webView?.goBack();
          return false;
        }
        return true;
      },
      child: super.build(context),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      PopupMenuButton(
        tooltip: "更多操作",
        // overflow menu
        itemBuilder: (BuildContext context) {
          return [
            new PopupMenuItem(
              value: "open_in_browser",
              child: ListTile(
                title: new Text("浏览器打开"),
                leading: Icon(Icons.open_in_browser),
              ),
            ),
            new PopupMenuItem(
              value: "close",
              child: ListTile(
                title: new Text("关闭网页"),
                leading: Icon(Icons.close),
              ),
            ),
          ];
        },
        onSelected: (String v) {
          if (v == "open_in_browser") {
            _launchUrl(Uri.parse(url));
          } else {
            Navigator.of(context).pop();
          }
        },
      ),
    ];
  }

  _launchUrl(Uri path) async {
    if (await canLaunchUrl(path)) {
      await launchUrl(path, mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not launch $path';
    }
  }

  @override
  Widget getBody(BuildContext context) {
    return Stack(
      children: [
        kIsWeb == true
            ? Center(
                child: TextButton(
                  child: Text("浏览器打开"),
                  onPressed: () {
                    _launchUrl(Uri.parse(url)).then((v) {});
                  },
                ),
              )
            : InAppWebView(
                initialUrlRequest: URLRequest(url: Uri.parse(url)),
                initialOptions: InAppWebViewGroupOptions(
                  crossPlatform: InAppWebViewOptions(supportZoom: false),
                ),
                onWebViewCreated: (InAppWebViewController controller) {
                  _webView = controller;
                },
                onLoadStart: (InAppWebViewController controller, Uri url) {
                  setState(() {
                    this.load = true;
                  });
                },
                onLoadStop: (InAppWebViewController controller, Uri u) async {
                  this.title = await controller.getTitle();
                  await Future.delayed(Duration(milliseconds: 200));
                  setState(() {
                    this.load = false;
                  });
                },
                onProgressChanged:
                    (InAppWebViewController controller, int progress) {
                  setState(() {
                    _progress = progress / 100;
                  });
                },
              ),
        Visibility(
          visible: load,
          child: Container(
            color: ThemeColor.getColor("color", opacity: false),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Column(
              children: [
                LinearProgressIndicator(value: _progress),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
