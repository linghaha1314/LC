import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefresherScroll.dart';
import 'package:csc_app/pojo/SendMessage.dart';
import 'package:csc_app/pojo/UserInfo.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';


class ChatDetailPage extends BaseApp {
  ChatDetailPage();

  @override
  ChatDetailPageState createState() => ChatDetailPageState();
}

class ChatDetailPageState extends BaseAppPage<ChatDetailPage> {
  RefreshController _refreshController = RefreshController();
  ScrollController _scrollController = ScrollController();
  var ctrl = new TextEditingController();
  String url;
  UserInfo _userInfo;

  ChatDetailPageState() {
    loading = true;
  }

  List leftSpots = [
    Coordinate(cx: 6, cy: 0),
    Coordinate(cx: 26, cy: 6),
    Coordinate(cx: 26, cy: -6),
  ];

  Map<String, NetworkImage> _netImage = {};
  NetworkImage _minImage;

  @override
  initRouteSuccess() {
    chatDetailPageState = this;
    this.title = routeData["name"];
    getHttpPath().then((path) {
      url = path;
      getCurrentAccount().then((value) {
        if (messageData[routeData["senderId"]] == null) {
          messageData[routeData["senderId"]] = [];
        }
        setState(() {
          _userInfo = value;
          if (_userInfo.staff["avator"] != null) {
            _minImage = NetworkImage(url + _userInfo.staff["avator"]);
          }
          _getMessageList();
        });
        setMessageRead();
      });
    });
  }

  _getMessageList() {
    var old = messageData[routeData["senderId"]];
    if (!_refreshController.isRefresh) {
      WidgetsBinding.instance.addPostFrameCallback((callback) {
        Future.delayed(Duration(milliseconds: 200), () {
          setState(() {
            loading = false;
            empty = false;
          });
          _scrollBottom();
        });
      });
    }
    if (old.length > 0 && old.first["id"] == null) {
      _refreshController.refreshCompleted();
      return;
    }
    post("/message/getMessageListByPage", {
      "sort": old.length > 0 ? old.first["sort"] as int : null,
      "senderId": routeData["senderId"],
      "receiverId": _userInfo.staff["id"],
    }).then((res) {
      var rows = res["data"] as List<dynamic>;
      if (rows.length > 0) {
        setState(() {
          messageData[routeData["senderId"]].insertAll(0, rows);
        });
      }
      _refreshController.refreshCompleted();
    }).catchError((err) {
      _refreshController.refreshFailed();
      showErrorToast(err["msg"]);
    });
  }

  @override
  void dispose() {
    super.dispose();
    if (chatDetailPageState.hashCode == this.hashCode) {
      chatDetailPageState = null;
    }
  }

  refreshMessage() {
    setMessageRead();
    _scrollBottom();
    setState(() {});
  }

  setMessageRead() {
    if (messageData[routeData["senderId"]] == null ||
        messageData[routeData["senderId"]].length == 0) {
      return;
    }
    List<dynamic> readData = [];
    dynamic _cache = {};
    messageData[routeData["senderId"]].forEach((msg) {
      if (msg["flag"] != null && msg["flag"] == true) {
        _cache[msg["id"]] = true;
        readData.add({"id": msg["id"], "receiverId": _userInfo.staff["id"]});
      }
    });
    if (readData.length > 0) {
      post("/message/readData", readData).then((value) {
        if (value["success"]) {
          messagePageState.updateUnread(
              -(value["data"] as int), routeData["senderId"]);
          messageData[routeData["senderId"]].forEach((msg) {
            if (msg["flag"] != null && msg["flag"] == true) {
              if (_cache[msg["id"]] == true) {
                msg["flag"] = null;
              }
            }
          });
        }
      });
    }
  }

  _scrollBottom() {
    WidgetsBinding.instance.addPostFrameCallback((callback) {
      _scrollStart();
      Future.delayed(Duration(milliseconds: 100), () {
        _scrollStart();
      });
      Future.delayed(Duration(milliseconds: 300), () {
        _scrollStart();
      });
      Future.delayed(Duration(milliseconds: 500), () {
        _scrollStart();
      });
    });
  }

  _scrollStart() {
    try {
      _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    } catch (e) {}
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: [
        Flexible(
          flex: 1,
          child: RefresherScroll(
            controller: _refreshController,
            enablePullUp: false,
            enablePullDown: true,
            header: CustomHeader(
                builder: (BuildContext context, RefreshStatus status) {
              Widget body;
              if (status == RefreshStatus.idle) {
                body = Text("下拉加载聊天记录");
              } else if (status == RefreshStatus.refreshing) {
                body = Container(
                  height: 35,
                  margin: EdgeInsets.all(0.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 35,
                        child: loadingWidget,
                      ),
                      Text("加载中...")
                    ],
                  ),
                );
              } else if (status == RefreshStatus.failed) {
                body = Text("加载失败,请重新尝试!");
              } else if (status == RefreshStatus.completed) {
                body = Text("加载完成!");
              } else if (status == RefreshStatus.canRefresh) {
                body = Text("松开加载!");
              } else {
                body = Text("记录加载完成");
              }
              return Container(
                height: 35.0,
                child: Center(child: body),
              );
            }),
            child: ListView.builder(
              padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
              controller: _scrollController,
              itemBuilder: (BuildContext context, int i) {
                var row = messageData[routeData["senderId"]][i];
                int prevSort;
                if (i > 0) {
                  prevSort =
                      messageData[routeData["senderId"]][i - 1]["sort"] as int;
                }
                return Column(
                  children: [
                    _buildTimeLine(row["sort"], prevSort),
                    row["senderId"] == _userInfo.staff["id"]
                        ? _buildRowRight(row)
                        : _buildRowLeft(row),
                  ],
                );
              },
              itemCount: messageData[routeData["senderId"]].length,
            ),
            onRefresh: _getMessageList,
          ),
        ),
        Divider(),
        Container(
          child: TextFormField(
            controller: ctrl,
            maxLines: 5,
            minLines: 1,
            decoration: InputDecoration(
              hintText: '输入消息',
              contentPadding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
              suffixIcon: IconButton(
                icon: Icon(Icons.send),
                onPressed: _sendMessage,
              ),
            ),
          ),
        )
      ],
    );
  }

  _sendMessage() async {
    var msg = ctrl.text;
    var d = SendMessage(
      "App单人聊天",
      msg,
      _userInfo.staff["id"],
      _userInfo.staff["name"],
      1,
      routeData["senderId"],
      "singleChat",
      null,
      _userInfo.staff["hospitalId"],
      DateTime.now().millisecondsSinceEpoch,
    );
    _scrollBottom();
    setState(() {
      var a = d.toMap();
      a["created"] = formatDate(
          DateTime.now(), [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
      messageData[routeData["senderId"]].add(a);
    });
    ctrl.clear();
    messagePageState.updateNowMsg(routeData["senderId"], "您:" + d.content);
    var socket = await getSocket();
    socket.sink.add(d.toJsonString());
  }

  Widget _buildRowLeft(dynamic row) {
    String t = (routeData['name']).toString().substring(0, 1);
    if (row["name"] != null) {
      t = (row['name']).toString().substring(0, 1);
    }
    if (_netImage[row["senderId"]] == null) {
      if (row["avator"] != null) {
        _netImage[row["senderId"]] = NetworkImage(url + row["avator"]);
      } else {
        if (routeData["avator"] != null) {
          _netImage[row["senderId"]] = NetworkImage(url + routeData["avator"]);
        }
      }
    }
    return Container(
      padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, .0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            child: CircularProfileAvatar(
              _netImage[row["senderId"]]?.url == null
                  ? ''
                  : _netImage[row["senderId"]]?.url,
              initialsText: Text(
                t,
                style: TextStyle(color: ThemeColor.getColor("fontColor")),
              ),
              borderColor: ThemeColor.getColor("content"),
              backgroundColor: ThemeColor.getColor("content"),
            ),
          ),
          Container(
            width: 12.0,
            padding: EdgeInsets.fromLTRB(.0, 20.0, .0, .0),
            child: CustomPaint(
              painter: new TriangleCustomPainter(
                context,
                leftSpots,
                color: ThemeColor.getColor("content"),
              ),
            ),
          ),
          ConstrainedBox(
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width - 150),
            child: InkWell(
              child: Card(
                margin: EdgeInsets.fromLTRB(14.0, .0, .0, .0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Container(
                  margin: EdgeInsets.all(10.0),
                  child: Text(
                    row["content"],
                    overflow: TextOverflow.ellipsis,
                    maxLines: 100,
                    softWrap: true,
                  ),
                ),
              ),
              onTap: () {
                showInfoToast("msg");
              },
              splashColor: Colors.transparent,
              highlightColor: Colors.transparent,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRowRight(dynamic row) {
    String t = (_userInfo.staff['name']).toString().substring(0, 1);
    return Container(
      padding: EdgeInsets.fromLTRB(10.0, 10.0, 10.0, .0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ConstrainedBox(
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width - 150),
            child: Card(
              margin: EdgeInsets.fromLTRB(.0, 5.0, 14.0, .0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: Container(
                margin: EdgeInsets.all(10.0),
                child: Text(
                  row["content"],
                  overflow: TextOverflow.ellipsis,
                  maxLines: 100,
                  softWrap: true,
                ),
              ),
            ),
          ),
          Container(
            width: 12.0,
            padding: EdgeInsets.fromLTRB(.0, 20.0, .0, .0),
            child: Transform.rotate(
              angle: 9.4,
              child: CustomPaint(
                painter: new TriangleCustomPainter(
                  context,
                  leftSpots,
                  color: ThemeColor.getColor("content"),
                ),
              ),
            ),
          ),
          CircleAvatar(
            child: CircularProfileAvatar(
              _minImage?.url == null ? '' : _minImage?.url,
              initialsText: Text(
                t,
                style: TextStyle(color: ThemeColor.getColor("fontColor")),
              ),
              borderColor: ThemeColor.getColor("content"),
              backgroundColor: ThemeColor.getColor("content"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimeLine(int time, int prev) {
    int space = 0;
    if (prev != null) {
      var d = DateTime.fromMillisecondsSinceEpoch(time)
          .difference(DateTime.fromMillisecondsSinceEpoch(prev));
      space = d.inMinutes;
    }
    return space >= 10
        ? Container(
            margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(buildMessageTime(time)),
              ],
            ),
          )
        : Container();
  }
}

class TriangleCustomPainter extends CustomPainter {
  Paint _paint = new Paint(); //画笔富含各种属性方法。仔细查看源码
  final BuildContext context;
  final List spots;
  final Color color;

  TriangleCustomPainter(this.context, this.spots, {this.color});

  @override
  void paint(Canvas canvas, Size size) {
    Path path = new Path();
    path.moveTo(spots[0].cx, spots[0].cy);
    path.lineTo(spots[1].cx, spots[1].cy);
    path.lineTo(spots[2].cx, spots[2].cy);
    _paint.color = color;
    canvas.drawPath(path, _paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

class Coordinate {
  final double cx;
  final double cy;

  Coordinate({this.cx, this.cy});
}
