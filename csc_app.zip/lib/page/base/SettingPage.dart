import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../ThemeColor.dart';

class Setting extends BaseApp {
  @override
  SettingPage createState() => new SettingPage();
}

class SettingPage extends BaseAppPage<Setting> {
  ConfigService configService = ConfigService();

  String _color = ThemeColor.colors[ThemeColor.themeIndex]["title"];
  var progressValue = ThemeColor.opacity;

  SettingPage() {
    empty = false;
    title = '设置';
  }

  @override
  Widget getBody(BuildContext context) {
    return Container(
      child: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.color_lens),
            trailing: DropdownButton(
              value: _color,
              isDense: true,
              underline: Container(height: 0),
              icon: Icon(Icons.arrow_forward),
              onChanged: (String newValue) {
                _color = newValue;
                var m = ThemeColor.getTheme(newValue);
                ThemeColor.themeIndex = m["index"];
                configService
                    .update(Config("theme", m["index"].toString()));
                initWatermark();
                ThemeColor.changeTheme(context);
              },
              items: ThemeColor.colors.map((Map value) {
                return new DropdownMenuItem(
                  value: value["title"].toString(),
                  child: new Text('${value["title"]}(${value["theme"]})'),
                );
              }).toList(),
            ),
            title: Text('颜色主题'),
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.opacity),
            trailing: Icon(Icons.arrow_forward),
            title: Text('背景透明度'),
            onTap: () {
              showDialog(
                context: context,
                barrierDismissible: false,
                builder: (BuildContext context) {
                  return new AlertDialog(
                    title: new Text('透明度'),
                    content: new SingleChildScrollView(
                      child: new ListBody(
                        children: <Widget>[
                          Slider(
                            value: progressValue,
                            //实际进度的位置
                            label: '透明度:$progressValue',
                            min: 10.0,
                            max: 100.0,
                            divisions: 16,
                            activeColor: ThemeColor.getColor("progress"),
                            //进度中活动部分的颜色
                            onChanged: (double) {
                              progressValue = double.roundToDouble();
                              ThemeColor.opacity = progressValue;
                              ThemeColor.changeTheme(context);
                              configService.update(Config("opacity", progressValue.toString()));
                            },
                          ),
                        ],
                      ),
                    ),
                    actions: <Widget>[
                      new MaterialButton(
                        child: new Text('确定'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  );
                },
              ).then((val) {
                print(val);
              });
            },
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.image),
            trailing: Icon(Icons.arrow_forward),
            title: Text('背景图片'),
            onTap: () async{
              FilePickerResult result = await FilePicker.platform.pickFiles(type: FileType.image);
              if (result != null) {
                configService.update(Config("background", result.files.single.path));
                setState(() {
                  ThemeColor.background = result.files.single.path;
                });
              }
            },
          ),
          Divider(),
        ],
      ),
    );
  }
}
