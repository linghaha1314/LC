import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'ApprovePage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

import 'WebViewPage.dart';

class TodoTaskPage extends BaseApp {
  @override
  _TodoTaskPageState createState() => new _TodoTaskPageState();
}

class _TodoTaskPageState extends BaseAppPage<TodoTaskPage> {
  List<Map<String, dynamic>> data = [];
  Map<String, dynamic> params = {};
  String senderId = "";
  String url = "";
  RefreshController _refreshController;

  @override
  initRouteSuccess() {
    title = routeData["title"];
    senderId = routeData["senderId"];
    _refreshController = RefreshController(initialRefresh: false);
    getCurrentAccount().then((account) {
      params["staffId"] = account.staff["id"];
      params["labelCode"] = senderId;
      params["typeCode"] = "TypePending";
      getHttpPath().then((v) {
        url = v;
        empty = false;
        setState(() {});
        _refreshController?.requestRefresh();
      });
    });
  }

  final _buttonStyle = TextStyle(fontSize: 14.0);

  @override
  List<Widget> getActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(MdiIcons.notificationClearAll),
        tooltip: "清除所有待办数据",
        onPressed: () {
          showPromptAlert("选择要完成的待办截至日期", isDate: true).then((value) {
            if (value != false) {
              setState(() {
                loading = true;
              });
              post('/todotask/completeMineByDate', {"date": value, "labelCode": params["labelCode"]}).then((res) {
                setState(() {
                  loading = false;
                });
                if (res["success"]) {
                  _refreshController.requestRefresh();
                }
              });
            }
          });
        },
      ),
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      url: "/todotask/listQueryByPage",
      queryParams: params,
      controller: _refreshController,
      buildItem: (dynamic r, int i) {
        String router = r["router"];
        bool auditFlat = false;
        if (router.split("/").last == "audit") {
          auditFlat = true;
        }
        return Card(
          margin: EdgeInsets.all(10.0),
          child: Container(
            padding: EdgeInsets.all(10.0),
            width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        flex: 1,
                        child: Text(
                          r["name"],
                          overflow: TextOverflow.ellipsis,
                          maxLines: 100,
                          softWrap: true,
                        ),
                      ),
                      Text(
                        buildMessageTime(r["sort"] as int),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 100,
                        softWrap: true,
                      ),
                    ],
                  ),
                ),
                Divider(),
                Container(
                  margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                  child: Text(
                    "${r["content"] == null ? "无内容" : r["content"]}",
                    overflow: TextOverflow.ellipsis,
                    maxLines: 100,
                    softWrap: true,
                  ),
                ),
                SizedBox(height: 10),
                Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    TextButton.icon(
                      icon: Icon(
                        MdiIcons.checkOutline,
                        size: 15.0,
                      ),
                      label: Text(
                        auditFlat ? "审批或处理" : "已处理",
                        style: _buttonStyle,
                      ),
                      onPressed: () {
                        if (r['status'] == 1) {
                          showConfirmAlert("确认将这条待办数据完成吗?").then((v) {
                            if (v) {
                              setState(() {
                                loading = true;
                              });
                              post("/todotask/completeTask", {"id": r["id"]})
                                  .then((value) {
                                if (value["success"]) {
                                  setState(() {
                                    loading = false;
                                  });
                                  Navigator.pop(context, true);
                                }
                              });
                            }
                          });
                          return;
                        }
                        if (auditFlat) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ApprovePage(
                                  r["params"], router.split("/")[1], r["id"]),
                            ),
                          ).then((v) {
                            if (v) {
                              setState(() {
                                r['status'] = 1;
                              });
                              _refreshController.requestRefresh();
                              messagePageState?.refresh();
                            }
                          });
                        } else {
                          completeTodo(r);
                        }
                      },
                    ),
                    TextButton.icon(
                      icon: Icon(
                        MdiIcons.eyeCircle,
                        size: 15.0,
                      ),
                      label: Text(
                        "查看详情",
                        style: _buttonStyle,
                      ),
                      onPressed: () {
                        if (auditFlat) {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => WebViewPage(
                                  url: url +
                                      "/${router.split("/")[1]}/view/${jsonDecode(r["params"])["id"]}?type=0"),
                            ),
                          );
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  WebViewPage(url: url + router + "?type=0"),
                            ),
                          );
                        }
                      },
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }

  readMsg(dynamic r) {
    messagePageState.updateUnread(-1, senderId);
  }

  completeTodo(dynamic row) {
    setState(() {
      loading = true;
    });
    post("/todotask/completeTask", {"businessKey": row["data"]}).then((value) {
      if (value["success"]) {
        setState(() {
          loading = false;
          row['status'] = 1;
        });
        messagePageState?.refresh();
      }
    });
  }
}
