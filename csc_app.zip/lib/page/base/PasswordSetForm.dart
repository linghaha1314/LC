import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class PasswordSet extends BaseApp {
  @override
  PasswordSetForm createState() => new PasswordSetForm();
}

class PasswordSetForm extends BaseAppPage<PasswordSet> {
  ConfigService configService = ConfigService();
  final _formKey = GlobalKey<FormState>();
  dynamic data = {};

  PasswordSetForm() {
    empty = false;
    title = '修改密码';
  }

  @override
  Widget getBody(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            TextFormField(
              keyboardType: TextInputType.text,
              obscureText: true,
              decoration:
                  const InputDecoration(hintText: '请输入原密码！', labelText: '原密码'),
              onChanged: (value) {
                data["oldPassword"] = value;
              },
              validator: (value) {
                if (value == null || value == '') {
                  return '请输入原密码';
                }
                return null;
              },
            ),
            TextFormField(
              keyboardType: TextInputType.text,
              obscureText: true,
              decoration:
                  const InputDecoration(hintText: '请输入新密码！', labelText: '新密码'),
              onChanged: (value) {
                data["newPassword"] = value;
              },
              validator: (value) {
                if (value == null || value == '') {
                  return '请输入新密码';
                }
                return null;
              },
            ),
            TextFormField(
              keyboardType: TextInputType.text,
              obscureText: true,
              decoration:
                  const InputDecoration(hintText: '请输入！', labelText: '确认密码'),
              onChanged: (value) {
                data["confirmPassword"] = value;
              },
              validator: (value) {
                if (value == null || value != data["newPassword"]) {
                  return '两次密码不一致';
                }
                return null;
              },
            ),
          ],
        ),
      ),
    );
  }

  updatePassword() {
    post("/accounts/updatePassword", data).then((value) {
      if (value["success"]) {
        Navigator.of(context).pop();
        Navigator.of(context).pushNamed("login");
      }
    }).catchError((onError) {
      showErrorAlert(onError["msg"]);
    });
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        onPressed: () {
          if (_formKey.currentState.validate()) {
            updatePassword();
          }
        },
        tooltip: "保存",
        icon: Icon(Icons.check),
      )
    ];
  }
}
