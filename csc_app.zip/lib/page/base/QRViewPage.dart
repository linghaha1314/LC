import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vibrate/flutter_vibrate.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

class QRViewPage extends BaseApp {
  @override
  _QRViewPageState createState() => new _QRViewPageState();
}

class _QRViewPageState extends BaseAppPage<QRViewPage> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController controller;
  var flag = false;

  _QRViewPageState() {
    title = '扫描二维码';
    empty = false;
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      appBar: barFlag ? getAppBar(context) : null,
      body: empty ? emptyWidget : getBody(context),
      drawer: empty ? null : getDraw(context),
      bottomNavigationBar: empty ? null : getBottom(context),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: <Widget>[
        Expanded(
          flex: 1,
          child: kIsWeb == true
              ? Center(
                  child: Text("浏览器不支持扫码"),
                )
              : QRView(
                  key: qrKey,
                  onQRViewCreated: _onQRViewCreated,
                  overlay: QrScannerOverlayShape(
                    borderColor: ThemeColor.getColor("border"),
                    borderRadius: 10,
                    borderLength: 30,
                    borderWidth: 10,
                    cutOutSize: 300,
                  ),
                ),
        ),
      ],
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.resumeCamera();
    controller.scannedDataStream.listen((scanData) {
      if (!flag) {
        flag = true;
        Vibrate.feedback(FeedbackType.success);
        Navigator.pop(context, scanData.code);
      }
    });
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }
}
