import 'dart:convert';

import 'package:badges/badges.dart' as badges;
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

import 'WebViewPage.dart';

class MessageCardPage extends BaseApp {
  final String title;

  MessageCardPage(this.title);

  @override
  _MessageCardPageState createState() => new _MessageCardPageState(this.title);
}

class _MessageCardPageState extends BaseAppPage<MessageCardPage> {
  List<Map<String, dynamic>> data = [];
  Map<String, dynamic> params = {};
  String url = "";
  String viewUrl;
  String clientUrl;
  final _buttonStyle = TextStyle(fontSize: 14.0);

  _MessageCardPageState(String head) {
    title = head;
  }

  @override
  void initState() {
    super.initState();
    getCurrentAccount().then((account) {
      params["staffId"] = account.staff["id"];
      getHttpPath().then((v) {
        url = v;
        setState(() {
          empty = false;
        });
      });
    });
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      url: "/message/getAccountMessageList",
      queryParams: params,
      buildItem: (dynamic r, int i) {
        if ("${r["status"]}" == "0") {
          readMsg({"id": r["id"], "receiverId": params["staffId"]});
        }
        return badges.Badge(
          position: badges.BadgePosition.topEnd(top: 5.0, end: 5.0),
          showBadge: "${r["status"]}" == "0",
          child: Card(
            margin: EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10.0),
              width: MediaQuery.of(context).size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(r["title"]),
                        Text(buildMessageTime(r["sort"] as int)),
                      ],
                    ),
                  ),
                  Divider(),
                  Container(
                    margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                    child: HtmlWidget(
                      replaceHtml(r["content"], url),
                      onTapUrl: (uri) {
                        if(uri.startsWith(url) && uri.contains("questionnaire")) {
                          var u = Uri.parse(uri);
                          Navigator.pushNamed(context, "surveyVolume",
                              arguments: u.queryParameters);
                          return true;
                        }
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => WebViewPage(url: uri),
                          ),
                        );
                        return true;
                      },
                    ),
                  ),
                  if (r["attachs"] != null) SizedBox(height: 10.0),
                  if (r["attachs"] != null) Divider(),
                  if (r["attachs"] != null)
                    Container(
                      margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                      child: Column(
                        children: (r["attachs"] as String).split(",").map((e) {
                          var fileName = getFileName(e);
                          return ListTile(
                            title: Text(
                              "$fileName",
                              style: _buttonStyle,
                            ),
                            trailing: TextButton.icon(
                              icon: Icon(
                                MdiIcons.download,
                                size: 18.0,
                              ),
                              label: Text(
                                "下载",
                                style: _buttonStyle,
                              ),
                              onPressed: () {
                                downloadFile(e, fileName);
                              },
                            ),
                            onTap: () {
                              viewFile(e);
                            },
                          );
                        }).toList(),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  getFileName(String path) {
    var source = path.split('/');
    return source[source.length - 1];
  }

  viewFile(String path) async {
    if (viewUrl == null) {
      var config = await get("/config/getFileViewer");
      viewUrl = "${config["fileServer"]}/onlinePreview?url=";
      clientUrl = config["fileClient"];
    }
    String u =  path;
    if (!path.startsWith("http")) {
      u = viewUrl + Uri.encodeComponent(base64Encode(utf8.encode("$clientUrl$path")));
    } else {
      u = viewUrl + Uri.encodeComponent(base64Encode(utf8.encode(Uri.decodeFull(path))));
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WebViewPage(url:u),
      ),
    );
  }

  readMsg(dynamic r) {
    post("/message/readData", [r]).then((value) {
      if (value["success"]) {
        messagePageState.updateUnread(-(value["data"] as int), "otherMsg");
      }
    });
  }
}
