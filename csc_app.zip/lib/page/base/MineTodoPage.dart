import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/page/base/TodoAddPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:badges/badges.dart' as badges;

class MineTodoPage extends BaseApp {
  @override
  _MineTodoPageState createState() => new _MineTodoPageState();
}

class _MineTodoPageState extends BaseAppPage<MineTodoPage>
    with TickerProviderStateMixin {
  RefreshController _controller;
  Map<String, List> data = {};
  DateFormat dateFormat = DateFormat("yyyy-MM-dd");
  Map<String, dynamic> params = {};
  AnimationController _animationController;
  String _oldMonth;
  int nowYear = DateTime.now().year;

  _MineTodoPageState() {
    empty = false;
    title = "我的待办";
    params["todoDay"] = dateFormat.format(DateTime.now());
    _controller = RefreshController(initialRefresh: false);
  }

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _animationController.forward();
    _getCountData(dateFormat.format(DateTime.now()).substring(0, 7));
  }

  _getCountData(String month) {
    if (month == null) {
      month = _oldMonth;
    } else {
      _oldMonth = month;
    }
    post("/todotask/getMineByDay", {"month": month}).then((res) {
      data = {};
      if (res['success']) {
        var list = res['data'] as List<dynamic>;
        list.forEach((e) {
          data[e["date"].toString()] = [e["total"]];
        });
        setState(() {});
      }
    });
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: [
        Container(
          child: TableCalendar(
            firstDay: DateTime.utc(nowYear - 5, 1, 1),
            lastDay: DateTime.utc(nowYear + 5, 12, 28),
            focusedDay: dateFormat.parse(params["todoDay"]),
            currentDay: dateFormat.parse(params["todoDay"]),
            headerVisible: true,
            availableCalendarFormats: {
              CalendarFormat.month: 'Month',
            },
            onDaySelected: (DateTime selectedDay, DateTime focusedDay) {
              setState(() {
                params["todoDay"] = dateFormat.format(selectedDay);
              });
              _controller.requestRefresh(needMove: false);
            },
            locale: 'zh_CH',
            rowHeight: 50.0,
            eventLoader: (DateTime day) {
              return data[dateFormat.format(day)] ?? [];
            },
            calendarBuilders: CalendarBuilders(
              selectedBuilder: (context, date, _) {
                return FadeTransition(
                  opacity:
                      Tween(begin: 0.0, end: 1.0).animate(_animationController),
                  child: Container(
                    margin: const EdgeInsets.all(4.0),
                    padding: const EdgeInsets.only(top: 5.0, left: 6.0),
                    color: ThemeColor.getColor("focus"),
                    width: 100,
                    height: 100,
                    child: Text(
                      '${date.day}',
                      style: TextStyle(color: ThemeColor.getColor("active"))
                          .copyWith(fontSize: 16.0),
                    ),
                  ),
                );
              },
              holidayBuilder: (context, date, _) {
                return Container(
                  margin: const EdgeInsets.all(4.0),
                  padding: const EdgeInsets.only(top: 5.0, left: 6.0),
                  color: ThemeColor.getColor("active"),
                  width: 100,
                  height: 100,
                  child: Text(
                    '${date.day}',
                    style: TextStyle().copyWith(fontSize: 16.0),
                  ),
                );
              },
              markerBuilder: (context, date, events) {
                final children = <Widget>[];
                if (events.isNotEmpty) {
                  children.add(
                    badges.Badge(
                      position: badges.BadgePosition.topEnd(top: 0, end: 0),
                      badgeStyle: badges.BadgeStyle(
                        shape: badges.BadgeShape.circle,
                        badgeColor: ThemeColor.getColor("info"),
                      ),
                      badgeContent: Text(
                        '${events[0]}',
                        style: TextStyle(fontSize: 10.0),
                      ),
                    ),
                  );
                }
                return Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  children: children,
                );
              },
              todayBuilder: (context, date, _) {
                return Container(
                  margin: const EdgeInsets.all(4.0),
                  padding: const EdgeInsets.only(top: 5.0, left: 6.0),
                  color: ThemeColor.getColor("active"),
                  width: 100,
                  height: 100,
                  child: Text(
                    '${date.day}',
                    style: TextStyle().copyWith(fontSize: 16.0),
                  ),
                );
              },
            ),
          ),
        ),
        Divider(),
        Expanded(
          flex: 1,
          child: RefreshList(
            controller: _controller,
            url: '/todotask/getMineTodo',
            queryParams: params,
            buildItem: (row, i) {
              return Slidable(
                child: Container(
                  child: ListTile(
                    title: Text(row["name"]),
                    trailing: Text(buildMessageTime(
                        (DateTime.parse(row['todoDate'])
                            .millisecondsSinceEpoch))),
                    subtitle: Text(row["content"]),
                  ),
                ),
                endActionPane: ActionPane(
                  motion: ScrollMotion(),
                  children: [
                    SlidableAction(
                      label: '完成',
                      backgroundColor: ThemeColor.getColor("success"),
                      foregroundColor: ThemeColor.getColor("fontColor"),
                      icon: Icons.edit,
                      onPressed: (BuildContext context) {
                        showConfirmAlert("确认该待办已经处理吗?").then((value) {
                          if (value) {
                            setState(() {
                              loading = true;
                            });
                            post("/todotask/completeTask", {"id": row["id"]})
                                .then((res) {
                              if (res['success']) {
                                showSuccessToast("完成成功");
                              }
                              setState(() {
                                loading = false;
                              });
                              _controller.requestRefresh(needMove: false);
                              _getCountData((params["todoDay"] as String)
                                  .substring(0, 7));
                            });
                          }
                        });
                      },
                    ),
                    SlidableAction(
                      label: '删除',
                      backgroundColor: ThemeColor.getColor("danger"),
                      foregroundColor: ThemeColor.getColor("fontColor"),
                      icon: Icons.delete,
                      onPressed: (BuildContext context) {
                        showConfirmAlert("确认删除吗?").then((value) {
                          if (value) {
                            setState(() {
                              loading = true;
                            });
                            post("/todotask/delete", {"id": row["id"]})
                                .then((res) {
                              if (res['success']) {
                                showSuccessToast("删除成功");
                              }
                              setState(() {
                                loading = false;
                              });
                              _controller.requestRefresh(needMove: false);
                              _getCountData((params["todoDay"] as String)
                                  .substring(0, 7));
                            });
                          }
                        });
                      },
                    ),
                  ],
                ),
              );
            },
          ),
        )
      ],
    );
  }

  Widget _buildEventsMarker(DateTime date, List events) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      decoration: BoxDecoration(
        shape: BoxShape.rectangle,
      ),
      width: 16.0,
      height: 16.0,
      child: Center(
        child: Text(
          '${events[0]}',
          style: TextStyle().copyWith(
            color: ThemeColor.getColor("danger"),
            fontSize: 12.0,
          ),
        ),
      ),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        tooltip: "添加待办",
        icon: Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TodoAddPage(),
            ),
          ).then((value) {
            if (value != null) {
              _controller.requestRefresh(needMove: false);
              _getCountData(null);
            }
          });
        },
      )
    ];
  }
}
