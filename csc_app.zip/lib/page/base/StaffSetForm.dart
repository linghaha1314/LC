import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';

class StaffSet extends BaseApp {
  @override
  StaffSetForm createState() => new StaffSetForm();
}

class StaffSetForm extends BaseAppPage<StaffSet> {
  dynamic data;

  StaffSetForm() {
    empty = false;
    title = "修改人员信息";
  }

  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  final d = r"^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$";

  @override
  Widget getBody(BuildContext context) {
    return Visibility(
      visible: data != null,
      child: FormBuilder(
        key: _fbKey,
        autovalidateMode: AutovalidateMode.always,
        initialValue: {
          "mobile": data["mobile"],
          "qq": data["qq"],
          "wechat": data["wechat"],
          "birthdayTime": data["birthdayTime"],
          "email": data["email"]
        },
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              FormBuilderTextField(
                name: "mobile",
                decoration: InputDecoration(labelText: "手机号"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(errorText: "请填写手机号"),
                  FormBuilderValidators.maxLength(11, errorText: "手机号格式错误"),
                  (val) {
                    if (!RegExp(
                            r"^1([38][0-9]|4[579]|5[0-3,5-9]|6[6]|7[0135678]|9[89])\d{8}$")
                        .hasMatch(val)) {
                      FormBuilderValidators.maxLength(11, errorText: "手机号格式错误");
                    }
                    return null;
                  }
                ]),
              ),
              FormBuilderTextField(
                name: "qq",
                decoration: InputDecoration(labelText: "qq"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.maxLength(
                    12,
                    errorText: "输入长度不得大于12位!",
                  ),
                ]),
              ),
              FormBuilderTextField(
                name: "wechat",
                decoration: InputDecoration(labelText: "微信"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.maxLength(
                    20,
                    errorText: "输入长度不得大于20位!",
                  ),
                ]),
              ),
              FormBuilderDateTimePicker(
                name: "birthdayTime",
                inputType: InputType.date,
                format: DateFormat("yyyy-MM-dd"),
                decoration: InputDecoration(labelText: "生日"),
              ),
              FormBuilderTextField(
                name: "email",
                decoration: InputDecoration(labelText: "邮箱"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.maxLength(
                    50,
                    errorText: "输入长度不得大于50位!",
                  ),
                  FormBuilderValidators.email(
                    errorText: "请输入正确的邮箱格式!",
                  ),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        onPressed: () {
          if (_fbKey.currentState.saveAndValidate()) {
            _updateStaff(_fbKey.currentState.value);
          }
        },
        tooltip: "保存",
        icon: Icon(Icons.check),
      )
    ];
  }

  @override
  void initState() {
    _initStaff();
    super.initState();
  }

  _initStaff() {
    getCurrentAccount().then((value) {
      if (value == null) return;
      setState(() {
        data = value.staff;
        data["birthdayTime"] = DateTime.parse(data["birthday"]);
      });
    });
  }

  _updateStaff(d) {
    dynamic data = Map.of(d);
    data["id"] = this.data["id"];
    data["birthday"] = formatDate(data["birthdayTime"],
        [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    data["birthdayTime"] = null;
    loading = true;
    post("/accounts/saveCurrentAccount", data).then((value) {
      if (value["success"]) {
        loading = false;
        showSuccessAlert("修改成功,请返回下拉刷新!");
        refreshUserInfo().then((value) {});
      }
    }).catchError((error) {
      loading = false;
      showErrorAlert(error["msg"]);
    });
  }
}
