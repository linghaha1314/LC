import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class TodoAddPage extends BaseApp {
  @override
  _TodoAddPageState createState() => new _TodoAddPageState();
}

class _TodoAddPageState extends BaseAppPage<TodoAddPage> {
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  _TodoAddPageState() {
    empty = false;
    title = "添加待办";
  }

  @override
  Widget getBody(BuildContext context) {
    return Card(
      child: FormBuilder(
        key: _fbKey,
        initialValue: {"urgentStatus": "0"},
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              margin: EdgeInsets.fromLTRB(10.0, .0, 10.0, 10.0),
              child: FormBuilderTextField(
                name: "name",
                decoration: new InputDecoration(
                  labelText: '标题',
                ),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(errorText: "请输入标题!"),
                ]),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10.0, .0, 10.0, 0.0),
              child: FormBuilderDateTimePicker(
                name: "todoDate",
                decoration: new InputDecoration(
                  labelText: '待办时间',
                ),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                      errorText: "请选择待办时间!"),
                ]),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10.0, .0, 10.0, 0.0),
              child: Row(
                children: [
                  Text("状态"),
                  Expanded(
                    flex: 1,
                    child: FormBuilderRadioGroup(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                      ),
                      options: [
                        {"name": "默认", "id": "0"},
                        {"name": "重要(短信提醒)", "id": "1"},
                      ].map((lang) {
                        return FormBuilderFieldOption(
                          value: lang["id"],
                          child: Text(lang["name"]),
                        );
                      }).toList(growable: false),
                      name: 'urgentStatus',
                    ),
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(10.0, .0, 10.0, 0.0),
              child: FormBuilderTextField(
                minLines: 3,
                maxLines: 30,
                name: "content",
                decoration: new InputDecoration(
                  labelText: '内容',
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
              width: MediaQuery.of(context).size.width,
              child: ElevatedButton.icon(
                label: Text("提交"),
                icon: Icon(MdiIcons.checkCircle),
                onPressed: () {
                  if (_fbKey.currentState.saveAndValidate()) {
                    dynamic d = Map.of(_fbKey.currentState.value);
                    setState(() {
                      loading = true;
                    });
                    DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm:ss");
                    d["todoDate"] = dateFormat.format(d["todoDate"]);
                    post("/todotask/saveMineTodo", d).then((res) {
                      setState(() {
                        loading = false;
                      });
                      if (res['success']) {
                        Navigator.pop(context, true);
                        showSuccessToast("保存成功");
                      }
                    });
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
