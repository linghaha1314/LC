import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/component/SignatureComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class TemporaryCourseSignaturePage extends BaseApp {
  @override
  _TemporaryCourseSignaturePageState createState() =>
      new _TemporaryCourseSignaturePageState();
}

class _TemporaryCourseSignaturePageState
    extends BaseAppPage<TemporaryCourseSignaturePage> {
  RefreshController _controller = RefreshController(initialRefresh: false);

  _TemporaryCourseSignaturePageState() {
    title = '临时培训申请列表';
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      controller: _controller,
      searchText: "请输入申请名称进行搜索",
      url: "/curriculum/listQueryGraduationByPage",
      queryParams: {"categoryCode": "temporary_curriculum", "status": 1},
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  _bodyContentOne(data) {
    return ListTile(
      title: Text(data['couresGraduationName']),
      subtitle: Text("创建日期：${data['created']}"),
      trailing: data['attachs'] != null
          ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Chip(
                  backgroundColor: ThemeColor.getColor('success'),
                  label: Row(
                    children: [
                      Text(
                        '已上传',
                        style: TextStyle(
                          color: ThemeColor.getColor("fontColor"),
                        ),
                      ),
                      Icon(
                        Icons.arrow_upward,
                        color: ThemeColor.getColor("fontColor"),
                      ),
                    ],
                  ),
                ),
              ],
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Chip(
                  backgroundColor: ThemeColor.getColor('warning'),
                  label: Row(
                    children: [
                      Text(
                        '未上传',
                        style: TextStyle(
                          color: ThemeColor.getColor("fontColor"),
                        ),
                      ),
                      Icon(
                        Icons.arrow_upward,
                        color: ThemeColor.getColor("fontColor"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
      onTap: () {
        //跳转到附件列表页面
        Navigator.push(
          context,
          new MaterialPageRoute(builder: (context) => new SignatureComponent()),
        ).then((value) {
          if (value != null) {
            uploadFile(file: value).then((value) {
              loading = true;
              var params = {
                "id": data["couresGraduationId"],
                "attachs": value,
              };
              post("/couresgraduation/updateField", params).then((value) {
                if (value['success']) {
                  loading = false;
                  showSuccessToast("签名上传成功！");
                  //修改课表数据为已提交
                  var params = {
                    "id": data["id"],
                    "status": 2,
                  };
                  post("/curriculum/updateField", params).then((value) {
                    if(value["success"]){
                      showSuccessToast("课表状态已修改！");
                      //刷新页面
                      _controller.requestRefresh();
                    }
                  });
                }
              });
            });
          }
        });
      },
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }
}
