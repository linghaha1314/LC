import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/ApprovalStatus.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/component/SignatureComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CourseSignaturePage extends BaseApp {
  @override
  _CourseSignaturePageState createState() => new _CourseSignaturePageState();
}

class _CourseSignaturePageState extends BaseAppPage<CourseSignaturePage> {
  _CourseSignaturePageState() {
    title = '培训课程申请列表';
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      searchText: "请输入申请名称进行搜索",
      url: "/teachingplatform/listQueryByPage",
      queryParams: {"type": "apply"},
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  _bodyContentOne(data) {
    return ListTile(
      title: Text(data['name']),
      subtitle: Text("申请日期：${data['date']}"),
      trailing: data['status'] != null
          ? ApprovalStatus(
              status: data['status'],
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Chip(
                  backgroundColor: ThemeColor.getColor('warning'),
                  label: Row(
                    children: [
                      Text(
                        '待提交',
                        style: TextStyle(
                          color: ThemeColor.getColor("fontColor"),
                        ),
                      ),
                      Icon(
                        Icons.arrow_upward,
                        color: ThemeColor.getColor("fontColor"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
      onTap: () {
        if (data['status'] != null && data["status"] != 1) {
          showErrorToast("只有待提交和已驳回的申请可以签名！");
        } else {
          //跳转到附件列表页面
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new SignatureComponent()),
          ).then((value) {
            if (value != null) {
              uploadFile(file: value).then((value) {
                loading = true;
                var params = {
                  "path": value,
                  "attachType": 3,
                  "applyId": data['id'],
                  "uploadDate": formatDate(
                      DateTime.now(), [yyyy, "-", mm, "-", dd, " ", HH, ":", nn,":", ss])
                };
                post("/teachingplatformattach/save", params).then((value) {
                  if (value['success']) {
                    loading = false;
                    showSuccessToast("签名上传成功！");
                  }
                });
              });
            }
          });
        }
      },
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }
}
