import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import 'ScoreRecordForm.dart';
import 'ScoreRecordView.dart';

class ScoreRecordPage extends BaseApp {
  @override
  _ScoreRecordPageState createState() => new _ScoreRecordPageState();
}

class _ScoreRecordPageState extends BaseAppPage<ScoreRecordPage> {
  final GlobalKey<FormBuilderState> _diaLogKey = GlobalKey<FormBuilderState>();
  RefreshController recordController = RefreshController(initialRefresh: true);
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();

  _ScoreRecordPageState() {
    title = "评分记录";
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.add),
        tooltip: "添加评分记录",
        onPressed: () {
          _showAddDialog();
        },
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      controller: recordController,
      searchText: "请输入人员名称进行搜索",
      url: "/scorerecord/listQueryByPage",
      queryKey: "evalStaffName",
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  Widget _bodyContentOne(data) {
    print(data);
    return ListTile(
      title: Text("评价对象：" + showString(data["evalStaffName"])),
      subtitle: Text("试卷名称：" + showString(data["scorePaperName"])),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [],
      ),
      onTap: () {
        //跳转到详情页面
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new ScoreRecordView(data)),
        ).then((value) {
          if (value != null && value) {
            recordController.requestRefresh();
          }
        });
      },
    );
  }

  void _showAddDialog() {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('添加评分记录'),
            content: SingleChildScrollView(
              child: FormBuilder(
                key: _diaLogKey,
                initialValue: {},
                child: Column(
                  children: [
                    FormBuilderTextField(
                      name: "evalStaffName",
                      focusNode: focusNode1,
                      decoration: InputDecoration(labelText: "评价对象"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择评价对象!",
                        ),
                      ]),
                      onTap: () {
                        focusNode1.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择评价对象",
                                url: "/staff/listQueryByPage",
                                searchText: "输入人员名称进行搜索",
                              ),
                            )).then((value) {
                          setState(() {
                            if (value != null) {
                              _diaLogKey.currentState.setState(() {
                                _diaLogKey.currentState.fields['evalStaffName']
                                    .didChange(value["name"]);
                                _diaLogKey.currentState.setInternalFieldValue(
                                    "evalStaffId", value["id"]);
                              });
                            }
                          });
                        });
                      },
                    ),
                    FormBuilderTextField(
                      name: "scorePaperName",
                      focusNode: focusNode2,
                      decoration: InputDecoration(labelText: "评分试卷"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择评分试卷!",
                        ),
                      ]),
                      onTap: () {
                        focusNode2.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择评分试卷",
                                url: "/scorepaper/listQueryByPage",
                                searchText: "输入试卷名称进行搜索",
                              ),
                            )).then((value) {
                          setState(() {
                            if (value != null) {
                              _diaLogKey.currentState.setState(() {
                                _diaLogKey.currentState.fields['scorePaperName']
                                    .didChange(value["name"]);
                                _diaLogKey.currentState.setInternalFieldValue(
                                    "scorePaperId", value["id"]);
                              });
                            }
                          });
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
            actions: <Widget>[
              new ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text("取消"),
              ),
              new ElevatedButton(
                child: new Text('确定'),
                onPressed: () {
                  if (_diaLogKey.currentState.saveAndValidate()) {
                    Navigator.of(context).pop(true);
                    Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) => new ScoreRecordForm(
                              _diaLogKey.currentState.value)),
                    ).then((value) {
                      if (value == true) {
                        recordController.requestRefresh();
                      }
                    });
                  } else {
                    showErrorToast("请填写完记录数据！");
                  }
                },
              ),
            ],
          );
        });
  }
}
