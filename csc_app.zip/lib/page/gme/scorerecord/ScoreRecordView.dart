import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class ScoreRecordView extends BaseApp {
  final Map data;

  ScoreRecordView(this.data) : super();

  @override
  _ScoreRecordViewState createState() => new _ScoreRecordViewState(data);
}

class _ScoreRecordViewState extends BaseAppPage<ScoreRecordView> {
  dynamic data;
  var groupMap = {};
  List<dynamic> itemList = [];
  List<String> starList = [
    "starOne",
    "starTwo",
    "starThree",
    "starFour",
    "starFive"
  ];

  _ScoreRecordViewState(data) {
    this.data = data;
    title = "评分记录详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 10,
            ),
            _dataView(),
            _detailList(),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _initItemList();
    empty = false;
  }

  Widget _dataView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "评分记录基本信息",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 18,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _titleView("评价对象", data["evalStaffName"]),
                          Divider(),
                          _titleView("试卷名称", data["scorePaperName"]),
                          Divider(),
                          _titleView("评价日期", data["evalDate"]),
                          Divider(),
                          _titleView("评价人", data["staffName"]),
                          Divider(),
                          _titleView("总分", data["score"].toString()),
                          Divider(),
                          _titleView("创建人", data["userName"]),
                          Divider(),
                          _titleView("创建日期", data["created"]),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _detailList() {
    List<Widget> itemViewList = [];
    var indexMap = {"groupIndex": 0, "contentIndex": 0};
    this.itemList.forEach((item) {
      itemViewList.add(_buildExperienceRow(item, indexMap));
    });

    return Container(
      padding: EdgeInsets.all(10),
      child: Scrollbar(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
              alignment: Alignment.topLeft,
              child: Text(
                "评分详情",
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                ),
                textAlign: TextAlign.left,
              ),
            ),
            Column(
              children: itemViewList,
            )
          ],
        ),
      ),
    );
  }

  _titleView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 15),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 15),
          ),
        ],
      ),
    );
  }

  _initItemList() {
    setState(() {
      loading = true;
    });
    post("/recorditem/listQueryByPage", {"scoreId": data["id"]}).then((value) {
      var list = value["rows"];
      setState(() {
        loading = false;
        itemList = _createData(list);
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  _createData(List itemList) {
    groupMap = {};
    List resultList = [];
    String lastGroupName = "";
    var tmp = 10000;
    for (int i = 0; i < itemList.length; i++) {
      var scoreItem = itemList[i];

      if (scoreItem["starInfoName"] != null) {
        var weight = (scoreItem["score"] * tmp / scoreItem["totalScore"]);
        var starInfoNameList = scoreItem["starInfoName"].split('，');
        for (var j = 0; j < starList.length; j++) {
          var value = starList[i];
          if (scoreItem[value] * tmp / 100 == weight) {
            scoreItem["star"] = starInfoNameList[j];
          }
        }
      }
      if (lastGroupName != scoreItem['group']) {
        var groupItem = {
          "title": scoreItem['group'],
          "titleType": "group",
        };
        lastGroupName = scoreItem['group'];
        resultList.add(groupItem);
      }
      var childItem = {
        "title": scoreItem['content'],
        "titleType": "content",
        "info": scoreItem
      };
      resultList.add(childItem);
    }
    return resultList;
  }

  Widget _buildExperienceRow(item, indexMap) {
    bool isGroup = item['titleType'] == 'group';
    if (isGroup) {
      indexMap["groupIndex"] += 1;
      indexMap["contentIndex"] = 0;
    } else {
      indexMap["contentIndex"] += 1;
    }
    var info = item["info"];
    var groupIndex = indexMap["groupIndex"];
    var contentIndex = indexMap["contentIndex"];
    var title = item["title"];
    var totalScore = 0.0;
    if (info != null && info["totalScore"] != null) {
      totalScore = info["totalScore"];
    }
    var score = info != null && info["score"] != null ? info["score"].toString() : "";
    var star = info != null && info["star"] != null ? info["star"] : "";
    return Row(
      children: [
        Visibility(
          visible: isGroup,
          child: Container(
            child: Text(
              "$groupIndex.$title",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
            width: 220,
            margin: EdgeInsets.fromLTRB(10.0, 10.0, .0, .0),
          ),
        ),
        Visibility(
          visible: !isGroup,
          child: Container(
            padding: EdgeInsets.all(.0),
            child: Text(
              "$groupIndex.$contentIndex  $title ($totalScore分)",
              style: TextStyle(
                fontSize: 16,
              ),
            ),
            width: 220,
            margin: EdgeInsets.fromLTRB(25.0, 10.0, 60.0, .0),
          ),
        ),
        Visibility(
            visible: !isGroup,
            child: Text(info != null ? (star != "" ? star : score) : "")),
      ],
//      mainAxisAlignment: MainAxisAlignment.spaceBetween,
    );
  }
}
