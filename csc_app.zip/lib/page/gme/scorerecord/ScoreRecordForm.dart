import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class ScoreRecordForm extends BaseApp {
  final dynamic data;

  ScoreRecordForm(this.data);

  @override
  _ScoreRecordFormState createState() => new _ScoreRecordFormState(this.data);
}

class _ScoreRecordFormState extends BaseAppPage {
  dynamic data;
  RefreshController recordController = RefreshController(initialRefresh: true);
  var groupMap = {};

  var groupSize = 0;
  List itemList = [];
  String itemUrl = "/scoreitems/listQueryByPage";
  String saveUrl = "/scorerecord/saveDto";
  List<String> starList = [
    "starOne",
    "starTwo",
    "starThree",
    "starFour",
    "starFive"
  ];

  _ScoreRecordFormState(this.data);

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      MaterialButton(
        child: Text(
          "保存",
        ),
        onPressed: () {
          List recordItemList = [];
          int groupIndex = 0;
          int itemIndex = 0;
          for (int i = 0; i < this.itemList.length; i++) {
            var item = itemList[i];
            bool isGroup = item["titleType"] == "group";
            if (isGroup) {
              groupIndex += 1;
              itemIndex = 0;
              continue;
            }
            itemIndex += 1;

            var info = item["info"];
            if (info["levelNum"] < 2 && info["curScore"] == null) {
              showErrDialog(groupIndex, itemIndex);
              break;
            }
            if (info["levelNum"] > 1 && info["scoreWeight"] == null) {
              showErrDialog(groupIndex, itemIndex);
              break;
            }
            var recordItem = {
              "comment": info["comment"],
              "score": info["score"],
              "explanation": info["explanation"],
              "scoreItemId": info["id"],
              "curScore": info["curScore"],
              "scoreWeight": info["scoreWeight"]
            };
            recordItemList.add(recordItem);
          }

          var params = {
            "scoreRecord": this.data,
            "recordItemList": recordItemList
          };
          loading = true;
          post(this.saveUrl, params).then((value) {
            setState(() {
              loading = false;
            });
            showDialog<Null>(
              context: context,
              barrierDismissible: false,
              builder: (BuildContext context) {
                return new AlertDialog(
                  title: new Text('提示'),
                  content: new SingleChildScrollView(
                    child: new ListBody(
                      children: <Widget>[
                        new Text('保存成功！'),
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    new MaterialButton(
                      child: new Text('确定'),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.pop(context, true);
                      },
                    ),
                  ],
                );
              },
            ).then((val) {});
          }).catchError((error) {
            showErrorToast(error["msg"]);
            setState(() {
              loading = false;
            });
          });
        },
      )
    ];
  }

  showErrDialog(groupIndex, itemIndex) {
    showDialog<Null>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return new AlertDialog(
          title: new Text('请完成评分'),
          content: new SingleChildScrollView(
            child: new ListBody(
              children: <Widget>[
                new Text('第$groupIndex.$itemIndex题未完成评分！'),
              ],
            ),
          ),
          actions: <Widget>[
            new MaterialButton(
              child: new Text('确定'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    ).then((val) {});
  }

  @override
  Widget getBody(BuildContext context) {
    List<Widget> itemViewList = [];
    var indexMap = {"groupIndex": 0, "contentIndex": 0};
    this.itemList.forEach((item) {
      itemViewList.add(_itemView(item, indexMap));
    });
    return Scrollbar(
        child: SingleChildScrollView(
      child: Column(
        children: itemViewList,
      ),
    ));
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    if (data != null) {
      _getScoreItemList();
    }
  }

  _getScoreItemList() {
    post(this.itemUrl, {"scoreId": data["scorePaperId"]}).then((value) {
      var itemList = _createData(value["rows"]);
      setState(() {
        loading = false;
        this.itemList = itemList;
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  _createData(List itemList) {
    groupMap = {};
    List resultList = [];
    String lastGroupName = "";
    for (int i = 0; i < itemList.length; i++) {
      var scoreItem = itemList[i];
      String typeCode = scoreItem['typeCode'];
      scoreItem['levelNum'] =
          int.parse(typeCode.substring(scoreItem['typeCode'].length - 1));
      scoreItem['scoreWeight'] = null;

      List statInfoNameList = [];
      if (scoreItem['starInfoName'] != null) {
        statInfoNameList = scoreItem['starInfoName'].split("，");
      }

      double curScore = 0;
      if (scoreItem['levelNum'] <= 1) {
        curScore = scoreItem['score'];
      }
      if (scoreItem['levelNum'] > 1) {
        curScore = null;
      }

      TextEditingController textController = TextEditingController();
      textController.text = curScore.toString();
      Map<String, dynamic> itemInfo = {
        ...scoreItem,
        "curScore": curScore,
        "statInfoNameList": statInfoNameList,
        "textController": textController,
        "textFieldFocusNode": FocusNode()
      };

      if (lastGroupName != scoreItem['group']) {
        var groupItem = {
          "title": scoreItem['group'],
          "titleType": "group",
        };
        lastGroupName = scoreItem['group'];
        resultList.add(groupItem);
      }
      var childItem = {
        "title": scoreItem['content'],
        "titleType": "content",
        "info": itemInfo
      };
      resultList.add(childItem);
    }
    return resultList;
  }

  _itemView(item, indexMap) {
    bool isGroup = item['titleType'] == 'group';
    if (isGroup) {
      indexMap["groupIndex"] += 1;
      indexMap["contentIndex"] = 0;
    } else {
      indexMap["contentIndex"] += 1;
    }
    var info = item["info"];
    var groupIndex = indexMap["groupIndex"];
    var contentIndex = indexMap["contentIndex"];
    List<String> starInfoNameList = [];
    if (info != null && info['starInfoName'] != null) {
      starInfoNameList = info['starInfoName'].toString().split("，");
      if (info["curStarName"] == null) {
        var key = this.starList[0];
        info["scoreWeight"] = info[key];
        info["curStarName"] = starInfoNameList[0];
      }
    }
    var title = item["title"];
    var totalScore = 0.0;
    if (info != null && info["score"] != null) {
      totalScore = info["score"];
    }
    return Row(
      children: [
        Visibility(
          visible: isGroup,
          child: Container(
            child: Text(
              "$groupIndex.$title",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 20,
              ),
            ),
            width: 180,
            margin: EdgeInsets.fromLTRB(5.0, 10.0, .0, .0),
          ),
        ),
        Visibility(
          visible: !isGroup,
          child: Container(
            child: Text(
              "$groupIndex.$contentIndex  $title ($totalScore分)",
              style: TextStyle(
                fontSize: 16,
              ),
            ),
            width: 180,
            margin: EdgeInsets.fromLTRB(15.0, 7.0, 4.0, 0.0),
          ),
        ),
        Visibility(
            visible: !isGroup && info['levelNum'] < 2,
            child: Expanded(
              child: TextFormField(
                focusNode: info != null && info["textFieldFocusNode"] != null
                    ? info["textFieldFocusNode"]
                    : null,
                controller: info != null && info["textController"] != null
                    ? info["textController"]
                    : null,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: '输入分数',
                  hintStyle: TextStyle(fontSize: 14),
                  contentPadding: const EdgeInsets.symmetric(vertical: 10.0),
                  prefixIcon: Container(
                    decoration: BoxDecoration(
                        border: Border(
                            right: BorderSide(
                                width: 1, style: BorderStyle.solid))),
                    child: SizedBox(
                      width: .0,
                      child: IconButton(
                        onPressed: () {
                          setFocus(info);
                          changeScore("sub", info);
                        },
                        padding: EdgeInsets.all(.0),
                        icon: new Icon(Icons.remove),
                      ),
                    ),
                  ),
                  suffixIcon: Container(
                    width: 10,
                    margin: EdgeInsets.all(.0),
                    decoration: BoxDecoration(
                        border: Border(
                            left: BorderSide(
                                width: 1, style: BorderStyle.solid))),
                    child: SizedBox(
                      width: 20,
                      child: IconButton(
                        onPressed: () {
                          setFocus(info);
                          changeScore("add", info);
                        },
                        padding: EdgeInsets.all(.0),
                        icon: new Icon(Icons.add),
                      ),
                    ),
                  ),
                ),
              ),
            )),
        Visibility(
            visible: !isGroup && info['levelNum'] >= 2,
            child: new DropdownButton(
              hint: Text("请选择评分等级"),
              items: starInfoNameList.map((e) {
                return DropdownMenuItem(
                  child: new Text(e),
                  value: e,
                );
              }).toList(),
              value: info != null && info["curStarName"] != null
                  ? info["curStarName"]
                  : "",
              onChanged: (value) {
                var index = starInfoNameList.indexOf(value);
                var key = this.starList[index];
                setState(() {
                  info["scoreWeight"] = info[key];
                  info["curStarName"] = value;
                });
              },
            )),
      ],
//      mainAxisAlignment: MainAxisAlignment.spaceBetween,
    );
  }

  setFocus(info) {
    FocusNode textFieldFocusNode = info["textFieldFocusNode"];
    textFieldFocusNode.unfocus();
    textFieldFocusNode.canRequestFocus = false;
    Future.delayed(Duration(milliseconds: 100), () {
      textFieldFocusNode.canRequestFocus = true;
    });
  }

  changeScore(method, info) {
    if (info == null || info["step"] == null) {
      return;
    }
    TextEditingController controller = info["textController"];
    double step = info["step"];
    double score = info["score"];
    double curScore = double.parse(controller.text);
    double tempScore = 0.0;
    if (method == "add") {
      tempScore = curScore + step;
    } else {
      tempScore = curScore - step;
    }

    if (tempScore <= 0) {
      tempScore = 0;
    }
    if (tempScore >= score) {
      tempScore = score;
    }
    info["curScore"] = tempScore.toStringAsFixed(2);
    controller.text = tempScore.toStringAsFixed(2);
  }
}
