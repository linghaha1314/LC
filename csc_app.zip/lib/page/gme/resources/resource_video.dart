import 'dart:async';
import 'dart:io';

import 'package:chewie/chewie.dart';
import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/pojo/UserInfo.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:video_player/video_player.dart';
import 'package:local_auth_android/local_auth_android.dart';
import 'package:local_auth_ios/local_auth_ios.dart';

class ResourceVideoPage extends BaseApp {
  @override
  _ResourceVideoPageState createState() => new _ResourceVideoPageState();
}

class _ResourceVideoPageState extends BaseAppPage<ResourceVideoPage> {
  VideoPlayerController videoPlayerController;
  ChewieController chewieController;
  var ratio = 16 / 9;
  bool play = false;
  Timer _timer;
  bool complete = false;
  String completeId;
  String url;
  double now = 0.0;
  String playTime = "--:--:--/--:--:--";
  var lastAuthTime = 0;
  final LocalAuthentication auth = LocalAuthentication();
  TextEditingController _controller;

  _ResourceVideoPageState() {
    title = '学习资源';
    loading = true;
    empty = true;
  }

  @override
  initRouteSuccess() async {
    title = routeData["resources"]["name"];
    var path = await getHttpPath();
    var file = routeData["resources"]["attach"].toString();
    if (file.startsWith("http")) {
      url = file;
    } else {
      url = Uri.encodeFull('$path${routeData["resources"]["attach"]}');
    }
    _controller = TextEditingController();
    if (routeData["resourceStudy"] != null) {
      _controller.text = routeData["resourceStudy"]["note"];
    }
    videoPlayerController = VideoPlayerController.network(url)
      ..addListener(
        () {
          if (chewieController != null) {
            if (chewieController.isPlaying) {
              if (!play) {
                play = true;
                setState(() {});
              }
            } else {
              if (play) {
                play = false;
                setState(() {});
              }
            }
          }
        },
      );
    showInfoToast("由于服务器宽带原因,视频可能出现卡顿,请耐心等待!");
    await videoPlayerController.initialize();
    chewieController = ChewieController(
      videoPlayerController: videoPlayerController,
      autoPlay: false,
      allowMuting: false,
      isLive: true,
      allowPlaybackSpeedChanging: false,
      autoInitialize: true,
      aspectRatio: ratio,
      playbackSpeeds: [1.0, 0.5],
      showControls:
          (Platform.isIOS || routeData["resources"]["forwardFlag"] == true),
      customControls: routeData["resources"]["forwardFlag"] == true
          ? null
          : IconButton(
              icon: Icon(Icons.arrow_back),
              color: ThemeColor.getColor("info"),
              onPressed: () {
                chewieController.exitFullScreen();
              },
            ),
    );
    UserInfo userInfo = await getCurrentAccount();
    post("/resourcestudy/listByEntity", {
      "resourceId": routeData["resourceId"],
      "staffId": userInfo.staff["id"]
    }).then((res) {
      var list = res["data"] as List<dynamic>;
      Duration seek = Duration(milliseconds: 0);
      list.forEach((e) {
        if (e["complete"] != true) {
          print(e);
          seek = Duration(milliseconds: e["progress"]);
        } else {
          complete = true;
          completeId = e["id"];
        }
      });
      if (seek.inMilliseconds != 0) {
        complete = false;
      }
      videoPlayerController.seekTo(seek).then((value) {
        empty = false;
        loading = false;
        setState(() {});
      });
    });
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      videoPlayerController.position.then((d) {
        setState(() {
          playTime = d.toString().split(".")[0] +
              "/" +
              videoPlayerController.value.duration.toString().split(".")[0];
          now = d.inMilliseconds /
              videoPlayerController.value.duration.inMilliseconds;
        });
        // 记录进度
        if (chewieController.isPlaying) {
          post("/resourcestudy/saveOrUpdate", {
            "resourceId": routeData["resourceId"],
            "total": videoPlayerController.value.duration.inMilliseconds,
            "progress": d.inMilliseconds,
          }).then((res) {
            print(res);
          });
        }
        // 完成学习
        if (complete == false &&
            chewieController.isPlaying == false &&
            videoPlayerController.value.duration.inMilliseconds -
                    d.inMilliseconds <
                5000) {
          complete = true;
          post("/resourcestudy/saveOrUpdate", {
            "resourceId": routeData["resourceId"],
            "complete": true,
            "status": 0,
          }).then((res) {
            print(res);
          });
        }
        // 防挂机验证
        if (!complete &&
            chewieController.isPlaying &&
            d.inSeconds != lastAuthTime &&
            routeData["resources"]["verifyTime"] > 0 &&
            d.inSeconds % routeData["resources"]["verifyTime"] == 0) {
          lastAuthTime = d.inSeconds;
          chewieController.pause();
          showAuth(d.inMilliseconds,
              videoPlayerController.value.duration.inMilliseconds);
        }
      });
    });
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.eighteen_mp),
        onPressed: changeRatio,
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        AspectRatio(
          aspectRatio: ratio,
          child: Chewie(
            controller: chewieController,
          ),
        ),
        LinearProgressIndicator(
          value: now,
          backgroundColor: ThemeColor.getColor("info"),
          valueColor: new AlwaysStoppedAnimation<Color>(
            ThemeColor.getColor("focus"),
          ),
        ),
        Expanded(
          flex: 1,
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Text(
                      "🎆提示: 视频播放自动结束才算已完成学习🎆",
                      style: TextStyle(
                        color: ThemeColor.getColor("focus"),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Center(
                    child: Text(
                      "已学习点击播放会重新学习,原学习记录会保留",
                      style: TextStyle(
                        color: ThemeColor.getColor("focus"),
                      ),
                    ),
                  ),
                  SizedBox(height: 10),
                  Text("简介: ${showString(routeData["resources"]["info"])}"),
                  SizedBox(height: 20),
                  Text("时长: $playTime"),
                  SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("是否可以下载: "),
                      if (routeData["canDownload"] == true)
                        Container(
                          height: 25.0,
                          child: OutlinedButton(
                            onPressed: () {
                              downloadFile(url, routeData["resources"]["name"]);
                            },
                            child: Text(
                              "点击下载",
                            ),
                          ),
                        )
                      else
                        Text("不能下载")
                    ],
                  ),
                  SizedBox(height: 20),
                  Text(
                      "是否可以快进: ${routeData["resources"]["forwardFlag"] == true ? "是" : "否"}"),
                  SizedBox(height: 20),
                  Text(
                      "是否启用验证: ${(routeData["resources"]["verifyTime"] != null && routeData["resources"]["verifyTime"] > 0) ? ("每" + routeData["resources"]["verifyTime"].toString() + "秒验证一次") : "否"}"),
                  SizedBox(height: 20),
                  Text(
                      "试卷: ${showString(routeData["resources"]["volumeName"])}"),
                  SizedBox(height: 20),
                  Text(
                      "备注: ${showString(routeData["resources"]["resourceRemark"])}"),
                  SizedBox(height: 20),
                  Container(
                    margin: EdgeInsets.fromLTRB(10.0, .0, 10.0, 10.0),
                    child: TextField(
                      minLines: 5,
                      maxLines: 20,
                      controller: _controller,
                      decoration: new InputDecoration(
                        focusedBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: ThemeColor.getColor("border")),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide:
                              BorderSide(color: ThemeColor.getColor("border")),
                        ),
                        hintText: '请输入学习笔记或意见,500字以内,修改后自动保存',
                      ),
                      onChanged: (value) {
                        post("/resourcestudy/saveOrUpdate", {
                          "id": complete ? completeId : null,
                          "resourceId": routeData["resourceId"],
                          "note": value,
                        });
                      },
                      inputFormatters: <TextInputFormatter>[
                        LengthLimitingTextInputFormatter(500)
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Container(
          height: 50.0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              OutlinedButton.icon(
                icon: Icon(chewieController.isPlaying
                    ? MdiIcons.pause
                    : MdiIcons.play),
                label: Text(chewieController.isPlaying ? "暂停学习" : "开始学习"),
                onPressed: () {
                  if (complete) {
                    showConfirmAlert("您已完成当前学习,重新学习不会影响您之前的学习记录,是否继续?")
                        .then((value) {
                      if (value) {
                        complete = false;
                        chewieController.seekTo(Duration(milliseconds: 0));
                        play = true;
                        chewieController?.play();
                        setState(() {});
                      }
                    });
                    return;
                  }
                  if (chewieController.isPlaying) {
                    play = false;
                    chewieController?.pause();
                  } else {
                    play = true;
                    chewieController?.play();
                  }
                  setState(() {});
                },
              ),
              SizedBox(width: 20.0),
              if (routeData["resourceStudy"] != null)
                Visibility(
                  visible:
                      (complete && routeData["resources"]["volumeId"] != null),
                  child: OutlinedButton.icon(
                    icon: Icon(MdiIcons.volumeSource),
                    label: Text(routeData["resourceStudy"]["resultId"] == null
                        ? "开始答题"
                        : "已答题"),
                    onPressed: () {
                      if (routeData["resourceStudy"]["resultId"] == null) {
                        Navigator.pushNamed(context, "volume", arguments: {
                          "volumeId": routeData["resources"]["volumeId"],
                          "volumeName": routeData["resources"]["volumeName"],
                        }).then((value) {
                          if (value != null) {
                            dynamic d = value as dynamic;
                            setState(() {
                              loading = true;
                              routeData["resourceStudy"]["resultId"] =
                                  d["examAnswer"]["id"];
                            });
                            post("/resourcestudy/updateField", {
                              "id": completeId,
                              "resultId": d["examAnswer"]["id"],
                            }).then((res) {
                              setState(() {
                                loading = false;
                              });
                            });
                          }
                        });
                      } else {
                        Navigator.pushNamed(context, "volumeResult",
                            arguments: {
                              "resultId": routeData["resourceStudy"]["resultId"]
                            });
                      }
                    },
                  ),
                ),
              if (chewieController?.isPlaying)
                OutlinedButton.icon(
                  icon: Icon(MdiIcons.fullscreen),
                  label: Text("全屏"),
                  onPressed: () {
                    if (chewieController.isPlaying) {
                      chewieController.enterFullScreen();
                    }
                  },
                ),
            ],
          ),
        )
      ],
    );
  }

  changeRatio() {
    showBarModalBottomSheet(
      context: context,
      builder: (context) => Material(
          child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              title: Text('16:9'),
              leading: Icon(Icons.airplay),
              onTap: () {
                setState(() {
                  ratio = 16 / 9;
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('4:3'),
              leading: Icon(Icons.airplay),
              onTap: () {
                setState(() {
                  ratio = 4 / 3;
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('21:9'),
              leading: Icon(Icons.airplay),
              onTap: () {
                setState(() {
                  ratio = 21 / 9;
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: Text('3:2'),
              leading: Icon(Icons.airplay),
              onTap: () {
                setState(() {
                  ratio = 3 / 2;
                });
                Navigator.pop(context);
              },
            ),
          ],
        ),
      )),
    );
  }

  showAuth(int progress, int total) async {
    var d = DateTime.now().toString();
    bool _auth = await _authenticate();
    String client = await getDeviceName();
    if (_auth == null) {
      showConfirmAlert("请点击确认按钮开始继续观看").then((value) {
        chewieController.play();
        post("/resourcerecord/save", {
          "total": total,
          "progress": progress,
          "resourceId": routeData["resourceId"],
          "startTime": d,
          "platform": client,
          "type": 0,
          "status": 0,
          "endTime": DateTime.now().toString(),
        });
      });
    } else {
      if (_auth) {
        chewieController.play();
      }
      post("/resourcerecord/save", {
        "total": total,
        "progress": progress,
        "resourceId": routeData["resourceId"],
        "startTime": d,
        "platform": client,
        "type": 1,
        "status": _auth ? 0 : 1,
        "endTime": DateTime.now().toString(),
      });
    }
  }

  Future<bool> _authenticate() async {
    bool authenticated = false;
    final bool canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
    final bool canAuthenticate =
        canAuthenticateWithBiometrics || await auth.isDeviceSupported();
    if (!canAuthenticate) {
      return Future.value(null);
    }
    try {
      authenticated = await auth.authenticate(
        localizedReason: '不验证会进行记录',
        authMessages: const <AuthMessages>[
          AndroidAuthMessages(
            biometricHint: '需要验证是否本人观看',
            signInTitle: '观看验证',
            cancelButton: '取消',
          ),
          IOSAuthMessages(
            lockOut: '需要验证是否本人观看',
            cancelButton: '取消',
          ),
        ],
      );
    } on PlatformException catch (e) {
      print(e);
      return Future.value(null);
    }
    if (!mounted) return Future.value(authenticated);
    return Future.value(authenticated);
  }

  @override
  void dispose() {
    _timer?.cancel();
    videoPlayerController?.dispose();
    chewieController?.dispose();
    super.dispose();
  }
}
