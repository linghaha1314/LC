import 'dart:convert';

import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class ResourceStaffPage extends BaseApp {
  @override
  _ResourceStaffPageState createState() => new _ResourceStaffPageState();
}

class _ResourceStaffPageState extends BaseAppPage<ResourceStaffPage> {
  RefreshController _controller;
  String viewUrl;
  String clientUrl;

  _ResourceStaffPageState() {
    title = '我的资源';
    empty = false;
  }

  @override
  initRouteSuccess() {
    if (routeData != null && routeData["resourceId"] != null) {
      setState(() {
        loading = true;
      });
      post("/resourcestaff/save", {
        "resourceId": routeData["resourceId"],
        "type": 1,
        "downloadFlag": false,
        "status": 0
      }).then((res) {
        setState(() {
          loading = false;
        });
        _controller?.requestRefresh();
        showSuccessToast("资源获取成功!");
      }).catchError((err) {
        setState(() {
          loading = false;
        });
        showErrorAlert(err["msg"]);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    _controller = RefreshController(initialRefresh: false);
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      searchText: "请输入名称进行搜索",
      controller: _controller,
      url: "/resourcestaff/listMyResource",
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  _bodyContentOne(data) {
    return ListTile(
      title: Text(data["resources"]["name"]),
      subtitle: data["resourceStudy"] != null
          ? Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: new LinearProgressIndicator(
                    value: (data["resourceStudy"]["progress"] == null ||
                            data["resourceStudy"]["total"] == null)
                        ? 0
                        : data["resourceStudy"]["progress"] /
                            data["resourceStudy"]["total"],
                    backgroundColor: ThemeColor.getColor("info"),
                    valueColor: new AlwaysStoppedAnimation<Color>(
                      ThemeColor.getColor("focus"),
                    ),
                  ),
                  flex: 1,
                ),
                Text(
                  " ${(data["resourceStudy"]["progress"] == null || data["resourceStudy"]["total"] == null) ? 0 : (double.parse((data["resourceStudy"]["progress"] / data["resourceStudy"]["total"]).toStringAsFixed(2)) * 100).toStringAsFixed(0)}% ",
                  style: TextStyle(
                    color: ThemeColor.getColor("fontColor"),
                  ),
                ),
              ],
            )
          : null,
      trailing: data["resourceStudy"] != null
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Visibility(
                  visible: data["resourceStudy"] != null,
                  child: data["resourceStudy"]["complete"] == true
                      ? Chip(
                          backgroundColor: ThemeColor.getColor("success"),
                          label: Text("已学习"),
                        )
                      : Chip(
                          backgroundColor: ThemeColor.getColor("info"),
                          label: Text("学习中"),
                        ),
                ),
                Visibility(
                  visible: data["resourceStudy"] == null,
                  child: Chip(
                    backgroundColor: ThemeColor.getColor("warning"),
                    label: Text("未学习"),
                  ),
                ),
              ],
            )
          : null,
      onTap: () {
        if (data["resources"]['suffix'] == null ||
            data["resources"]['suffix'].length == 0) {
          data["resources"]['suffix'] = "mp4";
        }
        if ("mp4,m4v,mov,qt,avi,flv,wmv,asf,mpeg,mpg,vob,mkv,asf,wmv,rm,rmvb,vob,ts,dat"
            .contains(data["resources"]['suffix'])) {
          Navigator.pushNamed(context, "resourceVideo", arguments: data)
              .then((value) {
            _controller.requestRefresh();
          });
        } else {
          if (data["resources"]['attach'] != null) {
            viewFile(data["resources"]['attach']);
          } else {
            showErrorAlert("当前资源不存在,无法打开!");
          }
        }
      },
    );
  }

  viewFile(String path) async {
    if (viewUrl == null) {
      var config = await get("/config/getFileViewer");
      viewUrl = "${config["fileServer"]}/onlinePreview?url=";
      clientUrl = config["fileClient"];
    }
    String u =  path;
    if (!path.startsWith("http")) {
      u = viewUrl + Uri.encodeComponent(base64Encode(utf8.encode("$clientUrl$path")));
    } else {
      u = viewUrl + Uri.encodeComponent(base64Encode(utf8.encode(Uri.decodeFull(path))));
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WebViewPage(url:u),
      ),
    );
  }
}
