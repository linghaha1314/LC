import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/page/exam/examStorehouse/ExamStorehouseExamine.dart';
import 'package:flutter/material.dart';

class ExamStorehouseExamPage extends BaseApp {
  @override
  _ExamStorehouseExamPageState createState() =>
      new _ExamStorehouseExamPageState();
}

class _ExamStorehouseExamPageState extends BaseAppPage<ExamStorehouseExamPage> {
  _ExamStorehouseExamPageState() {
    title = "待开始考试列表";
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      searchText: "请输入考试名称进行搜索",
      url: "/testplan/listQueryByPage",
      queryParams: {"status": "2"},
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  _bodyContentOne(data) {
    return ListTile(
      title: Text(data['name']),
      subtitle: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("类型:${data['typeName']}"),
          Text("${data['planDateList'][0]['startDate']}")
        ],
      ),
      onTap: () {
        data['viable'] = true;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ExamStorehouseExamine(data),
          ),
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SelectPage(
                  title: "选择考试",
                  url: "/testplan/listQueryByPage",
                  queryParams: {"statisticsFlag": true},
                  searchText: "输入名称进行搜索",
                ),
              )).then((value) {
            if (value != null) {
              //跳转至详情页面
              value['viable'] = false;
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ExamStorehouseExamine(value),
                ),
              );
            }
          });
        },
        tooltip: "历史考试",
        icon: Icon(Icons.menu),
      )
    ];
  }
}
