import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

import '../../../ThemeColor.dart';

class ExamStorehouseExamine extends BaseApp {
  final dynamic data;

  ExamStorehouseExamine(this.data);

  @override
  _ExamStorehouseExamineState createState() =>
      new _ExamStorehouseExamineState(this.data);
}

class _ExamStorehouseExamineState extends BaseAppPage<ExamStorehouseExamine>
    with SingleTickerProviderStateMixin {
  final dynamic data;
  List<dynamic> list = [];
  dynamic planItemStationMap = {};
  dynamic planItemPaperMap = {};
  dynamic scorePaperSuppliesMap = {};
  int total = 0;
  int commitTotal = 0;
  int currentIndex = 0;
  bool viable = false;
  Map<String, bool> paperSupplies = {};
  TabController _controller;

  _ExamStorehouseExamineState(this.data) {
    viable = this.data['viable'];
    title = "考试考室分布";
  }

  @override
  Widget getAppBar(BuildContext context) {
    if (list.length == 0) return super.getAppBar(context);
    return AppBar(
      title: getTitle(context),
      actions: getActions(context),
      bottom: TabBar(
        isScrollable: true,
        onTap: (index) {
          currentIndex = index;
        },
        controller: _controller,
        tabs: list.map((e) {
          return Tab(
            text: e["roomName"],
          );
        }).toList(),
      ),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return viable
        ? [
            PopupMenuButton(
              icon: Icon(Icons.more_horiz),
              itemBuilder: (BuildContext context) {
                return [
                  new PopupMenuItem(
                    value: "all",
                    child: ListTile(
                      title: new Text("全部清点"),
                    ),
                  ),
                  new PopupMenuItem(
                    value: "commit",
                    child: ListTile(
                      title: new Text("提交"),
                    ),
                  ),
                ];
              },
              onSelected: (String newValue) {
                if (newValue == 'all') {
                  setState(() {
                    commitTotal = total;
                    paperSupplies.keys.forEach((element) {
                      paperSupplies[element] = true;
                    });
                  });
                } else if (newValue == 'commit') {
                  commitExamStorehouseExamine();
                }
              },
            ),
          ]
        : [];
  }

  @override
  Widget getBottom(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: ThemeColor.getColor("data"),
        border: Border(
          top: BorderSide(
            width: 1, //宽度
            color: ThemeColor.getColor("content"), //边框颜色
          ),
        ),
      ),
      height: 65,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Expanded(
            flex: 1,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "已清点: $commitTotal / $total",
                    style: TextStyle(fontSize: 15),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: SizedBox(
                width: MediaQuery.of(context).size.width / 2.5,
                child: ElevatedButton(
                  child: Text("当前考室清点完成"),
                  // color: ThemeColor.getColor("info"),
                  onPressed: () {
                    var _e = list[_controller.index];
                    planItemPaperMap[_e['id']].forEach((e) {
                      if (scorePaperSuppliesMap[e["paperId"]] != null) {
                        setState(() {
                          scorePaperSuppliesMap[e["paperId"]].forEach((s) {
                            if (!paperSupplies["${_e['id']}&${s["id"]}"]) {
                              commitTotal += 1;
                            }
                            paperSupplies["${_e['id']}&${s["id"]}"] = true;
                          });
                          paperSupplies["${_e['id']}&${e["paperId"]}"] = true;
                        });
                      }
                    });
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: _controller,
      children: list.map((_e) {
        if (planItemPaperMap[_e['id']] != null) {
          return SingleChildScrollView(
            child: Column(
              children: planItemPaperMap[_e['id']].map<Widget>((e) {
                return Card(
                  margin: EdgeInsets.all(10.0),
                  child: Container(
                    padding: EdgeInsets.all(10.0),
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(.0, .0, 13.0, 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("${e['paperName']}"),
                              scorePaperSuppliesMap[e["paperId"]] != null
                                  ? Checkbox(
                                      value: paperSupplies[
                                          _e['id'] + '&' + e['paperId']],
                                      onChanged: viable
                                          ? (value) {
                                              paperSupplies[
                                                      "${_e['id']}&${e['paperId']}"] =
                                                  !paperSupplies[
                                                      "${_e['id']}&${e['paperId']}"];
                                              scorePaperSuppliesMap[
                                                      e["paperId"]]
                                                  .forEach((s) {
                                                setState(() {
                                                  if (paperSupplies[
                                                          "${_e['id']}&${s["id"]}"] &&
                                                      !paperSupplies[
                                                          "${_e['id']}&${e["paperId"]}"]) {
                                                    commitTotal -= 1;
                                                  } else if (!paperSupplies[
                                                          "${_e['id']}&${s["id"]}"] &&
                                                      paperSupplies[
                                                          "${_e['id']}&${e["paperId"]}"]) {
                                                    commitTotal += 1;
                                                  }
                                                  paperSupplies[
                                                          "${_e['id']}&${s["id"]}"] =
                                                      paperSupplies[
                                                          "${_e['id']}&${e["paperId"]}"];
                                                });
                                              });
                                            }
                                          : null,
                                    )
                                  : SizedBox()
                            ],
                          ),
                        ),
                        Divider(),
                        scorePaperSuppliesMap[e["paperId"]] != null
                            ? Column(
                                children: scorePaperSuppliesMap[e["paperId"]]
                                    .map<Widget>((s) {
                                  return CheckboxListTile(
                                    title: Text(
                                        "${s["name"]}(${s["amount"].toString() + s["unitName"]})"),
                                    subtitle: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                            "规格:${s["specificationName"] != null ? s["specificationName"] : "无"}"),
                                        Text(
                                            "编码:${s["code"] != null ? s["code"] : "无"}")
                                      ],
                                    ),
                                    value:
                                        paperSupplies[_e['id'] + '&' + s["id"]],
                                    onChanged: viable
                                        ? (bool value) {
                                            setState(() {
                                              paperSupplies[_e['id'] +
                                                      '&' +
                                                      s["id"]] =
                                                  !paperSupplies[
                                                      _e['id'] + '&' + s["id"]];
                                              if (paperSupplies[
                                                  _e['id'] + '&' + s["id"]]) {
                                                commitTotal += 1;
                                              } else {
                                                commitTotal -= 1;
                                              }
                                              if (value) {
                                                var flag = true;
                                                scorePaperSuppliesMap[
                                                        e["paperId"]]
                                                    .forEach((s) {
                                                  if (!paperSupplies[_e['id'] +
                                                      '&' +
                                                      s["id"]]) {
                                                    flag = false;
                                                  }
                                                });
                                                if (flag) {
                                                  paperSupplies[
                                                          "${_e['id']}&${e['paperId']}"] =
                                                      true;
                                                }
                                              } else {
                                                paperSupplies[
                                                        "${_e['id']}&${e['paperId']}"] =
                                                    false;
                                              }
                                            });
                                          }
                                        : null,
                                  );
                                }).toList(),
                              )
                            : Center(
                                child: Container(
                                  margin: EdgeInsets.only(top: 20, bottom: 20),
                                  child: Text(
                                    "无需准备耗材！",
                                    style: TextStyle(
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                              ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          );
        } else {
          return SizedBox();
        }
      }).toList(),
    );
  }

  @override
  void initState() {
    initExamExamine();
    super.initState();
  }

  _initController() {
    _controller = TabController(length: list.length, vsync: this);
  }

  initExamExamine() {
    post("/testplan/getTestPlanStoreHouseById", {"id": data['id']})
        .then((value) {
      if (value["success"]) {
        var data = value["data"];
        var dataList = [];
        var testBeforeChecksMap = data["testBeforeChecksMap"] != null
            ? data["testBeforeChecksMap"]
            : {};
        data['planItemStationMap'].values.forEach((r) {
          if (r != null) {
            dataList.addAll(r);
            r.forEach((pi) {
              if (data['planItemPaperMap'][pi['id']] != null) {
                data['planItemPaperMap'][pi['id']].forEach((d) {
                  if (data['scorePaperSuppliesMap'][d['paperId']] != null) {
                    var flag = true;
                    total += (data['scorePaperSuppliesMap'][d['paperId']]
                            as List<dynamic>)
                        .length;
                    data['scorePaperSuppliesMap'][d['paperId']].forEach((s) {
                      if (testBeforeChecksMap[pi['id'] + '&' + s['id']] !=
                          null) {
                        paperSupplies[pi['id'] + '&' + s['id']] =
                            testBeforeChecksMap[pi['id'] + '&' + s['id']] == 1
                                ? true
                                : false;
                        if (testBeforeChecksMap[pi['id'] + '&' + s['id']] ==
                            0) {
                          flag = false;
                        } else {
                          commitTotal += 1;
                        }
                      } else {
                        paperSupplies[pi['id'] + '&' + s['id']] = false;
                        flag = false;
                      }
                    });
                    paperSupplies[pi['id'] + '&' + d['paperId']] = flag;
                  }
                });
              }
            });
          }
        });
        setState(() {
          planItemStationMap = data['planItemStationMap'];
          list = dataList;
          planItemPaperMap = data['planItemPaperMap'];
          scorePaperSuppliesMap = data['scorePaperSuppliesMap'];
        });
        _initController();
        empty = data["planItemStationMap"].values.length == 0;
      }
    });
  }

  commitExamStorehouseExamine() {
    var params = {
      "testId": data['id'],
      "suppliesMap": jsonEncode(paperSupplies)
    };
    setState(() {
      loading = true;
    });
    post("/testbeforecheck/examSuppliesExamine", params).then((value) {
      if (value['success']) {
        showSuccessToast("提交完成！");
        setState(() {
          loading = false;
          Navigator.pop(context);
        });
      }
    }).catchError((onError) {
      setState(() {
        loading = false;
      });
    });
  }
}
