import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/page/exam/simpleTest/ScorePage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'SimpleTestHistory.dart';

class SimpleTestScore extends BaseApp {
  @override
  _SimpleTestScoreState createState() => new _SimpleTestScoreState();
}

class _SimpleTestScoreState extends BaseAppPage<SimpleTestScore> {
  List<dynamic> examList = [];
  dynamic nowExam = {};
  dynamic nowPaper = {};
  dynamic staff = {};

  _SimpleTestScoreState() {
    title = "考核评分";
    loading = true;
  }

  @override
  void initState() {
    super.initState();
    initData();
  }

  initData() async {
    var exam = await post('/simpletestexaminer/getMyExam', {});
    if (!exam['success']) {
      return;
    }
    examList = exam['data'];
    if (examList.length > 0) {
      nowExam = examList[0];
      if (nowExam["paper"].length > 0) {
        nowPaper = nowExam["paper"][0];
      }
    } else {
      showErrorAlert("未查询到您的考试,请联系考务人员!");
    }
    setState(() {
      empty = false;
      loading = false;
    });
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.history),
        tooltip: "历史记录",
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SimpleTestHistory(),
            ),
          );
        },
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return ListView(
      children: [
        ListTile(
          title: Text("考试:"),
          trailing: Text(showString(nowExam["name"])),
          onTap: showExamList,
        ),
        Divider(),
        ListTile(
          title: Text("考题:"),
          trailing: Text(showString(nowPaper["name"])),
          onTap: showVolumeList,
        ),
        Divider(),
        ListTile(
          title: Text("考生:"),
          trailing: Text(showString(staff["name"])),
          onTap: showStudent,
        ),
        Divider(),
        Container(
          padding: EdgeInsets.fromLTRB(.0, 20.0, .0, .0),
          child: Center(
            child: Text("🍥请按照考试、考题、考生的顺序进行选择🍥"),
          ),
        ),
        Container(
          padding: EdgeInsets.fromLTRB(.0, 20.0, .0, .0),
          child: Center(
            child: Text("⚡评分过程中请保证您的手机或平板电量充足⚡"),
          ),
        ),
      ],
    );
  }

  showExamList() {
    if (examList.length == 0) {
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return ListView.separated(
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              title: Text(examList[index]["name"]),
              onTap: () {
                nowExam = examList[index];
                if (nowExam["paper"].length > 0) {
                  nowPaper = nowExam["paper"][0];
                }
                setState(() {});
                Navigator.of(context).pop();
              },
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return Divider();
          },
          itemCount: examList.length,
          shrinkWrap: true,
        );
      },
    );
  }

  showVolumeList() {
    if (examList.length == 0) {
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return ListView.separated(
          itemBuilder: (BuildContext context, int index) {
            return ListTile(
              title: Text(nowExam["paper"][index]["name"]),
              onTap: () {
                nowPaper = nowExam["paper"][index];
                setState(() {});
                Navigator.of(context).pop();
              },
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return Divider();
          },
          itemCount: nowExam["paper"].length,
          shrinkWrap: true,
        );
      },
    );
  }

  showStudent() {
    if (examList.length == 0) {
      return;
    }
    if (nowExam["id"] == null) {
      showErrorToast("请先选择考试!");
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return RefreshList(
          url: "/simpleteststudent/listQueryByPage",
          queryParams: {"testId": nowExam["id"]},
          searchText: "请输入姓名或胸牌",
          buildItem: (dynamic row, int i) {
            return ListTile(
              title: new Text(row["name"]),
              trailing: new Text(row["serialNo"]),
              onTap: () {
                staff = row;
                setState(() {});
                Navigator.pop(context);
              },
            );
          },
        );
      },
    );
  }

  @override
  Widget getBottom(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10.0),
      child: OutlinedButton.icon(
        icon: Icon(Icons.arrow_forward_outlined),
        label: Text("进入评分"),
        onPressed: () {
          if (nowExam["id"] == null) {
            showErrorToast("请选择考试!");
            return;
          }
          if (nowPaper["id"] == null) {
            showErrorToast("请选择考题!");
            return;
          }
          if (staff["id"] == null) {
            showErrorToast("请选择考生!");
            return;
          }
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  ScorePage(nowExam, nowPaper["id"], staff),
            ),
          );
        },
      ),
    );
  }
}
