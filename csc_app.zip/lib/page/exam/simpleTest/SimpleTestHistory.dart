import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';

import 'SimpleTestHistoryDetail.dart';

class SimpleTestHistory extends BaseApp {
  @override
  _SimpleTestHistoryState createState() => new _SimpleTestHistoryState();
}

class _SimpleTestHistoryState extends BaseAppPage<SimpleTestHistory> {
  _SimpleTestHistoryState() {
    title = "参与的考试";
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      url: "/simpletestplan/getMyPlan",
      searchText: "请输入名称查询",
      buildItem: (dynamic row, int i) {
        return ListTile(
          title: new Text(row["name"]),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SimpleTestHistoryDetail(row),
              ),
            );
          },
        );
      },
    );
  }
}
