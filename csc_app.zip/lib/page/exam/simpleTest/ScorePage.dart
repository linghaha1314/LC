import 'dart:async';
import 'dart:ui';

import 'package:badges/badges.dart' as badges;
import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RichSubText.dart';
import 'package:csc_app/component/SignatureComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:date_format/date_format.dart';
import 'package:decimal/decimal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

class ScorePage extends BaseApp {
  final dynamic exam;
  final String paperId;
  final dynamic staff;

  ScorePage(this.exam, this.paperId, this.staff);

  @override
  _ScorePageState createState() =>
      _ScorePageState(this.exam, this.paperId, this.staff);
}

class _ScorePageState extends BaseAppPage<ScorePage>
    with SingleTickerProviderStateMixin {
  TabController tabController;
  dynamic scorePaper = {};
  dynamic controllerMap = {};
  dynamic remarks = {};
  double buttonWidth = 35;
  double buttonHeight = 35;
  Map<String, dynamic> scoreItems = {};
  final ItemScrollController listViewController = ItemScrollController();
  final ItemPositionsListener itemPositionsListener =
      ItemPositionsListener.create();
  var titleList = [];
  var heightList = [];
  var commitScore = 0.0;
  var allScoreTotal = 0.0;
  var titleIndex = 0;
  String scorePaperId;
  String examId;
  dynamic staff;
  int time = 0;
  Timer _timer;
  final TextStyle _style = TextStyle(fontSize: 20.0);
  DateTime startDate = DateTime.now();
  bool multipleFlag;
  bool signFlag;
  bool backFlag = false;
  bool fullFlag = false;

  _ScorePageState(dynamic exam, String paperId, dynamic staff) {
    empty = true;
    loading = true;
    this.examId = exam["id"];
    this.multipleFlag = exam["multipleFlag"];
    this.signFlag = exam["signFlag"];
    this.scorePaperId = paperId;
    this.staff = staff;
  }

  Widget getTitle(BuildContext context) {
    return new TabBar(
      controller: this.tabController,
      tabs: <Tab>[
        Tab(text: '题目'),
        Tab(text: '评分表'),
      ],
    );
  }

  Widget getBuild(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (backFlag) return true;
        if (commitScore == allScoreTotal) return true;
        var flag = await showConfirmAlert("您的打分未提交,是否退出?");
        return flag;
      },
      child: super.getBuild(context),
    );
  }

  getBody(context) {
    return TabBarView(
      controller: tabController,
      children: [
        Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                scorePaper["name"] != null ? scorePaper["name"] : "",
                style: TextStyle(fontSize: 25),
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 10,
              ),
              Expanded(
                flex: 1,
                child: Text(
                  scorePaper["description"] != null
                      ? "        ${scorePaper["description"]}"
                      : "",
                  style: TextStyle(fontSize: 15),
                  textAlign: TextAlign.start,
                ),
              ),
              Container(
                padding: EdgeInsets.fromLTRB(.0, 20.0, .0, 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: EdgeInsets.all(5.0),
                      color: ThemeColor.getColor("info"),
                      child: Text(
                        '考生: ' + showString(staff["name"]),
                        style: _style,
                      ),
                    ),
                    SizedBox(width: 20.0),
                    Container(
                      padding: EdgeInsets.all(5.0),
                      color: ThemeColor.getColor("success"),
                      child: Text(
                        '耗时: ' + _durationTransform(time),
                        style: _style,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Container(
          child: Column(
            children: [
              Container(
                color: ThemeColor.getColor("fontColor"),
                child: Row(
                  children: [
                    if (!fullFlag)
                      Container(
                        width: 80.0,
                        padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                        child: Text(
                          "评分项",
                          style:
                              TextStyle(color: ThemeColor.getColor("content")),
                        ),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(
                              width: 1, //宽度
                              color: ThemeColor.getColor("content"), //边框颜色
                            ),
                          ),
                        ),
                      ),
                    Expanded(
                      flex: 1,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                        child: Text(
                          "评分细则",
                          style:
                              TextStyle(color: ThemeColor.getColor("content")),
                        ),
                      ),
                    ),
                    Container(
                      width: 20 + buttonWidth * 3,
                      padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                      child: Text(
                        "评分",
                        style: TextStyle(color: ThemeColor.getColor("content")),
                      ),
                      decoration: BoxDecoration(
                        border: Border(
                          left: BorderSide(
                            width: 1, //宽度
                            color: ThemeColor.getColor("content"), //边框颜色
                          ),
                        ),
                      ),
                    ),
                    if (!fullFlag)
                      Container(
                        width: 70.0,
                        padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                        child: Text(
                          "备注",
                          style:
                              TextStyle(color: ThemeColor.getColor("content")),
                        ),
                        decoration: BoxDecoration(
                          border: Border(
                            left: BorderSide(
                              width: 1, //宽度
                              color: ThemeColor.getColor("content"), //边框颜色
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Row(
                  children: [
                    if (!fullFlag)
                      Container(
                        width: 79.0,
                        color: ThemeColor.getColor("content"),
                        child: ListView.builder(
                          itemBuilder: (context, int index) {
                            return _buildTitle(index);
                          },
                          itemCount: titleList.length,
                        ),
                      ),
                    Expanded(
                      flex: 1,
                      child: Container(
                        color: ThemeColor.getColor("data"),
                        child: ScrollablePositionedList.builder(
                          itemScrollController: listViewController,
                          itemPositionsListener: itemPositionsListener,
                          scrollDirection: Axis.vertical,
                          itemBuilder: (context, int index) {
                            return _buildItems(index);
                          },
                          itemCount: titleList.length,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  _buildTitle(int index) {
    return InkWell(
      child: titleIndex == index
          ? Container(
              padding: EdgeInsets.all(10.0),
              color: ThemeColor.getColor("data"),
              child: Text(titleList[index]["title"]),
            )
          : Container(
              padding: EdgeInsets.all(10.0),
              child: Text(titleList[index]["title"]),
            ),
      onTap: () {
        setState(() {
          this.titleIndex = index;
          listViewController.scrollTo(
              index: index,
              duration: Duration(seconds: 1),
              curve: Curves.easeInOutCubic);
        });
      },
    );
  }

  _buildItems(int index) {
    return Column(
      key: titleList[index]["key"],
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.all(5.0),
          color: ThemeColor.getColor("menu"),
          child: Text(
            "${titleList[index]["title"]} (${titleList[index]["scoreTotal"] % 1 == 0 ? Decimal.parse(titleList[index]["scoreTotal"].toString()).toBigInt() : titleList[index]["scoreTotal"]}分)",
            textAlign: TextAlign.start,
          ),
        ),
        Column(
          children:
              (scoreItems[titleList[index]["title"]] as List<dynamic>).map((s) {
            return Container(
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    width: 1, //宽度
                    color: ThemeColor.getColor("content"), //边框颜色
                  ),
                  left: BorderSide(
                    width: 1, //宽度
                    color: ThemeColor.getColor("content"), //边框颜色
                  ),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  if (!fullFlag)
                    Container(
                      padding: EdgeInsets.all(15.0),
                      width: 50,
                      child: Center(
                        child: Text(
                            "${(scoreItems[titleList[index]["title"]] as List<dynamic>).indexOf(s) + 1}"),
                      ),
                    ),
                  Expanded(
                    flex: 1,
                    child: Container(
                      constraints: BoxConstraints(minHeight: buttonHeight + 5),
                      padding: EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichSubText(
                              "${s["content"]}  (${(s["score"] % 1 == 0 ? (s["score"] as double).toInt() : s["score"])}分)"),
                          if (s["explanation"] != null &&
                              s["explanation"].toString().trim().length > 0)
                            Container(
                              margin: EdgeInsets.only(top: 5.0),
                              decoration: BoxDecoration(
                                color: ThemeColor.getColor("info"),
                                border: Border(
                                  bottom: BorderSide(
                                    width: 1, //宽度
                                    color:
                                        ThemeColor.getColor("content"), //边框颜色
                                  ),
                                  left: BorderSide(
                                    width: 1, //宽度
                                    color:
                                        ThemeColor.getColor("content"), //边框颜色
                                  ),
                                  top: BorderSide(
                                    width: 1, //宽度
                                    color:
                                        ThemeColor.getColor("content"), //边框颜色
                                  ),
                                  right: BorderSide(
                                    width: 1, //宽度
                                    color:
                                        ThemeColor.getColor("content"), //边框颜色
                                  ),
                                ),
                              ),
                              child: Text("${s["explanation"]}"),
                            ),
                        ],
                      ),
                      decoration: BoxDecoration(
                        border: Border(
                          right: BorderSide(
                            width: 1, //宽度
                            color: ThemeColor.getColor("content"), //边框颜色
                          ),
                          left: BorderSide(
                            width: 1, //宽度
                            color: ThemeColor.getColor("content"), //边框颜色
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 20 + buttonWidth * 3 - 1,
                    padding: EdgeInsets.all(1.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: buttonWidth,
                          height: buttonHeight,
                          padding: EdgeInsets.all(.0),
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            //设置四周边框
                            border: new Border.all(
                                width: 1,
                                color: ThemeColor.getColor("content")),
                          ),
                          child: OutlinedButton(
                            style: ButtonStyle(
                                overlayColor: MaterialStateProperty.all(
                                    ThemeColor.getColor("focus")),
                                padding: MaterialStateProperty.all(
                                    EdgeInsets.all(.0))),
                            child: Icon(
                              Icons.add,
                              size: 20,
                            ),
                            onPressed: () {
                              if (Decimal.parse(controllerMap[s["id"]].text) <
                                  Decimal.parse(s["score"].toString())) {
                                var num = (Decimal.parse(
                                        controllerMap[s["id"]].text) +
                                    Decimal.parse(s["step"].toString()));
                                controllerMap[s["id"]].text =
                                    (num.toDouble() % 1 == 0
                                            ? num.toBigInt()
                                            : num)
                                        .toString();
                                changeCommitScore();
                              } else {
                                showErrorToast(
                                    "最高可打${Decimal.parse(s["score"].toString())}分");
                              }
                            },
                          ),
                        ),
                        Container(
                          alignment: Alignment.center,
                          width: 40,
                          height: buttonHeight,
                          margin: EdgeInsets.only(left: 6.0, right: 6.0),
                          decoration: BoxDecoration(
                            color: ThemeColor.getColor("content"),
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            //设置四周边框
                            border: new Border.all(
                                width: 1,
                                color: ThemeColor.getColor("content")),
                          ),
                          child: TextField(
                            textAlign: TextAlign.center,
                            controller: controllerMap[s["id"]],
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.only(bottom: 13),
                            ),
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            keyboardType: TextInputType.numberWithOptions(
                                signed: true, decimal: true),
                            onChanged: (value) {
                              if (value == null) return;
                              if (Decimal.parse(value) <
                                  Decimal.parse(0.toString())) {
                                controllerMap[s["id"]].text = 0;
                              } else if (Decimal.parse(value) >
                                  Decimal.parse(s["score"].toString())) {
                                var score =
                                    Decimal.parse(s["score"].toString());
                                controllerMap[s["id"]].text =
                                    (score.toDouble() % 1 == 0
                                            ? score.toBigInt()
                                            : score.toDouble())
                                        .toString();
                              }
                              changeCommitScore();
                            },
                          ),
                        ),
                        Container(
                          width: buttonWidth,
                          height: buttonHeight,
                          padding: EdgeInsets.all(.0),
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            //设置四周边框
                            border: new Border.all(
                                width: 1,
                                color: ThemeColor.getColor("content")),
                          ),
                          child: OutlinedButton(
                            style: ButtonStyle(
                                overlayColor: MaterialStateProperty.all(
                                    ThemeColor.getColor("focus")),
                                padding: MaterialStateProperty.all(
                                    EdgeInsets.all(.0))),
                            child: Icon(
                              Icons.remove,
                              size: 20,
                            ),
                            onPressed: () {
                              if (s["score"].toString() == "0.0") {
                                if (Decimal.parse(controllerMap[s["id"]].text) >
                                    -Decimal.parse(
                                        s["limitScore"].toString())) {
                                  var num = (Decimal.parse(
                                          controllerMap[s["id"]].text) -
                                      Decimal.parse(s["step"].toString()));
                                  controllerMap[s["id"]].text =
                                      (num.toDouble() % 1 == 0
                                              ? num.toBigInt()
                                              : num)
                                          .toString();
                                  changeCommitScore();
                                } else {
                                  showErrorToast("最多扣${s["limitScore"]}分");
                                }
                                return;
                              }
                              if (Decimal.parse(controllerMap[s["id"]].text) >
                                  Decimal.parse("0")) {
                                var num = (Decimal.parse(
                                        controllerMap[s["id"]].text) -
                                    Decimal.parse(s["step"].toString()));
                                controllerMap[s["id"]].text =
                                    (num.toDouble() % 1 == 0
                                            ? num.toBigInt()
                                            : num)
                                        .toString();
                                commitScore =
                                    (Decimal.parse(commitScore.toString()) -
                                            Decimal.parse(s["step"].toString()))
                                        .toDouble();
                                setState(() {});
                              } else {
                                showErrorToast("最低可打0分");
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!fullFlag)
                    Container(
                      width: 70,
                      padding: EdgeInsets.all(15.0),
                      decoration: BoxDecoration(
                        border: Border(
                          left: BorderSide(
                            width: 1, //宽度
                            color: ThemeColor.getColor("content"), //边框颜色
                          ),
                        ),
                      ),
                      child: badges.Badge(
                        showBadge: remarks[s["id"]] != null,
                        child: IconButton(
                          tooltip: s["remark"] ?? "添加备注",
                          icon: Icon(s["remark"] != null
                              ? MdiIcons.unfoldMoreVertical
                              : Icons.more_horiz),
                          onPressed: () {
                            showPromptAlert(s["remark"] ?? "添加备注",
                                    value: remarks[s["id"]])
                                .then((v) {
                              if (v != false) {
                                remarks[s["id"]] = v;
                                setState(() {});
                              }
                            });
                          },
                        ),
                      ),
                    ),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  getBottom(content) {
    return Container(
      height: 65,
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            width: 1, //宽度
            color: ThemeColor.getColor("border"), //边框颜色
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            icon:
                Icon(fullFlag ? MdiIcons.fullscreen : MdiIcons.fullscreenExit),
            onPressed: () {
              setState(() {
                fullFlag = !fullFlag;
              });
            },
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: Text(
                "提交${commitScore % 1 == 0 ? (Decimal.parse(commitScore.toString())).toBigInt() : commitScore}/${(Decimal.parse(allScoreTotal.toString())).toBigInt()}分",
                style: TextStyle(fontSize: 20),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: SizedBox(
                width: MediaQuery.of(context).size.width / 2.5,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(
                        ThemeColor.getColor("success")),
                  ),
                  child: Text(
                    "提交成绩",
                    style: TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    showConfirmAlert("是否确定提交相关评分结果?").then((value) {
                      if (value) {
                        if (signFlag != true) {
                          commitScoreFunction(null);
                          return;
                        }
                        Navigator.push(
                          context,
                          new MaterialPageRoute(
                              builder: (context) => new SignatureComponent()),
                        ).then((value) {
                          if (value != null) {
                            uploadFile(file: value).then((value) {
                              commitScoreFunction(value);
                            });
                          }
                        });
                      }
                    });
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _durationTransform(int seconds) {
    var d = Duration(seconds: seconds);
    List<String> parts = d.toString().split(':');
    return '${Decimal.parse(parts[0])}:${Decimal.parse(parts[1])}:${Decimal.parse(parts[2])}';
  }

  @override
  void initState() {
    super.initState();
    var s = window.physicalSize;
    if (s.width >= 2000) {
      buttonWidth = 60.0;
      buttonHeight = 60.0;
    }
    judgmentMultiple();
    initTabController();
    getScorePaperView();
  }

  initTabController() {
    tabController = TabController(
      vsync: this, // 动画效果的异步处理
      length: 2, // tab 个数
      initialIndex: 1, // 起始位置
    );
  }

  getScorePaperView() {
    //获取评分试卷详情
    post("/scorepaper/getScorePaperView", {"id": scorePaperId}).then((value) {
      if (value["success"]) {
        var valData = value["data"];
        scorePaper = valData["scorePaper"];
        scoreItems = valData["groupNameMap"];
        titleList = valData["titleList"];
        this.titleList.forEach((element) {
          scoreItems[element["title"]].forEach((s) {
            if (s["typeCode"] == "scoreType_1") {
              controllerMap[s["id"]] = TextEditingController(text: "0");
            } else {
              controllerMap[s["id"]] = TextEditingController(
                  text: (s["score"] % 1 == 0
                          ? (s["score"] as double).toInt()
                          : s["score"])
                      .toString());
              changeCommitScore();
            }
          });
        });
        allScoreTotal =
            Decimal.parse(valData["allScoreTotal"].toString()).toDouble();
        loading = false;
        empty = false;
        if (MediaQuery.of(context).size.width < 550) {
          fullFlag = true;
        }
        setState(() {});
        startTimer();
      }
    }).catchError((error) {
      showConfirmAlert('获取试卷错误,信息:' + error["msg"] + ',是否重新获取?').then((value) {
        if (value) {
          //重新请求
          getScorePaperView();
        }
      });
    });
  }

  startTimer() {
    _timer?.cancel();
    _timer = null;
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      time++;
      if (tabController.index == 0) {
        setState(() {});
      }
    });
  }

  commitScoreFunction(String sign) async {
    setState(() {
      loading = true;
    });
    //提交信息
    dynamic data = {};
    List<dynamic> list = [];
    controllerMap.keys.forEach((key) {
      list.add({
        "scoreItemId": key,
        "score": controllerMap[key].text,
        "remark": remarks[key]
      });
    });
    //保存总分和提交分数
    data["item"] = list;
    data["score"] = commitScore;
    data["testId"] = examId;
    data["sign"] = sign;
    data["paperId"] = scorePaperId;
    data["evalStaffId"] = staff["id"];
    data["startDate"] = formatDate(
        startDate, [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    data["endDate"] = formatDate(
        DateTime.now(), [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    post("/simpletestscore/saveExamScore", data).then((res) {
      setState(() {
        loading = false;
      });
      if (res["success"]) {
        backFlag = true;
        showSuccessAlert("分数提交成功!").then((v) {
          Navigator.of(context).pop();
        });
      }
    });
  }

  // 判断是否可以多次填写
  judgmentMultiple() {
    if (multipleFlag == false) {
      post("/simpletestscore/getRecordCount", {
        "testId": examId,
        "paperId": scorePaperId,
        "studentId": staff["id"]
      }).then((res) {
        if (res["success"] && res["data"] > 0) {
          showErrorAlert("您已为当前学生评价,当前考试无法对相同考生进行多次评价,如有疑问请联系考务人员?")
              .then((value) {
            Navigator.of(context).pop();
          });
        }
      });
    }
  }

  changeCommitScore() {
    commitScore = 0;
    controllerMap.values.forEach((s) {
      commitScore =
          (Decimal.parse(commitScore.toString()) + Decimal.parse(s.text))
              .toDouble();
    });
    if (commitScore < 0) {
      commitScore = 0;
    }
    setState(() {});
  }

  @override
  void dispose() {
    _timer?.cancel();
    _timer = null;
    super.dispose();
  }
}
