import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class SimpleTestHistoryDetail extends BaseApp {
  final dynamic data;

  SimpleTestHistoryDetail(this.data);

  @override
  _SimpleTestHistoryDetailState createState() =>
      new _SimpleTestHistoryDetailState(this.data);
}

class _SimpleTestHistoryDetailState
    extends BaseAppPage<SimpleTestHistoryDetail> {
  dynamic row = {};

  _SimpleTestHistoryDetailState(dynamic data) {
    title = data["name"];
    row = data;
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      url: "/simpletestscore/getMyScoreHistory",
      searchText: "请输入姓名或胸牌",
      queryParams: {"testId": row["id"]},
      buildItem: (dynamic row, int i) {
        print(row);
        return Card(
          child: Column(
            children: [
              ListTile(
                title: Text("考生"),
                trailing: Text(row["name"]),
              ),
              ListTile(
                title: Text("胸牌号"),
                trailing: Text(row["serialNo"]),
              ),
              ListTile(
                title: Text("考题"),
                trailing: Text(row["paperName"]),
              ),
              ListTile(
                title: Text("得分"),
                trailing: Text(showString(row["score"])),
              ),
              ListTile(
                title: Text("评分时间"),
                trailing: Text(showString(row["created"])),
              ),
            ],
          ),
        );
      },
    );
  }
}
