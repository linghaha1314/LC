import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class AnswerResultPage extends BaseApp {
  @override
  _AnswerResultPageState createState() => _AnswerResultPageState();
}

class _AnswerResultPageState extends BaseAppPage<AnswerResultPage> {
  @override
  initRouteSuccess() {
    title = "考试结果";
    get("/examanswer/findById/${routeData["resultId"]}").then((res) {
      if (res["success"]) {
        empty = false;
        routeData = res["data"];
        setState(() {});
      }
    });
  }

  @override
  Widget getBody(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("人员: ${routeData["staffName"]}"),
          SizedBox(height: 20),
          Text("试卷: ${routeData["volumeName"]}"),
          SizedBox(height: 20),
          Text("开始时间: ${routeData["startDate"]}"),
          SizedBox(height: 20),
          Text("结束时间: ${routeData["endDate"]}"),
          SizedBox(height: 20),
          Text("得分: ${routeData["score"]}"),
          SizedBox(height: 20),
          Text("总分: ${routeData["totalScore"]}"),
          SizedBox(height: 20),
          Text("客户端: ${routeData["client"]}"),
          SizedBox(height: 20),
          Text("ip地址: ${routeData["ip"]}"),
        ],
      ),
    );
  }
}
