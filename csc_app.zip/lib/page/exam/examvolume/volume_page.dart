import 'dart:io';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart' as help;
import 'package:device_info/device_info.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

class VolumePage extends BaseApp {
  @override
  _VolumePageState createState() => _VolumePageState();
}

class _VolumePageState extends BaseAppPage<VolumePage> {
  var _cardFlag = false;
  String _proportion = "";
  List<dynamic> rows = [];

  String now;

  var canExit = false;

  final ItemScrollController itemScrollController = ItemScrollController();

  _VolumePageState() {
    now = DateTime.now().toString();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  initRouteSuccess() {
    loading = true;
    title = "开始考试";
    setState(() {});
    getDataVolume(routeData["volumeId"]);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        var exitFlag = true;
        rows.forEach((r) {
          if (r["value"] != null) {
            exitFlag = false;
          }
        });
        if (!canExit && !exitFlag) {
          showConfirmAlert("退出不会保存已答题内容,是否继续?").then((value) {
            if (value) {
              canExit = true;
              Navigator.of(context).pop();
            }
          });
          return false;
        }
        return true;
      },
      child: super.build(context),
    );
  }

  @override
  Widget getBuild(BuildContext context) {
    getProportion();
    return Scaffold(
      appBar: getAppBar(context),
      body: getBody(context),
      bottomNavigationBar: getBottomBart(),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    int index = 0;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Visibility(
          visible: _cardFlag,
          child: Material(
            elevation: 4.0,
            child: Container(
              color: ThemeColor.getColor("console"),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: rows.map((row) {
                    row["i"] = index;
                    int i = 0;
                    index++;
                    if (row["examQuestion"]["inputCode"] == "input_radio") {
                      return Row(
                        children: [
                          Container(
                            padding: EdgeInsets.fromLTRB(5.0, .0, 5.0, .0),
                            child: Text("${row["index"]}."),
                          ),
                          ...(row["examOptionList"] as List<dynamic>).map((o) {
                            i++;
                            return InkWell(
                              child: Container(
                                padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
                                child: row["value"] == o["id"]
                                    ? Container(
                                        width: 25.0,
                                        height: 25.0,
                                        margin: EdgeInsets.fromLTRB(
                                            .0, .0, 5.0, .0),
                                        decoration: new BoxDecoration(
                                          color: ThemeColor.getColor("focus"),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(25.0)),
                                          border: new Border.all(
                                              width: 1,
                                              color:
                                                  ThemeColor.getColor("focus")),
                                        ),
                                        child: Center(
                                          child: Icon(
                                            MdiIcons.checkBold,
                                            color:
                                                ThemeColor.getColor("content"),
                                            size: 18,
                                          ),
                                        ),
                                      )
                                    : Container(
                                        width: 25.0,
                                        height: 25.0,
                                        margin: EdgeInsets.fromLTRB(
                                            .0, .0, 5.0, .0),
                                        decoration: new BoxDecoration(
                                          color: ThemeColor.getColor("console"),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(25.0)),
                                          border: new Border.all(
                                              width: 1,
                                              color: ThemeColor.getColor(
                                                  "border")),
                                        ),
                                        child: Center(
                                          child: Text(getChar(i)),
                                        ),
                                      ),
                              ),
                              onTap: () {
                                itemScrollController.jumpTo(index: row["i"]);
                                setState(() {
                                  row["value"] = o["id"];
                                });
                              },
                            );
                          }).toList(),
                        ],
                      );
                    } else if (row["examQuestion"]["inputCode"] ==
                        "input_check") {
                      return Row(
                        children: [
                          Container(
                            padding: EdgeInsets.fromLTRB(5.0, .0, 5.0, .0),
                            child: Text("${row["index"]}."),
                          ),
                          ...(row["examOptionList"] as List<dynamic>).map((o) {
                            i++;
                            return InkWell(
                              child: Container(
                                padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
                                child: ((row["value"] != null
                                                ? row["value"]
                                                : "") as String)
                                            .indexOf(o["id"]) >
                                        -1
                                    ? Container(
                                        width: 25.0,
                                        height: 25.0,
                                        margin: EdgeInsets.fromLTRB(
                                            .0, .0, 5.0, .0),
                                        decoration: new BoxDecoration(
                                          color: ThemeColor.getColor("focus"),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(5.0)),
                                          border: new Border.all(
                                              width: 1,
                                              color:
                                                  ThemeColor.getColor("focus")),
                                        ),
                                        child: Center(
                                          child: Icon(
                                            MdiIcons.checkBold,
                                            color:
                                                ThemeColor.getColor("content"),
                                            size: 18,
                                          ),
                                        ),
                                      )
                                    : Container(
                                        width: 25.0,
                                        height: 25.0,
                                        margin: EdgeInsets.fromLTRB(
                                            .0, .0, 5.0, .0),
                                        decoration: new BoxDecoration(
                                          color: ThemeColor.getColor("console"),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(5.0)),
                                          border: new Border.all(
                                              width: 1,
                                              color: ThemeColor.getColor(
                                                  "border")),
                                        ),
                                        child: Center(
                                          child: Text(getChar(i)),
                                        ),
                                      ),
                              ),
                              onTap: () {
                                itemScrollController.jumpTo(index: row["i"]);
                                List<String> list =
                                        (row["value"] as String).split(","),
                                    values = [];
                                if (row["value"] == "") values.add(o["id"]);
                                bool flag =
                                    (row["value"] as String).indexOf(o["id"]) >
                                        -1;
                                if (flag) {
                                  list.forEach((l) {
                                    if (l != "" && l != o["id"]) {
                                      values.add(l);
                                    }
                                  });
                                } else {
                                  values.addAll(list);
                                  values.add(o["id"]);
                                }
                                setState(() {
                                  row["value"] = values.join(",");
                                });
                              },
                            );
                          }).toList(),
                        ],
                      );
                    }
                    return Container();
                  }).toList(),
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: Column(
            children: [
              Expanded(
                child: ScrollablePositionedList.builder(
                  padding: EdgeInsets.fromLTRB(10.0, .0, 35.0, .0),
                  itemCount: rows.length,
                  itemScrollController: itemScrollController,
                  itemBuilder: (c, i) {
                    return _buildRow(i);
                  },
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget getBottomBart() {
    return Container(
      height: 55,
      decoration: BoxDecoration(
        color: ThemeColor.getColor("data"),
        border: Border(
          top: BorderSide(
            width: 1, //宽度
            color: ThemeColor.getColor("content"), //边框颜色
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            child: Center(
              child: IconButton(
                icon: Icon(_cardFlag
                    ? MdiIcons.arrowLeftBoldOutline
                    : MdiIcons.arrowRightBoldOutline),
                onPressed: () {
                  setState(() {
                    _cardFlag = !_cardFlag;
                  });
                },
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: Text(
                _proportion,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: Container(
                height: 45.0,
                width: MediaQuery.of(context).size.width / 2.5,
                child: OutlinedButton.icon(
                  label: Text(
                    "提交答卷",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  icon: Icon(Icons.check),
                  onPressed: () {
                    showConfirmAlert("确认提交考试结果吗?").then((v) {
                      if (v) {
                        commitScoreFunction();
                      }
                    });
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(int i) {
    dynamic r = rows[i];
    print(r);
    String title = "${r["examQuestion"]["name"]} ";
    if (r["examQuestion"]["score"] != null) {
      title = title + ("${(r["examQuestion"]["score"] as double).toInt()}分");
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (i == 0)
          SizedBox(
            child: Center(
              child: Container(
                margin: EdgeInsets.all(10.0),
                child: Text(
                  routeData["volumeName"],
                  style: TextStyle(fontSize: 30),
                ),
              ),
            ),
          ),
        if (r["examQuestion"]["inputCode"] == "input_sub")
          Container(
            padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
            child: Center(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 22.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          )
        else if (r["examQuestion"]["inputCode"] == "input_big")
          Container(
            padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                HtmlWidget(
                  title,
                  textStyle: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: (r['attachs'] as List<dynamic>).map((e) {
                    return Container(
                      padding: EdgeInsets.all(5.0),
                      child: Center(
                        child: ExtendedImage.network(
                          e,
                          width: 400,
                          fit: BoxFit.contain,
                          cache: true,
                          mode: ExtendedImageMode.gesture,
                          initGestureConfigHandler: (state) {
                            return GestureConfig(
                              minScale: 2.9,
                              animationMinScale: 0.7,
                              maxScale: 3.0,
                              animationMaxScale: 3.5,
                              speed: 1.0,
                              inertialSpeed: 100.0,
                              initialScale: 1.0,
                              inPageView: false,
                              initialAlignment: InitialAlignment.center,
                            );
                          },
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          )
        else
          Container(
            padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                HtmlWidget(
                  "${r['index']}." + title,
                  textStyle: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: (r['attachs'] as List<dynamic>).map((e) {
                    return Container(
                      padding: EdgeInsets.all(5.0),
                      child: Center(
                        child: ExtendedImage.network(
                          e,
                          fit: BoxFit.contain,
                          cache: true,
                          mode: ExtendedImageMode.gesture,
                          initGestureConfigHandler: (state) {
                            return GestureConfig(
                              minScale: 0.9,
                              animationMinScale: 0.7,
                              maxScale: 3.0,
                              animationMaxScale: 3.5,
                              speed: 1.0,
                              inertialSpeed: 100.0,
                              initialScale: 1.0,
                              inPageView: false,
                              initialAlignment: InitialAlignment.center,
                            );
                          },
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        if (r["examQuestion"]["inputCode"] == "input_radio")
          _buildRadio(r)
        else if (r["examQuestion"]["inputCode"] == "input_check")
          _buildCheck(r)
        else if (r["examQuestion"]["inputCode"] == "input_fill_blank" ||
            r["examQuestion"]["inputCode"] == "input_short_answer")
          _buildText(r)
      ],
    );
  }

  Widget _buildRadio(dynamic row) {
    List<dynamic> options = row["examOptionList"];
    var i = 0;
    return Column(
      children: options.map((o) {
        i++;
        return Container(
          padding: EdgeInsets.all(2.0),
          child: TextButton(
            child: Container(
              padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
              child: Row(
                children: [
                  row["value"] == o["id"]
                      ? Container(
                          width: 25.0,
                          height: 25.0,
                          margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                          decoration: new BoxDecoration(
                            color: ThemeColor.getColor("focus"),
                            borderRadius:
                                BorderRadius.all(Radius.circular(25.0)),
                            border: new Border.all(
                                width: 1, color: ThemeColor.getColor("focus")),
                          ),
                          child: Center(
                            child: Icon(
                              MdiIcons.checkBold,
                              color: ThemeColor.getColor("content"),
                              size: 18,
                            ),
                          ),
                        )
                      : Container(
                          width: 25.0,
                          height: 25.0,
                          margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                          decoration: new BoxDecoration(
                            color: ThemeColor.getColor("console"),
                            borderRadius:
                                BorderRadius.all(Radius.circular(25.0)),
                            border: new Border.all(
                                width: 1, color: ThemeColor.getColor("border")),
                          ),
                          child: Center(
                            child: Text(getChar(i)),
                          ),
                        ),
                  Expanded(
                    flex: 1,
                    child: HtmlWidget(o["name"]),
                  ),
                ],
              ),
            ),
            onPressed: () {
              setState(() {
                row["value"] = o["id"];
              });
            },
          ),
        );
      }).toList(),
    );
  }

  Widget _buildCheck(dynamic row) {
    List<dynamic> options = row["examOptionList"];
    var i = 0;
    return Column(
      children: options.map((o) {
        i++;
        return Container(
          padding: EdgeInsets.all(2.0),
          child: TextButton(
            child: Container(
              padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
              child: Row(
                children: [
                  ((row["value"] != null ? row["value"] : "") as String)
                              .indexOf(o["id"]) >
                          -1
                      ? Container(
                          width: 25.0,
                          height: 25.0,
                          margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                          decoration: new BoxDecoration(
                            color: ThemeColor.getColor("focus"),
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            border: new Border.all(
                                width: 1, color: ThemeColor.getColor("focus")),
                          ),
                          child: Center(
                            child: Icon(
                              MdiIcons.checkBold,
                              color: ThemeColor.getColor("content"),
                              size: 18,
                            ),
                          ),
                        )
                      : Container(
                          width: 25.0,
                          height: 25.0,
                          margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                          decoration: new BoxDecoration(
                            color: ThemeColor.getColor("console"),
                            borderRadius:
                                BorderRadius.all(Radius.circular(5.0)),
                            border: new Border.all(
                                width: 1, color: ThemeColor.getColor("border")),
                          ),
                          child: Center(
                            child: Text(getChar(i)),
                          ),
                        ),
                  Expanded(
                    flex: 1,
                    child: HtmlWidget(o["name"]),
                  ),
                ],
              ),
            ),
            onPressed: () {
              List<String> list =
                      ((row["value"] != null ? row["value"] : "") as String)
                          .split(","),
                  values = [];
              if (row["value"] == "") values.add(o["id"]);
              bool flag = ((row["value"] != null ? row["value"] : "") as String)
                      .indexOf(o["id"]) >
                  -1;
              if (flag) {
                list.forEach((l) {
                  if (l != "" && l != o["id"]) {
                    values.add(l);
                  }
                });
              } else {
                values.addAll(list);
                values.add(o["id"]);
              }
              setState(() {
                row["value"] = values.join(",");
              });
            },
          ),
        );
      }).toList(),
    );
  }

  Widget _buildText(dynamic row) {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: TextFormField(
        maxLines: 5,
        minLines: 1,
        onChanged: (v) {
          setState(() {
            row["value"] = v.trim();
          });
        },
        decoration: InputDecoration(
          hintText: '输入答案',
          contentPadding: const EdgeInsets.symmetric(vertical: 10.0),
        ),
      ),
    );
  }

  String getChar(int i) {
    return 'abcdefghijklmnopqrstuvwxyz'
        .characters
        .characterAt(i - 1)
        .string
        .toUpperCase();
  }

  getProportion() {
    int index = 0;
    rows.forEach((e) {
      if (e["value"] != null && e["value"].length > 0) {
        index++;
      }
    });
    _proportion = "已答题数: $index/${rows.length != 0 ? rows.last["index"] : 0}";
  }

  getDataVolume(String volumeId) {
    help.post(
      "/examquestion/listQueryByVolumeId",
      {"volumeId": volumeId},
    ).then((value) {
      if (value["success"]) {
        List<dynamic> list = value["data"];
        int index = 0;
        help.getHttpPath().then((p) {
          list.forEach((r) {
            r["value"] = "";
            if (r["examQuestion"]["inputCode"] != "input_sub" &&
                r["examQuestion"]["inputCode"] != "input_big") {
              index++;
            }
            r["value"] = null;
            r["index"] = index;
            String attach = r["examQuestion"]["attach"] as String;
            if (attach != null && attach.length > 0) {
              r["attachs"] = attach.split(",").map((e) => p + e).toList();
            } else {
              r["attachs"] = [];
            }
          });
          setState(() {
            rows = list;
            loading = false;
          });
        });
      }
    });
  }

  commitScoreFunction() async {
    //验证是否都已提交完
    var fullFlag = true;
    rows.forEach((r) {
      if (r["value"] == null) {
        fullFlag = false;
      }
    });
    if (!fullFlag) {
      showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("警告"),
            content: Text("您的试卷未填写完，请问是否提交！"),
            actions: <Widget>[
              new TextButton(
                child: new Text('取消'),
                onPressed: () {
                  Navigator.of(context).pop(); //关闭弹框
                },
              ),
              new TextButton(
                child: new Text('确定'),
                onPressed: () {
                  Navigator.of(context).pop();
                  commitAll(); //关闭弹框
                },
              )
            ],
          );
        },
      );
    } else {
      commitAll();
    }
  }

  commitAll() async {
    setState(() {
      loading = true;
    });
    List<dynamic> list = [];
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    String client = "other";
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      client = androidInfo.device;
    }
    if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      client = iosInfo.name;
    }

    dynamic examAnswer = {
      "startDate": now,
      "endDate": DateTime.now().toString(),
      "client": client,
      "planId": routeData["planId"],
      "volumeId": routeData["volumeId"],
    };
    rows.forEach((r) {
      print(r);
      print(r["value"]);
      if (r["examOptionList"] != null) {
        list.add({
          "questionId": r["examQuestion"]["volumeQuestionId"],
          "optionId": r["value"]
        });
      } else {
        list.add({
          "questionId": r["examQuestion"]["volumeQuestionId"],
          "answerText": r["value"]
        });
      }
    });
    help.post("/examanswer/updateDto",
        {"examAnswer": examAnswer, "answerResultList": list}).then((res) {
      if (res["success"]) {
        showSuccessToast(res["val"]);
        Navigator.pop(context, res["data"]);
      } else {
        setState(() {
          loading = false;
        });
        showErrorToast("提交失败,请重新提交!");
      }
    });
  }
}
