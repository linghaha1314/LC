import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../../ThemeColor.dart';

class MineExamPage extends BaseApp {
  @override
  _MineExamPageState createState() => _MineExamPageState();
}

class _MineExamPageState extends BaseAppPage<MineExamPage> {
  RefreshController _controller;

  _MineExamPageState() {
    title = '我的考试';
    empty = false;
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    _controller = RefreshController(initialRefresh: true);
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      searchText: "请输入安排名称进行搜索",
      controller: _controller,
      url: "/examplan/listMyPlan",
      buildItem: (dynamic row, int i) {
        return ListTile(
          title: Text("${row["name"]}"),
          subtitle: Text("${row["startDate"]} 至 ${row["endDate"]}"),
          trailing: Chip(
            backgroundColor: ThemeColor.getColor(
                row["answerId"] == null ? "warning" : "success"),
            label: Text(row["answerId"] == null ? "未考试" : "已考试"),
          ),
          onTap: () {
            if (row["answerId"] == null) {
              DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm");
              var now = DateTime.now().millisecondsSinceEpoch;
              if (now >=
                      dateFormat
                          .parse(row["startDate"])
                          .millisecondsSinceEpoch &&
                  now <=
                      dateFormat.parse(row["endDate"]).millisecondsSinceEpoch) {
                Navigator.pushNamed(context, "volume", arguments: {
                  "volumeId": row["volumeId"],
                  "volumeName": row["volumeName"],
                  "planId": row["id"],
                }).then((value) {
                  if (value != null) {
                    _controller.requestRefresh();
                  }
                });
              } else {
                showErrorToast("考试时间不匹配!");
              }
            } else {
              if (row["scoreFlag"]) {
                Navigator.pushNamed(context, "volumeResult",
                    arguments: {"resultId": row["answerId"]});
              } else {
                showInfoToast("不允许查看考试结果!");
              }
            }
          },
        );
      },
    );
  }
}
