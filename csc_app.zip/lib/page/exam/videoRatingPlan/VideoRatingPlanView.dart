import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:chewie/chewie.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:video_player/video_player.dart';

class VideoRatingPlanView extends BaseApp {
  final Map data;

  VideoRatingPlanView(this.data) : super();

  @override
  _VideoRatingPlanViewState createState() =>
      new _VideoRatingPlanViewState(data);
}

class _VideoRatingPlanViewState extends BaseAppPage<_VideoRatingPlanViewState>
    with SingleTickerProviderStateMixin {
  dynamic data;
  double aspectRatio = 16 / 9;
  Map itemVoicePlayerMap = {};
  VideoPlayerController _videoPlayerController;
  ChewieController _chewieController;
  TabController tabController;
  RefreshController timelineController =
      RefreshController(initialRefresh: true);
  RefreshController scoreRecordController =
      RefreshController(initialRefresh: true);

  _VideoRatingPlanViewState(data) {
    this.data = data;
    title = "评分详情";
  }

  @override
  void initState() {
    initTabController();
    initializePlayer();
    super.initState();
    empty = false;
  }

  initializePlayer() async {
    var basePath = await getHttpPath();
    _videoPlayerController =
        VideoPlayerController.network('$basePath${data["attach"]}');
    await _videoPlayerController.initialize();
    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController,
      aspectRatio: aspectRatio,
      autoPlay: false, //自动播放
      looping: false, //循环播放
    );
    setState(() {});
  }

  initTabController() {
    tabController = TabController(
        vsync: this, // 动画效果的异步处理
        length: 2, // tab 个数
        initialIndex: 0 // 起始位置
        );
  }

  @override
  Widget getBody(BuildContext context) {
    if (_chewieController == null) {
      return loadingWidget;
    }
    double playerHeight = MediaQuery.of(context).size.width / aspectRatio;
    double tabHeight = MediaQuery.of(context).size.height - playerHeight - 128;

    return Column(
      children: <Widget>[
        SizedBox(
          height: playerHeight,
          child: Chewie(
            controller: _chewieController,
          ),
        ),
        Container(
          child: Column(
            children: [
              TabBar(
                controller: this.tabController,
                tabs: <Tab>[
                  Tab(text: '评价时间轴'),
                  Tab(text: '评分详情'),
                ],
              ),
              SizedBox(
                height: tabHeight,
                child: TabBarView(
                  controller: tabController,
                  children: [
                    RefreshList(
                      controller: timelineController,
                      url: "/videocommentdetail/listQueryByPage",
                      queryParams: {"commentId": data["commentId"]},
                      refreshBefore: () {
                        if (itemVoicePlayerMap.isNotEmpty) {
                          print("12312312312");
                          disposePlayerMap();
                        }
                      },
                      buildItem: (dynamic row, int i) {
                        if (itemVoicePlayerMap[row["id"]] == null) {
                          row["voiceStatus"] = "waitPlay";
                          row["icon"] = Icon(Icons.play_circle_filled);
                          itemVoicePlayerMap[row["id"]] = row;
                        }
                        return _buildTimeline(itemVoicePlayerMap[row["id"]]);
                      },
                    ),
                    RefreshList(
                      controller: scoreRecordController,
                      url: "/recorditem/listContentGroup",
                      queryParams: {"scoreId": data["recordId"]},
                      buildItem: (dynamic row, int i) {
                        return _buildScoreRecord(row, i + 1);
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  _buildTimeline(data) {
    return ListTile(
      title: Row(
        children: [
          Text('时间: ' + getTimeData(data["time"])),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Visibility(
            visible: data["comment"] != null,
            child: Text('文字评价: ${data["comment"]}'),
          ),
          Visibility(
            visible: data["voice"] != null,
            child: _voicePlayerView(data),
          ),
        ],
      ),
      isThreeLine: false,
      onTap: () {},
    );
  }

  _voicePlayerView(data) {
    return Row(
      children: [
        Text('语音评价:'),
        SizedBox(
          width: 10,
        ),
        IconButton(
          icon: data["icon"],
          tooltip: '播放/暂停',
          onPressed: () {
            if (data["voiceStatus"] == "waitPlay") {
              voicePlay(data);
            } else {
              voicePause(data);
            }
          },
        ),
      ],
    );
  }

  voicePlay(data) async {
    VideoPlayerController voicePlayerController = data["voicePlayerController"];
    if (voicePlayerController == null) {
      var basePath = await getHttpPath();
      voicePlayerController =
          VideoPlayerController.network('$basePath${data["voice"]}');
      await voicePlayerController.initialize();
    }
    itemVoicePlayerMap.forEach((key, value) {
      value["icon"] = Icon(Icons.play_circle_filled);
    });
    _videoPlayerController.seekTo(new Duration(seconds: data["time"]));
    voicePlayerController.play();
    data["voiceStatus"] = "waitPause";
    data["voicePlayerController"] = voicePlayerController;
    data["icon"] = Icon(Icons.pause_circle_filled);
    itemVoicePlayerMap[data["id"]] = data;
    setState(() {});
  }

  voicePause(data) {
    VideoPlayerController voicePlayerController = data["voicePlayerController"];
    if (voicePlayerController != null) {
      voicePlayerController.pause();
    }
    data["voiceStatus"] = "waitPlay";
    data["icon"] = Icon(Icons.play_circle_filled);
    setState(() {});
  }

  _buildScoreRecord(row, i) {
    return Container(
      padding: EdgeInsets.fromLTRB(5.0, .0, 5.0, 5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${row["first"]}',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400)),
          ..._contentListView(row["second"])
        ],
      ),
    );
  }

  List<Widget> _contentListView(List list) {
    List<Widget> tabViewList = [];
    list.forEach((item) {
      var index = list.indexOf(item) + 1;
      tabViewList.add(
        Container(
          padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 280,
                child:
                    Text('$index.${item["content"]} (${item["totalScore"]}分)'),
              ),
              Text('${item["score"]}')
            ],
          ),
        ),
      );
    });
    return tabViewList;
  }

  getTimeData(time) {
    var timeNum = time.round();
    var minuteNum = double.parse((timeNum / 60).toString()).toInt();
    var secondNum = timeNum - 60 * minuteNum;
    var minute = minuteNum.toString();
    var second = secondNum.toString();
    if (minuteNum < 10) {
      minute = "0$minuteNum";
    }
    if (secondNum < 10) {
      second = "0$secondNum";
    }
    return "$minute分$second秒";
  }

  disposePlayerMap() {
    if (itemVoicePlayerMap != null && itemVoicePlayerMap.isNotEmpty) {
      itemVoicePlayerMap.forEach((key, value) {
        VideoPlayerController voicePlayerController =
            value["voicePlayerController"];
        if (voicePlayerController != null) {
          voicePlayerController.dispose();
          voicePlayerController = null;
        }
      });
    }
    itemVoicePlayerMap = {};
  }

  @override
  void dispose() {
    disposePlayerMap();
    _chewieController.dispose();
    _chewieController = null;
    _videoPlayerController.dispose();
    _videoPlayerController = null;
    super.dispose();
  }
}
