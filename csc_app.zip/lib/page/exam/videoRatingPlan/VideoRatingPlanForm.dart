import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:date_format/date_format.dart';

import '../../../ThemeColor.dart';

class VideoRatingPlanForm extends BaseApp {
  final dynamic data;

  VideoRatingPlanForm(this.data);

  @override
  _VideoRatingPlanFormState createState() =>
      new _VideoRatingPlanFormState(this.data);
}

class _VideoRatingPlanFormState extends BaseAppPage {
  dynamic data;

  _VideoRatingPlanFormState(this.data);

  @override
  void initState() {
    super.initState();
    empty = false;
    title = "视频评价安排详情";
    if (data != null) {}
  }

  @override
  Widget getBody(BuildContext context) {
    return Scrollbar(
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
                alignment: Alignment.topLeft,
                child: Text(
                  "基本信息",
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                  textAlign: TextAlign.left,
                ),
              ),
              Card(
                child: Container(
                  alignment: Alignment.topLeft,
                  padding: EdgeInsets.all(15),
                  child: Column(
                    children: ListTile.divideTiles(
                      color: ThemeColor.getColor("border"),
                      tiles: [
                        _textView("计划名称", data["planName"].toString()),
                        Divider(),
                        _textView("试卷名称", data["scorePaperName"].toString()),
                        Divider(),
                        _textView("开始时间",
                            data["startDate"].toString().substring(0, 10)),
                        Divider(),
                        _textView("结束时间",
                            data["endDate"].toString().substring(0, 10)),
                        ListTile(
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("视频"),
                              Row(
                                children: [
                                  Visibility(
                                    visible: data["attach"] == null,
                                    child: MaterialButton(
                                      child: Text("上传"),
                                      onPressed: () async {
                                        var url = await uploadFile(
                                            title: "视频上传中", type: FileType.any);
                                        if (url == null) {
                                          return;
                                        }
                                        updateFiled(data["id"], url);
                                      },
                                    ),
                                  ),
                                  Visibility(
                                    visible: data["attach"] != null,
                                    child: Text(
                                      "已上传",
                                      style: TextStyle(fontSize: 14),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ).toList(),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  _textView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 14),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  updateFiled(id, attach) {
    var params = {
      "id": data["id"],
      "attach": attach,
      "uploadDate": formatDate(
          DateTime.now(), [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss])
    };
    setState(() {
      loading = true;
    });
    post("/videoplanstudent/updateField", params).then((res) {
      if (res["success"]) {
        setState(() {
          data["attach"] = attach;
          loading = false;
        });
        showSuccessToast("上传视频成功！");
      }
    }).catchError((err) {
      setState(() {
        loading = false;
      });
      showErrorToast(err["msg"]);
    });
  }
}
