import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import 'VideoRatingPlanForm.dart';
import 'VideoRatingPlanView.dart';

class VideoRatingPlanPage extends BaseApp {
  @override
  _VideoRatingPlanPageState createState() => new _VideoRatingPlanPageState();
}

class _VideoRatingPlanPageState extends BaseAppPage<VideoRatingPlanPage> {
  RefreshController recordController = RefreshController(initialRefresh: true);
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();

  _VideoRatingPlanPageState() {
    title = "视频评分安排";
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      controller: recordController,
      searchText: "请输入计划名称进行搜索",
      url: "/videoplanstudent/listQueryByPage",
      queryKey: "evalStaffName",
      queryParams: {"currentStaff": "Y"},
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  Widget _bodyContentOne(data) {
    return ListTile(
      title: Text("计划名称：" + data["planName"]),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text("评分问卷：" + data["scorePaperName"]),
          Text("开始日期：" + data["startDate"].toString().substring(0, 10)),
          Text("结束日期：" + data["endDate"].toString().substring(0, 10)),
          Visibility(
            visible: data["attach"] == null,
            child: Text("状态：未上传视频"),
          ),
          Visibility(
            visible: data["attach"] != null && data["commentId"] == null,
            child: Text("状态：已上传视频"),
          ),
          Visibility(
            visible: data["attach"] != null && data["commentId"] != null,
            child: Text("状态：已评价"),
          )
        ],
      ),
      onTap: () {
        if (data["commentId"] != null) {
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new VideoRatingPlanView(data)),
          ).then((value) {
            if (value != null && value) {
              recordController.requestRefresh();
            }
          });
        } else {
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new VideoRatingPlanForm(data)),
          ).then((value) {
            if (value != null && value) {
              recordController.requestRefresh();
            }
          });
        }
      },
    );
  }
}
