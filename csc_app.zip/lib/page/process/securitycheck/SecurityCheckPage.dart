import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:csc_app/page/process/securitycheck/CheckRecordForm.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class SecurityCheckPage extends BaseApp {
  @override
  _SecurityCheckPageState createState() => new _SecurityCheckPageState();
}

class _SecurityCheckPageState extends BaseAppPage<SecurityCheckPage>
    with SingleTickerProviderStateMixin {
  _SecurityCheckPageState() {
    title = "安全检查模板列表";
  }

  dynamic params;
  var tabController;
  List<dynamic> list = [];

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: [
        RefreshList(
          searchText: "请输入名称进行搜索",
          url: "/checktemplate/listQueryByPage",
          buildItem: (dynamic row, int i) {
            return ListTile(
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [Text('${row["name"]}')],
              ),
              subtitle: Text('类型: ${row["typeName"]}   创建人：${row["userName"]}'),
              onTap: () {
                //判断编辑模式
                if (row["editFlag"] == 1) {
                  showModalBottomSheet(
                    context: context,
                    builder: (BuildContext context) {
                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: row["attachs"].toString().split(",").map((e) {
                          return ListTile(
                            title: Text(e.substring(e.lastIndexOf("/") + 1)),
                            onTap: () async {
                              String path = await getHttpPath();
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => WebViewPage(
                                        url: "$path/office.html?url=$e")),
                              );
                            },
                          );
                        }).toList(),
                      );
                    },
                  );
                } else {
                  //跳转到模板记录页
                  Navigator.push(
                    context,
                    new MaterialPageRoute(
                        builder: (context) =>
                            new CheckRecordForm({"templateId": row["id"]})),
                  );
                }
              },
            );
          },
        ),
        RefreshList(
          searchText: "请输入名称进行搜索",
          url: "/checkrecord/listQueryByPage",
          buildItem: (dynamic row, int i) {
            return ListTile(
              title: Row(
                children: [
                  Text('检查名称: ${row["name"]}'),
                ],
              ),
              subtitle: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('检查类型: ${row["typeName"]}'),
                  Text('模板名称：${row["templateName"]}'),
                ],
              ),
              onTap: () {
                //跳转到模板记录页
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => new CheckRecordForm(row)),
                );
              },
            );
          },
        )
      ],
    );
  }

  initTabController() {
    tabController = TabController(
        vsync: this, // 动画效果的异步处理
        length: 2, // tab 个数
        initialIndex: 0 // 起始位置
        );
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
          controller: this.tabController,
          tabs: <Tab>[
            Tab(text: '可填写模板列表'),
            Tab(text: '已填写模板列表'),
          ],
        ),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  @override
  void initState() {
    super.initState();
    initTabController();
  }

  @override
  void dispose() {
    this.tabController.dispose();
    super.dispose();
  }
}
