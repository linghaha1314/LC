import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';

import '../../../ThemeColor.dart';

class CheckRecordForm extends BaseApp {
  final Map data;

  CheckRecordForm(this.data) : super();

  @override
  _CheckRecordFormState createState() => new _CheckRecordFormState(data);
}

class _CheckRecordFormState extends BaseAppPage<CheckRecordForm> {
  dynamic data;

  _CheckRecordFormState(this.data) {
    title = "检查记录";
  }

  List<dynamic> list = [];
  List<dynamic> dataList = [];
  List<dynamic> checkRecord = [];
  List<Map<String, dynamic>> addForm = [];
  List<dynamic> typeList = [];
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  Map<String, GlobalKey> textKey = {};
  Map<String, TextEditingController> textController = {};
  FocusNode focusNode1 = new FocusNode();
  double length = 120.0;
  int extraNumber = 0;

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      ElevatedButton(
        onPressed: () {
          //检查是否填写完成
          var insertFlag = false;
          List<dynamic> saveItems = [];
          int row = 1;
          addForm.forEach((element) {
            element.keys.forEach((e) {
              if (element[e]["code"] == "date") {
                saveItems.add({
                  "id": e,
                  "dataId": element[e]["id"],
                  "value": element[e]["value"].toString().substring(0, 10),
                  "code": element[e]["code"].toString(),
                  "row": row.toString()
                });
              } else {
                saveItems.add({
                  "id": e,
                  "dataId": element[e]["id"],
                  "value": element[e]["value"].toString(),
                  "code": element[e]["code"].toString(),
                  "row": row.toString()
                });
              }
              if (element[e]["value"] == null) {
                insertFlag = true;
              }
            });
            row++;
          });
          if (insertFlag) {
            showErrorToast("请填写完记录信息！");
          } else {
            showDialog<Null>(
              context: context,
              barrierDismissible: false,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: new Text('填写记录'),
                  content: new SingleChildScrollView(
                    child: new ListBody(
                      children: <Widget>[
                        FormBuilder(
                          key: _fbKey,
                          initialValue: {
                            'id': data["id"],
                            'staffName': data["staffName"],
                            'typeId': data["typeId"],
                            'typeName': data["typeName"],
                            'staffId': data["staffId"],
                            'checkDate': data["checkDate"] != null
                                ? DateTime.parse(data["checkDate"])
                                : DateTime.now(),
                            'name': data["name"],
                          },
                          child: Column(
                            children: [
                              FormBuilderTextField(
                                name: "name",
                                decoration: InputDecoration(labelText: "名称"),
                                validator: FormBuilderValidators.compose([
                                  FormBuilderValidators.required(
                                    errorText: "请输入名称!",
                                  ),
                                ]),
                              ),
                              FormBuilderTextField(
                                focusNode: focusNode1,
                                name: "staffName",
                                decoration: const InputDecoration(
                                    hintText: '请选择人员！', labelText: '检查人员'),
                                validator: FormBuilderValidators.compose([
                                  FormBuilderValidators.required(
                                    errorText: "请输入名称!",
                                  ),
                                ]),
                                onTap: () {
                                  focusNode1.unfocus();
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => SelectPage(
                                          title: "选择人员",
                                          url: "/staff/listQueryByPage",
                                          queryParams: {},
                                        ),
                                      )).then((value) {
                                    setState(() {
                                      if (value != null) {
                                        _fbKey.currentState.setState(() {
                                          _fbKey
                                              .currentState.fields['staffName']
                                              .didChange(value["name"]);
                                          _fbKey.currentState
                                              .setInternalFieldValue(
                                                  "staffId", value["id"]);
                                        });
                                      }
                                    });
                                  });
                                },
                              ),
                              FormBuilderDropdown(
                                name: "typeId",
                                decoration: InputDecoration(labelText: "检查类型", hintText: '选择类型'),
                                validator: FormBuilderValidators.compose([
                                  FormBuilderValidators.required(
                                    errorText: "请选择类型!",
                                  ),
                                ]),
                                items: typeList
                                    .map((gender) => DropdownMenuItem(
                                        value: gender["id"],
                                        child: Text(gender['name'])))
                                    .toList(),
                              ),
                              FormBuilderDateTimePicker(
                                name: "checkDate",
                                inputType: InputType.date,
                                format: DateFormat("yyyy-MM-dd"),
                                validator: FormBuilderValidators.compose([
                                  FormBuilderValidators.required(
                                    errorText: "请检查日期!",
                                  ),
                                ]),
                                decoration: InputDecoration(labelText: "检查日期"),
                              ),
                              FormBuilderTextField(
                                name: "remark",
                                maxLines: 2,
                                decoration: InputDecoration(labelText: "备注"),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    new ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: Text("取消"),
                    ),
                    new ElevatedButton(
                      child: new Text('确定'),
                      onPressed: () {
                        if (_fbKey.currentState.saveAndValidate()) {
                          loading = false;
                          //保存信息
                          var formData = Map.of(_fbKey.currentState.value);
                          formData["checkDate"] =
                              formData["checkDate"].toString();
                          post("/checkrecord/saveCheckRecord", {
                            ...formData,
                            "saveItems": jsonEncode(saveItems),
                            "templateId": data["templateId"] != null
                                ? data["templateId"]
                                : data["id"]
                          }).then((value) {
                            if (value["success"]) {
                              showSuccessToast("保存成功！");
                              addForm = [];
                              loading = true;
                              initDataList();
                            }
                            Navigator.of(context).pop();
                            Navigator.of(context).pop();
                          });
                        } else {
                          showErrorToast("请填写完记录数据！");
                        }
                      },
                    ),
                  ],
                );
              },
            );
          }
        },
        child: Text("保存"),
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: () {
        FocusScope.of(context).requestFocus(new FocusNode());
      },
      child: OrientationBuilder(
        builder: (context, orientation) {
          if (dataList.length > 0) {
            var width = MediaQuery.of(context).size.width;
            var w = (dataList.length + extraNumber) * 120;
            if (w < width) {
              length = width / (dataList.length + extraNumber);
            } else {
              length = 120.0;
            }
          }
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: SingleChildScrollView(
              child: Visibility(
                visible: dataList.length > 0,
                child: Center(
                  child: Container(
                    width: (dataList.length + extraNumber) * length,
                    child: Column(
                      children: [
                        Container(
                          height: length,
                          child: InkWell(
                            child: Row(
                              children: dataList.map((e) {
                                return Container(
                                  width: e["configListLength"] * length,
                                  child: GridView(
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 1,
                                              childAspectRatio: e["configListLength"] * length / length),
                                      children: [
                                        _createGridViewItem(e,
                                            color:
                                                ThemeColor.getColor("success"))
                                      ]),
                                );
                              }).toList(),
                            ),
                          ),
                        ),
                        _checkRecordList(),
                        Column(
                          children: addForm.map((e) {
                            return Container(
                              width:
                                  ((dataList.length + extraNumber) * length) +
                                      (dataList.length * 0.5),
                              height: length,
                              child: InkWell(
                                child: Row(
                                  children: dataList.map((d) {
                                    List<Widget> wList = [];
                                    wList.add(Container(
                                      width: length,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          width: 0.5,
                                        ),
                                      ),
                                      child: _createGridDataItem(
                                          d, addForm.indexOf(e)),
                                    ));
                                    if (d["configList"] != null) {
                                      var index = 1;
                                      d["configList"].forEach((c) {
                                        var config = {
                                          "id": d["id"] + index.toString(),
                                          "type": c["type"],
                                          "params": c["type"] == "selectDic"
                                              ? c["paramsCode"]
                                              : c["params"]
                                        };
                                        index++;
                                        wList.add(Container(
                                          width: length,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              width: 0.5,
                                            ),
                                          ),
                                          child: _createGridDataItem(
                                              config, addForm.indexOf(e)),
                                        ));
                                      });
                                    }
                                    return Container(
                                      width: d["configListLength"] * length,
                                      child: GridView(
                                        physics: NeverScrollableScrollPhysics(),
                                        gridDelegate:
                                            SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: wList.length,
                                        ),
                                        children: wList,
                                      ),
                                    );
                                  }).toList(),
                                ),
                                onTap: () {
                                  FocusScope.of(context)
                                      .requestFocus(new FocusNode());
                                },
                                onLongPress: () {
                                  showModalBottomSheet(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          ListTile(
                                            title: Text("新增"),
                                            onTap: () {
                                              setState(() {
                                                addForm.insert(
                                                    addForm.indexOf(e) + 1, {});
                                                Navigator.pop(context);
                                              });
                                            },
                                          ),
                                          Visibility(
                                            visible: addForm.length > 1,
                                            child: ListTile(
                                              title: Text("删除"),
                                              onTap: () {
                                                //弹出确认框
                                                showConfirmAlert("是否确认删除！")
                                                    .then((value) {
                                                  if (value) {
                                                    setState(() {
                                                      var deleteList = [];
                                                      e.keys.forEach((element) {
                                                        if (e[element]["id"] !=
                                                            null) {
                                                          //删除
                                                          deleteList.add(
                                                              e[element]["id"]);
                                                        }
                                                      });
                                                      if (deleteList.length >
                                                          0) {
                                                        loading = true;
                                                        post(
                                                            "/checkrecorditem/deleteByIds",
                                                            {
                                                              "ids": jsonEncode(
                                                                  deleteList)
                                                            }).then((value) {
                                                          if (value[
                                                              "success"]) {
                                                            showSuccessToast(
                                                                "删除成功！");
                                                          }
                                                          loading = false;
                                                        }).catchError(
                                                            (onError) {
                                                          loading = false;
                                                          showErrorAlert(
                                                              onError["msg"]);
                                                        });
                                                      }
                                                      addForm.removeAt(
                                                          addForm.indexOf(e));
                                                    });
                                                  }
                                                  Navigator.pop(context);
                                                });
                                              },
                                            ),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    this.initDataList();
    this._initTypeList();
  }

  @override
  void dispose() {
    FocusScope.of(context).requestFocus(new FocusNode());
    super.dispose();
  }

  Widget _createGridViewItem(data, {Color color}) {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color,
        border: Border.all(
          width: 0.5,
        ),
      ),
      child: Text(
        data["name"] != null ? data["name"] : "",
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _createGridDataItem(data, index) {
    if (data != null && data.length > 0) {
      if (addForm[index] == null) {
        addForm.add({});
      }
      if (addForm[index][data["id"]] == null) {
        addForm[index][data["id"]] = {};
      }
      addForm[index][data["id"]]["code"] = data["type"];
      if (data["type"] == "select") {
        return _formDataTextButton(data["params"], data["id"], addForm[index]);
      } else if (data["type"] == "text") {
        if (textKey[data["id"]] == null) {
          textKey[data["id"]] = GlobalKey();
        }
        return _formText(data["id"], addForm[index], textKey[data["id"]]);
      } else if (data["type"] == "selectDic") {
        return _formUrlTextButton(
            "/dictionarydata/listQueryByTypeCode/" + data["params"],
            "请输入字典名称进行搜索",
            data["id"],
            addForm[index]);
      } else if (data["type"] == "selectStaff") {
        return _formUrlTextButton("/staff/listQueryByPage", "请输入人员名称进行搜索",
            data["id"], addForm[index]);
      } else if (data["type"] == "selectPlace") {
        return _formUrlTextButton("/place/listQueryByPage", "请输入场地名称进行搜索",
            data["id"], addForm[index]);
      } else if (data["type"] == "date") {
        if (addForm[index][data["id"]]["value"] == null) {
          addForm[index][data["id"]]["value"] = DateTime.now();
        }
        return _formDate(data["id"], addForm[index]);
      } else if (data["type"] == "number") {
        if (textKey[data["id"]] == null) {
          textKey[data["id"]] = GlobalKey();
        }
        return _formNumber(data["id"], addForm[index], textKey[data["id"]]);
      }
    }
    return SizedBox();
  }

  initDataList() {
    this.loading = true;
    //获取记录
    if (data["id"] != null) {
      post("/checkrecord/listQueryByPage", {"id": data["id"]}).then((value) {
        if (value["total"] > 0) {
          var d = value["rows"][0];
          setState(() {
            textKey = {};
            List<Map<String, dynamic>> formList = [];
            d["itemMap"].forEach((s) {
              Map<String, dynamic> form = {};
              s.keys.forEach((i) {
                var id = i;
                if (s[i]["itemCode"] == "text" ||
                    s[i]["itemCode"] == "number") {
                  textKey[i] = GlobalKey();
                }
                if (s[i]["value"].toString().indexOf(s[i]["itemId"]) > -1) {
                  var dd = s[i]["value"].toString().substring(36);
                  var index = dd.substring(0, dd.indexOf("-"));
                  s[i]["itemId"] = s[i]["itemId"] + index;
                  id = s[i]["itemId"];
                  s[i]["value"] = dd.substring(dd.indexOf("-") + 1);
                }
                if (s[i]["itemCode"] == "date") {
                  form[id] = {
                    "id": s[i]["id"],
                    "value": DateTime.parse(s[i]["value"]),
                    "code": s[i]["itemCode"],
                    "name": s[i]["valueName"]
                  };
                } else {
                  form[id] = {
                    "id": s[i]["id"],
                    "value": s[i]["value"],
                    "code": s[i]["itemCode"],
                    "name": s[i]["valueName"]
                  };
                }
              });
              formList.add(form);
            });
            this.addForm = formList;
          });
        }
      });
    } else {
      setState(() {
        this.addForm = [{}];
      });
    }

    post("/checktemplateitems/listQueryByPage",
        {"templateId": data["templateId"]}).then((value) {
      if (value["total"] > 0) {
        value["rows"].forEach((s) {
          s["configListLength"] = 1;
          if (s["type"] == "select") {
            var list = [];
            jsonDecode(s["params"]).forEach((p) {
              list.add({"name": p, "id": p});
            });
            s["paramsList"] = list;
          }
          if (s["config"] != null) {
            var configList = jsonDecode(s["config"]);
            if (configList != null && configList.length > 0) {
              s["configList"] = configList;
              s["configListLength"] = configList.length + 1;
              extraNumber += configList.length;
            }
          }
        });
        setState(() {
          this.dataList = value["rows"];
          //动态调调整宽度
          var width = MediaQuery.of(context).size.width;
          var w = (dataList.length + extraNumber) * 120;
          if (w < width) {
            length = width / (dataList.length + extraNumber);
          }
          this.loading = false;
        });
      }
    });
  }

  Widget _checkRecordList() {
    return Column(
      children: checkRecord.map((r) {
        return Column(
          children: _createItemMap(r["itemMap"]),
        );
      }).toList(),
    );
  }

  List<Widget> _createItemMap(list) {
    List<Widget> wList = [];
    list.forEach((m) {
      wList.add(Container(
        height: 120,
        child: InkWell(
          child: Container(
            child: GridView(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: dataList.length != 0 ? dataList.length : 1,
              ),
              children: dataList.map((e) {
                return Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 0.5,
                    ),
                  ),
                  child: Text(e["type"] == 'date'
                      ? m[e["id"]]["value"].toString().substring(0, 10)
                      : m[e["id"]]["value"]),
                );
              }).toList(),
            ),
          ),
          onLongPress: () {},
        ),
      ));
    });
    return wList;
  }

  Widget _formDate(id, form) {
    return InkWell(
      onTap: () {
        //调起日期选择器
        _showDatePicker(id, form);
      },
      onLongPress: () {},
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text("${formatDate(form[id]["value"], [yyyy, "-", mm, "-", dd])}"),
          Icon(Icons.arrow_drop_down)
        ],
      ),
    );
  }

  Widget _formText(id, form, key) {
    return TextField(
      controller: new TextEditingController(),
      onChanged: (d) {
        form[id]["value"] = d;
      },
    )..controller.text = form[id]["value"];
  }

  Widget _formNumber(id, form, key) {
    return TextField(
      controller: new TextEditingController(),
      inputFormatters: [FilteringTextInputFormatter.digitsOnly], //只允许输入数字
      onChanged: (d) {
        form[id]["value"] = d;
      },
    )..controller.text = form[id]["value"];
  }

  Widget _formUrlTextButton(url, searchText, id, form) {
    return ElevatedButton(
      child: Text(form[id]["name"] == null ? "请选择" : form[id]["name"]),
      onPressed: () {
        FocusScope.of(context).requestFocus(new FocusNode());
        showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return RefreshList(
                searchText: searchText,
                url: url,
                buildItem: (dynamic row, int i) {
                  return ListTile(
                    title: new Text(row["name"]),
                    onTap: () async {
                      setState(() {
                        form[id]["value"] = row["id"];
                        form[id]["name"] = row["name"];
                      });
                      Navigator.pop(context);
                    },
                  );
                },
              );
            });
      },
    );
  }

  Widget _formDataTextButton(data, id, form) {
    if (data is String) {
      data = jsonDecode(data);
    }
    return ElevatedButton(
      child: Text(form[id]["name"] == null ? "请选择" : form[id]["name"]),
      onPressed: () {
        FocusScope.of(context).requestFocus(new FocusNode());
        showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: data.map<Widget>((e) {
                    return ListTile(
                      title: Text(e),
                      onTap: () {
                        Navigator.pop(context);
                        setState(() {
                          form[id]["value"] = e;
                          form[id]["name"] = e;
                        });
                      },
                    );
                  }).toList(),
                ),
              );
            });
      },
    );
  }

  _showDatePicker(id, form) {
    //获取异步方法里面的值的第一种方式：then
    return showDatePicker(
      //如下四个参数为必填参数
      context: context,
      initialDate: form[id]["value"], //选中的日期
      firstDate: DateTime(1997), //日期选择器上可选择的最早日期
      lastDate: DateTime(2100), //日期选择器上可选择的最晚日期
    ).then((selectedValue) {
      setState(() {
        //将选中的值传递出来
        if (selectedValue != null) {
          form[id]["value"] = selectedValue;
        }
      });
    });
  }

  _initTypeList() {
    post("/dictionarydata/listQueryByTypeCode/checkRecordType", {})
        .then((value) {
      if (value["total"] > 0) {
        setState(() {
          typeList = value["rows"];
        });
      }
    });
  }
}
