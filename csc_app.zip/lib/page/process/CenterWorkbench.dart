import 'package:badges/badges.dart' as badges;
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

import '../../ThemeColor.dart';

class CenterWorkbench extends BaseApp {
  @override
  _CenterWorkbenchState createState() => new _CenterWorkbenchState();
}

class _CenterWorkbenchState extends BaseAppPage<CenterWorkbench> {
  var sessionList = [];
  var weekList = [];
  var cacheHeader = [];
  var dataCache = {};
  var type = "time";
  dynamic queryParams = {};
  var placeName = "选择教室";
  DateTime nowDate = DateTime.now();
  ScrollController _scrollController1;
  ScrollController _scrollController2;
  ScrollController _scrollController3;
  ScrollController _scrollController4;

  _CenterWorkbenchState() {
    title = "中心工作台";
  }

  @override
  void initState() {
    super.initState();
    getSessionList().then((value) {
      if (value) {
        initTimeData();
      }
    });
    _scrollController1 = new ScrollController();
    _scrollController2 = new ScrollController();
    _scrollController3 = new ScrollController();
    _scrollController4 = new ScrollController();
    _scrollController2.addListener(() {
      _scrollController1.position.jumpTo(_scrollController2.offset);
    });
    _scrollController4.addListener(() {
      _scrollController3.position.jumpTo(_scrollController4.offset);
    });
  }

  initPlaceData() async {
    weekList = [];
    nowDate = DateTime.now();
    cacheHeader = [];
    getPlaceDataList();
  }

  initTimeData() async {
    weekList = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期天"];
    nowDate = DateTime.now();
    var days = getWeekDate(nowDate);
    cacheHeader = [];
    days.forEach((d) {
      cacheHeader.add(d);
    });
    getTimeDataList();
  }

  Future<bool> getSessionList() async {
    setState(() {
      loading = true;
    });
    var res = await post("/session/listQueryByPage", {});
    if (res["total"] > 0) {
      sessionList = res["rows"];
    }
    return Future.value(true);
  }

  getTimeDataList() {
    dataCache = {};
    post("/reservation/getCenterWork", {
      "startDate": cacheHeader[0],
      "endDate": cacheHeader[cacheHeader.length - 1],
      ...queryParams
    }).then((res) {
      if (res["success"]) {
        res["data"].forEach((d) {
          var key = "${d["date"]}-${d["sessionId"]}";
          if (dataCache[key] == null) {
            dataCache[key] = [];
          }
          dataCache[key].add(d);
        });
        setState(() {
          loading = false;
          empty = false;
        });
      }
    });
  }

  getPlaceDataList() {
    dataCache = {};
    post("/reservation/getCenterWork", {
      "date": formatDate(nowDate, [yyyy, "-", mm, "-", dd])
    }).then((res) {
      if (res["success"]) {
        var cache = {};
        res["data"].forEach((d) {
          cache[d["placeName"]] = d["placeId"];
          var key = "${d["placeId"]}-${d["sessionId"]}";
          if (dataCache[key] == null) {
            dataCache[key] = [];
          }
          dataCache[key].add(d);
        });
        weekList = cache.keys.toList();
        cacheHeader = cache.values.toList();
        setState(() {
          loading = false;
          empty = false;
        });
      }
    });
  }

  @override
  Widget getBody(BuildContext context) {
    return weekList.length > 0
        ? _buildChart()
        : Center(
            child: Text(
              "当前日期无工作,请切换日期后尝试",
              style: TextStyle(
                fontSize: 20.0,
              ),
            ),
          );
  }

  @override
  Widget getBottom(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        OutlinedButton.icon(
          onPressed: () {
            if (type == 'time') {
              nowDate = nowDate.subtract(new Duration(days: 7));
              var days = getWeekDate(nowDate);
              cacheHeader = [];
              days.forEach((d) {
                cacheHeader.add(d);
              });
              setState(() {
                loading = true;
              });
              getTimeDataList();
            } else {
              nowDate = nowDate.subtract(new Duration(days: 1));
              setState(() {
                loading = true;
              });
              getPlaceDataList();
            }
          },
          label: Text(type == 'time' ? "上周" : "前"),
          icon: Icon(Icons.arrow_back),
        ),
        OutlinedButton.icon(
          onPressed: () {
            if (type == 'time') {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SelectPage(
                      title: "切换场地",
                      url: "/place/listQueryByPage",
                      searchText: "输入名称进行搜索",
                      queryParams: {},
                    ),
                  )).then((value) {
                if (value != null) {
                  setState(() {
                    queryParams["placeId"] = value["id"];
                    placeName = value["name"];
                    loading = true;
                  });
                  getTimeDataList();
                }
              });
            } else {
              showDatePicker(
                context: context,
                initialDate: nowDate,
                firstDate: DateTime(1997),
                lastDate: DateTime(DateTime.now().year + 30),
              ).then((DateTime value) {
                if (value != null) {
                  setState(() {
                    loading = true;
                  });
                  nowDate = value;
                  getPlaceDataList();
                }
              });
            }
          },
          label: Text(type == 'time'
              ? placeName
              : formatDate(nowDate, [yyyy, "-", mm, "-", dd])),
          icon: Icon(MdiIcons.swapHorizontal),
        ),
        OutlinedButton.icon(
          onPressed: () {
            if (type == 'time') {
              nowDate = nowDate.add(new Duration(days: 7));
              var days = getWeekDate(nowDate);
              cacheHeader = [];
              days.forEach((d) {
                cacheHeader.add(d);
              });
              setState(() {
                loading = true;
              });
              getTimeDataList();
            } else {
              nowDate = nowDate.add(new Duration(days: 1));
              setState(() {
                loading = true;
              });
              getPlaceDataList();
            }
          },
          label: Text(type == 'time' ? "下周" : "后"),
          icon: Icon(Icons.arrow_forward),
        ),
      ],
    );
  }

  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      TextButton(
        onPressed: () {
          setState(() {
            loading = true;
            type = type == 'time' ? "place" : "time";
          });
          if (type == 'time') {
            initTimeData();
          } else {
            initPlaceData();
          }
        },
        child: Text(type == 'time' ? "按场地" : "按时间"),
      ),
    ];
  }

  //创建一个表单
  Widget _buildChart() {
    return Container(
      child: Column(
        children: [
          Container(
            child: Row(
              children: [
                Container(
                  child: Table(children: [_buildSingleColumnOne(-1)]),
                  width: firstWidth, //固定第一列
                ),
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    controller: _scrollController3,
                    physics: NeverScrollableScrollPhysics(),
                    child: Container(
                      child: SingleChildScrollView(
                        child: Table(children: [_buildSingleRow(-1)]),
                      ),
                      width: numRowWidth * weekList.length,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Row(
              children: <Widget>[
                Container(
                  child: SingleChildScrollView(
                    controller: _scrollController1,
                    physics: NeverScrollableScrollPhysics(),
                    child: Table(children: _buildTableColumnOne()),
                  ),
                  width: firstWidth, //固定第一列
                ),
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    controller: _scrollController4,
                    child: Container(
                      child: SingleChildScrollView(
                        controller: _scrollController2,
                        child: Table(children: _buildTableRow()),
                      ),
                      width: numRowWidth * weekList.length,
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  //创建第一列行
  double firstWidth = 60.0; //单个表宽
  double numRowWidth = 150.0; //单个表宽
  double firstHeight = 60.0; //表格高
  double numRowHeight = 85.0; //表格高

  List<TableRow> _buildTableColumnOne() {
    List<TableRow> returnList = [];
    for (int i = 0; i < sessionList.length; i++) {
      returnList.add(_buildSingleColumnOne(i));
    }
    return returnList;
  }

  //创建tableRows
  List<TableRow> _buildTableRow() {
    List<TableRow> returnList = [];
    for (int i = 0; i < sessionList.length; i++) {
      returnList.add(_buildSingleRow(i));
    }
    return returnList;
  }

  //创建第一列tableRow
  TableRow _buildSingleColumnOne(int index) {
    return TableRow(
      //第一行样式 添加背景色
      children: [
        //增加行高
        if (index == -1)
          SizedBox(
            height: firstHeight,
            width: firstWidth,
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(
                    width: 0.25, color: ThemeColor.getColor("border")),
              ),
              child: Text(
                type == 'time' ? "时间" : "教室",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          )
        else
          SizedBox(
            height: numRowHeight,
            width: firstWidth,
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(
                    width: 0.25, color: ThemeColor.getColor("border")),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(sessionList[index]["startTime"]),
                  Text("-"),
                  Text(sessionList[index]["endTime"]),
                ],
              ),
            ),
          ),
      ],
    );
  }

  //创建一行tableRow
  TableRow _buildSingleRow(int index) {
    int i = 0;
    return TableRow(
      //第一行样式 添加背景色
      children: weekList.map((e) {
        i++;
        if (index == -1) {
          return _buildSideBox(e, i);
        }
        var data =
            dataCache[cacheHeader[i - 1] + "-" + sessionList[index]["id"]];
        var t;
        if (data != null) {
          data.forEach((d) {
            t = (t == null ? "" : (t + "\n")) +
                d["itemName"] +
                " " +
                d["staffName"];
          });
        }
        return SizedBox(
          height: numRowHeight,
          width: numRowWidth,
          child: t != null
              ? badges.Badge(
                  badgeStyle: badges.BadgeStyle(
                    shape: badges.BadgeShape.circle,
                    badgeColor: ThemeColor.getColor("info"),
                  ),
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      border: Border.all(
                          width: 0.25, color: ThemeColor.getColor("border")),
                    ),
                    child: TextButton(
                      child: SingleChildScrollView(
                        child: Text(
                          showString(t),
                        ),
                      ),
                      onPressed: () {
                        List<Widget> list = [];
                        data.forEach((e) {
                          list.add(ListTile(
                            title: Text(e["itemName"]),
                            trailing:
                                Text("${e["staffName"]} - ${e["placeName"]}"),
                          ));
                        });
                        showBarModalBottomSheet(
                          context: context,
                          builder: (context) => Material(
                            child: SafeArea(
                              top: false,
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: list,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  position: badges.BadgePosition.topEnd(top: 2, end: 5),
                  badgeContent: Text(
                    "${data.length}",
                    style: TextStyle(fontSize: 10.0),
                  ),
                )
              : Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    border: Border.all(
                        width: 0.25, color: ThemeColor.getColor("border")),
                  ),
                  child: SingleChildScrollView(
                    child: Text(
                      showString(t),
                    ),
                  ),
                ),
        );
      }).toList(),
    );
  }

  //创建单个表格
  Widget _buildSideBox(String title, int index) {
    return SizedBox(
      height: firstHeight,
      width: numRowWidth,
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(width: 0.25, color: ThemeColor.getColor("border")),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
            ),
            if (type == 'time')
              Text(
                cacheHeader[index - 1],
              ),
          ],
        ),
      ),
    );
  }
}
