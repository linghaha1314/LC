import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flare_flutter/flare_actor.dart';
import 'package:flare_flutter/provider/asset_flare.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../ThemeColor.dart';

class PlaceDrillSignInPage extends BaseApp {
  final Map data;

  PlaceDrillSignInPage(this.data) : super();

  @override
  _PlaceDrillSignInPageState createState() =>
      new _PlaceDrillSignInPageState(this.data);
}

class _PlaceDrillSignInPageState extends BaseAppPage<PlaceDrillSignInPage> {
  dynamic data;
  Map statusMap = {0: "签到", 1: "签退"};
  Map<String, String> queryParams = {};
  int nowYear = DateTime.now().year;
  DateFormat dateFormat = DateFormat("yyyy-MM-dd");
  var dataList = [];
  Map statusColorMap = {
    1: ThemeColor.getColor("danger"),
    0: ThemeColor.getColor("success")
  };

  final _titleStyle = TextStyle(fontSize: 18, fontWeight: FontWeight.w600);

  _PlaceDrillSignInPageState(data) {
    this.data = data;
    queryParams["date"] = formatDate(DateTime.now(), [yyyy, "-", mm, "-", dd]);
    title = "实验室签到记录";
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: [
        Container(
          child: TableCalendar(
            firstDay: DateTime.utc(nowYear - 5, 1, 1),
            lastDay: DateTime.utc(nowYear + 5, 12, 28),
            focusedDay: dateFormat.parse(queryParams["date"]),
            currentDay: dateFormat.parse(queryParams["date"]),
            headerVisible: true,
            availableCalendarFormats: {
              CalendarFormat.month: 'Month',
            },
            onDaySelected: (DateTime selectedDay, DateTime focusedDay) {
              showCheckList(selectedDay);
            },
            locale: 'zh_CH',
          ),
        ),
        Divider(),
        Visibility(
          visible: dataList.length != 0,
          child: Expanded(
            flex: 1,
            child: SingleChildScrollView(
              child: Column(
                children: dataList.map<Widget>((row) {
                  return _buildRow(row);
                }).toList(),
              ),
            ),
          ),
        ),
        Visibility(
          visible: dataList.length == 0,
          child: Expanded(
            child: FlareActor.asset(
              AssetFlare(
                  bundle: rootBundle, name: "assets/flare/empty_data.flr"),
              alignment: Alignment.center,
              fit: BoxFit.contain,
              animation: "empty",
            ),
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    getListQueryByCurrentPage();
    super.initState();
    empty = false;
  }

  @override
  void dispose() {
    super.dispose();
  }

  handleNewDate(data) {}

  _buildRow(row) {
    var list = [];
    var timeDifference = 0;
    list.addAll(row["signInCheck"]);
    //计算总时间
    if (row["signOutCheck"] != null) {
      list.addAll(row["signOutCheck"]);
      var startDate = row["signInCheck"][0]["date"];
      var endDate = row["signOutCheck"][row["signOutCheck"].length - 1]["date"];
      timeDifference = DateTime.parse(endDate)
          .difference(DateTime.parse(startDate))
          .inMinutes;
    }
    var times = row["reservationItem"]["dateTime"].toString().split("-");
    var startTime = times[0];
    var endTime = times[1];
    return Column(
      children: [
        ListTile(
          title: Text(
            "${row["reservationItem"]["itemName"]}",
            style: _titleStyle,
          ),
          subtitle: Text(
            "训练时间：${showDate(timeDifference)}",
          ),
        ),
        Row(
          children: [
            Container(
              padding: EdgeInsets.all(10.0),
              alignment: Alignment.center,
              child: Column(
                children: [
                  Text(startTime, style: _titleStyle),
                  Container(
                    child: RotatedBox(
                      quarterTurns: 45,
                      child: Container(
                        width: list.length * 40.0 - 20.0,
                        child: Divider(thickness: 2.0),
                      ),
                    ),
                  ),
                  Text(endTime, style: _titleStyle),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Column(
                children: list.map((item) {
                  return ListTile(
                    title: Row(
                      children: [
                        Text(
                          '${statusMap[item["status"]]}打卡',
                          style: _titleStyle,
                        ),
                      ],
                    ),
                    subtitle: Text(
                        "${item["flag"] ? '正常' : '${item["status"] == 0 ? '迟到' : '早退'}'}打卡(${item["date"].toString().substring(11, item["date"].toString().length - 3)})"),
                  );
                }).toList(),
              ),
            )
          ],
        ),
        Divider()
      ],
    );
  }

  showCheckList(date) {
    queryParams["date"] = formatDate(date, [yyyy, "-", mm, "-", dd]);
    getListQueryByCurrentPage();
  }

  getListQueryByCurrentPage() {
    loading = true;
    post("/reservationcheck/listQueryByCurrentGroupPage", queryParams)
        .then((value) {
      setState(() {
        dataList = value["rows"];
        loading = false;
      });
    });
  }

  showDate(minute) {
    if (minute > 60) {
      return "${minute ~/ 60}小时 ${minute % 60}分钟";
    }
    if (minute == 0) minute = 1;
    return "$minute分钟";
  }
}
