import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PlaceDrillRemark extends BaseApp {
  final String data;

  PlaceDrillRemark(this.data);

  @override
  _PlaceDrillRemarkState createState() => new _PlaceDrillRemarkState(this.data);
}

class _PlaceDrillRemarkState extends BaseAppPage<PlaceDrillRemark> {
  String data;

  TextEditingController _controller;

  _PlaceDrillRemarkState(v) {
    data = v;
    title = "添加备注";
    empty = false;
  }

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController();
    _controller.text = data;
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return [
      ElevatedButton(
        onPressed: () {
          Navigator.pop(context, _controller.text);
        },
        child: Text("保存"),
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: [
        Card(
          child: Container(
            margin: EdgeInsets.all(10.0),
            child: TextField(
              minLines: 10,
              maxLines: 30,
              controller: _controller,
              decoration: InputDecoration(
                hintText: '请输入备注,500字以内',
                contentPadding: const EdgeInsets.symmetric(vertical: 10.0),
              ),
              inputFormatters: <TextInputFormatter>[
                LengthLimitingTextInputFormatter(500)
              ],
            ),
          ),
        )
      ],
    );
  }
}
