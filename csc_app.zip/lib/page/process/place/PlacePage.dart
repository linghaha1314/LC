import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/page/process/place/PlaceDrillView.dart';
import 'package:flutter/material.dart';

class PlacePage extends BaseApp {
  @override
  _PlacePageState createState() => new _PlacePageState();
}

class _PlacePageState extends BaseAppPage<PlacePage> {
  dynamic params;

  _PlacePageState() {
    title = "实验室训练列表";
  }

  List<dynamic> list = [];
  Map statusMap = {0: "已签到", 1: "已签退", 2: "已签到", 4: "未签到"};

  @override
  Widget getBody(BuildContext context) {
    return Container(
      child: Column(
        children: list.map((e) {
          return Column(
            children: [
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("场地: ${e["placeName"]}"),
                    Text("签到状态: ${statusMap[e["checkStatus"]]}"),
                  ],
                ),
                subtitle: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("训练项:  ${e["timeName"]}"),
                    Text("时间段:  ${e["dateTime"]}"),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    new MaterialPageRoute(
                        builder: (context) => new PlaceDrillView()),
                  ).then((value) {
                    initPlaceDrillList();
                  });
                },
              ),
              Divider(),
            ],
          );
        }).toList(),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    empty =false;
  }

  @override
  Widget build(BuildContext context) {
    if (params == null) {
      params = ModalRoute.of(context).settings.arguments;
      initPlaceDrillList();
    }
    return super.build(context);
  }

  initPlaceDrillList() {
    params = ModalRoute.of(context).settings.arguments;
    loading = true;
//    post("/reservation/listQueryByPlaceDrill", params).then((value) {
//      setState(() {
//        list = value["rows"];
//        loading = false;
//        if (list.length == 1) {
//          //直接进入训练详情
//          Navigator.push(
//            context,
//            new MaterialPageRoute(
//                builder: (context) => new PlaceDrillV(list[0])),
//          ).then((value) {
//            Navigator.pop(context);
//          });
//        }else if(list.length == 0){
//          this.empty = true;
//        }
//      });
//    }).catchError((error) {
//      setState(() {
//        loading = false;
//      });
//      showErrorToast(error["msg"]);
//    });
  }
}
