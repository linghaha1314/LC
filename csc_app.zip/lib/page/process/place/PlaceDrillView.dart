import 'dart:async';

import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/page/process/place/PlaceDrillRemark.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

import 'PlaceDrillSignInPage.dart';

class PlaceDrillView extends BaseApp {
  @override
  _PlaceDrillViewState createState() => new _PlaceDrillViewState();
}

class _PlaceDrillViewState extends BaseAppPage<PlaceDrillView> {
  dynamic params;
  dynamic data = {"timeName": "无预约", "checkStatus": 4, "reservationId": null};
  var dataList = [];
  String address;
  String remark;
  dynamic _timer;
  bool check = false;
  Map statusMap = {0: "已签到", 1: "已签退", 2: "已签到", 4: "未签到"};
  Map statusSaveMap = {0: "签到", 1: "签退"};
  bool _signInLoading = false;
  double buttonWidth = 200;
  DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm");

  _PlaceDrillViewState() {
    title = "训练签到";
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return _buildSignIn();
  }

  @override
  void initState() {
    super.initState();
    getReservation();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
          onPressed: () {
            if (data != null) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PlaceDrillSignInPage(data),
                ),
              );
            } else {
              showErrorToast("请先选择预约信息，再进行查询！");
            }
          },
          tooltip: "签到记录",
          icon: Icon(MdiIcons.calendarWeek))
    ];
  }

  _startTimer() {
    /*创建循环*/
    _timer = new Timer.periodic(new Duration(seconds: 1), (timer) {
      setState(() {});
    });
  }

  _buildSignIn() {
    print(data);
    return Column(
      children: [
        Expanded(
          flex: 1,
          child: Column(
            children: [
              Container(
                height: 35,
                margin: EdgeInsets.fromLTRB(.0, 5.0, .0, .0),
                child: MaterialButton(
                  child: Text("操作说明"),
                  onPressed: () {
                    showAlert(msg: "点击地点可以重新定位,点击预约名称可以选择相近的预约进行签到");
                  },
                ),
              ),
              Container(
                padding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 20.0),
                child: InkWell(
                  child: Text(
                    "${address == null ? '定位中' : address}",
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
                    textAlign: TextAlign.center,
                  ),
                  onTap: () {
                    setState(() {
                      address = null;
                    });
                    getLocation().then((value) {
                      setState(() {
                        address = value["address"];
                      });
                    });
                  },
                ),
              ),
              SizedBox(
                child: TextButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                      (data != null && data["dateTime"] != null)
                            ? (data["timeName"] + data["dateTime"])
                            : "选择训练",
                        style: TextStyle(
                          fontSize: 20,
                          color: ThemeColor.getColor("focus"),
                        ),
                      ),
                      Icon(Icons.keyboard_arrow_down_sharp,
                          color: ThemeColor.getColor("focus")),
                    ],
                  ),
                  onPressed: () {
                    showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return RefreshList(
                            url: "/reservation/listQueryByPlaceDrill",
                            buildItem: (dynamic row, int i) {
                              return ListTile(
                                title: new Text(row["placeName"]),
                                subtitle: new Text(
                                    row["timeName"] + "(${row["dateTime"]})"),
                                onTap: () async {
                                  setState(() {
                                    data = row;
                                  });
                                  Navigator.pop(context);
                                },
                              );
                            },
                          );
                        });
                  },
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text("请在预约时间段前后20分钟内进行签到签退")
            ],
          ),
        ),
        Container(
          height: 350.0,
          child: Column(
            children: [
              _buildContent(data["checkStatus"] == 4 ? 0 : 1),
              SizedBox(
                child: TextButton(
                  child: Text("添加备注...", style: TextStyle(fontSize: 13.0)),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PlaceDrillRemark(remark),
                      ),
                    ).then((value) {
                      remark = value;
                    });
                  },
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  _buildContent(status) {
    return Container(
      child: Column(
        children: [
          MaterialButton(
            color: ThemeColor.getColor("info"),
            shape: CircleBorder(),
            onPressed: () async {
              if (data["reservationId"] == null) {
                showErrorToast("当前不能签到!");
                return;
              }
              var nowDate = DateTime.now();
              var now = formatDate(DateTime.now(), [yyyy, "-", mm, "-", dd]);
              var time = data["dateTime"].split("-");
              var startDate = dateFormat.parse(now + " " + time[0]);
              var endDate = dateFormat.parse(now + " " + time[1]);
              if (!(nowDate.difference(startDate).inMinutes >= -20 &&
                  endDate.difference(nowDate).inMinutes >= -20)) {
                if (endDate.difference(nowDate).inMinutes <= -20) {
                  showConfirmAlert("请在预约时间段前后20分钟进行签到签退!", ok: "我要补签")
                      .then((val) {
                    if (val) {
                      _startCheck(status, false);
                    }
                  });
                } else {
                  showErrorToast("请在预约时间段前后20分钟进行签到签退!");
                }
                return;
              }
              _startCheck(status, true);
            },
            child: Container(
              height: buttonWidth,
              width: buttonWidth,
              child: Stack(
                children: [
                  Visibility(
                    visible: _signInLoading,
                    child: Container(
                      height: buttonWidth,
                      width: buttonWidth,
                      child: CircularProgressIndicator(
                        strokeWidth: 6,
                        backgroundColor: ThemeColor.getColor("focus"),
                      ),
                    ),
                  ),
                  Container(
                    height: buttonWidth,
                    width: buttonWidth,
                    decoration: BoxDecoration(
                      borderRadius:
                          BorderRadius.all(Radius.circular(buttonWidth / 2)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "${formatDate(DateTime.now(), [HH, ":", nn])}",
                          style: TextStyle(
                              fontSize: 40, fontWeight: FontWeight.w600),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              "${statusSaveMap[status]}",
                              style: TextStyle(
                                  fontSize: 25,
                                  color: ThemeColor.getColor("fontColor")),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  _startCheck(status, flag) {
    if (status == 0) {
      var msg = data["prContent"];
      if (msg == null || msg.toString().trim().length == 0) {
        msg = "请注意设备使用要求，保持实验室环境卫生，按时归还器械、耗材，谢谢！";
      }
      showConfirmAlert(
        msg,
        title: "实验室注意事项",
        ok: "已阅读",
      ).then((value) {
        if (value) {
          signInPlaceDrill(status, flag: flag);
        }
      });
      return;
    }
    signInPlaceDrill(status, flag: flag);
  }

  signInPlaceDrill(status, {bool flag = true}) async {
    setState(() {
      _signInLoading = true;
    });
    String photo = await takePicture();
    if (photo == null) {
      setState(() {
        _signInLoading = false;
      });
      showErrorToast("请完成拍照!");
      return;
    }
    if (address == null) {
      showErrorToast("请重新定位!");
      return;
    }
    dynamic d = {
      "reservationId": data["reservationId"],
      "address": address,
      "remark": remark,
      "status": status,
      "organizeFlag": false,
      "flag": flag
    };
    //上传照片
    d["picture"] = await uploadFile(file: photo, loading: false);
    //签退
    if (status == 1) {
      showConfirmAlert("您是否整理实验室?", ok: "是", cancel: "否").then((f) async {
        d["organizeFlag"] = f;
        post("/reservationcheck/save", d).then((value) {
          if (value["success"]) {
            showSuccessToast("${statusSaveMap[status]}成功！");
            setState(() {
              _signInLoading = false;
              data["checkStatus"] = status;
            });
          }
        });
      });
    } else {
      post("/reservationcheck/save", d).then((value) {
        if (value["success"]) {
          showSuccessToast("${statusSaveMap[status]}成功！");
          setState(() {
            _signInLoading = false;
            data["checkStatus"] = status;
          });
        }
      });
    }
  }

  getReservation() {
    getLocation().then((value) {
      setState(() {
        address = value["address"];
      });
    });
    post("/reservation/listQueryByPlaceDrill", {}).then((res) {
      if (res["total"] > 0) {
        setState(() {
          data = res["rows"][0];
          dataList = res["rows"];
        });
      }
    });
  }
}
