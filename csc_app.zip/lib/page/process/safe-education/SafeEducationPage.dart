import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/page/process/safe-education/SafeEducationRecordPage.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class SafeEducationPage extends BaseApp {
  @override
  _SafeEducationPageState createState() => new _SafeEducationPageState();
}

class _SafeEducationPageState extends BaseAppPage<SafeEducationPage> {
  RefreshController _controller;

  _SafeEducationPageState() {
    title = '安全教育学习';
    empty = false;
    _controller = RefreshController(initialRefresh: false);
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      controller: _controller,
      url: "/safeeducation/queryMineList",
      buildItem: (row, i) {
        return ListTile(
          title: Text("${row["name"]}"),
          trailing: Chip(
            backgroundColor:
                ThemeColor.getColor(row["status"] == 0 ? "danger" : "success"),
            label: Text(row["status"] == 0 ? "未学习" : "已学习"),
          ),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SafeEducationRecordPage(row),
              ),
            ).then((value) {
              if (value) {
                _controller.requestRefresh();
              }
            });
          },
        );
      },
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
