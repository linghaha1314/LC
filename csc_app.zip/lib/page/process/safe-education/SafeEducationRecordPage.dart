import 'dart:convert';
import 'dart:core';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SignatureComponent.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class SafeEducationRecordPage extends BaseApp {
  final dynamic data;

  SafeEducationRecordPage(this.data);

  @override
  _SafeEducationRecordPageState createState() =>
      new _SafeEducationRecordPageState(this.data);
}

class _SafeEducationRecordPageState
    extends BaseAppPage<SafeEducationRecordPage> {
  dynamic data;

  String url;

  String viewUrl;
  String clientUrl;

  final _buttonStyle = TextStyle(fontSize: 14.0);

  _SafeEducationRecordPageState(dynamic d) {
    data = d;
    title = d != null ? d["name"] : '暂无';
  }

  @override
  void initState() {
    super.initState();
    getHttpPath().then((value) {
      setState(() {
        url = value;
        if (data != null) {
          empty = false;
        }
      });
    });
  }

  @override
  initRouteSuccess() {
    if (routeData != null) {
      get("/safeeducation/findById/${routeData["id"]}").then((res) {
        if (res["success"]) {
          setState(() {
            this.data = res["data"];
            title = this.data["name"];
            empty = false;
          });
        }
      });
    }
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: data != null
          ? [
              Expanded(
                flex: 1,
                child: Column(
                  children: [
                    Card(
                      child: Container(
                        padding: EdgeInsets.all(10.0),
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                              child: Text("学习资料(请保证学习完成后再提交)"),
                            ),
                            Divider(),
                            Container(
                              margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                              child: Container(
                                margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                                child: Column(
                                  children: (data["files"] as String)
                                      .split(",")
                                      .map((e) {
                                    var fileName = getFileName(e);
                                    return ListTile(
                                      title: Text(
                                        "$fileName",
                                        style: _buttonStyle,
                                      ),
                                      trailing: ElevatedButton.icon(
                                        icon: Icon(
                                          MdiIcons.download,
                                          size: 18.0,
                                        ),
                                        label: Text(
                                          "下载",
                                          style: _buttonStyle,
                                        ),
                                        onPressed: () {
                                          downloadFile(e, fileName);
                                        },
                                      ),
                                      onTap: () {
                                        viewFile(e);
                                      },
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                      child: Container(
                        padding: EdgeInsets.all(10.0),
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                              child: Text("备注"),
                            ),
                            Divider(),
                            Container(
                              margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                              child: Text(
                                data["remark"] != null ? data["remark"] : "无",
                                overflow: TextOverflow.ellipsis,
                                maxLines: 100,
                                softWrap: true,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                width: MediaQuery.of(context).size.width,
                child: OutlinedButton.icon(
                  icon: Icon(Icons.check),
                  label: Text(data["status"] == 0 ? "提交学习记录" : "您已学习"),
                  onPressed: data["status"] == 0
                      ? () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignatureComponent(),
                            ),
                          ).then((value) {
                            if (value != null) {
                              setState(() {
                                loading = true;
                              });
                              uploadFile(file: value).then((filePath) {
                                post("/safeeducationrecord/save", {
                                  "educationId": data["id"],
                                  "attach": filePath
                                }).then((res) {
                                  if (res["success"]) {
                                    setState(() {
                                      loading = false;
                                    });
                                    Navigator.pop(context, true);
                                  }
                                });
                              });
                            } else {
                              showInfoToast("完成签名后才可提交!");
                            }
                          });
                        }
                      : null,
                ),
              ),
            ]
          : [],
    );
  }

  getFileName(String path) {
    var source = path.split('/');
    return source[source.length - 1];
  }

  viewFile(String path) async {
    if (viewUrl == null) {
      var config = await get("/config/getFileViewer");
      viewUrl = "${config["fileServer"]}/onlinePreview?url=";
      clientUrl = config["fileClient"];
    }
    String u = path;
    if (!path.startsWith("http")) {
      u = viewUrl +
          Uri.encodeComponent(base64Encode(utf8.encode(clientUrl + path)));
    } else {
      u = viewUrl +
          Uri.encodeComponent(base64Encode(utf8.encode(Uri.decodeFull(path))));
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => WebViewPage(url: u),
      ),
    );
  }
}
