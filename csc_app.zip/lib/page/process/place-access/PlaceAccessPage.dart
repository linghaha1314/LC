import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RowsLayout.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class PlaceAccessPage extends BaseApp {
  @override
  _PlaceAccessPageState createState() => new _PlaceAccessPageState();
}

class _PlaceAccessPageState extends BaseAppPage<PlaceAccessPage>
    with SingleTickerProviderStateMixin {
  TabController _controller;

  var list = [];

  var tabData = {};

  _PlaceAccessPageState() {
    title = '门禁管理';
    loading = true;
  }

  @override
  void initState() {
    super.initState();
    _initTabs();
  }

  _initController() {
    _controller = TabController(length: list.length, vsync: this);

    _controller.addListener(() {
      print("Selected Index: " + _controller.index.toString());
    });
  }

  @override
  Widget getAppBar(BuildContext context) {
    if (list.length == 0) return super.getAppBar(context);
    return AppBar(
      title: getTitle(context),
      actions: getActions(context),
      bottom: TabBar(
        isScrollable: true,
        onTap: (index) {},
        controller: _controller,
        tabs: list.map((e) {
          return Tab(
            text: e["name"],
          );
        }).toList(),
      ),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: _controller,
      children: list.map((_e) {
        Map<dynamic, dynamic> data = tabData[_e['id']];
        if (data == null || data.keys.length == 0) return emptyWidget;
        return SingleChildScrollView(
          child: Column(
            children: data.keys.map((e) {
              List<Widget> list = [];
              for (var i = 0; i < data[e].length; i++) {
                list.add(_buildButton(i, data, e));
              }
              return Card(
                margin: EdgeInsets.all(10.0),
                child: Container(
                  padding: EdgeInsets.all(10.0),
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                        child: Text("${e}F"),
                      ),
                      Divider(),
                      Container(
                        margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                        child: RowsLayout(width: 120, list: list),
                      )
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        );
      }).toList(),
    );
  }

  _buildButton(int v, dynamic data, String group) {
    if (v < data[group].length) {
      return MaterialButton(
        padding: EdgeInsets.all(15.0),
        child: Column(
          children: [
            SvgPicture.asset(
              "assets/images/door.svg",
              width: 40,
              height: 40,
            ),
            Text(
              data[group][v]["roomNo"],
              softWrap: true,
              textAlign: TextAlign.left,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        onPressed: () {
          showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    leading: Icon(MdiIcons.doorOpen),
                    title: Text("开门"),
                    onTap: () {
                      Navigator.pop(context);
                      _openDoor(data[group][v]["roomNo"]);
                    },
                  ),
                ],
              );
            },
          );
        },
      );
    }
    return Card();
  }

  _openDoor(String roomNo) {
    post('/placeAccess/openDoor', {"roomNo": roomNo}).then((value) {
      if (value["success"]) {
        showSuccessToast(value["val"]);
      }
    }).catchError((err) {
      showErrorToast(err["msg"]);
    });
  }

  _initTabs() async {
    var res = await post("/buildings/listQueryByPage", {});
    list = res["rows"];
    List<Future<dynamic>> rows = [];
    list.forEach((e) {
      rows.add(_initData(e["id"]));
    });
    await Future.wait(rows);
    _initController();
    setState(() {
      empty = false;
      loading = false;
    });
  }

  _initData(String buildingId) async {
    var res = await post("/place/getPlaceGroup", {"buildingId": buildingId});
    tabData[buildingId] = res["data"];
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }
}
