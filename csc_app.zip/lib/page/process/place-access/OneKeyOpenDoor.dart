import 'dart:async';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RowsLayout.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

class OneKeyOpenDoorPage extends BaseApp {
  @override
  _OneKeyOpenDoorPageState createState() => new _OneKeyOpenDoorPageState();
}

class _OneKeyOpenDoorPageState extends BaseAppPage<OneKeyOpenDoorPage> {
  var rows = [];
  Timer _timer;

  _OneKeyOpenDoorPageState() {
    title = '一键开门';
  }

  @override
  void initState() {
    super.initState();
    _getDoorList();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  _getDoorList() async {
    var res = await post("/placeAccess/queryOpenList", {});
    print(res);
    rows = res["data"];
    setState(() {
      empty = false;
    });
  }

  _startTimer() {
    _timer = new Timer.periodic(new Duration(seconds: 5), (timer) {
      _getDoorList();
    });
  }

  @override
  Widget getBody(BuildContext context) {
    List<Widget> list = [];
    for (var i = 0; i < rows.length; i++) {
      list.add(_buildButton(rows[i]));
    }
    return Column(
      children: [
        Card(
          margin: EdgeInsets.all(10.0),
          child: Container(
            padding: EdgeInsets.all(10.0),
            width: MediaQuery.of(context).size.width,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                  child: Text("门禁列表"),
                ),
                Divider(),
                Container(
                  margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                  child: RowsLayout(
                    width: 120,
                    list: list,
                  ),
                )
              ],
            ),
          ),
        ),
        Divider(),
        Card(
          margin: EdgeInsets.all(10.0),
          child: Container(
            margin: EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 10.0),
            child: Center(
              child: Text("一键开门只能打开您申请通过的预约实验室以及您的课程上课教室,默认是可以打开的时间范围为前后20分钟!"),
            ),
          ),
        ),
      ],
    );
  }

  _buildButton(dynamic data) {
    return TextButton(
      child: Column(
        children: [
          SvgPicture.asset(
            "assets/images/door.svg",
            width: 40,
            height: 40,
          ),
          Text(
            data["roomNo"],
            softWrap: true,
            textAlign: TextAlign.left,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
      onPressed: () {
        if (data['includePlace'] != null &&
            data['includePlace'].toString().trim().length > 0) {
          showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children:
                    data['includePlace'].toString().trim().split(",").map((e) {
                  return ListTile(
                    leading: Icon(MdiIcons.doorOpen),
                    title: Text(e),
                    onTap: () {
                      Navigator.pop(context);
                      _openDoor(e);
                    },
                  );
                }).toList(),
              );
            },
          );
        } else {
          showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    leading: Icon(MdiIcons.doorOpen),
                    title: Text("开门"),
                    onTap: () {
                      Navigator.pop(context);
                      _openDoor(data["roomNo"]);
                    },
                  ),
                ],
              );
            },
          );
        }
      },
    );
  }

  _openDoor(String roomNo) {
    post('/placeAccess/openDoor', {"roomNo": roomNo}).then((value) {
      if (value["success"]) {
        showSuccessToast(value["val"]);
      }
    }).catchError((err) {
      showErrorToast(err["msg"]);
    });
  }
}
