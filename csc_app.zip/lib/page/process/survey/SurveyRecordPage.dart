import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class SurveyRecordPage extends BaseApp {
  @override
  _SurveyRecordPageState createState() => new _SurveyRecordPageState();
}

class _SurveyRecordPageState extends BaseAppPage<SurveyRecordPage> {
  Map<String, dynamic> params = {"status": "0"};
  String baseUrl;

  _SurveyRecordPageState() {
    title = "教学评价";
  }

  @override
  initRouteSuccess() {
    print(routeData);
    if (routeData != null) {
      params["typeCode"] = routeData["type"];
      title = routeData["title"];
    } else {
      params["type"] = "all";
    }
    loading = false;
    empty = false;
    setState(() {});
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      queryParams: params,
      url: "/surveyrecord/listQueryByPage",
      buildItem: (dynamic row, int i) {
        return ListTile(
          title: Text(row["name"]),
          subtitle: Text(row["surveyName"]),
          onTap: () {
            Navigator.of(context).pushNamed('surveyVolume', arguments: {
              "surveyId": row["surveyId"],
              "key": row["id"],
              "limit": "false",
            });
          },
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    getCurrentAccount().then((account) {
      params["roles"] = account.role["id"];
      loading = false;
      getHttpPath().then((url) {
        baseUrl = url;
        setState(() {});
      });
    });
  }
}
