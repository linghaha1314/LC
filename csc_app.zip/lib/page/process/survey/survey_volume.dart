import 'dart:convert';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:intl/intl.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

import '../../../ThemeColor.dart';

class SurveyVolumePage extends BaseApp {
  @override
  _SurveyVolumePageState createState() => new _SurveyVolumePageState();
}

class _SurveyVolumePageState extends BaseAppPage<SurveyVolumePage> {
  List<dynamic> rows = [];
  List<dynamic> original = [];
  dynamic record;
  var saveFlag = false;
  String msg;
  var startDate = formatDate(
      DateTime.now(), [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);

  _SurveyVolumePageState() {
    title = "填写问卷";
  }

  @override
  initRouteSuccess() async {
    setState(() {
      empty = false;
      loading = true;
    });
    String key = routeData["key"];
    record = await get("/surveyrecord/findById/$key");
    title = record["data"]["name"];
    // 判断填写日期
    if (routeData["limit"] != "false") {
      var limit = await post("/surveyrecord/queryLimitDate", {"id": key});
      if (limit["val"] == "false") {
        loading = false;
        saveFlag = true;
        msg =
            "问卷填写日期为:${limit['data']['startDate']}~${limit['data']['endDate']}!";
        setState(() {});
        return;
      }
      if (limit['data']['status'] == 1) {
        loading = false;
        saveFlag = true;
        msg = "当前问卷已撤销发布,目前不能填写!";
        setState(() {});
        return;
      }
    }
    // 获取填写结果
    if(record["data"]["repeatFlag"] != true) {
      var result = await post("/surveyresult/listByEntity", {"surveyRecordId": key});
      if(result["data"][0]["status"] == 1) {
          loading = false;
          saveFlag = true;
          msg = "当前问卷您已填写,无需再次填写!";
          setState(() {});
          return;
      }
    }

    var res = await post(
        "/surveyquestion/queryQuestions", {"surveyId": routeData["surveyId"]});
    if (res["success"]) {
      rows = res["data"];
      for (var i = 0; i < rows.length; i++) {
        rows[i]['index'] = i + 1;
        if (rows[i]["question"]["typeName"] == "questionDefault") {
          var r = await post("/staff/getMineInfo",
              {"type": jsonDecode(rows[i]["question"]["params"])["value"]});
          if (r["success"]) {
            rows[i]["value"] = r["data"];
            rows[i]["name"] = r["data"];
          }
        }
      }
      original = jsonDecode(jsonEncode(rows));
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget getBody(BuildContext context) {
    if (msg != null)
      return Center(
        child: Text(
          msg,
          style: TextStyle(
            fontSize: 25.0,
            fontWeight: FontWeight.w700,
          ),
          textAlign: TextAlign.center,
        ),
      );
    return saveFlag
        ? Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "提交成功!",
                  style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 20.0),
                ElevatedButton.icon(
                  icon: Icon(MdiIcons.flipToBack),
                  label: Text("继续填写"),
                  onPressed: () {
                    rows = jsonDecode(jsonEncode(original));
                    setState(() {
                      saveFlag = false;
                      startDate = formatDate(DateTime.now(),
                          [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
                    });
                  },
                ),
                SizedBox(height: 20.0),
                ElevatedButton.icon(
                  icon: Icon(MdiIcons.arrangeSendToBack),
                  label: Text("采用上次数据继续填写"),
                  onPressed: () {
                    setState(() {
                      saveFlag = false;
                      startDate = formatDate(DateTime.now(),
                          [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
                    });
                  },
                ),
              ],
            ),
          )
        : SingleChildScrollView(
            child: Scrollbar(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: rows.map((row) {
                  return _buildRow(row);
                }).toList(),
              ),
            ),
          );
  }

  Widget getBottom(BuildContext context) {
    return saveFlag
        ? null
        : SafeArea(
            child: Container(
              padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
              child: ElevatedButton.icon(
                icon: Icon(MdiIcons.contentSave),
                label: Text("提交"),
                onPressed: () {
                  showConfirmAlert("是否提交?").then((value) {
                    if (value) {
                      save();
                    }
                  });
                },
              ),
            ),
          );
  }

  Widget _buildRow(dynamic r) {
    String title = "${r["question"]["name"]}";
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (r["question"]["typeName"] == "questionParagraph")
          Container(
            padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
            child: Center(
              child: Text(
                title.replaceAll(RegExp("<[^>]+>"), ""),
                style: TextStyle(
                  fontSize: 22.0,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          )
        else
          Container(
            padding: EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  height: 28.0,
                  child: Center(
                    child: Text(
                      "${r['index']}.",
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                if (r["question"]["required"] == true)
                  Container(
                    height: 28.0,
                    child: Center(
                      child: Text(
                        "*",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.red,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                Expanded(
                  flex: 1,
                  child: HtmlWidget(
                    title,
                    textStyle: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                )
              ],
            ),
          ),
        if (r["question"]["typeName"] == "questionSingle")
          _buildRadio(r)
        else if (r["question"]["typeName"] == "questionMultiple")
          _buildCheck(r)
        else if (r["question"]["typeName"] == "questionDate")
          _buildDate(r)
        else if (r["question"]["typeName"] == "questionSelect")
          _buildSelect(r)
        else if (r["question"]["typeName"] == "questionStars")
          _buildStars(r)
        else if (r["question"]["typeName"] == "questionGroupRadio")
          _buildGroupRadio(r)
        else if (r["question"]["typeName"] == "questionGroupCheck")
          _buildGroupCheck(r)
        else if (r["question"]["typeName"] == "questionListRadio")
          _buildListRadio(r)
        else if (r["question"]["typeName"] == "questionListCheck")
          _buildListCheck(r)
        else if (r["question"]["typeName"] == "questionUpload")
          _buildUpload(r)
        else if (r["question"]["typeName"] == "questionDefault" ||
            r["question"]["typeName"] == "questionAnswer")
          _buildText(r)
      ],
    );
  }

  Widget _buildRadio(dynamic row) {
    List<dynamic> options = row["options"];
    var i = 0;
    return Column(
      children: options.map((o) {
        i++;
        return Column(
          children: [
            Container(
              padding: EdgeInsets.all(2.0),
              child: TextButton(
                child: Container(
                  padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
                  child: Row(
                    children: [
                      row["value"] == o["id"]
                          ? Container(
                              width: 25.0,
                              height: 25.0,
                              margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                              decoration: new BoxDecoration(
                                color: ThemeColor.getColor("focus"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(25.0)),
                                border: new Border.all(
                                    width: 1,
                                    color: ThemeColor.getColor("focus")),
                              ),
                              child: Center(
                                child: Icon(
                                  MdiIcons.checkBold,
                                  color: ThemeColor.getColor("content"),
                                  size: 18,
                                ),
                              ),
                            )
                          : Container(
                              width: 25.0,
                              height: 25.0,
                              margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                              decoration: new BoxDecoration(
                                color: ThemeColor.getColor("console"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(25.0)),
                                border: new Border.all(
                                    width: 1,
                                    color: ThemeColor.getColor("border")),
                              ),
                              child: Center(
                                child: Text(getChar(i)),
                              ),
                            ),
                      Expanded(
                        flex: 1,
                        child: HtmlWidget(o["name"]),
                      ),
                    ],
                  ),
                ),
                onPressed: () {
                  setState(() {
                    row["name"] = o["name"];
                    row["value"] = o["id"];
                  });
                },
              ),
            ),
            if (o["inputFlag"] == true && row["value"] == o["id"])
              Container(
                padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                child: TextFormField(
                  initialValue: row["write"],
                  decoration: InputDecoration(
                    hintText: "请输入内容",
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 5.0, horizontal: 5.0),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide:
                            BorderSide(width: 1.0, style: BorderStyle.solid)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide:
                            BorderSide(width: 1.0, style: BorderStyle.solid)),
                    filled: true,
                  ),
                  onChanged: (v) {
                    row["write"] = v;
                  },
                ),
              )
          ],
        );
      }).toList(),
    );
  }

  Widget _buildCheck(dynamic row) {
    List<dynamic> options = row["options"];
    var i = 0;
    return Column(
      children: options.map((o) {
        i++;
        return Column(
          children: [
            Container(
              padding: EdgeInsets.all(2.0),
              child: TextButton(
                child: Container(
                  padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
                  child: Row(
                    children: [
                      o["checked"] == true
                          ? Container(
                              width: 25.0,
                              height: 25.0,
                              margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                              decoration: new BoxDecoration(
                                color: ThemeColor.getColor("focus"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)),
                                border: new Border.all(
                                    width: 1,
                                    color: ThemeColor.getColor("focus")),
                              ),
                              child: Center(
                                child: Icon(
                                  MdiIcons.checkBold,
                                  color: ThemeColor.getColor("content"),
                                  size: 18,
                                ),
                              ),
                            )
                          : Container(
                              width: 25.0,
                              height: 25.0,
                              margin: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
                              decoration: new BoxDecoration(
                                color: ThemeColor.getColor("console"),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5.0)),
                                border: new Border.all(
                                    width: 1,
                                    color: ThemeColor.getColor("border")),
                              ),
                              child: Center(
                                child: Text(getChar(i)),
                              ),
                            ),
                      Expanded(
                        flex: 1,
                        child: HtmlWidget(o["name"]),
                      ),
                    ],
                  ),
                ),
                onPressed: () {
                  setState(() {
                    o["checked"] = o["checked"] != true;
                  });
                  var values = [];
                  var names = [];
                  var writes = [];
                  options.forEach((e) {
                    if (e["checked"] == true) {
                      values.add(e["id"]);
                      names.add(e["name"]);
                      writes.add(e["write"]);
                    }
                  });
                  row["value"] = values;
                  row["name"] = names;
                  row["write"] = writes;
                },
              ),
            ),
            if (o["inputFlag"] == true && o["checked"] == true)
              Container(
                padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                child: TextFormField(
                  initialValue: o["write"],
                  decoration: InputDecoration(
                    hintText: "请输入内容",
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 5.0, horizontal: 5.0),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide:
                            BorderSide(width: 1.0, style: BorderStyle.solid)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15.0),
                        borderSide:
                            BorderSide(width: 1.0, style: BorderStyle.solid)),
                    filled: true,
                  ),
                  onChanged: (v) {
                    o["write"] = v;
                  },
                ),
              )
          ],
        );
      }).toList(),
    );
  }

  Widget _buildText(dynamic row) {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: TextFormField(
        initialValue: row["value"],
        onChanged: (v) {
          setState(() {
            row["value"] = v.trim();
            row["name"] = v.trim();
          });
        },
        decoration: InputDecoration(
          hintText: '请输入',
          contentPadding:
              const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15.0),
              borderSide: BorderSide(width: 1.0, style: BorderStyle.solid)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15.0),
              borderSide: BorderSide(width: 1.0, style: BorderStyle.solid)),
          filled: true,
        ),
      ),
    );
  }

  Widget _buildStars(dynamic row) {
    List<dynamic> options = row["options"];
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: options.map((o) {
          return Column(
            children: [
              Text(
                o["name"] ?? "",
                style: TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    child: Center(
                      child: Text(o["prefixLabel"] ?? ""),
                    ),
                    width: 70.0,
                  ),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child: RatingBar(
                        initialRating: 0,
                        direction: Axis.horizontal,
                        allowHalfRating: false,
                        itemCount: o["score"],
                        itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                        ratingWidget: RatingWidget(
                          full: Icon(MdiIcons.star),
                          half: Icon(MdiIcons.starHalfFull),
                          empty: Icon(MdiIcons.starOutline),
                        ),
                        onRatingUpdate: (rating) {
                          o["value"] = rating;
                        },
                      ),
                    ),
                  ),
                  Container(
                    width: 70.0,
                    child: Center(
                      child: Text(o["suffixLabel"] ?? ""),
                    ),
                  ),
                ],
              ),
            ],
          );
        }).toList(),
      ),
    );
  }

  _buildGroupRadio(dynamic row) {
    List<dynamic> options = row["options"];
    Map<String, List<dynamic>> group = {};
    options.forEach((o) {
      if (group[o["group"]] == null) {
        group[o["group"]] = [];
      }
      group[o["group"]].add(o);
    });
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Column(
        children: group.keys.map((k) {
          return Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(10),
              child: Column(
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
                    alignment: Alignment.topLeft,
                    child: Text(
                      k,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ),
                  FormBuilderRadioGroup(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                    ),
                    options: group[k].map((o) {
                      return FormBuilderFieldOption(
                        value: o["id"],
                        child: Text(o["name"]),
                      );
                    }).toList(growable: false),
                    onChanged: (v) {
                      group[k].forEach((g) {
                        if (g["id"] == v) {
                          g["checked"] = true;
                        } else {
                          g["checked"] = false;
                        }
                      });
                    },
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  _buildListRadio(dynamic row) {
    List<dynamic> options = row["options"];
    List<dynamic> params = jsonDecode(row["question"]["params"]);
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Card(
        child: Container(
          padding: EdgeInsets.all(5.0),
          child: Column(
            children: options.map((k) {
              return Container(
                alignment: Alignment.topLeft,
                padding: EdgeInsets.all(0),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
                      alignment: Alignment.topLeft,
                      child: Text(
                        k["name"],
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    FormBuilderRadioGroup(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                      ),
                      options: params.map((o) {
                        return FormBuilderFieldOption(
                          value: o,
                          child: Text("$o"),
                        );
                      }).toList(growable: false),
                      onChanged: (v) {
                        k["value"] = v;
                      },
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  _buildListCheck(dynamic row) {
    List<dynamic> options = row["options"];
    List<dynamic> params = jsonDecode(row["question"]["params"]);
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Card(
        child: Container(
          padding: EdgeInsets.all(5.0),
          child: Column(
            children: options.map((k) {
              return Container(
                alignment: Alignment.topLeft,
                padding: EdgeInsets.all(0),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
                      alignment: Alignment.topLeft,
                      child: Text(
                        k["name"],
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.left,
                      ),
                    ),
                    FormBuilderCheckboxGroup(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                      ),
                      options: params.map((o) {
                        return FormBuilderFieldOption(
                          value: o,
                          child: Text("$o"),
                        );
                      }).toList(growable: false),
                      onChanged: (v) {
                        k["value"] = v;
                      },
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  _buildGroupCheck(dynamic row) {
    List<dynamic> options = row["options"];
    Map<String, List<dynamic>> group = {};
    options.forEach((o) {
      if (group[o["group"]] == null) {
        group[o["group"]] = [];
      }
      group[o["group"]].add(o);
    });
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Column(
        children: group.keys.map((k) {
          return Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(10),
              child: Column(
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
                    alignment: Alignment.topLeft,
                    child: Text(
                      k,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ),
                  FormBuilderCheckboxGroup(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                    ),
                    options: group[k].map((o) {
                      return FormBuilderFieldOption(
                        value: o["id"],
                        child: Text(o["name"]),
                      );
                    }).toList(growable: false),
                    onChanged: (v) {
                      group[k].forEach((g) {
                        if (v.contains(g["id"])) {
                          g["checked"] = true;
                        } else {
                          g["checked"] = false;
                        }
                      });
                    },
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildDate(dynamic row) {
    var type = jsonDecode(row["question"]["params"]);
    return Container(
      padding: EdgeInsets.all(5.0),
      child: FormBuilderDateTimePicker(
        initialValue:
            row["value"] == null ? null : DateTime.parse(row["value"]),
        inputType: type == "date" ? InputType.date : InputType.both,
        format: DateFormat("yyyy-MM-dd" + (type == "date" ? "" : " HH:mm:ss")),
        onChanged: (v) {
          if (v != null) {
            var d = formatDate(
                v, [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
            if (type == "date") {
              d = formatDate(v, [yyyy, "-", mm, "-", dd]);
            }
            row["value"] = d;
            row["name"] = d;
          } else {
            row["value"] = null;
            row["name"] = null;
          }
        },
        decoration: InputDecoration(
          hintText: '请输入',
          contentPadding:
              const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15.0),
              borderSide: BorderSide(width: 1.0, style: BorderStyle.solid)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15.0),
              borderSide: BorderSide(width: 1.0, style: BorderStyle.solid)),
          filled: true,
        ),
      ),
    );
  }

  _buildUpload(dynamic row) {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: Center(
        child: OutlinedButton(
          child: Container(
            height: 70.0,
            width: 70.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(MdiIcons.fileUpload),
                Text("选择文件"),
              ],
            ),
          ),
          onPressed: () async {
            var url = await uploadFile(title: "文件上传中", type: FileType.any);
            if (url == null) {
              return;
            }
            showSuccessToast("上传成功");
            row["value"] = url;
          },
        ),
      ),
    );
  }

  Widget _buildSelect(dynamic row) {
    var params = jsonDecode(row["question"]["params"]);
    return Container(
      padding: EdgeInsets.all(5.0),
      child: row['hide'] != true
          ? FormBuilderTextField(
              readOnly: true,
              initialValue: row["name"],
              decoration: InputDecoration(
                hintText: '请选择',
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.0),
                    borderSide:
                        BorderSide(width: 1.0, style: BorderStyle.solid)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15.0),
                    borderSide:
                        BorderSide(width: 1.0, style: BorderStyle.solid)),
                filled: true,
              ),
              onTap: () {
                setState(() {
                  row['hide'] = true;
                });
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SelectPage(
                        title: "选择数据",
                        url: params["url"],
                        queryParams: {"nameMore": "yes"},
                        searchText: "输入名称进行搜索",
                      ),
                    )).then((value) {
                  if (value != null) {
                    setState(() {
                      row["value"] = value["id"];
                      row["name"] = value["name"];
                      row['hide'] = false;
                    });
                  } else {
                    setState(() {
                      row['hide'] = null;
                    });
                  }
                });
              },
            )
          : null,
    );
  }

  String getChar(int i) {
    return 'abcdefghijklmnopqrstuvwxyz'
        .characters
        .characterAt(i - 1)
        .string
        .toUpperCase();
  }

  save() async {
    var results = [], totalScore = 0;
    rows.forEach((r) {
      List<dynamic> options = r["options"];
      if (r["question"]["typeName"] == "questionStars") {
        var values = [], names = [], score = 0;
        options.forEach((o) {
          values.add(o["value"]);
          names.add(o["name"]);
          score = score + (int.tryParse(o["value"].toString()) ?? 0);
        });
        results.add({
          "questionId": r["question"]["id"],
          "sort": r["question"]["sort"],
          "score": score,
          "value": jsonEncode({
            "name": names,
            "value": values,
          })
        });
        totalScore = totalScore + score;
      } else if (r["question"]["typeName"] == "questionGroupRadio" ||
          r["question"]["typeName"] == "questionGroupCheck") {
        var values = [], names = [], writes = [], score = 0;
        options.forEach((o) {
          if (o["checked"] == true) {
            values.add(o["id"]);
            names.add(o["name"]);
            writes.add(o["write"]);
            score = score + (int.tryParse(o["name"]) ?? 0);
          }
        });
        results.add({
          "questionId": r["question"]["id"],
          "sort": r["question"]["sort"],
          "score": score,
          "value": jsonEncode({
            "name": names,
            "value": values,
            "write": writes,
          })
        });
        totalScore = totalScore + score;
      } else if (r["question"]["typeName"] == "questionListRadio") {
        var values = [], names = [], writes = [], index = 0, score = 0;
        options.forEach((o) {
          index++;
          if (o["value"] != null) {
            values.add("${index}_" + o["id"]);
            writes.add(o["value"]);
            names.add(o["name"]);
            score = score + (int.tryParse(o["value"].toString()) ?? 0);
          }
        });
        results.add({
          "questionId": r["question"]["id"],
          "sort": r["question"]["sort"],
          "score": score,
          "value": jsonEncode({
            "name": names,
            "value": values,
            "write": writes,
          })
        });
        totalScore = totalScore + score;
      } else if (r["question"]["typeName"] == "questionListCheck") {
        var values = [], names = [], index = 0, score = 0, cache = {};
        List<dynamic> params = jsonDecode(r["question"]["params"]);
        for (var i = 0; i < params.length; i++) {
          cache[params[i].toString()] = i;
        }
        options.forEach((o) {
          if (o["value"] != null) {
            List<dynamic> vs = o["value"];
            for (var i = 0; i < vs.length; i++) {
              values.add("${index}_${cache[vs[i].toString()]}");
              names.add("${o["name"]}(${vs[i]})");
              score = score + (int.tryParse(vs[i].toString()) ?? 0);
            }
            index++;
          }
        });
        results.add({
          "questionId": r["question"]["id"],
          "sort": r["question"]["sort"],
          "score": score,
          "value": jsonEncode({
            "name": names,
            "value": values,
          })
        });
        totalScore = totalScore + score;
      } else {
        int score = 0;
        if (r["name"] is List) {
          List<dynamic> s = r["name"] as List<dynamic>;
          s.forEach((e) {
            score = score + (int.tryParse(e) ?? 0);
          });
        } else {
          score = int.tryParse((r["name"] ?? r["value"]) ?? "0") ?? 0;
        }
        results.add({
          "questionId": r["question"]["id"],
          "sort": r["question"]["sort"],
          "score": score,
          "value": jsonEncode({
            "name": r["name"],
            "value": r["value"],
            "write": r["write"],
          }),
        });
        totalScore = totalScore + score;
      }
    });
    var index = -1;
    for (var i = 0; i < rows.length; i++) {
      dynamic r = rows[i];
      if (r["question"]["required"] == true) {
        dynamic res = jsonDecode(results[i]["value"]);
        if (res["value"] is List && res["name"] is List) {
          if (res["value"].length == 0 && res["name"].length == 0) {
            index = i;
            break;
          }
        } else {
          if (res["value"] == null && res["name"] == null) {
            index = i;
            break;
          }
        }
      }
    }
    if (index >= 0) {
      showErrorToast("请填写第${index + 1}题!");
      return;
    }
    setState(() {
      loading = true;
    });
    var user = await getCurrentAccount();
    String client = await getDeviceName();
    post("/surveyresult/saveAnswer", {
      "data": results,
      "result": {
        "name": title,
        "staffId": user.staff["id"],
        "startDate": startDate,
        "surveyRecordId": routeData["key"],
        "status": 1,
        "totalScore": totalScore,
        "platform": client,
      }
    }).then((res) {
      if (res["success"]) {
        setState(() {
          saveFlag = true;
          loading = false;
        });
      }
    });
  }
}
