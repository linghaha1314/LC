import 'dart:core';

import 'package:csc_app/component/LoadingProgress.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/page/process/opentraining/CurrentReservationPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../opentraining/OpenTrainingPage.dart';

class OpenPlacePage extends BaseApp {
  @override
  _OpenPlacePageState createState() => new _OpenPlacePageState();
}

class _OpenPlacePageState extends BaseAppPage<OpenPlacePage>
    with SingleTickerProviderStateMixin {
  RefreshController recordController1 = RefreshController(initialRefresh: true);
  RefreshController recordController2 = RefreshController(initialRefresh: true);

  var tabController;

  _OpenPlacePageState() {
    title = "预约教室列表";
  }

  @override
  void initState() {
    super.initState();
    tabController = TabController(
      vsync: this,
      length: 2,
      initialIndex: 0,
    );
    empty = false;
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
          controller: this.tabController,
          tabs: <Tab>[
            Tab(text: '按场地'),
            Tab(text: '按训练项'),
          ],
        ),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.history),
        onPressed: () {
          //跳转至已预约列表
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new CurrentReservationPage()),
          );
        },
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: [
        RefreshList(
          controller: recordController1,
          searchText: "请输入场地进行搜索",
          url: "/opentraining/listByPlace",
          buildItem: (dynamic row, int i) {
            return _bodyContentOne(row);
          },
        ),
        RefreshList(
          controller: recordController2,
          searchText: "请输入训练项或场地进行搜索",
          url: "/opentraining/listOpenQueryByPage",
          buildItem: (dynamic row, int i) {
            return _bodyContentTwo(row);
          },
        ),
      ],
    );
  }

  Widget _bodyContentOne(data) {
    return ListTile(
      title: Text(showString(data["name"])),
      subtitle: Text(showString(data["itemName"])),
      onTap: () async{
        List<dynamic> rows = [];
        showLoading(title: '加载中...');
        var res = await post("/opentraining/listOpenQueryByPage", {"placeId": data["id"]});
        rows = res["rows"];
        showLoading(close: true);
        showBarModalBottomSheet(
          context: globalContent,
          builder: (context) => Material(
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: rows.map((e) {
                  return _bodyContentTwo(e);
                }).toList(),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _bodyContentTwo(data) {
    return ListTile(
      title: Text(data["itemName"] != null ? data["itemName"] : ''),
      subtitle: Text(
          "${data["buildingName"]}-${data["floor"].toString()}F-${data["roomNo"].toString()}-${data["placeName"]}"),
      onTap: () {
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new OpenTrainingPage(data)),
        ).then((value) {});
      },
    );
  }
}
