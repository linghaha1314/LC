import 'package:csc_app/component/ApprovalStatus.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import 'CurrentReservationView.dart';
import '../../../ThemeColor.dart';

class CurrentReservationPage extends BaseApp {
  @override
  _CurrentReservationPageState createState() =>
      new _CurrentReservationPageState();
}

class _CurrentReservationPageState extends BaseAppPage<CurrentReservationPage> {
  dynamic viewDataList;
  RefreshController recordController = RefreshController(initialRefresh: true);

  _CurrentReservationPageState() {
    title = "已预约的开放训练列表";
  }

  @override
  void initState() {
    super.initState();
    this.empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
        controller: recordController,
        searchText: "请输入场地名称进行搜索",
        url: "/reservation/getCurrentReservationList",
        queryKey: "placeName",
        buildItem: (dynamic row, int i) {
          return _buildList(row);
        });
  }

  _bodyContent(data) {
    var reservation = data["reservation"];
    List<dynamic> list = data["itemList"];
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("预约场地:" +
                  (reservation["openTrainingName"] != null
                      ? reservation["openTrainingName"]
                      : '无')),
              Column(
                children: list.map((e) {
                  return Text(
                    "${e["itemName"]} 预约时间:${e["date"]} ${e["dateTime"]}",
                    style: TextStyle(fontSize: 12),
                    softWrap: true,
                  );
                }).toList(),
              )
            ],
          ),
          (reservation["status"] == 5 || reservation["status"] == 3)
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Chip(
                      backgroundColor: ThemeColor.getColor("active"),
                      label: Row(
                        children: [
                          Text(
                            reservation["status"] == 5 ? "已取消" : "已过期",
                            style: TextStyle(
                              color: ThemeColor.getColor("fontColor"),
                            ),
                          ),
                          reservation["status"] == 5
                              ? Icon(
                                  Icons.cancel,
                                  color: ThemeColor.getColor("fontColor"),
                                )
                              : Icon(
                                  Icons.autorenew,
                                  color: ThemeColor.getColor("fontColor"),
                                ),
                        ],
                      ),
                    ),
                  ],
                )
              : ApprovalStatus(status: reservation["status"]),
        ],
      ),
      onTap: () {
        //跳转到详情页面
        Navigator.push(
                context,
                new MaterialPageRoute(
                    builder: (context) => new CurrentReservationView(data)))
            .then((value) {
          if (value) {
            recordController.requestRefresh();
          }
        });
      },
    );
  }

  _buildList(data) {
    var reservation = data["reservation"];
    List<dynamic> list = data["itemList"];
    return ListTile(
      title: Text("预约场地:" +
          (reservation["openTrainingName"] != null
              ? reservation["openTrainingName"]
              : '无')),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: list.map((e) {
          return Text(
            "${e["itemName"]} 预约时间:${e["date"]} ${e["dateTime"]}",
            style: TextStyle(
                fontSize: 12, color: ThemeColor.getColor("fontColor")),
            softWrap: true,
          );
        }).toList(),
      ),
      trailing: (reservation["status"] == 5 || reservation["status"] == 3)
          ? Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Chip(
                  backgroundColor: ThemeColor.getColor("active"),
                  label: Row(
                    children: [
                      Text(
                        reservation["status"] == 5 ? "已取消" : "已过期",
                        style: TextStyle(
                          color: ThemeColor.getColor("fontColor"),
                        ),
                      ),
                      reservation["status"] == 5
                          ? Icon(
                              Icons.cancel,
                              color: ThemeColor.getColor("fontColor"),
                            )
                          : Icon(
                              Icons.autorenew,
                              color: ThemeColor.getColor("fontColor"),
                            ),
                    ],
                  ),
                ),
              ],
            )
          : ApprovalStatus(status: reservation["status"]),
      onTap: () {
        //跳转到详情页面
        Navigator.push(
                context,
                new MaterialPageRoute(
                    builder: (context) => new CurrentReservationView(data)))
            .then((value) {
          if (value) {
            recordController.requestRefresh();
          }
        });
      },
    );
  }
}
