import 'package:csc_app/component/ApprovalStatus.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/utils/Help.dart';

import '../../../ThemeColor.dart';

class CurrentReservationView extends BaseApp {
  final dynamic data;

  CurrentReservationView(this.data) : super();

  @override
  CurrentReservationViewPage createState() =>
      new CurrentReservationViewPage(this.data);
}

class CurrentReservationViewPage extends BaseAppPage<CurrentReservationView> {
  final dynamic viewData;
  dynamic openTraining;

  CurrentReservationViewPage(this.viewData) {
    this.title = "预约训练详情";
  }

  @override
  void initState() {
    super.initState();
    this.empty = false;
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () async {
          var path = await getHttpPath();
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => WebViewPage(
                    url:
                        "$path/flowview/${viewData["processInstanceId"]}?type=f")),
          );
        },
        icon: Icon(Icons.menu),
        tooltip: "审批进程",
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    var reservation = this.viewData["reservation"];
    var itemList = this.viewData["itemList"];
    var memberList = this.viewData["memberList"];
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "预约基本信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              margin: EdgeInsets.all(0.0),
              child: Column(
                children: ListTile.divideTiles(
                  color: ThemeColor.getColor("border"),
                  tiles: [
                    _textView("预约场地", reservation["openTrainingName"]),
                    Divider(),
                    ListTile(
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "预约状态",
                            style: TextStyle(fontSize: 14),
                          ),
                          reservation["status"] == 5
                              ? Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Chip(
                                      backgroundColor:
                                          ThemeColor.getColor("active"),
                                      label: Row(
                                        children: [
                                          Text(
                                            "已取消",
                                            style: TextStyle(
                                              color: ThemeColor.getColor(
                                                  "fontColor"),
                                            ),
                                          ),
                                          Icon(
                                            Icons.cancel,
                                            color: ThemeColor.getColor(
                                                "fontColor"),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                )
                              : ApprovalStatus(status: reservation["status"])
                        ],
                      ),
                    ),
                    Divider(),
                    _textView("预约参与人数", memberList.length.toString()),
                    Divider(),
                    _textView("申请时间", reservation["created"].toString()),
                    Divider(),
                    _textView("预约类型", reservation["typeName"].toString()),
                    Divider(),
                    _textView("申请人", reservation["userName"].toString()),
                  ],
                ).toList(),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "训练项信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              margin: EdgeInsets.all(0.0),
              child: Column(
                children: ListTile.divideTiles(
                  color: ThemeColor.getColor("border"),
                  tiles: itemList.map<Widget>((item) {
                    return ListTile(
                      title: Row(
                        children: [
                          Text(
                            item["itemName"],
                            style: TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                      subtitle: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            item["date"],
                            style: TextStyle(fontSize: 14),
                          ),
                          Text(
                            item["dateTime"],
                            style: TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                ).toList(),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "参与人员信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              margin: EdgeInsets.all(0.0),
              child: Column(
                children: ListTile.divideTiles(
                  color: ThemeColor.getColor("border"),
                  tiles: memberList.map<Widget>((member) {
                    return _textView(member["staffName"], member["mobile"]);
                  }).toList(),
                ).toList(),
              ),
            ),
          ),
          Visibility(
            visible: reservation["status"] == 2,
            child: Container(
              child: ElevatedButton(
                  child: Text("取消预约"),
                  onPressed: () {
                    showConfirmAlert("是否确定取消此次预约吗?").then((value) {
                      if (value) {
                        this.cancelReservation();
                      }
                    });
                  }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _textView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 14),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  cancelReservation() async {
    post("/reservation/cancelReservation",
        {"reservationId": this.viewData["reservation"]["id"]}).then((value) {
      if (value["success"]) {
        Navigator.of(context).pop(true);
        showSuccessToast("取消预约成功！");
      }
    }).catchError((err) {
      showErrorAlert(err["msg"]);
    });
  }
}
