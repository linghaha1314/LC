import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:intl/intl.dart';
import '../../../ThemeColor.dart';

import './OpenTrainingForm.dart';

class ReservationView extends BaseApp {
  final dynamic params;

  ReservationView(this.params) : super();

  @override
  _ReservationViewState createState() => new _ReservationViewState(params);
}

class _ReservationViewState extends BaseAppPage<ReservationView> {
  dynamic data;
  dynamic openTraining;
  bool isStudent = false;
  List dataList;
  String day;
  String date;

  _ReservationViewState(params) {
    this.data = params["reserveData"];
    this.openTraining = params["openTraining"];
    this.isStudent = params["isStudent"];
    title = "已预约训练详情";
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    initReservationSessionData();
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.only(left: 5.0, right: 5.0, top: 16.0, bottom: 16.0),
        child: Column(
          children: [
            Card(
              child: Container(
                alignment: Alignment.topLeft,
                margin: EdgeInsets.all(0.0),
                child: Column(
                  children: ListTile.divideTiles(
                    color: ThemeColor.getColor("border"),
                    tiles: [
                      _textView("预约时段", this.date),
                      Divider(),
                      _textView("场地容量", data["maxCount"].toString()),
                      Divider(),
                      _textView("已预约数", data["number"].toString()),
                      Divider(),
                      _textView("训练项", data["trainingItemName"].toString()),
                      Divider(),
                      _textView(
                          "预约班级",
                          data["className"] != null
                              ? data["className"].toString()
                              : "无"),
                      Divider(),
                      _textView("申请人", data["reservationStaffName"].toString()),
                      Divider(),
                    ],
                  ).toList(),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 10),
              child: ElevatedButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [Text("一起上课"), Icon(Icons.arrow_forward)],
                ),
                onPressed: () {
                  this.dataList.forEach((d) {
                    DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm");
                    d["millisecond"] = dateFormat
                        .parse("2021-11-11 " + d["startTime"])
                        .millisecondsSinceEpoch;
                  });
                  this.dataList.sort((left, right) =>
                      left["millisecond"].compareTo(right["millisecond"]));
                  var params = {
                    "openTraining": this.openTraining,
                    "day": this.day,
                    "dataList": this.dataList,
                    "isStudent": isStudent,
                    "share": true,
                    "number": this.data["number"]
                  };
                  Navigator.push(
                      context,
                      new MaterialPageRoute(
                          builder: (context) =>
                              new OpenTrainingForm(params))).then((value) {
                    if (value) {
                      showSuccessAlert("预约成功!");
                      Navigator.pop(context, true);
                    }
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  _textView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 14),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }

  initReservationSessionData() {
    var params = {"reservationId": this.data["reservationId"]};
    post("/session/listByReservationId", params).then((res) {
      if (res["total"] > 0) {
        List list = res["rows"];
        this.dataList = list;
        this.day = list[0]["date"];
        var date =
            "${list[0]["date"]} ${list[0]["startTime"]}-${list[list.length - 1]["endTime"]}";
        setState(() {
          this.date = date;
        });
      }
    }).catchError((onError) {
      loading = false;
      showErrorAlert(onError["msg"]);
    });
  }
}
