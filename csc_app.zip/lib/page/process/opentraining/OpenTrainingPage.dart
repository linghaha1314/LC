import 'dart:core';
import 'dart:convert';

import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:intl/intl.dart';
import '../../../ThemeColor.dart';
import './OpenTrainingForm.dart';
import './ReservationView.dart';

class OpenTrainingPage extends BaseApp {
  final dynamic data;

  OpenTrainingPage(this.data);

  @override
  _OpenTrainingPageState createState() => new _OpenTrainingPageState(data);
}

class _OpenTrainingPageState extends BaseAppPage<OpenTrainingPage>
    with SingleTickerProviderStateMixin {
  dynamic openTrainingData;
  double boxWidth = 85;
  double boxHeight = 80;
  var dateList = [];
  var sessionList = [];
  DateTime startDate;
  DateTime endDate;
  dynamic userInfo;
  List sessionDataList = [];
  List selectedList = [];
  String selectedDay;

  _OpenTrainingPageState(data) {
    this.openTrainingData = data;
    title = "选择预约日期";
  }

  @override
  void initState() {
    super.initState();
    changeDate();
    getSessionList();
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      appBar: getAppBar(context),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      TextButton(
        child: Text("下一步"),
        onPressed: () async {
          if (this.selectedList.length == 0) {
            return showErrorToast("请选择预约时段");
          }
          var msg = openTrainingData["notice"];
          if (msg != null && msg.trim().length > 0) {
            var s = MediaQuery.of(context).size;
            var flag = await showConfirmAlert(msg,
                ok: "我同意", height: s.height * 0.95, width: s.width * 0.9);
            if (!flag) {
              return;
            }
          }
          this.selectedList.forEach((d) {
            DateFormat dateFormat = DateFormat("yyyy-MM-dd HH:mm");
            d["millisecond"] = dateFormat
                .parse("2021-11-11 " + d["startTime"])
                .millisecondsSinceEpoch;
          });
          this.selectedList.sort((left, right) =>
              left["millisecond"].compareTo(right["millisecond"]));
          var userInfo = await getCurrentAccount();
          bool isStudent = userInfo.role["code"] == "student";
          var currentYear = startDate.year;
          // 跨年处理
          if (selectedDay.split("-")[0] == '01' && startDate.month == 12) {
            currentYear = endDate.year;
          }
          var params = {
            "openTraining": this.openTrainingData,
            "day": "$currentYear-${this.selectedDay}",
            "dataList": this.selectedList,
            "isStudent": isStudent,
            "share": false
          };
          Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => new OpenTrainingForm(params)))
              .then((value) {
            if (value) {
              showSuccessAlert("预约提交成功,请等待审核通过!");
              selectedList = [];
              getSessionList();
              Navigator.pop(context, true);
            }
          });
        },
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: [
        Expanded(
          flex: 1,
          child: Scrollbar(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: SingleChildScrollView(
                child: Container(
                  margin: EdgeInsets.only(top: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("请选择您可预约的时间段,选择后点击下一步,请确认好您的时间再进行预约,请勿将自己账号借用他人使用"),
                      _weekDayView(), //创建日期行的数据视图
                      ..._sessionListView() //根据session数据创建每一行的视图
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: ThemeColor.getColor("toolbar"),
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                  color: Colors.black12,
                  offset: Offset(0.0, 15.0), //阴影xy轴偏移量
                  blurRadius: 15.0, //阴影模糊程度
                  spreadRadius: 10.0 //阴影扩散程度
                  )
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              OutlinedButton.icon(
                onPressed: () {
                  if (startDate
                          .subtract(new Duration(days: 1))
                          .millisecondsSinceEpoch <
                      DateTime.now().millisecondsSinceEpoch) {
                    showErrorAlert("不能预约过去的日期!");
                    return;
                  }
                  selectedList = [];
                  setState(() {
                    loading = true;
                  });
                  startDate = startDate.subtract(new Duration(days: 7));
                  changeDate();
                  getReservationList();
                },
                label: Text("上一周"),
                icon: Icon(Icons.arrow_back),
              ),
              OutlinedButton.icon(
                onPressed: () {
                  selectedList = [];
                  setState(() {
                    loading = true;
                  });
                  startDate = startDate.add(new Duration(days: 7));
                  changeDate();
                  getReservationList();
                },
                label: Text("下一周"),
                icon: Icon(Icons.arrow_forward),
              ),
            ],
          ),
        ),
      ],
    );
  }

  changeDate() {
    if (startDate == null) {
      startDate = new DateTime.now();
    }
    setDateList(startDate, true);
    for (var i = 0; i < 6; i++) {
      DateTime currentDay = startDate.add(new Duration(days: i + 1));
      setDateList(currentDay, false);
      if (i == 5) {
        endDate = currentDay;
      }
    }
  }

  _weekDayView() {
    this.dateList = [];
    changeDate();
    List<Widget> weekDayViewList = [];
    this.dateList.forEach((item) {
      weekDayViewList.add(_weekDayItemView(item));
    });
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        SizedBox(
          width: boxWidth,
        ),
        ...weekDayViewList
      ],
    );
  }

  _weekDayItemView(data) {
    return Container(
        margin: EdgeInsets.only(top: 10),
        width: boxWidth,
        height: 45,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(data["name"]),
            Text(data["dateStr"]),
          ],
        ));
  }

  setDateList(DateTime dateTime, bool isToday) {
    var weekDayList = [
      {"weekIndex": 1, "name": "周一"},
      {"weekIndex": 2, "name": "周二"},
      {"weekIndex": 3, "name": "周三"},
      {"weekIndex": 4, "name": "周四"},
      {"weekIndex": 5, "name": "周五"},
      {"weekIndex": 6, "name": "周六"},
      {"weekIndex": 7, "name": "周日"},
    ];
    int index = dateTime.weekday - 1;
    var month;
    var day;
    if (dateTime.month < 10) {
      month = "0${dateTime.month}";
    } else {
      month = dateTime.month;
    }
    if (dateTime.day < 10) {
      day = "0${dateTime.day}";
    } else {
      day = dateTime.day;
    }
    this.dateList.add({
      ...weekDayList[index],
      "dateStr": "$month-$day",
      "isToday": isToday,
      "dataList": []
    });
  }

  //循环遍历所有session
  _sessionListView() {
    List<Widget> list = [];
    sessionDataList.forEach((item) {
      //根据session创建这一行的视图
      list.add(sessionRowView(item));
    });
    return list;
  }

  //创建当前session行的视图
  sessionRowView(data) {
    List<Widget> list = [_timeBox(data["session"])];
    List dateList = data["dateList"]; //日期数组
    dateList.forEach((date) {
      //根据每一天的日期数据创建视图
      list.add(_boxView(data["session"], date));
    });
    return Row(
      children: list,
    );
  }

  //节次单元格
  _timeBox(session) {
    return Container(
        width: boxWidth,
        height: boxHeight,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(session["startTime"]),
            Text("-"),
            Text(session["endTime"]),
          ],
        ),
        decoration: _decoration(null));
  }

  //数据单元格设置
  _boxView(session, date) {
    List dataList = date["dataList"];
    if (dataList != null && dataList.length > 0) {
      //开放信息不为空
      bool classed = false; //是否被课表课程占用
      bool reserved = false; //是否被预约了
      bool invalid = false; //是否失效了
      var reserveData;
      var reservationUserIds;
      dataList.forEach((element) {
        if (element["timeFlag"] == 0) {
          invalid = true;
        }
        if (element["curriculumId"] != null) {
          classed = true;
        }
        if (element["reservationItemId"] != null) {
          reserveData = element;
          reserved = true; //预约Id不为空，则已被预约
        }
        if (element["reservationUserIds"] != null) {
          reservationUserIds = element["reservationUserIds"];
        }
      });
      if (invalid) {
        return _invalidBox("已失效");
      }
      if (classed) {
        return _invalidBox("课程占用");
      }
      if (reservationUserIds != null &&
          reservationUserIds.toString().indexOf(userInfo.accounts["id"]) !=
              -1) {
        return _invalidBox("您已预约"); //未约满 但是未共享
      }
      if (reserved) {
        if (reserveData["number"] >= reserveData["maxCount"]) {
          return _invalidBox("已约满");
        }
        if (false == reserveData["shareFlag"]) {
          return _invalidBox("已预约"); //未约满 但是未共享
        }
        return _reservedBox(reserveData);
      } else {
        return _reservationBox(date);
      }
    } else {
      return _invalidBox("未开放");
    }
  }

  //已预约单元格
  _reservedBox(reserveData) {
    return InkWell(
        onTap: () async {
          var userInfo = await getCurrentAccount();
          bool isStudent = userInfo.role["code"] == "student";
          var params = {
            "openTraining": this.openTrainingData,
            "day": "",
            "dataList": [],
            "isStudent": isStudent,
            "reserveData": reserveData
          };
          Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => new ReservationView(params)))
              .then((value) {
            if (value) {
              showSuccessAlert("预约成功!");
              getSessionList();
            }
          });
        },
        child: Container(
            width: boxWidth,
            height: boxHeight,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
//                Text("${reserveData["trainingItemName"]}"),
                Text("${reserveData["number"]}/${reserveData["maxCount"]}")
              ],
            ),
            decoration: _decoration(null)));
  }

  //待预约单元格
  _reservationBox(date) {
    List dataList = date["dataList"];
    bool selected = date["selected"];
    return InkWell(
        onTap: () async {
          selected = !selected;
          String day = date["dateStr"];
          if (selected) {
            var userInfo = await getCurrentAccount();
            bool isStudent = userInfo.role["code"] == "student";
            if (isStudent && selectedList.length > 0) {
              return showErrorToast("不能预约多节次");
            }
            if (selectedDay != null && selectedDay != day) {
              return showErrorToast("不能跨天预约");
            }
            if (openTrainingData["status"] == 1 && selectedList.length >= 1) {
              return showErrorToast("此场地不能预约多节次");
            }
            this.selectedList.addAll(dataList);
          } else {
            dataList.forEach((element) {
              this.selectedList.remove(element);
            });
            if (this.selectedList.length == 0) {
              day = null;
            }
          }
          setState(() {
            this.selectedDay = day;
            date["selected"] = selected;
          });
        },
        child: Container(
          alignment: Alignment.center,
          width: boxWidth,
          height: boxHeight,
          decoration:
              _decoration(selected ? ThemeColor.getColor("success") : null),
          child: Visibility(
            visible: selected,
            child: Text("已选择"),
          ),
        ));
  }

  //不可预约单元格
  _invalidBox(title) {
    return Container(
        alignment: Alignment.center,
        width: boxWidth,
        height: boxHeight,
        child: Text(title),
        decoration: _decoration(Colors.black12));
  }

  _decoration(color) {
    return BoxDecoration(
        color: color,
        border: Border(
          top: BorderSide(
            width: 0.5,
            color: ThemeColor.getColor("border"),
          ),
          right: BorderSide(
            width: 0.5,
            color: ThemeColor.getColor("border"),
          ),
        ));
  }

  getSessionList() async {
    setState(() {
      loading = true;
    });
    userInfo = await getCurrentAccount();
    post("/session/listQueryByPage", {}).then((res) {
      if (res["total"] > 0) {
        setState(() {
          sessionList = res["rows"];
        });
        getReservationList();
      }
    }).catchError((onError) {
      loading = false;
      showErrorAlert(onError["msg"]);
    });
  }

  getReservationList() {
    var params = {
      "openTrainingId": openTrainingData["id"],
      "openTrainingItemId": openTrainingData["itemId"],
      "startDate": startDate.toString().substring(0, 19),
      "taskStatus": "1",
      "isReservationStatus": "true",
      "terminationDate": "${endDate.toString().substring(0, 10)} 23:59:59"
    };
    post("/sessiondate/listSessionData", params).then((res) {
      List list = [];
      if (res["total"] > 0) {
        sessionList.forEach((session) {
          var dateList = json.decode(json.encode(this.dateList));
          res["rows"].forEach((item) {
            if (session["startTime"] == item["startTime"] &&
                session["endTime"] == item["endTime"]) {
              dateList.forEach((date) {
                date["selected"] = false;
                var weekIndex = date["weekIndex"];
                var day = item["day"];
                if (weekIndex == day) {
                  date["dataList"].add(item);
                }
              });
            }
          });
          list.add({"session": session, "dateList": dateList});
        });
      } else {
        sessionList.forEach((session) {
          var dateList = json.decode(json.encode(this.dateList));
          list.add({"session": session, "dateList": dateList});
        });
      }
      setState(() {
        loading = false;
        sessionDataList = list;
      });
    }).catchError((onError) {
      loading = false;
      showErrorAlert(onError["msg"]);
    });
  }
}
