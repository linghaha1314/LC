import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter/material.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

import '../../../ThemeColor.dart';
import '../../../utils/Help.dart';

class OpenTrainingForm extends BaseApp {
  final dynamic params;

  OpenTrainingForm(this.params) : super();

  @override
  _OpenTrainingFormState createState() =>
      new _OpenTrainingFormState(this.params);
}

class _OpenTrainingFormState extends BaseAppPage {
  dynamic day;
  List dataList;
  dynamic openTraining;
  dynamic data;
  bool isStudent;
  bool share; //共用教室
  int useNumber = 0; //已预约人数
  Map shareFlagMap = {"是": true, "否": false};
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  final GlobalKey<FormBuilderState> _diaLogKey = GlobalKey<FormBuilderState>();
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  FocusNode focusNode3 = new FocusNode();
  FocusNode focusNode4 = new FocusNode();
  FocusNode nodeCategory = new FocusNode();
  Set sessionDateIdList = new Set();

  _OpenTrainingFormState(params) {
    title = "预约信息确认";
    this.day = params["day"];
    this.dataList = params["dataList"];
    this.openTraining = params["openTraining"];
    this.isStudent = params["isStudent"];
    this.share = params["share"];
    if (params["number"] != null) {
      this.useNumber = params["number"];
    }
    this.dataList.forEach((element) {
      sessionDateIdList.add(element["sessionDateId"]);
    });
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.only(left: 5.0, right: 5.0, top: 16.0, bottom: 16.0),
        child: Column(
          children: [_dataView(), _formBuilderView()],
        ),
      ),
    );
  }

  _dataView() {
    String capacity;
    if (share && useNumber != null) {
      //共享教室
      capacity = "$useNumber/${openTraining["maxCount"].toString()}";
    } else {
      capacity = openTraining["maxCount"].toString();
    }
    return Container(
      child: Column(
        children: <Widget>[
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              margin: EdgeInsets.all(0.0),
              child: Column(
                children: <Widget>[
                  ...ListTile.divideTiles(
                    color: ThemeColor.getColor("border"),
                    tiles: [
                      _textView("训练项", this.openTraining["itemName"]),
                      Divider(),
                      _textView("场地名称", this.openTraining["placeName"]),
                      Divider(),
                      _textView("场地地址",
                          "${openTraining["buildingName"]}-${openTraining["floor"].toString()}F-${openTraining["roomNo"].toString()}-${openTraining["placeName"]}"),
                      Divider(),
                      _textView("场地容量", capacity),
                      Divider(),
                      _textView("预约日期", this.day),
                      Divider(),
                      ListTile(
                        title: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("预约时段 ", style: TextStyle(fontSize: 14)),
                            Column(children: _timeView()),
                          ],
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  _formBuilderView() {
    return Container(
      padding: EdgeInsets.all(5.0),
      child: FormBuilder(
        key: _fbKey,
        initialValue: this.data != null ? data : {},
        child: Column(
          children: [
            Visibility(
              visible: !isStudent,
              child: Column(
                children: [
                  FormBuilderTextField(
                    name: "className",
                    focusNode: focusNode2,
                    decoration: InputDecoration(labelText: "上课班级"),
                    onTap: () async {
                      focusNode2.unfocus();
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SelectPage(
                              title: "选择上课班级",
                              url: "/classes/listQueryByPage",
                              searchText: "输入名称进行搜索",
                            ),
                          )).then((value) {
                        if (value != null) {
                          _fbKey.currentState.setState(() {
                            _fbKey.currentState.fields['className']
                                .didChange(value["name"]);
                            _fbKey.currentState
                                .setInternalFieldValue("classId", value["id"]);
                          });
                        }
                      });
                    },
                  ),
                  FormBuilderTextField(
                    name: "count",
                    focusNode: focusNode3,
                    decoration: InputDecoration(labelText: "上课人员"),
                    onTap: () {
                      focusNode3.unfocus();
                      var classId = _fbKey.currentState.value["classId"];
                      if (classId == null) {
                        return showErrorAlert("请先选择上课班级");
                      }
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SelectPage(
                              labelKey: "studentName",
                              title: "选择上课人员",
                              url: "/studentclasses/listQueryByPage",
                              searchText: "输入名称进行搜索",
                              multiple: true,
                              queryParams: {"classesId": classId},
                            ),
                          )).then((value) {
                        if (value != null) {
                          var staffIdList = [];
                          value.forEach((item) {
                            staffIdList.add(item["staffId"]);
                          });
                          _fbKey.currentState.setState(() {
                            _fbKey.currentState.fields['count']
                                .didChange("已选${value.length}人");
                            _fbKey.currentState.setInternalFieldValue(
                                "staffIdList", staffIdList);
                          });
                        }
                      });
                    },
                  ),
                  FormBuilderTextField(
                    name: "number",
                    focusNode: focusNode4,
                    decoration: InputDecoration(labelText: "上课人数(必填)"),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: "请输入上课人数!",
                      ),
                    ]),
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    onChanged: (number) {
                      int capacity;
                      if (share && useNumber != null) {
                        //共享教室
                        capacity =
                            (openTraining["maxCount"] - useNumber).toInt();
                      } else {
                        capacity = openTraining["maxCount"].toInt();
                      }
                      if (int.parse(number) > capacity) {
                        _fbKey.currentState.fields['number']
                            .didChange(capacity.toString());
                      }
                    },
                  ),
                  FormBuilderTextField(
                    readOnly: true,
                    name: "categoryName",
                    focusNode: nodeCategory,
                    decoration: InputDecoration(labelText: "本科/毕业后(必选)"),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: "请选择预约类型!",
                      ),
                    ]),
                    onTap: () async {
                      nodeCategory.unfocus();
                      showDictionaryData((value) {
                        _fbKey.currentState.setState(() {
                          _fbKey.currentState.fields['categoryName']
                              .didChange(value["name"]);
                          _fbKey.currentState
                              .setInternalFieldValue("categoryId", value["id"]);
                        });
                      }, url: "/dictionarydata/listQueryByTypeCode/reservationType");
                    },
                  ),
                  FormBuilderTextField(
                    name: "name",
                    decoration: InputDecoration(labelText: "课程/培训名称(必填)"),
                    validator: FormBuilderValidators.compose([
                      FormBuilderValidators.required(
                        errorText: "请输入课程/培训名称!",
                      ),
                    ]),
                  ),
                ],
              ),
            ),
            FormBuilderTextField(
              name: "remark",
              maxLines: 2,
              decoration: InputDecoration(labelText: "训练项目及模型耗材"),
            ),
            Container(
              margin: EdgeInsets.only(top: 10),
              child: ElevatedButton(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [Text("保存"), Icon(Icons.check)],
                ),
                onPressed: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                  if (_fbKey.currentState.saveAndValidate()) {
                    save(context);
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  _timeView() {
    List<Widget> list = [];
    Set setArray = new Set();
    this.dataList.forEach((item) {
      setArray.add("${item["startTime"]}-${item["endTime"]}");
    });
    setArray.forEach((item) {
      list.add(Text(item, style: TextStyle(fontSize: 14)));
    });
    return list;
  }

  _textView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            flex: 1,
            child: Text(
              name,
              style: TextStyle(fontSize: 14),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              value != null ? value : "",
              style: TextStyle(fontSize: 14),
              textAlign: TextAlign.end,
            ),
          ),
        ],
      ),
    );
  }

  _saveDiaAlertDialog(context, formValue, number) {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('是否允许共享教室'),
            content: SingleChildScrollView(
              child: FormBuilder(
                key: _diaLogKey,
                initialValue: {},
                child: FormBuilderRadioGroup(
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(
                      errorText: "请选择是否允许共享教室!",
                    ),
                  ]),
                  options: ['是', '否']
                      .map((lang) => FormBuilderFieldOption(value: lang))
                      .toList(growable: false),
                  name: "shareFlag",
                ),
              ),
            ),
            actions: <Widget>[
              new TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text("取消"),
              ),
              new TextButton(
                child: new Text('确定'),
                onPressed: () {
                  FocusScope.of(context).requestFocus(new FocusNode());
                  if (_diaLogKey.currentState.saveAndValidate()) {
                    Navigator.of(context).pop();
                    submit(formValue, number);
                  }
                },
              ),
            ],
          );
        });
  }

  save(context) {
    dynamic formValue = Map.of(_fbKey.currentState.value);
    if (!isStudent) {
      if ((formValue["number"] == null || formValue["number"] == '') &&
          (formValue["staffIdList"].length == 0)) {
        showErrorToast("请检查是否填写完整！");
        return;
      }
    }
    formValue["trainingItemId"] = this.openTraining["itemId"];
    var number = isStudent
        ? 1
        : ((formValue["staffIdList"] != null &&
                formValue["staffIdList"].length != 0)
            ? formValue["staffIdList"].length
            : int.parse(formValue["number"]));
    if (number + useNumber > this.openTraining["maxCount"]) {
      showErrorToast("申请人数不能大于剩余人数");
      return;
    }
    if (!isStudent &&
        useNumber == 0 &&
        number < this.openTraining["maxCount"]) {
      _saveDiaAlertDialog(context, formValue, number);
    } else {
      submit(formValue, number, shareFlag: true);
    }
  }

  submit(formValue, number, {bool shareFlag = false}) async {
    setState(() {
      loading = true;
    });
    var userInfo = await getCurrentAccount();
    String taskName =
        "【${userInfo.staff["name"]}${isStudent ? '同学' : '老师'}】于【${this.day + ' ' + dataList[0]["startTime"] + '至' + dataList[dataList.length - 1]["endTime"]}】申请使用【${this.openTraining["placeName"]}】实验室进行【${this.openTraining["itemName"]}】训练";
    if (!isStudent) {
      taskName = taskName +
          ",上课人数【$number】,预约类型【${formValue["categoryName"]}】,培训/课程名称【${formValue["name"]}】";
    }
    if (_diaLogKey.currentState != null) {
      var dialogValue = _diaLogKey.currentState.value;
      shareFlag = this.shareFlagMap[dialogValue["shareFlag"]];
    }
    var date = "$day ${dataList[0]["startTime"]}:00";
    formValue["urgentStatus"] = 0;
    var params = {
      "openTrainingId": this.openTraining["id"],
      "typeCode": isStudent ? "personal_open_training" : "class_open_training",
      "staffIdList": isStudent ? null : formValue["staffIdList"],
      "number": number,
      "maxCount": this.openTraining["maxCount"],
      "remark": formValue["remark"],
      "classId": formValue["classId"],
      "name": formValue["name"],
      "categoryId": formValue["categoryId"],
      "day": this.day,
      "date": date,
      "share": this.share,
      "shareFlag": shareFlag,
      "taskName": taskName,
      "sessionDateIdList": this.sessionDateIdList.toList(),
      "trainingItemId": formValue["trainingItemId"]
    };
    post("/reservation/applyReservation", params).then((value) {
      setState(() {
        loading = false;
      });
      if (value["success"] == true) {
        if (this.share) {
          Navigator.pop(context, true);
        }
        Navigator.pop(context, true);
      }
    }).catchError((error) {
      showErrorAlert(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }
}
