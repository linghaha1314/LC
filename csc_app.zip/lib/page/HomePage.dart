import 'dart:convert';
import 'dart:io';

import 'package:badges/badges.dart' as badges;
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/page/MessagePage.dart';
import 'package:csc_app/page/MinePage.dart';
import 'package:csc_app/page/WorkbenchPage.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import '../ThemeColor.dart';
import 'ContactPersonPage.dart';

class Home extends BaseApp {
  @override
  HomePage createState() => HomePage();
}

class HomePage extends BaseAppPage<Home>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  int pageIndex = 0;

  ConfigService configService = ConfigService();

  List<Widget> pageList = [
    MessagePage(),
    ContactPersonPage(),
    Workbench(),
    Mine()
  ];

  int unReadTotal = 0;

  HomePage() {
    empty = false;
    barFlag = false;
  }

  clearReadTotal() {
    setState(() {
      unReadTotal = 0;
    });
  }

  addUnreadTotal({int size = 1}) {
    if (size == null) return;
    setState(() {
      unReadTotal = unReadTotal + size;
    });
  }

  initContext() {
    initToastContent(context);
  }

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    super.initState();
    initContext();
    homePage = this;
    _saveDeviceInfo();
    initWatermark();
    configService.getTheme().then((dynamic v) {
      if (v != null) {
        if (v["opacity"] != null) {
          ThemeColor.opacity = double.parse(v["opacity"]);
        }
        if (v["theme"] != null) {
          ThemeColor.themeIndex = int.parse(v["theme"]);
        }
        if (v["background"] != null && File(v["background"]).existsSync()) {
          ThemeColor.background = v["background"];
        }
      }
      ThemeColor.changeTheme(context);
    });
    startConnectSocket();
    _initUserInfo();
    if (kIsWeb != true) {
      initNotify(context);
      initNotifyServerPush(context).then((value) {
        configService.update(Config("pushId", value));
        _saveDeviceInfo();
      });
      requestPermission().then((value) {
        if (!value) {
          showErrorAlert("请您在系统设置中开启当前应用储存权限,以便app自动更新!");
        }
      });
      checkUpdate();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.inactive: // 处于这种状态的应用程序应该假设它们可能在任何时候暂停。
        break;
      case AppLifecycleState.resumed: // 应用程序可见，前台
        backgroundRun = false;
        initContext();
        ThemeColor.initStatusBar();
        if (kIsWeb != true) {
          clearNotifyNumber();
        }
        break;
      case AppLifecycleState.paused: // 应用程序不可见，后台
        backgroundRun = true;
        break;
      case AppLifecycleState.detached: // 应用程序导航或取消导航
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return IndexedStack(
      index: this.pageIndex,
      children: this.pageList,
    );
  }

  @override
  Widget getBottom(BuildContext context) {
    var icon = Icon(Icons.message,
        size: 25, color: ThemeColor.getColor("barFontColor"));
    return GNav(
        curve: Curves.easeInCubic,
        // tab animation curves
        duration: Duration(milliseconds: 300),
        // tab animation duration
        gap: 15,
        // the tab button gap between icon and text
        activeColor: ThemeColor.getColor("barFontColor"),
        // selected icon and text color
        iconSize: 25,
        // tab button icon size
        tabBackgroundColor:
            ThemeColor.getColor("barFontColor").withOpacity(0.2),
        // selected tab background color
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        tabMargin: EdgeInsets.fromLTRB(5, 5, 5, (!kIsWeb && Platform.isIOS) ? 20 : 5),
        color: ThemeColor.getColor("barFontColor"),
        backgroundColor: ThemeColor.getColor("appbar"),
        // navigation bar padding
        onTabChange: (int index) {
          setState(() {
            pageIndex = index;
          });
        },
        tabs: [
          GButton(
            leading: unReadTotal > 0
                ? badges.Badge(
                    child: icon,
                    badgeStyle: badges.BadgeStyle(
                      shape: badges.BadgeShape.circle,
                      badgeColor: ThemeColor.getColor("info"),
                    ),
                    position: badges.BadgePosition.topEnd(top: -15, end: -15),
                    badgeContent: Text(
                      unReadTotal > 99 ? '99+' : unReadTotal.toString(),
                      style: TextStyle(fontSize: 10.0),
                    ),
                  )
                : icon,
            text: '消息',
          ),
          GButton(
            icon: Icons.contacts,
            text: '通讯录',
          ),
          GButton(
            icon: Icons.apps,
            text: '工作台',
          ),
          GButton(
            icon: Icons.person_outline,
            text: '我的',
          )
        ]);
  }

  _initUserInfo() {
    judgmentLogin().then((value) {
      if (value == false) {
        configService.getConfig("account").then((c) {
          if (c != null) {
            var user = jsonDecode(c);
            postNoAuth(
              "/login",
              {
                "username": user["username"],
                "password": user["password"],
                "hospitalId": user["hospitalId"]
              },
              options: Options(
                headers: {
                  "hospitalId": user["hospitalId"],
                },
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
              ),
            ).then((value) {
              setAuth(value["token"]);
              configService.update(Config("auth", value["token"]));
              _saveDeviceInfo();
            }).catchError((err) {
              Navigator.pushNamed(context, 'login').then((v) {
                // 登录成功
                if (v) {
                  _saveDeviceInfo();
                  refreshAll();
                }
              });
              showErrorAlert(err["msg"]);
            });
          } else {
            showInfoToast("请先登录");
            Navigator.pushNamed(context, 'login').then((v) {
              // 登录成功
              if (v) {
                _saveDeviceInfo();
                refreshAll();
              }
            });
          }
        });
        return;
      }
      ThemeColor.initStatusBar();
    }).catchError((err) {
      showErrorToast(err["msg"]);
      ThemeColor.initStatusBar();
    });
  }

  // 处理是否连接到聊天服务器
  changeConnect(bool v) {
    setState(() {});
  }

  _saveDeviceInfo() async {
    var userInfo = await getCurrentAccount();
    if (userInfo == null) return;
    var registerId = await configService.getConfig("pushId");
    if (registerId == null) return;
    var deviceName = await getDeviceName();
    post('/appdevice/save', {"name": deviceName, "register": registerId})
        .then((v) {})
        .catchError((e) {});
  }

  refreshAll() {
    closeSocket();
    messagePageState?.refresh();
    contactPersonPageState?.refresh();
    workbenchPageState?.refresh();
    minePageState?.refresh();
  }
}
