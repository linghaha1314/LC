import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:csc_app/page/login/EntrancePage.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:dio/dio.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'HomePage.dart';
import 'package:flutter/material.dart';
import '../ThemeColor.dart';
import '../component/MethodComponent.dart';
import '../service/ConfigService.dart';
import '../utils/Help.dart';

class InitPage extends StatefulWidget {
  InitPage({Key key}) : super(key: key);

  @override
  _InitPageState createState() => _InitPageState();
}

class _InitPageState extends State<InitPage> {
  final introKey = GlobalKey<IntroductionScreenState>();

  ConfigService configService = ConfigService();

  bool _init = false;

  bool _home = false;

  Timer _timer;

  @override
  Widget build(BuildContext context) {
    const bodyStyle = TextStyle(fontSize: 19.0);
    const pageDecoration = const PageDecoration(
      titleTextStyle: TextStyle(fontSize: 28.0, fontWeight: FontWeight.w700),
      bodyTextStyle: bodyStyle,
      imagePadding: EdgeInsets.zero,
    );
    return Stack(
      children: [
        IntroductionScreen(
          key: introKey,
          pages: [
            PageViewModel(
              title: "简化操作",
              body: "简化平时运行管理操作功能,实现快速完成平时工作内容及实时消息反馈",
              image: Image.asset("assets/images/intro-1.png"),
              decoration: pageDecoration,
            ),
            PageViewModel(
              title: "提高效率",
              body: "不受限制随时随地使用办公,提升平时工作效率",
              image: Image.asset("assets/images/intro-2.png"),
              decoration: pageDecoration,
            ),
            PageViewModel(
              title: "智能化教学",
              body: "摆脱纸质化工作的繁琐,提升办公方便程度",
              image: Image.asset("assets/images/intro-3.png"),
              decoration: pageDecoration,
            ),
          ],
          onDone: () {
            configService.update(new Config("introFlag", "YES"));
            showPage();
          },
          onSkip: () {
            configService.update(new Config("introFlag", "YES"));
            showPage();
          },
          showSkipButton: true,
          skipOrBackFlex: 0,
          nextFlex: 0,
          skip: const Text('跳过'),
          next: const Icon(Icons.arrow_forward),
          done: const Text('完成', style: TextStyle(fontWeight: FontWeight.w600)),
          dotsDecorator: const DotsDecorator(
            size: Size(10.0, 10.0),
            activeSize: Size(22.0, 10.0),
            activeShape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(25.0)),
            ),
          ),
        ),
        if (_init == false)
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Stack(
              children: [
                Positioned(
                  bottom: 50.0,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: new Center(
                      child: new SizedBox(
                        height: 50.0,
                        width: 50.0,
                        child: new CircularProgressIndicator(
                          value: null,
                          strokeWidth: 5.0,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/start.png"),
                fit: BoxFit.fill,
              ),
            ),
          ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    globalContent = context;
    _timer = Timer.periodic(Duration(seconds: 5), (timer) {
      setState(() {
        _init = true;
      });
      timer.cancel();
    });
    initConfigData();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void initConfigData() {
    configService.getTheme().then((dynamic v) {
      if (v != null) {
        if (v["opacity"] != null) {
          ThemeColor.opacity = double.parse(v["opacity"]);
        }
        if (v["theme"] != null) {
          ThemeColor.themeIndex = int.parse(v["theme"]);
        }
        if (v["background"] != null && File(v["background"]).existsSync()) {
          ThemeColor.background = v["background"];
        }
      }
      ThemeColor.changeTheme(context);
      _initUserInfo();
    });
  }

  _initUserInfo() {
    judgmentLogin().then((value) {
      if (value == false) {
        configService.getConfig("account").then((c) {
          if (c != null) {
            var user = jsonDecode(c);
            postNoAuth(
              "/login",
              {
                "username": user["username"],
                "password": user["password"],
                "hospitalId": user["hospitalId"]
              },
              options: Options(
                headers: {
                  "hospitalId": user["hospitalId"],
                },
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
              ),
            ).then((value) {
              setAuth(value["token"]);
              configService.update(Config("auth", value["token"])).then((c) {
                configService.getConfig("introFlag").then((introFlag) {
                  if (introFlag == 'YES') {
                    showHome();
                  } else {
                    _home = true;
                    setState(() {
                      _init = true;
                    });
                  }
                });
              });
            }).catchError((err) {
              _home = false;
              setState(() {
                _init = true;
              });
              showErrorAlert(err["msg"]);
            });
          } else {
            showInfoToast("请先登录");
            _home = false;
            setState(() {
              _init = true;
            });
          }
        });
        return;
      } else {
        configService.getConfig("introFlag").then((introFlag) {
          if (introFlag == 'YES') {
            showHome();
          } else {
            _home = true;
            setState(() {
              _init = true;
            });
          }
        });
      }
    }).catchError((err) {
      _home = false;
      setState(() {
        _init = true;
      });
      showErrorToast(err["msg"]);
    });
  }

  showPage() {
    if (_home)
      showHome();
    else
      showEntrance();
  }

  showEntrance() {
    Navigator.of(context).pushAndRemoveUntil(
      new MaterialPageRoute(
        builder: (context) => EntrancePage(),
      ),
      (route) => route == null,
    );
  }

  showHome() {
    configService.getConfig("account").then((c) {
      var username;
      if (c != null) {
        var user = jsonDecode(c);
        username = user["username"];
      }
      if (username == null) {
        showEntrance();
      } else {
        Navigator.of(context).pushAndRemoveUntil(
          new MaterialPageRoute(
            builder: (context) => Home(),
          ),
          (route) => route == null,
        );
      }
    });
  }
}
