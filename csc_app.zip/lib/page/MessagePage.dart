import 'package:animations/animations.dart';
import 'package:badges/badges.dart' as badges;
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefresherScroll.dart';
import 'package:csc_app/page/base/MessageCardPage.dart';
import 'package:csc_app/page/base/MineTodoPage.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:circular_profile_avatar/circular_profile_avatar.dart';

import '../ThemeColor.dart';

class MessagePage extends StatefulWidget {
  @override
  MessagePageState createState() => new MessagePageState();
}

class MessagePageState extends State<MessagePage> {
  String url;

  List<dynamic> list = [];

  dynamic userIndex = {};

  bool _connect = true;

  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  @override
  void initState() {
    super.initState();
    messagePageState = this;
    getHttpPath().then((path) {
      url = path;
      _initData();
    });
  }

  refresh() {
    _initData();
  }

  //添加你接收的消息
  addMessageTotal(dynamic row) async {
    if (userIndex[row["senderId"]] == null) {
      await _addUserList(row["senderId"], row["content"]);
    }
    var r = list[userIndex[row["senderId"]]];
    if (r["total"] == null) {
      r["total"] = 0;
    }
    r["total"] = r["total"] + 1;
    r["content"] = row["content"];
    r["sort"] = row["sort"];
    if (userIndex[row["senderId"]] != 0) {
      r = list.removeAt(userIndex[row["senderId"]]);
      setState(() {
        list.insert(0, r);
      });
    } else {
      setState(() {});
    }
  }

  //更新已读个数
  updateUnread(int size, String senderId) {
    var r = list[userIndex[senderId]];
    if (r["total"] == null) {
      r["total"] = 0;
    }
    setState(() {
      r["total"] = r["total"] + size;
    });
    homePage.addUnreadTotal(size: size);
  }

  //更新你发送的消息
  updateNowMsg(String senderId, String content) async {
    if (userIndex[senderId] == null) {
      await _addUserList(senderId, content);
    } else {
      var r = list[userIndex[senderId]];
      r["content"] = content;
      r = list.removeAt(userIndex[senderId]);
      setState(() {
        list.insert(0, r);
      });
    }
  }

  _addUserList(String senderId, String content) async {
    var res = await get('/staff/findById/$senderId');
    if (res["success"]) {
      var data = res['data'];
      dynamic msg = {
        "name": data["name"],
        "avator": data["avator"],
        "senderId": senderId,
        "content": content,
        "sort": DateTime.now().millisecondsSinceEpoch,
      };
      setState(() {
        list.insert(0, msg);
      });
    }
  }

  changeConnect(bool v) {
    if (!v) _initData();
    setState(() {
      _connect = v;
    });
  }

  @override
  Widget build(BuildContext context) {
    userIndex = {};
    return new Scaffold(
      appBar: AppBar(
        title: Text("消息"),
        actions: [
          Visibility(
            visible: _connect,
            child: Row(
              children: [
                Container(
                  height: 40.0,
                  width: 40.0,
                  child: loadingWidget,
                ),
                Text(
                  "连接中...",
                  style: TextStyle(fontSize: 13.0),
                ),
              ],
            ),
          ),
        ],
      ),
      body: RefresherScroll(
        enablePullDown: true,
        header: WaterDropMaterialHeader(
          distance: 40.0,
          color: ThemeColor.getColor("fontColor"),
          backgroundColor: ThemeColor.getColor("focus"),
        ),
        controller: _refreshController,
        child: list.length == 0
            ? emptyWidget
            : ListView.separated(
                itemCount: list.length,
                itemBuilder: (BuildContext context, int i) {
                  userIndex[list[i]["senderId"]] = i;
                  // 聊天消息
                  if (list[i]['type'] == 'singleChat') {
                    return _buildChatRow(list[i]);
                  } else {
                    return _buildProcessRow(list[i]);
                  }
                },
                separatorBuilder: (BuildContext context, int i) {
                  return Divider();
                },
              ),
        onRefresh: _initData,
      ),
      floatingActionButton: OpenContainer(
        transitionType: ContainerTransitionType.fade,
        openBuilder: (BuildContext context, VoidCallback _) {
          return MineTodoPage();
        },
        closedElevation: 6.0,
        closedShape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(56.0 / 2),
          ),
        ),
        closedColor: Theme.of(context).colorScheme.secondary,
        closedBuilder: (BuildContext context, VoidCallback openContainer) {
          return SizedBox(
            height: 56.0,
            width: 56.0,
            child: Center(
              child: Icon(
                MdiIcons.calendarPlus,
                color: Theme.of(context).colorScheme.onSecondary,
              ),
            ),
          );
        },
      ),
    );
  }

  _initData() async {
    var userInfo = await getCurrentAccount();
    messageData = {};
    post("/message/getMineMessageList", {"receiverId": userInfo.staff["id"]})
        .then((res) {
      if (res["success"] as bool) {
        setState(() {
          list = res["data"] as List<dynamic>;
        });
        homePage.clearReadTotal();
        list.forEach((r) {
          homePage.addUnreadTotal(size: r["total"]);
        });
      }
      _refreshController.refreshCompleted();
    }).catchError((err) {
      _refreshController.refreshFailed();
      showErrorToast(err["msg"]);
    });
  }

  final _biggerFont = const TextStyle(fontSize: 18.0);

  Widget _buildChatRow(dynamic row) {
    String t = (row['name']).toString().substring(0, 1), avatar = "";
    int total = 0;
    if (row["total"] != null) {
      total = row["total"] as int;
    }
    if (row["avator"] != null) {
      avatar = row["avator"];
    }
    return ListTile(
      leading: badges.Badge(
        badgeStyle: badges.BadgeStyle(
          shape: badges.BadgeShape.circle,
          badgeColor: ThemeColor.getColor("info"),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(50.0),
          child: Container(
            width: 50.0,
            height: 50.0,
            child: CircularProfileAvatar(
              url + avatar,
              initialsText: Text(
                t,
                style: TextStyle(color: ThemeColor.getColor("fontColor")),
              ),
              borderColor: ThemeColor.getColor("content"),
              backgroundColor: ThemeColor.getColor("content"),
            ),
          ),
        ),
        showBadge: total > 0,
        badgeContent: Text(
          total > 99 ? '99+' : total.toString(),
          style: TextStyle(fontSize: 10.0),
        ),
      ),
      title: Text(
        '${row['name']}',
        style: _biggerFont,
      ),
      subtitle: Text(
        "${row["content"]}",
        softWrap: true,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
      ),
      trailing: Text(buildMessageTime(row["sort"] as int)),
      onTap: () {
        Navigator.of(context).pushNamed('chatDetailPage', arguments: row);
      },
    );
  }

  Widget _buildProcessRow(dynamic row) {
    int total = 0;
    if (row["total"] != null) {
      total = row["total"] as int;
    }
    return ListTile(
      leading: badges.Badge(
        badgeStyle: badges.BadgeStyle(
          shape: badges.BadgeShape.circle,
          badgeColor: ThemeColor.getColor("info"),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10.0),
          child: Container(
            width: 50.0,
            height: 50.0,
            color: ThemeColor.getColor("success"),
            child: Center(
              child: SvgPicture.asset(
                row["type"] == "otherMsg"
                    ? "assets/images/bell.svg"
                    : "assets/images/approve.svg",
                width: 30.0,
                height: 30.0,
              ),
            ),
          ),
        ),
        showBadge: total > 0,
        badgeContent: Text(
          total > 99 ? '99+' : total.toString(),
          style: TextStyle(fontSize: 10.0),
        ),
      ),
      title: Text(
        '${row['name']}',
        style: _biggerFont,
      ),
      subtitle: Text(
        "${row["content"]}",
        softWrap: true,
        overflow: TextOverflow.ellipsis,
        maxLines: 1,
      ),
      trailing: Text(buildMessageTime(row["sort"] as int)),
      onTap: () {
        if (row["type"] == "otherMsg") {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MessageCardPage(row['name']),
            ),
          );
        } else {
          Navigator.pushNamed(context, "todoTask",
              arguments: {"title": row['name'], "senderId": row["senderId"]});
        }
      },
    );
  }
}
