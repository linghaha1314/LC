import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/MethodComponent.dart';
import '../../../ThemeColor.dart';

class EquipmentWarehousingView extends BaseApp {
  EquipmentWarehousingView();

  @override
  _EquipmentWarehousingViewState createState() =>
      new _EquipmentWarehousingViewState();
}

class _EquipmentWarehousingViewState
    extends BaseAppPage<EquipmentWarehousingView> {
  String id;
  dynamic warehousingData;
  dynamic equipmentInfo;
  bool showBottomBtn = false;

  _EquipmentWarehousingViewState() {
    title = "设备详情";
  }

  @override
  initRouteSuccess() {
    if (routeData != null && routeData["id"] != null) {
      id = routeData["id"];
      getEquipmentWarehousingData();
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  getBottom(BuildContext context) {
    if (showBottomBtn) {
      return SizedBox(
          height: 40,
          child: OutlinedButton(
            onPressed: () {
              toBorrowPage();
            },
            child: Text("申请领用"),
          ));
    } else {
      return null;
    }
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Visibility(
              visible: (warehousingData != null),
              child: _warehousingDataView()),
          Visibility(
              visible: (equipmentInfo != null), child: _equipmentInfoView()),
        ],
      ),
    );
  }

  Widget _warehousingDataView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "基础信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _textView("资产名称", warehousingData["name"]),
                          Divider(),
                          _textView("资产号", warehousingData["assetNumber"]),
                          Divider(),
                          _textView("单价（元）", warehousingData["price"]),
                          Divider(),
                          _textView("分类号", warehousingData["classification"]),
                          Divider(),
                          _textView("领用单位", warehousingData["receivingUnit"]),
                          Divider(),
                          _textView(
                              "领用人", warehousingData["receivingStaffName"]),
                          Divider(),
                          _textView("实验室", warehousingData["placeName"]),
                          Divider(),
                          _textView("库房", warehousingData["storehouseName"]),
                          Divider(),
                          _textView("资产归属", warehousingData["ascriptionName"]),
                          Divider(),
                          _textView("经费来源", warehousingData["sourceName"]),
                          Divider(),
                          _textView("创建人", warehousingData["userName"]),
                          Divider(),
                          _textView("创建日期", warehousingData["created"]),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "备注",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            subtitle: Text((warehousingData["remark"] != null &&
                                    warehousingData["remark"] != '')
                                ? warehousingData["remark"]
                                : "无"),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _equipmentInfoView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "详细信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _textView("保修日期", equipmentInfo["warrantyDate"]),
                          Divider(),
                          _textView("生产厂家", equipmentInfo["manufacturer"]),
                          Divider(),
                          _textView("国别", equipmentInfo["country"]),
                          Divider(),
                          _textView("入库日期", equipmentInfo["storageDate"]),
                          Divider(),
                          _textView("经手人", equipmentInfo["dealer"]),
                          Divider(),
                          _textView("记账人", equipmentInfo["keeperStaffName"])
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  getEquipmentWarehousingData() {
    this.loading = true;
    post("/equipmentwarehousing/listQueryByPage", {"id": this.id}).then((res) {
      this.loading = false;
      if (res["total"] > 0) {
        setState(() {
          this.warehousingData = res["rows"][0];
          this.empty = false;
          this.showBottomBtn = this.warehousingData["storehouseId"] != null;
        });
      }
    });

    post("/equipmentinfo/findByWarehousingId", {"warehousingId": this.id})
        .then((res) {
      this.loading = false;
      if (res["success"]) {
        setState(() {
          this.equipmentInfo = res["data"];
        });
      }
    });
  }

  _textView(name, value) {
    if (value == null || value == "") {
      value = "-";
    }
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name),
          Text(value.toString(), style: TextStyle(fontSize: 14)),
        ],
      ),
    );
  }

  toBorrowPage() {
    String storehouseId = warehousingData["storehouseId"];
    String warehousingId = warehousingData["id"];
    if (storehouseId == null) {
      return showErrorToast("该设备未存入库房，不能借用");
    }
    setState(() {
      this.loading = true;
    });
    post("/storehousearticle/listQueryByPage", {
      "storehouseId": storehouseId,
      "warehousingId": warehousingId
    }).then((res) {
      setState(() {
        this.loading = false;
      });
      if (res["total"] > 0) {
        Navigator.pushNamed(context, "equipmentBorrowForm",
                arguments: res["rows"][0])
            .then((value) {
          setState(() {
            this.showBottomBtn = false;
          });
        });
      }
    }).catchError((onError) {
      setState(() {
        this.loading = false;
      });
    });
  }
}
