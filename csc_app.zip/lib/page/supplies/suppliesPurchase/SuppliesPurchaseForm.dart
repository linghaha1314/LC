import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/component/EmptyWidget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import '../../../ThemeColor.dart';
import 'SuppliesPurchaseItemForm.dart';
import 'SuppliesPurchaseDetailView.dart';

class SuppliesPurchaseForm extends BaseApp {
  final dynamic data;

  SuppliesPurchaseForm(this.data);

  @override
  _SuppliesPurchaseFormState createState() =>
      new _SuppliesPurchaseFormState(this.data);
}

class _SuppliesPurchaseFormState extends BaseAppPage {
  dynamic data;
  List<dynamic> itemList = [];
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  FocusNode focusNode3 = new FocusNode();
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  int page = 0;
  PageController _pageController;

  _SuppliesPurchaseFormState(this.data) {
    if (data != null && data != {}) {
      data["purchaseDate"] = DateTime.parse("${data["purchaseDate"]}");
    }
    title = "添加耗材申购";
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    _pageController = PageController(
      initialPage: page,
      keepPage: true,
    );
    if (data != null) {
      initItemList();
    }
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      Visibility(
        visible: page == 1,
        child: ElevatedButton(
          child: Text("添加耗材"),
          onPressed: () {
            editItem(null);
          },
        ),
      ),
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Container(
      child: PageView.custom(
        controller: _pageController,
        physics: NeverScrollableScrollPhysics(),
        childrenDelegate: SliverChildBuilderDelegate((context, index) {
          if (index == 0) {
            return _buildForm();
          } else if (index == 1) {
            return _buildTable(context);
          }
          return Text("");
        }, childCount: 3),
      ),
    );
  }

  _buildForm() {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(16.0),
        child: FormBuilder(
          key: _fbKey,
          initialValue: this.data != null ? data : {},
          child: Column(
            children: [
              FormBuilderTextField(
                name: "unitName",
                focusNode: focusNode1,
                decoration: InputDecoration(labelText: "申请实验单元"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择申请实验单元!",
                  ),
                ]),
                onTap: () {
                  focusNode1.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择申请实验单元",
                          url: "/experimentalunit/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['unitName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("unitId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderDateTimePicker(
                name: "purchaseDate",
                inputType: InputType.date,
                format: DateFormat("yyyy-MM-dd"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择申领日期!",
                  ),
                ]),
                decoration: InputDecoration(labelText: "申领日期"),
              ),
              FormBuilderTextField(
                name: "staffName",
                focusNode: focusNode3,
                decoration: InputDecoration(labelText: "申领人"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择申领人!",
                  ),
                ]),
                onTap: () {
                  focusNode3.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择科申领人",
                          url: "/staff/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['staffName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("staffId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "remark",
                maxLines: 3,
                decoration: InputDecoration(labelText: "备注"),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: ElevatedButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [Text("下一步"), Icon(Icons.arrow_forward)],
                  ),
                  onPressed: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    if (_fbKey.currentState.saveAndValidate()) {
                      setState(() {
                        page = 1;
                        this.data = Map.of(_fbKey.currentState.value);
                      });
                      _pageController.nextPage(
                          duration: Duration(milliseconds: 200),
                          curve: Curves.linear);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _buildTable(context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 5, top: 10),
            child: Text(
              "耗材申购详情列表",
              style: TextStyle(fontSize: 20),
            ),
          ),
          Visibility(
            visible: itemList.length == 0,
            child: EmptyWidget(
              height: 200,
              child: Text("暂无耗材申购详情信息，请添加！"),
            ),
          ),
          Visibility(
            visible: itemList.length > 0,
            child: Container(
              child: Column(
                children: itemList.map((item) {
                  return Column(
                    children: [
                      Slidable(
                        child: Container(
                          child: ListTile(
                            title: Text("材料名称:${item['name']}"),
                            subtitle: Text("材料编码:${item['code']}"),
                          ),
                        ),
                        endActionPane: ActionPane(
                          motion: ScrollMotion(),
                          children: [
                            SlidableAction(
                              label: '编辑',
                              backgroundColor: ThemeColor.getColor("info"),
                              icon: Icons.edit,
                              onPressed: (BuildContext context) =>
                                  editItem(item),
                            ),
                            SlidableAction(
                              label: '删除',
                              backgroundColor: ThemeColor.getColor("danger"),
                              icon: Icons.delete,
                              onPressed: (BuildContext context) =>
                                  deleteItem(item),
                            ),
                          ],
                        ),
                      ),
                      Divider(),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  child: Row(
                    children: [
                      Text("上一步"),
                      SizedBox(
                        width: 5,
                      ),
                      Icon(Icons.arrow_back)
                    ],
                  ),
                  onPressed: () {
                    setState(() {
                      page = 0;
                    });
                    _pageController.previousPage(
                        duration: Duration(milliseconds: 200),
                        curve: Curves.linear);
                  },
                ),
                ElevatedButton(
                  child: Row(
                    children: [
                      Text("完成"),
                      SizedBox(
                        width: 5,
                      ),
                      Icon(Icons.check)
                    ],
                  ),
                  onPressed: () {
                    save(context);
                  },
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  deleteItem(item) {
    showConfirmAlert("是否删除申购耗材：${item['name']}").then((bool) {
      if (bool) {
        if (item["id"] != null) {
          post("/suppliespurchasedetails/delete", {"id": item["id"]})
              .then((value) {
            if (value["success"]) {
              setState(() {
                itemList.remove(item);
              });
            }
          });
        } else {
          setState(() {
            itemList.remove(item);
          });
        }
      }
    });
  }

  editItem(item) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => new SuppliesPurchaseItemForm(item),
        )).then((value) {
      if (value != null) {
        var index = itemList.indexOf(item);
        if (index > -1) {
          itemList[index] = value;
        } else {
          itemList.add(value);
        }
        setState(() {
          this.itemList = itemList;
        });
      }
    });
  }

  initItemList() {
    if (data != null && data != {}) {
      post("/suppliespurchasedetails/listQueryByPage",
          {"suppliesPurchaseId": data["id"]}).then((value) {
        if (value != null && value["total"] > 0) {
          itemList = value["rows"];
          itemList.forEach((element) {
            element["isExpanded"] = false;
          });
        }
      });
    }
  }

  toItemForm(data) {
    Navigator.push(
      context,
      new MaterialPageRoute(
          builder: (context) => new SuppliesPurchaseDetailView(data)),
    );
  }

  save(context) {
    if (itemList == null || itemList.length < 1) {
      return showErrorAlert("请至少添加一条申购详情数据");
    }
    var suppliesPurchase = this.data;
    if (suppliesPurchase != null) {
      var date = suppliesPurchase["purchaseDate"] as DateTime;
      suppliesPurchase["purchaseDate"] = date.toString();
    }
    var params = {
      "suppliesPurchase": suppliesPurchase,
      "suppliesPurchaseDetailList": itemList
    };
    post("/suppliespurchase/saveDto", params).then((value) {
      if (value["success"]) {
        loading = false;
        Navigator.pop(context, suppliesPurchase);
      }
    }).catchError((error) {
      loading = false;
      showErrorAlert(error["msg"]);
    });
  }
}
