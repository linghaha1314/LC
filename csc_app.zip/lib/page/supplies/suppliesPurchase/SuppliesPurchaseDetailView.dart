import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter/material.dart';

class SuppliesPurchaseDetailView extends BaseApp {
  final dynamic data;

  SuppliesPurchaseDetailView(this.data);

  @override
  _SuppliesPurchaseDetailViewState createState() =>
      new _SuppliesPurchaseDetailViewState(this.data);
}

class _SuppliesPurchaseDetailViewState
    extends BaseAppPage<SuppliesPurchaseDetailView> {
  dynamic data;

  _SuppliesPurchaseDetailViewState(this.data) {
    title = "物资详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(15),
        child: Card(
          child: Column(
            children: [
              _textView("材料名称", data["name"]),
              Divider(),
              _textView("材料编码", data["code"]),
              Divider(),
              _textView("请领数量", data["total"]),
              Divider(),
              _textView("品牌", data["brandName"]),
              Divider(),
              _textView("规格", data["model"]),
              Divider(),
              _textView("计量单位", data["measuringUnitName"]),
              Divider(),
              _textView("耗材类别", data["categoryName"]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    empty = data == null;
  }

  _textView(name, value) {
    if (value == null || value == "") {
      value = "无";
    }
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name),
          Text(value.toString()),
        ],
      ),
    );
  }
}
