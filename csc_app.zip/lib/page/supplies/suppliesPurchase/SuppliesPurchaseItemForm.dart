import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class SuppliesPurchaseItemForm extends BaseApp {
  final dynamic data;

  SuppliesPurchaseItemForm(this.data) : super();

  @override
  _SuppliesPurchaseItemFormState createState() =>
      new _SuppliesPurchaseItemFormState(this.data);
}

class _SuppliesPurchaseItemFormState
    extends BaseAppPage<SuppliesPurchaseItemForm> {
  dynamic data;
  dynamic autoValidate = false;
  Map<String, dynamic> saveData = {};
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  FocusNode focusNode3 = new FocusNode();
  List<dynamic> inletFlagList = [];
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  _SuppliesPurchaseItemFormState(this.data) {
    if (data != null && data != []) {
      data["total"] = data["total"].toString();
      data["univalent"] = data["univalent"].toString();
    }
    empty = false;
    title = "添加耗材申购";
  }

  @override
  void initState() {
    super.initState();
    initList();
  }

  @override
  Widget getBody(BuildContext context) {
    return Stepper(
      currentStep: 0,
      steps: [
        Step(
            title: Text("填写详情信息"),
            content: FormBuilder(
                key: _fbKey,
                initialValue: this.data != null ? data : {},
                autovalidateMode: AutovalidateMode.always,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FormBuilderTextField(
                      name: "name",
                      decoration: InputDecoration(labelText: "材料名称"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写材料名称!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "code",
                      decoration: InputDecoration(labelText: "材料编码"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写材料编码!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "total",
                      decoration: InputDecoration(labelText: "请领数量"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写请领数量!",
                        ),
                        FormBuilderValidators.numeric(
                          errorText: "请输入数字",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "model",
                      decoration: InputDecoration(labelText: "规格"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写规格!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "measuringUnitName",
                      focusNode: focusNode2,
                      decoration: InputDecoration(labelText: "计量单位"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择计量单位!",
                        ),
                      ]),
                      onTap: () {
                        focusNode2.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择计量单位",
                                url: "/measuringUnit/listQueryByPage",
                                searchText: "输入名称进行搜索",
                                queryParams: {},
                              ),
                            )).then((value) {
                          if (value != null) {
                            _fbKey.currentState.setState(() {
                              _fbKey.currentState.fields['measuringUnitName']
                                  .didChange(value["name"]);
                              _fbKey.currentState.setInternalFieldValue(
                                  "measuringUnitId", value["id"]);
                            });
                          }
                        });
                      },
                    ),
                    FormBuilderTextField(
                      name: "categoryName",
                      focusNode: focusNode3,
                      decoration: InputDecoration(labelText: "耗材类别"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择耗材类别!",
                        ),
                      ]),
                      onTap: () {
                        focusNode3.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择耗材类别",
                                url:
                                    "/dictionarydata/listQueryByTypeCode/suppliesType",
                                searchText: "输入名称进行搜索",
                                queryParams: {"shortCode": "supplies"},
                              ),
                            )).then((value) {
                          if (value != null) {
                            _fbKey.currentState.setState(() {
                              _fbKey.currentState.fields['categoryName']
                                  .didChange(value["name"]);
                              _fbKey.currentState
                                  .setInternalFieldValue("categoryId", value["id"]);
                            });
                          }
                        });
                      },
                    ),
                    FormBuilderTextField(
                      name: "remark",
                      maxLines: 2,
                      decoration: InputDecoration(labelText: "备注"),
                    ),
                  ],
                )))
      ],
      type: StepperType.vertical,
      controlsBuilder: (BuildContext cc,ControlsDetails details) {
        return Row(
          children: [
            TextButton(
              onPressed: () {
                this.autoValidate = true;
                if (_fbKey.currentState.saveAndValidate()) {
                  details.onStepContinue.call();
                }
              },
              child: const Text('完成'),
            )
          ],
        );
      },
      onStepCancel: () {
        Navigator.pop(context, null);
      },
      onStepContinue: () {
        Navigator.pop(context, Map.of(_fbKey.currentState.value));
      },
    );
  }

  initList() {
    inletFlagList.add({"id": false, "name": "否"});
    inletFlagList.add({"id": true, "name": "是"});
  }
}
