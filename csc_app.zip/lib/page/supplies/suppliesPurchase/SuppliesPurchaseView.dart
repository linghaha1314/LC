import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

import '../../../ThemeColor.dart';
import 'SuppliesPurchaseDetailView.dart';
import 'SuppliesPurchaseForm.dart';

class SuppliesPurchaseView extends BaseApp {
  final Map data;

  SuppliesPurchaseView(this.data);

  @override
  _SuppliesPurchaseViewState createState() =>
      new _SuppliesPurchaseViewState(data);
}

class _SuppliesPurchaseViewState extends BaseAppPage<SuppliesPurchaseView> {
  dynamic data;
  List<dynamic> itemList = [];
  String avator = "";

  _SuppliesPurchaseViewState(data) {
    this.data = data;
    title = "申购详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return Scrollbar(
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 10,
              ),
              _dataView(),
              Visibility(
                visible: (itemList != null && itemList.length > 0),
                child: _detailList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      PopupMenuButton(
        tooltip: "更多操作",
        itemBuilder: (BuildContext context) {
          return getPopupItem();
        },
        onSelected: (dynamic v) async {
          if (v == "edit") {
            Navigator.push(
              context,
              new MaterialPageRoute(
                  builder: (context) => new SuppliesPurchaseForm(data)),
            ).then((value) {
              if (value != null) {
                initItemList();
                if (data != null && data["purchaseDate"] != null) {
                  data["purchaseDate"] =
                      data["purchaseDate"].toString().substring(0, 11);
                }
                this.data = data;
                showSuccessAlert("修改成功!");
              }
            });
          } else if (v == "submit") {
            var user = await getCurrentAccount();
            _submitApply(data, user);
          } else {
            var path = await getHttpPath();
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => WebViewPage(
                      url:
                          "$path/flowview/${data["processInstanceId"]}?type=f")),
            );
          }
        },
      ),
    ];
  }

  dynamic getPopupItem() {
    var status = this.data["status"];
    var taskStatus = this.data["taskStatus"];
    var popupList = <PopupMenuEntry<dynamic>>[];
    if (status == null) {
      popupList.add(new PopupMenuItem(
          value: "edit",
          child: ListTile(title: new Text("修改"), leading: Icon(Icons.edit))));
      popupList.add(new PopupMenuItem(
          value: "submit",
          child: ListTile(
              title: new Text("提交"), leading: Icon(Icons.vertical_align_top))));
    } else if (status == 1 || (status == 0 && taskStatus == 1) || status == 2) {
      popupList.add(new PopupMenuItem(
          value: "processInstance",
          child: ListTile(title: new Text("审批进程"), leading: Icon(Icons.menu))));
    }
    return popupList;
  }

  @override
  void initState() {
    super.initState();
    getHttpPath().then((value) {
      setState(() {
        avator = value + data["avator"];
      });
    });
    initItemList();
  }

  initItemList() {
    setState(() {
      loading = true;
    });
    post("/suppliespurchasedetails/listQueryByPage",
        {"suppliesPurchaseId": data["id"]}).then((value) {
      setState(() {
        loading = false;
        itemList = value["rows"];
        empty = false;
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  _dataView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "耗材申购基本信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _textView("申请实验单元", data["unitName"], null),
                          Divider(),
                          _textView(
                              "申领日期", data["purchaseDate"].toString(), null),
                          Divider(),
                          _textView("申领人", data["staffName"], null),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "备注",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            subtitle: Text(
                                (data["remark"] != null && data["remark"] != '')
                                    ? data["remark"]
                                    : "无"),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _detailList() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "耗材申购列表",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Column(
              children: itemList.map<Widget>((item) {
                return _textView(
                    "材料名称：${item["name"]}", "数量：${item["total"]}", item);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  _textView(name, value, item) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 14),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
      onTap: () {
        if (item != null) {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => new SuppliesPurchaseDetailView(item)),
          );
        }
      },
    );
  }

  _submitApply(data, user) {
    setState(() {
      loading = true;
    });
    post("/suppliespurchase/applyAudit", {
      "id": data["id"],
      "date": "${data["purchaseDate"]} 00:00:00",
      "name": "${user.staff["name"]}申请耗材申购"
    }).then((value) {
      setState(() {
        loading = false;
      });
      if (value["success"] == true) {
        Navigator.of(context).pop(true);
        showSuccessToast("提交成功");
      }
    }).catchError((error) {
      showErrorAlert(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }
}
