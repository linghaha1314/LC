import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../../ThemeColor.dart';
import 'SuppliesPurchaseForm.dart';
import 'SuppliesPurchaseView.dart';

class SuppliesPurchasePage extends BaseApp {
  @override
  _SuppliesPurchasePageState createState() => new _SuppliesPurchasePageState();
}

class _SuppliesPurchasePageState extends BaseAppPage
    with SingleTickerProviderStateMixin {
  RefreshController notSubmitController =
      RefreshController(initialRefresh: true);
  RefreshController submittedController =
      RefreshController(initialRefresh: true);

  _SuppliesPurchasePageState() {
    title = "耗材申购";
  }

  var statusIconList = [
    Icons.vertical_align_top,
    Icons.close,
    Icons.check,
    Icons.pause,
    Icons.check,
  ];

  var statusList = ["待提交", "已驳回", "已审核", "审核中", "您已审核"];

  var statusColorList = [
    ThemeColor.getColor("info"),
    ThemeColor.getColor("danger"),
    ThemeColor.getColor("success"),
    ThemeColor.getColor("warning"),
    ThemeColor.getColor("success")
  ];

  var tabController;

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: [
        RefreshList(
          controller: notSubmitController,
          searchText: "请输入项目名称进行搜索",
          url: "/suppliespurchase/listQueryByPage",
          queryParams: {"notStatus": "true", "processType": "apply"},
          loadSuccess: (row) {
            row.forEach((element) {
              element["isExpanded"] = false;
            });
          },
          buildItem: (dynamic row, int i) {
            return _buildRowOne(row);
          },
        ),
        RefreshList(
          controller: submittedController,
          searchText: "请输入项目名称进行搜索",
          url: "/suppliespurchase/listQueryByPage",
          queryParams: {"hasProcess": "1", "processType": "apply"},
          buildItem: (dynamic row, int i) {
            return _buildRowTwo(row);
          },
        ),
      ],
    );
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
          controller: this.tabController,
          tabs: <Tab>[
            Tab(text: '可申请列表'),
            Tab(text: '已申请列表'),
          ],
        ),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  @override
  void initState() {
    super.initState();
    initTabController();
  }

  initTabController() {
    tabController = TabController(
        vsync: this, // 动画效果的异步处理
        length: 2, // tab 个数
        initialIndex: 0 // 起始位置
        );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        onPressed: () {
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new SuppliesPurchaseForm(null)),
          ).then((value) => {
                if (value)
                  {
                    showSuccessAlert("添加成功!"),
                    notSubmitController.requestRefresh(),
                    submittedController.requestRefresh()
                  }
              });
        },
        tooltip: "添加",
        icon: Icon(Icons.add),
      )
    ];
  }

  @override
  void dispose() {
    this.tabController.dispose();
    super.dispose();
  }

  _buildRowOne(row) {
    return ListTile(
      title: Row(
        children: [
          Text('申领人: ${row["staffName"]}'),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('申请实验单元: ${row["unitName"] != null ? row["unitName"] : "无"}'),
          Text('申领日期：${row["purchaseDate"]}')
        ],
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Chip(
            backgroundColor: statusColorList[getStatus(row)],
            label: Row(
              children: [
                Text(
                  statusList[getStatus(row)],
                  style: TextStyle(
                    color: ThemeColor.getColor("fontColor"),
                  ),
                ),
                Icon(
                  statusIconList[getStatus(row)],
                  color: ThemeColor.getColor("fontColor"),
                ),
              ],
            ),
          ),
        ],
      ),
      onTap: () {
        //跳转到详情页
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new SuppliesPurchaseView(row)),
        ).then((value) {
          if (value) {
            notSubmitController.requestRefresh();
          }
        });
      },
    );
  }

  _buildRowTwo(row) {
    return ListTile(
      title: Row(
        children: [
          Text('申领人: ${row["staffName"]}'),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('申请实验单元: ${row["unitName"]}'),
          Text('申领日期：${row["purchaseDate"].toString()}')
        ],
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Chip(
            backgroundColor: statusColorList[getStatus(row)],
            label: Row(
              children: [
                Text(
                  statusList[getStatus(row)],
                  style: TextStyle(
                    color: ThemeColor.getColor("fontColor"),
                  ),
                ),
                Icon(
                  statusIconList[getStatus(row)],
                  color: ThemeColor.getColor("fontColor"),
                ),
              ],
            ),
          ),
        ],
      ),
      onTap: () {
        //跳转到详情页
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new SuppliesPurchaseView(row)),
        );
      },
    );
  }

  getStatus(data) {
    var status = data["status"];
    var taskStatus = data["taskStatus"];
    if (status == null) {
      return 0;
    } else if (status == 1) {
      return 1;
    } else if (status == 2) {
      return 2;
    }
    if (status == 0 && (taskStatus == "0" || taskStatus == null)) {
      return 3;
    }
    if (status == 0 && taskStatus == "1") {
      return 4;
    }
  }
}
