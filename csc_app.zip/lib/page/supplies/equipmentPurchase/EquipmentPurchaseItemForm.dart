import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class EquipmentPurchaseItemForm extends BaseApp {
  final dynamic data;

  EquipmentPurchaseItemForm(this.data) : super();

  @override
  _EquipmentPurchaseItemFormState createState() =>
      new _EquipmentPurchaseItemFormState(this.data);
}

class _EquipmentPurchaseItemFormState extends BaseAppPage {
  dynamic data;
  dynamic autoValidate = false;
  Map<String, dynamic> saveData = {};
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  FocusNode focusNode3 = new FocusNode();
  List<dynamic> inletFlagList = [];
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  _EquipmentPurchaseItemFormState(this.data) {
    if (data != null && data != []) {
      data["total"] = data["total"].toString();
      data["univalent"] = data["univalent"].toString();
    }
    empty = false;
    title = "添加设备申购";
  }

  @override
  void initState() {
    super.initState();
    initList();
  }

  @override
  Widget getBody(BuildContext context) {
    return Stepper(
      currentStep: 0,
      steps: [
        Step(
            title: Text("填写基本信息"),
            content: FormBuilder(
                key: _fbKey,
                initialValue: this.data != null ? data : {},
                autovalidateMode: AutovalidateMode.always,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FormBuilderTextField(
                      name: "name",
                      decoration: InputDecoration(labelText: "物资名称"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写物资名称!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "total",
                      decoration: InputDecoration(labelText: "数量"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.numeric(
                          errorText: "请输入数字!",
                        ),
                        FormBuilderValidators.required(
                          errorText: "请填写数量!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "measuringUnitName",
                      focusNode: focusNode1,
                      decoration: InputDecoration(labelText: "计量单位"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择计量单位!",
                        ),
                      ]),
                      onTap: () {
                        focusNode1.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择计量单位",
                                url: "/measuringUnit/listQueryByPage",
                                searchText: "输入名称进行搜索",
                                queryParams: {},
                              ),
                            )).then((value) {
                          if (value != null) {
                            _fbKey.currentState.setState(() {
                              _fbKey.currentState.fields['measuringUnitName']
                                  .didChange(value["name"]);
                              _fbKey.currentState.setInternalFieldValue(
                                  "measuringUnitId", value["id"]);
                            });
                          }
                        });
                      },
                    ),
                    FormBuilderTextField(
                      name: "univalent",
                      decoration: InputDecoration(labelText: "单价"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.numeric(
                          errorText: "请输入数字!",
                        ),
                        FormBuilderValidators.required(
                          errorText: "请填写单价!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "content",
                      maxLines: 3,
                      decoration: InputDecoration(labelText: "主要技术参数"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写主要技术参数!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "brandName",
                      focusNode: focusNode2,
                      decoration: InputDecoration(labelText: "品牌"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择品牌!",
                        ),
                      ]),
                      onTap: () {
                        focusNode2.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择品牌",
                                url: "/brand/listQueryByPage",
                                searchText: "输入名称进行搜索",
                                queryParams: {},
                              ),
                            )).then((value) {
                          if (value != null) {
                            _fbKey.currentState.setState(() {
                              _fbKey
                                  .currentState.fields['brandName']
                                  .didChange(value["name"]);
                              _fbKey.currentState
                                  .setInternalFieldValue("brandId", value["id"]);
                            });
                          }
                        });
                      },
                    ),
                    FormBuilderDropdown(
                      name: "inletFlag",
                      decoration: InputDecoration(labelText: ""),
                      // initialValue: 'Male',
                      hint: Text('请选择是否进口'),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择是否进口!",
                        ),
                      ]),
                      items: inletFlagList
                          .map((value) => DropdownMenuItem(
                              value: value["id"],
                              child: Text("${value["name"]}")))
                          .toList(),
                    ),
                    FormBuilderTextField(
                      name: "afterSales",
                      maxLines: 3,
                      decoration: InputDecoration(labelText: "售后服务要求"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写售后服务要求!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "categoryName",
                      focusNode: focusNode3,
                      decoration: InputDecoration(labelText: "物品类别"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请选择物品类别!",
                        ),
                      ]),
                      onTap: () {
                        focusNode3.unfocus();
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SelectPage(
                                title: "选择物品类别",
                                url: "/itemCategory/listQueryByPage",
                                searchText: "输入名称进行搜索",
                                queryParams: {},
                              ),
                            )).then((value) {
                          if (value != null) {
                            _fbKey.currentState.setState(() {
                              _fbKey.currentState.fields['categoryName']
                                  .didChange(value["name"]);
                              _fbKey.currentState
                                  .setInternalFieldValue("categoryId", value["id"]);
                            });
                          }
                        });
                      },
                    ),
                    FormBuilderTextField(
                      name: "model",
                      decoration: InputDecoration(labelText: "型号"),
                      validator: FormBuilderValidators.compose([
                        FormBuilderValidators.required(
                          errorText: "请填写型号!",
                        ),
                      ]),
                    ),
                    FormBuilderTextField(
                      name: "remark",
                      maxLines: 2,
                      decoration: InputDecoration(labelText: "备注"),
                    ),
                  ],
                )))
      ],
      type: StepperType.vertical,
      controlsBuilder: (BuildContext cc,ControlsDetails details) {
        return Row(
          children: [
            TextButton(
              onPressed: () {
                this.autoValidate = true;
                if (_fbKey.currentState.saveAndValidate()) {
                  details.onStepContinue.call();
                }
              },
              child: const Text('完成'),
            )
          ],
        );
      },
      onStepCancel: () {
        Navigator.pop(context, null);
      },
      onStepContinue: () {
        Navigator.pop(context, Map.of(_fbKey.currentState.value));
      },
    );
  }

  initList() {
    inletFlagList.add({"id": false, "name": "否"});
    inletFlagList.add({"id": true, "name": "是"});
  }
}
