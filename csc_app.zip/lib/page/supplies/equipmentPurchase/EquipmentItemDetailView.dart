import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter/material.dart';

class EquipmentItemDetailView extends BaseApp {
  final dynamic data;

  EquipmentItemDetailView(this.data);

  @override
  _EquipmentItemDetailViewState createState() =>
      new _EquipmentItemDetailViewState(this.data);
}

class _EquipmentItemDetailViewState
    extends BaseAppPage<EquipmentItemDetailView> {
  dynamic data;

  _EquipmentItemDetailViewState(this.data) {
    title = "设备详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(15),
        child: Card(
          child: Column(
            children: [
              _textView("数量", data["total"]),
              Divider(),
              _textView("计量单位", data["measuringUnitName"]),
              Divider(),
              _textView("单价", data["univalent"]),
              Divider(),
              _textView("主要技术参数", data["content"]),
              Divider(),
              _textView("品牌", data["brandName"]),
              Divider(),
              _textView("是否进口", data["inletFlag"] ? '是' : '否'),
              Divider(),
              _textView("售后服务要求", data["afterSales"]),
              Divider(),
              _textView("物品类别", data["categoryName"]),
              Divider(),
              _textView("型号", data["model"]),
              Divider(),
              ListTile(
                title: Container(
                  margin: EdgeInsets.only(bottom: 10, top: 10),
                  child: Text(
                    "备注",
                    style: TextStyle(fontSize: 15),
                  ),
                ),
                subtitle: Text((data["remark"] != null && data["remark"] != '')
                    ? data["remark"]
                    : "无"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    empty = data == null;
  }

  _textView(name, value) {
    if (value == null || value == "") {
      value = "无";
    }
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name),
          Text(value.toString()),
        ],
      ),
    );
  }
}
