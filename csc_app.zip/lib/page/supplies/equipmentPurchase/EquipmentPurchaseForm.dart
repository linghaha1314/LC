import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/EmptyWidget.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:file_picker/file_picker.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';

import 'EquipmentPurchaseItemForm.dart';

class EquipmentPurchaseForm extends BaseApp {
  final dynamic data;

  EquipmentPurchaseForm(this.data) : super();

  @override
  _EquipmentPurchaseFormState createState() =>
      new _EquipmentPurchaseFormState(this.data);
}

class _EquipmentPurchaseFormState extends BaseAppPage<EquipmentPurchaseForm> {
  dynamic data;
  dynamic autoValidate = false;
  int currentStep = 0;
  List<dynamic> itemList = [];
  Map<String, dynamic> saveData = {};
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  FocusNode focusNode3 = new FocusNode();
  FocusNode focusNode4 = new FocusNode();
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  int page = 0;
  PageController _pageController;

  _EquipmentPurchaseFormState(this.data) {
    if (data != null && data != {}) {
      data["purchaseDate"] = DateTime.parse("${data["purchaseDate"]}-01");
    }
    empty = false;
    title = "添加设备申购";
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    _pageController = PageController(
      initialPage: page,
      keepPage: true,
    );
    if (data != null) {
      initItemList();
    }
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      Visibility(
        visible: page == 1,
        child: ElevatedButton(
          child: Text("添加设备"),
          onPressed: () {
            toItemForm(null);
          },
        ),
      ),
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Container(
      child: PageView.custom(
        controller: _pageController,
        physics: NeverScrollableScrollPhysics(),
        childrenDelegate: SliverChildBuilderDelegate((context, index) {
          if (index == 0) {
            return _buildForm();
          } else if (index == 1) {
            return _buildTable(context);
          }
          return Text("");
        }, childCount: 2),
      ),
    );
  }

  _buildForm() {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(16.0),
        child: FormBuilder(
          key: _fbKey,
          initialValue: this.data != null ? data : {},
          child: Column(
            children: [
              FormBuilderTextField(
                name: "typeName",
                focusNode: focusNode1,
                decoration: InputDecoration(labelText: "类型"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择类型!",
                  ),
                ]),
                onTap: () {
                  focusNode1.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择类型",
                          url:
                              "/dictionarydata/listQueryByTypeCode/purchaseType",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['typeName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("typeId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderDateTimePicker(
                name: "purchaseDate",
                inputType: InputType.date,
                format: DateFormat("yyyy-MM"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择购置年月!",
                  ),
                ]),
                decoration: InputDecoration(labelText: "购置年月"),
              ),
              FormBuilderTextField(
                name: "sectionName",
                focusNode: focusNode2,
                decoration: InputDecoration(labelText: "申请科室"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择申请科室!",
                  ),
                ]),
                onTap: () {
                  focusNode2.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择申请科室",
                          url: "/sections/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['sectionName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("sectionId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "staffName",
                focusNode: focusNode3,
                decoration: InputDecoration(labelText: "科室负责人"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择科室负责人!",
                  ),
                ]),
                onTap: () {
                  focusNode3.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择科室负责人",
                          url: "/staff/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['staffName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("staffId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "mobile",
                decoration: InputDecoration(labelText: "科室负责人手机"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请填写科室负责人手机!",
                  ),
                  FormBuilderValidators.numeric(
                    errorText: "请输入数字",
                  ),
                ]),
              ),
              FormBuilderTextField(
                name: "fillStaffName",
                focusNode: focusNode4,
                decoration: InputDecoration(labelText: "填表人"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择填表人!",
                  ),
                ]),
                onTap: () {
                  focusNode4.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择填表人",
                          url: "/staff/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['fillStaffName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("fillStaffId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "fillMobile",
                decoration: InputDecoration(labelText: "填表人手机"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请填写填表人手机!",
                  ),
                  FormBuilderValidators.numeric(
                    errorText: "请输入数字!",
                  ),
                ]),
              ),
              FormBuilderTextField(
                name: "reasons",
                maxLines: 3,
                decoration: InputDecoration(labelText: "申请原因"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请填写申请原因!",
                  ),
                ]),
              ),
              FormBuilderTextField(
                name: "remark",
                maxLines: 3,
                decoration: InputDecoration(labelText: "备注"),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: ElevatedButton(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("附件",
                              style: TextStyle(
                                  fontSize: 14,
                                  color: ThemeColor.getColor("fontColor"))),
                          Row(
                            children: [
                              MaterialButton(
                                child: Text("上传"),
                                onPressed: () async {
                                  var url = await uploadFile(
                                      title: "附件上传中", type: FileType.any);
                                  if (url == null) {
                                    return;
                                  }
                                  var d = {"id": data["id"], "attach": url};
                                  post("/equipmentpurchase/updateField", {...d})
                                      .then((value) {
                                    if (value["success"]) {
                                      setState(() {
                                        data["attach"] = url;
                                      });
                                      showSuccessToast("上传申请表成功！");
                                    }
                                  });
                                },
                              ),
                              Visibility(
                                visible:
                                    data != null && data["attachs"] != null,
                                child: Container(
                                  child: MaterialButton(
                                      child: Text("删除"),
                                      onPressed: () {
                                        setState(() {
                                          data["attachs"] = null;
                                        });
                                      }),
                                  margin: const EdgeInsets.only(left: 10.0),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            child: Text(
                                "${data != null && data['attachs'] != null ? data['attachs'].toString().substring(data['attachs'].toString().lastIndexOf('/') + 1) : ''}"),
                            margin:
                                const EdgeInsets.only(top: 10.0, bottom: 10.0),
                          )
                        ],
                      ),
                    ],
                  ),
                  onPressed: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    if (_fbKey.currentState.saveAndValidate()) {
                      setState(() {
                        this.data = Map.of(_fbKey.currentState.value);
                        page = 1;
                      });
                      _pageController.nextPage(
                          duration: Duration(milliseconds: 200),
                          curve: Curves.linear);
                    }
                  },
                ),
              ),
              Divider(),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: ElevatedButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [Text("下一步"), Icon(Icons.arrow_forward)],
                  ),
                  onPressed: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    if (_fbKey.currentState.saveAndValidate()) {
                      setState(() {
                        this.data = Map.of(_fbKey.currentState.value);
                        page = 1;
                      });
                      _pageController.nextPage(
                          duration: Duration(milliseconds: 200),
                          curve: Curves.linear);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _buildTable(context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 5, top: 10),
            child: Text(
              "设备申购详情列表",
              style: TextStyle(fontSize: 20),
            ),
          ),
          Visibility(
            visible: itemList.length == 0,
            child: EmptyWidget(
              height: 200,
              child: Text("暂无设备申购详情信息，请添加！"),
            ),
          ),
          Visibility(
            visible: itemList.length > 0,
            child: Container(
              child: Column(
                children: itemList.map((item) {
                  return Column(
                    children: [
                      Slidable(
                        child: Container(
                          child: ListTile(
                            title: Text("物资名称:${item['name']}"),
                            subtitle: Text("数量:${item['total']}"),
                          ),
                        ),
                        endActionPane: ActionPane(
                          motion: ScrollMotion(),
                          children: [
                            SlidableAction(
                              label: '编辑',
                              backgroundColor: ThemeColor.getColor("info"),
                              icon: Icons.edit,
                              onPressed: (BuildContext context) =>
                                  editItem(item),
                            ),
                            SlidableAction(
                              label: '删除',
                              backgroundColor: ThemeColor.getColor("danger"),
                              icon: Icons.delete,
                              onPressed: (BuildContext context) =>
                                  deleteItem(item),
                            ),
                          ],
                        ),
                      ),
                      Divider(),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  child: Row(
                    children: [
                      Text("上一步"),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_back)
                    ],
                  ),
                  onPressed: () {
                    setState(() {
                      page = 0;
                    });
                    _pageController.previousPage(
                        duration: Duration(milliseconds: 200),
                        curve: Curves.linear);
                  },
                ),
                ElevatedButton(
                  child: Row(
                    children: [
                      Text("完成"),
                      SizedBox(width: 5),
                      Icon(Icons.check)
                    ],
                  ),
                  onPressed: () {
                    save(context);
                  },
                )
              ],
            ),
          )
        ],
      ),
    );
  }

  initItemList() {
    if (data != null && data != {}) {
      get("/equipmentpurchasedetails/listQueryById/${data["id"]}")
          .then((value) {
        if (value != null && value["success"]) {
          var data = value["data"];
          if (data["total"] > 0) {
            itemList = data["rows"];
            itemList.forEach((element) {
              element["isExpanded"] = false;
            });
          }
        }
      });
    }
  }

  deleteItem(item) {
    showConfirmAlert("是否删除申购设备：${item['name']}").then((bool) {
      if (bool) {
        if (item["id"] != null) {
          post("/equipmentpurchasedetails/delete", {"id": item["id"]})
              .then((value) {
            if (value["success"]) {
              setState(() {
                itemList.remove(item);
              });
            }
          });
        } else {
          setState(() {
            itemList.remove(item);
          });
        }
      }
    });
  }

  editItem(item) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => new EquipmentPurchaseItemForm(item),
        )).then((value) {
      if (value != null) {
        var index = itemList.indexOf(item);
        itemList[index] = value;
        setState(() {
          this.itemList = itemList;
        });
      }
    });
  }

  toItemForm(data) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => new EquipmentPurchaseItemForm(data),
        )).then((value) {
      if (value != null) {
        itemList.add(value);
        setState(() {
          this.itemList = itemList;
        });
      }
    });
  }

  save(context) {
    if (itemList == null || itemList.length < 1) {
      return showErrorAlert("请至少添加一条申购详情数据");
    }
    var equipmentPurchase = this.data;
    if (equipmentPurchase != null) {
      var date = equipmentPurchase["purchaseDate"] as DateTime;
      equipmentPurchase["purchaseDate"] = date.toString().substring(0, 7);
    }
    var params = {
      "equipmentPurchase": equipmentPurchase,
      "equipmentPurchaseDetailList": itemList
    };
    post("/equipmentpurchase/saveDto", params).then((value) {
      if (value["success"]) {
        loading = false;
        Navigator.pop(context, true);
      }
    }).catchError((error) {
      loading = false;
      showErrorAlert(error["msg"]);
    });
  }
}
