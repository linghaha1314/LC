import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/component/EmptyWidget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:intl/intl.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

import '../../../ThemeColor.dart';

class SuppliesHighReceiveForm extends BaseApp {
  SuppliesHighReceiveForm();

  @override
  _SuppliesHighReceiveFormState createState() =>
      new _SuppliesHighReceiveFormState();
}

class _SuppliesHighReceiveFormState extends BaseAppPage {
  String typeId;
  List<dynamic> itemList = [];
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();

  _SuppliesHighReceiveFormState() {
    title = "添加高值耗材领用";
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    getTypeId();
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(16.0),
        child: Column(children: [
          Container(
            alignment: Alignment.topLeft,
            margin: EdgeInsets.only(bottom: 5),
            child: Text(
              "高值耗材领用基本信息",
              style: TextStyle(fontSize: 16),
            ),
          ),
          _formView(),
          Container(
            alignment: Alignment.topLeft,
            margin: EdgeInsets.only(bottom: 5, top: 20),
            child: Text(
              "高值耗材领用详情列表",
              style: TextStyle(fontSize: 16),
            ),
          ),
          _detailListView(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择耗材",
                          multiple: true,
                          url: "/storehousearticle/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {
                            "typeCode": "suppliesType_high",
                            "total": "1"
                          },
                        ),
                      )).then((value) {
                    if (value != null) {
                      value.forEach((item) {
                        itemList.add({
                          "articleId": item["id"],
                          "code": item["code"],
                          "name": item["name"],
                          "unitName": item["unitName"],
                          "specificationName": item["specificationName"],
                          "storehouseName": item["storehouseName"],
                          "curTotal": (item["total"] as double).toInt(),
                        });
                      });
                      setState(() {});
                    }
                  });
                },
                icon: Icon(Icons.add),
                label: Text("添加"),
              ),
              SizedBox(width: 10),
              ElevatedButton.icon(
                onPressed: () {
                  save(context);
                },
                icon: Icon(Icons.check),
                label: Text("保存"),
              ),
            ],
          )
        ]),
      ),
    );
  }

  _formView() {
    DateFormat dateFormat = DateFormat("yyyy-MM-dd");
    var now = dateFormat.format(new DateTime.now());
    return Card(
      child: FormBuilder(
        key: _fbKey,
        initialValue: {},
        child: Column(
          children: [
            FormBuilderTextField(
              name: "receiveDate",
              initialValue: now,
              readOnly: true,
              decoration: InputDecoration(labelText: "申领日期"),
            ),
            FormBuilderTextField(
              name: "placeName",
              focusNode: focusNode1,
              decoration: InputDecoration(labelText: "使用场地"),
              onTap: () {
                focusNode1.unfocus();
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SelectPage(
                        title: "选择使用场地",
                        url: "/place/listQueryByPage",
                        searchText: "输入名称进行搜索",
                        queryParams: {},
                      ),
                    )).then((value) {
                  if (value != null) {
                    _fbKey.currentState.setState(() {
                      _fbKey.currentState.fields['placeName']
                          .didChange(value["name"]);
                      _fbKey.currentState
                          .setInternalFieldValue("placeId", value["id"]);
                    });
                  }
                });
              },
            ),
            FormBuilderTextField(
              name: "useName",
              focusNode: focusNode2,
              decoration: InputDecoration(labelText: "用途"),
              onTap: () {
                focusNode2.unfocus();
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SelectPage(
                        title: "选择用途",
                        url:
                            "/dictionarydata/listQueryByTypeCode/receiveUseType",
                        searchText: "输入名称进行搜索",
                        queryParams: {},
                      ),
                    )).then((value) {
                  if (value != null) {
                    _fbKey.currentState.setState(() {
                      _fbKey.currentState.fields['useName']
                          .didChange(value["name"]);
                      _fbKey.currentState
                          .setInternalFieldValue("useId", value["id"]);
                    });
                  }
                });
              },
            ),
            FormBuilderTextField(
              name: "remark",
              maxLines: 3,
              decoration: InputDecoration(labelText: "领用说明"),
            ),
          ],
        ),
      ),
    );
  }

  _detailListView() {
    if (itemList.length == 0) {
      return EmptyWidget(
        height: 200,
        child: Text("暂无高值耗材领用详情信息，请添加！"),
      );
    } else {
      return Container(
        child: Column(
          children: itemList.map((item) {
            return _itemView(item);
          }).toList(),
        ),
      );
    }
  }

  Widget _itemView(item) {
    var controller = new TextEditingController();
    var prodDateCtl = new TextEditingController();
    return Slidable(
      child: Card(
        child: Container(
          child: Column(
            children: <Widget>[
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('材料名称:'),
                    Text(showString(item['name'])),
                  ],
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('材料编码:'),
                        Text(showString(item['code'])),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('规格:'),
                        Text(showString(item['specificationName'])),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('存放地:'),
                        Text(showString(item['storehouseName'])),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('剩余数量:'),
                        Text(
                            '${item['curTotal']} ${showString(item['unitName'])}')
                      ],
                    ),
                    Row(
                      children: [
                        Text("领用数量:"),
                        Expanded(
                          flex: 1,
                          child: TextField(
                            controller: controller,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly
                            ],
                            textAlign: TextAlign.right,
                            onChanged: (v) {
                              if (v != null && v != "") {
                                if (double.parse(v) > item["curTotal"]) {
                                  item["total"] = item["curTotal"].toString();
                                  controller.text = item["curTotal"].toString();
                                } else {
                                  item["total"] = v.toString();
                                }
                              } else {
                                item["total"] = v.toString();
                              }
                            },
                          ),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        Text("生产日期:"),
                        Expanded(
                          flex: 1,
                          child: TextField(
                            controller: prodDateCtl,
                            textAlign: TextAlign.right,
                            onTap: () {
                              showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1997),
                                lastDate: DateTime.now(),
                              ).then((DateTime value) {
                                if (value != null) {
                                  prodDateCtl.text =
                                      "${value.year}-${value.month}-${value.day}";
                                  item["prodDate"] = prodDateCtl.text;
                                }
                              });
                            },
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      endActionPane: ActionPane(
        motion: ScrollMotion(),
        children: [
          SlidableAction(
            label: '删除',
            backgroundColor: ThemeColor.getColor("danger"),
            icon: Icons.delete,
            onPressed: (BuildContext context) =>
                deleteItem(item),
          ),
        ],
      ),
    );
  }

  deleteItem(item) {
    showConfirmAlert("是否取消领用耗材：${item['name']}").then((bool) {
      if (bool) {
        setState(() {
          itemList.remove(item);
        });
      }
    });
  }

  getTypeId() {
    setState(() {
      loading = true;
    });
    post("/dictionarydata/listQueryByPage", {"code": "suppliesType_high"})
        .then((value) {
      if (value["total"] > 0) {
        typeId = value["rows"][0]["id"];
        setState(() {
          loading = false;
        });
      }
    }).catchError((error) {
      setState(() {
        loading = false;
      });
      showErrorAlert(error["msg"]);
    });
  }

  save(context) async {
    if (itemList == null || itemList.length < 1) {
      return showErrorAlert("请至少添加一条高值耗材领用详情数据");
    }
    var user = await getCurrentAccount();
    var details = [];
    var names = [];
    double total = 0;
    var err = false;
    itemList.forEach((element) {
      var itemTotal = element["total"];
      if (itemTotal == null) {
        err = true;
        return showErrorToast("耗材【${element['name']}】未填写领用数量");
      }
      total += double.parse(element["total"]);
      details.add('${element["name"]}（${element["total"]}）');
      names.add(element["name"]);
    });
    if (err) {
      return;
    }
    var articleReceiving = Map.of(_fbKey.currentState.value);
    var name = names.toString();
    articleReceiving["name"] = name.substring(1, name.length - 1);
    articleReceiving["total"] = total;
    articleReceiving["staffId"] = user.staff["id"];
    articleReceiving["typeId"] = typeId;
    var params = {
      "articleReceiving": articleReceiving,
      "receiveList": itemList,
      "apply": "true",
      "urgentStatus": 0,
      "name": '${user.staff["name"]}申请领用高值耗材：${details.toString()}',
    };
    post("/articlereceiving/saveDto", params).then((value) {
      if (value["success"]) {
        loading = false;
        Navigator.pop(context, true);
      }
    }).catchError((error) {
      loading = false;
      showErrorAlert(error["msg"]);
    });
  }
}
