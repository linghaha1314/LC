import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:csc_app/component/MethodComponent.dart';

import '../../../ThemeColor.dart';
import './SuppliesHighReceiveView.dart';
import './SuppliesHighReceiveForm.dart';

class SuppliesHighReceivePage extends BaseApp {
  @override
  _SuppliesHighReceivePageState createState() =>
      new _SuppliesHighReceivePageState();
}

class _SuppliesHighReceivePageState extends BaseAppPage<SuppliesHighReceivePage>
    with SingleTickerProviderStateMixin {
  var tabController;
  RefreshController receivedController =
      RefreshController(initialRefresh: true);
  RefreshController auditController = RefreshController(initialRefresh: true);

  var statusIconList = [
    Icons.vertical_align_top,
    Icons.close,
    Icons.check,
    Icons.pause,
    Icons.check,
  ];

  var statusList = ["待提交", "已驳回", "已审核", "审核中", "您已审核"];

  var statusColorList = [
    ThemeColor.getColor("info"),
    ThemeColor.getColor("danger"),
    ThemeColor.getColor("success"),
    ThemeColor.getColor("warning"),
    ThemeColor.getColor("success")
  ];

  _SuppliesHighReceivePageState() {
    title = "高值耗材领用";
  }

  @override
  void initState() {
    super.initState();
    tabController = TabController(
        vsync: this, // 动画效果的异步处理
        length: 2, // tab 个数
        initialIndex: 0 // 起始位置
        );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        onPressed: () {
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new SuppliesHighReceiveForm()),
          ).then((value) => {
                if (value)
                  {
                    showSuccessToast("添加成功!"),
                    receivedController.requestRefresh(),
                    auditController.requestRefresh()
                  }
              });
        },
        tooltip: "添加",
        icon: Icon(Icons.add),
      )
    ];
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
          controller: this.tabController,
          tabs: <Tab>[
            Tab(text: '审批列表'),
            Tab(text: '已领用列表'),
          ],
        ),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: [
        RefreshList(
          controller: auditController,
          searchText: "请输入材料名称进行搜索",
          url: "/articlereceiving/listQueryByPage",
          queryParams: {
            "processType": "apply",
            "typeCode": "suppliesType_high"
          },
          queryKey: "name",
          buildItem: (dynamic row, int i) {
            return _buildAuditRow(row);
          },
        ),
        RefreshList(
          controller: receivedController,
          searchText: "请输入材料名称进行搜索",
          url: "/articlereceiving/listQueryByPage",
          queryParams: {"status": "2", "typeCode": "suppliesType_high"},
          queryKey: "name",
          buildItem: (dynamic row, int i) {
            return _buildReceivedRow(row);
          },
        ),
      ],
    );
  }

  _buildReceivedRow(row) {
    return ListTile(
      title: Container(
        child: Text('材料名称: ${row["name"]}', style: TextStyle(fontSize: 16)),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('领用数量: ${row["total"]}'),
          Text('领用日期：${row["receiveDate"]}'),
          Text('使用场地：${row["placeName"] == null ? "-" : row["placeName"]}')
        ],
      ),
      onTap: () {
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new SuppliesHighReceiveView(row)),
        ).then((value) {
          if (value) {
            receivedController.requestRefresh();
          }
        });
      },
    );
  }

  _buildAuditRow(row) {
    return ListTile(
      title: Container(
        child: Text('材料名称: ${row["name"]}', style: TextStyle(fontSize: 16)),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('领用数量: ${row["total"]}'),
          Text('领用日期：${row["receiveDate"]}'),
          Text('使用场地：${row["placeName"] == null ? "-" : row["placeName"]}')
        ],
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Chip(
            backgroundColor: statusColorList[getStatus(row)],
            label: Row(
              children: [
                Text(
                  statusList[getStatus(row)],
                  style: TextStyle(
                      color: ThemeColor.getColor("fontColor"), fontSize: 12),
                ),
                Icon(
                  statusIconList[getStatus(row)],
                  color: ThemeColor.getColor("fontColor"),
                  size: 12,
                ),
              ],
            ),
          ),
        ],
      ),
      onTap: () {
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new SuppliesHighReceiveView(row)),
        ).then((value) {
          if (value) {
            auditController.requestRefresh();
          }
        });
      },
    );
  }

  getStatus(data) {
    var status = data["status"];
    var taskStatus = data["taskStatus"];
    if (status == null) {
      return 0;
    } else if (status == 1) {
      return 1;
    } else if (status == 2) {
      return 2;
    }
    if (status == 0 && (taskStatus == "0" || taskStatus == null)) {
      return 3;
    }
    if (status == 0 && taskStatus == "1") {
      return 4;
    }
  }

  @override
  void dispose() {
    this.tabController.dispose();
    super.dispose();
  }
}
