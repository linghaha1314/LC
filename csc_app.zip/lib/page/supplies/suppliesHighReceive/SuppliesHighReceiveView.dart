import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

import '../../../ThemeColor.dart';

class SuppliesHighReceiveView extends BaseApp {
  final Map data;

  SuppliesHighReceiveView(this.data);

  @override
  _SuppliesHighReceiveViewState createState() =>
      new _SuppliesHighReceiveViewState(data);
}

class _SuppliesHighReceiveViewState
    extends BaseAppPage<SuppliesHighReceiveView> {
  dynamic data;
  List<dynamic> itemList = [];

  _SuppliesHighReceiveViewState(data) {
    this.data = data;
    title = "高值耗材领用详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return Scrollbar(
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 10,
              ),
              _dataView(),
              Visibility(
                visible: (itemList != null && itemList.length > 0),
                child: _detailList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  dynamic getPopupItem() {
    var status = this.data["status"];
    var taskStatus = this.data["taskStatus"];
    var popupList = <PopupMenuEntry<dynamic>>[];
    if (status == 1 || (status == 0 && taskStatus == 1) || status == 2) {
      popupList.add(new PopupMenuItem(
          value: "processInstance",
          child: ListTile(title: new Text("审批进程"), leading: Icon(Icons.menu))));
    }
    return popupList;
  }

  @override
  void initState() {
    super.initState();
    initItemList();
  }

  initItemList() {
    setState(() {
      loading = true;
    });
    post("/receivingitem/listQueryByPage", {"receivingId": data["id"]})
        .then((value) {
      setState(() {
        loading = false;
        itemList = value["rows"];
        empty = false;
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  _dataView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "高值耗材领用基本信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _textView("材料名称", data["name"]),
                          Divider(),
                          _textView(" 领用数量", data["total"].toString()),
                          Divider(),
                          _textView("领用人", data["staffName"]),
                          Divider(),
                          _textView("领用日期", data["receiveDate"]),
                          Divider(),
                          _textView("使用场地", data["placeName"]),
                          Divider(),
                          _textView("用途", data["useName"]),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child:
                                  Text("领用说明", style: TextStyle(fontSize: 15)),
                            ),
                            subtitle: Text((data["receiveInfo"] != null &&
                                    data["receiveInfo"] != '')
                                ? data["receiveInfo"]
                                : "无"),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _detailList() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "高值耗材领用列表",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Column(
              children: itemList.map<Widget>((item) {
                return Column(
                  children: [_itemView(item), Divider()],
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  _itemView(item) {
    return ListTile(
      title: Container(
        child: Text('材料名称: ${item["name"]}', style: TextStyle(fontSize: 16)),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('材料编码: ${item["code"] == null ? "-" : item["code"]}'),
          Text('领用数量: ${item["total"]}'),
        ],
      ),
    );
  }

  _textView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 14),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }
}
