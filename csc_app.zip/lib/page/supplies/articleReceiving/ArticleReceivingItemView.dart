import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter/material.dart';

class ArticleReceivingItemView extends BaseApp {
  final dynamic data;

  ArticleReceivingItemView(this.data);

  @override
  _ArticleReceivingItemViewState createState() =>
      new _ArticleReceivingItemViewState(this.data);
}

class _ArticleReceivingItemViewState
    extends BaseAppPage<ArticleReceivingItemView> {
  dynamic data;

  _ArticleReceivingItemViewState(this.data) {
    title = "耗材详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(15),
        child: Card(
          child: Column(
            children: [
              _textView("批次编码", data["batch"]),
              Divider(),
              _textView("材料名称", data["name"]),
              Divider(),
              _textView("材料编码", data["code"]),
              Divider(),
              _textView("数量", data["maxTotal"]),
              Divider(),
              _textView("单价(元)", data["price"]),
              Divider(),
              _textView("单位", data["unitName"]),
              Divider(),
              _textView("品牌", data["brandName"]),
              Divider(),
              _textView("保质期", data["expirationDate"]),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    empty = data == null;
  }

  _textView(name, value) {
    if (value == null || value == "") {
      value = "-";
    }
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name),
          Text(value.toString()),
        ],
      ),
    );
  }
}
