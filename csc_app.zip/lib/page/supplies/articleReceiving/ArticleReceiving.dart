import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:decimal/decimal.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter/services.dart';
import 'package:form_builder_validators/form_builder_validators.dart';

class ArticleReceiving extends BaseApp {
  @override
  _ArticleReceivingState createState() => new _ArticleReceivingState();
}

class _ArticleReceivingState extends BaseAppPage<ArticleReceiving> {
  dynamic data;
  String storehouseId;
  List<dynamic> itemList = [];
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();

  _ArticleReceivingState() {
    title = "耗材领用";
  }

  @override
  initRouteSuccess() {
    if (routeData != null) {
      setState(() {
        this.itemList = routeData;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return Scrollbar(
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 10,
              ),
              Visibility(
                visible: (itemList != null && itemList.length > 0),
                child: _detailList(),
              ),
              _formView()
            ],
          ),
        ),
      ),
    );
  }

  Widget _formView() {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(16.0),
        child: FormBuilder(
          key: _fbKey,
          initialValue: this.data != null ? data : {},
          child: Column(
            children: [
              FormBuilderTextField(
                name: "placeName",
                focusNode: focusNode1,
                decoration: InputDecoration(labelText: "领用场地"),
                onTap: () {
                  focusNode1.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择类型",
                          url: "/place/listQueryByPage",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['placeName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("placeId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "useName",
                focusNode: focusNode2,
                decoration: InputDecoration(labelText: "用途(必填)"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(errorText: "请选择领用场地!"),
                ]),
                onTap: () {
                  focusNode2.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择用途",
                          url:
                              "/dictionarydata/listQueryByTypeCode/receiveUseType",
                          searchText: "输入名称进行搜索",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['useName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("useId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "receiveInfo",
                maxLines: 3,
                decoration: InputDecoration(labelText: "领用说明"),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: TextButton(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [Text("保存"), Icon(Icons.arrow_forward)],
                  ),
                  onPressed: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    if (_fbKey.currentState.saveAndValidate()) {
                      save(context);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailList() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "耗材领用列表",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Column(
              children: itemList.map<Widget>((item) {
                return _itemView(item);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  _itemView(row) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('材料名称:'),
          Text(showString(row['name'])),
        ],
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('材料编码:'),
              Text(showString(row['code'])),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('规格:'),
              Text(showString(row['specificationName'])),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('存放地:'),
              Text(showString(row['storehouseName'])),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('剩余数量:'),
              Text(
                  '${(row['maxTotal'] as double).toInt()} ${showString(row['unitName'])}')
            ],
          ),
          Row(
            children: [
              Text("领用数量(必填):"),
              Expanded(
                flex: 1,
                child: TextFormField(
                  initialValue: "${row["total"] ?? ""}",
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  textAlign: TextAlign.right,
                  onChanged: (v) {
                    var input = Decimal.parse(v).toBigInt();
                    var maxTotal = Decimal.parse(row["maxTotal"].toString()).toBigInt();
                    if (input > maxTotal) {
                      showErrorAlert("领用数量[$input]不能大于剩余数量[$maxTotal]请重新输入!");
                      row["total"] = null;
                      return;
                    }
                    setState(() {
                      row["total"] = input;
                    });
                  },
                ),
              )
            ],
          ),
          Row(
            children: [
              Text("生产日期:"),
              Expanded(
                flex: 1,
                child: TextField(
                  textAlign: TextAlign.right,
                  onTap: () {
                    showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1997),
                      lastDate: DateTime.now(),
                    ).then((DateTime value) {
                      if (value != null) {
                        row["prodDate"]  = "${value.year}-${value.month}-${value.day}";
                      }
                    });
                  },
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  save(context) {
    var list = [];
    var total = 0;
    var names = "";
    var errorList = [];
    for (int i = 0; i < itemList.length; i++) {
      var item = itemList[i];
      if (item["total"] != null && item["total"] != 0) {
        total += item["total"] as int;
        list.add(item);
        names += "${item["name"]},";
      } else {
        errorList.add(item["name"]);
      }
      item["status"] = "2";
    }
    if (errorList.length > 0) {
      showErrorAlert("请填写物品[${errorList.join(",")}]领用数量");
      return;
    }
    if (list.length < 1) {
      showErrorToast("请至少领用一种物资(数量不为0)");
      return;
    }
    names = names.substring(0, names.length - 1);
    dynamic articleReceiving = Map.of(_fbKey.currentState.value);
    articleReceiving["name"] = names;
    articleReceiving["total"] = total;
    articleReceiving["typeId"] = itemList[0]["storehouseArticleTypeId"];
    if (articleReceiving["useId"] == null) {
      showErrorToast("请选择用途!");
      return;
    }
    var params = {
      "articleReceiving": articleReceiving,
      "receiveList": itemList,
    };
    post("/articlereceiving/saveDto", params).then((value) {
      if (value["success"]) {
        loading = false;
        Navigator.pop(context, true);
        showSuccessToast("领用成功!");
      }
    }).catchError((error) {
      loading = false;
      showErrorAlert(error["msg"]);
    });
  }
}
