import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/MethodComponent.dart';

class ArticleInventoryForm extends BaseApp {
  @override
  _ArticleInventoryFormState createState() => new _ArticleInventoryFormState();
}

class _ArticleInventoryFormState extends BaseAppPage<ArticleInventoryForm> {
  List<dynamic> itemList = [];
  String storehouseId;

  _ArticleInventoryFormState() {
    title = '耗材盘点';
    empty = false;
  }

  @override
  Widget getBody(BuildContext context) {
    return Scrollbar(
      child: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _itemListView(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  MaterialButton(
                    color: ThemeColor.getColor("info"),
                    child: Row(
                      children: [Text("保存"), Icon(Icons.check)],
                    ),
                    onPressed: () {
                      save();
                    },
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  initRouteSuccess() {
    if (routeData != null && routeData["storehouseId"] != null) {
      this.storehouseId = routeData["storehouseId"];
      initItemList();
    }
  }

  Widget _itemListView() {
    List<Widget> itemViewList = [];
    this.itemList.forEach((item) {
      itemViewList.add(_itemView(item));
    });
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: itemViewList,
    );
  }

  _itemView(item) {
    return Card(
      child: Container(
        alignment: Alignment.topLeft,
        child: Column(
          children: <Widget>[
            Column(
              children: <Widget>[
                ...ListTile.divideTiles(
                  color: ThemeColor.getColor("border"),
                  tiles: [
                    _textView("耗材名称", item["name"]),
                    Divider(),
                    _textView("耗材编码", item["code"]),
                    Divider(),
                    _textView("规格", item["specificationName"]),
                    Divider(),
                    _textView("数量", item["storehouseTotal"]),
                    Divider(),
//                    ListTile(
//                      title: Row(
//                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                        children: [
//                          Text("状态"),
//                          Row(
//                            mainAxisAlignment: MainAxisAlignment.end,
//                            children: [
//                              _radioView(2, "正常", item),
//                              _radioView(0, "盘亏", item),
//                              _radioView(1, "盘余", item),
//                            ],
//                          )
//                        ],
//                      ),
//                    ),
                    Visibility(
//                      visible: item["status"] != 2,
                      child: Column(
                        children: [
                          Divider(),
                          ListTile(
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("盘点数量"),
                                SizedBox(
                                  width: 100,
                                  child: TextField(
                                    keyboardType: TextInputType.number,
                                    onChanged: (v) {
                                      item["total"] = v;
                                    },
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                Divider(),
              ],
            )
          ],
        ),
      ),
    );
  }

  changeItemStatus(item, value) {
    setState(() {
      item["status"] = value;
    });
  }

  _radioView(value, text, item) {
    return Row(
      children: [
        Radio(
          value: value,
          groupValue: item["status"],
          visualDensity: VisualDensity.compact,
          onChanged: (v) => {changeItemStatus(item, v)},
        ),
        Text(text, style: TextStyle(fontSize: 12)),
      ],
    );
  }

  _textView(name, value) {
    if (value == null || value == "") {
      value = "-";
    }
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name),
          Text(value.toString(), style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  initItemList() {
    if (this.storehouseId != null && this.storehouseId != "") {
      setState(() {
        loading = true;
      });
      post("/storehousearticle/listQueryByPage", {
        "storehouseId": this.storehouseId,
        "shortCode": "supplies"
      }).then((value) {
        if (value != null && value["total"] > 0) {
          itemList = [];
          value["rows"].forEach((item) {
            itemList.add({
              "name": item["name"],
              "code": item["code"],
              "specificationName": item["specificationName"],
              "storehouseTotal": item["total"],
              "total": 0,
              "articleId": item["id"],
              "status": 2,
            });
          });
          setState(() {
            this.itemList = itemList;
            this.empty = false;
            loading = false;
          });
        } else {
          setState(() {
            this.empty = true;
            loading = false;
          });
        }
      });
    }
  }

  save() {
    var saveList = [];
    itemList.forEach((element) {
      if (element["total"] != null && element["total"] != '') {
        saveList.add(element);
      }
    });
    setState(() {
      loading = true;
    });
    post("/articleinventory/saveOrUpdateList", saveList).then((value) {
      if (value["success"]) {
        showSuccessToast("操作成功!");
        setState(() {
          loading = false;
        });
        Navigator.pop(context);
      }
    }).catchError((error) {
      setState(() {
        loading = false;
      });
      showErrorAlert(error["msg"]);
    });
  }
}
