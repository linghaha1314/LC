import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class ArticleInventoryPage extends BaseApp {
  @override
  _ArticleInventoryPageState createState() => new _ArticleInventoryPageState();
}

class _ArticleInventoryPageState extends BaseAppPage<ArticleInventoryPage> {
  RefreshController _controller;

  _ArticleInventoryPageState() {
    title = "耗材盘点";
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
      controller: _controller,
      searchText: "请输入名称或编码进行搜索",
      url: "/storehousearticle/suppliesQueryByPage",
      buildItem: (dynamic row, int i) {
        return _bodyContentOne(row);
      },
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        onPressed: () {
          Navigator.pushNamed(context, "articleInventoryQR").then((value) {
            _controller.requestRefresh();
          });
        },
        tooltip: "扫库房码盘点",
        icon: Icon(MdiIcons.qrcodeScan),
      ),
    ];
  }

  _bodyContentOne(data) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(data["name"]), Text(data["typeName"])],
      ),
      subtitle: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("库房:${data["placeName"]}"),
              Text("编码:${data["code"] != null ? data["code"] : '无'}"),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("货架:${data["shelf"]}"),
              Text("数量:${data["total"]}"),
            ],
          )
        ],
      ),
      onTap: () {
        Navigator.pushNamed(context, "articleInventory", arguments: data)
            .then((value) {
          _controller.requestRefresh();
        });
      },
    );
  }

  @override
  void initState() {
    empty = false;
    _controller = RefreshController(initialRefresh: false);
    super.initState();
  }
}
