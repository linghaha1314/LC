import 'dart:convert';

import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vibrate/flutter_vibrate.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

class ArticleInventoryQRCodePage extends BaseApp {
  @override
  _ArticleInventoryQRCodePageState createState() =>
      new _ArticleInventoryQRCodePageState();
}

class _ArticleInventoryQRCodePageState
    extends BaseAppPage<ArticleInventoryQRCodePage> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController controller;
  var flag = false;

  _ArticleInventoryQRCodePageState() {
    title = '扫描库房二维码';
    empty = false;
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      appBar: barFlag ? getAppBar(context) : null,
      body: empty ? emptyWidget : getBody(context),
      drawer: empty ? null : getDraw(context),
      bottomNavigationBar: empty ? null : getBottom(context),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: <Widget>[
        Expanded(
          flex: 1,
          child: QRView(
            key: qrKey,
            onQRViewCreated: _onQRViewCreated,
            overlay: QrScannerOverlayShape(
              borderColor: ThemeColor.getColor("border"),
              borderRadius: 10,
              borderLength: 30,
              borderWidth: 10,
              cutOutSize: 300,
            ),
          ),
        ),
      ],
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.resumeCamera();
    controller.scannedDataStream.listen((scanData) {
      if (!flag) {
        flag = true;
        Vibrate.feedback(FeedbackType.success);
        var d = jsonDecode(scanData.code);
        Navigator.popAndPushNamed(context, "articleInventory",
            arguments: d["params"]);
      }
    });
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }
}
