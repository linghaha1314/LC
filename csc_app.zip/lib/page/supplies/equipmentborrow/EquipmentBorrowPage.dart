import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../../../ThemeColor.dart';
import 'EquipmentBorrowForm.dart';
import 'EquipmentBorrowReturnView.dart';
import 'EquipmentBorrowView.dart';

class EquipmentBorrowPage extends BaseApp {
  @override
  _EquipmentBorrowReceivingFormState createState() =>
      new _EquipmentBorrowReceivingFormState();
}

class _EquipmentBorrowReceivingFormState
    extends BaseAppPage<EquipmentBorrowPage>
    with SingleTickerProviderStateMixin {
  var tabController;

  _EquipmentBorrowReceivingFormState() {
    title = "借用管理";
  }

  RefreshController borrowController = RefreshController(initialRefresh: true);
  RefreshController returnController = RefreshController(initialRefresh: true);

  Map statusMap = {1: "已驳回", 2: "已同意", 0: "待审核", 3: "待提交"};

  Map returnStatusMap = {1: "已归还", 0: "未归还"};

  Map statusColorMap = {
    1: ThemeColor.getColor("danger"),
    2: ThemeColor.getColor("success"),
    3: ThemeColor.getColor("warning"),
    0: ThemeColor.getColor("info"),
  };

  Map statusIconMap = {
    1: Icons.close,
    2: Icons.check,
    3: Icons.vertical_align_top,
    0: Icons.pause,
  };

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.add),
        tooltip: "申请借用",
        onPressed: () async {
          var res = await post("/configparameter/getConfigParams",
              {"configCode": "BorrowMessage"});
          var msg;
          if (res["success"]) {
            dynamic data = res["data"];
            if (data["cfgValue"] != null) {
              msg = data["cfgValue"];
            } else {
              msg = data["defaultValue"];
            }
          }
          if (msg != null) {
            showConfirmAlert(msg, ok: "我同意", height: 400.0).then((val) {
              if (val) {
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => new EquipmentBorrowForm(null)),
                ).then((value) {
                  if (value == true) {
                    borrowController.requestRefresh();
                  }
                });
              }
            });
            return;
          }
          Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new EquipmentBorrowForm(null)),
          ).then((value) {
            if (value == true) {
              borrowController.requestRefresh();
            }
          });
        },
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: [
        RefreshList(
          url: "/equipmentwarehousing/listQueryByPage",
          searchText: "输入设备名称进行搜索",
          queryParams: {"borrowFlag": true},
          buildItem: (dynamic row, int i) {
            return ListTile(
                title: Text(row["name"]),
                trailing: Chip(
                  label: Text(row["borrowStatus"] == true ? "已借用" : "未借用"),
                  backgroundColor: row["borrowStatus"] == true
                      ? ThemeColor.getColor("warning")
                      : ThemeColor.getColor("info"),
                ),
                subtitle: Row(
                  children: [
                    Text(
                        "编号:${showString("${row["assetNumber"] ?? row["code"]}")}"),
                    Text(" 管理员:${showString(row["managerStaffName"])}"),
                  ],
                ),
                onTap: () {
                  showInfoToast("请点击右上角申请借用");
                });
          },
          tooltip: "查看可借用设备",
        ),
        RefreshList(
          controller: borrowController,
          searchText: "请输入人员名称进行搜索",
          url: "/equipmentborrow/listQueryByPage",
          buildItem: (dynamic row, int i) {
            return _bodyContentOne(row);
          },
          tooltip: "当前无申请,您可以点击右上角的加号申请设备借用",
        ),
        RefreshList(
          controller: returnController,
          searchText: "请输入接收人进行搜索",
          url: "/equipmentreturn/listEquipmentBorrowQueryByPage",
          buildItem: (dynamic row, int i) {
            return _bodyContentTwo(row);
          },
        ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    this.initTabController();
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
          controller: this.tabController,
          tabs: <Tab>[
            Tab(text: '可借设备'),
            Tab(text: '已借申请'),
            Tab(text: '设备归还'),
          ],
        ),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: getBottom(context),
    );
  }

  initTabController() {
    tabController = TabController(
        vsync: this, // 动画效果的异步处理
        length: 3, // tab 个数
        initialIndex: 0 // 起始位置
        );
  }

  Widget _bodyContentOne(data) {
    return ListTile(
      title: Text("借用人：" + data["staffName"]),
      subtitle: Text("借用日期：" + data["startDate"].toString().substring(0, 10)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Chip(
            backgroundColor:
                statusColorMap[data["status"] != null ? data["status"] : 3],
            label: Row(
              children: [
                Text(
                  "${statusMap[data["status"] != null ? data["status"] : 3]}",
                  style: TextStyle(
                    color: ThemeColor.getColor("fontColor"),
                  ),
                ),
                Icon(
                  statusIconMap[data["status"] != null ? data["status"] : 3],
                  color: ThemeColor.getColor("fontColor"),
                ),
              ],
            ),
          ),
        ],
      ),
      onTap: () {
        //跳转到详情页面
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new EquipmentBorrowView(data)),
        ).then((value) {
          if (value != null && value) {
            borrowController.requestRefresh();
          }
        });
      },
    );
  }

  Widget _bodyContentTwo(data) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("借用人：" + data["staffName"]),
          Text("状态：" + returnStatusMap[data["status"]]),
        ],
      ),
      subtitle: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("接收人：" +
              (data["receiveStaffName"] != null
                  ? data["receiveStaffName"]
                  : "暂无")),
          Text("借用日期：" + data["startDate"].toString().substring(0, 10)),
        ],
      ),
      onTap: () {
        Navigator.push(
          context,
          new MaterialPageRoute(
              builder: (context) => new EquipmentBorrowReturnView(data)),
        ).then((value) {
          if (value != null && value) {
            returnController.requestRefresh();
          }
        });
      },
    );
  }
}
