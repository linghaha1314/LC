import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/EmptyWidget.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';

class EquipmentBorrowForm extends BaseApp {
  final dynamic data;

  EquipmentBorrowForm(this.data);

  @override
  _EquipmentBorrowFormState createState() =>
      new _EquipmentBorrowFormState(this.data);
}

class _EquipmentBorrowFormState extends BaseAppPage<EquipmentBorrowForm> {
  Map<String, dynamic> data;
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();
  int page = 0;
  PageController _pageController;
  List<dynamic> details = [];
  List<String> deleteDetails = [];

  _EquipmentBorrowFormState(this.data) {
    print(data);
    if (this.data != null) {
      if (data["startDate"] != null && data["startDate"] is String) {
        data["startDate"] = DateTime.parse(data["startDate"]);
      }
      if (data["endDate"] != null && data["endDate"] is String) {
        data["endDate"] = DateTime.parse(data["endDate"]);
      }
      title = "编辑设备借用信息";
    } else {
      title = "添加设备借用信息";
    }
  }

  @override
  initRouteSuccess() {
    if (routeData != null) {
      this.details.add(routeData);
    }
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      Visibility(
        visible: page == 1,
        child: IconButton(
          tooltip: "添加设备",
          icon: Icon(Icons.add),
          onPressed: () {
            _saveDiaAlertDialog(null);
          },
        ),
      ),
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Container(
      child: PageView.custom(
        controller: _pageController,
        physics: NeverScrollableScrollPhysics(),
        childrenDelegate: SliverChildBuilderDelegate((context, index) {
          if (index == 0) {
            return _buildForm();
          } else if (index == 1) {
            return _buildTable();
          }
          return Text("");
        }, childCount: 3),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    empty = false;
    _pageController = PageController(
      initialPage: page,
      keepPage: true,
    );
    if (data != null) {
      _initDetails();
    }
  }

  _buildForm() {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(16.0),
        child: FormBuilder(
          key: _fbKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          initialValue: this.data != null ? data : {},
          child: Column(
            children: [
              FormBuilderTextField(
                name: "mobile",
                decoration: InputDecoration(labelText: "手机号(必填)"),
                maxLength: 11,
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请填写手机号!",
                  ),
                  FormBuilderValidators.numeric(
                    errorText: "请输入数字!",
                  ),
                  FormBuilderValidators.match(
                      r'^((13[0-9])|(14[0-9])|(15[0-9])|(16[0-9])|(17[0-9])|(18[0-9])|(19[0-9]))\d{8}$',
                      errorText: "请输入有效的手机号!")
                ]),
              ),
              FormBuilderTextField(
                name: "reason",
                maxLines: 3,
                decoration: InputDecoration(labelText: "借用事由(必填)"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请填写借用事由!",
                  ),
                ]),
              ),
              FormBuilderTextField(
                name: "objectName",
                focusNode: focusNode1,
                decoration: InputDecoration(labelText: "教学对象(必填)"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择教学对象!",
                  ),
                ]),
                onTap: () {
                  focusNode1.unfocus();
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SelectPage(
                          title: "选择教学对象",
                          url:
                              "/dictionarydata/listQueryByTypeCode/teachingObjectType",
                          queryParams: {},
                        ),
                      )).then((value) {
                    if (value != null) {
                      _fbKey.currentState.setState(() {
                        _fbKey.currentState.fields['objectName']
                            .didChange(value["name"]);
                        _fbKey.currentState
                            .setInternalFieldValue("objectId", value["id"]);
                      });
                    }
                  });
                },
              ),
              FormBuilderTextField(
                name: "place",
                focusNode: focusNode2,
                decoration: InputDecoration(labelText: "使用场地(必填)"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请输入使用场地",
                  ),
                ]),
              ),
              FormBuilderDateTimePicker(
                name: "startDate",
                format: DateFormat("yyyy-MM-dd HH:mm:ss"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择借用日期!",
                  ),
                ]),
                decoration: InputDecoration(labelText: "借用日期(必填)"),
                initialValue: DateTime.now(),
              ),
              FormBuilderDateTimePicker(
                name: "endDate",
                format: DateFormat("yyyy-MM-dd HH:mm:ss"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择结束时间!",
                  ),
                ]),
                decoration: InputDecoration(labelText: "归还时间(必填)"),
              ),
              FormBuilderTextField(
                name: "remark",
                maxLines: 3,
                decoration: InputDecoration(labelText: "备注"),
              ),
              Container(
                margin: EdgeInsets.only(top: 10),
                child: TextButton.icon(
                  icon: Icon(Icons.arrow_forward),
                  label: Text("下一步"),
                  onPressed: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                    if (_fbKey.currentState.saveAndValidate()) {
                      if (_fbKey.currentState.value["startDate"]
                          .isAfter(_fbKey.currentState.value["endDate"])) {
                        showErrorToast("开始时间不能大于结束时间");
                        return;
                      }
                      setState(() {
                        page = 1;
                        if (data == null) {
                          this.data = Map.of(_fbKey.currentState.value);
                        } else {
                          this.data = {
                            ...data,
                            ...Map.of(_fbKey.currentState.value)
                          };
                        }
                      });
                      _pageController.nextPage(
                          duration: Duration(milliseconds: 200),
                          curve: Curves.linear);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _buildTable() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(bottom: 5, top: 10),
            child: Text(
              "借用设备列表",
              style: TextStyle(fontSize: 20),
            ),
          ),
          Visibility(
            visible: details.length == 0,
            child: EmptyWidget(
              height: 200,
              child: Text("暂无设备信息，请点击右上角添加设备!"),
            ),
          ),
          Visibility(
            visible: details.length > 0,
            child: Container(
              child: Column(
                children: details.map((e) {
                  return Column(
                    children: [
                      Container(
                        child: Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: ListTile(
                                title: Text("${e["name"]}"),
                                subtitle: Text("编号:" +
                                    showString(
                                        "${e["assetNumber"] ?? e["code"]}") +
                                    " 管理员:" +
                                    showString(e["managerStaffName"])),
                              ),
                            ),
                            TextButton.icon(
                              icon: Icon(Icons.delete),
                              label: Text("删除"),
                              onPressed: () {
                                showConfirmAlert("是否删除借用设备：${e['name']}")
                                    .then((value) {
                                  if (value) {
                                    setState(() {
                                      details.remove(e);
                                    });
                                  }
                                });
                              },
                            )
                          ],
                        ),
                      ),
                      Divider(),
                    ],
                  );
                }).toList(),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextButton.icon(
                  icon: Icon(Icons.arrow_back),
                  label: Text("上一步"),
                  onPressed: () {
                    setState(() {
                      page = 0;
                    });
                    _pageController.previousPage(
                        duration: Duration(milliseconds: 200),
                        curve: Curves.linear);
                  },
                ),
                TextButton.icon(
                  icon: Icon(Icons.save),
                  label: Text("保存"),
                  onPressed: () {
                    _saveEquipmentBorrow();
                  },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  _saveDiaAlertDialog(data) {
    Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SelectPage(
              title: "选择设备",
              url: "/equipmentwarehousing/listQueryByPage",
              searchText: "输入设备名称进行搜索",
              queryParams: {"borrowFlag": true},
              buildItem: (row) {
                return ListTile(
                    title: Text(row["name"]),
                    trailing: Chip(
                      label: Text(row["borrowStatus"] == true ? "已借用" : "未借用"),
                      backgroundColor: row["borrowStatus"] == true
                          ? ThemeColor.getColor("warning")
                          : ThemeColor.getColor("info"),
                    ),
                    subtitle: Row(
                      children: [
                        Text(
                            "编号:${showString("${row["assetNumber"] ?? row["code"]}")}"),
                        Text(" 管理员:${showString(row["managerStaffName"])}"),
                      ],
                    ),
                    onTap: () {
                      Navigator.pop(context, row);
                    });
              }),
        )).then((value) {
      if (value != null) {
        bool flag = true;
        String msg;
        details.forEach((e) {
          if (value["id"] == e["id"] || value["id"] == e["warehousingId"]) {
            flag = false;
            msg = "当前设备资产已选择,请选择不同的资产编号设备!";
          }
          if (value["managerStaffId"] != e["managerStaffId"]) {
            flag = false;
            msg = "已选择设备与当前设备管理员不同请分开申请!";
          }
        });
        if (!flag) {
          showErrorAlert(msg);
          return;
        }
        value["total"] = 1;
        setState(() {
          details.add(value);
        });
      }
    });
  }

  _saveEquipmentBorrow() {
    //保存全部信息
    loading = true;
    dynamic d = data;
    if (details.length <= 0) {
      showErrorToast("请添加借用设备再进行保存");
      loading = false;
      return;
    }
    if (!(d["startDate"] is String)) {
      d["startDate"] = formatDate(
          d["startDate"], [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    }
    if (!(d["endDate"] is String)) {
      d["endDate"] = formatDate(
          d["endDate"], [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    }
    d["remark"] = d["remark"] ?? "";
    post(d["id"] != null ? "/equipmentborrow/update" : "/equipmentborrow/save",
            d)
        .then((value) {
      if (value["success"]) {
        var dd = value["data"];
        var rows = [];
        details.forEach((e) {
          rows.add({
            "borrowId": dd["id"],
            "warehousingId": e["warehousingId"] ?? e["id"],
            "name": e["name"],
            "total": e["total"],
            "code": e["assetNumber"] ?? e["code"]
          });
        });
        //开始保存详情信息
        post("/equipmentborrowdetail/saveOrUpdateList", rows).then((value) {
          if (value["success"]) {
            showSuccessToast("保存成功！");
            this.loading = false;
            Navigator.of(context).pop(true);
            loading = false;
          }
        });
      }
    });
  }

  _initDetails() {
    post("/equipmentborrowdetail/listQueryByPage", {"borrowId": data["id"]})
        .then((value) {
      setState(() {
        loading = false;
        details = value["rows"];
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  @override
  void dispose() {
    //将日期重置为string，避免回退出错
    if (!(data["startDate"] is String)) {
      data["startDate"] = formatDate(data["startDate"],
          [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    }
    if (!(data["endDate"] is String)) {
      data["endDate"] = formatDate(
          data["endDate"], [yyyy, "-", mm, "-", dd, " ", HH, ":", nn, ":", ss]);
    }
    super.dispose();
  }
}
