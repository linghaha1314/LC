import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SelectPage.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';

class EquipmentBorrowReturnForm extends BaseApp {
  final dynamic data;

  EquipmentBorrowReturnForm(this.data);

  @override
  _EquipmentBorrowReturnFormState createState() =>
      new _EquipmentBorrowReturnFormState(this.data);
}

class _EquipmentBorrowReturnFormState extends BaseAppPage {
  dynamic data;
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  FocusNode focusNode1 = new FocusNode();
  FocusNode focusNode2 = new FocusNode();

  _EquipmentBorrowReturnFormState(this.data) {
    title = "添加归还信息";
  }

  var damageFlag = false;

  @override
  Widget getBody(BuildContext context) {
    print(data);
    return Container(
      padding: EdgeInsets.all(10.0),
      child: FormBuilder(
        key: _fbKey,
        initialValue: {
          'borrowId': data["id"],
          'returnStaffName': data["staffName"],
          'returnStaffId': data["staffId"],
          'returnDate': DateTime.now()
        },
        child: Column(
          children: [
            FormBuilderTextField(
              focusNode: focusNode1,
              name: "returnStaffName",
              decoration:
                  const InputDecoration(hintText: '请选择人员！', labelText: '归还人'),
              validator: FormBuilderValidators.compose([
                FormBuilderValidators.required(
                  errorText: "请选择人员!",
                ),
              ]),
              onTap: () {
                focusNode1.unfocus();
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SelectPage(
                        title: "选择人员",
                        url: "/staff/listQueryByPage",
                        queryParams: {},
                      ),
                    )).then((value) {
                  if (value != null) {
                    _fbKey.currentState.setState(
                      () {
                        _fbKey.currentState.fields['returnStaffName']
                            .didChange(value["name"]);
                        _fbKey.currentState.setInternalFieldValue(
                            "returnStaffId", value["id"]);
                      },
                    );
                  }
                });
              },
            ),
            FormBuilderTextField(
              focusNode: focusNode2,
              name: "receiveStaffName",
              decoration:
                  const InputDecoration(hintText: '请选择人员！', labelText: '接收人'),
              validator: FormBuilderValidators.compose([
                FormBuilderValidators.required(
                  errorText: "请选择人员!",
                ),
              ]),
              onTap: () {
                focusNode2.unfocus();
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SelectPage(
                        title: "选择人员",
                        url: "/staff/listQueryByPage",
                        queryParams: {},
                      ),
                    )).then((value) {
                  if (value != null) {
                    _fbKey.currentState.setState(() {
                      _fbKey.currentState.fields['receiveStaffName']
                          .didChange(value["name"]);
                      _fbKey.currentState
                          .setInternalFieldValue("receiveStaffId", value["id"]);
                    });
                  }
                });
              },
            ),
            FormBuilderDateTimePicker(
              name: "returnDate",
              format: DateFormat("yyyy-MM-dd HH:mm:ss"),
              validator: FormBuilderValidators.compose([
                FormBuilderValidators.required(
                  errorText: "请选择归还日期!",
                ),
              ]),
              decoration: InputDecoration(labelText: "归还日期"),
            ),
            FormBuilderSwitch(
              title: Text('有无新增损坏'),
              name: "damageFlag",
              initialValue: false,
              onChanged: (data) {
                setState(() {
                  damageFlag = data;
                });
              },
            ),
            Visibility(
              visible: damageFlag,
              child: FormBuilderTextField(
                name: "damageInfo",
                maxLines: 3,
                decoration: InputDecoration(labelText: "损坏说明"),
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(.0, 5.0, .0, 5.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  data["returnAttach"] != null ? Text("已上传附件") : Text("上传归还附件"),
                  ElevatedButton(
                    child: Text("上传"),
                    onPressed: () async {
                      var url = await uploadFile(title: "归还附件上传中");
                      if (url != null) {
                        showSuccessToast("上传文件成功！");
                        setState(() {
                          data["returnAttach"] = url;
                        });
                      } else {
                        return;
                      }
                    },
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: const Icon(Icons.save),
        tooltip: "保存",
        onPressed: () {
          if (_fbKey.currentState.saveAndValidate()) {
            showConfirmAlert("确认归还吗?").then((v) {
              if (v) {
                setState(() {
                  loading = true;
                });
                //保存信息
                dynamic formData = Map.of(_fbKey.currentState.value);
                formData["returnDate"] = formData["returnDate"].toString();
                formData["attach"] = data["returnAttach"];
                formData["borrowId"] = data["id"];
                formData["returnStaffId"] =
                    formData["returnStaffId"] ?? data["staffId"];
                post("/equipmentreturn/save", formData).then((value) {
                  if (value["success"]) {
                    showSuccessToast("保存成功！");
                  }
                  data["returnId"] = value["data"]["id"];
                  data["damageInfo"] = _fbKey.currentState.value["damageInfo"];
                  data["damageFlag"] = _fbKey.currentState.value["damageFlag"];
                  data["returnDate"] = formData["returnDate"].toString();
                  data["receiveStaffName"] =
                      _fbKey.currentState.value["receiveStaffName"];
                  data["returnStaffName"] =
                      _fbKey.currentState.value["returnStaffName"];
                  data["status"] = 1;
                  Navigator.of(context).pop(data);
                }).catchError((err) {
                  showErrorToast(err["msg"]);
                });
              }
            });
          } else {
            showErrorToast("请填写完归还信息！");
          }
        },
      )
    ];
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }
}
