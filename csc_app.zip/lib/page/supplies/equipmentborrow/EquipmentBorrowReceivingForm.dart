import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:form_builder_validators/form_builder_validators.dart';
import 'package:intl/intl.dart';

class EquipmentBorrowReceivingForm extends BaseApp {
  final dynamic data;

  EquipmentBorrowReceivingForm(this.data);

  @override
  _EquipmentBorrowReceivingFormState createState() =>
      new _EquipmentBorrowReceivingFormState(this.data);
}

class _EquipmentBorrowReceivingFormState
    extends BaseAppPage<EquipmentBorrowReceivingForm> {
  dynamic data;
  final GlobalKey<FormBuilderState> _fbKey = GlobalKey<FormBuilderState>();
  FocusNode focusNode1 = new FocusNode();
  bool intactFlag = false;

  _EquipmentBorrowReceivingFormState(this.data) {
    title = "添加设备领用信息";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(15),
        child: FormBuilder(
          key: _fbKey,
          initialValue: {
            "staffName": data["staffName"],
            "staffId": data["staffId"],
            "name": data["name"],
            "code": data["code"],
            "articleId": data["articleId"],
            "total": data["total"].toString(),
            "placeId": data["placeId"],
            "placeName": data["placeName"],
            "remark": data["remark"],
          },
          child: Column(
            children: [
              FormBuilderSwitch(
                title: Text('领用时设备是否完好'),
                name: "intactFlag",
                initialValue: true,
                onChanged: (flag) {
                  setState(() {
                    intactFlag = !flag;
                  });
                },
              ),
              if (intactFlag)
                FormBuilderTextField(
                  name: "intactInfo",
                  maxLines: 3,
                  decoration: InputDecoration(labelText: "设备损坏情况(必填)"),
                  validator: FormBuilderValidators.compose([
                    FormBuilderValidators.required(
                      errorText: "请填写设备损坏情况,设备完好请填无",
                    ),
                  ]),
                ),
              FormBuilderDateTimePicker(
                name: "receiveDate",
                inputType: InputType.date,
                format: DateFormat("yyyy-MM-dd"),
                initialValue: DateTime.now(),
                decoration: InputDecoration(labelText: "领用日期"),
                validator: FormBuilderValidators.compose([
                  FormBuilderValidators.required(
                    errorText: "请选择领用日期！",
                  ),
                ]),
              ),
              FormBuilderTextField(
                name: "remark",
                decoration: InputDecoration(labelText: "备注"),
                maxLines: 3,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.save),
        tooltip: "保存",
        onPressed: () {
          if (this._fbKey.currentState.saveAndValidate()) {
            showConfirmAlert("是否确认领用?").then((value) {
              if (value) {
                dynamic articleReceiving = Map.of(_fbKey.currentState.value);
                articleReceiving["receiveDate"] = null;
                articleReceiving["total"] = 1;
                articleReceiving["name"] = data["name"];
                articleReceiving["code"] = data["code"] ?? data["assetNumber"];
                articleReceiving["articleId"] = data["articleId"];
                getCurrentAccount().then((account) {
                  articleReceiving["staffId"] = account.staff["id"];
                  dynamic formData = {
                    "articleReceiving": articleReceiving,
                    "apply": false,
                    "name": null,
                    "borrowDetailId": data["id"],
                    "urgentStatus": null,
                    "receiveList": [articleReceiving]
                  };
                  post("/articlereceiving/saveDto", formData).then((value) {
                    if (value["success"]) {
                      //修改详情数据
                      data["receivingId"] =
                          value["data"]["articleReceiving"]["id"];
                      post("/equipmentborrowdetail/updateField", this.data)
                          .then((value) {
                        if (value["success"]) {
                          showSuccessToast("领用设备成功！");
                          Navigator.of(context).pop(true);
                        }
                      });
                    }
                  }).catchError((error) => {showErrorAlert(error["msg"])});
                });
              }
            });
          }
        },
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    empty = false;
  }
}
