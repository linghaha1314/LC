import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/SignatureComponent.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:csc_app/page/supplies/equipmentborrow/EquipmentBorrowReceivingView.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

import '../../../ThemeColor.dart';
import 'EquipmentBorrowForm.dart';
import 'EquipmentBorrowReceivingForm.dart';

class EquipmentBorrowView extends BaseApp {
  final dynamic data;

  EquipmentBorrowView(this.data);

  @override
  _EquipmentBorrowViewState createState() =>
      new _EquipmentBorrowViewState(this.data);
}

class _EquipmentBorrowViewState extends BaseAppPage<EquipmentBorrowView> {
  dynamic data;
  List<dynamic> detailList = [];
  Map statusMap = {1: "已驳回", 2: "已同意", 0: "待审核", 3: "待提交"};
  Map statusColorMap = {
    1: ThemeColor.getColor("danger"),
    2: ThemeColor.getColor("success"),
    3: ThemeColor.getColor("warning"),
    0: ThemeColor.getColor("info"),
  };
  Map statusIconMap = {
    1: Icons.close,
    2: Icons.check,
    3: Icons.vertical_align_top,
    0: Icons.pause,
  };

  _EquipmentBorrowViewState(this.data) {
    title = "设备借用详情";
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      if (data["status"] == null)
        IconButton(
          onPressed: () {
            showConfirmAlert("确认删除借用?").then((val) {
              if (val == true) {
                setState(() {
                  loading = true;
                });
                post("/equipmentborrow/delete", {"id": data["id"]}).then((res) {
                  setState(() {
                    loading = false;
                  });
                  if (res["success"]) {
                    Navigator.of(context).pop(true);
                  }
                });
              }
            });
          },
          icon: Icon(Icons.delete, color: Colors.red),
          tooltip: "删除",
        ),
      if (data["status"] == null)
        IconButton(
          onPressed: () {
            //跳转到修改页面
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => new EquipmentBorrowForm(data)),
            ).then((value) {
              if (value == true) {
                Navigator.of(context).pop(value);
              }
            });
          },
          icon: Icon(Icons.edit),
          tooltip: "修改",
        ),
      if (data["status"] != null)
        IconButton(
          onPressed: () async {
            var path = await getHttpPath();
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => WebViewPage(
                      url:
                          "$path/flowview/${data["processInstanceId"]}?type=f")),
            );
          },
          icon: Icon(Icons.menu),
          tooltip: "审批进程",
        ),
    ];
  }

  @override
  Widget getBottom(BuildContext context) {
    return data["status"] == null
        ? Container(
            padding: EdgeInsets.fromLTRB(20.0, .0, 20.0, 10.0),
            child: ElevatedButton.icon(
              icon: Icon(Icons.check),
              label: Text("提交申请"),
              onPressed: () async {
                var ids = [];
                detailList.forEach((d) {
                  ids.add(d["warehousingId"]);
                });
                var res =
                    await post("/equipmentwarehousing/queryBorrowStatus", ids);
                String msg;
                res["data"].forEach((e) {
                  if (e["borrowFlag"] == true) {
                    if (e["borrowStatus"] == true) {
                      msg = "[${e["name"]}]已被借用,请重新选择设备或归还后再提交申请!";
                    }
                  } else {
                    msg = "[${e["name"]}]停止借用,请重新选择设备或联系管理员!";
                  }
                });
                if (msg != null) {
                  showErrorAlert(msg);
                  return;
                }
                Navigator.push(
                  context,
                  new MaterialPageRoute(
                      builder: (context) => new SignatureComponent()),
                ).then((value) {
                  if (value != null) {
                    uploadFile(file: value).then((attach) {
                      data["attach"] = attach;
                      post("/equipmentborrow/updateField", data);
                      _showSubmitDialog(data);
                    });
                  } else {
                    showErrorToast("请完成签名!");
                  }
                });
              },
            ),
          )
        : Container(
            padding: EdgeInsets.fromLTRB(20.0, .0, 20.0, 10.0),
            child: OutlinedButton.icon(
              icon: Icon(Icons.undo),
              label: Text("撤回申请"),
              onPressed: () {
                showConfirmAlert("撤回后不能领取设备,确认撤回吗?").then((value) {
                  if (value) {
                    setState(() {
                      loading = true;
                    });
                    post("/equipmentborrow/undoApply", {"id": data["id"]})
                        .then((res) {
                      setState(() {
                        loading = false;
                      });
                      if (res["success"]) {
                        Navigator.of(context).pop(true);
                      }
                    });
                  }
                });
              },
            ),
          );
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 10,
            ),
            _dataView(),
            _detailList(),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _initDetailList();
    empty = false;
  }

  Widget _dataView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "设备借用基本信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _titleView("借用人", data["staffName"]),
                          Divider(),
                          _titleView("手机号", data["mobile"]),
                          Divider(),
                          _titleView("教学对象", data["objectName"]),
                          Divider(),
                          _titleView("使用地点", data["place"]),
                          Divider(),
                          _titleView("借用开始时间", data["startDate"].toString()),
                          Divider(),
                          _titleView("归还时间", data["endDate"].toString()),
                          Divider(),
                          ListTile(
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "状态",
                                  style: TextStyle(fontSize: 15),
                                ),
                                Chip(
                                  backgroundColor: statusColorMap[
                                      data["status"] != null
                                          ? data["status"]
                                          : 3],
                                  label: Row(
                                    children: [
                                      Text(
                                        "${statusMap[data["status"] != null ? data["status"] : 3]}",
                                        style: TextStyle(
                                          color:
                                              ThemeColor.getColor("fontColor"),
                                        ),
                                      ),
                                      Icon(
                                        statusIconMap[data["status"] != null
                                            ? data["status"]
                                            : 3],
                                        color: ThemeColor.getColor("fontColor"),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(),
                          _titleView("创建人", data["userName"]),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "借用事由",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            subtitle: Text(data["reason"]),
                          ),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "备注",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            subtitle: Text(
                                (data["remark"] != null && data["remark"] != '')
                                    ? data["remark"]
                                    : "暂无备注"),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  _titleView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 15),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 15),
          ),
        ],
      ),
    );
  }

  Widget _detailList() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "借用设备列表",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Column(
              children: detailList.map((e) {
                return _buildExperienceRow(e);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  _initDetailList() {
    setState(() {
      loading = true;
    });
    post("/equipmentborrowdetail/listQueryByPage", {"borrowId": data["id"]})
        .then((value) {
      setState(() {
        loading = false;
        detailList = value["rows"];
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  Widget _buildExperienceRow(data) {
    return ListTile(
      title: Text(
        "${data["name"]}",
      ),
      trailing: Chip(
        label: Text("${data["receivingId"] != null ? '已领用' : '未领用'}"),
        backgroundColor:
            data["receivingId"] != null ? statusColorMap[0] : statusColorMap[1],
      ),
      subtitle: Text(
        "编号:" +
            showString("${data["assetNumber"] ?? data["code"]}") +
            " 管理员:" +
            showString(data["managerStaffName"]),
        style: TextStyle(fontWeight: FontWeight.w500),
      ),
      onTap: () {
        if (this.data["status"] == 2) {
          if (data["receivingId"] != null) {
            //查看详情
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => new EquipmentBorrowReceivingView(data)),
            ).then((value) {});
          } else if (data["receivingId"] == null &&
              this.data["returnId"] == null) {
            //领取设备
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => new EquipmentBorrowReceivingForm(data)),
            ).then((value) {
              if (value == true) {
                _initDetailList();
              }
            });
          } else {
            showErrorToast("借用信息已过期无法进行领用！");
          }
        } else {
          showErrorToast("借用信息未审核通过！");
        }
      },
    );
  }

  _showSubmitDialog(data) {
    showConfirmAlert("提交后管理员审核通过后即可前去领用设备,确认提交吗?").then((value) {
      if (value) {
        setState(() {
          loading = true;
        });
        var list = [];
        detailList.forEach((e) {
          list.add(e["name"] + "(${e["code"]})");
        });
        dynamic params = {
          "id": data["id"],
          "date": data["startDate"],
          "urgentStatus": 0,
          "name":
              "${data["userName"]}(${data["mobile"]})提交设备借用,于${data["startDate"]}至${data["endDate"]}申请借用[${list.join(',')}]设备"
        };
        post("/equipmentborrow/applyEquipmentBorrow", params).then((value) {
          setState(() {
            loading = false;
          });
          if (value["success"]) {
            showSuccessToast("提交成功！");
            Navigator.of(context).pop(true);
          }
        }).catchError((err) {
          setState(() {
            loading = false;
          });
          showErrorToast(err["msg"]);
        });
      }
    });
  }
}
