import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/EmptyWidget.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/material.dart';

import '../../../ThemeColor.dart';
import 'EquipmentBorrowReceivingForm.dart';
import 'EquipmentBorrowReceivingView.dart';
import 'EquipmentBorrowReturnForm.dart';

class EquipmentBorrowReturnView extends BaseApp {
  final dynamic data;

  EquipmentBorrowReturnView(this.data);

  @override
  _EquipmentBorrowReturnViewState createState() =>
      new _EquipmentBorrowReturnViewState(this.data);
}

class _EquipmentBorrowReturnViewState
    extends BaseAppPage<EquipmentBorrowReturnView> {
  dynamic data;
  List<dynamic> detailList = [];
  Map statusMap = {1: "已归还", 0: "未归还"};
  int page = 0;
  FocusNode focusNode1 = new FocusNode();
  Map statusColorMap = {
    1: ThemeColor.getColor("success"),
    0: ThemeColor.getColor("warning"),
  };

  _EquipmentBorrowReturnViewState(this.data) {
    title = "设备归还详情";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 10,
            ),
            Container(
              padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
              alignment: Alignment.topLeft,
              child: Text(
                "设备归还信息",
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                ),
                textAlign: TextAlign.left,
              ),
            ),
            Visibility(
              visible: data["status"] == 0,
              child: Card(
                margin: EdgeInsets.all(15),
                child: EmptyWidget(
                  height: 200,
                  child: SizedBox(
                    width: 160,
                    child: ElevatedButton.icon(
                      icon: Icon(Icons.add_circle),
                      label: Text("添加归还信息"),
                      onPressed: () {
                        var index = 0;
                        detailList.forEach((e) {
                          if (e["receivingId"] != null) {
                            index++;
                          }
                        });
                        if (index == 0) {
                          showErrorToast("请先领用设备后,再归还!");
                          return;
                        }
                        Navigator.push(
                          context,
                          new MaterialPageRoute(
                            builder: (context) =>
                                new EquipmentBorrowReturnForm(data),
                          ),
                        ).then((value) {
                          if (value != null) {
                            setState(() {
                              data = value;
                            });
                          }
                        });
                      },
                    ),
                  ),
                ),
              ),
            ),
            Visibility(
              visible: data["status"] == 1,
              child: _dataReturnView(),
            ),
            _dataView(),
            _detailList(),
          ],
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _initDetailList();
    empty = false;
  }

  Widget _dataView() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "设备借用基本信息",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _titleView("借用人", data["staffName"]),
                          Divider(),
                          _titleView("手机号", data["mobile"]),
                          Divider(),
                          _titleView("教学对象", data["objectName"]),
                          Divider(),
                          _titleView("借用地点", data["place"]),
                          Divider(),
                          _titleView(
                              "借用日期",
                              formatDate(DateTime.parse(data["startDate"]), [
                                yyyy,
                                "-",
                                mm,
                                "-",
                                dd,
                                " ",
                                HH,
                                ":",
                                nn,
                                ":",
                                ss
                              ])),
                          Divider(),
                          _titleView(
                              "归还时间",
                              formatDate(DateTime.parse(data["endDate"]), [
                                yyyy,
                                "-",
                                mm,
                                "-",
                                dd,
                                " ",
                                HH,
                                ":",
                                nn,
                                ":",
                                ss
                              ])),
                          Divider(),
                          ListTile(
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "状态",
                                  style: TextStyle(fontSize: 15),
                                ),
                                Chip(
                                  backgroundColor: statusColorMap[
                                      data["status"] != null
                                          ? data["status"]
                                          : 3],
                                  label: Row(
                                    children: [
                                      Text(
                                        "${statusMap[data["status"] != null ? data["status"] : 3]}",
                                        style: TextStyle(
                                          color:
                                              ThemeColor.getColor("fontColor"),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "借用事由",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            subtitle: Text(data["reason"]),
                          ),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "备注",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            subtitle: Text(
                                (data["remark"] != null && data["remark"] != '')
                                    ? data["remark"]
                                    : "暂无备注"),
                          ),
                          Divider(),
                          ListTile(
                            title: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("借用申请表附件"),
                                Row(
                                  children: [
                                    Visibility(
                                      visible: data["status"] == null,
                                      child: ElevatedButton(
                                        child: Text("上传"),
                                        onPressed: () async {
                                          var url =
                                              await uploadFile(title: "申请表上传中");
                                          if (url == null) {
                                            return;
                                          }
                                          var d = {
                                            "id": data["id"],
                                            "attach": url
                                          };
                                          post("/equipmentborrow/updateField",
                                              {...d}).then((value) {
                                            if (value["success"]) {
                                              setState(() {
                                                data["attach"] = url;
                                              });
                                              showSuccessToast("上传申请表成功！");
                                            }
                                          });
                                        },
                                      ),
                                    ),
                                    Visibility(
                                      visible: data["attach"] != null,
                                      child: ElevatedButton(
                                        child: Text(
                                          "下载",
                                        ),
                                        onPressed: () async {
                                          var url = await downloadFile(
                                            data["attach"],
                                            data["attach"]
                                                .toString()
                                                .split("/")
                                                .last,
                                            title: "申请模板下载",
                                          );
                                          if (url != null) {
                                            showSuccessToast("下载成功！");
                                          }
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _dataReturnView() {
    if (data["status"] != 1) {
      return SizedBox();
    }
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      ...ListTile.divideTiles(
                        color: ThemeColor.getColor("border"),
                        tiles: [
                          _titleView("归还人", data["returnStaffName"]),
                          Divider(),
                          _titleView("接收人", data["receiveStaffName"]),
                          Divider(),
                          _titleView("借用地点", data["placeName"]),
                          Divider(),
                          _titleView(
                              "设备归还日期",
                              formatDate(DateTime.parse(data["returnDate"]), [
                                yyyy,
                                "-",
                                mm,
                                "-",
                                dd,
                              ])),
                          Divider(),
                          _titleView("有无新增损坏", data["damageFlag"] ? "有" : "无"),
                          Divider(),
                          Visibility(
                            visible: data["damageInfo"] != null,
                            child: ListTile(
                              title: Container(
                                margin: EdgeInsets.only(bottom: 10, top: 10),
                                child: Text(
                                  "损坏说明",
                                  style: TextStyle(fontSize: 15),
                                ),
                              ),
                              subtitle: Text(data["damageInfo"] != null
                                  ? data["damageInfo"]
                                  : "无"),
                            ),
                          ),
                          Divider(),
                          ListTile(
                            title: Container(
                              margin: EdgeInsets.only(bottom: 10, top: 10),
                              child: Text(
                                "归还表附件",
                                style: TextStyle(fontSize: 15),
                              ),
                            ),
                            trailing: ElevatedButton(
                              child: Text("下载"),
                              onPressed: () async {
                                var url = await downloadFile(
                                  data["returnAttach"],
                                  data["returnAttach"]
                                      .toString()
                                      .split("/")
                                      .last,
                                  title: "归还表附件下载",
                                );
                                if (url != null) {
                                  showSuccessToast("下载成功！");
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  _titleView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: TextStyle(fontSize: 15),
          ),
          Text(
            value != null ? value : "",
            style: TextStyle(fontSize: 15),
          ),
        ],
      ),
    );
  }

  Widget _detailList() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
            alignment: Alignment.topLeft,
            child: Text(
              "借用设备列表",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 16,
              ),
              textAlign: TextAlign.left,
            ),
          ),
          Card(
            child: Column(
              children: detailList.map((e) {
                return _buildExperienceRow(e);
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  _initDetailList() {
    setState(() {
      loading = true;
    });
    post("/equipmentborrowdetail/listQueryByPage", {"borrowId": data["id"]})
        .then((value) {
      setState(() {
        loading = false;
        detailList = value["rows"];
      });
    }).catchError((error) {
      showErrorToast(error["msg"]);
      setState(() {
        loading = false;
      });
    });
  }

  Widget _buildExperienceRow(data) {
    return ListTile(
      title: Text(
        "名称:${data["name"]}",
        style: TextStyle(fontWeight: FontWeight.w500),
      ),
      trailing: Text(
        "编号:${data["code"]}",
        style: TextStyle(fontWeight: FontWeight.w500),
      ),
      subtitle: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Text(
                "状态:",
                style: TextStyle(
                    fontSize: 12.0, color: ThemeColor.getColor("fontColor")),
              ),
              Container(
                padding: EdgeInsets.all(3),
                decoration: new BoxDecoration(
                  border: new Border.all(
                      color: data["receivingId"] != null
                          ? statusColorMap[0]
                          : statusColorMap[1],
                      width: 0.5), // 边色与边宽度
                  color: data["receivingId"] != null
                      ? statusColorMap[0]
                      : statusColorMap[1],
                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                ),
                child: Text(
                  "${data["receivingId"] != null ? '已领用' : '未领用'}",
                  style: TextStyle(
                    fontSize: 12.0,
                    color: ThemeColor.getColor("fontColor"),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      onTap: () {
        print(data);
        if (data["receivingId"] != null) {
          //查看详情
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => new EquipmentBorrowReceivingView(data)),
          ).then((value) {});
        } else {
          //领取设备
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => new EquipmentBorrowReceivingForm(data)),
          ).then((value) {
            if (value == true) {
              _initDetailList();
            }
          });
        }
      },
    );
  }
}
