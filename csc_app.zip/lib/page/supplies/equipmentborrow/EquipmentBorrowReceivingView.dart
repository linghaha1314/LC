import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';

class EquipmentBorrowReceivingView extends BaseApp {
  final dynamic data;

  EquipmentBorrowReceivingView(this.data);

  @override
  _EquipmentBorrowReceivingViewState createState() =>
      new _EquipmentBorrowReceivingViewState(this.data);
}

class _EquipmentBorrowReceivingViewState
    extends BaseAppPage<EquipmentBorrowReceivingView> {
  dynamic data;
  dynamic viewData;

  _EquipmentBorrowReceivingViewState(this.data) {
    title = "设备领用信息";
  }

  @override
  Widget getBody(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        margin: EdgeInsets.all(15),
        child: Card(
          child: Column(
            children: [
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("设备名称"),
                    Text(viewData["name"]),
                  ],
                ),
              ),
              Divider(),
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("设备编码"),
                    Text(showString(data["code"])),
                  ],
                ),
              ),
              Divider(),
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("领用日期"),
                    Text(showString(viewData["receiveDate"])),
                  ],
                ),
              ),
              Divider(),
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("领用时设备是否完好"),
                    Text(
                        showString(viewData["intactFlag"] == true ? "是" : "否")),
                  ],
                ),
              ),
              Divider(),
              ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("设备损坏情况(必填)"),
                    Text(showString(viewData["intactInfo"])),
                  ],
                ),
              ),
              Divider(),
              ListTile(
                title: Text("备注"),
                subtitle:
                    Text(viewData["remark"] != null ? viewData["remark"] : "无"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _getReceiving();
  }

  _getReceiving() {
    var params = {"id": data["receivingId"]};
    post("/articlereceiving/listQueryByPage", {...params}).then((value) {
      if (value["total"] > 0) {
        setState(() {
          this.viewData = value["rows"][0];
          empty = false;
        });
      }
    });
  }
}
