import 'package:csc_app/component/BaseApp.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/component/MethodComponent.dart';
import '../../../ThemeColor.dart';

class StorehouseSuppliesPage extends BaseApp {
  @override
  _StorehouseSuppliesPageState createState() =>
      new _StorehouseSuppliesPageState();
}

class _StorehouseSuppliesPageState extends BaseAppPage<StorehouseSuppliesPage>
    with TickerProviderStateMixin {
  String storehouseId;
  var tabController;
  List<dynamic> itemList = [];
  List<Tab> tabList = [];

  _StorehouseSuppliesPageState() {
    title = "库房耗材列表";
  }

  @override
  initRouteSuccess() {
    if (routeData != null && routeData["storehouseId"] != null) {
      this.storehouseId = routeData["storehouseId"];
      initItemList();
    }
  }

  @override
  void initState() {
    super.initState();
    tabController = TabController(
        vsync: this, // 动画效果的异步处理
        length: tabList.length, // tab 个数
        initialIndex: 0 // 起始位置
        );
  }

  @override
  Widget getBottom(BuildContext context) {
    return SafeArea(
      child: SizedBox(
        height: 40,
        child: ElevatedButton(
          onPressed: () {
            toArticlePage();
          },
          child: Text("申请领用"),
        ),
      ),
    );
  }

  @override
  Widget getBody(BuildContext context) {
    return TabBarView(
      controller: tabController,
      children: getTabList(),
    );
  }

  @override
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: getTitle(context),
        actions: getActions(context),
        bottom: new TabBar(
            controller: this.tabController, tabs: tabList, isScrollable: true),
      ),
      body: getBody(context),
      drawer: getDraw(context),
      bottomNavigationBar: SafeArea(
        child: getBottom(context),
      ),
    );
  }

  initItemList() {
    if (this.storehouseId != null && this.storehouseId != "") {
      post("/supplieswarehousing/listQueryByPage",
          {"storehouseId": this.storehouseId}).then((value) {
        if (value != null && value["total"] > 0) {
          List<Tab> tabList = [];
          itemList = value["rows"];
          itemList.forEach((item) {
            item["maxTotal"] = item["total"];
            item["total"] = null;
            item["created"] = null;
            item["check"] = true;
            tabList.add(new Tab(text: item["name"]));
          });
          setState(() {
            this.tabController = TabController(
              vsync: this, // 动画效果的异步处理
              length: tabList.length, //
              initialIndex: 0, // 起始位置// tab 个数
            );
            this.itemList = itemList;
            this.tabList = tabList;
            this.empty = false;
          });
        } else {
          setState(() {
            this.empty = true;
          });
        }
      });
    }
  }

  List<Widget> getTabList() {
    List<Widget> tabViewList = [];
    this.itemList.forEach((item) {
      tabViewList.add(_buildTabView(item));
    });
    return tabViewList;
  }

  _buildTabView(data) {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          new CheckboxListTile(
            title: const Text('是否申请领用'),
            value: data["check"],
            onChanged: (bool value) {
              setState(() {
                data["check"] = !data["check"];
              });
            },
          ),
          Divider(),
          _textView("规格", data["specificationName"]),
          Divider(),
          _textView("材料名称", data["name"]),
          Divider(),
          _textView("材料编码", data["code"]),
          Divider(),
          _textView("数量", data["maxTotal"]),
          Divider(),
          _textView("单价(元)", data["price"]),
          Divider(),
          _textView("单位", data["unitName"]),
          Divider(),
          _textView("品牌", data["brandName"]),
          Divider(),
          _textView("保质期", data["expirationDate"]),
        ],
      ),
    );
  }

  _textView(name, value) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name),
          Container(
            padding: EdgeInsets.fromLTRB(.0, .0, 10.0, .0),
            child: Text(showString(value)),
          ),
        ],
      ),
    );
  }

  toArticlePage() {
    var list = [];
    this.itemList.forEach((item) {
      if (item["check"]) {
        list.add(item);
      }
    });
    if (list.length < 1) {
      return showErrorToast("请至少勾选一条数据！");
    }
    Navigator.pushNamed(context, "articleReceiving", arguments: list)
        .then((value) {
      if (value) {
        Navigator.pop(context, true);
      } else {
        initItemList();
      }
    });
  }
}
