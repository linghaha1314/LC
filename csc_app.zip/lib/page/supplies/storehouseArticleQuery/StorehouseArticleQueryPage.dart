import 'package:badges/badges.dart' as badges;
import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

import '../../../ThemeColor.dart';

class StorehouseArticleQuery extends BaseApp {
  @override
  StorehouseArticleQueryPage createState() => new StorehouseArticleQueryPage();
}

class StorehouseArticleQueryPage extends BaseAppPage<StorehouseArticleQuery> {
  bool multipleFlag = false;
  dynamic selected = {};

  StorehouseArticleQueryPage() {
    title = "物资查询";
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      badges.Badge(
        badgeStyle: badges.BadgeStyle(
          shape: badges.BadgeShape.circle,
          badgeColor: ThemeColor.getColor("info"),
        ),
        child: IconButton(
          tooltip: '批量领用',
          icon: Icon(MdiIcons.formatListChecks),
          onPressed: () {
            setState(() {
              multipleFlag = !multipleFlag;
            });
          },
        ),
        position: badges.BadgePosition.topEnd(top: 0, end: 0),
        showBadge: multipleFlag && selected.keys.length > 0,
        badgeContent: Text(
          '${selected.keys.length}',
          style: TextStyle(fontSize: 10.0),
        ),
      ),
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return RefreshList(
        searchText: "请输入名称或编码,批量领用请点右上角",
        url: "/storehousearticle/suppliesQueryByPage",
        buildItem: (dynamic row, int i) {
          return _bodyContentOne(row);
        });
  }

  _bodyContentOne(data) {
    if (multipleFlag) {
      return CheckboxListTile(
        value: selected[data["storehouseId"]] == true,
        onChanged: (val) {
          if (val) {
            selected[data["storehouseId"]] = val;
          } else {
            selected.remove(data["storehouseId"]);
          }
          setState(() {});
        },
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(data["name"]), Text(data["typeName"])],
        ),
        subtitle: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("库房:${data["placeName"]}"),
                Text("编码:${data["code"] != null ? data["code"] : '无'}"),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("货架:${data["shelf"]}"),
                Text("数量:${data["total"]}"),
              ],
            )
          ],
        ),
      );
    }
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(data["name"]), Text(data["typeName"])],
      ),
      subtitle: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("库房:${data["placeName"]}"),
              Text("编码:${data["code"] != null ? data["code"] : '无'}"),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("货架:${data["shelf"]}"),
              Text("数量:${data["total"]}"),
            ],
          )
        ],
      ),
      onTap: () {
        Navigator.pushNamed(
          context,
          "storehouseSupplies",
          arguments: data,
        );
      },
    );
  }

  @override
  Widget getBottom(BuildContext context) {
    return multipleFlag
        ? SafeArea(
            child: SizedBox(
              height: 40,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(
                    context,
                    "storehouseSupplies",
                    arguments: {"storehouseId": selected.keys.join(",")},
                  );
                },
                child: Text("确认领用"),
              ),
            ),
          )
        : null;
  }

  @override
  void initState() {
    empty = false;
    super.initState();
  }
}
