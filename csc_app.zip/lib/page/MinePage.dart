import 'dart:convert';
import 'dart:io';

import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefresherScroll.dart';
import 'package:csc_app/page/base/QRViewPage.dart';
import 'package:csc_app/page/base/WebViewPage.dart';
import 'package:csc_exam_grade/Login.dart' as grade;
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/pojo/UserInfo.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:package_info/package_info.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class Mine extends StatefulWidget {
  @override
  MinePageState createState() => MinePageState();
}

class MinePageState extends State<Mine> {
  ConfigService configService = ConfigService();

  String background;

  String avatar;

  String version = "";

  UserInfo userInfo = new UserInfo();

  List<dynamic> infos = [];

  RefreshController _controller = RefreshController(initialRefresh: false);

  refresh() {
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        extendBody: true,
        body: RefresherScroll(
          enablePullDown: true,
          controller: _controller,
          onRefresh: _refresh,
          header: WaterDropMaterialHeader(
            color: ThemeColor.getColor("fontColor"),
            backgroundColor: ThemeColor.getColor("focus"),
          ),
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                ProfileHeader(
                  avatar: avatar != null ? avatar : null,
                  coverImage: background == null
                      ? AssetImage("assets/images/profile.jpg")
                      : FileImage(File(background)),
                  title: userInfo.staff == null ? "" : userInfo.staff["name"],
                  subtitle: userInfo.role == null ? "" : userInfo.role["name"],
                  changeAvatar: _changeAvatar,
                  changeRole: _changeRole,
                  actions: <Widget>[
                    Tooltip(
                      message: "扫描二维码",
                      child: MaterialButton(
                        color: ThemeColor.getColor("color").withOpacity(0.5),
                        shape: CircleBorder(),
                        elevation: 0,
                        child: Icon(MdiIcons.qrcodeScan),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => QRViewPage(),
                              )).then((value) {
                            if (value != null) {
                              if (value.startsWith("http")) {
                                if (value
                                    .toString()
                                    .contains("questionnaire")) {
                                  var u = Uri.parse(value);
                                  Navigator.pushNamed(context, "surveyVolume",
                                      arguments: u.queryParameters);
                                } else if (value
                                    .toString()
                                    .contains("safeeducationsignature")) {
                                  var u = Uri.parse(value);
                                  Navigator.pushNamed(
                                      context, "safeEducationRecord",
                                      arguments: {
                                        "id": u.path
                                            .split("safeeducationsignature/")[1]
                                      });
                                } else {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          WebViewPage(url: value),
                                    ),
                                  );
                                }
                                return;
                              }
                              try {
                                var d = jsonDecode(value);
                                Navigator.pushNamed(context, d["code"],
                                    arguments: d["params"]);
                              } catch (e) {
                                showErrorToast("无法识别的参数:$value");
                              }
                            }
                          });
                        },
                      ),
                    ),
                    Tooltip(
                      message: "修改背景图片",
                      child: MaterialButton(
                        color: ThemeColor.getColor("color").withOpacity(0.5),
                        shape: CircleBorder(),
                        elevation: 0,
                        child: Icon(MdiIcons.imageEditOutline),
                        onPressed: () async {
                          FilePickerResult result = await FilePicker.platform
                              .pickFiles(type: FileType.image);
                          if (result != null) {
                            configService.update(
                                Config("profile", result.files.single.path));
                            setState(() {
                              background = result.files.single.path;
                            });
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10.0),
                UserSetting(title: "用户信息", list: infos),
                UserSetting(title: "操作", list: [
                  {
                    "icon": Icons.settings,
                    "label": "设置",
                    "onTap": () {
                      Navigator.pushNamed(context, 'setting');
                    },
                  },
                  {
                    "icon": MdiIcons.devices,
                    "label": "设备解绑",
                    "onTap": () {
                      Navigator.pushNamed(context, 'devices');
                    },
                  },
                  {
                    "icon": MdiIcons.lockReset,
                    "label": "修改密码",
                    "onTap": () {
                      Navigator.pushNamed(context, 'passwordSet');
                    },
                  },
                  {
                    "icon": MdiIcons.accountEdit,
                    "label": "修改个人信息",
                    "onTap": () {
                      Navigator.pushNamed(context, 'staffSet');
                    },
                  },
                  {
                    "icon": MdiIcons.switchIcon,
                    "label": "切换考官评分",
                    "onTap": () {
                      showGradeLogin();
                    },
                  },
                  {
                    "icon": MdiIcons.accountSwitch,
                    "label": "切换账号",
                    "onTap": () {
                      Navigator.pushNamed(context, 'login').then((v) {
                        homePage.initContext();
                        homePage.refreshAll();
                        _initUserData();
                      });
                    },
                  },
                  {
                    "icon": MdiIcons.exitRun,
                    "label": "退出登录",
                    "onTap": () async {
                      var flag = await showConfirmAlert("是否删除当前登录记录并退出应用?");
                      if (flag != true) {
                        return;
                      }
                      await configService.delete("auth");
                      await configService.delete("account");
                      await configService.delete("userInfo");
                      if (Platform.isAndroid) {
                        SystemNavigator.pop();
                      } else {
                        exit(0);
                      }
                    },
                  },
                  {
                    "icon": MdiIcons.information,
                    "label": "版本:$version",
                    "onTap": () {
                      checkUpdate(flag: true);
                    },
                  },
                ]),
              ],
            ),
          ),
        ));
  }

  showGradeLogin() {
    Navigator.of(context).pop();
    Navigator.of(context).push(new MaterialPageRoute(
      builder: (context) => grade.Login(),
    ));
  }

  @override
  void initState() {
    super.initState();
    minePageState = this;
    _initUserData();
    configService.getConfig("profile").then((value) {
      if (value != null) {
        background = value;
      }
    });
  }

  _changeRole() async {
    var user = await getCurrentAccount();
    if (user != null && user.roles != null) {
      var list = [];
      for (var k in user.roles.keys) {
        list.add(user.roles[k]);
      }
      showBarModalBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return new Column(
              mainAxisSize: MainAxisSize.min,
              children: list.map((r) {
                return new ListTile(
                  leading: new Icon(MdiIcons.accountMultipleOutline),
                  title: new Text(r["name"]),
                  onTap: () async {
                    Navigator.pop(context);
                    user.role = r;
                    post("/accounts/updateCurrentRole", {
                      ...{"roleId": r["id"]}
                    }).then((value) {
                      if (value["success"]) {
                        configService
                            .update(Config("auth", value["token"]))
                            .then((v) {
                          configService
                              .update(
                                  Config("userInfo", jsonEncode(user.toMap())))
                              .then((value) {
                            refreshUserInfo().then((v) {
                              setState(() {
                                userInfo = user;
                              });
                              homePage.refreshAll();
                            });
                          });
                        });
                      }
                    });
                  },
                );
              }).toList(),
            );
          });
    }
  }

  _changeAvatar() async {
    var url = await uploadFile(type: FileType.image, title: "头像上传中");
    if (url == null) return;
    var user = await getCurrentAccount();
    post("/staff/updateField", {"id": user.staff["id"], "avator": url})
        .then((res) {
      if (res["success"]) {
        showSuccessToast("头像修改成功!");
        refreshUserInfo().then((value) {
          refreshUserInfo().then((v) {
            getHttpPath().then((path) {
              setState(() {
                avatar = path + url;
              });
            });
          });
        });
      }
    });
  }

  _initUserData() {
    getHttpPath().then((path) {
      configService.delete("userInfo").then((r) {
        refreshUserInfo().then((user) {
          configService
              .update(Config("userInfo", jsonEncode(user.toMap())))
              .then((value) {
            getCurrentAccount().then((value) {
              if (value == null) {
                _controller.loadFailed();
              }
              setState(() {
                userInfo = value;
                if (value.staff["avator"] != null) {
                  avatar = path + value.staff["avator"];
                } else {
                  avatar = null;
                }
                infos = [
                  {
                    "label": "胸牌号",
                    "icon": MdiIcons.cardAccountDetailsOutline,
                    "text": userInfo.staff["serialNo"]
                  },
                  {
                    "label": "科室",
                    "icon": MdiIcons.domain,
                    "text": userInfo.staff["sectionName"]
                  },
                  {
                    "label": "手机号",
                    "icon": MdiIcons.cellphone,
                    "text": userInfo.staff["mobile"]
                  },
                  {
                    "label": "专业",
                    "icon": MdiIcons.book,
                    "text": userInfo.staff["majorName"]
                  },
                  {
                    "label": "性别",
                    "icon": MdiIcons.genderMale,
                    "text": userInfo.staff["genderName"]
                  },
                  {
                    "label": "学位",
                    "icon": MdiIcons.license,
                    "text": userInfo.staff["degreeName"]
                  },
                  {
                    "label": "学历",
                    "icon": MdiIcons.bookEducation,
                    "text": userInfo.staff["academicName"]
                  },
                  {
                    "label": "邮箱",
                    "icon": MdiIcons.email,
                    "text": userInfo.staff["email"]
                  },
                ];
              });
              _controller.refreshCompleted();
            });
          });
        });
      });
    });
    PackageInfo.fromPlatform().then((info) {
      setState(() {
        version = info.version;
      });
    });
  }

  _refresh() async {
    try {
      await configService.delete("userInfo");
      await refreshUserInfo();
      _initUserData();
    } catch (e) {
      _controller.loadFailed();
    }
  }

  @override
  void dispose() {
    minePageState = null;
    super.dispose();
  }
}

class UserSetting extends StatelessWidget {
  final List<dynamic> list;
  final String title;

  UserSetting({Key key, this.list, this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          Card(
            child: Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(15),
              child: Column(
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
                    alignment: Alignment.topLeft,
                    child: Text(
                      title,
                      style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 25,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ),
                  Column(
                    children: list.map((e) {
                      return ListTile(
                        leading: e["icon"] == null
                            ? null
                            : Icon(e["icon"],
                                color: ThemeColor.getColor("focus")),
                        title: Text(e["label"]),
                        trailing: (e["onTap"] == null && e["text"] == null)
                            ? null
                            : (e["onTap"] != null
                                ? Icon(Icons.arrow_forward,
                                    color: ThemeColor.getColor("fontColor"))
                                : Text(e["text"])),
                        onTap: e["onTap"],
                      );
                    }).toList(),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

class ProfileHeader extends StatelessWidget {
  final ImageProvider<dynamic> coverImage;
  final String avatar;
  final String title;
  final String subtitle;
  final List<Widget> actions;
  final Function changeAvatar;
  final Function changeRole;

  const ProfileHeader(
      {Key key,
      this.coverImage,
      this.avatar,
      this.title = "",
      this.subtitle = "",
      this.actions,
      this.changeAvatar,
      this.changeRole})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        if (coverImage != null)
          Container(
            height: 320,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: coverImage,
                fit: BoxFit.fitWidth,
                alignment: Alignment.topCenter,
              ),
            ),
          ),
        Container(
          width: double.infinity,
          height: 130,
          padding: const EdgeInsets.only(bottom: 0.0, left: 0.0),
          alignment: Alignment.bottomLeft,
          child: actions[0],
        ),
        Container(
          width: double.infinity,
          height: 130,
          padding: const EdgeInsets.only(bottom: 0.0, right: 0.0),
          alignment: Alignment.bottomRight,
          child: actions[1],
        ),
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(top: 120),
          child: Column(
            children: <Widget>[
              InkWell(
                borderRadius: BorderRadius.all(Radius.circular(40)),
                child: Avatar(
                  image: avatar,
                  radius: 40,
                  name: title,
                  backgroundColor: ThemeColor.getColor("color"),
                  borderWidth: 4.0,
                ),
                onTap: this.changeAvatar,
              ),
              Text(
                title,
                style: Theme.of(context).textTheme.headline6,
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 5.0),
                ActionChip(
                  label: Text(
                    subtitle,
                    style: Theme.of(context).textTheme.subtitle2,
                  ),
                  tooltip: "切换角色",
                  onPressed: changeRole,
                ),
              ]
            ],
          ),
        )
      ],
    );
  }
}

class Avatar extends StatelessWidget {
  final String image;
  final Color backgroundColor;
  final double radius;
  final double borderWidth;
  final String name;

  const Avatar(
      {Key key,
      this.image,
      this.name,
      this.backgroundColor,
      this.radius = 30,
      this.borderWidth = 5})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: radius + borderWidth,
      backgroundColor: ThemeColor.getColor("color"),
      child: CircleAvatar(
        radius: radius,
        backgroundColor: backgroundColor != null
            ? backgroundColor
            : Theme.of(context).primaryColor,
        child: CircularProfileAvatar(
          image != null && image.trim().length > 0 ? image : '',
          backgroundColor: ThemeColor.getColor("focus"),
          borderColor: ThemeColor.getColor("focus"),
          initialsText: Text(
            name.substring(0, 1),
            style: TextStyle(
              fontSize: 30.0,
              fontWeight: FontWeight.w600,
              color: ThemeColor.getColor("info"),
            ),
          ),
          cacheImage: true,
        ),
      ),
    );
  }
}
