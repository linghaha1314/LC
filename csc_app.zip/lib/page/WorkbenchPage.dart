import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefresherScroll.dart';
import 'package:csc_app/component/RowsLayout.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../ThemeColor.dart';

class Workbench extends StatefulWidget {
  @override
  WorkbenchPageState createState() => new WorkbenchPageState();
}

class WorkbenchPageState extends State<Workbench> {
  Map<String, List<dynamic>> data = {};
  RefreshController _refreshController =
      RefreshController(initialRefresh: true);

  @override
  void initState() {
    super.initState();
    workbenchPageState = this;
  }

  refresh() {
    _refreshController.requestRefresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("工作台"),
      ),
      body: RefresherScroll(
        enablePullDown: true,
        onRefresh: _refresh,
        controller: _refreshController,
        header: WaterDropMaterialHeader(
          distance: 40.0,
          color: ThemeColor.getColor("fontColor"),
          backgroundColor: ThemeColor.getColor("focus"),
        ),
        child: data.keys.length > 0
            ? SingleChildScrollView(
                child: getBody(context),
              )
            : Column(
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(.0, 20.0, .0, 35.0),
                    child: Text("✨您的角色当前无菜单,请联系管理员✨"),
                  ),
                  Expanded(
                    flex: 1,
                    child: emptyWidget,
                  )
                ],
              ),
      ),
    );
  }

  Widget getBody(BuildContext context) {
    return Column(
      children: [
        ...data.keys.map((e) {
          List<Widget> list = [];
          for (var i = 0; i < data[e].length; i++) {
            list.add(_buildButton(i, e));
          }
          return Card(
            margin: EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10.0),
              width: MediaQuery.of(context).size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: EdgeInsets.fromLTRB(.0, .0, .0, 10.0),
                    child: Text(e),
                  ),
                  Divider(),
                  Container(
                    margin: EdgeInsets.fromLTRB(.0, 10.0, .0, .0),
                    child: RowsLayout(width: 120, list: list),
                  )
                ],
              ),
            ),
          );
        }).toList(),
        Container(
          padding: EdgeInsets.fromLTRB(.0, .0, .0, 35.0),
          child: Text("✨更多功能敬请期待✨"),
        ),
      ],
    );
  }

  _buildButton(int v, String group) {
    if (v < data[group].length) {
      return TextButton(
        style:
            ButtonStyle(padding: MaterialStateProperty.all(EdgeInsets.all(10))),
        child: Column(
          children: [
            SvgPicture.string(
              data[group][v]["icon"],
              width: 40,
              height: 40,
              color: ThemeColor.getColor("focus"),
            ),
            Text(
              data[group][v]["name"],
              softWrap: true,
              textAlign: TextAlign.left,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
        onPressed: () {
          String route = data[group][v]["code"];
          try {
            var list = route.split(":");
            if (list.length == 1) {
              Navigator.pushNamed(context, list[0]);
            } else {
              Navigator.pushNamed(context, list[0], arguments: {
                "type": list[1],
                "title": data[group][v]["name"]
              });
            }
          } on FlutterError catch (e) {
            print(e);
            showErrorToast("未找到路由[$route],请更新app后重试");
          }
        },
      );
    }
    return Card();
  }

  Future<void> _refresh() async {
    try {
      var account = await getCurrentAccount();
      if (account == null ||
          account.role == null ||
          account.role["id"] == null) {
        _refreshController.refreshFailed();
        return;
      }
      setState(() {
        data.clear();
      });
      post("/appmenus/listMenuRolesByRole",
          {"roleId": account.role["id"], "status": "0"}).then((v) {
        (v["data"]["rows"] as List<dynamic>).forEach((group) {
          data[group["menuGroupName"]] = group["menuList"];
        });
        setState(() {});
        _refreshController.refreshCompleted();
      }).catchError((err) {
        _refreshController.refreshFailed();
        showErrorToast(err["msg"]);
      });
    } catch (e) {
      _refreshController.refreshFailed();
      showErrorToast("网络错误,请重新尝试!");
    }
  }

  @override
  void dispose() {
    workbenchPageState = this;
    super.dispose();
  }
}
