import 'package:animations/animations.dart';
import 'package:csc_app/page/base/PasswordSetForm.dart';
import 'package:csc_app/page/base/SettingPage.dart';
import 'package:csc_app/page/base/StaffSetForm.dart';
import 'package:csc_app/page/base/TodoTaskPage.dart';
import 'package:csc_app/page/base/devices_page.dart';
import 'package:csc_app/page/exam/examStorehouse/ExamStorehouseExamPage.dart';
import 'package:csc_app/page/exam/examplan/mine_exam.dart';
import 'package:csc_app/page/gme/coursesignature/CourseSignaturePage.dart';
import 'package:csc_app/page/gme/resources/resource_staff.dart';
import 'package:csc_app/page/gme/resources/resource_video.dart';
import 'package:csc_app/page/gme/scorerecord/ScoreRecordPage.dart';
import 'package:csc_app/page/gme/temporarycouressignature/TemporaryCourseSignaturePage.dart';
import 'package:csc_app/page/login/loginPage.dart';
import 'package:csc_app/page/process/CenterWorkbench.dart';
import 'package:csc_app/page/process/opentraining/OpenPlacePage.dart';
import 'package:csc_app/page/process/place-access/OneKeyOpenDoor.dart';
import 'package:csc_app/page/process/place/PlaceDrillView.dart';
import 'package:csc_app/page/process/safe-education/SafeEducationPage.dart';
import 'package:csc_app/page/process/safe-education/SafeEducationRecordPage.dart';
import 'package:csc_app/page/process/securitycheck/SecurityCheckPage.dart';
import 'package:csc_app/page/supplies/articleInventory/ArticleInventoryForm.dart';
import 'package:csc_app/page/supplies/articleInventory/ArticleInventoryQRCodePage.dart';
import 'package:csc_app/page/supplies/equipmentborrow/EquipmentBorrowPage.dart';
import 'package:csc_app/page/supplies/equipmentborrow/EquipmentBorrowForm.dart';
import 'package:csc_app/page/supplies/equipmentPurchase/EquipmentPurchasePage.dart';
import 'package:csc_app/page/supplies/storehouseArticleQuery/StorehouseArticleQueryPage.dart';
import 'package:csc_app/page/supplies/suppliesPurchase/SuppliesPurchasePage.dart';
import 'package:csc_app/page/supplies/storehouseSupplies/StorehouseSuppliesPage.dart';
import 'package:csc_app/page/supplies/equipmentWarehousing/EquipmentWarehousingView.dart';
import 'package:csc_app/page/supplies/suppliesHighReceive/SuppliesHighReceivePage.dart';
import 'package:csc_app/page/exam/videoRatingPlan/VideoRatingPlanPage.dart';
import 'package:csc_app/page/exam/simpleTest/SimpleTestScore.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:csc_app/page/process/place/PlacePage.dart';
import './page/MinePage.dart';
import './page/InitPage.dart';
import './component/dynamic_theme.dart';
import 'package:flutter/material.dart';
import 'package:csc_exam_info/page/CheckPage.dart';
import 'package:csc_exam_info/page/InfoPage.dart';
import 'package:csc_exam_info/page/ScreenPage.dart';
import 'package:csc_exam_info/page/TabletPage.dart';
import 'ThemeColor.dart';
import 'page/base/ChatDetailPage.dart';
import 'page/exam/examvolume/answer_result_page.dart';
import 'page/exam/examvolume/volume_page.dart';
import 'page/process/place-access/PlaceAccessPage.dart';
import 'page/process/survey/SurveyRecordPage.dart';
import 'page/process/survey/survey_volume.dart';
import 'page/supplies/articleInventory/ArticleInventoryPage.dart';
import 'page/supplies/articleReceiving/ArticleReceiving.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
//    NAME         SIZE  WEIGHT  SPACING
//    headline1    96.0  light   -1.5
//    headline2    60.0  light   -0.5
//    headline3    48.0  regular  0.0
//    headline4    34.0  regular  0.25
//    headline5    24.0  regular  0.0
//    headline6    20.0  medium   0.15
//    subtitle1    16.0  regular  0.15
//    subtitle2    14.0  medium   0.1
//    body1        16.0  regular  0.5   (bodyText1)
//    body2        14.0  regular  0.25  (bodyText2)
//    button       14.0  medium   1.25
//    caption      12.0  regular  0.4
//    overline     10.0  regular  1.5
//    where "light" is FontWeight.w300, "regular" is FontWeight.w400 and "medium" is FontWeight.w500.
    ThemeColor.initStatusBar();
    return new DynamicTheme(
      defaultBrightness: ThemeColor.getBaseTheme() == "dark"
          ? Brightness.dark
          : Brightness.light,
      data: (brightness) => new ThemeData(
        fontFamily: '微软雅黑',
        brightness: brightness,
        useMaterial3: true,
        colorScheme: ColorScheme(
          brightness: brightness,
          primary: ThemeColor.getColor("focus"),
          onPrimary: ThemeColor.getColor("fontColor"),
          secondary: ThemeColor.getColor("appbar"),
          onSecondary: ThemeColor.getColor("barFontColor"),
          error: ThemeColor.getColor("danger"),
          onError: ThemeColor.getColor("fontColor"),
          background: ThemeColor.getColor("color"),
          onBackground: ThemeColor.getColor("fontColor"),
          surface: ThemeColor.getColor("toolbar"),
          onSurface: ThemeColor.getColor("fontColor"),
        ),
        iconTheme: IconThemeData(color: ThemeColor.getColor("fontColor")),
        canvasColor: ThemeColor.getColor("color"),
        hoverColor: ThemeColor.getColor("active"),
        textSelectionTheme: TextSelectionThemeData(
          cursorColor: ThemeColor.getColor("focus"),
          selectionHandleColor: ThemeColor.getColor("focus"),
          selectionColor: ThemeColor.getColor("color"),
        ),
        highlightColor: ThemeColor.getColor("focus"),
        cardColor: ThemeColor.getColor("content"),
        cardTheme: CardTheme(
          color: ThemeColor.getColor("content"),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(15.0)),
          ),
          shadowColor: ThemeColor.getColor("active").withOpacity(0.3),
          clipBehavior: Clip.antiAlias,
        ),
        bottomAppBarTheme: BottomAppBarTheme(
          color: ThemeColor.getColor("appbar"),
        ),
        tabBarTheme: TabBarTheme(
          labelColor: ThemeColor.getColor("fontColor"),
        ),
        indicatorColor: ThemeColor.getColor("focus"),
        hintColor: ThemeColor.getColor("fontColor"),
        focusColor: ThemeColor.getColor("focus"),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: ThemeColor.getColor("appbar"),
          selectedItemColor: ThemeColor.getColor("focus"),
          unselectedItemColor: ThemeColor.getColor("barFontColor"),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: ThemeColor.getColor("appbar"),
          surfaceTintColor: ThemeColor.getColor("focus"),
          indicatorColor: ThemeColor.getColor("content"),
          height: 70.0,
          labelTextStyle: MaterialStateProperty.all(
            TextStyle(
              color: ThemeColor.getColor("barFontColor"),
            ),
          ),
          iconTheme: MaterialStateProperty.all(
            IconThemeData(
              color: ThemeColor.getColor("barFontColor"),
            ),
          ),
        ),
        buttonBarTheme: const ButtonBarThemeData(
          buttonTextTheme: ButtonTextTheme.primary,
        ),
        buttonTheme: ButtonThemeData(
          buttonColor: ThemeColor.getColor("data"),
          splashColor: ThemeColor.getColor("appbar"),
          textTheme: ButtonTextTheme.accent,
          colorScheme: Theme.of(context).colorScheme.copyWith(
                secondary: ThemeColor.getColor("fontColor"),
                background: ThemeColor.getColor("color"),
                brightness: brightness,
              ),
        ),
        chipTheme: ChipThemeData.fromDefaults(
          primaryColor: ThemeColor.getColor("focus"),
          secondaryColor: ThemeColor.getColor("active"),
          labelStyle: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 16.0,
            wordSpacing: 0.5,
            fontWeight: FontWeight.w400,
          ),
        ),
        dialogTheme: DialogTheme(
          backgroundColor: ThemeColor.getColor("content"),
        ),
        dividerTheme:
            DividerThemeData(color: ThemeColor.getColor("border"), space: 0.0),
        inputDecorationTheme: InputDecorationTheme(
          contentPadding:
              const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
          border: UnderlineInputBorder(
              borderSide: BorderSide(color: ThemeColor.getColor("border"))),
          focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: ThemeColor.getColor("focus"))),
        ),
        primaryIconTheme:
            IconThemeData(color: ThemeColor.getColor("fontColor")),
        primaryColor: ThemeColor.getColor("focus"),
        splashColor: ThemeColor.getColor("active"),
        timePickerTheme: TimePickerThemeData(
          backgroundColor: ThemeColor.getColor("content"),
          dialTextColor: ThemeColor.getColor("fontColor"),
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: ThemeColor.getColor("data"),
          splashColor: ThemeColor.getColor("appbar"),
          foregroundColor: ThemeColor.getColor("fontColor"),
        ),
        textTheme: TextTheme(
          displayLarge: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 96.0,
            wordSpacing: -1.5,
            fontWeight: FontWeight.w300,
          ),
          displaySmall: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 60.0,
            wordSpacing: -0.5,
            fontWeight: FontWeight.w300,
          ),
          headlineMedium: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 34.0,
            wordSpacing: 0.25,
            fontWeight: FontWeight.w400,
          ),
          headlineSmall: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 24.0,
            wordSpacing: 0.0,
            fontWeight: FontWeight.w400,
          ),
          titleLarge: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 20.0,
            wordSpacing: 0.15,
            fontWeight: FontWeight.w500,
          ),
          bodyLarge: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 16.0,
            wordSpacing: 0.5,
            fontWeight: FontWeight.w400,
          ),
          bodyMedium: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 14.0,
            wordSpacing: 0.25,
            fontWeight: FontWeight.w400,
          ),
          titleMedium: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 16.0,
            wordSpacing: 0.15,
            fontWeight: FontWeight.w400,
          ),
          titleSmall: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 14.0,
            wordSpacing: 0.1,
            fontWeight: FontWeight.w500,
          ),
        ),
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(color: ThemeColor.getColor("barFontColor")),
          color: ThemeColor.getColor("appbar"),
          titleTextStyle: TextStyle(
            color: ThemeColor.getColor("barFontColor"),
            fontSize: 20.0,
            wordSpacing: 0.15,
            fontWeight: FontWeight.w500,
          ),
          toolbarTextStyle: TextStyle(
            color: ThemeColor.getColor("fontColor"),
            fontSize: 20.0,
            wordSpacing: 0.15,
            fontWeight: FontWeight.w500,
          ),
        ),
        popupMenuTheme: PopupMenuThemeData(color: ThemeColor.getColor("menu")),
        tooltipTheme: TooltipThemeData(
          textStyle: const TextStyle(fontSize: 13),
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: ThemeColor.getColor("active"),
                spreadRadius: 5,
                blurRadius: 7,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ],
            color: ThemeColor.getColor("menu"),
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all(
              ThemeColor.getColor("focus"),
            ),
            overlayColor: MaterialStateProperty.all(
              ThemeColor.getColor("menu"),
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: ButtonStyle(
            foregroundColor: MaterialStateProperty.all(
              ThemeColor.getColor("focus"),
            ),
            shadowColor: MaterialStateProperty.all(
              ThemeColor.getColor("focus"),
            ),
            overlayColor: MaterialStateProperty.all(
              ThemeColor.getColor("menu"),
            ),
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(
              ThemeColor.getColor("appbar"),
            ),
            foregroundColor: MaterialStateProperty.all(
              ThemeColor.getColor("barFontColor"),
            ),
          ),
        ),
      ),
      themedWidgetBuilder: (context, theme) {
        return new MaterialApp(
          title: '临床技能中心',
          theme: theme.copyWith(
            pageTransitionsTheme: const PageTransitionsTheme(
              builders: <TargetPlatform, PageTransitionsBuilder>{
                TargetPlatform.fuchsia: FadeThroughPageTransitionsBuilder(),
                TargetPlatform.android: FadeThroughPageTransitionsBuilder(),
                TargetPlatform.windows: FadeThroughPageTransitionsBuilder(),
                TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
                TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
              },
            ),
          ),
          localeResolutionCallback:
              (Locale locale, Iterable<Locale> supportedLocales) {
            //print("change language");
            return locale;
          },
          localizationsDelegates: [
            RefreshLocalizations.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
          ],
          supportedLocales: [
            Locale.fromSubtags(languageCode: 'zh'),
            Locale.fromSubtags(
                languageCode: 'zh', scriptCode: 'Hans', countryCode: 'CN'),
          ],
          home: InitPage(),
          routes: <String, WidgetBuilder>{
            'login': (BuildContext context) => new LoginPage(),
            'todoTask': (BuildContext context) => new TodoTaskPage(),
            'mine': (BuildContext context) => new Mine(),
            'setting': (BuildContext context) => new Setting(),
            'openTrainingList': (BuildContext context) => new OpenPlacePage(),
            'placeListDrillList': (BuildContext context) => new PlacePage(),
            'passwordSet': (BuildContext context) => new PasswordSet(),
            'staffSet': (BuildContext context) => new StaffSet(),
            'reservationSignIn': (BuildContext context) => new PlaceDrillView(),
            'chatDetailPage': (BuildContext context) => new ChatDetailPage(),
            'securityCheck': (BuildContext context) => new SecurityCheckPage(),
            'storehouseArticleQuery': (BuildContext context) =>
                new StorehouseArticleQuery(),
            'equipmentBorrow': (BuildContext context) =>
                new EquipmentBorrowPage(),
            'equipmentPurchase': (BuildContext context) =>
                new EquipmentPurchasePage(),
            'suppliesPurchase': (BuildContext context) =>
                new SuppliesPurchasePage(),
            'scoreRecord': (BuildContext context) => new ScoreRecordPage(),
            'articleReceiving': (BuildContext context) =>
                new ArticleReceiving(),
            'storehouseSupplies': (BuildContext context) =>
                new StorehouseSuppliesPage(),
            'equipmentWarehousing': (BuildContext context) =>
                new EquipmentWarehousingView(),
            'equipmentBorrowForm': (BuildContext context) =>
                new EquipmentBorrowForm(null),
            'placeAccess': (BuildContext context) => new PlaceAccessPage(),
            'videoRatingPlan': (BuildContext context) =>
                new VideoRatingPlanPage(),
            'safeEducationRecord': (BuildContext context) =>
                new SafeEducationRecordPage(null),
            'examStorehouseExamine': (BuildContext context) =>
                new ExamStorehouseExamPage(),
            'articleInventoryQR': (BuildContext context) =>
                new ArticleInventoryQRCodePage(),
            'articleInventory': (BuildContext context) =>
                new ArticleInventoryForm(),
            'articleInventoryList': (BuildContext context) =>
                new ArticleInventoryPage(),
            'safeEducation': (BuildContext context) => new SafeEducationPage(),
            'courseSignature': (BuildContext context) =>
                new CourseSignaturePage(),
            'suppliesHighReceivePage': (BuildContext context) =>
                new SuppliesHighReceivePage(),
            'temporaryCouresSignature': (BuildContext context) =>
                new TemporaryCourseSignaturePage(),
            'simpleTestScore': (BuildContext context) => new SimpleTestScore(),
            'oneKeyOpenDoor': (BuildContext context) =>
                new OneKeyOpenDoorPage(),
            'surveyRecord': (BuildContext context) => new SurveyRecordPage(),
            'resourceStaff': (BuildContext context) => new ResourceStaffPage(),
            'resourceVideo': (BuildContext context) => new ResourceVideoPage(),
            'volume': (BuildContext context) => new VolumePage(),
            'volumeResult': (BuildContext context) => new AnswerResultPage(),
            'devices': (BuildContext context) => new DevicesPage(),
            'mineExam': (BuildContext context) => new MineExamPage(),
            'surveyVolume': (BuildContext context) => new SurveyVolumePage(),
            'centerWorkbench': (BuildContext context) => new CenterWorkbench(),
            "info": (BuildContext context) => new InfoPage(),
            "tablet": (BuildContext context) => new TabletPage(),
            "screen": (BuildContext context) => new ScreenPage(),
            "check": (BuildContext context) => new CheckPage(),
          },
        );
      },
    );
  }
}
