import 'dart:ui';

import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/component/RefresherScroll.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import '../ThemeColor.dart';

class RefreshList extends StatefulWidget {
  final String url;
  final String searchText;
  final Function buildItem;
  final Function loadSuccess;
  final Function refreshBefore;
  final Map<String, dynamic> queryParams;
  final String queryKey;
  final bool divide;
  final bool enablePullDown;
  final bool enablePullUp;
  final RefreshController controller;
  final String tooltip;

  const RefreshList(
      {Key key,
      @required this.url,
      this.queryParams,
      this.queryKey,
      @required this.buildItem,
      this.searchText,
      this.loadSuccess,
      this.refreshBefore,
      this.divide,
      this.enablePullDown = true,
      this.enablePullUp = true,
      this.controller,
      this.tooltip})
      : super(key: key);

  @override
  _RefreshListState createState() => new _RefreshListState(
        buildItem: this.buildItem,
        url: this.url,
        queryParams: this.queryParams,
        queryKey: this.queryKey,
        searchText: this.searchText,
        loadSuccess: this.loadSuccess,
        refreshBefore: this.refreshBefore,
        divide: this.divide,
        enablePullDown: this.enablePullDown,
        enablePullUp: this.enablePullUp,
        controller: this.controller,
        tooltip: this.tooltip,
      );
}

class _RefreshListState extends State<RefreshList> {
  String url;

  bool _refresh = false;

  bool _more = true;

  Map<String, dynamic> queryParams = {};

  String queryKey = "name";

  String tooltip = "暂时还没有数据😴,您可以下拉刷新🐛";

  int pageNum = 1;

  int pageSize = 20;

  List<dynamic> items = [];

  Function buildItem;

  Function loadSuccess;

  Function refreshBefore;

  String searchText;

  bool divide = true;

  bool _load = true;

  RefreshController _refreshController;

  _RefreshListState(
      {url,
      queryParams,
      queryKey,
      buildItem,
      searchText,
      loadSuccess,
      refreshBefore,
      divide,
      enablePullDown,
      enablePullUp,
      controller,
      tooltip}) {
    this.url = url;
    this.buildItem = buildItem;
    this.loadSuccess = loadSuccess;
    this.refreshBefore = refreshBefore;
    if (tooltip != null) this.tooltip = tooltip;
    if (queryParams != null) this.queryParams = queryParams;
    if (queryKey != null) this.queryKey = queryKey;
    if (searchText != null) this.searchText = searchText;
    if (divide != null) this.divide = divide;
    if (controller != null) {
      this._refreshController = controller;
    } else {
      this._refreshController = RefreshController(initialRefresh: false);
    }
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (searchText != null)
          Container(
            height: 50,
            padding: EdgeInsets.fromLTRB(6.0, 6.0, 6.0, 6.0),
            child: TextField(
              onChanged: (v) {
                queryParams[queryKey] = v;
                _refresh = true;
                _more = true;
                pageNum = 1;
                _refreshController.loadComplete();
                getData();
              },
              decoration: InputDecoration(
                suffixIcon: Icon(Icons.search),
                hintText: searchText,
              ),
            ),
          ),
        Visibility(
          visible: _load,
          child: Expanded(
            flex: 1,
            child: Center(
              child: Container(
                height: 65.0,
                width: 65.0,
                child: loadingWidget,
              ),
            ),
          ),
        ),
        Visibility(
          visible: !_load,
          child: Expanded(
            flex: 1,
            child: Scrollbar(
              child: RefresherScroll(
                enablePullDown: widget.enablePullDown,
                enablePullUp: widget.enablePullUp,
                controller: _refreshController,
                header: WaterDropMaterialHeader(
                  distance: 40.0,
                  color: ThemeColor.getColor("fontColor"),
                  backgroundColor: ThemeColor.getColor("focus"),
                ),
                child: items.length > 0
                    ? ListView.separated(
                        itemBuilder: (BuildContext context, int i) {
                          return buildItem(items[i], i);
                        },
                        separatorBuilder: (BuildContext context, int i) {
                          return divide ? Divider() : Container();
                        },
                        itemCount: items.length,
                      )
                    : Stack(
                        fit: StackFit.expand,
                        children: <Widget>[
                          emptyWidget,
                          if (tooltip != null)
                            Center(
                              child: ClipRect(
                                child: Text(tooltip),
                              ),
                            ),
                        ],
                      ),
                onRefresh: _refreshData,
                onLoading: _loadMoreData,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _refreshData() async {
    if (refreshBefore != null) {
      refreshBefore();
    }
    _refresh = true;
    _more = true;
    pageNum = 1;
    _refreshController.loadComplete();
    await getData();
    return Future.value(null);
  }

  void _loadMoreData() async {
    if (!_more) {
      _refreshController.loadNoData();
      return;
    }
    _refresh = false;
    pageNum++;
    await getData();
  }

  getData() async {
    post(url, {...queryParams, "pageNum": pageNum, "pageSize": pageSize})
        .then((res) {
      var rows = res["rows"] as List<dynamic>;
      if (loadSuccess != null) {
        loadSuccess(rows);
      }
      setState(() {
        if (_refresh) {
          items = rows;
        } else {
          items.addAll(rows);
        }
        if (items.length == res["total"]) {
          _more = false;
        }
        _load = false;
      });
      if (_refresh) {
        _refreshController.refreshCompleted();
      } else {
        if (_more) {
          _refreshController.loadComplete();
        } else {
          _refreshController.loadNoData();
        }
      }
    }).catchError((err) {
      print(err);
      if (_refresh) {
        _refreshController.refreshFailed();
      } else {
        _refreshController.loadFailed();
      }
      showErrorToast(err["msg"]);
    });
  }
}
