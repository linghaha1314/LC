import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../ThemeColor.dart';

abstract class DialogOverlay extends ModalRoute<void> {
  @override
  Duration get transitionDuration => Duration(milliseconds: 150);

  @override
  bool get opaque => false;

  @override
  bool get barrierDismissible => false;

  @override
  Color get barrierColor => Colors.black.withOpacity(0.5);

  @override
  String get barrierLabel => null;

  @override
  bool get maintainState => true;
  var icon = Icons.desktop_windows;
  var title = "Dialog";
  var cancelFlag = true;
  var okFlag = true;
  var okTxt = "保存";
  var cancelTxt = "关闭";
  var btnAlign = MainAxisAlignment.end;
  Size size;
  BuildContext ctt;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    // This makes sure that text and other content follows the material style
    return _buildOverlayContent(context);
  }

  Widget _buildOverlayContent(BuildContext context) {
    ctt = context;
    if (size == null) {
      size = MediaQuery.of(context).size;
    }
    return Center(
      child: Material(
        elevation: 4,
        borderRadius: BorderRadius.all(Radius.circular(10)),
        color: ThemeColor.getColor("content"),
        child: Container(
          width: size.width * 0.85,
          height: size.height > 0 ? size.height * 0.85 : null,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              Container(
                height: 30,
                padding: EdgeInsets.fromLTRB(5.0, 10.0, .0, .0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    SizedBox(width: 30.0, child: new Icon(icon, size: 18.0)),
                    Text(
                      title,
                      softWrap: true,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  child: buildContent(context),
                ),
              ),
              Container(
                height: 36,
                margin: EdgeInsets.fromLTRB(.0, .0, 10.0, 10.0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: btnAlign,
                  children: <Widget>[
                    Visibility(
                      visible: cancelFlag,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                        child: InkWell(
                          onTap: () {
                            if (beforeClose()) {
                              close();
                            }
                          },
                          child: Center(
                            child: Container(
                              padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                              child: Text(cancelTxt),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: okFlag,
                      child: TextButton(
                        onPressed: () {
                          onSave(ctt);
                        },
                        child: Center(
                          child: Container(
                            padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
                            child: Text(okTxt),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget child) {
    // You can add your own animations for the overlay content
    return FadeTransition(
      opacity: animation,
      child: child,
    );
  }

  Widget buildContent(BuildContext context);

  void onSave(BuildContext context) {}

  bool beforeClose() {
    return true;
  }

  void close() {
    Navigator.pop(ctt, false);
  }

  void popTrue() {
    Navigator.pop(ctt, true);
  }
}
