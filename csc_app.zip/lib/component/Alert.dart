import 'package:flutter/material.dart';

import 'DialogOverlay.dart';

class Alert extends DialogOverlay {

  var msg = "";

  var contentIcon = Icons.error;

  Alert(String msg, String title, IconData iconData) {
    this.msg = msg;
    this.title = title;
    this.icon = Icons.adjust;
    contentIcon = iconData;
    this.okTxt = '关闭';
    this.cancelFlag = false;
    this.size = Size(300, 200);
  }

  @override
  Widget buildContent(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
      child: Center(
        child:  Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
              child: Icon(contentIcon, size: 25,),
            ),
            Flexible(
              child: SingleChildScrollView(
                child: Text(msg, style: TextStyle(fontSize: 16),softWrap: true),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void onSave(BuildContext context) {
    popTrue();
  }

}
