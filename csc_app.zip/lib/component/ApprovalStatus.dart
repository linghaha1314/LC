import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../ThemeColor.dart';

class ApprovalStatus extends StatefulWidget {
  final int status;

  ApprovalStatus({
    Key key,
    this.status,
  });

  @override
  State<StatefulWidget> createState() {
    return new ApprovalStatusPage(this.status);
  }
}

class ApprovalStatusPage extends State<ApprovalStatus> {

  int status;

  var statusIconList = [
    Icons.vertical_align_top,
    Icons.close,
    Icons.check,
    Icons.pause,
    Icons.check,
  ];

  var statusList = ["待审核", "已驳回", "已审核", "审核中", "您已审核"];

  var statusColorList = [
    ThemeColor.getColor("info"),
    ThemeColor.getColor("danger"),
    ThemeColor.getColor("success"),
    ThemeColor.getColor("warning"),
    ThemeColor.getColor("success")
  ];

  ApprovalStatusPage(status) {
    this.status = status;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Chip(
          backgroundColor: statusColorList[status],
          label: Row(
            children: [
              Text(
                statusList[status],
                style: TextStyle(
                  color: ThemeColor.getColor("fontColor"),
                ),
              ),
              Icon(
                statusIconList[status],
                color: ThemeColor.getColor("fontColor"),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
