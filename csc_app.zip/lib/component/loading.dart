import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:flutter/material.dart';

class ProgressDialog extends StatelessWidget {
  //子布局
  final Widget child;

  //加载中是否显示
  final bool loading;

  //背景透明度
  final double alpha;

  final Function close;

  ProgressDialog(
      {Key key,
      @required this.loading,
      this.close,
      this.alpha = 0.6,
      @required this.child})
      : assert(child != null),
        assert(loading != null),
        super(key: key);

  @override
  Widget build(BuildContext context) {
    List<Widget> widgetList = [];
    widgetList.add(child);
    if (loading) {
      widgetList.add(Opacity(
        opacity: alpha,
        child: new ModalBarrier(dismissible: false),
      ));
      widgetList.add(Center(
        child: Container(
          width: 65.0,
          height: 65.0,
          decoration: BoxDecoration(
            color: ThemeColor.getColor("active"),
            borderRadius: BorderRadius.all(Radius.circular(10.0)),
          ),
          child: loadingWidget,
        ),
      ));
      if (close != null)
        widgetList.add(
          Center(
            child: Container(
              padding: EdgeInsets.fromLTRB(55.0, .0, .0, 55.0),
              child: InkWell(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    color: ThemeColor.getColor("active"),
                  ),
                  child: const Icon(
                    Icons.close,
                    size: 20.0,
                  ),
                ),
                onTap: close,
              ),
            ),
          ),
        );
    }
    return Scaffold(
      body: Stack(
        children: widgetList,
      ),
    );
  }
}
