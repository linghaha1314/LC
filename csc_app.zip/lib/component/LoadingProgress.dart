import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import '../ThemeColor.dart';
import 'MethodComponent.dart';

OverlayEntry _overlayEntry;
double _percent = 0.0;
String _progress;

showProgressLoading(double percent,
    {String title = "文件上传中",
    bool close = false,
    int total = 0,
    int progress = 0}) {
  if (close) {
    if (_overlayEntry != null) {
      _overlayEntry.remove();
      _overlayEntry = null;
    }
    return;
  }
  _percent = percent;
  if (total != 0) {
    _progress = "${formatSizeUnits(progress)}/${formatSizeUnits(total)}";
  } else {
    _progress = null;
  }
  if (_overlayEntry == null) {
    _overlayEntry = new OverlayEntry(
      builder: (c) => Positioned(
        top: MediaQuery.of(globalContent).size.height * 0.4,
        width: MediaQuery.of(globalContent).size.width * 0.8,
        left: MediaQuery.of(globalContent).size.width * 0.1,
        child: Material(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: ThemeColor.getColor("appbar"),
          elevation: 4.0,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    icon: Icon(Icons.stop),
                    color: ThemeColor.getColor("danger"),
                    tooltip: '停止下载',
                    onPressed: () {},
                  ),
                  Text(
                    title,
                    style:
                        TextStyle(fontSize: 20.0, fontWeight: FontWeight.w500),
                  ),
                  IconButton(
                    icon: Icon(Icons.chevron_right),
                    tooltip: '隐藏',
                    onPressed: () {},
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.all(10.0),
                child: LinearPercentIndicator(
                  padding: EdgeInsets.fromLTRB(0, .0, 1.0, 0.0),
                  lineHeight: 20,
                  percent: _percent,
                  animation: false,
                  animationDuration: 500,
                  progressColor: ThemeColor.getColor("progress"),
                  backgroundColor: ThemeColor.getColor("toolbar"),
                  linearStrokeCap: LinearStrokeCap.butt,
                  center: Text(
                    (_percent * 100).roundToDouble().toString() + "%",
                    style: TextStyle(
                      fontSize: 14.0,
                      height: 1.15, //You can set your custom height here
                    ),
                  ),
                ),
              ),
              if (_progress != null)
                Container(
                  padding: EdgeInsets.all(10.0),
                  child: Text("$_progress"),
                )
            ],
          ),
        ),
      ),
    );
    Overlay.of(globalContent).insert(_overlayEntry);
  }
  _overlayEntry.markNeedsBuild();
  if (percent >= 1.0) {
    _overlayEntry.remove();
    _overlayEntry = null;
  }
}

showLoading({String title = "文件上传中", bool close = false}) {
  if (close) {
    if (_overlayEntry != null) {
      _overlayEntry.remove();
      _overlayEntry = null;
    }
    return;
  }
  if (_overlayEntry == null) {
    _overlayEntry = new OverlayEntry(
      builder: (c) => Positioned(
        top: MediaQuery.of(globalContent).size.height * 0.4,
        width: MediaQuery.of(globalContent).size.width * 0.8,
        left: MediaQuery.of(globalContent).size.width * 0.1,
        child: Material(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: ThemeColor.getColor("appbar"),
          elevation: 4.0,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Text(
                title,
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.w500),
              ),
              Container(
                padding: EdgeInsets.all(10.0),
                child: LinearProgressIndicator(),
              ),
            ],
          ),
        ),
      ),
    );
    Overlay.of(globalContent).insert(_overlayEntry);
  }
}

String formatSizeUnits(int bytes) {
  var txt = "";
  if (bytes >= 1073741824) {
    txt = "${(bytes / 1073741824).toStringAsFixed(2)} GB";
  } else if (bytes >= 1048576) {
    txt = "${(bytes / 1048576).toStringAsFixed(2)} MB";
  } else if (bytes >= 1024) {
    txt = "${(bytes / 1024).toStringAsFixed(2)} KB";
  } else if (bytes > 1) {
    txt = "$bytes bytes";
  } else if (bytes == 1) {
    txt = "$bytes byte";
  } else {
    txt = "0 bytes";
  }
  return txt;
}
