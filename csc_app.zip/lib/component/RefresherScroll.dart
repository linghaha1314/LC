import 'package:csc_app/utils/AssetConst.dart';
import 'package:flutter/material.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class RefresherScroll extends StatefulWidget {
  final Widget child;
  final Widget header;
  final Widget footer;
  final bool enablePullUp;
  final bool enablePullDown;
  final VoidCallback onRefresh;
  final VoidCallback onLoading;
  final RefreshController controller;

  RefresherScroll({
    Key key,
    @required this.controller,
    this.child,
    this.header,
    this.footer,
    this.enablePullDown: true,
    this.enablePullUp: false,
    this.onRefresh,
    this.onLoading,
  })  : assert(controller != null),
        super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _RefresherScrollState();
  }
}

class _RefresherScrollState extends State<RefresherScroll> {
  @override
  Widget build(BuildContext context) {
    return SmartRefresher(
      enablePullUp: widget.enablePullUp,
      enablePullDown: widget.enablePullDown,
      header: widget.header ??
          CustomHeader(builder: (BuildContext context, RefreshStatus status) {
            Widget body;
            if (status == RefreshStatus.idle) {
              body = Text("下拉刷新");
            } else if (status == RefreshStatus.refreshing) {
              body = Container(
                height: 35,
                margin: EdgeInsets.all(0.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 35,
                      child: loadingWidget,
                    ),
                    Text("刷新中...")
                  ],
                ),
              );
            } else if (status == RefreshStatus.failed) {
              body = Text("刷新失败,请重新尝试!");
            } else if (status == RefreshStatus.completed) {
              body = Text("刷新完成!");
            } else if (status == RefreshStatus.canRefresh) {
              body = Text("松开刷新!");
            } else {
              body = Text("无数据");
            }
            return Container(
              height: 35.0,
              child: Center(child: body),
            );
          }),
      footer: widget.footer ??
          CustomFooter(
            builder: (BuildContext context, LoadStatus mode) {
              Widget body;
              if (mode == LoadStatus.idle) {
                body = Text("上拉加载");
              } else if (mode == LoadStatus.loading) {
                body = Container(
                  height: 35,
                  margin: EdgeInsets.all(0.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 35,
                        child: loadingWidget,
                      ),
                      Text("加载中..."),
                    ],
                  ),
                );
              } else if (mode == LoadStatus.failed) {
                body = Text("加载失败,请重新尝试!");
              } else if (mode == LoadStatus.canLoading) {
                body = Text("✨松开加载更多✨");
              } else {
                body = Text("ヾ(•ω•`)o无更多数据");
              }
              return Center(
                child: body,
              );
            },
          ),
      controller: widget.controller,
      child: widget.child,
      onRefresh: widget.onRefresh,
      onLoading: widget.onLoading,
    );
  }
}
