import 'package:flutter/material.dart';

import 'DialogOverlay.dart';

class Confirm extends DialogOverlay {
  var msg = "";

  Confirm(String msg, {okText = "确认", cancelText = "取消", title= "提示", width = 300.0, height = 300.0}) {
    this.msg = msg;
    this.title = title;
    this.icon = Icons.help_outline;
    this.cancelTxt = cancelText;
    this.okTxt = okText;
    this.size = Size(width, height);
  }

  @override
  Widget buildContent(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(10.0, .0, 10.0, .0),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Container(
            padding: EdgeInsets.fromLTRB(.0, .0, 5.0, .0),
            child: Icon(
              Icons.help,
              size: 25,
            ),
          ),
          Flexible(
            child: SingleChildScrollView(
              child: Text(msg, style: TextStyle(fontSize: 16), softWrap: true),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void onSave(BuildContext context) {
    popTrue();
  }
}
