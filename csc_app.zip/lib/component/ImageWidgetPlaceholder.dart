import 'package:flutter/material.dart';

class ImageWidgetPlaceholder extends StatelessWidget {
  const ImageWidgetPlaceholder({
    Key key,
    this.image,
    this.placeholder,
    this.width,
    this.fit,
  }) : super(key: key);

  final ImageProvider image;
  final Widget placeholder;
  final double width;
  final BoxFit fit;

  @override
  Widget build(BuildContext context) {
    return Image(
      image: image,
      fit: fit,
      width: width,
      frameBuilder: (context, child, frame, wasSynchronousLoaded) {
        if (wasSynchronousLoaded) {
          return child;
        } else {
          return AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: frame != null ? child : placeholder,
          );
        }
      },
    );
  }
}