import 'dart:io';

import 'package:csc_app/component/BaseApp.dart';
import 'package:csc_app/component/MethodComponent.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:painter/painter.dart';
import 'package:path_provider/path_provider.dart';

class SignatureComponent extends BaseApp {
  @override
  _SignatureComponentState createState() => new _SignatureComponentState();
}

class _SignatureComponentState extends BaseAppPage<SignatureComponent> {
  PainterController _controller;
  dynamic data;

  _SignatureComponentState() {
    title = '电子签名';
  }

  @override
  Widget getBody(BuildContext context) {
    return Container(
      child: Painter(_controller),
    );
  }

  @override
  void initState() {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    empty = false;
    super.initState();
    _controller = _newController();
  }

  PainterController _newController() {
    PainterController controller = new PainterController();
    controller.thickness = 5.0;
    controller.backgroundColor = Colors.white;
    return controller;
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          setState(() {
            _controller.undo();
          });
        },
        tooltip: "撤销",
        icon: Icon(Icons.undo),
      ),
      IconButton(
        onPressed: () {
          setState(() {
            _controller.clear();
          });
        },
        tooltip: "重置",
        icon: Icon(Icons.refresh),
      ),
      IconButton(
        onPressed: () async {
          if (!_controller.isEmpty) {
            PictureDetails p = _controller.finish();
            var image = await p.toPNG();
            File file = await writeToFile(image.toList());
            Navigator.pop(context, file.path);
          } else {
            showErrorToast("请进行签名后进行提交！");
          }
        },
        tooltip: "提交",
        icon: Icon(Icons.check),
      ),
    ];
  }

  Future<File> writeToFile(List<int> data) async {
    String filePath = (await getTemporaryDirectory()).path;
    File file = File('$filePath/temp.png');
    await file.writeAsBytes(data);
    return file;
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    super.dispose();
  }
}
