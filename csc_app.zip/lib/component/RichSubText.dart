import 'package:flutter/material.dart';

class RichSubText extends StatelessWidget {
  final String text;

  final TextAlign textAlign;

  final TextDirection textDirection;

  final bool softWrap;

  final double textScaleFactor;

  final TextOverflow overflow;

  final int maxLines;

  final double supSize;

  final double subSize;

  final TextStyle textStyle;

  final Locale locale;

  final StrutStyle strutStyle;

  final TextWidthBasis textWidthBasis;

  final TextHeightBehavior textHeightBehavior;

  RichSubText(
    this.text, {
    Key key,
    this.textAlign = TextAlign.start,
    this.textDirection,
    this.softWrap = true,
    this.overflow = TextOverflow.clip,
    this.textScaleFactor = 1.0,
    this.maxLines,
    this.locale,
    this.strutStyle,
    this.textWidthBasis = TextWidthBasis.parent,
    this.textHeightBehavior,
    this.textStyle,
    this.supSize = 5.0,
    this.subSize = 5.0,
  });

  @override
  Widget build(BuildContext context) {
    return RichText(
      textAlign: textAlign,
      textDirection: textDirection,
      softWrap: softWrap,
      overflow: overflow,
      textScaleFactor: textScaleFactor,
      maxLines: maxLines,
      locale: locale,
      strutStyle: strutStyle,
      textWidthBasis: textWidthBasis,
      textHeightBehavior: textHeightBehavior,
      text: TextSpan(
        children: transferText().map((e) {
          if (e["type"] == "sub") {
            return WidgetSpan(
              child: Transform.translate(
                offset: Offset(0, subSize),
                child: Text(
                  e["value"],
                  textScaleFactor: 0.7,
                  style: textStyle,
                ),
              ),
            );
          }
          if (e["type"] == "sup") {
            return WidgetSpan(
              child: Transform.translate(
                offset: Offset(0, -supSize),
                child: Text(
                  e["value"],
                  textScaleFactor: 0.7,
                  style: textStyle,
                ),
              ),
            );
          }
          return WidgetSpan(
            child: Text(e["value"], style: textStyle),
          );
        }).toList(),
      ),
    );
  }

  List<dynamic> transferText() {
    int start = 0;
    List<dynamic> list = [];
    RegExp exp = new RegExp(r"(<sub>)[0-9]*(</sub>)|(<sup>)[0-9]*(</sup>)");
    Iterable<Match> matches = exp.allMatches(this.text);
    for (Match m in matches) {
      String s = m.group(0), r, t;
      if (s.contains("sup")) {
        t = "sup";
        r = s.replaceAll("<sup>", "").replaceAll("</sup>", "");
      } else {
        t = "sub";
        r = s.replaceAll("<sub>", "").replaceAll("</sub>", "");
      }
      list.add({"start": m.start, "end": m.end, "replace": r, "type": t});
    }
    List<dynamic> rows = [];
    for (var i = 0; i < list.length; i++) {
      rows.add({
        "type": "string",
        "value": this.text.substring(start, list[i]["start"])
      });
      if (list[i]["type"] == "sub") {
        rows.add({"type": "sub", "value": list[i]["replace"]});
      } else {
        rows.add({"type": "sup", "value": list[i]["replace"]});
      }
      start = list[i]["end"];
    }
    if (start < this.text.length) {
      rows.add({"type": "string", "value": this.text.substring(start)});
    }
    return rows;
  }
}
