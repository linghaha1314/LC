import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:flutter/material.dart';

class EmptyWidget extends StatefulWidget {
  // 组件高度
  final double height;

  // 操作按钮
  final Widget child;

  // 空数据说明
  final String emptyText;

  const EmptyWidget(
      {Key key, @required this.height, @required this.child, this.emptyText})
      : super(key: key);

  @override
  State<StatefulWidget> createState() => _EmptyWidgetState();
}

class _EmptyWidgetState extends State<EmptyWidget> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          height: widget.height,
          child: emptyWidget,
        ),
        Positioned(
          top: (widget.height - 55) / 2,
          left: 0,
          right: 0,
          child: Column(
            children: [
              if (widget.emptyText != null)
                Container(
                  color: ThemeColor.getColor("info").withOpacity(0.5),
                  padding: EdgeInsets.all(10.0),
                  child: Text(widget.emptyText),
                ),
              widget.child,
            ],
          ),
        ),
      ],
    );
  }
}
