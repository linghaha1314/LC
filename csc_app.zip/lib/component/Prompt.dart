import 'package:csc_app/component/MethodComponent.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:intl/intl.dart';
import 'DialogOverlay.dart';

class Prompt extends DialogOverlay {
  var ctrl = new TextEditingController();
  var numberKey = false;
  var dateFlag = false;

  Prompt(String msg, {Object value, bool isNumber, bool isDate}) {
    this.title = msg;
    this.icon = Icons.border_color;
    this.cancelTxt = '取消';
    this.okTxt = '确认';
    this.size = Size(350, 220);
    if (isNumber != null) this.numberKey = isNumber;
    if (isDate != null) this.dateFlag = isDate;
    ctrl.text = value;
  }

  @override
  Widget buildContent(BuildContext context) {
    return Center(
      child: Container(
        padding: EdgeInsets.fromLTRB(10.0, 6.0, 10.0, 6.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (dateFlag)
              FormBuilderDateTimePicker(
                name: 'date',
                onChanged: (v) {
                  if (v == null) {
                    ctrl.text = null;
                  } else {
                    ctrl.text = v.toString();
                  }
                },
                inputType: InputType.date,
                format: DateFormat("yyyy-MM-dd"),
              )
            else
              TextField(
                controller: ctrl,
                autofocus: true,
                keyboardType:
                    numberKey ? TextInputType.number : TextInputType.text,
                onSubmitted: (v) {
                  onSave(context);
                },
              ),
          ],
        ),
      ),
    );
  }

  @override
  void onSave(_context) {
    if (ctrl.text == null || ctrl.text.toString().trim().length == 0) {
      showErrorToast("请输入或选择值");
      return;
    }
    Navigator.pop(_context, ctrl.text);
  }
}
