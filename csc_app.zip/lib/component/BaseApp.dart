import 'dart:io';

import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/utils/AssetConst.dart';
import 'package:flutter/material.dart';
import 'loading.dart';

class BaseApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    throw UnimplementedError("请重写createState方法");
  }
}

abstract class BaseAppPage<T> extends State<BaseApp> {
  bool loading = false;
  String title = "";
  bool barFlag = true;
  bool empty = true;
  dynamic routeData;

  @override
  @mustCallSuper
  Widget build(BuildContext context) {
    if (routeData == null) {
      routeData = ModalRoute.of(context).settings.arguments;
      initRouteSuccess();
    }
    return DecoratedBox(
      decoration: BoxDecoration(
        image: DecorationImage(
            image: ThemeColor.background == ""
                ? AssetImage("assets/images/main.gif")
                : FileImage(File(ThemeColor.background)),
            fit: BoxFit.cover),
      ),
      child: ProgressDialog(
        loading: loading,
        close: () {
          setState(() {
            loading = false;
          });
        },
        child: Center(
          child: getBuild(context),
        ),
      ),
    );
  }

  List<Widget> getActions(BuildContext context) {
    return <Widget>[];
  }

  Widget getTitle(BuildContext context) {
    return Text(title);
  }

  //重写build方法
  Widget getBuild(BuildContext context) {
    return new Scaffold(
      appBar: barFlag ? getAppBar(context) : null,
      body: empty ? emptyWidget : SafeArea(
        child: getBody(context)
      ),
      drawer: empty ? null : getDraw(context),
      bottomNavigationBar: empty ? null : getBottom(context),
    );
  }

  Widget getAppBar(BuildContext context) {
    return AppBar(
      title: getTitle(context),
      actions: getActions(context),
    );
  }

  Widget getBody(BuildContext context);

  Widget getDraw(BuildContext context) {
    return null;
  }

  Widget getBottom(BuildContext context) {
    return null;
  }

  onRefresh() {
    setState(() {
      loading = !loading;
    });
  }

  @override
  void initState() {
    super.initState();
  }

  initRouteSuccess() {}
}
