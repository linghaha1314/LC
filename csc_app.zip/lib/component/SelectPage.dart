import 'package:csc_app/component/RefreshList.dart';
import 'package:flutter/material.dart';
import 'package:csc_app/component/BaseApp.dart';

class SelectPage extends BaseApp {
  final String title;

  final bool multiple;

  final Function buildInfo;

  final Function buildSubTitle;

  final Function buildItem;

  final String url;

  final String idKey;

  final String labelKey;

  final String searchText;

  final List<dynamic> values;

  final Map<String, dynamic> queryParams;

  SelectPage({
    this.multiple,
    @required this.url,
    this.idKey,
    this.labelKey,
    @required this.title,
    this.queryParams,
    this.values,
    this.searchText,
    this.buildInfo,
    this.buildSubTitle,
    this.buildItem,
  });

  @override
  _SelectPageState createState() => _SelectPageState(
      multiple,
      url,
      idKey,
      labelKey,
      title,
      queryParams,
      values,
      searchText,
      buildInfo,
      buildSubTitle,
      buildItem);
}

class _SelectPageState extends BaseAppPage<SelectPage> {
  String url;

  String idKey = "id";

  String labelKey = "name";

  String _searchText = "请输入名称搜索";

  bool multiple = false;

  Map<String, dynamic> queryParams = {};

  int pageNum = 1;

  int pageSize = 20;

  Map<String, bool> _values = {};

  List<dynamic> _results = [];

  Function buildInfo;
  Function buildSubTitle;
  Function buildItem;

  _SelectPageState(multiple, url, idKey, labelKey, title, queryParams, values,
      searchText, buildInfo, buildSubTitle, buildItem) {
    empty = false;
    if (multiple != null) this.multiple = multiple;
    if (buildInfo != null) this.buildInfo = buildInfo;
    if (buildSubTitle != null) this.buildSubTitle = buildSubTitle;
    if (buildItem != null) this.buildItem = buildItem;
    if (url != null) this.url = url;
    if (idKey != null) this.idKey = idKey;
    if (labelKey != null) this.labelKey = labelKey;
    if (queryParams != null) this.queryParams = queryParams;
    if (values != null) this._results = values;
    if (searchText != null) this._searchText = searchText;
    this.title = title;
  }

  @override
  List<Widget> getActions(BuildContext context) {
    return <Widget>[
      Visibility(
        visible: multiple,
        child: IconButton(
          icon: Icon(Icons.check),
          onPressed: () {
            Navigator.pop(
              context,
              _results,
            );
          },
          tooltip: "确认",
        ),
      )
    ];
  }

  @override
  Widget getBody(BuildContext context) {
    return Column(
      children: [
        Visibility(
          visible: multiple,
          child: Card(
            margin: EdgeInsets.all(5.0),
            child: Container(
              width: MediaQuery.of(context).size.width,
              margin: EdgeInsets.all(15.0),
              child:
                  Text("已选择${_results.length}条数据", textAlign: TextAlign.center),
            ),
          ),
        ),
        Expanded(
          flex: 1,
          child: RefreshList(
            url: url,
            searchText: _searchText,
            queryParams: queryParams,
            buildItem: (dynamic row, int i) {
              return _buildRow(row);
            },
            loadSuccess: (rows) {
              if (multiple) {
                rows.forEach((r) {
                  _values[r[idKey]] = false;
                });
                _results.forEach((r) {
                  _values[r[idKey]] = true;
                });
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildRow(dynamic row) {
    if (buildItem != null) {
      return buildItem(row);
    }
    if (multiple) {
      return CheckboxListTile(
        title: Text(row[labelKey]),
        value: _values[row[idKey]],
        subtitle: buildInfo == null ? null : Text(buildInfo(row)),
        onChanged: (v) {
          if (_values[row[idKey]] == v) return;
          if (v) {
            _results.add(row);
          } else {
            for (var j = 0; j < _results.length; j++) {
              if (_results[j][idKey] == row[idKey]) {
                _results.removeAt(j);
              }
            }
          }
          setState(() {
            _values[row[idKey]] = v;
          });
        },
      );
    } else {
      return ListTile(
        title: Text(row[labelKey]),
        trailing: buildInfo == null ? null : Text(buildInfo(row)),
        subtitle: buildSubTitle == null ? null : Text(buildSubTitle(row)),
        onTap: () {
          row[idKey] = row[idKey];
          row[labelKey] = row[labelKey];
          Navigator.pop(context, row);
        },
      );
    }
  }
}
