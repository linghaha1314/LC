import 'dart:convert';
import 'dart:io';

import 'package:amap_location_fluttify/amap_location_fluttify.dart';
import 'package:csc_app/ThemeColor.dart';
import 'package:csc_app/component/Alert.dart';
import 'package:csc_app/component/Confirm.dart';
import 'package:csc_app/component/Prompt.dart';
import 'package:csc_app/pojo/Notify.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:dio/dio.dart';
import 'package:ext_storage/ext_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:jpush_flutter/jpush_flutter.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info/device_info.dart';
import 'LoadingProgress.dart';

BuildContext globalContent;

Future<dynamic> showAlert(
    {String title = "提示", @required String msg, IconData icon = Icons.info}) {
  return Navigator.of(globalContent).push(Alert(msg, title, icon));
}

Future<dynamic> showErrorAlert(String msg) {
  return showAlert(msg: msg, icon: Icons.error, title: "错误提示");
}

Future<dynamic> showSuccessAlert(String msg) {
  return showAlert(msg: msg, icon: Icons.check, title: "成功提示");
}

Future<dynamic> showWarnAlert(String msg) {
  return showAlert(msg: msg, icon: Icons.warning, title: "警告提示");
}

Future<dynamic> showConfirmAlert(String msg,
    {String ok = "确认",
    String cancel = "取消",
    String title = "提示",
    width = 300.0,
    height = 200.0}) {
  return Navigator.of(globalContent).push(Confirm(msg,
      okText: ok,
      cancelText: cancel,
      title: title,
      width: width,
      height: height));
}

Future<dynamic> showPromptAlert(String msg,
    {String value, bool isNumber, bool isDate}) {
  return Navigator.of(globalContent)
      .push(Prompt(msg, value: value, isNumber: isNumber, isDate: isDate));
}

FToast _toast;

_baseToast({String msg, IconData icon = Icons.check, Color color}) {
  Widget toast = Container(
    padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(25.0),
      color: color ?? ThemeColor.getColor("data"),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon),
        SizedBox(
          width: 12.0,
        ),
        Flexible(
          child: Text(
            msg,
            overflow: TextOverflow.ellipsis,
            maxLines: 100,
            softWrap: true,
          ),
        ),
      ],
    ),
  );
  if (_toast == null) {
    initToastContent(globalContent);
  }

  _toast.showToast(
    child: toast,
    gravity: ToastGravity.CENTER,
    toastDuration: Duration(seconds: 3),
  );
}

initToastContent(BuildContext context) {
  globalContent = context;
  _toast = FToast();
  _toast.init(context);
}

showInfoToast(String msg) {
  _baseToast(msg: msg, icon: Icons.info, color: ThemeColor.getColor("info"));
}

showErrorToast(String msg) {
  _baseToast(msg: msg, icon: Icons.error, color: ThemeColor.getColor("danger"));
}

showSuccessToast(String msg) {
  _baseToast(msg: msg, color: ThemeColor.getColor("success"));
}

showWarnToast(String msg) {
  _baseToast(
      msg: msg, icon: Icons.warning, color: ThemeColor.getColor("warning"));
}

FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin;

initNotify(BuildContext context) async {
  if (_flutterLocalNotificationsPlugin != null) return;
  _flutterLocalNotificationsPlugin = new FlutterLocalNotificationsPlugin();
  var android = new AndroidInitializationSettings('@mipmap/ic_launcher');
  var iOS = new IOSInitializationSettings();
  var initSettings = new InitializationSettings(android: android, iOS: iOS);
  await _flutterLocalNotificationsPlugin.initialize(initSettings,
      onSelectNotification: (String payload) {
    if (payload != null) {
      var data = jsonDecode(payload);
      Navigator.pushNamed(context, data["route"],
          arguments: jsonDecode(data["data"]));
    }
    return Future.value(true);
  });
}

showNotification(String title, String msg, {Notify payload}) {
  var android = new AndroidNotificationDetails(
      'default', 'notification', '临床技能中心app通知',
      priority: Priority.high, importance: Importance.max, ticker: 'ticker');
  var iOS = new IOSNotificationDetails();
  var platform = new NotificationDetails(android: android, iOS: iOS);
  _flutterLocalNotificationsPlugin.show(0, title, msg, platform,
      payload: payload == null ? null : payload.toJsonString());
}

final JPush _jpush = new JPush();

Future<String> initNotifyServerPush(BuildContext context) async {
  try {
    _jpush.addEventHandler(
      onReceiveNotification: (Map<String, dynamic> message) async {
        messagePageState?.refresh();
        print("onReceiveNotification $message");
      },
      onOpenNotification: (Map<String, dynamic> message) async {
        print("onOpenNotification $message");
        var notify = Notify.fromMap(
            jsonDecode(message["extras"]["cn.jpush.android.EXTRA"]));
        // 刷新消息
        if (notify.route == 'messageRefresh') {
          messagePageState?.refresh();
          dynamic d = jsonDecode(notify.data);
          Navigator.pushNamed(context, "todoTask", arguments: {
            "title": d['type'] == 'LabelFlow' ? '流程' : '借用',
            "senderId": d["type"]
          });
        } else {
          Navigator.pushNamed(context, notify.route, arguments: notify.data);
        }
      },
      onReceiveMessage: (Map<String, dynamic> message) async {
        print("onReceiveMessage $message");
        var notify = Notify.fromMap(
            jsonDecode(message["extras"]["cn.jpush.android.EXTRA"]));
        showNotification("新消息", message["message"], payload: notify);
      },
      onReceiveNotificationAuthorization: (Map<String, dynamic> message) async {
        print("onReceiveNotificationAuthorization $message");
      },
    );
  } on PlatformException {
    print('Failed to get platform version.');
  }
  _jpush.setup(
    appKey: "11f5a21b97aab38134ce0690", //你自己应用的 AppKey
    channel: "theChannel",
    production: true,
    debug: true,
  );
  _jpush.applyPushAuthority(
      new NotificationSettingsIOS(sound: true, alert: true, badge: true));
  // Platform messages may fail, so we use a try/catch PlatformException.
  return await _jpush.getRegistrationID();
}

clearNotifyNumber() {
  if (_jpush != null) {
    _jpush.setBadge(0);
  }
}

// 获取当前设备名称
Future<String> getDeviceName() async {
  if (kIsWeb == true) {
    return Future.value("网页");
  }
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  String client = "其它设备";
  if (Platform.isAndroid) {
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
    client = androidInfo.device;
  }
  if (Platform.isIOS) {
    IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
    client = iosInfo.name;
  }
  return Future.value(client);
}

Future<dynamic> uploadFile(
    {FileType type = FileType.image,
    String file,
    String title = "文件上传中",
    bool loading = true}) async {
  String value;
  if (file == null) {
    FilePickerResult result = await FilePicker.platform.pickFiles(type: type);
    if (result != null) {
      value = result.files.single.path;
    }
    if (value == null) return null;
  } else {
    value = file;
  }
  if (loading) {
    showProgressLoading(0.0, title: title);
  }
  return post("/file/upload", {"files": await MultipartFile.fromFile(value)},
      form: true, onSendProgress: (int progress, int total) {
    if (loading) {
      showProgressLoading(
        (((progress / total) * 100).roundToDouble()) / 100,
        title: title,
      );
    }
  }).then((res) {
    if (res["success"]) {
      return Future.value(res["filePath"]);
    }
    return Future.value(null);
  }).catchError((err) {
    if (loading) {
      showProgressLoading(1.0, close: true);
    }
    showErrorToast(err["msg"]);
    return Future.value(null);
  });
}

Future<String> downloadFile(String url, String fileName,
    {String title = "文件下载中"}) async {
  var storeFlag = await requestPermission(info: "手机存储");
  if (!storeFlag) {
    showErrorToast("未开启储存权限,无法下载文件!");
    return Future.value(null);
  }
  String downloadPath;
  if (Platform.isAndroid) {
    downloadPath = await ExtStorage.getExternalStoragePublicDirectory(
        ExtStorage.DIRECTORY_DOWNLOADS);
  } else {
    Directory applicationDir = await getApplicationDocumentsDirectory();
    bool isDirExist = await Directory(applicationDir.path).exists();
    if (!isDirExist) Directory(applicationDir.path).create();
    downloadPath = applicationDir.path;
  }
  var f = File(downloadPath + "/$fileName");
  var flag = await f.exists();
  if (flag) {
    var x = fileName.substring(0, fileName.lastIndexOf("."));
    var index = 1;
    //文件已存在增加文件序号
    while (flag) {
      fileName =
          "$x(${index.toString()})${fileName.substring(fileName.lastIndexOf("."))}";
      f = File(downloadPath + "/$fileName");
      flag = await f.exists();
      index++;
    }
  }
  var dio = await getDio(time: false);
  showProgressLoading(0.0, title: title);
  return dio.download(url, downloadPath + "/$fileName",
      options: Options(headers: {"Authorization": "Bearer ${getAuth()}"}),
      onReceiveProgress: (int progress, int total) {
    if (total != -1) {
      showProgressLoading((((progress / total) * 100).roundToDouble()) / 100,
          title: title, total: total, progress: progress);
    }
  }).then((res) {
    showProgressLoading(100.0, close: true);
    var file = downloadPath + "/$fileName";
    showConfirmAlert(
            "文件$fileName下载成功${Platform.isAndroid ? "(位于download下)" : "(位于文档下)"},是否打开?",
            ok: "是",
            cancel: "否")
        .then((value) {
      if (value) {
        OpenFile.open(file).then((r) {
          if (r.type == ResultType.noAppToOpen) {
            showErrorToast("文件$fileName无法打开,请于文件管理器中下载目录中查看");
          }
        });
      }
    });
    return Future.value(file);
  }).catchError((err) {
    showErrorToast("文件下载失败,请稍后重试!");
    showProgressLoading(1.0, close: true);
    if (err is FileSystemException) {
      showErrorAlert("请将app存储权限设置为始终允许,如果为已允许就先拒绝再切换成允许所有即可").then((value) {
        openAppSettings();
      });
      return Future.value(null);
    } else {
      showErrorToast(err["msg"]);
      return Future.value(null);
    }
  });
}

Future<bool> requestPermission(
    {Permission permission = Permission.storage, info = "对应"}) async {
  var status = await permission.status;
  if (!status.isGranted) {
    await permission.request();
  }
  if (await permission.isPermanentlyDenied) {
    showConfirmAlert("请在设置中开启$info权限").then((value) {
      if (value) {
        openAppSettings();
      }
    });
  }
  return await permission.isGranted;
}

// 获取当前位置信息
Future<dynamic> getLocation() async {
  var isGranted =
      await requestPermission(permission: Permission.location, info: "定位");
  if (isGranted) {
    AmapLocation.instance.updatePrivacyShow(true);
    AmapLocation.instance.updatePrivacyAgree(true);
    await AmapLocation.instance
        .init(iosKey: '8936930c27cd6edd6df0a074bd119b51');
    var location =
        await AmapLocation.instance.fetchLocation(mode: LocationAccuracy.High);
    if (location.address.trim().length == 0) {
      showErrorToast("请在手机设置中开启位置信息!");
      return Future.value(null);
    }
    return {
      "address": location.address,
      "longitude": location.latLng.longitude,
      "latitude": location.latLng.latitude
    };
  } else {
    showErrorToast("请在手机设置中开启位置权限!");
    return Future.value(null);
  }
}

// 拍摄一张照片
Future<String> takePicture() async {
  var isGranted =
      await requestPermission(permission: Permission.camera, info: "相机");
  if (isGranted) {
    ImagePicker _picker = ImagePicker();
    final pickedFile = await _picker.getImage(source: ImageSource.camera);
    if (pickedFile == null) return Future.value(null);
    return Future.value(pickedFile.path);
  }
  return Future.value(null);
}

showDictionaryData(Function result, {String url, List<dynamic> list}) async {
  List<dynamic> data = [];
  if (url != null) {
    showLoading(title: '加载中...');
    var res = await post(url, {});
    showLoading(close: true);
    data = res["rows"];
  } else {
    data = list;
  }
  showBarModalBottomSheet(
    context: globalContent,
    builder: (context) => Material(
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: data.map((e) {
            return ListTile(
              title: Text("${e["name"]}"),
              leading: Icon(
                Icons.api,
                color: ThemeColor.getColor("fontColor"),
              ),
              onTap: () {
                Navigator.pop(context);
                result(e);
              },
            );
          }).toList(),
        ),
      ),
    ),
  );
}
