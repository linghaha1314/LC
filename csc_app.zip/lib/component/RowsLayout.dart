import 'package:flutter/material.dart';

/// 按照宽度或col设置布局如: RowsLayout(width: 160, list: list), RowsLayout(col: 3, list: list)
class RowsLayout extends StatefulWidget {
  final double width;
  final int col;
  final List<Widget> list;

  const RowsLayout({Key key, this.width, this.col, @required this.list})
      : super(key: key);

  @override
  State<StatefulWidget> createState() => RowsLayoutPage(width, col, list);
}

class RowsLayoutPage extends State<RowsLayout> {
  List<Widget> list = [];
  int _col;
  double _width;

  RowsLayoutPage(width, col, list) {
    if (col != null) this._col = col;
    if (width != null) this._width = width;
    this.list = list;
  }

  _initCol() {
    _col = 3;
    if (_width != null) {
      var w = MediaQuery.of(context).size.width;
      _col = (w / _width).round();
    }
  }

  @override
  Widget build(BuildContext context) {
    _initCol();
    List<TableRow> rows = [];
    int r = (list.length / _col).ceil();
    for (var i = 0; i < r; i++) {
      rows.add(new TableRow(
        children: _buildRows(i),
      ));
    }
    return Table(
      children: rows,
    );
  }

  _buildRows(int row) {
    List<Widget> rows = [];
    for (var i = 0; i < _col; i++) {
      int index = row * _col + i;
      if (index < list.length) {
        rows.add(list[index]);
      } else {
        rows.add(Card());
      }
    }
    return rows;
  }
}
