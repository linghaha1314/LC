import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flare_flutter/flare_actor.dart';
import 'package:flare_flutter/provider/asset_flare.dart';

final _loadingAsset =
    AssetFlare(bundle: rootBundle, name: "assets/flare/Loading.flr");
final _emptyAsset =
    AssetFlare(bundle: rootBundle, name: "assets/flare/empty_data.flr");
final _knight =
AssetFlare(bundle: rootBundle, name: "assets/flare/knight.riv");

final loadingWidget = FlareActor.asset(
  _loadingAsset,
  alignment: Alignment.center,
  fit: BoxFit.contain,
  animation: "Alarm",
);

final emptyWidget = FlareActor.asset(
  _emptyAsset,
  alignment: Alignment.center,
  fit: BoxFit.contain,
  animation: "empty",
);

final knightWidget = FlareActor.asset(
  _knight,
  alignment: Alignment.center,
  fit: BoxFit.contain,
);