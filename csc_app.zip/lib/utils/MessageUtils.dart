import 'dart:async';
import 'dart:convert';

import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/page/ContactPersonPage.dart';
import 'package:csc_app/page/HomePage.dart';
import 'package:csc_app/page/MinePage.dart';
import 'package:csc_app/page/WorkbenchPage.dart';
import 'package:csc_app/page/base/ChatDetailPage.dart';
import 'package:csc_app/page/MessagePage.dart';
import 'package:csc_app/pojo/Notify.dart';
import 'package:csc_app/utils/Help.dart';
import 'package:date_format/date_format.dart';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/io.dart';
import 'package:web_socket_channel/status.dart' as status;

IOWebSocketChannel _socket;

Map<String, List<dynamic>> messageData = {};

ChatDetailPageState chatDetailPageState;

MessagePageState messagePageState;

WorkbenchPageState workbenchPageState;

ContactPersonPageState contactPersonPageState;

MinePageState minePageState;

HomePage homePage;

// 程序是否在后台
bool backgroundRun;

Timer _timer;
// 初始化连接socket
_connectServer() async {
  var path = await getHttpPath();
  var url = "ws${path.replaceFirst("https", "").replaceFirst("http", "")}/chat";
  _socket = IOWebSocketChannel.connect(url,
      headers: {"Authorization": "Bearer ${getAuth()}"});
  _socket.stream.listen((message) {
    print(message);
    var data = jsonDecode(message);
    // 单人聊天接收消息
    if (data["type"] == 'singleChat') {
      if (messageData[data["senderId"]] == null) {
        messageData[data["senderId"]] = [];
      }
      messageData[data["senderId"]].add(data);
      if (chatDetailPageState != null) {
        chatDetailPageState.refreshMessage();
      }
      if (messagePageState != null) {
        messagePageState.addMessageTotal(data);
      }
      if (homePage != null) {
        homePage.addUnreadTotal();
      }
      if (backgroundRun == true ||
          chatDetailPageState == null ||
          (chatDetailPageState != null &&
              chatDetailPageState.routeData["senderId"] != data["senderId"])) {
        var row =
            messagePageState.list[messagePageState.userIndex[data["senderId"]]];
        showNotification(data["senderName"], data["content"],
            payload: Notify("chatDetailPage", jsonEncode(row)));
      }
    } else if (data["type"] == "connected") {
      _timer?.cancel();
      messagePageState?.changeConnect(false);
      homePage?.changeConnect(false);
    }
  }, onDone: () {
    startConnectSocket();
  }, onError: (err) {
    startConnectSocket();
  });
}

startConnectSocket() {
  _socket = null;
  messagePageState?.changeConnect(true);
  homePage?.changeConnect(true);
  _timer?.cancel();
  _timer = Timer.periodic(Duration(seconds: 2), (timer) {
    if (!kIsWeb) {
      _connectServer();
    }
  });
}

// 获取socket
Future<IOWebSocketChannel> getSocket() async {
  if (_socket == null && !kIsWeb) {
    await _connectServer();
  }
  return _socket;
}

// 关闭socket
closeSocket() {
  if (_socket != null) {
    _socket.sink.close(status.goingAway);
    _socket = null;
  }
}

var _intToDay = {1: "一", 2: "二", 3: "三", 4: "四", 5: "五", 6: "六", 7: "天"};

String buildMessageTime(int time) {
  if (time == 0) return '无';
  var date = DateTime.fromMillisecondsSinceEpoch(time);
  var now = DateTime.now();
  if (formatDate(date, [yyyy, "-", mm, "-", dd]) ==
      formatDate(now, [yyyy, "-", mm, "-", dd])) {
    return formatDate(date, [HH, ":", nn]);
  }
  if (formatDate(date, [yyyy, "-", mm, "-", dd]) ==
      formatDate(
          now.subtract(new Duration(days: 1)), [yyyy, "-", mm, "-", dd])) {
    return "昨天 " + formatDate(date, [HH, ":", nn]);
  }
  if (date.millisecondsSinceEpoch >
      now.subtract(Duration(days: now.weekday)).millisecondsSinceEpoch) {
    return "星期${_intToDay[date.weekday]} " + formatDate(date, [HH, ":", nn]);
  }
  return formatDate(date, [yyyy, "-", mm, "-", dd, " ", HH, ":", nn]);
}
