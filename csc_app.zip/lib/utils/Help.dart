import 'dart:convert';
import 'dart:io';

import 'package:csc_app/component/MethodComponent.dart';
import 'package:csc_app/pojo/Config.dart';
import 'package:csc_app/pojo/UserInfo.dart';
import 'package:csc_app/service/ConfigService.dart';
import 'package:csc_app/utils/MessageUtils.dart';
import 'package:date_format/date_format.dart';
import 'package:dio/dio.dart';
import 'package:disable_screenshots/disable_screenshots.dart';
import 'package:ext_storage/ext_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:ota_update/ota_update.dart';
import 'package:package_info/package_info.dart';
import 'package:url_launcher/url_launcher.dart';
import '../ThemeColor.dart';

String _auth;

UserInfo _userInfo;

Dio _dio;

Future<Dio> getDio({time = true}) async {
  if (_dio == null) {
    var path = await getHttpPath();
    _dio = new Dio(BaseOptions(
      baseUrl: path,
      connectTimeout: time ? Duration(seconds: 5) : null,
      receiveTimeout: time ? Duration(seconds: 5) : null,
    ));
  }
  if (time == false) {
    var path = await getHttpPath();
    _dio = new Dio(BaseOptions(
      baseUrl: path,
      connectTimeout: null,
      receiveTimeout: null,
    ));
  }
  return Future.value(_dio);
}

Future<dynamic> post(String url, dynamic data,
    {Options options,
    form = false,
    ProgressCallback onSendProgress,
    ProgressCallback onReceiveProgress}) async {
  if (options == null) options = Options();
  var userInfo = await getCurrentAccount();
  if (userInfo != null) {
    if (options.headers == null) {
      options.headers = {};
    }
    options.headers["Authorization"] = "Bearer $_auth";
    options.headers["hospitalId"] = userInfo.accounts["hospitalId"];
  }
  try {
    var dio = await getDio();
    dynamic _data = data;
    if (form) _data = FormData.fromMap(data);
    var response = await dio.post(url,
        data: _data,
        options: options,
        onSendProgress: onSendProgress,
        onReceiveProgress: onReceiveProgress);
    return response.data;
  } on DioError catch (e) {
    if (e.response != null) {
      if (e.response.statusCode == 302) {
        throw ({"msg": "未登录"});
      } else if (e.response.data is String) {
        throw jsonDecode(e.response.data as String);
      }
      throw ({"msg": e.response.data['msg']});
    } else {
      print(e);
      throw ({"msg": "连接超时!"});
    }
  }
}

Future<dynamic> postNoAuth(String url, dynamic data, {Options options}) async {
  if (options == null) options = Options();
  try {
    var dio = await getDio();
    var response = await dio.post(url, data: data, options: options);
    return response.data;
  } on DioError catch (e) {
    if (e.response != null) {
      if (e.response.data is String) {
        throw jsonDecode(e.response.data as String);
      }
      throw ({"msg": e.response.data['msg']});
    } else {
      throw ({"msg": "连接超时!"});
    }
  }
}

Future<dynamic> get(String url, {Options options}) async {
  if (options == null) options = Options();
  var userInfo = await getCurrentAccount();
  if (userInfo != null) {
    if (options.headers == null) {
      options.headers = {};
    }
    options.headers["Authorization"] = "Bearer $_auth";
    options.headers["hospitalId"] = userInfo.accounts["hospitalId"];
  }
  try {
    var dio = await getDio();
    var response = await dio.get(url, options: options);
    return response.data;
  } on DioError catch (e) {
    if (e.response != null) {
      if (e.response.statusCode == 302) {
        throw ({"msg": "未登录"});
      } else if (e.response.data is String) {
        throw jsonDecode(e.response.data as String);
      }
      throw ({"msg": e.response.data['msg']});
    } else {
      throw ({"msg": "连接超时!"});
    }
  }
}

Future<dynamic> getNoAuth(String url, {Options options}) async {
  if (options == null) options = Options();
  try {
    var dio = await getDio();
    var response = await dio.get(url, options: options);
    return response.data;
  } on DioError catch (e) {
    if (e.response != null) {
      if (e.response.data is String) {
        throw jsonDecode(e.response.data as String);
      }
      throw ({"msg": e.response.data['msg']});
    } else {
      throw ({"msg": "连接超时!"});
    }
  }
}

Future<UserInfo> getCurrentAccount() async {
  if (_userInfo == null) {
    ConfigService _configService = ConfigService();
    _auth = await _configService.getConfig("auth");
    var _user = await _configService.getConfig("userInfo");
    dynamic res;
    if (_user != null) {
      res = jsonDecode(_user);
    } else {
      res = await getNoAuth("/accounts/getCurrentAccounts",
          options: Options(headers: {"Authorization": "Bearer $_auth"}));
    }
    if (res is String) {
      return null;
    }
    var userInfo = new UserInfo();
    userInfo.accounts = res["accounts"];
    userInfo.role = res["role"];
    userInfo.roles = res["roles"];
    userInfo.staff = res["staff"];
    _userInfo = userInfo;
  }
  return Future.value(_userInfo);
}

Future<bool> judgmentLogin() async {
  ConfigService _configService = ConfigService();
  _auth = await _configService.getConfig("auth");
  var res = await getNoAuth("/accounts/getCurrentAccounts",
      options: Options(headers: {"Authorization": "Bearer $_auth"}));
  if (res is String) {
    return Future.value(false);
  }
  var userInfo = new UserInfo();
  userInfo.accounts = res["accounts"];
  userInfo.role = res["role"];
  userInfo.roles = res["roles"];
  userInfo.staff = res["staff"];
  _userInfo = userInfo;
  return Future.value(true);
}

Future<UserInfo> refreshUserInfo() async {
  _userInfo = null;
  return getCurrentAccount();
}

setAuth(String auth) {
  _auth = auth;
}

String getAuth() {
  return _auth;
}

String _baseUrl;

// 获取服务器路径
Future<String> getHttpPath({refresh = false}) async {
  if (refresh) {
    _dio = null;
    _baseUrl = null;
    closeSocket();
  }
  if (_baseUrl == null) {
    ConfigService _configService = ConfigService();
    String _url = await _configService.getConfig("baseUrl");
    if (_url == null) {
      _baseUrl = "http://simulationcenter.wchscu.cn/gl";
      await _configService.update(Config("baseUrl", _baseUrl));
    } else {
      _baseUrl = _url;
    }
  }
  return Future.value(_baseUrl);
}

String showString(dynamic d) {
  if (d == null)
    return "无";
  else
    return d.toString();
}

// 检查更新
checkUpdate({flag = false}) async {
  if (Platform.isAndroid) {
    get('http://gitlab.kbmrt.cn/root/config-data/raw/master/%E4%B8%B4%E5%BA%8AApp%E9%85%8D%E7%BD%AE.json')
        .then((res) async {
      var config = jsonDecode(res);
      String version = config['version'];
      var info = await PackageInfo.fromPlatform();
      if (version == info.version) {
        if (flag) {
          showInfoToast("当前已是最新版本!");
        }
        return;
      }
      showConfirmAlert("检测到新版本是否更新").then((res) {
        if (res) {
          showInfoToast("下载中...");
          ExtStorage.getExternalStoragePublicDirectory(
                  ExtStorage.DIRECTORY_DOWNLOADS)
              .then((v) {
            requestPermission().then((value) {
              if (value) {
                OtaUpdate().execute(
                  config['file'],
                  destinationFilename: '华创医学模拟中心智慧管理平台.apk',
                  sha256checksum: config['sha256checksum'],
                );
              }
            });
          });
        }
      });
    });
  }
  if (Platform.isIOS) {
    var info = await PackageInfo.fromPlatform();
    var dio = new Dio();
    var response =
        await dio.get("https://itunes.apple.com/cn/lookup?id=1558396907");
    String version = jsonDecode(response.data)["results"][0]["version"];
    if (version == info.version) {
      if (flag) {
        showInfoToast("当前已是最新版本!");
      }
    } else {
      showConfirmAlert("检测到新版本是否更新").then((value) {
        if (value) {
          _launchUrl(
              "https://apps.apple.com/cn/app/%E5%8D%8E%E5%88%9B%E5%8C%BB%E5%AD%A6%E6%A8%A1%E6%8B%9F%E4%B8%AD%E5%BF%83%E6%99%BA%E6%85%A7%E7%AE%A1%E7%90%86%E5%B9%B3%E5%8F%B0/id1558396907");
        }
      });
    }
  }
}

_launchUrl(String path) async {
  var p = Uri.parse(path);
  if (await canLaunchUrl(p)) {
    await launchUrl(p);
  } else {
    throw 'Could not launch $path';
  }
}

// 初始化插件
DisableScreenshots _plugin = DisableScreenshots();

//初始化水印
initWatermark() {
  if (_userInfo != null && !kIsWeb) {
    _plugin.removeWatermark();
    _plugin.addWatermark(globalContent,
        "${_userInfo.staff["name"]} ${_userInfo.staff["serialNo"]}",
        rowCount: 2,
        columnCount: 4,
        textStyle: TextStyle(
          color: ThemeColor.getColor("fontColor").withOpacity(0.08),
          fontSize: 13.0,
          decoration: TextDecoration.none,
        ));
  }
}

// 获取一周的时间
getWeekDate(DateTime time) {
  var l = time.weekday;
  var start = time.subtract(new Duration(days: l - 1));
  var rows = [];
  for (var i = 0; i < 7; i++) {
    rows.add(
        formatDate(start.add(new Duration(days: i)), [yyyy, "-", mm, "-", dd]));
  }
  return rows;
}

String replaceHtml(String html, String url) {
  return html.replaceAll("src=\"/", "src=\"$url/").replaceAll("src='/", "src='$url/").replaceAll("href=\"/", "href=\"$url/").replaceAll("href='/", "href='$url/");
}