import 'package:flutter/foundation.dart';

import './component/dynamic_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_statusbarcolor/flutter_statusbarcolor.dart';
import './component/HexColor.dart';

class ThemeColor {
  static var themeIndex = 3;
  static var background = "";
  static var opacity = 100.0;
  static var colors = [
    {
      "theme": "light",
      "title": "默认主题",
      "color": HexColor('#F5F5F5'),
      "fontColor": HexColor('#333'),
      "barFontColor": HexColor('#191919'),
      "appbar": HexColor('##64C496'),
      "toolbar": HexColor('#FEF8EC'),
      "data": HexColor('#F8EFDD'),
      "console": HexColor('#F6EBD5'),
      "content": HexColor('#FFFFFF'),
      "split": HexColor('#F0E3C2'),
      "active": HexColor('#FDF6E3'),
      "progress": HexColor('#0099AD'),
      "border": HexColor('#3e2723'),
      "menu": HexColor('##64C496'),
      "focus": HexColor('#64C496'),
      "danger": HexColor('#F8D7DA'),
      "success": HexColor('#D4EDDA'),
      "warning": HexColor('#FFF3CD'),
      "info": HexColor('#D1ECF1'),
    },
    {
      "theme": "light",
      "title": "叶绿色",
      "color": HexColor('#F2F1F6'),
      "fontColor": HexColor('#333'),
      "barFontColor": HexColor('#ffffff'),
      "appbar": HexColor('#109D58'),
      "toolbar": HexColor('#E4E6EB'),
      "data": HexColor('#EEF0F4'),
      "console": HexColor('#EEF0F4'),
      "content": HexColor('#ffffff'),
      "split": HexColor('#BEC5CD'),
      "active": HexColor('#C3C6C9'),
      "progress": HexColor('#85C5D5'),
      "border": HexColor('#282828'),
      "menu": HexColor('#DCDCDC'),
      "focus": HexColor('#109D58'),
      "danger": HexColor('#F8D7DA'),
      "success": HexColor('#D4EDDA'),
      "warning": HexColor('#FFF3CD'),
      "info": HexColor('#D1ECF1'),
    },
    {
      "theme": "light",
      "title": "淡黄色",
      "color": HexColor('#F5F5F5'),
      "fontColor": HexColor('#333'),
      "barFontColor": HexColor('#191919'),
      "appbar": HexColor('#F9DF71'),
      "toolbar": HexColor('#FEF8EC'),
      "data": HexColor('#F8EFDD'),
      "console": HexColor('#F6EBD5'),
      "content": HexColor('#FFFFFF'),
      "split": HexColor('#F0E3C2'),
      "active": HexColor('#FDF6E3'),
      "progress": HexColor('#0099AD'),
      "border": HexColor('#3e2723'),
      "menu": HexColor('#F9DF71'),
      "focus": HexColor('#FFC107'),
      "danger": HexColor('#F8D7DA'),
      "success": HexColor('#D4EDDA'),
      "warning": HexColor('#FFF3CD'),
      "info": HexColor('#D1ECF1'),
    },
    {
      "theme": "light",
      "title": "叶青绿",
      "color": HexColor('#EBF8F3'),
      "fontColor": HexColor('#008847'),
      "barFontColor": HexColor('#008847'),
      "appbar": HexColor('#d6e4e4'),
      "toolbar": HexColor('#E4E6EB'),
      "data": HexColor('#EEF0F4'),
      "console": HexColor('#EEF0F4'),
      "content": HexColor('#FFFFFF'),
      "split": HexColor('#BEC5CD'),
      "active": HexColor('#c1c7c0'),
      "progress": HexColor('#85C5D5'),
      "border": HexColor('#008847'),
      "menu": HexColor('#DCDCDC'),
      "focus": HexColor('#079117'),
      "danger": HexColor('#F8D7DA'),
      "success": HexColor('#D4EDDA'),
      "warning": HexColor('#FFF3CD'),
      "info": HexColor('#D1ECF1'),
    },
    {
      "theme": "dark",
      "title": "暗夜紫",
      "color": HexColor('#2C2C3B'),
      "fontColor": HexColor('#E4E6EB'),
      "barFontColor": HexColor('#E4E6EB'),
      "appbar": HexColor('#3C3C3C'),
      "toolbar": HexColor('#333333'),
      "data": HexColor('#2C2C3B'),
      "console": HexColor('#2C2C3B'),
      "content": HexColor('#262627'),
      "split": HexColor('#5D5D65'),
      "active": HexColor('#1E1E24'),
      "progress": HexColor('#533473'),
      "border": HexColor('#eceff1'),
      "menu": HexColor('#252526'),
      "focus": HexColor('#b388ff'),
      "danger": HexColor('#d84315'),
      "success": HexColor('#6200ea'),
      "warning": HexColor('#ba68c8'),
      "info": HexColor('#9575cd'),
    },
    {
      "theme": "dark",
      "title": "深夜黄",
      "color": HexColor('#343746'),
      "fontColor": HexColor('#E4E6EB'),
      "barFontColor": HexColor('#E4E6EB'),
      "appbar": HexColor('#262626'),
      "toolbar": HexColor('#191A21'),
      "data": HexColor('#262626'),
      "console": HexColor('#282A36'),
      "content": HexColor('#282A36'),
      "split": HexColor('#2c2c3b'),
      "active": HexColor('#3C3D50'),
      "progress": HexColor('#BF9EEE'),
      "border": HexColor('#eceff1'),
      "menu": HexColor('#191A21'),
      "focus": HexColor('#ffd180'),
      "danger": HexColor('#d84315'),
      "success": HexColor('#2962ff'),
      "warning": HexColor('#ba68c8'),
      "info": HexColor('#2196f3'),
    },
    {
      "theme": "dark",
      "title": "黑夜蓝",
      "color": HexColor('#000000'),
      "fontColor": HexColor('#E4E6EB'),
      "barFontColor": HexColor('#E4E6EB'),
      "appbar": HexColor('#000000'),
      "toolbar": HexColor('#000000'),
      "data": HexColor('#000000'),
      "console": HexColor('#000000'),
      "content": HexColor('#000000'),
      "split": HexColor('#2c2c3b'),
      "active": HexColor('#3794ff'),
      "progress": HexColor('#BF9EEE'),
      "border": HexColor('#eceff1'),
      "menu": HexColor('#191A21'),
      "focus": HexColor('#3794ff'),
      "danger": HexColor('#d84315'),
      "success": HexColor('#2962ff'),
      "warning": HexColor('#ba68c8'),
      "info": HexColor('#2196f3'),
    },
  ];

  static var _colorKey = {
    "默认主题": 0,
    "叶绿色": 1,
    "淡黄色": 2,
    "叶青绿": 3,
    "暗夜紫": 4,
    "深夜黄": 5,
    "黑夜蓝": 6,
  };

  static String getBaseTheme() {
    return (colors[ThemeColor.themeIndex]["theme"] as String);
  }

  static String getThemeTitle() {
    return (colors[ThemeColor.themeIndex]["title"] as String);
  }

  static Color getColor(String k, {bool opacity = true}) {
    if (k == "fontColor" ||
        k == "barFontColor" ||
        k == "focus" ||
        opacity == false)
      return (colors[ThemeColor.themeIndex][k] as Color).withOpacity(1);
    return (colors[ThemeColor.themeIndex][k] as Color)
        .withOpacity(ThemeColor.opacity / 100);
  }

  static setColor(String k, Color color) {
    colors[ThemeColor.themeIndex][k] =
        color.withOpacity(ThemeColor.opacity / 100);
  }

  static getColorByName(String name, String title) {
    return (colors[_colorKey[name]][title] as Color)
        .withOpacity(ThemeColor.opacity / 100);
  }

  static getTheme(String theme) {
    return {
      "index": _colorKey[theme],
      "theme": colors[_colorKey[theme]]['theme']
    };
  }

  static changeTheme(BuildContext context) {
    try {
      DynamicTheme.of(context).setBrightness(
          colors[ThemeColor.themeIndex]['theme'] == "dark"
              ? Brightness.dark
              : Brightness.light);
      initStatusBar();
    } catch (e) {}
  }

  static initStatusBar() {
    if (kIsWeb == true) {
      return;
    }
    FlutterStatusbarcolor.setStatusBarColor(Colors.transparent);
    if (getBaseTheme() == 'dark') {
      FlutterStatusbarcolor.setStatusBarWhiteForeground(true);
      FlutterStatusbarcolor.setNavigationBarWhiteForeground(false);
    } else {
      FlutterStatusbarcolor.setStatusBarWhiteForeground(false);
      FlutterStatusbarcolor.setNavigationBarWhiteForeground(true);
    }
  }
}
