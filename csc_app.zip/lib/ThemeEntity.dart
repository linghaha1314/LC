import 'package:flutter/material.dart';

class ThemeEntity {
  const ThemeEntity({this.title, this.icon, this.id});

  final String title;
  final IconData icon;
  final int id;
}