import 'package:csc_app/pojo/Config.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConfigService {
  SharedPreferences _db;

  Future<SharedPreferences> getDB() async {
    if (_db == null) {
      _db = await SharedPreferences.getInstance();
    }
    return _db;
  }

  Future<Config> update(Config config) async {
    SharedPreferences db = await getDB();
    db.setString(config.id, config.value);
    return config;
  }

  Future<bool> delete(String id) async {
    SharedPreferences db = await getDB();
    return await db.remove(id);
  }

  Future<String> getConfig(String id) async {
    SharedPreferences db = await getDB();
    return db.getString(id);
  }

  Future<dynamic> getTheme() async {
    SharedPreferences db = await getDB();
    var map = {
      "theme": db.getString("theme"),
      "opacity": db.getString("opacity"),
      "background": db.getString("background")
    };
    return map;
  }
}
