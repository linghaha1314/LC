import {NgModule} from '@angular/core';
import {CommonModule, registerLocaleData} from '@angular/common';
import {AppRoutingModule} from "./app-routing.module";
import {BootComponent} from "./boot.component";
import {BrowserModule} from "@angular/platform-browser";
import zh from "@angular/common/locales/zh";
import {HTTP_INTERCEPTORS, HttpClientModule} from "@angular/common/http";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {NzMessageModule} from 'ng-zorro-antd/message';
import {HttpBaseInterceptor} from "./utils/HttpBaseInterceptor";

registerLocaleData(zh);

@NgModule({
  declarations: [BootComponent],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NzMessageModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: HttpBaseInterceptor,
    multi: true
  }],
  bootstrap: [BootComponent],
})
export class BootModule {
}

