import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {IntroComponent} from "./intro.component";


const routes: Routes = [
  {path: 'base', component: IntroComponent, data: {title: '系统设置'}},
  {path: 'exam', component: IntroComponent, data: {title: '考核管理系统'}},
  {path: 'gme', component: IntroComponent, data: {title: '评价管理系统'}},
  {path: 'process', component: IntroComponent, data: {title: '运行管理系统'}},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IntroRoutingModule {
}
