import {Component, OnInit} from "@angular/core";

@Component({
  selector: 'intro',
  template: `
    <div nz-row nzJustify="space-around" nzAlign="middle" style="height: 100%;">
      <div nz-col nzSpan="24" style="text-align: center;">
        <img [src]="img" (error)="changeImg()" style="max-width:1200px !important">
      </div>
    </div>`
})
export class IntroComponent implements OnInit {

  img: string;

  ngOnInit(): void {
    const list = window.location.pathname.split('/');
    this.img = './assets/images/intro/' + list[list.length - 1] + '.png';
  }

  changeImg() {
    this.img = './assets/images/logo.png';
  }
}
