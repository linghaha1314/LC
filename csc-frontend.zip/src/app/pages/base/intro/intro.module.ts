import {CommonModule} from '@angular/common';
import {NgModule} from "@angular/core";
import {IntroComponent} from "./intro.component";
import {IntroRoutingModule} from "./intro-routing.module";
import {NzGridModule} from "ng-zorro-antd/grid";

@NgModule({
  declarations: [IntroComponent],
  imports: [CommonModule, IntroRoutingModule, NzGridModule]
})
export class IntroModule {
}
