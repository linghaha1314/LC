export class OftenMenu {
  id: string;
  menuId: string;
  name: string;
  url: string;
  staffId: string;
  userId: string;
  created: any;
  menuName: string;
  staffName: string;
  userName: string;
}
