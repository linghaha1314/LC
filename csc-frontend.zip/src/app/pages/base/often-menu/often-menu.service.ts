import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {OftenMenu} from "./often-menu";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class OftenMenuService extends BaseService<OftenMenu> {
  protected url = {
    listByPage: '/oftenmenu/listQueryByPage',
    insert: '/oftenmenu/save',
    update: '/oftenmenu/update',
    delete: '/oftenmenu/delete',
    deleteAll: '/oftenmenu/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
