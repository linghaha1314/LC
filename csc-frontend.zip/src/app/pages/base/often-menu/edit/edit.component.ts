import {Component, OnInit} from "@angular/core";
import {OftenMenu} from "../often-menu";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {OftenMenuService} from "../often-menu.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'often-menu-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<OftenMenu> implements OnInit {

  constructor(public location: Location, public service: OftenMenuService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new OftenMenu());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        menuId: [d.menuId, [Validators.required, Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(250)]],
        url: [d.url, [Validators.required]],
        staffId: [d.staffId, [Validators.required, Validators.maxLength(40)]],
        userId: [d.userId, [Validators.maxLength(40)]],
        created: [d.created],
        menuName: [d.menuName],
        staffName: [d.staffName],
        userName: [d.userName],
      });
      this.isLoading = false;
    });
  }

}
