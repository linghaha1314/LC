import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '常用功能列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '常用功能详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加常用功能'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑常用功能'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OftenMenuRoutingModule {
}
