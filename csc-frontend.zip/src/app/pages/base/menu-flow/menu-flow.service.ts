import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {MenuFlow} from "./menu-flow";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class MenuFlowService extends BaseService<MenuFlow> {
  protected url = {
    listByPage: '/menuflow/listQueryByPage',
    insert: '/menuflow/save',
    update: '/menuflow/update',
    delete: '/menuflow/delete',
    deleteAll: '/menuflow/deleteAll',
    menuFlowList: '/menuflow/listQueryByPage',
    menuFlowItemList: '/menuflowitem/listQueryByPage',
  };
  currentMenuFlowItem = null;
  currentMenuFlow = null;
  firstNumber = null;
  menuFlowFlagMap = {};
  menuId = null;

  constructor(help: Help) {
    super(help);
  }

  // 获取流程菜单详情
  getMenusFlowByMenuId(params) {
    return this.help.post(this.url.menuFlowList, params)
  }

  getMenusFlowItemByMenuId(params) {
    return this.help.post(this.url.menuFlowItemList, params)
  }
}
