import {AfterContentChecked, AfterContentInit, Component, OnInit, QueryList, ViewChild, ViewChildren} from "@angular/core";
import {MenuFlowService} from "../menu-flow.service";
import {ActivatedRoute, ParamMap, Router} from "@angular/router";

@Component({
  selector: 'menu-flow-list',
  templateUrl: './examine.component.html',
  styles: []
})
export class ExamineComponent implements OnInit, AfterContentInit, AfterContentChecked {

  menuId = null;
  reloadMenuItemFlag = false;
  menuFlow = null;
  menuFlowAttachs = [];
  itemCount = 0;
  parentWidth = 0;
  math = Math;
  isMenuFlowContentShow = false;
  @ViewChildren('menuFlowItemElement')
  menuFlowItemElementList: QueryList<Element>;
  @ViewChild('menuFlowItemElements')
  menuFlowItemElement: Element;
  menuFlowItemList = [];
  viewMenuFlowItemList = [];

  constructor(private router: Router, private service: MenuFlowService, private route: ActivatedRoute) {
    this.changeRouteData();
  }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.menuId = params.get('id');
      this.initMenuFlow();
    });
  }

  changeRouteData() {
    if (this.menuFlow) {
      localStorage.setItem("nowName", this.menuFlow.name);
    }
  }

  initMenuFlow() {
    this.service.getMenusFlowByMenuId({menuId: this.menuId}).subscribe((res: any) => {
      if (res.total > 0) {
        this.menuFlow = res.rows[0];
        this.changeRouteData();
        if (this.service.menuId != this.menuId) {
          this.service.menuId = this.menuId;
          this.service.firstNumber = null;
        }
        if (this.menuFlow.info != null && this.menuFlow.info != '' && this.service.firstNumber != 1) {
          this.isMenuFlowContentShow = true;
          this.service.firstNumber = 1;
        }
        if (this.menuFlow.attachs != null && this.menuFlow.attachs != '') {
          let attach = [];
          this.menuFlow.attachs.split(",").forEach(s => {
            attach.push({path: s});
          });
          this.menuFlowAttachs = attach;
        }
        this.service.getMenusFlowItemByMenuId({menuFlowId: this.menuFlow.id, type: "use"}).subscribe((r: any) => {
          if (r.total > 0) {
            let displayJson = localStorage.getItem("displayMenuFlow");
            if ((this.service.menuFlowFlagMap[this.menuId] == null || this.service.menuFlowFlagMap[this.menuId] == true) && (displayJson == null || (JSON.parse(displayJson)[this.menuId] == null))
              && this.menuFlow.attachs != null && this.menuFlow.attachs != '') {
              //跳转至帮助页面
              this.service.menuFlowFlagMap[this.menuId] = true;
              this.menuFlowClick();
            } else {
              r.rows.forEach(i => {
                i["index"] = 0;
                i["type"] = 'right';
                i["downFlag"] = false;
                i["viewFlag"] = true;
                i["clickFlag"] = true;
                if (i["menuId"] != null) {
                  i["clickFlag"] = i["menuAuth"] != null;
                } else {
                  i["clickFlag"] = i["attachs"] != null;
                }
              });
              this.menuFlowItemList = r.rows;
              this.viewMenuFlowItemList = [...this.menuFlowItemList];
            }
          } else {
            //没有流程直接跳转至详情页面
            this.menuFlowClick();
          }
          this.reloadMenuItemFlag = true;
        });
      }
    });
  }

  menuFlowItemClick(data) {
    localStorage.setItem("nowName", data.name);
    if (data['menusFlowFlag']) {
      let path = data.menuPath;
      let displayJson = localStorage.getItem("displayMenuFlow");
      if (displayJson == null) {
        path = "/menuflow/examine/" + data.menuId;
      } else {
        if (JSON.parse(displayJson)[data.menuId] == null) {
          path = "/menuflow/examine/" + data.menuId;
        }
      }
      this.router.navigate([path]).then();
    } else {
      if (data.menuPath != null && data.menuPath != '') {
        this.service.help.setMenuAuth(data.menuAuth);
        this.router.navigate([data.menuPath]).then();
        return;
      }
      //没有关联路径
      let viewData = JSON.parse(JSON.stringify(data));
      let attachsList = [];
      if (viewData['attachs'] != null) {
        viewData['attachs'].toString().split(',').map(s => {
          attachsList.push({path: s});
        });
      }
      viewData['attachs'] = attachsList;
      this.service.currentMenuFlowItem = viewData;
      this.router.navigate(['/menuflow/examineView']).then();
    }
  }

  menuFlowClick() {
    let viewData = JSON.parse(JSON.stringify(this.menuFlow));
    let attachsList = [];
    if (viewData['attachs'] != null) {
      viewData['attachs'].toString().split(',').map(s => {
        attachsList.push({path: s});
      });
    }
    viewData['attachs'] = attachsList;
    this.service.currentMenuFlow = viewData;
    localStorage.setItem('nowName', '帮助说明');
    this.router.navigate(['/menuflow/examineHelp']).then();
  }

  showMenuFlowItem(i, dataList, c) {
    //获取这一排的数据
    let indexs = i;
    if (i % c != 0) {
      indexs = i - (i % c);
    }
    if (dataList[indexs + c] != null) {
      let index = i + (c - (i % c) * 2) - 1;
      return index;
    } else {
      //获取这一排有多少个值
      let count = dataList.length - indexs;
      let index = i + (count - (i % count) * 2) - 1;
      return index;
    }
  }

  afterViewChange() {
    let parentWidth = this.menuFlowItemElement['nativeElement'].clientWidth;
    let count = Math.floor((parentWidth - 234) / 312) + 1;
    if (this.menuFlowItemList.length < count) {
      count = this.menuFlowItemList.length;
    }
    if (parentWidth != this.parentWidth || this.reloadMenuItemFlag) {
      this.parentWidth = parentWidth;
      this.itemCount = count;
      this.reloadMenuItemFlag = false;
      let viewMenuFlowItemList = JSON.parse(JSON.stringify(this.menuFlowItemList));
      let allNumber = this.math.ceil(viewMenuFlowItemList.length / count);
      let lastIndex = (allNumber - 1) * count - 1;
      let s = count - (viewMenuFlowItemList.length % count);
      if (viewMenuFlowItemList.length % count != 0) {
        for (let i = 0; i < s; i++) {
          viewMenuFlowItemList.push({"name": 1, "index": 0, "type": 'right', 'downFlag': false, 'viewFlag': false});
        }
      }
      let lastNumber = viewMenuFlowItemList.length - lastIndex - 1;
      viewMenuFlowItemList.forEach((s, i) => {
        viewMenuFlowItemList[i]["index"] = 0;
        viewMenuFlowItemList[i]["downFlag"] = false;
        let number = this.math.ceil((i + 1) / count);
        let d = (i + 1) % count;
        let n = number % 2;
        if (viewMenuFlowItemList[i + 1] != null) {
          viewMenuFlowItemList[i]["index"] = 0;
          if (n == 1) {
            if (viewMenuFlowItemList[i + 1]["viewFlag"]) {
              viewMenuFlowItemList[i]["type"] = "right";
            } else {
              viewMenuFlowItemList[i]["type"] = "last";
            }
            if (d == 0) {
              viewMenuFlowItemList[i]["type"] = "";
              viewMenuFlowItemList[i]["downFlag"] = true;
            }
          } else {
            viewMenuFlowItemList[i]["type"] = d != 0 ? "left" : "";
            let h = i > lastIndex ? this.math.ceil(lastNumber / 2) : this.math.ceil(count / 2);
            let c = i > lastIndex ? lastNumber : count;
            let k = c % 2;
            if (d != h || k == 0) {
              let ix;
              if (c % 2 == 1) {
                ix = d > h ? (1 + (c - d) - d) : d == 1 ? c - d : c - d - 1;
              } else {
                if (d == h) {
                  ix = 1;
                } else {
                  ix = d > h ? (1 + (c - d) - d) : d == 1 ? c - d : c - d - 1;
                }
              }
              if (d == 0) {
                ix = d - c + 1;
              }
              if (viewMenuFlowItemList[i + ix] != null) {
                viewMenuFlowItemList[i]["index"] = ix;
              } else {
                let index = this.showMenuFlowItem(i, viewMenuFlowItemList, count);
                viewMenuFlowItemList[i]["index"] = index - i;
              }
            }
            if ((count == 1 || d == 1) && viewMenuFlowItemList[i + count] != null) {
              viewMenuFlowItemList[i]["downFlag"] = true;
            }
          }
        } else {
          viewMenuFlowItemList[i]["type"] = "";
          if (n == 0) {
            //双行
            viewMenuFlowItemList[i]["index"] = 1 - count > 0 ? count - 1 : 1 - count;
          }
        }
        if (viewMenuFlowItemList[i + 1] != null && !viewMenuFlowItemList[i + 1]['viewFlag']) {
          if (count != 1 && d == 1) {
            viewMenuFlowItemList[i]["type"] = "last";
          }
        }
      });
      this.viewMenuFlowItemList = [...viewMenuFlowItemList];
    }
  }

  ngAfterContentChecked(): void {
    if (this.menuFlowItemElementList != null && this.menuFlowItemElementList.length > 0) {
      this.afterViewChange();
    }
  }

  ngAfterContentInit(): void {
    if (this.menuFlowItemElementList != null && this.menuFlowItemElementList.length > 0) {
      this.afterViewChange();
    }
  }

  showEditorText(data) {
    return data.replace(/<[^>]+>/g, "");
  }
}
