import {Component, OnInit} from "@angular/core";

@Component({
  selector: 'menu-flow-list',
  templateUrl: './menu-empty.component.html',
  styles: []
})
export class MenuEmptyComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }
}
