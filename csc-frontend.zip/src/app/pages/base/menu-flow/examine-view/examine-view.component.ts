import {Component, ElementRef, OnInit, ViewChild} from "@angular/core";
import {MenuFlowService} from "../menu-flow.service";
import {Router} from "@angular/router";

@Component({
  selector: 'menu-flow-list',
  templateUrl: './examine-view.component.html',
  styles: []
})
export class ExamineViewComponent implements OnInit {

  constructor(private router: Router, private service: MenuFlowService) {
  }

  currentMenuFlowItem = {};

  isLoading = false;

  @ViewChild('divElement')
  divElement: ElementRef;

  attachViewHeight = 0;

  ngOnInit() {
    this.isLoading = true;
    this.currentMenuFlowItem = {...this.service.currentMenuFlowItem};
    setTimeout(() => {
      this.attachViewHeight = this.divElement.nativeElement.clientHeight - 70;
    }, 500);
    this.isLoading = false;
  }

}
