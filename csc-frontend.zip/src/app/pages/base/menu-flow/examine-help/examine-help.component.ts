import {Component, ElementRef, OnInit, ViewChild} from "@angular/core";
import {MenuFlowService} from "../menu-flow.service";
import {ActivatedRoute, ParamMap, Router} from "@angular/router";
import {Location} from "@angular/common";

@Component({
  selector: 'menu-flow-list',
  templateUrl: './examine-help.component.html',
  styles: []
})
export class ExamineHelpComponent implements OnInit {

  constructor(private router: Router, private location: Location, public service: MenuFlowService, private route: ActivatedRoute) {
  }

  currentMenuFlow = {};
  isLoading = false;
  attachViewHeight = 0;
  @ViewChild('divElement')
  divElement: ElementRef;
  @ViewChild('skipElement')
  skipElement: ElementRef;
  displayFlag = false;
  menuFlowFlag = false;

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      if (params.get('id') != null) {
        this.initMenuFlow(params.get('id'));
      } else {
        this.isLoading = true;
        this.currentMenuFlow = {...this.service.currentMenuFlow};
        this.menuFlowFlag = this.service.menuFlowFlagMap[this.currentMenuFlow['menuId']];
        this.isLoading = false;
        this.setAttachViewHeight();
      }
    });
  }

  back() {
    this.location.back();
  }

  initMenuFlow(menuId) {
    this.service.getMenusFlowByMenuId({menuId: menuId}).subscribe((res: any) => {
      if (res.total > 0) {
        let data = res.rows[0];
        if (data['attachs'] != null && data['attachs'] != '') {
          let attach = [];
          data['attachs'].split(",").forEach(s => {
            attach.push({path: s});
          });
          data['attachs'] = attach;
        }
        this.currentMenuFlow = data;
        this.setAttachViewHeight();
      }
    });
  }

  skipMenuFlow() {
    if (this.displayFlag) {
      let displayMenuFlowData = localStorage.getItem("displayMenuFlow");
      if (displayMenuFlowData == null) {
        displayMenuFlowData = "{}";
      }
      let d = JSON.parse(displayMenuFlowData);
      d[this.currentMenuFlow['menuId']] = true;
      localStorage.setItem("displayMenuFlow", JSON.stringify(d));
    }
    if (this.service.menuFlowFlagMap[this.currentMenuFlow['menuId']] == true) {
      this.service.menuFlowFlagMap[this.currentMenuFlow['menuId']] = false;
      this.location.back();
    } else {
      this.router.navigate([this.currentMenuFlow['menuUrl']]).then();
    }
  }

  setAttachViewHeight() {
    setTimeout(() => {
      let height = this.divElement.nativeElement.clientHeight - 70;
      if ((this.currentMenuFlow != null && this.currentMenuFlow["menuUrl"] != '#') || this.menuFlowFlag) {
        height = height - this.skipElement.nativeElement.clientHeight;
      }
      this.attachViewHeight = height;
    }, 500);
  }
}
