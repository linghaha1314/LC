export class MenuFlow {
  id: string;
  name: string;
  menuId: string;
  params: string;
  info: string;
  attachs: string;
  status: number;
  created: any;
  userId: string;
  hospitalId: string;
  menuName: string;
  userName: string;
}
