import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";
import {ExamineComponent} from "./examine/examine.component";
import {ExamineViewComponent} from "./examine-view/examine-view.component";
import {ExamineHelpComponent} from "./examine-help/examine-help.component";
import {MenuEmptyComponent} from "./menu-empty/menu-empty.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '菜单流程表列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '菜单流程表详情'}},
  {path: 'examine/:id', component: ExamineComponent, data: {title: '业务流程'}},
  {path: 'menuEmpty', component: MenuEmptyComponent, data: {title: '提示信息'}},
  {path: 'examineView', component: ExamineViewComponent, data: {title: '流程说明'}},
  {path: 'examineHelp/:id', component: ExamineHelpComponent, data: {title: '说明信息'}},
  {path: 'examineHelp', component: ExamineHelpComponent, data: {title: '说明信息'}},
  {path: 'edit', component: EditComponent, data: {title: '添加菜单流程表'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑菜单流程表'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MenuFlowRoutingModule {
}
