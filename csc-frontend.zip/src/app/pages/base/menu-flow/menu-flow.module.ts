import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {NZ_I18N, zh_CN} from 'ng-zorro-antd/i18n';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzDescriptionsModule} from 'ng-zorro-antd/descriptions';
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzModalModule, NzModalService} from 'ng-zorro-antd/modal';
import {NzPageHeaderModule} from 'ng-zorro-antd/page-header';
import {NzPopconfirmModule} from 'ng-zorro-antd/popconfirm';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzResultModule} from 'ng-zorro-antd/result';
import {NzSpinModule} from 'ng-zorro-antd/spin';
import {NzTableModule} from 'ng-zorro-antd/table';
import {NzToolTipModule} from 'ng-zorro-antd/tooltip';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {LoadStatusModule} from "../../../component/load-status/load-status.module";
import {ValidateMsgModule} from "../../../component/validate-msg/validate-msg.module";

import {MenuFlowRoutingModule} from "./menu-flow-routing.module";
import {MenuFlowService} from "./menu-flow.service";

import {ListComponent} from "./list/list.component";
import {EditComponent} from "./edit/edit.component";
import {ViewComponent} from "./view/view.component";
import {ExamineComponent} from "./examine/examine.component"
import {ExamineViewComponent} from "./examine-view/examine-view.component"
import {ExamineHelpComponent} from "./examine-help/examine-help.component"
import {MenuEmptyComponent} from "./menu-empty/menu-empty.component";
import {FormComboModule} from "../../../component/form/combobox/form-combo.module";
import {NzCardModule} from "ng-zorro-antd/card";
import {AttachViewerModule} from "../../../component/attach-viewer/attach-viewer.module";
import {ExamQuestionModule} from "../../exam/exam-question/exam-question.module";
import {NzCheckboxModule} from "ng-zorro-antd/checkbox";
import {SafeHtmlModule} from "../../../pipe/SafeHtml.module";
import {NzPopoverModule} from "ng-zorro-antd/popover";

@NgModule({
  declarations: [ListComponent, EditComponent, ViewComponent, ExamineComponent, MenuEmptyComponent, ExamineViewComponent, ExamineHelpComponent],
  imports: [
    CommonModule,
    MenuFlowRoutingModule,
    NzInputModule,
    FormsModule,
    NzTableModule,
    NzPopconfirmModule,
    NzButtonModule,
    NzToolTipModule,
    NzIconModule,
    NzDescriptionsModule,
    NzSpaceModule,
    NzBadgeModule,
    NzResultModule,
    NzSpinModule,
    LoadStatusModule,
    ReactiveFormsModule,
    NzRadioModule,
    NzFormModule,
    NzPageHeaderModule,
    ValidateMsgModule,
    FormComboModule,
    NzCardModule,
    NzModalModule,
    AttachViewerModule,
    ExamQuestionModule,
    NzCheckboxModule,
    SafeHtmlModule,
    NzPopoverModule
  ],
  providers: [MenuFlowService, NzModalService, {provide: NZ_I18N, useValue: zh_CN}]
})
export class MenuFlowModule {
}
