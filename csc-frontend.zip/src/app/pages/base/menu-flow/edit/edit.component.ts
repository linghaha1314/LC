import {Component, OnInit} from "@angular/core";
import {MenuFlow} from "../menu-flow";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {MenuFlowService} from "../menu-flow.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'menu-flow-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<MenuFlow> implements OnInit {

  constructor(public location: Location, public service: MenuFlowService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(500)]],
      menuId: [null, [Validators.required, Validators.maxLength(40)]],
      params: [null, [Validators.required, Validators.maxLength(500)]],
      info: [null, [Validators.required]],
      attachs: [null, [Validators.required]],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      created: [null],
      userId: [null, [Validators.maxLength(40)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      menuName: [null],
      userName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new MenuFlow());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

}
