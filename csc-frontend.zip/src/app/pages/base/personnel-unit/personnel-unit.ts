export class PersonnelUnit {
  id: string;
  name: string;
  address: string;
  levelId: string;
  contactPerson: string;
  contactAddress: string;
  status: number;
  remark: string;
  created: any;
  hospitalId: string;
  levelName: string;
}
