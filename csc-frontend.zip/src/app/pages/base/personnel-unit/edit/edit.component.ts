import {Component, OnInit} from "@angular/core";
import {PersonnelUnit} from "../personnel-unit";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {PersonnelUnitService} from "../personnel-unit.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'personnel-unit-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<PersonnelUnit> implements OnInit {

  constructor(public location: Location, public service: PersonnelUnitService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new PersonnelUnit());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        address: [d.address, [Validators.required, Validators.maxLength(250)]],
        levelId: [d.levelId || '123', [Validators.required, Validators.maxLength(40)]],
        contactPerson: [d.contactPerson, [Validators.required, Validators.maxLength(50)]],
        contactAddress: [d.contactAddress, [Validators.required, Validators.maxLength(250)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        remark: [d.remark, [Validators.maxLength(200)]],
        created: [d.created],
        hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        levelName: [d.levelName],
      });
      this.isLoading = false;
    });
  }

}
