import {Component, OnInit} from "@angular/core";
import {PersonnelUnit} from "../personnel-unit";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {PersonnelUnitService} from "../personnel-unit.service";
import {ImportConfig} from "../../../../component/import-data/import-data";

@Component({
  selector: 'personnel-unit-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<PersonnelUnit> implements OnInit {
  importConfig: ImportConfig = {
    url: '/personnelunit/importPersonnelUnit',
    template: '/xlsx/单位导入模板.xlsx',
    validateUrl: '/personnelunit/validateData',
    columns: [
      {field: 'name', text: '单位名称', editor: {type: "string", require: true}},
      {field: 'address', text: '所在省市', editor: {type: "string", require: true}},
      {
        field: 'levelName',
        text: '等级',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/hospitalLevelType",
          valueKey: "name",
          require: true
        }
      },
      {field: 'contactPerson', text: '联系人', editor: {type: "string", require: true}},
      {field: 'contactAddress', text: '联系地址', editor: {type: "string", require: true}},
    ]
  };

  constructor(public modal: NzModalService, public service: PersonnelUnitService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }

  importAfter(data) {
    this.reloadData();
  }
}
