import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {PersonnelUnit} from "./personnel-unit";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class PersonnelUnitService extends BaseService<PersonnelUnit> {
  protected url = {
    listByPage: '/personnelunit/listQueryByPage',
    insert: '/personnelunit/save',
    update: '/personnelunit/update',
    delete: '/personnelunit/delete',
    deleteAll: '/personnelunit/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
