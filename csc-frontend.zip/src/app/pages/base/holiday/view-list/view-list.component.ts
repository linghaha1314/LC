import {Component, OnInit} from "@angular/core";
import {Holiday} from "../holiday";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {HolidayService} from "../holiday.service";
import {ActivatedRoute, ParamMap} from "@angular/router";

@Component({
  selector: 'holiday-view-list',
  templateUrl: './view-list.component.html',
  styles: []
})
export class ViewListComponent extends BaseListComponent<Holiday> implements OnInit {

  constructor(public modal: NzModalService, public service: HolidayService, public message: NzMessageService, private route: ActivatedRoute) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.pageIndex = this.service.pageNum;
      this.pageSize = this.service.pageSize;
      this.getData();
      this.refreshChecked();
    });

  }

}
