import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Holiday} from "./holiday";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class HolidayService extends BaseService<Holiday> {
  protected url = {
    listByPage: '/holiday/listQueryByPage',
    insert: '/holiday/save',
    update: '/holiday/update',
    delete: '/holiday/delete',
    deleteAll: '/holiday/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

  getAllHoliday(data: any) {
    return this.help.post(this.url.listByPage, data);
  }
}
