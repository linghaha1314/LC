import {Component, OnInit} from "@angular/core";
import {Holiday} from "../holiday";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {HolidayService} from "../holiday.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'holiday-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Holiday> implements OnInit {

  constructor(public location: Location, public service: HolidayService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Holiday());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        code: [d.code, [Validators.maxLength(50)]],
        startDate: [d.startDate, [Validators.required]],
        endDate: [d.endDate, [Validators.required]],
        typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        remark: [d.remark, [Validators.maxLength(200)]],
        hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        userId: [d.userId, [Validators.maxLength(40)]],
        created: [d.created],
        typeName: [d.typeName],
        userName: [d.userName],
      });
      this.isLoading = false;
    });
  }

  submitForm() {
    if (!this.validateForm.valid) {
      this.message.error('请填写完相关信息!');
      return;
    }
    const startDate = this.validateForm.value["startDate"];
    const endDate = this.validateForm.value["endDate"];
    if (endDate < startDate) {
      this.message.error('开始时间必须小于或等于结束时间!');
      return;
    }
    this.isLoading = true;
    this.validateForm.get("startDate").setValue(this.validateForm.get("startDate") + " 00:00:00")
    this.validateForm.get("endDate").setValue(this.validateForm.get("startDate") + " 00:00:00")
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            this.location.back();
          }
        });
      }
    });
  }

}
