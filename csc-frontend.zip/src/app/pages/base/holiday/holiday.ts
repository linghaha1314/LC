export class Holiday {
  id: string;
  name: string;
  code: string;
  startDate: any;
  endDate: any;
  typeId: string;
  status: number;
  remark: string;
  hospitalId: string;
  userId: string;
  created: any;
  typeCode: string;
  typeName: string;
  userName: string;
}
