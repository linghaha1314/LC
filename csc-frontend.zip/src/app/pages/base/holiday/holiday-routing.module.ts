import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";
import {ViewListComponent} from "./view-list/view-list.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '节假日列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '节假日详情'}},
  {path: 'view-list', component: ViewListComponent, data: {title: '节假日详情列表'}},
  {path: 'edit', component: EditComponent, data: {title: '添加节假日'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑节假日'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HolidayRoutingModule {
}
