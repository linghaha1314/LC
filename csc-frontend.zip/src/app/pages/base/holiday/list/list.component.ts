import {Component, OnInit, ViewChild, ViewEncapsulation} from "@angular/core";
import {Holiday} from "../holiday";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {HolidayService} from "../holiday.service";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {CalendarOptions, FullCalendarComponent} from "@fullcalendar/angular";
import {formatDate} from "@angular/common";
import {ImportConfig} from "../../../../component/import-data/import-data";

@Component({
  selector: 'holiday-list',
  templateUrl: './list.component.html',
  encapsulation: ViewEncapsulation.Emulated,
  styleUrls: ['./list.component.scss']
})
export class ListComponent extends BaseListComponent<Holiday> implements OnInit {

  date = new Date();
  dataList: any = {};
  initFlag = false;
  validateEditForm: FormGroup;
  @ViewChild('fullCalendar') calendarComponent: FullCalendarComponent;
  isEditVisible = false;
  calendarOptions: CalendarOptions;

  importConfig: ImportConfig = {
    url: '/holiday/importHoliday',
    template: '/xlsx/节假日导入.xlsx',
    validateUrl: '/holiday/validateData',
    extraParams: {status: 0},
    columns: [
      {field: 'name', text: '名称', editor: {type: "string", require: true}},
      {field: 'code', text: '编码', editor: {type: "string"}},
      {field: 'startDate', text: '开始日期', editor: {type: "date", require: true}},
      {field: 'endDate', text: '结束日期', editor: {type: "date", require: true}},
      {
        field: 'typeName', text: '类型', editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/holidayType",
          require: true
        }
      },
      {field: 'status', text: '状态', editor: {type: "radio", sources: ["启用", "禁用"], require: true}},
      {field: 'remark', text: '备注', editor: {type: "string"}},
    ]
  }

  constructor(public modal: NzModalService, public service: HolidayService, public message: NzMessageService, private fb: FormBuilder) {
    super(modal, service, message);
  }

  ngOnInit() {
    const that = this;
    this.calendarOptions = {
      headerToolbar: {
        left: '',
        center: 'title',
        right: 'today,prev,next'
      },
      eventClick(calEvent) {
        that.showView(that.dataList[calEvent.event.id]);
      },
      _noEventResize() {
        that.initFlag = true;
      },
      initialView: 'dayGridMonth',
      locale: 'zh-cn',
      lazyFetching: true,
      height: 780,
      selectable: true,
      events(info, successCallback, failureCallback) {
        that.queryParams.startDate = info.startStr.substring(0, 10);
        that.queryParams.endDate = info.endStr.substring(0, 10);
        const events = [];
        that.loading = true;
        that.service.getAllHoliday(that.queryParams).subscribe((res: any) => {
          if (res.total > 0) {
            res.rows.forEach(d => {
              const data = {
                title: d.name + '-' + d.typeName,
                start: formatDate(d.startDate, 'yyyy-MM-dd', 'zh'),
                backgroundColor: d.typeCode == 'originalHoliday' ? '#66CCFF' : '#33FF99',
                end: formatDate(d.endDate, 'yyyy-MM-dd', 'zh'),
                id: d.id,
                data: d
              };
              that.dataList[d.id] = d;
              events.push(data);
            });
          }
          setTimeout(function () {
            // 这里就是处理的事件
            that.loading = false;
            successCallback(events)
          }, 500);
        });
      },
      views: {
        timeGridWeek: {}
      }
    };
  }

  showView(data) {
    this.isEditVisible = true;
    this.service.getAllHoliday({id: data.id}).subscribe((res: any) => {
      if (res.total > 0) {
        const d = res.rows[0];
        this.validateEditForm = this.fb.group({
          id: [d.id, [Validators.maxLength(40)]],
          name: [d.name, [Validators.required, Validators.maxLength(100)]],
          code: [d.code, [Validators.maxLength(50)]],
          startDate: [d.startDate, [Validators.required]],
          endDate: [d.endDate, [Validators.required]],
          typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
          status: [d.status, [Validators.required, Validators.maxLength(11)]],
          remark: [d.remark, [Validators.maxLength(200)]],
          hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
          userId: [d.userId, [Validators.maxLength(40)]],
          created: [d.created],
          typeName: [d.typeName],
          userName: [d.userName],
        });
      }
    });
  }

  handleEditCancel() {
    this.isEditVisible = false;
  }

  handleEditOk() {
    if (!this.validateEditForm.valid) {
      this.message.error('请填写完相关信息!');
      return;
    }
    const startDate = this.validateEditForm.value["startDate"];
    const endDate = this.validateEditForm.value["endDate"];
    if (endDate < startDate) {
      this.message.error('开始时间必须小于或等于结束时间!');
      return;
    }
    this.service.saveOrUpdateData(this.validateEditForm.value).subscribe(res => {
      if (res.success) {
        this.isEditVisible = false;
        this.getData();
      }
    });
  }

  deleteHoliday(id) {
    this.service.deleteById(id.value).subscribe(res => {
      if (res.success) {
        this.message.success('删除成功!');
        this.isEditVisible = false;
        this.getData();
      }
    });
  }

  getData() {
    this.loading = true;
    this.dataList = {};
    const events = [];
    this.service.getAllHoliday(this.queryParams)
      .subscribe(data => {
        this.loading = false;
        if (data.rows.length > 0) {
          // 进行排序操作
          data.rows.forEach(d => {
            const data = {
              title: d.name + '-' + d.typeName,
              start: formatDate(d.startDate, 'yyyy-MM-dd', 'zh'),
              backgroundColor: d.typeCode == 'originalHoliday' ? '#66CCFF' : '#33FF99',
              end: formatDate(d.endDate, 'yyyy-MM-dd', 'zh'),
              id: d.id,
              data: d
            };
            this.dataList[d.id] = d;
            events.push(data);
          });
        }
        this.calendarComponent.getApi().refetchEvents();
        this.total = data.total;
      }, ({error}) => {
        this.loading = false;
        this.message.error(`请求出现错误: ${error.msg}`);
      });
  }

}
