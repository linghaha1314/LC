export class DictionaryData {
  id: string;
  name: string;
  code: string;
  typeId: string;
  remark: string;
  status: number;
  created: any;
  sort: number;
  typeName: string;
}
