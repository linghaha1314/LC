import {Component, OnInit} from "@angular/core";
import {DictionaryData} from "../dictionary-data";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {DictionaryDataService} from "../dictionary-data.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'dictionary-data-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<DictionaryData> implements OnInit {

  constructor(public location: Location, public service: DictionaryDataService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    const type = this.location.getState();
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new DictionaryData());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        code: [d.code, [Validators.required, Validators.maxLength(50)]],
        typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
        remark: [d.remark, [Validators.maxLength(200)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        created: [d.created],
        sort: [d.sort],
        typeName: [d.typeName]
      });
      if (type['typeId']) {
        this.initTypeData(type['typeId']);
      } else {
        this.isLoading = false;
      }
    });
  }

  initTypeData(typeId) {
    this.service.getTypeById(typeId).subscribe((d: any) => {
      this.isLoading = false;
      if (d) {
        this.validateForm.get('typeId').setValue(d.id);
        this.validateForm.get('typeName').setValue(d.name);
      }
    });
  }

}
