import {Component, OnInit} from "@angular/core";
import {DictionaryData} from "../dictionary-data";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {DictionaryDataService} from "../dictionary-data.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";
import {Location} from "@angular/common";

@Component({
  selector: 'dictionary-data-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<DictionaryData> implements OnInit {

  backFlag = false;

  typeId: string;

  constructor(modal: NzModalService, service: DictionaryDataService, message: NzMessageService, private route: ActivatedRoute, private location: Location) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return of(params.get('id'));
        } else {
          return of(null);
        }
      })
    ).subscribe(typeId => {
      if (typeId) {
        this.backFlag = true;
        this.typeId = typeId;
        this.queryParams = {...this.queryParams, typeId};
      }
      this.reloadData();
      this.refreshChecked();
    });
  }

  back() {
    this.location.back();
  }
}
