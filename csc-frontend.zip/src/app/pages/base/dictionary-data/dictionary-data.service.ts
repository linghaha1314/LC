import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {DictionaryData} from "./dictionary-data";
import {Help} from "../../../utils/Help";
import {map} from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class DictionaryDataService extends BaseService<DictionaryData> {
  protected url = {
    listByPage: '/dictionarydata/listQueryByPage',
    insert: '/dictionarydata/save',
    update: '/dictionarydata/update',
    delete: '/dictionarydata/delete',
    deleteAll: '/dictionarydata/deleteAll',
    findTypeData: '/dictionarytype/findById'
  };

  constructor(help: Help) {
    super(help);
  }

  getTypeById(typeId: string) {
    return this.help.get(this.url.findTypeData + '/' + typeId).pipe(map((d: any) => {
      if (d.success) {
        return d.data;
      }
      return null;
    }));
  }
}
