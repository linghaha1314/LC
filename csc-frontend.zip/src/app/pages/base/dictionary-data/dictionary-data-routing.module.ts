import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '字典数据列表'}},
  {path: 'list/:id', component: ListComponent, data: {title: '字典数据列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '字典数据详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加字典数据'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑字典数据'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DictionaryDataRoutingModule {
}
