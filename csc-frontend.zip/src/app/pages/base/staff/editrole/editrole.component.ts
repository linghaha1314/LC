import {Component, OnInit} from "@angular/core";
import {Staff} from "../staff";
import {ActivatedRoute, ParamMap} from '@angular/router';
import {StaffService} from "../staff.service";
import {FormBuilder} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'staff-edit',
  templateUrl: './editrole.component.html',
  styles: []
})
export class EditRoleComponent extends BaseEditComponent<Staff> implements OnInit {

  service = null;
  allRoles: any[] = [];
  staffRoles: any[] = [];
  staffId: string;

  constructor(location: Location, service: StaffService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
    this.service = service;
  }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.staffId = params.get('id');
      if (this.staffId) {
        this.getStaffRole();
      } else {
        this.getAll();
      }
      this.validateForm = this.fb.group({});
    });
  }

  getStaffRole() {
    this.service.getRoleByStaffId(this.staffId).subscribe((res: any) => {
      if (res.success) {
        this.staffRoles = res.data.rows;
      }
      this.getAll();
    });
  }

  getAll() {
    this.service.getAllRoles().subscribe((res: any) => {
      const list = res.data;
      if (res.success) {
        if (this.staffRoles != null) {
          for (const item of this.staffRoles) {
            list.splice(list.findIndex(v => v.id === item.id), 1);
          }
        }
        this.allRoles = list;
      }
      this.isLoading = false;
    });
  }

  selectedRole(data: any) {
    if (data != null && data.hasOwnProperty("id")) {
      this.staffRoles.push(data);
      this.allRoles.splice(this.allRoles.findIndex(v => v.id === data.id), 1);
    }
  }

  removeRole(data: any) {
    this.allRoles.push(data);
    this.staffRoles.splice(this.staffRoles.findIndex(v => v.id === data.id), 1);
  }

  submitForm() {
    this.isLoading = true;

    const roleIdList = [];
    for (const item of this.staffRoles) {
      roleIdList.push(item.id);
    }
    const params = {staffId: this.staffId, roleIdList};

    this.service.saveOrUpdateStaffRole(params).subscribe(res => {
      if (res.success) {
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            this.location.back();
          }
        });
      }
    });
  }

}
