import {Component, OnInit} from '@angular/core';
import {Staff} from '../staff';
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {StaffService} from '../staff.service';
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from '../../../../component/base/base-edit.component';

@Component({
  selector: 'staff-edit',
  templateUrl: './edit.component.html',
  styles: [],
})
export class EditComponent extends BaseEditComponent<Staff> implements OnInit {
  constructor(
    location: Location,
    service: StaffService,
    message: NzMessageService,
    private fb: FormBuilder,
    private route: ActivatedRoute
  ) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(20)]],
      genderId: [null],
      birthday: [null],
      academicId: [null],
      academicName: [null],
      degreeId: [null],
      degreeName: [null],
      avator: [null],
      positionId: [null],
      positionName: [null],
      typeId: [null],
      typeName: [null],
      sectionId: [null],
      departmentId: [null],
      titleId: [null],
      titleName: [null],
      sectionName: [null],
      majorId: [null],
      majorName: [null],
      identifyTypeId: [null],
      identifyNo: [null],
      serialNo: [null, [Validators.required, Validators.maxLength(20)],],
      mobile: [null],
      email: [null],
      qq: [null],
      wechat: [null],
      remark: [null],
      userId: [null],
      created: [null],
      status: [null],
      hospitalId: [null],
      accountName: [null],
      cardNo: [null]
    });
    this.route.paramMap
      .pipe(
        switchMap((params: ParamMap) => {
          if (params.get('id')) {
            return this.service.getDataById(params.get('id'));
          } else {
            return of(new Staff());
          }
        })
      )
      .subscribe((d) => {
        this.validateForm.patchValue(d);
        this.isLoading = false;
      });
  }
}
