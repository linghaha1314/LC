import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Staff} from "./staff";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class StaffService extends BaseService<Staff> {
  url = {
    listByPage: '/staff/listQueryByPage',
    insert: '/staff/addStaff',
    update: '/staff/updateField',
    delete: '/staff/delete',
    deleteAll: '/staff/deleteAll',
    staffRole: '/roles/getRoleByStaffId',
    rolesALL: '/roles/findAll',
    saveRole: '/accountrole/saveStaffRole',
    resetPassword: "/accounts/updateAccountsPassword",
  };

  constructor(help: Help) {
    super(help);
  }


  getRoleByStaffId(staffId: string) {
    return this.help.post(this.url.staffRole, {staffId});
  }

  getAllRoles() {
    return this.help.get(this.url.rolesALL, {});
  }

  saveOrUpdateStaffRole(params: {}) {
    return this.help.post(this.url.saveRole, params);
  }

  getAccounts(data) {
    return this.help.post("/staff/listQueryByPage", data);
  }

  resetPassword(data) {
    return this.help.post(this.url.resetPassword, data);
  }

}
