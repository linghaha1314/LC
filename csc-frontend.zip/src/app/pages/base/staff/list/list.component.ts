import {Component, OnInit} from "@angular/core";
import {Staff} from "../staff";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {StaffService} from "../staff.service";
import {ImportConfig} from "../../../../component/import-data/import-data";

@Component({
  selector: 'staff-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Staff> implements OnInit {

  importConfig: ImportConfig = {
    url: '/staff/importStaff',
    template: '/xlsx/人员导入模板.xlsx',
    validateUrl: '/staff/validateData',
    extraParams: {templateId: null},
    columns: [
      {
        field: 'name',
        text: '名称',
        editor: {type: "string", max: 20, min: 1, require: true}
      },
      {
        field: 'mobile',
        text: '手机号',
        editor: {
          type: "string",
          max: 11
        }
      },
      {
        field: 'importType',
        text: '角色',
        editor: {
          type: "combo",
          url: "/roles/listQueryByPage",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'genderName',
        text: '性别',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/gender",
          valueKey: "name"
        }
      },
      {
        field: 'identifyTypeName',
        text: '证件类型',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/CreditType",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'identifyNo',
        text: '证件号',
        editor: {
          type: "string",
          max: 50,
          require: true
        }
      },
      {
        field: 'serialNo',
        text: '胸牌号',
        editor: {
          type: "string",
          max: 20,
          require: true
        }
      },
      {
        field: 'typeName',
        text: '人员类型',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/staffType",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'academicName',
        text: '学历',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/Education",
          valueKey: "name"
        }
      },
      {
        field: 'degreeName',
        text: '学位',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/Degree",
          valueKey: "name"
        }
      },
      {
        field: 'positionName',
        text: '职位',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/Position",
          valueKey: "name"
        }
      },
      {
        field: 'majorName',
        text: '专业',
        editor: {
          type: "combo",
          url: "/majors/listQueryByPage",
          valueKey: "name"
        }
      },
      {
        field: 'sectionName',
        text: '科室',
        editor: {
          type: "combo",
          url: "/sections/listQueryByPage",
          valueKey: "name"
        }
      },
      {
        field: 'departmentName',
        text: '教研室',
        editor: {
          type: "combo",
          url: "/department/listQueryByPage",
          valueKey: "name"
        }
      },
    ]
  };

  constructor(public modal: NzModalService, public service: StaffService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }

  getData() {
    this.loading = true;
    this.service.queryParams = this.queryParams;
    this.service.getData()
      .subscribe(data => {
        this.loading = false;
        this.list = data.list;
        this.list.forEach(value => {
          value["encMobile"] = value.mobile?.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2");
          value["encIdentifyNo"] = value.identifyNo?.replace(/(\d{4})\d{10}(\d{2})/, "$1************$2");
        });
        this.total = data.total;
        this.refreshChecked();
      }, ({error}) => {
        this.loading = false;
        this.message.error(`请求出现错误: ${error.msg}`);
      });
  }

  showRoleConfirm(id): void {
    const params = {staffId: id};

    this.modal.confirm({
      nzTitle: '用户角色',
      nzContent: `123<form-combo url="/roles/getRoleByStaffId"  [queryParams]="${params}"  [page]="false" ></form-combo>5555`,
      nzOkText: '保存',
      nzOnOk: () => {

      },
      nzCancelText: '取消'
    });
  }

  resetPassword(data) {
    this.service.getAccounts({id: data.id}).subscribe((res: any) => {
      if (res.total > 0) {
        this.service.resetPassword({
          accountsId: res.rows[0].accountsId,
          newPassword: 'hx@123456'
        }).subscribe((r: any) => {
          if (r.success) {
            this.message.success("重置成功！");
          }
        });
      }
    });
  }

}
