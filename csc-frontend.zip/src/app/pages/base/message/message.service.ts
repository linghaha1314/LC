import {Injectable} from '@angular/core';
import {BaseService} from "../../../component/base/base.service";
import {Message} from "./message";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class MessageService extends BaseService<Message> {
  url = {
    listByPage: '/message/listQueryByPage',
    insert: '/message/save',
    update: '/message/update',
    delete: '/message/delete',
    deleteAll: '/message/deleteAll',
    sendMessage: '/message/updateField',
  };

  constructor(help: Help) {
    super(help);
  }

  getMessageViewById(data: any) {
    return this.help.post(this.url.listByPage, data);
  }

  sendMessage(params) {
    return this.help.post(this.url.sendMessage, params);
  }
}
