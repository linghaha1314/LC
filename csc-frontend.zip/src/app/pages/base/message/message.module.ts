import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {MessageRoutingModule} from './message-routing.module';
import {ListComponent} from "./list/list.component";
import {MessageService} from "./message.service";
import {NZ_I18N, zh_CN} from 'ng-zorro-antd/i18n';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzDescriptionsModule} from 'ng-zorro-antd/descriptions';
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {NzPageHeaderModule} from 'ng-zorro-antd/page-header';
import {NzPopconfirmModule} from 'ng-zorro-antd/popconfirm';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzResultModule} from 'ng-zorro-antd/result';
import {NzSpinModule} from 'ng-zorro-antd/spin';
import {NzTableModule} from 'ng-zorro-antd/table';
import {NzToolTipModule} from 'ng-zorro-antd/tooltip';
import {NzUploadModule} from 'ng-zorro-antd/upload';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {LoadStatusModule} from "../../../component/load-status/load-status.module";
import {EditComponent} from "./edit/edit.component";
import {ViewComponent} from "./view/view.component";
import {FormComboModule} from "../../../component/form/combobox/form-combo.module";
import {FormUploadModule} from "../../../component/form/uploadbox/form-upload.module";
import {FroalaEditorModule} from "../../../component/form/froala-editor/froala-editor.module";
import {SafeHtmlModule} from "../../../pipe/SafeHtml.module";
import {NzTypographyModule} from "ng-zorro-antd/typography";
import {AttachViewerModule} from "../../../component/attach-viewer/attach-viewer.module";


@NgModule({
  declarations: [ListComponent, EditComponent, ViewComponent],
  imports: [
    CommonModule,
    MessageRoutingModule,
    NzInputModule,
    FormsModule,
    NzTableModule,
    NzPopconfirmModule,
    NzButtonModule,
    NzToolTipModule,
    NzIconModule,
    NzGridModule,
    NzDescriptionsModule,
    NzSpaceModule,
    NzBadgeModule,
    NzResultModule,
    NzSpinModule,
    LoadStatusModule,
    ReactiveFormsModule,
    NzRadioModule,
    NzFormModule,
    NzPageHeaderModule,
    FormComboModule,
    FormUploadModule,
    NzUploadModule,
    FroalaEditorModule,
    SafeHtmlModule,
    NzTypographyModule,
    AttachViewerModule
  ],
  providers: [MessageService, NzModalService, NzMessageService, {provide: NZ_I18N, useValue: zh_CN}]
})
export class MessageModule {
}
