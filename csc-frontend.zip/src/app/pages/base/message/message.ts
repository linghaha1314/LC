export class Message {
  id: string;
  title: string;
  content: string;
  categoryId: string;
  senderId: string;
  userId: string;
  attachs: any;
  categoryName: string;
  senderName: string;
  receiverIds: string;
  status: number;
  created: any;
  code: any;
  messageKind: string;
  groupId: string;
  groupIds: string;
}
