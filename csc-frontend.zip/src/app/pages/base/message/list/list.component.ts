import {Component, OnInit} from '@angular/core';
import {Message} from '../message';
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {MessageService} from "../message.service";

@Component({
  selector: 'dictionary-type-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Message> implements OnInit {

  label = "title";

  constructor(modal: NzModalService, public service: MessageService, message: NzMessageService) {
    super(modal, service, message);
  }

  sendMessage(id) {
    this.loading = true;
    this.service.sendMessage({id, status: 1}).subscribe((res: any) => {
      if (res.success) {
        this.message.success('发送成功!');
        this.searchData();
      }
    });
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
