import {Component, OnInit} from '@angular/core';
import {MessageService} from "../message.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {Message} from "../message";

@Component({
  selector: 'dictionary-type-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: Message = new Message();

  loading = false;

  constructor(private service: MessageService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.loading = true;
    this.route.paramMap.subscribe((params: ParamMap) => {
      if (params.get('id')) {
        this.service.getMessageViewById({id: params.get('id'), typeCode: "view"}).subscribe((res: any) => {
          this.loading = false;
          if (res.total > 0) {
            this.data = res.rows[0];
          }
        });
      }
    });
  }

}
