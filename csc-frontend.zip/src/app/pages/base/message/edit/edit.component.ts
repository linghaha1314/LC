import {Component, OnInit} from '@angular/core';
import {Message} from '../message';
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {MessageService} from '../message.service';
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'message-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Message> implements OnInit {

  isFlag = false;

  isOtherFlag = false;

  groupFlag = false;

  groupUrl: String = "";

  queryGroupParams: any = {};

  constructor(location: Location, service: MessageService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Message());
        }
      })
    ).subscribe(d => {
      const list = [];
      if (d.receiverIds != null) {
        d.receiverIds.split(",").forEach(v => {
          list.push({id: v, name: '该用户不存在'});
        });
      }
      const groupList = [];
      if (d.groupIds != null) {
        d.groupIds.split(",").forEach(v => {
          groupList.push({id: v, name: '该组不存在'});
        });
      }

      this.validateForm = this.fb.group({
        id: [d.id],
        title: [d.title, [Validators.required]],
        content: [d.content, [Validators.required]],
        receiverId: [list],
        categoryId: [d.categoryId],
        messageKind: [d.messageKind],
        groupId: [groupList],
        status: 0,
        attachs: [d.attachs]
      });

      if (d.code != null || d.code != undefined) {
        if (d.code == 'RoleMessage' || d.code == 'GroupMessage') {
          this.getMessageKind(d.code);
        } else {
          this.isOtherFlag = true;
          this.getRows(d.code);
        }
      }

      this.isLoading = false;
    });
  }


  getMessageKind(rows: any) {
    if (rows.id != undefined && rows.id != '') {
      this.validateForm.get("groupId").reset();
      this.validateForm.get("receiverId").reset();
      this.validateForm.get("categoryId").reset();
      this.queryGroupParams = {};
    }

    const code = rows.code == undefined ? rows : rows.code;
    if (code == 'other') {
      this.isOtherFlag = true;
      this.groupFlag = false;
    } else {
      this.isOtherFlag = false;
      this.groupFlag = true;
      this.isFlag = false;
      if (code == 'GroupMessage') {
        this.groupUrl = '/group/listQueryByPage';
        this.queryGroupParams = {status: 1};
      } else if (code == 'RoleMessage') {
        this.groupUrl = '/roles/listQueryByPage';
        this.queryGroupParams = {status: 0};
      }
    }
  }

  getRows(rows: any) {
    if (rows != undefined || rows != null || rows != '') {
      const code = rows.code == undefined ? rows : rows.code;
      this.isFlag = code == 'UserMessage';
      if (rows.hasOwnProperty("id")){
        this.validateForm.patchValue({categoryId: rows.id});
      }
    }
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    let params = this.validateForm.value;
    if (params.receiverId != null) {
      let list = [];
      params.receiverId.forEach(item => {
        if (item.hasOwnProperty("id")) {
          list.push(item["id"]);
        } else {
          list.push(item);
        }
      })
      params.receiverId = list;
    }
    if (params.groupId != null) {
      let list = [];
      params.groupId.forEach(item => {
        if (item.hasOwnProperty("id")) {
          list.push(item["id"]);
        } else {
          list.push(item);
        }
      })
      params.groupId = list;
    }
    this.service.saveOrUpdateData(params).subscribe(res => {
      if (res.success) {
        this.saveSuccess(res.data);
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            if (back) {
              this.location.back();
            } else {
              this.validateForm.reset();
            }
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }

}
