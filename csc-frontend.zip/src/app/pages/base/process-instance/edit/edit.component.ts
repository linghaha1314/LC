import {Component, OnInit} from "@angular/core";
import {ProcessInstance} from "../process-instance";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {ProcessInstanceService} from "../process-instance.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";
import {CdkDragDrop, moveItemInArray} from "@angular/cdk/drag-drop";

@Component({
  selector: 'process-instance-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<ProcessInstance> implements OnInit {

  details: Array<any> = [];

  detailVisible = false;

  detail: string;

  label: string;

  private editDetailIndex: number;

  constructor(public location: Location, public service: ProcessInstanceService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(250)]],
      key: [null, [Validators.required, Validators.maxLength(100)]],
      remark: [null, [Validators.maxLength(500)]],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      userId: [null, [Validators.maxLength(40)]],
      created: [null],
      userName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new ProcessInstance());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
        this.service.queryDetails({processId: d.id}).subscribe(({rows}) => {
          this.details = rows;
          this.isLoading = false;
        });
      } else {
        this.isLoading = false;
      }
    });
  }

  showModal(index: number) {
    this.editDetailIndex = index;
    if (index != null) {
      this.detail = this.details[index].name.trim();
      this.label = this.details[index].label;
    } else {
      this.detail = null;
      this.label = null;
    }
    this.detailVisible = true;
  }

  addData() {
    if (this.detail && this.detail.trim().length > 0) {
      if (this.editDetailIndex != null) {
        this.details[this.editDetailIndex].name = this.detail.trim();
        this.details[this.editDetailIndex].label = this.label;
      } else {
        this.details.push({name: this.detail.trim(), label: this.label, step: this.details.length});
      }
      this.detailVisible = false;
      this.detail = null;
      this.label = null;
      this.editDetailIndex = null;
    } else {
      this.message.error('请输入名称');
    }
  }

  dropStep(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.details, event.previousIndex, event.currentIndex);
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        this.saveSuccess(res.data);
        const list = [...this.details];
        list.forEach(r => {
          r.processId = res.data.id;
        });
        this.service.saveDetails(list).subscribe(r => {
          if (r.success) {
            this.saveAfter();
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }

  saveAfter() {
    this.service.refreshData().subscribe(d => {
      if (d) {
        this.message.success('保存成功!');
        this.isLoading = false;
        this.location.back();
      }
    });
  }

  deleteDetails(index: number) {
    const detailId = this.details[index].id;
    if (detailId) {
      this.service.deleteDetailById(detailId).subscribe();
    }
    this.details.splice(index, 1);
  }
}
