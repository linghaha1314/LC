import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {ProcessInstance} from "./process-instance";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class ProcessInstanceService extends BaseService<ProcessInstance> {
  protected url = {
    listByPage: '/processinstance/listQueryByPage',
    insert: '/processinstance/save',
    update: '/processinstance/update',
    delete: '/processinstance/delete',
    deleteAll: '/processinstance/deleteAll',
    saveDetails: '/processdetail/saveOrUpdateList',
    queryDetail: '/processdetail/listQueryByPage',
    deleteDetail: '/processdetail/delete',
  };

  constructor(help: Help) {
    super(help);
  }

  saveDetails(params: Array<any>) {
    return this.help.post(this.url.saveDetails, params);
  }

  queryDetails(params: any) {
    return this.help.post(this.url.queryDetail, params);
  }

  deleteDetailById(detailId: string) {
    return this.help.post(this.url.deleteDetail, {id: detailId});
  }
}
