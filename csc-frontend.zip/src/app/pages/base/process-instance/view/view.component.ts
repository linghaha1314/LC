import {Component, OnInit} from '@angular/core';
import {ProcessInstance} from "../process-instance";
import {ProcessInstanceService} from "../process-instance.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'process-instance-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: ProcessInstance = new ProcessInstance();

  list: Array<any> = [];

  constructor(private service: ProcessInstanceService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new ProcessInstance());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
        this.service.queryDetails({processId: d.id}).subscribe(({rows}) => {
          this.list = rows;
        });
      } else {
        this.empty = true;
      }
    });
  }

}
