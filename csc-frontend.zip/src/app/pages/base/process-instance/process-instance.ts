export class ProcessInstance {
  id: string;
  name: string;
  key: string;
  remark: string;
  status: number;
  hospitalId: string;
  userId: string;
  created: any;
  userName: string;
}
