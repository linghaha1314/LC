import {Component, OnInit} from "@angular/core";
import {Sections} from "../sections";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {SectionsService} from "../sections.service";
import {NzFormatEmitEvent} from 'ng-zorro-antd/tree';
import {Help} from "../../../../utils/Help";
import {ImportConfig} from "../../../../component/import-data/import-data";

@Component({
  selector: 'sections-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Sections> implements OnInit {

  importConfig: ImportConfig = {
    url: '/sections/importSections',
    template: '/xlsx/sections.xls',
    validateUrl: '/sections/validateData',
    columns: [
      {field: 'name', text: '科室名称', editor: {type: "string", require: true}},
      {field: 'code', text: '编码', editor: {type: "string", require: true}},
      {field: 'sort', text: '排序', editor: {type: "number", require: true}},
      {field: 'parentName', text: '父级', editor: {type: "combo", valueKey: "name", url: "/sections/listQueryByPage"}},
    ]
  };
  nodes: any[] = [
    {title: '全部科室', key: '0'}
  ];

  constructor(public modal: NzModalService, public service: SectionsService, public message: NzMessageService, private help: Help) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }


  nzEvent(event: NzFormatEmitEvent): void {
    const id = event.keys[0] === '' ? '0' : event.keys[0];
    if (event.eventName === 'expand') {
      const node = event.node;
      if (node?.getChildren().length === 0 && node?.isExpanded) {
        this.loadNode(id, node);
      }
    }
  }

  activeNode(data: NzFormatEmitEvent): void {
    const obj = data.node.origin;
    if (obj.isLeaf) {
      this.queryParams = {id: obj.id};
    } else {
      this.queryParams = {parentId: obj.id};
    }
    this.reloadData();
  }

  loadNode(parentId: String, node: any) {
    node.clearChildren();
    this.loading = true;
    this.service.getTreeList(parentId).subscribe(data => {
      const arr = this.changeDataArr(data);
      node.addChildren(arr);
      this.nodes = [...this.nodes];
    }, ({error}) => {
      this.loading = false;
      this.message.error(`请求出现错误: ${error.msg}`);
    });
    this.loading = false;
  }

  changeDataArr(arr: any[]) {
    arr.map(item => {
      item.title = item.name;
      item.key = item.id;
      if (item.childCount) {
        item.children = [];
        item.isLeaf = false;
      } else {
        item.isLeaf = true;
      }
    });
    return arr;
  }

  searchData(search: boolean = false): void {
    if (search) {
      this.pageIndex = 1;
    }
    this.service.changeNum(this.pageIndex, this.pageSize);
    this.getData();
    this.nodes = [
      {title: '全部科室', key: '0'}
    ];
  }

}
