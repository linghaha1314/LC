import {Component, OnInit} from "@angular/core";
import {Sections} from "../sections";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {SectionsService} from "../sections.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'sections-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Sections> implements OnInit {

  parentId: any;

  constructor(public location: Location, public service: SectionsService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Sections());
        }
      })
    ).subscribe(d => {

      if (d.parentId != undefined) {
        this.parentId = d.parentId;
      } else {
        this.parentId = 0;
      }
      this.validateForm = this.fb.group({
        id: [d.id],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        code: [d.code, [Validators.required, Validators.maxLength(50)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        sort: [d.sort, [Validators.required, Validators.maxLength(11)]],
        remark: [d.remark],
        parentId: this.parentId
      });
      this.isLoading = false;
    });
  }

  compileData(rows) {
    rows.splice(0, 0, {id: '0', name: '全部'});
  }

}
