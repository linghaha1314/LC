export class Sections {
  id: string;
  name: string;
  code: string;
  parentId: string;
  directionSectionId: string;
  status: number;
  sort: number;
  remark: string;
  hospitalId: string;
  userId: string;
  created: any;
  parentName: string;
  directionSectionName: string;
  userName: string;
}
