import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Sections} from "./sections";
import {Help} from "../../../utils/Help";
import {Observable} from "rxjs";
import {map} from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class SectionsService extends BaseService<Sections> {
  protected url = {
    listByPage: '/sections/listQueryByPage',
    insert: '/sections/save',
    update: '/sections/updateField',
    delete: '/sections/delete',
    deleteAll: '/sections/deleteAll',
    getTreeList: '/sections/getTreeList',
    importData: '/sections/importExcel'
  };

  constructor(help: Help) {
    super(help);
  }

  getTreeList(parentId: String): Observable<any> {
    return this.help.post(this.url.getTreeList, {parentId})
      .pipe(map((res: any) => {
        return res.rows;
      }));
  }

  importData(params) {
    return this.help.post(this.url.importData, params);
  }


}
