import {Component, OnInit} from '@angular/core';
import {Sections} from "../sections";
import {SectionsService} from "../sections.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'sections-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: Sections = new Sections();

  constructor(private service: SectionsService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Sections());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
