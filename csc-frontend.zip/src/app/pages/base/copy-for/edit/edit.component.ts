import {Component, OnInit} from "@angular/core";
import {CopyFor} from "../copy-for";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {CopyForService} from "../copy-for.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'copy-for-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<CopyFor> implements OnInit {

  constructor(public location: Location, public service: CopyForService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      staffId: [null, [Validators.required, Validators.maxLength(40)]],
      url: [null, [Validators.required, Validators.maxLength(200)]],
      infoId: [null, [Validators.required, Validators.maxLength(40)]],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      userId: [null, [Validators.maxLength(40)]],
      created: [null],
      hospitalId: [null, [Validators.maxLength(40)]],
      staffName: [null],
      infoName: [null],
      userName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new CopyFor());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

}
