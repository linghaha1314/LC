export class CopyFor {
  id: string;
  staffId: string;
  url: string;
  infoId: string;
  status: number;
  userId: string;
  created: any;
  hospitalId: string;
  staffName: string;
  infoName: string;
  userName: string;
}
