import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {CopyFor} from "./copy-for";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class CopyForService extends BaseService<CopyFor> {
  protected url = {
    listByPage: '/copyfor/listQueryByPage',
    insert: '/copyfor/save',
    update: '/copyfor/update',
    delete: '/copyfor/delete',
    deleteAll: '/copyfor/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
