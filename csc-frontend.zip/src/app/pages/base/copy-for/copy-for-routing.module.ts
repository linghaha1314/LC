import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '抄送记录列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '抄送记录详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加抄送记录'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑抄送记录'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CopyForRoutingModule {
}
