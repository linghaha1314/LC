import {Component, OnInit} from '@angular/core';
import {PrepareProcess} from "../prepare-process";
import {PrepareProcessService} from "../prepare-process.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'prepare-process-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  listLoading = true;

  plans: any[] = [];

  data: PrepareProcess = new PrepareProcess();

  constructor(private service: PrepareProcessService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new PrepareProcess());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
        this.service.queryPlan({processId: d.id}).subscribe(d => {
          this.plans = d;
          this.listLoading = false;
        });
      } else {
        this.empty = true;
      }
    });

  }

}
