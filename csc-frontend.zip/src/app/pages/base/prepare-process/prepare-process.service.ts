import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {PrepareProcess} from "./prepare-process";
import {Help} from "../../../utils/Help";
import {Observable} from "rxjs";
import {map} from "rxjs/operators";


@Injectable({
  providedIn: 'root'
})
export class PrepareProcessService extends BaseService<PrepareProcess> {
  protected url = {
    listByPage: '/prepareprocess/listQueryByPage',
    insert: '/prepareprocess/save',
    update: '/prepareprocess/update',
    delete: '/prepareprocess/delete',
    deleteAll: '/prepareprocess/deleteAll',
    updateField: '/prepareprocess/updateField',
    getDictionary: '/dictionarydata/getByCodes',
    savePlan: '/prepareplan/save',
    updatePlan: '/prepareplan/update',
    deletePlan: '/prepareplan/delete',
    queryPlan: '/prepareplan/listQueryByPage',
  };

  constructor(help: Help) {
    super(help);
  }

  getTypeIdByCode(code: string): Observable<any> {
    return this.help.post(this.url.getDictionary, {typeCode: 'PrepareProcess', code}).pipe(map((res: any) => {
      if (res.success) {
        return res.data.id;
      }
      return null;
    }));
  }

  savePlan(data: any): Observable<any> {
    let url = this.url.savePlan;
    if (data['id']) {
      url = this.url.updatePlan;
    }
    return this.help.post(url, data);
  }

  queryPlan(params: any) {
    return this.help.post(this.url.queryPlan, params)
      .pipe(map((res: any) => {
        return res.rows;
      }));
  }

  deletePlan(planId: string) {
    return this.help.post(this.url.deletePlan, {id: planId});
  }

  updateField(data: any) {
    return this.help.post(this.url.updateField, data);
  }
}
