export class PrepareProcess {
  id: string;
  name: string;
  content: string;
  typeId: string;
  releaseDate: any;
  status: number;
  hospitalId: string;
  userId: string;
  created: any;
  typeName: string;
  userName: string;
}
