import {Component, OnInit} from "@angular/core";
import {PrepareProcess} from "../prepare-process";
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {PrepareProcessService} from "../prepare-process.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'prepare-process-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<PrepareProcess> implements OnInit {

  constructor(public modal: NzModalService, public service: PrepareProcessService, public message: NzMessageService, private route: ActivatedRoute) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('code')) {
          return this.service.getTypeIdByCode(params.get('code'));
        } else {
          return null;
        }
      })
    ).subscribe(d => {
      this.queryParams['typeId'] = d;
      this.getData();
    });
  }

  release(data: any) {
    this.service.updateField({id: data.id, status: 1}).subscribe( res => {
      if (res.success) {
        this.reloadData();
      }
    });
  }

  unRelease(data: any) {
    this.service.updateField({id: data.id, status: 0}).subscribe( res => {
      if (res.success) {
        this.reloadData();
      }
    });
  }
}
