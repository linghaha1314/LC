import {Component, OnInit} from "@angular/core";
import {PrepareProcess} from "../prepare-process";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {PrepareProcessService} from "../prepare-process.service";
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {formatDate, Location} from '@angular/common';
import { NzMessageService } from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'prepare-process-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<PrepareProcess> implements OnInit {

  memberModal = false;

  memberLoading = false;

  listLoading = false;

  memberForm: FormGroup;

  plans: any[] = [];

  constructor(public location: Location, public service: PrepareProcessService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    const {typeId}: any = this.location.getState();
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(200)]],
      content: [null, [Validators.required]],
      typeId: [null],
      releaseDate: [null],
      status: [null],
      hospitalId: [null],
      userId: [null],
      created: [null],
      typeName: [null],
      userName: [null],
    });
    this.createMemberForm();
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new PrepareProcess());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
        this.memberForm.get('processId').setValue(d.id);
      } else {
        this.validateForm.get('typeId').setValue(typeId);
      }
      this.isLoading = false;
      this.queryPlan();
    });
  }

  createMemberForm() {
    this.memberForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      created: [null],
      processId: [null, [Validators.required, Validators.maxLength(40)]],
      staffId: [null, [Validators.required, Validators.maxLength(40)]],
      content: [null, [Validators.required]],
      startDate: [null, [Validators.required]],
      endDate: [null, [Validators.required]],
      sort: [null],
      status: [null],
      processName: [null],
      staffName: [null],
      date: [null],
    });
  }

  queryPlan() {
    const id = this.validateForm.get('id').value;
    if (id == null) { return; }
    this.listLoading = true;
    this.service.queryPlan({processId: id}).subscribe(d => {
      this.plans = d;
      this.listLoading = false;
    });
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        this.validateForm.patchValue(res.data);
        this.memberForm.get('processId').setValue(res.data.id);
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }

  saveMember() {
    if (!this.memberForm.valid) {
      this.message.error('验证错误,请检查表单内容!');
      return;
    }
    this.memberLoading = true;
    this.service.savePlan(this.memberForm.value).subscribe(res => {
      this.memberLoading = false;
      if (res.success) {
        this.memberModal = false;
        this.memberForm.get('staffId').setValue(null);
        this.memberForm.get('content').setValue(null);
        this.memberForm.get('date').setValue(null);
        this.queryPlan();
      }
    }, error => {
      this.memberLoading = false;
    });
  }

  setDateValue(d: Date[]) {
    if (d == null) {
      this.memberForm.get('startDate').setValue(null);
      this.memberForm.get('endDate').setValue(null);
      return;
    }
    this.memberForm.get('startDate').setValue(formatDate(d[0], 'yyyy-MM-dd HH:mm:ss', 'zh'));
    this.memberForm.get('endDate').setValue(formatDate(d[1], 'yyyy-MM-dd HH:mm:ss', 'zh'));
  }

  toABC(i: number) {
    return 'abcdefghijklmnopqrstuvwxyz'.charAt(i).toUpperCase();
  }

  showMemberModal(d: any) {
    d.date = [new Date(d.startDate), new Date(d.endDate)];
    this.memberForm.setValue(d);
    this.memberModal = true;
  }

  deletePlan(planId: string) {
    this.listLoading = true;
    this.service.deletePlan(planId).subscribe(res => {
      this.listLoading = false;
      if (res.success) {
        this.queryPlan();
      }
    }, error => {
      this.listLoading = false;
    });
  }
}
