import {Component, OnInit} from "@angular/core";
import {Group} from "../group";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {GroupService} from "../group.service";
import {Router} from "@angular/router";

@Component({
  selector: 'group-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Group> implements OnInit {
  dataMap = {};
  keysList = [];

  constructor(modal: NzModalService, service: GroupService, message: NzMessageService, public router: Router) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }

  skipRouter(id: string): void {
    this.router.navigate(["/students/list/" + id]).then();
  }

  showModal(storehouse) {
    // this.isVisible = true;

  }

  routeActive(storehouse, r) {
    // this.service.storehouse = storehouse;
    // this.router.navigate([r, storehouse.id], {queryParams: {id: storehouse.id}});
  }
}
