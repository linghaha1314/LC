import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";
import {AddMemberComponent} from "./add-member/add-member.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '群组列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '群组详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加群组'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑群组'}},
  {path: 'add-member/:id', component: AddMemberComponent, data: {title: '添加成员'}},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GroupRoutingModule {
}
