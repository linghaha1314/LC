export class Group {
  id: string;
  name: string;
  describe: string;
  remark: string;
  hospitalId: string;
  created: any;
  status: number;
}
