import {Component, OnInit} from "@angular/core";
import {Group} from "../group";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {GroupService} from "../group.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'group-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Group> implements OnInit {

  constructor(location: Location, service: GroupService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Group());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id],
        name: [d.name, [Validators.required, Validators.maxLength(250)]],
        describe: [d.describe, [Validators.required, Validators.maxLength(500)]],
        remark: [d.remark, [Validators.maxLength(500)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
      });
      this.isLoading = false;
    });
  }

}
