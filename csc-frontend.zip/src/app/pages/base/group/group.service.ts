import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Group} from "./group";
import {Help} from "../../../utils/Help";
import {NzMessageService} from 'ng-zorro-antd/message';


@Injectable({
  providedIn: 'root'
})
export class GroupService extends BaseService<Group> {
  url = {
    listByPage: '/group/listQueryByPage',
    insert: '/group/save',
    update: '/group/update',
    delete: '/group/delete',
    deleteAll: '/group/deleteAll',
    getGroupMember: '/groupmember/listQueryByPage',
    addMember: '/groupmember/save',
    deleteMember: '/groupmember/deleteMember',
    saveOrDel: '/groupmember/saveMembers',
    staffList: '/staff/listQueryByPage',
    updateList: '/staff/saveOrUpdateList'
  };

  constructor(help: Help, public message: NzMessageService) {
    super(help);
  }


  getGroupMember(params) {
    return this.help.post(this.url.getGroupMember, params);
  }

  saveOrDel(params) {
    return this.help.post(this.url.saveOrDel, params);
  }

  staffList(params) {
    return this.help.post(this.url.staffList, params);
  }

  updateStaffList(params) {
    return this.help.post(this.url.updateList, params);
  }
}
