export class Hospitals {
  id: string;
  code: string;
  name: string;
  areaId: string;
  brief: string;
  contactName: string;
  contactPhone: string;
  status: number;
  created: any;
  domain: string;
  areaName: string;
}
