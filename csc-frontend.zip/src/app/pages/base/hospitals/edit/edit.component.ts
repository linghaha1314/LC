import {Component, OnInit} from "@angular/core";
import {Hospitals} from "../hospitals";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {HospitalsService} from "../hospitals.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'hospitals-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Hospitals> implements OnInit {

  constructor(location: Location, service: HospitalsService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Hospitals());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        code: [d.code, [Validators.required, Validators.maxLength(30)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        // areaId: [d.areaId, [Validators.required, Validators.maxLength(40)]],
        brief: [d.brief, [Validators.maxLength(255)]],
        contactName: [d.contactName, [Validators.required, Validators.maxLength(20)]],
        contactPhone: [d.contactPhone, [Validators.required, Validators.maxLength(20)]],
        status: [d.status || 1, [Validators.required, Validators.maxLength(11)]],
        created: [d.created],
        domain: [d.domain, [Validators.maxLength(100)]],
      });
      this.isLoading = false;
    });
  }

}
