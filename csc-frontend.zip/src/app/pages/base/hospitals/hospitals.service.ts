import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Hospitals} from "./hospitals";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class HospitalsService extends BaseService<Hospitals> {
  url = {
    listByPage: '/hospitals/listQueryByPage',
    insert: '/hospitals/save',
    update: '/hospitals/update',
    delete: '/hospitals/delete',
    deleteAll: '/hospitals/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
