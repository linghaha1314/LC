export class Schedule {
  id: string;
  name: string;
  content: string;
  startDate: any;
  endDate: any;
  typeId: string;
  endParams: string;
  notifyParams: string;
  address: string;
  remark: string;
  userId: string;
  created: any;
  attachs: string;
  status: number;
  hospitalId: string;
  urgentStatus: number;
  staffId: string;
  completeDate: any;
  sort: number;
  typeName: string;
  userName: string;
  staffName: string;
}
