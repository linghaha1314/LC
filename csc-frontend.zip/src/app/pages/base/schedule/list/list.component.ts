import {Component, OnInit} from "@angular/core";
import {Schedule} from "../schedule";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {ScheduleService} from "../schedule.service";

@Component({
  selector: 'schedule-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Schedule> implements OnInit {

  constructor(public modal: NzModalService, public service: ScheduleService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
  }

  complete(id) {
    this.service.complete({id: id, status: 1}).subscribe(res => {
      if (res.success) {
        this.message.success('修改成功!');
        this.reloadData();
      }
    });
  }
}
