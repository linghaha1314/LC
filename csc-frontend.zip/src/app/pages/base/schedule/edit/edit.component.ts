import {Component, OnInit} from "@angular/core";
import {Schedule} from "../schedule";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {ScheduleService} from "../schedule.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'schedule-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Schedule> implements OnInit {

  detailFlag = false;

  endParams: any = {};

  notifyParams: any = {
    repeat: 0,
    days: {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false
    },
    times: {
      punctuality: false,
      fiveMinutesAgo: false,
      tenMinutesAgo: false,
      thirtyMinutesAgo: false,
      oneHourAgo: false,
      oneDayAgo: false,
      threeDayAgo: false,
    }
  };

  constructor(public location: Location, public service: ScheduleService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(250)]],
      content: [null],
      startDate: [null, [Validators.required]],
      endDate: [null, [Validators.required]],
      typeId: ['NoRepeat', [Validators.required, Validators.maxLength(40)]],
      endParams: [null],
      notifyParams: [null],
      address: [null, [Validators.maxLength(500)]],
      remark: [null, [Validators.maxLength(500)]],
      userId: [null, [Validators.maxLength(40)]],
      created: [null],
      attachs: [null],
      status: [0, [Validators.maxLength(11)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      urgentStatus: [null, [Validators.required, Validators.maxLength(11)]],
      staffId: [null],
      completeDate: [null],
      sort: [null],
      typeName: [null],
      userName: [null],
      staffName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Schedule());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.endParams = JSON.parse(d.endParams);
        this.notifyParams = JSON.parse(d.notifyParams);
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

  submitForm(back: boolean = true) {
    this.validateForm.value.endParams = JSON.stringify(this.endParams);
    this.validateForm.value.notifyParams = JSON.stringify(this.notifyParams);
    super.submitForm(back);
  }

}
