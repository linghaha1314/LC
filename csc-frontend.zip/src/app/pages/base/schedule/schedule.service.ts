import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Schedule} from "./schedule";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class ScheduleService extends BaseService<Schedule> {
  protected url = {
    listByPage: '/schedule/listQueryByPage',
    insert: '/schedule/save',
    update: '/schedule/update',
    delete: '/schedule/delete',
    deleteAll: '/schedule/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

  complete(data: any) {
    return this.help.post('/schedule/updateField', data);
  }
}
