import {Component, OnInit} from '@angular/core';
import {Schedule} from "../schedule";
import {ScheduleService} from "../schedule.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'schedule-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: Schedule = new Schedule();

  endParams: any = {};

  notifyParams: any = {
    repeat: 0,
    days: {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false
    },
    times: {
      punctuality: false,
      fiveMinutesAgo: false,
      tenMinutesAgo: false,
      thirtyMinutesAgo: false,
      oneHourAgo: false,
      oneDayAgo: false,
      threeDayAgo: false,
    }
  };

  constructor(private service: ScheduleService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Schedule());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.endParams = JSON.parse(d.endParams);
        this.notifyParams = JSON.parse(d.notifyParams);
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
