import {Component, OnInit} from "@angular/core";
import {Majors} from "../majors";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {MajorsService} from "../majors.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'majors-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Majors> implements OnInit {

  constructor(public location: Location, public service: MajorsService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Majors());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        code: [d.code, [Validators.required, Validators.maxLength(50)]],
        typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
        remark: [d.remark, [Validators.maxLength(200)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        facultyId: [d.facultyId, [Validators.required, Validators.maxLength(40)]],
        facultyName: [d.facultyName],
        created: [d.created],
        hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        typeName: [d.typeName],
      });
      this.isLoading = false;
    });
  }

}
