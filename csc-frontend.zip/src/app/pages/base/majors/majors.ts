export class Majors {
  id: string;
  name: string;
  code: string;
  typeId: string;
  remark: string;
  status: number;
  created: any;
  hospitalId: string;
  typeName: string;
  facultyId: string;
  facultyName: string;
}
