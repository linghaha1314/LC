import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Majors} from "./majors";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class MajorsService extends BaseService<Majors> {
  protected url = {
    listByPage: '/majors/listQueryByPage',
    insert: '/majors/save',
    update: '/majors/update',
    delete: '/majors/delete',
    deleteAll: '/majors/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
