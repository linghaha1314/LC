import {Component, OnInit} from "@angular/core";
import {PreparePlan} from "../prepare-plan";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {PreparePlanService} from "../prepare-plan.service";
import {FormBuilder} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'prepare-plan-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<PreparePlan> implements OnInit {

  constructor(public location: Location, public service: PreparePlanService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of({id: null});
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        console.log(d);
      }
      this.isLoading = false;
    });
  }

}
