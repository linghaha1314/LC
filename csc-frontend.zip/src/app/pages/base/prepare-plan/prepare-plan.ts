export class PreparePlan {
  id: string;
  created: any;
  processId: string;
  staffId: string;
  content: string;
  startDate: any;
  endDate: any;
  sort: number;
  status: number;
  processName: string;
  staffName: string;
}
