import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {PreparePlan} from "./prepare-plan";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class PreparePlanService extends BaseService<PreparePlan> {
  protected url = {
    listByPage: '/prepareprocess/listMyData',
    insert: '/prepareplan/save',
    update: '/prepareplan/update',
    delete: '/prepareplan/delete',
    deleteAll: '/prepareplan/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
