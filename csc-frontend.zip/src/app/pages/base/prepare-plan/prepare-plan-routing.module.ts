import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '筹备安排列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '筹备安排详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加筹备安排'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑筹备安排'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PreparePlanRoutingModule {
}
