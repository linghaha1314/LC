export class Accounts {
  id: string;
  username: string;
  password: string;
  accountLocked: string;
  hospitalId: string;
  staffId: string;
  remark: string;
  status: number;
  created: any;
}
