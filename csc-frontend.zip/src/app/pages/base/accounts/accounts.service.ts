import {Injectable} from '@angular/core';
import {BaseService} from "../../../component/base/base.service";
import {Accounts} from "./accounts";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class AccountsService extends BaseService<Accounts> {
  url = {
    listByPage: '/accounts/listQueryByPage',
    insert: '/accounts/save',
    update: '/accounts/update',
    delete: '/accounts/delete',
    deleteAll: '/accounts/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
