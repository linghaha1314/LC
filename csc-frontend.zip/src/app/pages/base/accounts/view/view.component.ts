import {Component, OnInit} from '@angular/core';
import {AccountsService} from "../accounts.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";
import {Accounts} from "../accounts";

@Component({
  selector: 'accounts-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: Accounts = new Accounts();

  constructor(private service: AccountsService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Accounts());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
