import {Component, OnInit} from '@angular/core';
import {Accounts} from '../accounts';
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {AccountsService} from '../accounts.service';
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'accounts-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Accounts> implements OnInit {


  constructor(location: Location, service: AccountsService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Accounts());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id],
        name: [d.username, [Validators.required]],
        password: [d.password, [Validators.required]],
        accountLocked: [d.accountLocked, [Validators.required]],
        hospitalId: [d.hospitalId, [Validators.required]],
        staffId: [d.staffId, [Validators.required]],
        status: [d.status, [Validators.required]],
        remark: [d.remark]
      });
      this.isLoading = false;
    });
  }

}
