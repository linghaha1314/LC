import {Component, OnInit} from '@angular/core';
import {Accounts} from '../accounts';
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {AccountsService} from "../accounts.service";

@Component({
  selector: 'accounts-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Accounts> implements OnInit {

  constructor(modal: NzModalService, service: AccountsService, message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
