import {Component, OnInit} from "@angular/core";
import {Department} from "../department";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {DepartmentService} from "../department.service";
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzFormatEmitEvent} from "ng-zorro-antd/tree";
import {NzContextMenuService, NzDropdownMenuComponent} from "ng-zorro-antd/dropdown";
import {ImportConfig} from "../../../../component/import-data/import-data";

@Component({
  selector: 'department-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Department> implements OnInit {
  validateForm: FormGroup;
  validateKeyForm: FormGroup = null;

  nodes: any[] = [
    {title: '学校', key: ''}
  ];

  node;

  currentNode;

  isShowBtn = true;

  isTitle = '教研室编辑';

  isShow = false;

  isLoading = false;

  parentId = '';

  action = '';

  tabsData: any;

  staffData: any[];

  departmentId = ''; // 当前选中的id

  typeId = ''; // 当前选中tab的id

  total: number;

  name = '';

  isKeyVisible = false;

  staffId;
  importConfig: ImportConfig = {
    url: '/personnelunit/importPersonnelunit',
    template: '/xlsx/personnelunit.xls',
    validateUrl: '/personnelunit/validateData',
    columns: [
      {field: 'name', text: '单位名称', editor: {type: "string", require: true}},
      {field: 'address', text: '所在省市', editor: {type: "string", require: true}},
      {field: 'levelName', text: '等级', editor: {type: "string", require: true}},
      {field: 'contactPerson', text: '联系人', editor: {type: "string", require: true}},
      {field: 'contactAddress', text: '联系地址', editor: {type: "string", require: true}},
    ]
  };

  constructor(
    public modal: NzModalService,
    private nzContextMenuService: NzContextMenuService,
    private fb: FormBuilder,
    public service: DepartmentService,
    public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
    this.initForm();
    this.getTabsData();
    this.getStaffData();
  }

  expandClick(el) {
    const node = el.node;
    if (node.getChildren().length === 0 && node?.isExpanded) {
      const id = el.node.key;
      this.getNodeData(id, el.node);
    }
  }

  techClick(event) {
    this.departmentId = event.node.key;
    if (event.node.origin.staffCount === 0) {
      this.staffData = [];
      this.total = 0;
    } else {
      this.getStaffData();
    }
  }

  contextMenu($event: NzFormatEmitEvent, menu: NzDropdownMenuComponent) {
    this.currentNode = $event.node.origin;
    this.node = $event.node;
    this.parentId = this.node.key;
    this.nzContextMenuService.create($event.event, menu);
    this.isShowBtn = !!this.currentNode.id;
  }

  selectDropdown(str): void {
    this.action = str;
    if (str === 'add') {
      this.isShow = true;
      this.validateForm.reset();
    } else if (str === 'edit') {
      this.isShow = true;
      const d = this.node.origin;
      this.validateForm.patchValue(d);
    } else {
      if (this.currentNode.id) {
        this.message.info('正在删除...');
        this.service.delete({id: this.currentNode.id}).subscribe(res => {
          this.node.remove();
          this.message.remove();
        });
      } else {
        this.message.info('此菜单不能删除!');
      }
    }
  }

  okClick() {
    this.isShow = false;
    this.node.origin.isLeaf = false;
    this.node.clearChildren();
    this.nodes = [...this.nodes];
    this.submitMenusForm();
  }

  cancelClick() {
    this.isShow = false;
  }

  initForm() {
    this.validateForm = this.fb.group({
      id: [null],
      name: [null, [Validators.required]],
      code: [null, [Validators.required]],
      hospitalId: [null],
      parentId: [null, [Validators.required]],
      sort: [1, [Validators.required]],
      status: [0],
      remark: [''],
    });
  }

  submitMenusForm() {
    const params = {
      ...this.validateForm.value
    };
    if (this.action === 'add') {
      params.parentId = this.parentId;
      this.service.saveInsert(params).subscribe(() => {
        this.message.success('添加成功!!');
        this.getNodeData(this.node.key, this.node);
      });
    } else {
      this.service.update(params).subscribe(() => {
        this.message.success('修改成功!!');
        this.getNodeData(this.node.parentNode.key, this.node.parentNode);
      });
    }
  }

  getNodeData(id, node) {
    const params: any = {
      parentId: id
    };
    this.service.getListByPage(params).subscribe(res => {
      if (res.total > 0) {
        const data = this.formatData(res.rows);
        node.clearChildren();
        node.addChildren(data);
        this.nodes = [...this.nodes];
      }
    });
  }

  formatData(arr) {
    arr.forEach(item => {
      item.title = item.name;
      item.key = item.id;
      if (item.count && item.count > 0) {
        item.isLeaf = false;
      } else {
        item.isLeaf = true;
      }
    });
    return arr;
  }

  getTabsData() {
    this.service.getStaffType({}).subscribe(res => {
      this.tabsData = [
        {
          id: '',
          name: '全部'
        },
        ...res.rows
      ];
    });
  }

  checkTabs(id) {
    this.typeId = id;
    this.getStaffData();
  }

  getStaffData() {
    const params = {
      departmentId: this.departmentId,
      typeId: this.typeId,
      pageSize: this.pageSize,
      pageNum: this.pageIndex,
      name: this.name
    };
    this.service.getStaff(params).subscribe(res => {
      this.staffData = res.rows;
      this.total = res.total;
    });
  }

  searchData() {
    this.getStaffData();
  }

  showDeleteConfirm(): void {
    const deleteData = [], names = [];
    this.list.forEach((data: any) => {
      if (data._checked) {
        deleteData.push({id: data.id});
        names.push(data[this.label]);
      }
    });
    if (deleteData.length == 0) {
      this.message.error('请至少选择一条数据!');
      return;
    }
    this.modal.confirm({
      nzTitle: '确认删除吗?',
      nzContent: `将删除<b>[${names.join(',')}]</b>数据!`,
      nzOkText: '确认',
      nzOkType: 'danger',
      nzOnOk: () => {
        this.service.deleteStaffAll(deleteData).subscribe(res => {
          if (res.success) {
            this.message.success('删除成功!');
            this.searchData();
          }
        });
      },
      nzCancelText: '取消'
    });
  }

  deleteById(id) {
    this.loading = true;
    this.service.deleteStaff(id).subscribe(res => {
      this.loading = false;
      if (res.success) {
        this.message.success('删除成功!');
        this.searchData();
      }
    }, error => {
      this.loading = false;
    });
  }

  export() {
    this.isLoading = true;
    // this.service.export({}).subscribe(data=>{
    //   this.isLoading = false;
    //   this.downloadFile(data);
    // })
  }

  changePassword(id) {
    this.isKeyVisible = true;
    this.staffId = id;
    this.validateKeyForm = this.fb.group({
      newPassword: [null, [Validators.required, Validators.maxLength(12)]],
    });
  }

  handleKeyOk(): void {
    if (!this.validateKeyForm.valid) {
      this.message.error('请填写完相关信息!');
      return;
    }
    const params = {
      accountsId: this.staffId,
      ...this.validateKeyForm.value
    };
    this.service.updatePWD(params).subscribe((res: any) => {
        if (res.success) {
          this.message.success('修改密码成功！');
          this.isKeyVisible = false;
        } else {
          this.message.error(res.msg);
        }
      },
      error => {
        this.message.error(error.error.msg);
      }
    );
  }
}
