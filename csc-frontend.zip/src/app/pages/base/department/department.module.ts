import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {NZ_I18N, zh_CN} from 'ng-zorro-antd/i18n';
import {NzAvatarModule} from 'ng-zorro-antd/avatar';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzCardModule} from 'ng-zorro-antd/card';
import {NzDescriptionsModule} from 'ng-zorro-antd/descriptions';
import {NzDropDownModule} from 'ng-zorro-antd/dropdown';
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzModalModule, NzModalService} from 'ng-zorro-antd/modal';
import {NzPageHeaderModule} from 'ng-zorro-antd/page-header';
import {NzPopconfirmModule} from 'ng-zorro-antd/popconfirm';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzResultModule} from 'ng-zorro-antd/result';
import {NzSpinModule} from 'ng-zorro-antd/spin';
import {NzTableModule} from 'ng-zorro-antd/table';
import {NzTabsModule} from 'ng-zorro-antd/tabs';
import {NzToolTipModule} from 'ng-zorro-antd/tooltip';
import {NzTransferModule} from 'ng-zorro-antd/transfer';
import {NzTreeModule} from 'ng-zorro-antd/tree';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {LoadStatusModule} from "../../../component/load-status/load-status.module";
import {ValidateMsgModule} from "../../../component/validate-msg/validate-msg.module";

import {DepartmentRoutingModule} from "./department-routing.module";
import {DepartmentService} from "./department.service";

import {ListComponent} from "./list/list.component";
import {EditComponent} from "./edit/edit.component";
import {ViewComponent} from "./view/view.component";
import {AddStaffComponent} from "./addStaff/addStaff.component";
import {FormComboModule} from "../../../component/form/combobox/form-combo.module";
import {FormDateModule} from "../../../component/form/datebox/form-date.module";
import {FormUploadModule} from "../../../component/form/uploadbox/form-upload.module";

@NgModule({
  declarations: [ListComponent, EditComponent, ViewComponent, AddStaffComponent],
  imports: [
    CommonModule,
    DepartmentRoutingModule,
    NzInputModule,
    FormsModule,
    NzTableModule,
    NzPopconfirmModule,
    NzButtonModule,
    NzToolTipModule,
    NzIconModule,
    NzDescriptionsModule,
    NzSpaceModule,
    NzBadgeModule,
    NzResultModule,
    NzSpinModule,
    LoadStatusModule,
    ReactiveFormsModule,
    NzRadioModule,
    NzFormModule,
    NzPageHeaderModule,
    ValidateMsgModule,
    NzTreeModule,
    NzModalModule,
    NzDropDownModule,
    NzCardModule,
    FormComboModule,
    NzTabsModule,
    FormDateModule,
    FormUploadModule,
    NzAvatarModule,
    NzTransferModule
  ],
  providers: [DepartmentService, NzModalService, {provide: NZ_I18N, useValue: zh_CN}]
})
export class DepartmentModule {
}
