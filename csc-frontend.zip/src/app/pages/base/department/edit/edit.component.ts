import {Component, OnInit} from "@angular/core";
import {Department} from "../department";
import {Staff} from "../../staff/staff";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {DepartmentService} from "../department.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'department-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Department> implements OnInit {

  constructor(public location: Location, public service: DepartmentService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(20)]],
      genderId: [null, [Validators.required, Validators.maxLength(40)]],
      birthday: [null],
      academicId: [null, [Validators.required, Validators.maxLength(40)]],
      degreeId: [null, [Validators.required, Validators.maxLength(40)]],
      degreeName: [null],
      avator: [null, [Validators.maxLength(255)]],
      positionId: [null, [Validators.required, Validators.maxLength(40)]],
      positionName: [null],
      typeId: [null, [Validators.required, Validators.maxLength(40)]],
      typeName: [null],
      sectionId: [null, [Validators.required, Validators.maxLength(40)]],
      departmentId: [null, [Validators.required, Validators.maxLength(40)]],
      sectionName: [null],
      majorId: [null, [Validators.required, Validators.maxLength(40)]],
      majorName: [null],
      identifyTypeId: [null, [Validators.required, Validators.maxLength(40)]],
      identifyNo: [null, [Validators.required, Validators.maxLength(20)]],
      serialNo: [null, [Validators.required, Validators.maxLength(20)]],
      mobile: [null, [Validators.required, Validators.maxLength(20)]],
      email: [null, [Validators.maxLength(50)]],
      qq: [null, [Validators.maxLength(12)]],
      wechat: [null, [Validators.maxLength(20)]],
      remark: [null, [Validators.maxLength(255)]],
      userId: [null, [Validators.maxLength(40)]],
      created: [null],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      academicName: [null],
      genderName: [null],
      databaseId: [null],
      identifyTypeName: [null],
      userName: [null],
      accountName: [null],
      departmentName: [null],
      unReadMessage: [null],
      accountsId: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getStaff({id: params.get('id')});
        } else {
          return of(new Staff());
        }
      })
    ).subscribe(res => {
      const d = res.rows ? res.rows[0] : {};
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    this.service.saveOrUpdateStaff(this.validateForm.value, this.validateForm.value['id'] != null).subscribe(res => {
      if (res.success) {
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            if (back) {
              this.location.back();
            } else {
              this.validateForm.reset();
            }
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }
}
