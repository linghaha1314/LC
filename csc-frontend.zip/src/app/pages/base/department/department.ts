export class Department {
  id: string;
  name: string;
  code: string;
  parentId: string;
  status: number;
  sort: number;
  remark: string;
  hospitalId: string;
  userId: string;
  created: any;
  parentName: string;
  userName: string;
}
