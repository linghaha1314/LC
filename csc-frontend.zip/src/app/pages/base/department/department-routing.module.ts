import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";
import {AddStaffComponent} from "./addStaff/addStaff.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '教研室表管理'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '教研室表详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加教研室表'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑教研室表'}},
  {path: 'addStaff/:id', component: AddStaffComponent, data: {title: '添加人员'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DepartmentRoutingModule {
}
