import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Department} from "./department";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class DepartmentService extends BaseService<Department> {
  protected url = {
    listByPage: '/department/listQueryByPage',
    insert: '/department/save',
    update: '/department/update',
    delete: '/department/delete',
    deleteAll: '/department/deleteAll',
    staffType: '/dictionarydata/listQueryByTypeCode/staffType',
    staffListByPage: '/staff/listQueryByPage',
    staffInsert: '/staff/addStaff',
    staffUpdate: '/staff/update',
    deleteStaff: '/staff/delete',
    deleteAllStaff: '/staff/deleteAll',
    updatePWD: "/accounts/updateAccountsPassword"
  };

  constructor(help: Help) {
    super(help);
  }

  saveInsert(params) {
    return this.help.post(this.url.insert, params);
  }

  getListByPage(params) {
    return this.help.post(this.url.listByPage, params);
  }

  delete(params) {
    return this.help.post(this.url.delete, params);
  }

  update(params) {
    return this.help.post(this.url.update, params);
  }

  getStaffType(params) {
    return this.help.post(this.url.staffType, params);
  }

  getStaff(params) {
    return this.help.post(this.url.staffListByPage, params);
  }

  saveOrUpdateStaff(params, update?) {
    let url = this.url.staffInsert;
    if (update) {
      url = this.url.staffUpdate;
    }
    return this.help.post(url, params);
  }

  deleteStaffAll(params) {
    return this.help.post(this.url.deleteAllStaff, params);
  }

  deleteStaff(id) {
    const params = {
      id
    };
    return this.help.post(this.url.deleteStaff, params);
  }

  updatePWD(params) {
    return this.help.post(this.url.updatePWD, params);
  }
}
