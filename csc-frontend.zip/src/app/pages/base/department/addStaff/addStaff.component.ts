import {Component, OnInit} from "@angular/core";
import {Group} from "../../group/group";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {GroupService} from "../../group/group.service";
import {ActivatedRoute} from "@angular/router";
import {TransferChange, TransferItem, TransferSelectChange} from 'ng-zorro-antd/transfer';

@Component({
  selector: 'add-staff',
  templateUrl: './addStaff.component.html',
  styles: []
})
export class AddStaffComponent extends BaseListComponent<Group> implements OnInit {

  flag = false;
  pageSize = 10;
  pageNum = 1;
  data = {
    list: [],
    total: 0
  };

  empty = false;

  groupId: String = "";

  disabled = false;

  saveStaffIds = [];

  deleteStaffIds = [];

  alreadyCheck = [];

  searchName = '';

  allList = [];

  departmentId;

  list;

  constructor(modal: NzModalService, public groupService: GroupService, message: NzMessageService, private route: ActivatedRoute) {
    super(modal, groupService, message);
  }

  ngOnInit() {
    this.route.params.subscribe(res => {
      this.departmentId = res.id;
      this.loadData();
    });
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.refreshChecked();
  }

  loadData() {
    this.loading = true;
    this.pageSize = 999;
    const params = {
      departmentId: this.departmentId,
      pageSize: this.pageSize,
      pageNum: this.pageNum
    };
    this.groupService.staffList({}).subscribe(res => {
      this.groupService.staffList(params).subscribe(data => {
        this.loading = false;
        this.alreadyCheck = data.rows;
        if (res.total !== 0) {
          this.list = [...res.rows];

          this.list.forEach((item: any) => {
            item.checked = false;
            data.rows.forEach((ite: any) => {
              if (item.departmentId === ite.departmentId) {
                item.direction = 'right';
              }
            });
          });
          this.allList = [...this.list];
        }
      }, ({error}) => {
        this.loading = false;
        this.message.error(`请求出现错误: ${error.msg}`);
      });
    });

  }

  searchData(reset: boolean = false, search: boolean = false): void {
    if (reset) {
      this.pageIndex++;
    } else {
      if (search) {
        this.pageIndex = 1;
      }
    }
    this.groupService.changeNum(this.pageIndex, this.pageSize);
    this.loadData();
  }

  selectMember(ret: TransferSelectChange) {
  }

  changeMember(ret: TransferChange) {
    const listKeys = ret.list.map(l => l.key);
    const hasOwnKey = (e: TransferItem) => e.hasOwnProperty('key');
    if (ret.to === 'left') { // 取消加入
      const listArr = [];
      ret.list.forEach(item => {
        listArr.push(item.id);
      });
      this.deleteStaffIds = listArr;
      this.saveStaffIds = [];
      this.saveOrDelMember();
    } else if (ret.to === 'right') { // 加入成员
      const listArr = [];
      ret.list.forEach(item => {
        listArr.push(item.id);
      });
      this.deleteStaffIds = [];
      this.saveStaffIds = listArr;
      this.saveOrDelMember();
    }
    this.list = this.list.map((e: any) => {
      if (listKeys.includes(e.key) && hasOwnKey(e)) {
        if (ret.to === 'left') { // 取消加入
          delete e.hide;
        } else if (ret.to === 'right') { // 加入成员
          e.hide = false;
        }
      }
      return e;
    });

  }

  saveOrDelMember() {
    const params = [];
    if (this.deleteStaffIds.length === 0) {
      this.saveStaffIds.forEach(item => {
        const obj = {
          id: item,
          departmentId: this.departmentId
        };
        params.push(obj);
      });
    } else {
      this.deleteStaffIds.forEach(item => {
        const obj = {
          id: item,
          departmentId: ''
        };
        params.push(obj);
      });
    }
    this.groupService.updateStaffList(params).subscribe(res => {
      if (res.success) {
        this.message.success('操作成功!!');
      }
    });
  }

  searchMember() {
    if (this.searchName === '') {
      this.list = [...this.allList];
    } else {
      this.list = [...this.allList].filter((item: any) => item.name.indexOf(this.searchName) != -1);
    }
  }
}
