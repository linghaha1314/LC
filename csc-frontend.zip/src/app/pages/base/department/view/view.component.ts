import {Component, OnInit} from '@angular/core';
import {Department} from "../department";
import {Staff} from "../../staff/staff";
import {DepartmentService} from "../department.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'department-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: Staff = new Staff();

  constructor(private service: DepartmentService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getStaff({id: params.get('id')});
        } else {
          return of(new Department());
        }
      })
    ).subscribe(res => {
      const d = res.rows[0];
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
