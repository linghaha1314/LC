export class MenuFlowItem {
  id: string;
  name: string;
  color: string;
  menuId: string;
  remark: string;
  menuFlowId: string;
  attachs: string;
  status: number;
  sort: number;
  menuName: string;
  menuFlowName: string;
}
