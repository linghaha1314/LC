import {Component, OnInit} from "@angular/core";
import {MenuFlowItem} from "../menu-flow-item";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {MenuFlowItemService} from "../menu-flow-item.service";

@Component({
  selector: 'menu-flow-item-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<MenuFlowItem> implements OnInit {

  constructor(public modal: NzModalService, public service: MenuFlowItemService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
  }
}
