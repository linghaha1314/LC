import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {MenuFlowItem} from "./menu-flow-item";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class MenuFlowItemService extends BaseService<MenuFlowItem> {
  protected url = {
    listByPage: '/menuflowitem/listQueryByPage',
    insert: '/menuflowitem/save',
    update: '/menuflowitem/update',
    delete: '/menuflowitem/delete',
    deleteAll: '/menuflowitem/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
