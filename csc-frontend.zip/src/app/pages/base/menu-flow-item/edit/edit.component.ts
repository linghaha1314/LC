import {Component, OnInit} from "@angular/core";
import {MenuFlowItem} from "../menu-flow-item";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {MenuFlowItemService} from "../menu-flow-item.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'menu-flow-item-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<MenuFlowItem> implements OnInit {

  constructor(public location: Location, public service: MenuFlowItemService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(500)]],
      color: [null, [Validators.required, Validators.maxLength(20)]],
      menuId: [null, [Validators.required, Validators.maxLength(40)]],
      remark: [null],
      menuFlowId: [null, [Validators.required, Validators.maxLength(40)]],
      attachs: [null, [Validators.required]],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      sort: [null, [Validators.required, Validators.maxLength(11)]],
      menuName: [null],
      menuFlowName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new MenuFlowItem());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

}
