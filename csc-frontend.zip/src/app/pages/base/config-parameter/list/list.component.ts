import {Component, OnInit} from "@angular/core";
import {ConfigParameter} from "../config-parameter";
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {ConfigParameterService} from "../config-parameter.service";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'config-parameter-list',
  templateUrl: './list.component.html',
  styles: [
    `
      .btn-box{
        text-align: center;
        margin-top: 12px;
      }
      .input-item{
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
      }
      .item-input{
        flex: 1;
        margin: 0 12px;
        text-align: center;
      }
      .item-input input{
        width: 100%;
      }
      .item-name{
        width: 15%;
        text-align: right;
      }
      .item-btn{
        width: 15%;
        text-align: left;
      }
    `
  ]
})
export class ListComponent extends BaseListComponent<ConfigParameter> implements OnInit {
  // configparameter
  constructor(
    public modal: NzModalService,
    public service: ConfigParameterService,
    public message: NzMessageService,
    private fb: FormBuilder
  ) {
    super(modal, service, message);
  }
  validateForm!: FormGroup;
  date: any;
  time: Date | null = null;

  isVisible = false;
  optionList = [];
  textType = [
    {
      name: '输入框',
      inputType: 1
    },
    {
      name: '数字框',
      inputType: 2
    },
    {
      name: '日期选择框',
      inputType: 3
    },
    {
      name: '时间选择框',
      inputType: 4
    },
    {
      name: '多行输入框',
      inputType: 5
    },
    {
      name: '单选框',
      inputType: 6
    },
    {
      name: '附件框',
      inputType: 7
    }
  ];
  currentData: any;
  isEdit = false;
  ngOnInit() {
    this.validateForm = this.fb.group({
      name: [null, [Validators.required]],
      code: [null, [Validators.required]],
      defaultValue: [null, [Validators.required]],
      inputType: [null, [Validators.required]],
      remark: [null]
    });
    this.getCurrentClass();
  }

  addText() {
    this.validateForm.reset();
    this.isVisible = true;
  }

  cancelClick(){
    this.isVisible = false;
  }

  addTextNow() { // 添加新的参数项
    this.submitForm();
    if (this.validateForm.valid){
      const obj = this.validateForm.value;
      if (this.isEdit){
        this.optionList[this.currentData] = {...obj};
      }else {
        this.optionList.push(obj);
        this.validateForm.reset();
      }
      this.isVisible = false;
      this.isEdit = false;
    }
  }

  getCurrentClass(){ // 获取当前参数
    const params = {
    };
    this.service.getAll(params).subscribe((res: any) => {
      this.optionList = res.rows;
    });
  }

  editInput(data, index){ // 修改参数
    this.isVisible = true;
    this.isEdit = true;
    this.currentData = index;
    this.validateForm.get('name').setValue(data.name);
    this.validateForm.get('code').setValue(data.code);
    this.validateForm.get('defaultValue').setValue(data.defaultValue);
    this.validateForm.get('inputType').setValue(data.inputType);
    this.validateForm.get('remark').setValue(data.remark);
  }

  delInput(el, index){
    if (el.id){
      this.service.deleteParam({id: el.id}).subscribe();
    }
    this.optionList.splice(index, 1);
    this.message.success('删除成功!!');
  }

  saveAll(){
    const params = this.optionList;
    this.service.getSave(params).subscribe((res: any) => {
      if (res.success){
        this.message.success('保存成功!');
      }else{
        this.message.error('保存失败!');
      }
    });
  }

  submitForm(): void {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }
  }
}
