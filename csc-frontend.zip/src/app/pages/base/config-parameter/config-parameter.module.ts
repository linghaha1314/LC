import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import { NZ_I18N, zh_CN } from 'ng-zorro-antd/i18n';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTimePickerModule } from 'ng-zorro-antd/time-picker';


import {ConfigParameterRoutingModule} from "./config-parameter-routing.module";
import {ConfigParameterService} from "./config-parameter.service";

import {ListComponent} from "./list/list.component";
import {EditComponent} from "./edit/edit.component";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {FormDateModule} from "../../../component/form/datebox/form-date.module";
import {FormUploadModule} from "../../../component/form/uploadbox/form-upload.module";
import {NzTypographyModule} from "ng-zorro-antd/typography";

@NgModule({
  declarations: [ListComponent, EditComponent],
  imports: [
    CommonModule,
    ConfigParameterRoutingModule,
    NzInputModule,
    NzButtonModule,
    NzIconModule,
    NzRadioModule,
    NzTabsModule,
    NzCardModule,
    NzInputNumberModule,
    NzDatePickerModule,
    NzTimePickerModule,
    FormsModule,
    NzModalModule,
    NzSelectModule,
    NzGridModule,
    NzFormModule,
    NzSpaceModule,
    ReactiveFormsModule,
    FormDateModule,
    FormUploadModule,
    NzTypographyModule
  ],
  providers: [ConfigParameterService, NzModalService, NzMessageService, {provide: NZ_I18N, useValue: zh_CN}]
})
export class ConfigParameterModule {
}
