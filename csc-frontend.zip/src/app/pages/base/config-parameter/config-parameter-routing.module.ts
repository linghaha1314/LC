import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '参数设置列表'}},
  {path: 'edit', component: EditComponent, data: {title: '参数结果表'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑参数设置'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigParameterRoutingModule {
}
