import {Component, OnInit} from "@angular/core";
import {ConfigParameter} from "../config-parameter";
import {ConfigParameterService} from "../config-parameter.service";
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'config-parameter-edit',
  templateUrl: './edit.component.html'
})
export class EditComponent extends BaseEditComponent<ConfigParameter> implements OnInit {
  optionList: any;

  constructor(
    public location: Location,
    public service: ConfigParameterService,
    public message: NzMessageService) {
    super(location, service, message);
  }

  ngOnInit() {
    this.getCurrentClass();
  }

  getCurrentClass() { // 获取当前参数
    const params = {};
    this.service.getAll(params).subscribe((res: any) => {
      const list = res.rows;
      list.forEach(r => {
        r.defaultValue = r.cfgValue ?? r.defaultValue;
      });
      this.optionList = list;
    });
  }

  updateData(data) {
    const params = {
      parameterId: data.id,
      cfgValue: data.defaultValue
    };
    this.service.updateValue(params).subscribe(res => {
      this.message.success('配置成功!');
    });
  }

}
