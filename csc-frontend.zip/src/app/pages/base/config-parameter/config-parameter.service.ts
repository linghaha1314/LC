import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {ConfigParameter} from "./config-parameter";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class ConfigParameterService extends BaseService<ConfigParameter> {
  protected url = {
    listByPage: '/configparameter/listQueryByPage',
    insert: '/configparameter/save',
    update: '/configparameter/updateConfig ',
    delete: '/configparameter/delete',
    deleteAll: '/configparameter/deleteAll',
    deleteAllConfigValue: '/configparameter/deleteAllConfigValue',
    current: '/configparameter/getConfigParams',
    allSave: '/configparameter/saveOrUpdateList'
  };

  constructor(help: Help) {
    super(help);
  }
  // 保存参数信息
  getSave(params){
    return this.help.post(this.url.allSave, params);
  }
  // 获取参数信息
  getAll(params){
    return this.help.post(this.url.listByPage, params);
  }

  updateValue(params){
    return this.help.post(this.url.update, params);
  }
  // 删除参数
  deleteParam(params){
    return this.help.post(this.url.delete, params);
  }

}
