export class ConfigParameter {
  id: string;
  name: string;
  code: string;
  typeId: string;
  inputType: number;
  defaultValue: string;
  status: number;
  remark: string;
  created: any;
  typeName: string;
}
