import {Component, Input, OnInit} from '@angular/core';
import {ProcessRecord} from "../process-record";
import {ProcessRecordService} from "../process-record.service";
import {Location} from "@angular/common";
import {NzStatusType} from "ng-zorro-antd/steps";

@Component({
  selector: 'process-record-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: ProcessRecord = new ProcessRecord();

  list: Array<any> = [];

  current = 0;

  status: NzStatusType = 'process';

  loading = false;

  private cache: any = [];

  private len: number = 0;

  private _init: any;

  @Input()
  type: 'default' | 'simple' = 'default';

  get init(): any {
    return this._init;
  }

  @Input()
  set init(value: any) {
    this._init = value;
    this.getData();
  }

  constructor(private service: ProcessRecordService, private location: Location) {
  }

  ngOnInit() {
    this.getData();
  }

  getData() {
    const data: any = this._init || this.location.getState();
    if (data.list) {
      this.len = data.list.length;
      data.list.forEach((r, i) => {
        this.initData(r.recordId, r.start, r.end, i);
      });
    } else {
      if (data.recordId == null) {
        this.empty = true;
        return;
      }
      this.empty = false;
      this.initData(data.recordId, data.start, data.end, 0);
    }
  }

  initData(recordId: string, start: string, end: string, step: number, type = 'single') {
    this.loading = true;
    this.service.queryData({id: recordId}).subscribe(res => {
      if (res.success) {
        let index = 0, errorFlag = false;
        res.data.forEach((d, i) => {
          if (d.status != null) {
            index = i;
            if (d.status == 1) {
              errorFlag = true;
              d.status = 'error';
            } else {
              d.status = 'finish';
            }
          } else {
            d.status = 'wait';
          }
        });
        if (errorFlag) {
          this.status = "error";
        } else {
          this.current = res.data[0]['status'] == 'wait' ? index : index + 1;
          if (this.current == res.data.length) {
            this.status = "finish";
          } else {
            res.data[this.current]['icon'] = 'loading';
            res.data[this.current]['status'] = 'progress';
          }
        }
        const rows = [{name: start, status: 'finish'}, ...res.data, {
          name: end,
          status: index == res.data.length - 1 ? this.status : 'wait'
        }];
        if (type == 'single') {
          this.list = rows;
        } else {
          this.cache[step] = rows;
          this.addList(step);
        }
      }
      this.loading = false;
    });
  }

  addList(i) {
    if (this.len == i + 1) {
      let rows: Array<any> = [];
      this.cache.forEach(r => {
        rows = rows.concat(r);
      });
      this.list = rows;
    }
  }
}
