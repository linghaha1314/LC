export class ProcessRecord {
  id: string;
  status: number;
  staffId: string;
  created: any;
  hospitalId: string;
  processId: string;
  staffName: string;
  processName: string;
}
