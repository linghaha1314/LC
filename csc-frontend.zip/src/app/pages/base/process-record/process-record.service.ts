import {Injectable} from "@angular/core";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class ProcessRecordService {
  protected url = {
    listByPage: '/processrecord/queryAuditRecord'

  };

  constructor(private help: Help) {
  }

  queryData(params: any) {
    return this.help.post(this.url.listByPage, params);
  }
}
