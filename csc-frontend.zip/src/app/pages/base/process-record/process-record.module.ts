import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {NZ_I18N, zh_CN} from 'ng-zorro-antd/i18n';
import {NzModalService} from 'ng-zorro-antd/modal';
import {NzPageHeaderModule} from 'ng-zorro-antd/page-header';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {LoadStatusModule} from "../../../component/load-status/load-status.module";

import {ProcessRecordRoutingModule} from "./process-record-routing.module";
import {ProcessRecordService} from "./process-record.service";

import {ViewComponent} from "./view/view.component";
import {NzStepsModule} from "ng-zorro-antd/steps";
import {NzTagModule} from "ng-zorro-antd/tag";
import {NzIconModule} from "ng-zorro-antd/icon";

@NgModule({
  declarations: [ViewComponent],
  imports: [
    CommonModule,
    ProcessRecordRoutingModule,
    FormsModule,
    LoadStatusModule,
    ReactiveFormsModule,
    NzPageHeaderModule,
    NzStepsModule,
    NzTagModule,
    NzIconModule,
  ],
  exports: [
    ViewComponent
  ],
  providers: [ProcessRecordService, NzModalService, {provide: NZ_I18N, useValue: zh_CN}]
})
export class ProcessRecordModule {
}
