import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {DictionaryTypeRoutingModule} from './dictionary-type-routing.module';
import {ListComponent} from './list/list.component';
import {DictionaryTypeService} from './dictionary-type.service';
import { NZ_I18N, zh_CN } from 'ng-zorro-antd/i18n';
import { NzBadgeModule } from 'ng-zorro-antd/badge';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzDescriptionsModule } from 'ng-zorro-antd/descriptions';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzPageHeaderModule } from 'ng-zorro-antd/page-header';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NzSpaceModule} from 'ng-zorro-antd/space';
import {LoadStatusModule} from '../../../component/load-status/load-status.module';
import {EditComponent} from './edit/edit.component';
import {ViewComponent} from './view/view.component';
import {ValidateMsgModule} from "../../../component/validate-msg/validate-msg.module";

@NgModule({
  declarations: [ListComponent, EditComponent, ViewComponent],
    imports: [
        CommonModule,
        DictionaryTypeRoutingModule,
        NzInputModule,
        FormsModule,
        NzTableModule,
        NzPopconfirmModule,
        NzButtonModule,
        NzToolTipModule,
        NzIconModule,
        NzGridModule,
        NzDescriptionsModule,
        NzSpaceModule,
        NzBadgeModule,
        NzResultModule,
        NzSpinModule,
        LoadStatusModule,
        ReactiveFormsModule,
        NzRadioModule,
        NzFormModule,
        NzPageHeaderModule,
        ValidateMsgModule
    ],
  providers: [DictionaryTypeService, NzModalService, NzMessageService, {provide: NZ_I18N, useValue: zh_CN}]
})
export class DictionaryTypeModule {
}
