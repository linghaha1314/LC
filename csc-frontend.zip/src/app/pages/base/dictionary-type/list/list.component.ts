import {Component, OnInit} from '@angular/core';
import {DictionaryType} from '../dictionary-type';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {DictionaryTypeService} from "../dictionary-type.service";

@Component({
  selector: 'dictionary-type-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<DictionaryType> implements OnInit {

  constructor(modal: NzModalService, service: DictionaryTypeService, message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
