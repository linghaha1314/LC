import {Component, OnInit} from '@angular/core';
import {DictionaryType} from '../dictionary-type';
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {DictionaryTypeService} from '../dictionary-type.service';
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import { NzMessageService } from 'ng-zorro-antd/message';
import {BaseEditComponent} from '../../../../component/base/base-edit.component';

@Component({
  selector: 'dictionary-type-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<DictionaryType> implements OnInit {


  constructor(location: Location, service: DictionaryTypeService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new DictionaryType());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id],
        name: [d.name, [Validators.required, Validators.maxLength(50)]],
        code: [d.code, [Validators.required, Validators.maxLength(50), Validators.min(2), Validators.max(5)]],
        status: [d.status, [Validators.required]],
        remark: [d.remark, Validators.maxLength(200)]
      });
      this.isLoading = false;
    });
  }

}
