import {Injectable} from '@angular/core';
import {BaseService} from '../../../component/base/base.service';
import {DictionaryType} from './dictionary-type';
import {Help} from '../../../utils/Help';


@Injectable({
  providedIn: 'root'
})
export class DictionaryTypeService extends BaseService<DictionaryType> {
  protected url = {
    listByPage: '/dictionarytype/listQueryByPage',
    insert: '/dictionarytype/save',
    update: '/dictionarytype/update',
    delete: '/dictionarytype/delete',
    deleteAll: '/dictionarytype/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
