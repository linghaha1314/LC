export class DictionaryType {
  id: string;
  code: string;
  name: string;
  remark: string;
  status: number;
  created: any;
}
