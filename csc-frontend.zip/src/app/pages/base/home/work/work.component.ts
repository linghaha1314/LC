import {Component, OnInit} from "@angular/core";
import {NzMessageService} from "ng-zorro-antd/message";
import {HomeService} from "../home.service";
import {TodoTask} from "../../todo-task/todo-task";
import {Location} from "@angular/common";
import {Router} from "@angular/router";
import {Help} from "../../../../utils/Help";


@Component({
  selector: 'home-work',
  templateUrl: './work.component.html'
})
export class WorkComponent implements OnInit {
  label = 'name';
  list: Array<TodoTask> = [];
  total = 0;
  pageIndex = 1;
  pageSize = 10;
  loading = false;
  queryParams: any = {name: null};
  todoTypes = [];

  constructor(private service: HomeService, private help: Help, private message: NzMessageService, private location: Location, private router: Router) {
    const d = this.location.getState() as any;
    this.queryParams.todoDay = d['todoDay'];
    this.queryParams.typeCode = d['typeCode'];
  }

  reloadData() {
    this.loading = true;
    this.service.queryParams = this.queryParams;
    this.service.refreshData().subscribe(d => {
      if (d) {
        this.getData();
      }
    });
  }

  getData() {
    this.loading = true;
    this.service.queryParams = this.queryParams;
    this.service.getData()
      .subscribe(data => {
        this.loading = false;
        this.list = data.list;
        this.total = data.total;
      }, ({error}) => {
        this.loading = false;
        this.message.error(`请求出现错误: ${error.msg}`);
      });
  }

  searchData(search: boolean = false): void {
    if (search) {
      this.pageIndex = 1;
    }
    this.service.changeNum(this.pageIndex, this.pageSize);
    this.getData();
  }

  ngOnInit(): void {
    this.service.getDictionaryData("TodoType").subscribe(({rows}) => {
      this.todoTypes = rows;
    });
    this.reloadData();
  }

  intoRoute(data: TodoTask) {
    this.loading = true;
    this.service.getMenuAuthByPath(data.router).subscribe(res => {
      if (res.success) {
        this.loading = false;
        this.help.setMenuAuth(res.data);
        this.router.navigate([data.router], {state: JSON.parse(data.params)}).then();
      }
    });
  }
}
