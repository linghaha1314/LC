import {Component, OnInit, ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {CdkDragDrop, moveItemInArray} from "@angular/cdk/drag-drop";
import {HomeService} from "../home.service";
import {Help} from "../../../../utils/Help";
import {NzFormatEmitEvent, NzTreeComponent, NzTreeNode} from "ng-zorro-antd/tree";
import {formatDate} from "@angular/common";
import {TodoTask} from "../../todo-task/todo-task";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {NzMessageService} from "ng-zorro-antd/message";

@Component({
  selector: 'home-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  todoTypes = {"TypeReceived": 0, "TypeProcessed": 0, "TypePending": 0, "TypeLaunch": 0};

  menus: any[] = [];

  _cacheMenus: any[] = [];

  saveMenuFlag = false;

  menuModalVisible = false;

  oftenVisible = false;

  visible = false;

  detailFlag = false;

  menuTree = [];

  _cacheMenuKey = {};

  private _workType = 'system';

  get workType(): string {
    return this._workType;
  }

  set workType(value: string) {
    this._workType = value;
    if (value == 'mine') {
      this.queryMineSchedule();
    } else {
      this.showTodoTypeList(this.query['typeCode']);
    }
  }

  @ViewChild('oftenMenuTree', {static: false}) oftenMenuTree!: NzTreeComponent;

  calendar = [];

  startDate: Date = new Date();

  now = formatDate(new Date(), 'MM月dd日', 'zh');

  works = [];

  workLen = 0;

  todoLoad = false;

  labelData = {};

  query: any = {};

  validateForm: FormGroup;

  endParams: any = {};

  notifyParams: any = {
    repeat: 0,
    days: {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false
    },
    times: {
      punctuality: false,
      fiveMinutesAgo: false,
      tenMinutesAgo: false,
      thirtyMinutesAgo: false,
      oneHourAgo: false,
      oneDayAgo: false,
      threeDayAgo: false,
    }
  };

  constructor(private router: Router, private service: HomeService, private help: Help, private fb: FormBuilder, private message: NzMessageService) {
    this.getTypeTodo();
    this.showTodoTypeList('TypePending');
  }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(250)]],
      content: [null],
      startDate: [null, [Validators.required]],
      endDate: [null, [Validators.required]],
      typeId: ['NoRepeat', [Validators.required, Validators.maxLength(40)]],
      endParams: [null],
      notifyParams: [null, [Validators.maxLength(200)]],
      address: [null, [Validators.maxLength(500)]],
      remark: [null, [Validators.maxLength(500)]],
      userId: [null, [Validators.maxLength(40)]],
      created: [null],
      attachs: [null],
      status: [0, [Validators.maxLength(11)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      urgentStatus: [null, [Validators.required, Validators.maxLength(11)]],
      staffId: [null],
      completeDate: [null],
      sort: [null],
      typeName: [null],
      userName: [null],
      staffName: [null],
    });
    this.initNowStart();
    this.getMyMenu();
  }

  getTypeTodo() {
    this.service.queryTypeCount().subscribe((res) => {
      if (res.success) {
        res.data.forEach(r => {
          this.todoTypes[r.code] = r.total;
        });
      }
    });
  }

  getLabelTodo() {
    const d = this.calendar[0];
    this.service.queryLabelCount(d[0].date, d[d.length - 1].date).subscribe(res => {
      if (res.success) {
        res.data.forEach(r => {
          this.labelData[r.day].push(r);
        });
      }
    });
  }

  getMyMenu() {
    this._cacheMenuKey = {};
    this.service.getOftenMenuData().subscribe(({rows}) => {
      rows.forEach(r => {
        this._cacheMenuKey[r.menuId] = true;
      });
      this.menus = rows;
    });
  }

  changeMenu(m: any) {
    localStorage.setItem('nowName', m.name);
    if (m.menusFlowFlag) {
      this.help.setMenuAuth(m.userName);
      let displayJson = localStorage.getItem("displayMenuFlow");
      if (displayJson == null) {
        this.router.navigate(["/menuflow/examineHelp/" + m.id]).then();
      } else {
        if (JSON.parse(displayJson)[m.id] == null) {
          this.router.navigate(["/menuflow/examineHelp/" + m.id]).then();
        }
      }
    }
    if (m.url != "#" && m.url.length > 0) {
      this.help.setMenuAuth(m.auth);
      this.router.navigate([m.url]).then();
    }
  }

  dropMenu(event: CdkDragDrop<string[]>) {
    moveItemInArray(this._cacheMenus, event.previousIndex, event.currentIndex);
  }

  removeMenu(index: number) {
    this._cacheMenus.splice(index, 1);
  }

  menuEditChange() {
    if (this.oftenVisible) {
      this.saveMenuFlag = true;
      if (this._cacheMenus.length == 0) {
        this.service.deleteAllOftenMenu().subscribe(() => {
          this.saveMenuFlag = false;
          this.menus = [...this._cacheMenus];
        });
      } else {
        this.service.updateOftenMenu(this._cacheMenus).subscribe(() => {
          this.saveMenuFlag = false;
          this.menus = [...this._cacheMenus];
        });
      }
    } else {
      this._cacheMenus = [...this.menus];
    }
    this.oftenVisible = !this.oftenVisible;
  }

  addMenu() {
    const list: Array<NzTreeNode> = this.oftenMenuTree.getCheckedNodeList(), rows = [];
    list.forEach(r => {
      rows.push({menuId: r.key, name: r.title, url: r.origin.data.path});
    });
    if (rows.length == 0) {
      return;
    }
    this.menuModalVisible = false;
    this.saveMenuFlag = true;
    this.service.addOftenMenu(rows).subscribe(() => {
      this.saveMenuFlag = false;
      this.getMyMenu();
    });
  }

  showMenuModal() {
    this.menuModalVisible = true;
    this.service.getCurrentMenusByPid("isNull").subscribe(list => {
      list.forEach(r => {
        if (this._cacheMenuKey[r.key]) {
          r.disabled = true;
        }
      });
      this.menuTree = list;
    });
  }

  loadChildMenu(e: NzFormatEmitEvent) {
    if (e.node.children.length > 0) {
      return;
    }
    e.node.isLoading = true;
    this.service.getCurrentMenusByPid(e.node.key).subscribe(list => {
      list.forEach(r => {
        if (this._cacheMenuKey[r.key]) {
          r.disabled = true;
        }
      });
      e.node.addChildren(list);
      e.node.isLoading = false;
    });
  }

  initNowStart(now: Date = new Date()) {
    const oneDayLong = 24 * 60 * 60 * 1000;//一天的毫秒数
    const c_time = now.getTime();//当前时间的毫秒时间
    const c_day = now.getDay() || 7;//当前时间的星期几
    const m_time = c_time - (c_day - 1) * oneDayLong;//当前周一的毫秒时间
    const monday = new Date(m_time);//设置周一时间对象
    this.startDate = new Date(monday.setTime(monday.getTime() - 1000 * 60 * 60 * 24));
    this.calendar.length = 0;
    for (let j = 0; j < 1; j++) {
      const list = [];
      for (let i = 0; i < 7; i++) {
        const d = this.showDateColumn();
        list.push({name: formatDate(d, 'MM月dd日', 'zh'), date: formatDate(d, 'yyyy-MM-dd', 'zh')});
      }
      this.calendar.push(list);
    }
    this.labelData = {};
    this.calendar[0].forEach(r => {
      this.labelData[r.date] = [];
    });
    this.getLabelTodo();
  }

  showDateColumn() {
    return new Date(this.startDate.setTime(this.startDate.getTime() + 1000 * 60 * 60 * 24));
  }

  changeDate(type: 'now' | 'plus' | 'reduce') {
    if (type == 'now') {
      this.now = formatDate(new Date(), 'MM月dd日', 'zh');
      this.initNowStart();
    } else if (type == 'plus') {
      this.initNowStart(this.showDateColumn());
    } else {
      this.initNowStart(new Date(this.startDate.setTime(this.startDate.getTime() - (1000 * 60 * 60 * 24) * 8)));
    }
  }

  changeWork(d: any) {
    this.now = d.name;
    this.todoLoad = true;
    this.query['todoDay'] = d.date;
    this.query['typeCode'] = null;
    this.service.getTodoList({todoDay: d.date}).subscribe(({rows, total}) => {
      this.workLen = total;
      this.works = rows;
      this.todoLoad = false;
    });
  }

  showTodoTypeList(type: string) {
    this.todoLoad = true;
    this.query['todoDay'] = null;
    this.query['typeCode'] = type;
    this.service.getTodoList({typeCode: type}).subscribe(({rows, total}) => {
      this.workLen = total;
      this.works = rows;
      this.todoLoad = false;
    });
  }

  showMoreTodo() {
    this.help.setMenuAuth('list,add,update,delete,apply,audit');
    this.router.navigate([this.workType == 'system' ? '/home/work' : '/schedule'], {state: this.query}).then();
  }

  intoRoute(data: TodoTask) {
    if (this.workType == 'mine') {
      this.router.navigate(['/schedule/view', data.id]).then();
      return;
    }
    this.todoLoad = true;
    this.service.getMenuAuthByPath(data.router).subscribe(res => {
      if (res.success) {
        this.todoLoad = false;
        this.help.setMenuAuth(res.data);
        this.router.navigate([data.router], {state: JSON.parse(data.params)}).then();
      }
    });
  }

  submitTodo() {
    if (this.validateForm.valid) {
      this.todoLoad = true;
      this.visible = false;
      this.validateForm.value.endParams = JSON.stringify(this.endParams);
      this.validateForm.value.notifyParams = JSON.stringify(this.notifyParams);
      this.service.saveMineTask(this.validateForm.value).subscribe(res => {
        this.todoLoad = false;
        if (res['success']) {
          this.validateForm.reset();
          this.message.success('添加成功');
          if (this.workType == 'mine') {
            this.queryMineSchedule();
          } else {
            this.showTodoTypeList(this.query['typeCode']);
          }
        }
      });
    } else {
      this.message.error("请填写完整");
    }
  }

  queryMineSchedule() {
    this.todoLoad = true;
    this.service.getMineSchedule().subscribe(({rows, total}) => {
      this.workLen = total;
      this.works = rows;
      this.todoLoad = false;
    });
  }

  deleteTodo(id) {
    this.todoLoad = true;
    this.service.deleteById(id).subscribe(() => {
      this.showTodoTypeList('TypePending');
    });
  }

  completeTodo(id) {
    this.todoLoad = true;
    this.service.completeTask({id: id}).subscribe(() => {
      this.showTodoTypeList('TypePending');
    });
  }
}
