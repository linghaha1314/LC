import {Component, OnInit} from '@angular/core';
import {HomeService} from '../home.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {Help} from "../../../../utils/Help";
import {Observable, Observer} from "rxjs";
import {NzUploadFile} from "ng-zorro-antd/upload";

@Component({
  selector: 'home-edit',
  templateUrl: './edit.component.html',
  styles: [`
    .ant-upload-select-picture-card {
      border-radius: 50% 50%;
    }`
  ]
})
export class EditComponent implements OnInit {

  isLoading = false;
  validateForm: FormGroup = null;
  loading = false;
  avatarUrl?: string;


  constructor(private location: Location, private service: HomeService, private message: NzMessageService, private fb: FormBuilder, private help: Help) {

  }

  ngOnInit() {
    this.service.getUserInfo().subscribe((res: any) => {
      if (res) {
        this.avatarUrl = res["staff"].avator;
        this.validateForm = this.fb.group({
          id: [res["staff"].id],
          staffName: [res["staff"].name, [Validators.required, Validators.maxLength(20)]],
          birthday: [res["staff"].birthday, [Validators.required]],
          academicId: [res["staff"].academicId, [Validators.required]],
          genderId: [res["staff"].genderId, [Validators.required]],
          degreeId: [res["staff"].degreeId, [Validators.required]],
          positionId: [res["staff"].positionId],
          identifyTypeId: [res["staff"].identifyTypeId, [Validators.required]],
          identifyNo: [res["staff"].identifyNo, [Validators.required, Validators.maxLength(20)]],
          mobile: [res["staff"].mobile, [Validators.required, Validators.maxLength(20)]],
          email: [res["staff"].email, [Validators.maxLength(50)]],
          qq: [res["staff"].qq, [Validators.maxLength(12)]],
          wechat: [res["staff"].wechat, [Validators.maxLength(20)]],
          remark: [res["staff"].remark],
        });
      }
    });
  }

  submitForm() {
    if (!this.validateForm.valid) {
      this.message.error("请检查表单在进行保存！");
      return;
    }
    this.isLoading = true;
    this.validateForm.value["avator"] = this.avatarUrl;
    this.service.saveAccountEdit(this.validateForm.value).subscribe(
      (res: any) => {
        if (res.success) {
          window.location.reload();
        }
      }
    );
  }

  uploadFile = (options: any) => {
    const data = new FormData();
    data.append('files', options.file);
    return this.service.uploadFile(data).subscribe((res: any) => {
      if (res.success) {
        this.avatarUrl = res.filePath;
      }
      options.onSuccess(res, options.file);
    }, error => {
      options.onError(error);
    });
  };

  beforeUpload = (file: NzUploadFile, _fileList: NzUploadFile[]) => {
    return new Observable((observer: Observer<boolean>) => {
      const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
      if (!isJpgOrPng) {
        observer.complete();
        return;
      }
      observer.next(isJpgOrPng);
      observer.complete();
    });
  };

  back() {
    this.location.back();
  }
}
