import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ViewComponent} from "./account-view/view.component";
import {EditComponent} from "./account-edit/edit.component";
import {ListComponent} from "./list/list.component";
import {WorkComponent} from "./work/work.component";

const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '首页'}},
  {path: 'view', component: ViewComponent, data: {title: '人员信息'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '人员信息'}},
  {path: 'edit', component: EditComponent, data: {title: '账户设置'}},
  {path: 'work', component: WorkComponent, data: {title: '工作台'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class HomeRoutingModule {
}
