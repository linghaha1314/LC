import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {HomeRoutingModule} from './home-routing.module';
import {HomeService} from "./home.service";
import {ViewComponent} from "./account-view/view.component";
import {EditComponent} from "./account-edit/edit.component";
import {ListComponent} from "./list/list.component";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NzFormModule} from "ng-zorro-antd/form";
import {NzUploadModule} from "ng-zorro-antd/upload";
import {LoadStatusModule} from "../../../component/load-status/load-status.module";
import {NzIconModule} from "ng-zorro-antd/icon";
import {ValidateMsgModule} from "../../../component/validate-msg/validate-msg.module";
import {FormDateModule} from "../../../component/form/datebox/form-date.module";
import {FormComboModule} from "../../../component/form/combobox/form-combo.module";
import {NzButtonModule} from "ng-zorro-antd/button";
import {NzPageHeaderModule} from "ng-zorro-antd/page-header";
import {NzDescriptionsModule} from "ng-zorro-antd/descriptions";
import {NzAvatarModule} from "ng-zorro-antd/avatar";
import {NzBadgeModule} from "ng-zorro-antd/badge";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {NzCardModule} from "ng-zorro-antd/card";
import {NzTypographyModule} from "ng-zorro-antd/typography";
import {DragDropModule} from "@angular/cdk/drag-drop";
import {NzModalModule} from "ng-zorro-antd/modal";
import {NzTreeModule} from "ng-zorro-antd/tree";
import {NzListModule} from "ng-zorro-antd/list";
import {NzTableModule} from "ng-zorro-antd/table";
import {NzTagModule} from "ng-zorro-antd/tag";
import {NzSpinModule} from "ng-zorro-antd/spin";
import {NzEmptyModule} from "ng-zorro-antd/empty";
import {NzInputModule} from "ng-zorro-antd/input";
import {WorkComponent} from "./work/work.component";
import {NzRadioModule} from "ng-zorro-antd/radio";
import {FocusLoadingModule} from "../../../component/focus-loading/focus-loading.module";
import {NzDrawerModule} from "ng-zorro-antd/drawer";
import {NzPopconfirmModule} from "ng-zorro-antd/popconfirm";
import {FormUploadModule} from "../../../component/form/uploadbox/form-upload.module";
import {NzCheckboxModule} from "ng-zorro-antd/checkbox";

@NgModule({
  declarations: [EditComponent, ViewComponent, ListComponent, WorkComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NzFormModule,
    NzUploadModule,
    LoadStatusModule,
    NzIconModule,
    ValidateMsgModule,
    FormDateModule,
    FormComboModule,
    NzButtonModule,
    NzPageHeaderModule,
    NzDescriptionsModule,
    NzAvatarModule,
    NzBadgeModule,
    NzSpaceModule,
    NzCardModule,
    NzTypographyModule,
    DragDropModule,
    NzModalModule,
    NzTreeModule,
    NzListModule,
    NzTableModule,
    NzTagModule,
    NzSpinModule,
    NzEmptyModule,
    NzInputModule,
    NzRadioModule,
    FocusLoadingModule,
    NzDrawerModule,
    NzPopconfirmModule,
    FormUploadModule,
    NzCheckboxModule
  ],
  providers: [HomeService]
})
export class HomeModule {
}
