import {Component, OnInit} from '@angular/core';
import {HomeService} from "../home.service";
import {Accounts} from "../../accounts/accounts";
import {Staff} from "../../staff/staff";
import {Location} from "@angular/common";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'home-view',
  templateUrl: './view.component.html'
})
export class ViewComponent implements OnInit {

  empty = false;

  loading = true;

  data: { accounts: Accounts, staff: Staff };

  constructor(private service: HomeService, private location: Location, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return of(params.get('id'));
        } else {
          return of((this.location.getState() as any).staffId);
        }
      })
    ).subscribe(staffId => {
      console.log(staffId);
      this.service.getUserInfo(staffId == null, {staffId}).subscribe(res => {
        this.data = res;
        this.loading = false;
      });
    });
  }

}
