import {Injectable} from '@angular/core';
import {Help} from "../../../utils/Help";
import {Observable} from "rxjs";
import {Router} from "@angular/router";
import {map} from "rxjs/operators";
import {BaseService} from "../../../component/base/base.service";
import {TodoTask} from "../todo-task/todo-task";


@Injectable({
  providedIn: 'root'
})
export class HomeService extends BaseService<TodoTask> {

  protected url = {
    listByPage: '/todotask/listQueryByPage',
    insert: null,
    update: null,
    delete: '/todotask/delete',
    deleteAll: '/todotask/deleteAll'
  };

  constructor(help: Help, private router: Router) {
    super(help);
  }

  getUserInfo(current = true, params = {}): Observable<any> {
    if (current) {
      return this.help.post("/accounts/getCurrentAccounts", params);
    } else {
      return this.help.post("/accounts/getStaffInfo", params);
    }
  }

  saveAccountEdit(formDate: any) {
    return this.help.post("/accounts/saveCurrentAccount", formDate);
  }

  uploadFile(data: any) {
    return this.help.post("/file/upload", data);
  }

  getOftenMenuData() {
    return this.help.post("/oftenmenu/getCurrentOftenMenu", {});
  }

  getCurrentMenusByPid(id: string) {
    return this.help.post("/menus/getCurrentMenusByPid", {pid: id}).pipe(map(({rows}) => {
      const list = [];
      rows.forEach(r => {
        const childFlag = r.childCount > 0;
        list.push({title: r.name, key: r.id, isLeaf: !childFlag, disabled: childFlag, data: r});
      });
      return list;
    }));
  }

  deleteAllOftenMenu() {
    return this.help.get("/oftenmenu/deleteMine");
  }

  updateOftenMenu(data: any) {
    return this.help.post("/oftenmenu/saveOrUpdateList", data);
  }

  addOftenMenu(data: any[]) {
    return this.help.post("/oftenmenu/saveList", data);
  }

  skipMenu(menu: any) {
    this.help.setMenuAuth(menu.auth);
    this.router.navigate([menu.url]).then();
  }

  // 获取流程列表
  getProcess(params) {
    return this.help.post('/workprocess/listQueryByPage', params);
  }

  saveOrUpdate(params) {
    return this.help.post('/todotask/save', params);
  }

  // 获取待办类型统计
  queryTypeCount() {
    return this.help.get("/todotask/queryTypeCount");
  }

  // 获取待办标签统计
  queryLabelCount(startDate: string, endDate: string) {
    return this.help.post("/todotask/queryLabelCount", {startDate: startDate, endDate: endDate});
  }

  // 获取我的待办集合
  getTodoList(params) {
    return this.help.post("/todotask/listQueryByPage", {...params, pageSize: 5, pageNum: 1});
  }

  // 根据code查询字典数据
  getDictionaryData(typeCode: string) {
    return this.help.post("/dictionarydata/listQueryByTypeCode/" + typeCode, {});
  }

  // 获取菜单权限
  getMenuAuthByPath(path: string) {
    return this.help.post("/menurole/queryAuthByPath", {path: path});
  }

  // 保存我的待办
  saveMineTask(data: any) {
    return this.help.post("/schedule/save", data);
  }

  // 获取我的日程
  getMineSchedule() {
    return this.help.post("/schedule/listQueryByPage", {pageNum: 1, pageSize: 5, status: 0});
  }

  // 完成我的待办
  completeTask(data: any) {
    return this.help.post("/todotask/completeTask", data);
  }
}
