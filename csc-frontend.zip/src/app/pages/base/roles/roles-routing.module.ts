import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";
import {EditmenusComponent} from "./editmenus/editmenus.component";
import {EditAppMenusComponent} from "./edit-app-menus/editappmenus.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '角色列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '角色详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加角色'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑角色'}},
  {path: 'editmenus/:id', component: EditmenusComponent, data: {title: '角色菜单授权'}},
  {path: 'editappmenus/:id', component: EditAppMenusComponent, data: {title: '角色APP菜单授权'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RolesRoutingModule {
}
