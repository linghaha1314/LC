import {Component, OnInit} from '@angular/core';
import {Roles} from '../roles';
import {ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {RolesService} from "../roles.service";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzFormatEmitEvent, NzTreeNodeOptions} from 'ng-zorro-antd/tree';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'app-menus-editauth',
  templateUrl: './editappmenus.component.html',
  styles: []
})
export class EditAppMenusComponent extends BaseEditComponent<Roles> implements OnInit {

  roleId: string;

  nodes: NzTreeNodeOptions[] = [];
  saveList = [];
  deleteList = [];

  constructor(location: Location, message: NzMessageService, public service: RolesService, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit(): void {
    this.route.params.subscribe(res => {
      this.roleId = res.id;
      this.initGroup();
    });
  }

  initGroup() {
    this.service.appMenuGroup({}).subscribe((data: any) => {
      this.isLoading = false;
      if (data.success) {
        this.nodes = this.formatData(data.data.rows, "group");
      }
    });
  }

  listChild(event) {
    if (event.keys.length < 1 || event.node.getChildren().length > 0) {
      return;
    }
    const menuName = event.node.title;
    this.isLoading = true;
    this.service.appGroupMenus({groupName: menuName, roleId: this.roleId}).subscribe((data: any) => {
      this.isLoading = false;
      if (data.success) {
        event.node.addChildren(this.formatData(data.data.rows, "menu"));
      }
    });
  }

  formatData(list, level) {
    const tmpList: NzTreeNodeOptions[] = [];
    list.forEach(item => {
      const tmpItem: NzTreeNodeOptions = {
        title: item.group,
        key: item.id,
        id: item.id,
        icon: item.icon
      };
      if ("menu" === level) {
        tmpItem.title = item.name;
        tmpItem.isLeaf = true;
        tmpItem.isMenu = true;
      }
      if (item.checked == "true") {
        tmpItem.checked = true;
        this.saveList.push(item.id);
      }
      tmpList.push(tmpItem);
    });
    return tmpList;
  }

  saveData() {
    this.isLoading = true;
    const params = {
      saveList: [...new Set(this.saveList)],
      deleteList: [...new Set(this.deleteList)],
      roleId: this.roleId
    };
    this.service.saveAppMenuRole(params).subscribe((res: any) => {
      this.isLoading = false;
      if (res.success) {
        this.message.success('保存成功!');
      }
    });
  }

  checkBoxChange(event: NzFormatEmitEvent) {
    const node = event.node;
    if (node.isChecked) {
      this.deleteList = this.changeList(this.saveList, this.deleteList, node, node.children)
    } else {
      this.saveList = this.changeList(this.deleteList, this.saveList, node, node.children)
    }
    console.log(this.saveList, "save");
    console.log(this.deleteList, "delete");
  }

  changeList(addList, removeList, node, children) {
    const id = node.origin["id"];
    if (children.length > 0) {
      children.forEach(n => {
        addList.push(n.origin["id"]);
        removeList = removeList.filter(item => item != n.origin["id"]);
      })
    } else {
      addList.push(id);
      removeList = removeList.filter(item => item != id);
    }
    return removeList;
  }

}
