export class Roles {
  id: string;
  name: string;
  code: string;
  describle: string;
  status: number;
  created: any;
  adminFlag: number;
}
