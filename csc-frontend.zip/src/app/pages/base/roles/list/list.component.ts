import {Component, OnInit} from "@angular/core";
import {Roles} from "../roles";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {RolesService} from "../roles.service";

@Component({
  selector: 'roles-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Roles> implements OnInit {

  constructor(public modal: NzModalService, public service: RolesService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
