import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Roles} from "./roles";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class RolesService extends BaseService<Roles> {
  url = {
    listByPage: '/roles/listQueryByPage',
    insert: '/roles/save',
    update: '/roles/update',
    delete: '/roles/delete',
    deleteAll: '/roles/deleteAll',
    menusList: '/menurole/listQueryByPage',
    menusListAll: '/menus/listQuery',
    menusSave: '/menurole/saveOrUpdateList', // updateAuthList
    menusCheck: '/menurole/listByRoleId',
    menusAuthSave: '/menurole/updateAuthList',
    appMenuGroup: '/appmenus/listAllAppMenusGroup',
    apoGroupMenus: '/appmenus/listAppMenusByGroup',
    saveAppMenuRoleList: '/appmenurole/saveList',
    // menusDel: '/deleteAll/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

  // 获取全部菜单
  getMenusAll(params) {
    return this.help.post(this.url.menusListAll, params);
  }

  // 获取已选择菜单
  getMenus(params) {
    return this.help.post(this.url.menusList, params);
  }

  // 保存选中菜单
  getMenusSave(params) {
    return this.help.post(this.url.menusSave, params);
  }

  // 获取选中的菜单
  getCheckedMenu(params) {
    return this.help.post(this.url.menusCheck, params);
  }

  // 保存权限
  saveAuthMenu(params) {
    return this.help.post(this.url.menusAuthSave, params);
  }

  // 获取APP菜单分组
  appMenuGroup(params) {
    return this.help.post(this.url.appMenuGroup, params);
  }

  // 获取分组下的菜单
  appGroupMenus(params) {
    return this.help.post(this.url.apoGroupMenus, params);
  }

  // 保存App权限
  saveAppMenuRole(params) {
    return this.help.post(this.url.saveAppMenuRoleList, params);
  }

}
