import {Component, OnInit, ViewChild} from '@angular/core';
import {Roles} from '../roles';
import {ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {RolesService} from "../roles.service";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzFormatEmitEvent, NzTreeComponent, NzTreeNodeOptions} from 'ng-zorro-antd/tree';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'app-editauth',
  templateUrl: './editmenus.component.html',
  styles: [
      `
      button {
        margin-top: 15px;
      }
    `
  ]
})
export class EditmenusComponent extends BaseEditComponent<Roles> implements OnInit {

  // 权限类型
  operation: NzTreeNodeOptions[] = [
    {title: '查看', id: 'list', key: '', isLeaf: true, checked: false, icon: 'list-alt'},
    {title: '添加', id: 'add', key: '', isLeaf: true, checked: false, icon: 'plus'},
    {title: '修改', id: 'update', key: '', isLeaf: true, checked: false, icon: 'pen'},
    {title: '删除', id: 'delete', key: '', isLeaf: true, checked: false, icon: 'trash-alt'},
    {title: '申请', id: 'apply', key: '', isLeaf: true, checked: false, icon: 'user-plus'},
    {title: '审核', id: 'audit', key: '', isLeaf: true, checked: false, icon: 'check'}
  ];

  roleId: string;

  defaultCheckedKeys = {};

  nodes: NzTreeNodeOptions[] = [];

  @ViewChild('tree', {static: false})
  treeComponent!: NzTreeComponent;

  constructor(location: Location, message: NzMessageService, public service: RolesService, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit(): void {
    this.route.params.subscribe(res => {
      this.roleId = res.id;
      // 处理选中的菜单
      this.service.getMenus({roleId: res.id}).subscribe((d: any) => {
        d.rows.forEach(r => {
          r.auth?.split(',').forEach(c => this.defaultCheckedKeys[r.menuId + '-' + c] = true);
          this.defaultCheckedKeys[r.menuId] = true;
        });
        this.getMenuData('0');
      });
    });
  }

  // 统一获取数据
  getMenuData(parentId, menu?: any) {
    if (menu && menu.children.length > 0) {
      return;
    }
    if (menu) {
      menu.loading = true;
    }
    this.service.getMenusAll({"parentId": parentId, "status": 0}).subscribe((d: any) => {
      this.isLoading = false;
      if (parentId == '0') {
        this.nodes = this.compileMenuData(d.rows);
      } else {
        menu.addChildren(this.compileMenuData(d.rows));
      }
    });
  }

  // 处理为界面可显示的数据
  compileMenuData(list: any[]): any[] {
    const d: NzTreeNodeOptions[] = [];
    list.forEach(m => {
      const a: NzTreeNodeOptions = {key: m.id, title: m.name, originalCheck: null, id: m.id};
      a.isLeaf = false;
      a.icon = m.icon;
      a.childFlag = m.childCount > 0;
      a.checked = this.defaultCheckedKeys[m.id];
      a.originalCheck = a.checked;
      d.push(a);
    });
    return d;
  }

  // 处理功能权限数据
  getOperation(key: string) {
    const d: NzTreeNodeOptions[] = [];
    this.operation.forEach(m => {
      const a: NzTreeNodeOptions = {...m};
      a.key = key + '-' + m.id;
      a.menuId = key;
      a.checked = this.defaultCheckedKeys[a.key];
      a.originalCheck = a.checked;
      d.push(a);
    });
    return d;
  }

  // 加载下级
  openChild(event: NzFormatEmitEvent): void {
    this.isLoading = event.node.isLoading;
    if (event.node.origin.childFlag === false) {
      if (event.node.children.length > 0) {
        return;
      }
      event.node.addChildren(this.getOperation(event.node.key));
      this.isLoading = false;
    } else {
      this.getMenuData(event.node.key, event.node);
    }
  }

  // 获取选择数据
  getCheckedData(): any {
    let list = [];
    this.nodes.forEach(n => {
      if (n.checked != n.originalCheck) {
        list.push({id: n.id, checked: n.checked, key: n.key, menuId: n.menuId});
      }
      list = list.concat(this.getChildChecked(n));
    });
    const d = {};
    list.forEach(r => d[r.key] = r);
    return d;
  }

  getChildChecked(menu: NzTreeNodeOptions): any[] {
    let list = [];
    if (menu.children) {
      if (menu.childFlag === false) {
        menu.children.forEach(m => {
          if (m.checked) {
            list.push({id: m.id, checked: m.checked, key: m.key, menuId: m.menuId});
          }
        });
      } else {
        menu.children.forEach(m => {
          if (m.checked != m.originalCheck) {
            list.push({id: m.id, checked: m.checked, key: m.key, menuId: m.menuId});
          }
          list = list.concat(this.getChildChecked(m));
        });
      }
    }
    return list;
  }

  saveData() {
    const list = this.getCheckedData();
    this.treeComponent.getHalfCheckedNodeList().forEach(n => {
      if (list[n.key] === undefined) {
        list[n.key] = {id: n.origin.id, checked: n.origin.checked, key: n.origin.key, menuId: n.origin.menuId};
      }
      if (list[n.key].checked === false && n.origin.originalCheck === true) {
        delete list[n.key];
      }
      if (n.origin.originalCheck === false) {
        list[n.key].checked = true;
      }
    });
    for (const k in list) {
      if (list.hasOwnProperty(k) && list[k].menuId) {
        if (list[list[k].menuId] === undefined) {
          list[list[k].menuId] = {id: list[k].menuId, checked: true, key: list[k].menuId, auth: []};
        }
        if (list[list[k].menuId].auth === undefined) {
          list[list[k].menuId].auth = [];
        }
        if (list[list[k].menuId].checked) {
          list[list[k].menuId].auth.push(list[k].id);
        }
        delete list[k];
      }
    }
    const data = [];
    for (const k in list) {
      if (list.hasOwnProperty(k)) {
        if (list[k].auth === undefined) {
          list[k].auth = [];
        }
        data.push({menuId: list[k].id, checkFlag: list[k].checked, roleId: this.roleId, auth: list[k].auth.join(',')});
      }
    }
    this.isLoading = true;
    this.service.saveAuthMenu(data).subscribe((res: any) => {
      this.isLoading = false;
      if (res.success) {
        this.message.success('保存成功!');
      }
    });
  }
}
