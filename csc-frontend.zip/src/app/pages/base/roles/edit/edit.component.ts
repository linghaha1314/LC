import {Component, OnInit} from "@angular/core";
import {Roles} from "../roles";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {RolesService} from "../roles.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'roles-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Roles> implements OnInit {

  constructor(public location: Location, public service: RolesService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Roles());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(50)]],
        code: [d.code, [Validators.required, Validators.maxLength(50)]],
        describle: [d.describle, [Validators.maxLength(250)]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        created: [d.created],
        adminFlag: [d.adminFlag || 0, [Validators.required, Validators.maxLength(11)]],
      });
      this.isLoading = false;
    });
  }

}
