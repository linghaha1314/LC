import {Component, OnInit} from "@angular/core";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {ExamStaff} from "../exam-staff";
import {ExamStaffService} from "../exam-staff.service";
import {ImportConfig} from "../../../../component/import-data/import-data";

@Component({
  selector: 'exam-staff-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<ExamStaff> implements OnInit {

  tableStatus = 0;
  typeList = [{code: 'examiner', name: '考官'}, {code: 'spPatients', name: 'sp病人'}];
  importConfig: ImportConfig = {
    url: '/staff/importStaff',
    template: '/xlsx/考试考官及sp病人导入模板.xlsx',
    validateUrl: '/staff/validateData',
    extraParams: {templateId: null},
    columns: [
      {
        field: 'name',
        text: '名称',
        editor: {type: "string", max: 20, min: 1, require: true}
      },
      {
        field: 'mobile',
        text: '手机号',
        editor: {
          type: "string",
          max: 11,
          require: true
        }
      },
      {
        field: 'importType',
        text: '导入类型',
        editor: {type: "radio", sources: ["考官", "sp病人"], require: true}
      },
      {
        field: 'genderName',
        text: '性别',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/gender",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'identifyTypeName',
        text: '证件类型',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/CreditType",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'identifyNo',
        text: '证件号',
        editor: {
          type: "string",
          max: 50,
          require: true
        }
      },
      {
        field: 'serialNo',
        text: '胸牌号',
        editor: {
          type: "string",
          max: 20,
          require: true
        }
      },
      {
        field: 'typeName',
        text: '人员类型',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/staffType",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'academicName',
        text: '学历',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/Education",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'degreeName',
        text: '学位',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/Degree",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'positionName',
        text: '职位',
        editor: {
          type: "combo",
          url: "/dictionarydata/listQueryByTypeCode/Position",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'majorName',
        text: '专业',
        editor: {
          type: "combo",
          url: "/majors/listQueryByPage",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'sectionName',
        text: '科室',
        editor: {
          type: "combo",
          url: "/sections/listQueryByPage",
          valueKey: "name",
          require: true
        }
      },
      {
        field: 'departmentName',
        text: '教研室',
        editor: {
          type: "combo",
          url: "/department/listQueryByPage",
          valueKey: "name",
          require: true
        }
      },
    ]
  };

  constructor(modal: NzModalService, public service: ExamStaffService, message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.queryParams.roleCode = this.typeList[this.tableStatus].code;
    this.service.roleCode = this.typeList[this.tableStatus].code;
    this.getData();
    this.refreshChecked();
  }

  changeTable(index, data) {
    this.tableStatus = index;
    this.queryParams.roleCode = data.code;
    this.service.pageNum = 0;
    this.service.pageSize = 10;
    this.pageIndex = 1;
    this.pageSize = 10;
    this.service.flag = false;
    this.service.roleCode = data.code;
    this.reloadData();
  }

  getData() {
    this.loading = true;
    this.service.queryParams = this.queryParams;
    this.service.getData()
      .subscribe(data => {
        this.loading = false;
        this.list = data.list;
        this.list.forEach(value => {
          value["encMobile"] = (value.mobile).replace(/(\d{3})\d{4}(\d{4})/, "$1****$2");
          value["encIdentifyNo"] = (value.identifyNo).replace(/(\d{4})\d{10}(\d{2})/, "$1************$2");
        });
        this.total = data.total;
        this.refreshChecked();
      }, ({error}) => {
        this.loading = false;
        this.message.error(`请求出现错误: ${error.msg}`);
      });
  }
}
