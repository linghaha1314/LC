import {Component, OnInit} from "@angular/core";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";
import {ExamStaffService} from "../exam-staff.service";
import {ExamStaff} from "../exam-staff";

@Component({
  selector: 'exam-staff-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<ExamStaff> implements OnInit {

  constructor(location: Location, public service: ExamStaffService, message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new ExamStaff());
        }
      })
    ).subscribe(d => {
      if (this.service.roleCode != 'spPatients') {
        this.validateForm = this.fb.group({
          id: [d.id, [Validators.maxLength(40)]],
          name: [d.name, [Validators.required, Validators.maxLength(20)]],
          genderId: [d.genderId, [Validators.required, Validators.maxLength(40)]],
          birthday: [d.birthday],
          academicId: [d.academicId, [Validators.required, Validators.maxLength(40)]],
          academicName: [d.academicName],
          degreeId: [d.degreeId, [Validators.required, Validators.maxLength(40)]],
          degreeName: [d.degreeName],
          avator: [d.avator, [Validators.maxLength(255)]],
          titleId: [d.titleId, [Validators.required, Validators.maxLength(40)]],
          titleName: [d.titleName],
          typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
          typeName: [d.typeName],
          sectionId: [d.sectionId, [Validators.required, Validators.maxLength(40)]],
          sectionName: [d.sectionName],
          majorId: [d.majorId, [Validators.required, Validators.maxLength(40)]],
          majorName: [d.majorName],
          identifyTypeId: [d.identifyTypeId, [Validators.required, Validators.maxLength(40)]],
          identifyNo: [d.identifyNo, [Validators.required, Validators.maxLength(20)]],
          serialNo: [d.serialNo, [Validators.required, Validators.maxLength(20)]],
          mobile: [d.mobile, [Validators.required, Validators.maxLength(20)]],
          email: [d.email, [Validators.maxLength(50)]],
          remark: [d.remark, [Validators.maxLength(255)]],
          userId: [d.userId, [Validators.maxLength(40)]],
          departmentId: [d.departmentId, [Validators.maxLength(40)]],
          departmentName: [d.departmentName],
          created: [d.created],
          status: [d.status, [Validators.required, Validators.maxLength(11)]],
          hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        });
      } else {
        this.validateForm = this.fb.group({
          id: [d.id, [Validators.maxLength(40)]],
          name: [d.name, [Validators.required, Validators.maxLength(20)]],
          genderId: [d.genderId, [Validators.required, Validators.maxLength(40)]],
          avator: [d.avator, [Validators.maxLength(255)]],
          identifyTypeId: [d.identifyTypeId, [Validators.required, Validators.maxLength(40)]],
          identifyNo: [d.identifyNo, [Validators.required, Validators.maxLength(20)]],
          mobile: [d.mobile, [Validators.required, Validators.maxLength(20)]],
          userId: [d.userId, [Validators.maxLength(40)]],
          created: [d.created],
          status: [d.status, [Validators.required, Validators.maxLength(11)]],
          hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        });
      }
      this.isLoading = false;
    });
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        if (this.validateForm.value["id"] == null) {
          // 添加考官或sp病人角色
          this.service.saveOrUpdateStaffRole({
            staffId: res.data.staff.id,
            roleCode: this.service.roleCode
          }).subscribe((rs: any) => {
            this.message.success('保存角色成功!');
          });
        }
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            if (back) {
              this.location.back();
            } else {
              this.validateForm.reset();
            }
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }
}
