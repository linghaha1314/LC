import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {ExamStaff} from "./exam-staff";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class ExamStaffService extends BaseService<ExamStaff> {
  url = {
    listByPage: '/staff/listQueryRoleCodeByPage',
    insert: '/staff/addStaff',
    update: '/staff/update',
    delete: '/staff/delete',
    deleteAll: '/staff/deleteAll',
    saveRole: '/accountrole/saveStaffRoleByCode'
  };

  roleCode = "";

  constructor(help: Help) {
    super(help);
  }

  saveOrUpdateStaffRole(params: {}) {
    return this.help.post(this.url.saveRole, params);
  }

}
