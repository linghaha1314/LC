import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Semester} from "./semester";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class SemesterService extends BaseService<Semester> {
  protected url = {
    listByPage: '/semester/listQueryByPage',
    insert: '/semester/save',
    update: '/semester/update',
    delete: '/semester/delete',
    deleteAll: '/semester/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
