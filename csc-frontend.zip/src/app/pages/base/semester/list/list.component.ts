import {Component, OnInit} from "@angular/core";
import {Semester} from "../semester";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {SemesterService} from "../semester.service";

@Component({
  selector: 'semester-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Semester> implements OnInit {

  constructor(public modal: NzModalService, public service: SemesterService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
