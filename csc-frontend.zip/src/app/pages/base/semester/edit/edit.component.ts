import {Component, OnInit} from "@angular/core";
import {Semester} from "../semester";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {SemesterService} from "../semester.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'semester-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Semester> implements OnInit {

  constructor(public location: Location, public service: SemesterService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(20)]],
      year: [null, [Validators.maxLength(11)]],
      status: [null, [Validators.maxLength(11)]],
      created: [null],
      yearDate: [null, [Validators.required, Validators.maxLength(11)]],
      hospitalId: [null, [Validators.maxLength(40)]],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Semester());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        d.yearDate = new Date(d.year + "-01-01 00:00:00");
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    const data = this.validateForm.value;
    data["status"] = 0;
    data["year"] = this.validateForm.value["yearDate"].getFullYear();
    this.service.saveOrUpdateData(data).subscribe(res => {
      if (res.success) {
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            if (back) {
              this.location.back();
            } else {
              this.validateForm.reset();
            }
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }
}
