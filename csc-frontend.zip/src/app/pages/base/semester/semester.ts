export class Semester {
  id: string;
  name: string;
  year: number;
  yearDate: any;
  status: number;
  created: any;
  hospitalId: string;
}
