import {Component, OnInit} from "@angular/core";
import {AppMenus} from "../app-menus";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {AppMenusService} from "../app-menus.service";
import {Help} from "../../../../utils/Help";

@Component({
  selector: 'app-menus-list',
  templateUrl: './list.component.html',
  styles: []
})

export class ListComponent extends BaseListComponent<AppMenus> implements OnInit {

  constructor(public modal: NzModalService, public service: AppMenusService, public message: NzMessageService, private help: Help) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }


}
