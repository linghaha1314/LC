import {Component, OnInit} from "@angular/core";
import {AppMenus} from "../app-menus";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {AppMenusService} from "../app-menus.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'app-menus-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<AppMenus> implements OnInit {

  iconHTML: String = "";

  constructor(public location: Location, public service: AppMenusService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new AppMenus());
        }
      })
    ).subscribe(d => {
      this.iconHTML = d.icon || "";
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(50)]],
        code: [d.code, [Validators.required, Validators.maxLength(50)]],
        group: [d.group, [Validators.required, Validators.maxLength(50)]],
        icon: [d.icon, [Validators.required]],
        sort: [d.sort, [Validators.required, Validators.maxLength(11)]],
        remark: [d.remark, [Validators.maxLength(255)]],
        userId: [d.userId, [Validators.maxLength(40)]],
        created: [d.created],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        userName: [d.userName],
      });
      this.isLoading = false;
    });
  }

  svgInput() {
    this.iconHTML = this.validateForm.get("icon").value;
  }

}
