export class AppMenus {
  id: string;
  name: string;
  code: string;
  group: string;
  icon: string;
  sort: number;
  remark: string;
  userId: string;
  created: any;
  status: number;
  userName: string;
}
