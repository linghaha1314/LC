import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {AppMenus} from "./app-menus";
import {Help} from "../../../utils/Help";

@Injectable({
  providedIn: 'root'
})
export class AppMenusService extends BaseService<AppMenus> {
  protected url = {
    listByPage: '/appmenus/listQueryByPage',
    insert: '/appmenus/save',
    update: '/appmenus/update',
    delete: '/appmenus/delete',
    deleteAll: '/appmenus/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }


}
