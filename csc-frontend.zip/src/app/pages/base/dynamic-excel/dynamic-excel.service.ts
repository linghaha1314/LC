import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {DynamicExcel} from "./dynamic-excel";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class DynamicExcelService extends BaseService<DynamicExcel> {
  protected url = {
    listByPage: '/dynamicexcel/listQueryByPage',
    insert: '/dynamicexcel/save',
    update: '/dynamicexcel/update',
    delete: '/dynamicexcel/delete',
    deleteAll: '/dynamicexcel/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
