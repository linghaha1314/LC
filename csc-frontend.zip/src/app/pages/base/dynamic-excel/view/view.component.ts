import {Component, OnInit} from '@angular/core';
import {DynamicExcel} from "../dynamic-excel";
import {DynamicExcelService} from "../dynamic-excel.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'dynamic-excel-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: DynamicExcel = new DynamicExcel();

  constructor(private service: DynamicExcelService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new DynamicExcel());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
