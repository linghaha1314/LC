import {Component, OnInit} from "@angular/core";
import {DynamicExcel} from "../dynamic-excel";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {DynamicExcelService} from "../dynamic-excel.service";

@Component({
  selector: 'dynamic-excel-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<DynamicExcel> implements OnInit {

  constructor(public modal: NzModalService, public service: DynamicExcelService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
