export class DynamicExcel {
  id: string;
  name: string;
  typeId: string;
  params: string;
  remark: string;
  status: number;
  created: any;
  userId: string;
  hospitalId: string;
  typeName: string;
  userName: string;
}
