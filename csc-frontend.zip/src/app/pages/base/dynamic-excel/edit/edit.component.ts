import {Component, OnInit, ViewChild} from "@angular/core";
import {DynamicExcel} from "../dynamic-excel";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {DynamicExcelService} from "../dynamic-excel.service";
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";
import {ExcelTableComponent} from "../../../../component/excel-table/excel-table.component";

@Component({
  selector: 'dynamic-excel-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<DynamicExcel> implements OnInit {

  @ViewChild("excel")
  excel: ExcelTableComponent;

  columnVisible = false;
  columnForm: FormGroup;
  sources: string[] = [];
  columnType: any[] = [
    {id: 'text', name: '文本框'},
    {id: 'numeric', name: '数字框'},
    {id: 'checkbox', name: '复选框'},
    {id: 'password', name: '密码框'},
    {id: 'autocomplete', name: '自动填充框'},
    {id: 'select', name: '下拉框'},
    {id: 'date', name: '日期框'},
    {id: 'time', name: '时间框'}
  ];
  menuConfig = {
    col_add_left: {
      name() {
        return '左边添加列';
      },
      callback: (key, selection) => {
        this.addColumn(selection[0].end.col);
      }
    },
    col_add_right: {
      name() {
        return '右边添加列';
      },
      callback: (key, selection) => {
        this.addColumn(selection[0].end.col, 'right');
      }
    },
  };
  private columnIndex = 0;

  constructor(public location: Location, public service: DynamicExcelService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.columnForm = this.fb.group({
      name: [null, [Validators.required, Validators.maxLength(200)]],
      code: [null, [Validators.required, Validators.maxLength(200)]],
      type: [null, [Validators.required]],
      format: [null, [Validators.maxLength(30)]],
      min: [null],
      max: [null],
      pattern: [null],
    });
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(200)]],
      typeId: [null, [Validators.required, Validators.maxLength(40)]],
      params: [null, [Validators.required]],
      remark: [null, [Validators.maxLength(500)]],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      typeName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new DynamicExcel());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

  addColumn(col: number, type = 'left') {
    if (type == 'right') {
      this.columnIndex = col + 1;
    } else {
      this.columnIndex = col;
    }
    this.columnVisible = true;
    this.columnForm.reset();
  }

  removeSource(i) {
    this.sources.splice(i, 1);
  }

  changeSource(v, i) {
    this.sources[i] = v.target.value;
  }

  saveColumn() {
    if (!this.columnForm.valid) {
      return;
    }
    const setting = this.excel.tableSettings;
    const columns: any = setting.columns;
    const headers: any = setting.colHeaders;
    const col: any = {data: this.columnForm.value['code']};
    const type = this.columnForm.value['type'];
    if (type == 'date') {
      col.editor = type;
      col.dateFormat = 'YYYY-MM-DD';
    } else if (type == 'numeric') {
      col.type = type;
      col.numericFormat = {pattern: this.columnForm.value['pattern']};
      const {min, max} = this.columnForm.value;
      col.validator = function(value, callback) {
        let flag = true;
        if (min != null) {
          flag = value >= min;
        }
        if (flag && max != null) {
          flag = value <= max;
        }
        callback(flag);
      };
    } else if (type == 'autocomplete') {
      col.type = type;
      col.source = this.sources;
      col.strict = false;
    } else if (type == 'select') {
      col.editor = type;
      col.selectOptions = this.sources;
    } else {
      col.type = type;
    }
    columns.splice(this.columnIndex, 0, col);
    headers.splice(this.columnIndex, 0, this.columnForm.value['name']);
    setTimeout(() => {
      this.excel.updateSettings({
        columns,
        colHeaders: headers
      });
      this.columnVisible = false;
    }, 0);
  }

  save() {
    this.excel.getSetting();
  }

}
