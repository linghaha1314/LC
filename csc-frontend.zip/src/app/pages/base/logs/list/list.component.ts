import {Component, OnInit} from "@angular/core";
import {Logs} from "../logs";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {LogsService} from "../logs.service";

@Component({
  selector: 'logs-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<Logs> implements OnInit {

  queryParams = {name: null, created: null};

  constructor(modal: NzModalService, service: LogsService, message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
    this.refreshChecked();
  }
}
