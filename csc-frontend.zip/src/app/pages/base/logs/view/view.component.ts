import {Component, OnInit} from '@angular/core';
import {Logs} from "../logs";
import {LogsService} from "../logs.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'logs-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewComponent implements OnInit {

  empty = false;

  data: Logs = new Logs();

  constructor(private service: LogsService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Logs());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
