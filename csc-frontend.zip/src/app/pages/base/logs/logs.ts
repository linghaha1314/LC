export class Logs {
  id: string;
  name: string;
  method: string;
  fullMethod: string;
  data: string;
  times: number;
  sql: string;
  ip: string;
  userId: string;
  created: any;
  status: number;
  hospitalId: string;
  userName: string;
}
