import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '操作日志表列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '操作日志表详情'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LogsRoutingModule {
}
