import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Logs} from "./logs";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class LogsService extends BaseService<Logs> {
  url = {
    listByPage: '/logs/listQueryByPage',
    insert: '/logs/save',
    update: '/logs/update',
    delete: '/logs/delete',
    deleteAll: '/logs/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
