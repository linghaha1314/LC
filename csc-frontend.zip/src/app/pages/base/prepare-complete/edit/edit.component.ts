import {Component, OnInit} from "@angular/core";
import {PrepareComplete} from "../prepare-complete";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {PrepareCompleteService} from "../prepare-complete.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import { NzMessageService } from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'prepare-complete-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<PrepareComplete> implements OnInit {

  constructor(public location: Location, public service: PrepareCompleteService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
		  id: [null, [Validators.maxLength(40)]],
		  planId: [null, [Validators.required, Validators.maxLength(40)]],
		  attach: [null, [Validators.required, Validators.maxLength(50)]],
		  remark: [null, [Validators.maxLength(500)]],
		  status: [null, [Validators.required, Validators.maxLength(11)]],
		  created: [null],
		  planName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new PrepareComplete());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

}
