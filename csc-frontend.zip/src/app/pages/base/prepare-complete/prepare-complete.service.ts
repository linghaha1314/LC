import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {PrepareComplete} from "./prepare-complete";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class PrepareCompleteService extends BaseService<PrepareComplete> {
  protected url = {
    listByPage: '/preparecomplete/listQueryByPage',
    insert: '/preparecomplete/save',
    update: '/preparecomplete/update',
    delete: '/preparecomplete/delete',
    deleteAll: '/preparecomplete/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
