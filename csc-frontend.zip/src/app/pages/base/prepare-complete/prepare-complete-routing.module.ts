import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '筹备完成表列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '筹备完成表详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加筹备完成表'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑筹备完成表'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrepareCompleteRoutingModule {
}
