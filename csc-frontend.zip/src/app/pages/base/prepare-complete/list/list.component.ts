import {Component, OnInit} from "@angular/core";
import {PrepareComplete} from "../prepare-complete";
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzModalService } from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {PrepareCompleteService} from "../prepare-complete.service";

@Component({
  selector: 'prepare-complete-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent extends BaseListComponent<PrepareComplete> implements OnInit {

  constructor(public modal: NzModalService, public service: PrepareCompleteService, public message: NzMessageService) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.getData();
  }
}
