export class PrepareComplete {
  id: string;
  planId: string;
  attach: string;
  remark: string;
  status: number;
  created: any;
  planName: string;
}
