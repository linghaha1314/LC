import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '院系表列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '院系表详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加院系表'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑院系表'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FacultyRoutingModule {
}
