import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Faculty} from "./faculty";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class FacultyService extends BaseService<Faculty> {
  protected url = {
    listByPage: '/faculty/listQueryByPage',
    insert: '/faculty/save',
    update: '/faculty/update',
    delete: '/faculty/delete',
    deleteAll: '/faculty/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
