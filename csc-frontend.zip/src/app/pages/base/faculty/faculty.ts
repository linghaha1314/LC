export class Faculty {
  id: string;
  name: string;
  code: string;
  status: number;
  hospitalId: string;
  userId: string;
  created: any;
  userName: string;
}
