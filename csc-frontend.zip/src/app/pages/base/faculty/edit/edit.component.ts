import {Component, OnInit} from "@angular/core";
import {Faculty} from "../faculty";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {FacultyService} from "../faculty.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'faculty-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Faculty> implements OnInit {

  constructor(public location: Location, public service: FacultyService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.validateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(100)]],
      code: [null, [Validators.required, Validators.maxLength(40)]],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      userId: [null, [Validators.maxLength(40)]],
      created: [null],
      userName: [null],
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Faculty());
        }
      })
    ).subscribe(d => {
      if (d.id != null) {
        this.validateForm.patchValue(d);
      }
      this.isLoading = false;
    });
  }

}
