export class Menus {
  id: string;
  name: string;
  code: string;
  path: string;
  icon: string;
  sort: number;
  status: number;
}
