import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";

import {MenusRoutingModule} from './menus-routing.module';
import {ListComponent} from './list/list.component';

import {NzTreeModule} from 'ng-zorro-antd/tree';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzDropDownModule} from 'ng-zorro-antd/dropdown';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzInputNumberModule} from 'ng-zorro-antd/input-number';
import {NzModalModule} from 'ng-zorro-antd/modal';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzFormModule} from 'ng-zorro-antd/form';
// 自定义module
import {MenusService} from './menus.service';
import {LoadStatusModule} from "../../../component/load-status/load-status.module";
import {ValidateMsgModule} from "../../../component/validate-msg/validate-msg.module";
import {NzCardModule} from "ng-zorro-antd/card";
import {FroalaEditorModule} from "../../../component/form/froala-editor/froala-editor.module";
import {FormUploadModule} from "../../../component/form/uploadbox/form-upload.module";
import {NzEmptyModule} from "ng-zorro-antd/empty";
import {NzTableModule} from "ng-zorro-antd/table";
import {FormComboModule} from "../../../component/form/combobox/form-combo.module";
import {NzBadgeModule} from "ng-zorro-antd/badge";
import {DragDropModule} from "@angular/cdk/drag-drop";
import {NzPopconfirmModule} from "ng-zorro-antd/popconfirm";


@NgModule({
  declarations: [ListComponent],
  imports: [
    CommonModule,
    MenusRoutingModule,
    NzTreeModule,
    NzDropDownModule,
    NzIconModule,
    ReactiveFormsModule,
    NzGridModule,
    NzRadioModule,
    NzButtonModule,
    NzFormModule,
    FormsModule,
    LoadStatusModule,
    NzInputModule,
    NzInputNumberModule,
    ValidateMsgModule,
    NzModalModule,
    NzCardModule,
    FroalaEditorModule,
    FormUploadModule,
    NzEmptyModule,
    NzTableModule,
    FormComboModule,
    NzBadgeModule,
    DragDropModule,
    NzPopconfirmModule
  ],
  providers: [MenusService]
})
export class MenusModule {
}

