import {
  AfterContentChecked,
  AfterContentInit,
  Component,
  OnChanges,
  OnInit,
  QueryList,
  SimpleChanges,
  ViewChild,
  ViewChildren
} from '@angular/core';
import {NzContextMenuService, NzDropdownMenuComponent} from 'ng-zorro-antd/dropdown';
import {NzFormatEmitEvent} from 'ng-zorro-antd/tree';
import {NzMessageService} from 'ng-zorro-antd/message';
import {Help} from '../../../../utils/Help';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MenusService} from "../menus.service";
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import {NzTreeNode} from "ng-zorro-antd/core/tree/nz-tree-base-node";

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styles: [
      `
      nz-tree {
        overflow: hidden;
        margin: 0 -24px;
        padding: 0 24px;
      }

      [nz-form] {
        max-width: 600px;
      }

      input {
        width: 100%;
      }
    `
  ]
})

export class ListComponent implements OnInit, AfterContentInit, AfterContentChecked, OnChanges {
  nodes: any[] = [
    {title: '所有菜单', key: '0', icon: 'hashtag'}
  ];
  level = 0;
  parentWidth = 0;
  itemCount = 0;
  delMenuFlag = false;
  isShowBtn = true;
  validateForm!: FormGroup;
  menuFlowValidataForm!: FormGroup;
  menuFlowItemValidateForm!: FormGroup;
  isShow = false;
  isTitle = '新增';
  isHospital = false;
  isLoading = false;
  currentData: any;
  menuFlowItemSort = null;
  current = '';
  currentMenuId = '';
  currentMenuName = '';
  deleteMenuFlowItemId = [];
  isMenuFlowShow = false;
  isMenuFlowOrderShow = false;
  menuFlowItemOrderList = [];
  reloadMenuItemFlag = false;
  menuFlowLoading = false;
  math = Math;
  node: NzTreeNode;
  @ViewChildren('menuFlowItemElement')
  menuFlowItemElementList: QueryList<Element>;
  @ViewChild('menuFlowItemElements')
  menuFlowItemElement: Element;
  viewMenuFlowItemList = [];
  defaultColor = ['#ff9933', '#B3B3B3', '#F3D250', '#0861E7', '#209C51'];
  menuFlowItemList = [
    {"name": 1, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
    {"name": 2, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
    {"name": 3, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
    {"name": 4, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
    {"name": 5, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
    {"name": 6, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
    {"name": 7, "index": 0, "type": 'right', 'downFlag': false, "viewFlag": true},
  ];
  isMenuFlowItemShow = false;
  url = {
    hospitalmenus: '/hospitalmenus/listQuery',
    selfMenus: '/menus/listQuery',
    save: '/hospitalmenus/save',
    update: '/hospitalmenus/update',
    delete: '/hospitalmenus/delete',
    m_save: '/menus/save',
    m_update: '/menus/update',
    m_delete: '/menus/delete',
  };
  position;

  constructor(
    private message: NzMessageService,
    private nzContextMenuService: NzContextMenuService,
    private help: Help,
    private fb: FormBuilder,
    public service: MenusService
  ) {
  }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      name: [null, [Validators.required]],
      code: [null, [Validators.required]],
      path: [null, [Validators.required]],
      icon: [null, [Validators.required]],
      skipMenu: [null],
      skipMenuName: [null],
      sort: [1],
      status: [0],
    });
    this.menuFlowValidataForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(500)]],
      menuId: [null, [Validators.required, Validators.maxLength(40)]],
      params: [null, [Validators.maxLength(500)]],
      remark: [null],
      info: [null],
      attachs: [null],
      status: [null, [Validators.required, Validators.maxLength(11)]],
      created: [null],
      userId: [null, [Validators.maxLength(40)]],
      hospitalId: [null, [Validators.maxLength(40)]],
      menuName: [null],
      userName: [null],
    });
    this.menuFlowItemValidateForm = this.fb.group({
      id: [null, [Validators.maxLength(40)]],
      name: [null, [Validators.required, Validators.maxLength(500)]],
      color: [null, [Validators.maxLength(20)]],
      menuId: [null, [Validators.maxLength(40)]],
      remark: [null],
      menuFlowId: [null, [Validators.maxLength(40)]],
      attachs: [null],
      status: [null, [Validators.maxLength(11)]],
      sort: [null, [Validators.maxLength(11)]],
      menuName: [null],
      menuFlowName: [null],
    });
  }

  // 拼接数据结构
  changeDataArr(arr: any[]) {
    arr.map(item => {
      item.level = this.level;
      item.title = item.name;
      item.key = item.id;
      if (item.childCount) {
        item.children = [];
        item.isLeaf = false;
      } else {
        item.isLeaf = true;
      }
    });
    return arr;
  }

  // 右键菜单
  contextMenu($event: NzFormatEmitEvent, menu: NzDropdownMenuComponent): void {
    this.currentData = $event.node.origin;
    this.node = $event.node;
    this.nzContextMenuService.create($event.event, menu);
    this.isShowBtn = !!this.currentData.id;
  }

  loadChild(event: NzFormatEmitEvent): void {
    this.level = this.level + 1;
    if (event.eventName === 'expand') {
      const node = event.node;
      if (node.children.length === 0 && node?.isExpanded) {
        this.searchNodes(node);
      }
    }
  }

  showMenuFlow(event: NzFormatEmitEvent): void {
    this.currentMenuId = event.node["key"];
    this.currentMenuName = event.node["_title"];
    this.viewInit();
    this.initMenuFlowView();
  }

  initMenuFlowView() {
    this.deleteMenuFlowItemId = [];
    this.menuFlowItemList = [];
    this.viewMenuFlowItemList = [];
    if (this.currentMenuId != null && this.currentMenuId != "0") {
      //获取数据
      this.menuFlowLoading = true;
      this.service.getMenusFlowByMenuId({menuId: this.currentMenuId}).subscribe((res: any) => {
        if (res.total > 0) {
          let data = res.rows[0];
          this.menuFlowValidataForm = this.fb.group({
            id: [data.id, [Validators.maxLength(40)]],
            name: [data.name, [Validators.required, Validators.maxLength(500)]],
            menuId: [data.menuId, [Validators.required, Validators.maxLength(40)]],
            params: [data.params, [Validators.maxLength(500)]],
            remark: [data.remark],
            info: [data.info],
            attachs: [data.attachs],
            status: [data.status, [Validators.required, Validators.maxLength(11)]],
            created: [data.created],
            userId: [data.userId, [Validators.maxLength(40)]],
            hospitalId: [data.hospitalId, [Validators.maxLength(40)]]
          });
          this.service.getMenusFlowItemByMenuId({menuFlowId: data.id}).subscribe((r: any) => {
            if (r.total > 0) {
              r.rows.forEach(i => {
                i["index"] = 0;
                i["type"] = 'right';
                i["downFlag"] = false;
                i["viewFlag"] = true;
              });
              this.menuFlowItemList = r.rows;
              this.viewMenuFlowItemList = [...this.menuFlowItemList];
            }
            this.reloadMenuItemFlag = true;
            this.menuFlowLoading = false;
          });
        } else {
          this.menuFlowLoading = false;
          this.menuFlowValidataForm = this.fb.group({
            id: [null, [Validators.maxLength(40)]],
            name: [this.currentMenuName, [Validators.required, Validators.maxLength(500)]],
            menuId: [this.currentMenuId, [Validators.required, Validators.maxLength(40)]],
            params: [null, [Validators.maxLength(500)]],
            info: [null, [Validators.required]],
            remark: [null],
            attachs: [null, [Validators.required]],
            status: [0, [Validators.required, Validators.maxLength(11)]],
            created: [null],
            userId: [null, [Validators.maxLength(40)]],
            hospitalId: [null, [Validators.maxLength(40)]],
            menuName: [null],
            userName: [null],
          });
        }
      });
    }
  }

  searchNodes(node: NzTreeNode) {
    node.clearChildren();
    const params = {
      parentId: node.key
    };
    node.isLoading = true;
    this.help.post(this.isHospital ? this.url.hospitalmenus : this.url.selfMenus, params).subscribe(res => {
      const data = res['rows'];
      const arr = this.changeDataArr(data);
      node.addChildren(arr);
      node.isLoading = false;
    });
  }

  selectDropdown(str): void {
    if (str === 'del') {
      this.delete();
    } else if (str === 'edit') {
      this.isShow = true;
      this.isTitle = '修改';
      const data = this.currentData;
      let params = {};
      if (this.currentData.params != null) {
        params = JSON.parse(this.currentData.params)
      }
      this.validateForm = this.fb.group({
        name: [data.name, [Validators.required]],
        code: [data.code, [Validators.required]],
        path: [data.path, [Validators.required]],
        icon: [data.icon, [Validators.required]],
        skipMenu: [params['skipMenu']],
        skipMenuName: [params['skipMenuName']],
        sort: [data.sort],
        status: [data.status],
      });
    } else {
      this.isShow = true;
      this.isTitle = '新增';
      this.validateForm = this.fb.group({
        name: [null, [Validators.required]],
        code: [null, [Validators.required]],
        path: [null, [Validators.required]],
        icon: [null, [Validators.required]],
        skipMenu: [null],
        skipMenuName: [null],
        sort: [1],
        status: [0],
      });
    }
  }

  // 删除菜单
  delete() {
    if (this.currentData.id) {

      this.message.info('正在删除...');
      this.help.post(this.url.m_delete, {
        id: this.currentData.id
      }).subscribe(() => {
        this.node.remove();
        this.message.remove();
      });
    } else {
      this.message.info('此菜单不能删除!');
    }
  }

  submitMenusForm(): void {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }
    if (this.validateForm.valid) {
      this.isLoading = true;
      const id = this.currentData.id || '0';
      const parentId = this.currentData.parentId || '0';
      let params = {};
      if (this.currentData.params != null) {
        params = JSON.parse(this.currentData.params)
      }
      params["skipMenu"] = this.validateForm.value["skipMenu"]
      params["skipMenuName"] = this.validateForm.value["skipMenuName"]
      const a = {
        ...this.validateForm.value,
        parentId: id,
        menusId: this.currentData.menusId,
        params: JSON.stringify(params)
      };
      const b = {
        ...this.validateForm.value,
        params: JSON.stringify(params),
        parentId,
        menusId: this.currentData.menusId,
        id
      };
      this.help.post(this.isTitle === '新增' ? this.url.m_save : this.url.m_update, this.isTitle === '新增' ? a : b).subscribe(() => {
        this.isLoading = false;
        this.isShow = false;
        if (this.isTitle === '新增') {
          const node = item => {
            item.map(ite => {
              if (ite.id === this.currentData.key) {
                ite.isLeaf = false;
                ite.children = [];
                ite.childCount = 1;
                return false;
              } else if (ite.children && ite.children.length !== 0) {
                node(ite.children);
              } else {
                return false;
              }
            });
          };
          node(this.nodes);
          this.nodes = [...this.nodes];
        } else {
          this.node.origin = b;
          this.node.title = b.name;
        }
      });
    }

  }

  // 数据树drop事件
  treeDrop(event: NzFormatEmitEvent) {
    const drop = event.dragNode;
    const target = event.node;
    const parentNode = drop.getParentNode();
    if (parentNode.key == target.key) {
      const params = {
        id: drop.key,
        parentId: target.key
      };
      this.service.dragUpdate(params).subscribe(() => {
        target.origin.children = [];
        target.origin.isExpanded = false;
      });
    } else { // 父级id相同就对换sort
      const children = parentNode.getChildren();
      const params = [];
      children.forEach((item, index) => {
        const obj = {
          id: item.key,
          parentId: parentNode.key,
          sort: index
        };
        params.push(obj);
      });
      this.service.changeSort(params).subscribe(res => {
      });
    }
    this.message.success('操作成功!!');
  }

  // 以下弹窗事件
  okClick(): void {
    this.submitMenusForm();
  }

  cancelClick(): void {
    this.isShow = false;
  }

  deleteMenuFlowItem() {
    if (this.menuFlowItemList[this.menuFlowItemSort]['id'] != null) {
      this.deleteMenuFlowItemId.push(this.menuFlowItemList[this.menuFlowItemSort]['id']);
    }
    this.menuFlowItemList.splice(this.menuFlowItemSort, 1);
    this.isMenuFlowItemShow = false;
    this.menuFlowItemSort = null;
    this.viewMenuFlowItemList = [...this.menuFlowItemList];
    this.reloadMenuItemFlag = true;
  }

  okMenuFlowClick() {
    this.service.saveMenuFlow(this.menuFlowValidataForm.value).subscribe((res: any) => {
      if (res.success) {
        this.menuFlowValidataForm.value["id"] = res.data["id"];
        //保存
        this.service.saveMenuFlowItemList({
          menuFlowId: res.data["id"],
          menuFlowItemList: this.menuFlowItemList,
          deleteItemIds: this.deleteMenuFlowItemId.join(",")
        }).subscribe((res: any) => {
          if (res.success) {
            this.message.success("保存信息成功！");
          }
          this.initMenuFlowView();
          this.isMenuFlowShow = false;
        });
      }
    });
  }

  cancelMenuFlowClick() {
    this.isMenuFlowShow = false;
  }

  deleteMenuFlow() {
    this.menuFlowLoading = true;
    this.service.deleteMenuFlow({id: this.menuFlowValidataForm.value["id"]}).subscribe((res: any) => {
      if (res.success) {
        this.message.success("删除成功！");
        this.viewMenuFlowItemList = [];
        this.menuFlowItemList = [];
        this.menuFlowValidataForm = this.fb.group({
          id: [null, [Validators.maxLength(40)]],
          name: [null, [Validators.required, Validators.maxLength(500)]],
          menuId: [null, [Validators.required, Validators.maxLength(40)]],
          params: [null, [Validators.maxLength(500)]],
          info: [null, [Validators.required]],
          attachs: [null, [Validators.required]],
          status: [null, [Validators.required, Validators.maxLength(11)]],
          created: [null],
          userId: [null, [Validators.maxLength(40)]],
          hospitalId: [null, [Validators.maxLength(40)]],
          menuName: [null],
          userName: [null],
        });
      }
      this.menuFlowLoading = false;
    });
  }

  addMenuFlowItem() {
    this.isMenuFlowItemShow = true;
    this.menuFlowItemValidateForm.reset();
  }

  okMenuFlowItemClick() {
    if (!this.menuFlowItemValidateForm.valid) {
      this.message.error("请检查表单！");
      return;
    }
    this.menuFlowItemValidateForm.value["viewFlag"] = true;
    this.menuFlowItemValidateForm.value["index"] = 0;
    this.menuFlowItemValidateForm.value["downFlag"] = false;
    this.menuFlowItemValidateForm.value["type"] = "right";
    if (this.menuFlowItemValidateForm.value["color"] == null || this.menuFlowItemValidateForm.value["color"] == '') {
      this.menuFlowItemValidateForm.value["color"] = this.defaultColor[this.viewMenuFlowItemList.length % 5];
    }
    if (this.menuFlowItemSort != null) {
      this.menuFlowItemList[this.menuFlowItemSort] = this.menuFlowItemValidateForm.value;
      this.menuFlowItemSort = null;
    } else {
      this.menuFlowItemList.push(this.menuFlowItemValidateForm.value);
    }
    this.isMenuFlowItemShow = false;
    this.viewMenuFlowItemList = [...this.menuFlowItemList];
    this.reloadMenuItemFlag = true;
    this.afterViewChange();
  }

  cancelMenuFlowItemClick() {
    this.isMenuFlowItemShow = false;
    this.menuFlowItemSort = null;
    this.menuFlowItemValidateForm.reset();
  }

  showMenuFlowItem(i, dataList, c) {
    //获取这一排的数据
    let indexs = i;
    if (i % c != 0) {
      indexs = i - (i % c);
    }
    if (dataList[indexs + c] != null) {
      let index = i + (c - (i % c) * 2) - 1;
      return index;
    } else {
      //获取这一排有多少个值
      let count = dataList.length - indexs;
      let index = i + (count - (i % count) * 2) - 1;
      return index;
    }
  }

  afterViewChange() {
    let parentWidth = this.menuFlowItemElement['nativeElement'].clientWidth;
    let count = Math.floor((parentWidth - 234) / 312) + 1;
    if (this.menuFlowItemList.length < count) {
      count = this.menuFlowItemList.length;
    }
    if (parentWidth != this.parentWidth || this.reloadMenuItemFlag) {
      this.parentWidth = parentWidth;
      this.itemCount = count;
      this.reloadMenuItemFlag = false;
      let viewMenuFlowItemList = JSON.parse(JSON.stringify(this.menuFlowItemList));
      let allNumber = this.math.ceil(viewMenuFlowItemList.length / count);
      let lastIndex = (allNumber - 1) * count - 1;
      let s = count - (viewMenuFlowItemList.length % count);
      if (viewMenuFlowItemList.length % count != 0) {
        for (let i = 0; i < s; i++) {
          viewMenuFlowItemList.push({"name": 1, "index": 0, "type": 'right', 'downFlag': false, 'viewFlag': false});
        }
      }
      let lastNumber = viewMenuFlowItemList.length - lastIndex - 1;
      viewMenuFlowItemList.forEach((s, i) => {
        viewMenuFlowItemList[i]["index"] = 0;
        viewMenuFlowItemList[i]["downFlag"] = false;
        let number = this.math.ceil((i + 1) / count);
        let d = (i + 1) % count;
        let n = number % 2;
        if (viewMenuFlowItemList[i + 1] != null) {
          viewMenuFlowItemList[i]["index"] = 0;
          if (n == 1) {
            if (viewMenuFlowItemList[i + 1]["viewFlag"]) {
              viewMenuFlowItemList[i]["type"] = "right";
            } else {
              viewMenuFlowItemList[i]["type"] = "last";
            }
            if (d == 0) {
              viewMenuFlowItemList[i]["type"] = "";
              viewMenuFlowItemList[i]["downFlag"] = true;
            }
          } else {
            viewMenuFlowItemList[i]["type"] = d != 0 ? "left" : "";
            let h = i > lastIndex ? this.math.ceil(lastNumber / 2) : this.math.ceil(count / 2);
            let c = i > lastIndex ? lastNumber : count;
            let k = c % 2;
            if (d != h || k == 0) {
              let ix;
              if (c % 2 == 1) {
                ix = d > h ? (1 + (c - d) - d) : d == 1 ? c - d : c - d - 1;
              } else {
                if (d == h) {
                  ix = 1;
                } else {
                  ix = d > h ? (1 + (c - d) - d) : d == 1 ? c - d : c - d - 1;
                }
              }
              if (d == 0) {
                ix = d - c + 1;
              }
              if (viewMenuFlowItemList[i + ix] != null) {
                viewMenuFlowItemList[i]["index"] = ix;
              } else {
                let index = this.showMenuFlowItem(i, viewMenuFlowItemList, count);
                viewMenuFlowItemList[i]["index"] = index - i;
              }
            }
            if ((count == 1 || d == 1) && viewMenuFlowItemList[i + count] != null) {
              viewMenuFlowItemList[i]["downFlag"] = true;
            }
          }
        } else {
          viewMenuFlowItemList[i]["type"] = "";
          if (n == 0) {
            //双行
            viewMenuFlowItemList[i]["index"] = 1 - count > 0 ? count - 1 : 1 - count;
          }
        }
        if (viewMenuFlowItemList[i + 1] != null && !viewMenuFlowItemList[i + 1]['viewFlag']) {
          if (count != 1 && d == 1) {
            viewMenuFlowItemList[i]["type"] = "last";
          }
        }
      });
      this.viewMenuFlowItemList = [...viewMenuFlowItemList];
    }
  }

  viewInit() {
    this.viewMenuFlowItemList = this.menuFlowItemList;
  }

  ngAfterContentChecked(): void {
    if (this.menuFlowItemElementList != null && this.menuFlowItemElementList.length > 0) {
      this.afterViewChange();
    }
  }

  showMenuFlowItemOrder() {
    this.menuFlowItemOrderList = JSON.parse(JSON.stringify(this.menuFlowItemList));
    this.isMenuFlowOrderShow = true;
  }

  drop(event: CdkDragDrop<string[]>): void {
    moveItemInArray(this.menuFlowItemOrderList, event.previousIndex, event.currentIndex);
  }

  cancelMenuFlowItemOrderClick() {
    this.menuFlowItemOrderList = [];
    this.isMenuFlowOrderShow = false;
  }

  okMenuFlowItemOrderClick() {
    this.reloadMenuItemFlag = true;
    this.menuFlowItemList = JSON.parse(JSON.stringify(this.menuFlowItemOrderList));
    this.viewMenuFlowItemList = [...this.menuFlowItemList];
    this.menuFlowItemOrderList = [];
    this.isMenuFlowOrderShow = false;
  }

  updateMenuFlowItem(index) {
    this.menuFlowItemSort = index;
    this.menuFlowItemValidateForm.patchValue(this.menuFlowItemList[index]);
    this.isMenuFlowItemShow = true;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.menuFlowItemElementList != null && this.menuFlowItemElementList.length > 0) {
      this.afterViewChange();
    }
  }

  ngAfterContentInit(): void {
    if (this.menuFlowItemElementList != null && this.menuFlowItemElementList.length > 0) {
      this.afterViewChange();
    }
  }

  showEditorText(data) {
    return data.replace(/<[^>]+>/g, "")
  }
}
