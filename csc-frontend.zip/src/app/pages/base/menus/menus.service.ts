import {Injectable} from '@angular/core';
import {BaseService} from "../../../component/base/base.service";
import {Menus} from "./menus";
import {Help} from "../../../utils/Help";

@Injectable({
  providedIn: 'root'
})
export class MenusService extends BaseService<Menus> {
  url = {
    listByPage: '/dictionarytype/listQueryByPage',
    insert: '/hospitalmenus/save',
    update: '/hospitalmenus/update',
    delete: '/hospitalmenus/delete',
    deleteAll: '/dictionarytype/deleteAll',
    m_insert: '/menus/save',
    m_update: '/menus/update',
    m_delete: '/menus/delete',
    updateField: '/menus/updateField',
    changeSort: '/menus/updateListField',
    menuFlowList: '/menuflow/listQueryByPage',
    menuFlowItemList: '/menuflowitem/listQueryByPage',
    saveMenuFlow: '/menuflow/save',
    updateMenuFlow: '/menuflow/update',
    deleteMenuFlow: '/menuflow/delete',
    saveMenuFlowList: '/menuflowitem/saveList'
  };

  constructor(
    help: Help
  ) {
    super(help);
  }

  // 拖拽组件
  dragUpdate(params) {
    return this.help.post(this.url.updateField, params);
  }

  // 互换sort
  changeSort(params) {
    return this.help.post(this.url.changeSort, params);
  }

  // 获取流程菜单详情
  getMenusFlowByMenuId(params) {
    return this.help.post(this.url.menuFlowList, params)
  }

  getMenusFlowItemByMenuId(params) {
    return this.help.post(this.url.menuFlowItemList, params)
  }

  //保存流程菜单
  saveMenuFlow(menuFlow) {
    if (menuFlow["id"] != null) {
      return this.help.post(this.url.updateMenuFlow, menuFlow)
    } else {
      return this.help.post(this.url.saveMenuFlow, menuFlow)
    }
  }

  //保存流程菜单详情
  saveMenuFlowItemList(params) {
    return this.help.post(this.url.saveMenuFlowList, params)
  }

  //删除流程菜单
  deleteMenuFlow(params) {
    return this.help.post(this.url.deleteMenuFlow, params)
  }
}
