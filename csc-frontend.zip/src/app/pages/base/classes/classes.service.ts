import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Classes} from "./classes";
import {Help} from "../../../utils/Help";

@Injectable({
  providedIn: 'root'
})
export class ClassesService extends BaseService<Classes> {
  protected url = {
    listByPage: '/classes/listQueryByPage',
    insert: '/classes/save',
    update: '/classes/update',
    delete: '/classes/delete',
    deleteAll: '/classes/deleteAll',
    listClassesGroupStartYear: '/classes/listClassesGroupStartYear',
  };

  constructor(help: Help) {
    super(help);
  }

  getClassesTypeList() {
    return this.help.post("/dictionarydata/listQueryByTypeCode/ClassesType", {});
  }
}
