import {Component, OnInit} from "@angular/core";
import {Classes} from "../classes";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {ClassesService} from "../classes.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'classes-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Classes> implements OnInit {

  constructor(public location: Location, public service: ClassesService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Classes());
        }
      })
    ).subscribe(d => {
      let year: any = d.year;
      if (d.year != null) {
        year = new Date(d.year + '');
      }
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        majorId: [d.majorId, [Validators.required, Validators.maxLength(40)]],
        year: [year, [Validators.required]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        created: [d.created],
        hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
        typeName: [d.typeName],
        majorName: [d.majorName],
      });
      this.isLoading = false;
    });
  }

  submitForm() {
    this.isLoading = true;
    this.validateForm.get("year").setValue(this.validateForm.value.year.getFullYear());
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            this.location.back();
          }
        });
      }
    });
  }
}
