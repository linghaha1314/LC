import {Component, OnInit, ViewEncapsulation} from "@angular/core";
import {Classes} from "../classes";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {ClassesService} from "../classes.service";
import {Router} from "@angular/router";
import {ClassesStudentService} from "../classes-student.service";

@Component({
  selector: 'classes-list',
  templateUrl: './list.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [``]
})
export class ListComponent extends BaseListComponent<Classes> implements OnInit {

  tableStatus = 0;
  typeList = [];

  constructor(public modal: NzModalService, public service: ClassesService, public classesStudentService: ClassesStudentService, public message: NzMessageService, public router: Router) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;

    this.initTypeList();
  }

  initTypeList() {
    this.service.getClassesTypeList().subscribe((res: any) => {
      if (res.total > 0) {
        this.queryParams.typeId = res["rows"][0]["id"];
        this.typeList = res["rows"];
      }
      this.getData();
    });
  }

  changeTable(i, data) {
    this.queryParams.typeId = data["id"];
    this.reloadData();
  }
}
