import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Classes} from "./classes";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class ClassesStudentService extends BaseService<Classes> {
  protected url = {
    listByPage: '/students/listQueryByPage',
    insert: '/studentclasses/save',
    update: '/studentclasses/update',
    delete: '/studentclasses/deleteStudent',
    deleteAll: '/studentclasses/deleteStudentAll',
    saveStudentClasses: '/studentclasses/saveStudentClasses'
  };

  constructor(help: Help) {
    super(help);
  }

  deleteStudent(data) {
    return this.help.post(this.url.delete, data);
  }

  deleteStudentAll(data) {
    return this.help.post(this.url.deleteAll, data);
  }

  getStudentList(data) {
    return this.help.post(this.url.listByPage, data);
  }

  saveStudentClasses(data) {
    return this.help.post(this.url.saveStudentClasses, data);
  }

  verfiyStudent(list: string) {
    return this.help.post('/students/listQueryByPage', {list});
  }
}
