import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {NZ_I18N, zh_CN} from 'ng-zorro-antd/i18n';
import {NzAvatarModule} from 'ng-zorro-antd/avatar';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzCardModule} from 'ng-zorro-antd/card';
import {NzCheckboxModule} from 'ng-zorro-antd/checkbox';
import {NzDatePickerModule} from 'ng-zorro-antd/date-picker';
import {NzDescriptionsModule} from 'ng-zorro-antd/descriptions';
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalModule, NzModalService} from 'ng-zorro-antd/modal';
import {NzPageHeaderModule} from 'ng-zorro-antd/page-header';
import {NzPopconfirmModule} from 'ng-zorro-antd/popconfirm';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzResultModule} from 'ng-zorro-antd/result';
import {NzSkeletonModule} from 'ng-zorro-antd/skeleton';
import {NzSpinModule} from 'ng-zorro-antd/spin';
import {NzTableModule} from 'ng-zorro-antd/table';
import {NzTabsModule} from 'ng-zorro-antd/tabs';
import {NzToolTipModule} from 'ng-zorro-antd/tooltip';
import {NzTransferModule} from 'ng-zorro-antd/transfer';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {LoadStatusModule} from "../../../component/load-status/load-status.module";
import {ValidateMsgModule} from "../../../component/validate-msg/validate-msg.module";

import {ClassesRoutingModule} from "./classes-routing.module";
import {ClassesService} from "./classes.service";
import {ClassesStudentService} from "./classes-student.service";

import {ListComponent} from "./list/list.component";
import {EditComponent} from "./edit/edit.component";
import {ViewComponent} from "./view/view.component";
import {ListStudentComponent} from "./list-student/list-student.component";
import {FormComboModule} from "../../../component/form/combobox/form-combo.module";
import {SimpleDateModule} from "../../../pipe/SimpleDate.module";
import {NzTypographyModule} from "ng-zorro-antd/typography";

@NgModule({
  declarations: [ListComponent, EditComponent, ViewComponent, ListStudentComponent],
    imports: [
        CommonModule,
        ClassesRoutingModule,
        NzInputModule,
        FormsModule,
        NzTableModule,
        NzPopconfirmModule,
        NzButtonModule,
        NzToolTipModule,
        NzIconModule,
        NzGridModule,
        NzDescriptionsModule,
        NzSpaceModule,
        NzBadgeModule,
        NzResultModule,
        NzSpinModule,
        LoadStatusModule,
        ReactiveFormsModule,
        NzRadioModule,
        NzFormModule,
        NzPageHeaderModule,
        ValidateMsgModule,
        FormComboModule,
        NzDatePickerModule,
        NzCardModule,
        NzSkeletonModule,
        NzAvatarModule,
        NzModalModule,
        NzTransferModule,
        NzCheckboxModule,
        NzTabsModule,
        SimpleDateModule,
        NzTypographyModule
    ],
  providers: [ClassesService, ClassesStudentService, NzModalService, NzMessageService, {
    provide: NZ_I18N,
    useValue: zh_CN
  }]
})
export class ClassesModule {
}
