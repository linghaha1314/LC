export class Classes {
  id: string;
  name: string;
  staffId: string;
  majorId: string;
  year: number;
  address: string;
  typeId: string;
  typeName: string;
  status: number;
  created: any;
  hospitalId: string;
  staffName: string;
  staffAvator: string;
  majorName: string;
}
