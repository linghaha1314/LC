import {Component, OnInit, ViewEncapsulation} from "@angular/core";
import {Classes} from "../classes";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {TransferItem} from 'ng-zorro-antd/transfer';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {ActivatedRoute, ParamMap, Router} from "@angular/router";
import {ClassesStudentService} from "../classes-student.service";

@Component({
  selector: 'classes-list',
  templateUrl: './list-student.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [``]
})
export class ListStudentComponent extends BaseListComponent<Classes> implements OnInit {

  label = 'staffName';
  classesId = null;
  isStudentVisible = false;
  serialNoVisible = false;
  verifyLoading = false;
  verfiyMsg = "";
  studentList = [];
  defaultStudent = [];
  saveStudent = [];
  deleteStudent = [];
  serialNoList = "";

  constructor(public modal: NzModalService, private route: ActivatedRoute, public service: ClassesStudentService, public message: NzMessageService, public router: Router) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.route.paramMap.subscribe((params: ParamMap) => {
      if (params.get("id")) {
        this.queryParams["classId"] = params.get("id");
        this.classesId = params.get("id");
        this.getData();
      }
    });
  }

  addStudentClasses() {
    this.isStudentVisible = true;
    this.studentList = [];
    this.service.getStudentList({}).subscribe((res: any) => {
      if (res.total > 0) {
        this.service.getStudentList({classId: this.classesId}).subscribe((r: any) => {
          let sIds = [];
          if (r.total > 0) {
            sIds = r.rows.map(s => s.id);
            this.defaultStudent = sIds;
          }
          res.rows.forEach(f => {
            if (sIds.indexOf(f.id) > -1) {
              f.direction = 'right';
            }
            f.checked = false;
            f.key = f.id;
            f["hide"] = false;
            f.title = "人员名称：" + f.staffName + " 类型：" + f.typeName + " 专业：" + f.majorName + " 科室：" + f.sectionName;
          });
          this.studentList = res.rows;
        });
      }
    });
  }

  addBySerialNo() {

  }

  verifyStudent() {
    if (this.serialNoList.trim().length === 0) {
      return;
    }
    this.verifyLoading = true;
    this.service.verfiyStudent(this.serialNoList).subscribe(res => {
      this.verifyLoading = false;
      const list = this.serialNoList.trim().split("\n");
      if (list.length === res.rows.length) {
        this.verfiyMsg = '验证成功';
        const rows = [];
        res.rows.forEach(row => {
          rows.push(row['id']);
        });
        this.saveStudent = rows;
      } else {
        const cache = {};
        res.rows.forEach(r => {
          cache[r.studentNumber] = r;
        });
        list.some(r => {
          if (cache[r] == null) {
            this.verfiyMsg = `${r}不存在`;
            return true;
          }
        });
      }
    });
  }

  saveStudentClasses() {
    this.service.saveStudentClasses({
      classesId: this.classesId,
      saveStudents: this.saveStudent.join(","),
      deleteStudent: this.deleteStudent.join(",")
    }).subscribe((res: any) => {
      if (res.success) {
        this.isStudentVisible = false;
        this.serialNoVisible = false;
        this.message.success("保存成功！");
        this.reloadData();
      }
    });
  }

  changeStudent(ret) {
    console.log('nzChange', ret);
    const listKeys = ret.list.map(l => l.key);
    const hasOwnKey = (e: TransferItem) => e.hasOwnProperty('key');
    this.studentList = this.studentList.map(e => {
      if (listKeys.includes(e["key"]) && hasOwnKey(e)) {
        if (ret.to === 'left') {
          listKeys.forEach(s => {
            if (this.defaultStudent.indexOf(s) > -1) {
              if (this.deleteStudent.indexOf(s) == -1) {
                this.deleteStudent.push(s);
              }
            } else {
              if (this.saveStudent.indexOf(s) > -1) {
                this.saveStudent.splice(this.saveStudent.indexOf(s), 1);
              }
            }
          });
        } else if (ret.to === 'right') {
          listKeys.forEach(s => {
            if (this.defaultStudent.indexOf(s) == -1) {
              if (this.saveStudent.indexOf(s) == -1) {
                this.saveStudent.push(s);
              }
            } else {
              if (this.deleteStudent.indexOf(s) > -1) {
                this.deleteStudent.splice(this.deleteStudent.indexOf(s), 1);
              }
            }
          });
        }
      }
      return e;
    });
  }

  deleteData(data) {
    this.loading = true;
    this.service.deleteStudent({studentId: data.id, classesId: this.classesId}).subscribe(res => {
      this.loading = false;
      if (res.success) {
        this.message.success('删除成功!');
        this.searchData();
      }
    }, error => {
      this.loading = false;
    });
  }

  showDeleteConfirm() {
    const deleteData = [], names = [];
    this.list.forEach((data: any) => {
      if (data._checked) {
        deleteData.push({studentId: data.id, classesId: this.classesId});
        names.push(data[this.label]);
      }
    });
    if (deleteData.length == 0) {
      this.message.error('请至少选择一条数据!');
      return;
    }
    this.modal.confirm({
      nzTitle: '确认删除吗?',
      nzContent: `将删除<b>[${names.join(',')}]</b>数据!`,
      nzOkText: '确认',
      nzOkType: 'danger',
      nzOnOk: () => {
        this.service.deleteStudentAll(deleteData).subscribe(res => {
          if (res.success) {
            this.message.success('删除成功!');
            this.searchData();
          }
        });
      },
      nzCancelText: '取消'
    });
  }
}
