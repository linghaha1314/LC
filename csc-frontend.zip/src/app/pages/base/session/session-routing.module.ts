import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListComponent} from "./list/list.component";
import {ViewComponent} from "./view/view.component";
import {EditComponent} from "./edit/edit.component";


const routes: Routes = [
  {path: '', component: ListComponent, data: {title: '节次表列表'}},
  {path: 'view/:id', component: ViewComponent, data: {title: '节次表详情'}},
  {path: 'edit', component: EditComponent, data: {title: '添加节次表'}},
  {path: 'edit/:id', component: EditComponent, data: {title: '编辑节次表'}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SessionRoutingModule {
}
