import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {Session} from "./session";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class SessionService extends BaseService<Session> {
  protected url = {
    listByPage: '/session/listQueryByPage',
    insert: '/session/save',
    update: '/session/update',
    delete: '/session/delete',
    deleteAll: '/session/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
