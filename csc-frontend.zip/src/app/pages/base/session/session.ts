export class Session {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  status: number;
  created: any;
  hospitalId: string;
}
