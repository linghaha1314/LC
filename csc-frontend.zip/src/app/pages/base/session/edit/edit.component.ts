import {Component, OnInit} from "@angular/core";
import {Session} from "../session";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {SessionService} from "../session.service";
import {FormBuilder, Validators} from '@angular/forms';
import {formatDate, Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'session-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<Session> implements OnInit {

  constructor(public location: Location, public service: SessionService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new Session());
        }
      })
    ).subscribe(d => {
      const newDate = new Date();
      let startTime = null;
      let endTime = null;
      if (d.startTime != null) {
        startTime = new Date(newDate.getFullYear() + '-' + newDate.getMonth() + '-' + newDate.getDay() + ' ' + d.startTime);
      }
      if (d.endTime != null) {
        endTime = new Date(newDate.getFullYear() + '-' + newDate.getMonth() + '-' + newDate.getDay() + ' ' + d.endTime);
      }
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        startTime: [startTime, [Validators.required]],
        endTime: [endTime, [Validators.required]],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        created: [d.created],
        hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
      });
      this.isLoading = false;
    });
  }

  changeDate(data) {
    this.validateForm.get(data).setValue(Date());
  }

  submitForm() {
    this.isLoading = true;
    this.validateForm.value.startTime = formatDate(this.validateForm.value.startTime, 'HH:mm', 'zh');
    this.validateForm.value.endTime = formatDate(this.validateForm.value.endTime, 'HH:mm', 'zh');
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            this.location.back();
          }
        });
      }
    });
  }
}
