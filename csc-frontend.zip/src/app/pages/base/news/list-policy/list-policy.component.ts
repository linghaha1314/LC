import {Component, OnInit} from "@angular/core";
import {News} from "../news";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalRef, NzModalService} from 'ng-zorro-antd/modal';
import {BaseListComponent} from "../../../../component/base/base-list.component";
import {NewsPolicyService} from "../news-policy.service";
import {Help} from "../../../../utils/Help";
import {ActivatedRoute} from "@angular/router";
import {DatePipe} from "@angular/common";

@Component({
  selector: 'news-policy-list',
  templateUrl: './list-policy.component.html',
  providers: [DatePipe],
  styles: []
})
export class ListPolicyComponent extends BaseListComponent<News> implements OnInit {

  confirmModal?: NzModalRef;

  constructor(public modal: NzModalService, public service: NewsPolicyService, public message: NzMessageService, private help: Help, private route: ActivatedRoute, private datePipe: DatePipe) {
    super(modal, service, message);
  }

  ngOnInit() {
    this.pageIndex = this.service.pageNum;
    this.pageSize = this.service.pageSize;
    this.queryParams["code"] = "policyDocument";
    this.getData();
    this.refreshChecked();
  }

  showConfirm(data) {
    if (data.status !== 0) {
      return this.createMessage("error", "该资讯未启用，不能发布。");
    }
    const name = data.name;
    this.confirmModal = this.modal.confirm({
      nzTitle: '提示',
      nzContent: '确认现在发布资讯《' + name + '》吗？',
      nzOnOk: () => {
        data.releaseDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm:ss');
        this.service.update(data).subscribe(res => {
          if (res.success) {
            this.createMessage("success", res.val);
            this.reloadData();
          } else {
            this.createMessage("error", res.val);
          }
        });
      }
    });
  }

  createMessage(type: string, message: string): void {
    this.message.create(type, message);
  }

}
