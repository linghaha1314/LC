import {Component, OnInit} from '@angular/core';
import {News} from "../news";
import {NewsPolicyService} from "../news-policy.service";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";

@Component({
  selector: 'news-policy-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewPoliceComponent implements OnInit {

  empty = false;

  data: News = new News();

  constructor(private service: NewsPolicyService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new News());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
