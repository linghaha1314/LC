import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ListNoticeComponent} from "./list-notice/list-notice.component";
import {ListPolicyComponent} from "./list-policy/list-policy.component";
import {ViewNoticeComponent} from "./view-notice/view.component";
import {ViewPoliceComponent} from "./view-policy/view.component";
import {EditNoticeComponent} from "./edit-notice/edit.component";
import {EditPolicyComponent} from "./edit-policy/edit.component";


const routes: Routes = [
  {path: 'notice', component: ListNoticeComponent, data: {title: '通知公告', code: "notice"}},
  {path: 'policy', component: ListPolicyComponent, data: {title: '政策文件', code: "policyDocument"}},
  {path: 'view/notice/:id', component: ViewNoticeComponent, data: {title: '资讯详情'}},
  {path: 'view/policyDocument/:id', component: ViewPoliceComponent, data: {title: '资讯详情'}},
  {path: 'edit/notice', component: EditNoticeComponent, data: {title: '添加公告', code: "notice"}},
  {path: 'edit/policyDocument', component: EditPolicyComponent, data: {title: '添加政策文件', code: "policyDocument"}},
  {path: 'edit/notice/:id', component: EditNoticeComponent, data: {title: '编辑公告', code: "notice"}},
  {path: 'edit/policyDocument/:id', component: EditPolicyComponent, data: {title: '编辑政策文件', code: "policyDocument"}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NewsRoutingModule {
}
