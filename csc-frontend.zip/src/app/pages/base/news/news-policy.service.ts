import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {News} from "./news";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class NewsPolicyService extends BaseService<News> {
  protected url = {
    listByPage: '/news/listQueryByPage',
    insert: '/news/save',
    update: '/news/update',
    delete: '/news/delete',
    deleteAll: '/news/deleteAll',
    getTypeList: '/dictionarydata/listQueryByTypeCode/newsType'
  };

  constructor(help: Help) {
    super(help);
  }

  update(params) {
    return this.help.post(this.url.update, params);
  }

  getTypeList(params) {
    return this.help.post(this.url.getTypeList, params);
  }

}
