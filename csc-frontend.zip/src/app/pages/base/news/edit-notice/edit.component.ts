import {Component, OnInit} from "@angular/core";
import {News} from "../news";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";
import {NewsNoticeService} from "../news-notice.service";

@Component({
  selector: 'news-notice-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditNoticeComponent extends BaseEditComponent<News> implements OnInit {

  typeList = [];

  constructor(public location: Location, public service: NewsNoticeService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.data.subscribe(data => {
      if (data.code != null && data.code != "") {
        this.getTypeList({code: data.code});
      }
    });
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new News());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        name: [d.name, [Validators.required, Validators.maxLength(100)]],
        typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
        status: [d.status || 0, [Validators.required, Validators.maxLength(11)]],
        remark: [d.remark, [Validators.maxLength(200)]],
        hospitalId: [d.hospitalId, [Validators.maxLength(40)]],
        userId: [d.userId, [Validators.maxLength(40)]],
        created: [d.created],
        content: [d.content, [Validators.required]],
        attachs: [d.attachs, []],
        typeName: [d.typeName],
        userName: [d.userName],
      });
      this.isLoading = false;
    });
  }

  getTypeList(params) {
    this.service.getTypeList(params).subscribe(res => {
      if (res.total > 0) {
        this.typeList = res.rows;
      }
    });
  }

}
