import {Component, OnInit} from '@angular/core';
import {News} from "../news";
import {ActivatedRoute, ParamMap} from "@angular/router";
import {switchMap} from "rxjs/operators";
import {of} from "rxjs";
import {NewsNoticeService} from "../news-notice.service";

@Component({
  selector: 'news-notice-view',
  templateUrl: './view.component.html',
  styles: []
})
export class ViewNoticeComponent implements OnInit {

  empty = false;

  data: News = new News();

  constructor(private service: NewsNoticeService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new News());
        }
      })
    ).subscribe(d => {
      if (d) {
        this.data = d;
      } else {
        this.empty = true;
      }
    });
  }

}
