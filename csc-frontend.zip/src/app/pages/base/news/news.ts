export class News {
  id: string;
  name: string;
  releaseDate: any;
  typeId: string;
  status: number;
  remark: string;
  hospitalId: string;
  userId: string;
  created: any;
  content: string;
  attachs: string;
  typeName: string;
  userName: string;
}
