import {Injectable} from "@angular/core";
import {BaseService} from "../../../component/base/base.service";
import {MessageGroup} from "./message-group";
import {Help} from "../../../utils/Help";


@Injectable({
  providedIn: 'root'
})
export class MessageGroupService extends BaseService<MessageGroup> {
  protected url = {
    listByPage: '/messagegroup/listQueryByPage',
    insert: '/messagegroup/save',
    update: '/messagegroup/update',
    delete: '/messagegroup/delete',
    deleteAll: '/messagegroup/deleteAll'
  };

  constructor(help: Help) {
    super(help);
  }

}
