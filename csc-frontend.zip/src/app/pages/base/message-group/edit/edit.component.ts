import {Component, OnInit} from "@angular/core";
import {MessageGroup} from "../message-group";
import {of} from 'rxjs';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {switchMap} from 'rxjs/operators';
import {MessageGroupService} from "../message-group.service";
import {FormBuilder, Validators} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseEditComponent} from "../../../../component/base/base-edit.component";

@Component({
  selector: 'message-group-edit',
  templateUrl: './edit.component.html',
  styles: []
})
export class EditComponent extends BaseEditComponent<MessageGroup> implements OnInit {

  constructor(public location: Location, public service: MessageGroupService, public message: NzMessageService, private fb: FormBuilder, private route: ActivatedRoute) {
    super(location, service, message);
  }

  ngOnInit() {
    this.route.paramMap.pipe(
      switchMap((params: ParamMap) => {
        if (params.get('id')) {
          return this.service.getDataById(params.get('id'));
        } else {
          return of(new MessageGroup());
        }
      })
    ).subscribe(d => {
      this.validateForm = this.fb.group({
        id: [d.id, [Validators.maxLength(40)]],
        messageId: [d.messageId, [Validators.required, Validators.maxLength(40)]],
        typeId: [d.typeId, [Validators.required, Validators.maxLength(40)]],
        roleId: [d.roleId, [Validators.required, Validators.maxLength(40)]],
        groupId: [d.groupId, [Validators.required, Validators.maxLength(40)]],
        created: [d.created],
        status: [d.status, [Validators.required, Validators.maxLength(11)]],
        messageName: [d.messageName],
        typeName: [d.typeName],
        roleName: [d.roleName],
        groupName: [d.groupName],
      });
      this.isLoading = false;
    });
  }

}
