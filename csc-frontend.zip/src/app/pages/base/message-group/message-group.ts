export class MessageGroup {
  id: string;
  messageId: string;
  typeId: string;
  roleId: string;
  groupId: string;
  created: any;
  status: number;
  messageName: string;
  typeName: string;
  roleName: string;
  groupName: string;
}
