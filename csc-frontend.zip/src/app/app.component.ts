import {Component, OnInit, ViewChild} from '@angular/core';
import {
  ActivatedRoute,
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router
} from '@angular/router';
import {Title} from "@angular/platform-browser";
import {map} from "rxjs/operators";
import {NzMessageService} from 'ng-zorro-antd/message';
import {of} from "rxjs";
import {Help} from "./utils/Help";
import {InitUtils} from "./utils/InitUtils";
import {Location} from "@angular/common";
import {DataTreeComponent} from "./component/data-tree/data-tree.component";
import {StorageService} from "./storage.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  routeList = [];

  menus = [];

  theme: string;

  menuLoad = false;

  nowIcon = 'home';

  @ViewChild('menu', {static: false})
  menu!: DataTreeComponent;

  themeVisible = false;

  colors: Array<{
    color: string;
    background: string;
    shadow: string;
  }> = [
    {color: '#fff', background: '#673ab7', shadow: 'rgba(103,58,183, .2)'},
    {color: '#fff', background: '#3f51b5', shadow: 'rgba(63,81,181, .2)'},
    {color: '#fff', background: '#e91e63', shadow: 'rgba(233,30,99, .2)'},
    {color: '#fff', background: '#9c27b0', shadow: 'rgba(156,39,176, .2)'}
  ];

  color: string = '#006EFF';
  historyMenu: any[] = [];

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private storage: StorageService, private titleService: Title, private message: NzMessageService, private help: Help, private initUtils: InitUtils, private location: Location) {
    this.theme = this.initUtils.initTheme();
    let configColor = localStorage.getItem('base-color');
    let configColorList = localStorage.getItem('base-color-list');
    if (!this.help.isEmpty(configColor)) {
      this.changeColor(JSON.parse(configColor));
    }
    if (!this.help.isEmpty(configColorList)) {
      this.colors = JSON.parse(configColorList);
    }
  }

  // 设置主题
  initTheme(label?: string) {
    this.theme = label;
    this.initUtils.initTheme(label);
  }

  // 页面初始化成功
  ngOnInit() {
    let id = null, flag = true;
    // 路由监听
    this.router.events.subscribe(event => {
      // 路由开始时候执行的时间
      if (event instanceof NavigationStart) {
        id = this.message.loading('加载中..', {nzDuration: 0}).messageId;
        if (event.navigationTrigger == 'imperative') {
          flag = true;
        } else if (event.navigationTrigger == 'popstate') {
          flag = false;
        }
      }
      if (event instanceof NavigationEnd) {
        of(event).pipe(map(() => this.activatedRoute),
          map(route => {
            while (route.firstChild) {
              route = route.firstChild;
            }
            return route;
          }),
          map(route => route.data), map((route: any) => route.value)).subscribe((e) => {
          if (e.visible === false) {
            this.message.remove(id);
            return;
          }
          let title = localStorage.getItem('nowName') || e.title;
          if (title == 'undefined') {
            title = e.title;
          }
          if (flag) {
            this.routeList.push({title: title.trim(), url: event.url});
          } else {
            // 处理子路由刷新
            if (this.routeList.length === 1) {
              this.routeList = [{title: title.trim(), url: event.url}];
            } else {
              this.routeList = this.routeList.splice(0, this.routeList.length - 1);
            }
          }
          // 设置title
          this.routerInit(title);
          this.message.remove(id);
        });
      }
      if (event instanceof NavigationError) {
        this.message.remove(id);
      }
      if (event instanceof NavigationCancel) {
        this.message.remove(id);
      }
    });
    this.loadMenu();
  }

  //获取历史记录
  getHistory() {
    const historyMenuList = this.storage.get('historyMenuList') ? this.storage.get('historyMenuList') : [];
    const role = this.storage.get('role');
    historyMenuList.forEach((b, index) => {
      if (b.role.code === role.code) {
        this.historyMenu = historyMenuList[index].list;
      }
    });
  }

  // 设置名称
  routerInit(title: string) {
    if (title && title != 'undefined') {
      this.titleService.setTitle(title.trim());
    } else {
      this.message.error('该路由未配置[title]属性!');
    }
    localStorage.removeItem("nowName");
  }

  back(url: string, index: number) {
    if (this.routeList.length - 1 == index) {
      return;
    }
    this.routeList = this.routeList.splice(0, index);
    this.router.navigate([url]).then();
  }

  changePage(menu: any) {
    localStorage.setItem("nowName", menu.name);
    let path = menu.path;
    this.getHistory();
    if (path !== "#") {
      let flag = false;
      for (let i = 0; i < this.historyMenu.length; i++) {
        if (this.historyMenu[i].path === path) {
          const first = this.historyMenu[i];
          this.historyMenu.splice(i, 1);
          this.historyMenu.unshift(first);
          flag = true;
        }
      }
      if (!flag) {
        this.historyMenu.unshift(menu);
      }
      this.historyMenu.splice(20, this.historyMenu.length);
      const obj: any = {
        role: this.storage.get('role'),
        list: this.historyMenu
      };
      const historyMenuList = this.storage.get('historyMenuList') ? this.storage.get('historyMenuList') : [];
      const role = this.storage.get('role');
      let currentRoleFlag = false;
      historyMenuList.forEach((b, index) => {
        if (b.role.code === role.code) {
          historyMenuList[index] = obj;
          currentRoleFlag = true;
        }
      });
      if (!currentRoleFlag) {
        historyMenuList.unshift(obj);
      }
      this.storage.set('historyMenuList', historyMenuList);
    }
    //跳转制流程界面
    if (menu['menusFlowFlag']) {
      let displayJson = localStorage.getItem("displayMenuFlow");
      if (displayJson == null) {
        path = "/menuflow/examine/" + menu.id;
      } else {
        if (JSON.parse(displayJson)[menu.id] == null || menu.path == '' || menu.path == '#') {
          path = "/menuflow/examine/" + menu.id;
        }
      }
    }
    if (path == "#") {
      if (menu.params != null) {
        let params = JSON.parse(menu.params);
        if (params["skipMenu"] != null) {
          this.skipMenuAll(params["skipMenu"]);
          return;
        }
      }
    }
    if (path == window.location.pathname) {
      return;
    }
    this.help.setMenuAuth(menu.userName);
    this.routeList.length = 0;
    this.nowIcon = menu.icon;
    this.router.navigate([path]).then();
  }

  openPage(menu: any) {
    if (menu['menusFlowFlag']) {
      let path = "/menuflow/examineHelp/" + menu.id;
      if (menu['menusFlowItemFlag']) {
        path = "/menuflow/examine/" + menu.id;
      }
      if (path == window.location.pathname) {
        return;
      }
      this.help.setMenuAuth(menu.userName);
      this.routeList.length = 0;
      this.nowIcon = menu.icon;
      this.router.navigate([path]).then();
    }
  }

  loadMenu() {
    this.help.get('/hospitalmenus/getAuthMenus/0').subscribe((d: any) => {
      if (d.success) {
        this.menus = d.data;
        this.changeMenu({path: '/'});
      }
    });
  }

  changeMenu(m: any) {
    if (m.name) {
      this.titleService.setTitle(m.name);
    } else {
      this.titleService.setTitle('首页');
    }
    if (m.path != "#" && m.path.length > 0) {
      this.router.navigate([m.path]).then();
    }
    this.routeList.length = 0;
    // 切换到首页了
    if (m.id == null) {
      this.menu.showLogo();
      return;
    }
    this.menu.reloadMenu(m.id);
  }

  colorRgb(hex: string) {
    let sColor = hex.toLowerCase();
    //十六进制颜色值的正则表达式
    let reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
    // 如果是16进制颜色
    if (sColor && reg.test(sColor)) {
      if (sColor.length === 4) {
        let sColorNew = "#";
        for (let i = 1; i < 4; i += 1) {
          sColorNew += sColor.slice(i, i + 1).concat(sColor.slice(i, i + 1));
        }
        sColor = sColorNew;
      }
      //处理六位的颜色值
      const sColorChange = [];
      for (let i = 1; i < 7; i += 2) {
        sColorChange.push(parseInt("0x" + sColor.slice(i, i + 2)));
      }
      return sColorChange;
    }
    return sColor;
  };

  changeColor(c: any) {
    localStorage.setItem('base-color', JSON.stringify(c));
    this.help.loadStyle('base-color', `
    * {
      --base-color: ${c.color};
      --base-background-color: ${c.background};
      --base-shadow-color: ${c.shadow};
    }`);
    this.themeVisible = false;
  }

  addColorList() {
    const [a, b, c] = this.colorRgb(this.color);
    this.colors.push({color: '#fff', background: this.color, shadow: `rgba(${a},${b},${c}, .2)`});
    localStorage.setItem('base-color-list', JSON.stringify(this.colors));
  }

  removeColor(i: number) {
    this.colors.splice(i, 1);
    localStorage.setItem('base-color-list', JSON.stringify(this.colors));
  }


  skipMenuAll(menuId) {
    this.help.post("/menus/getParentMenusByMenuId", {menuId: menuId}).subscribe((res: any) => {
      if (res.success) {
        this.menu.menus = res.data["menuList"];
      }
    });
  }

  changeRole(e) {
    this.storage.set('role', e);
    this.getHistory();
  }
}
