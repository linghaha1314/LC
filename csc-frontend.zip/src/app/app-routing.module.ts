import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: '/home'},
  {path: 'welcome', loadChildren: () => import('./pages/welcome/welcome.module').then(m => m.WelcomeModule)},
  {
    path: 'dictionarydata',
    loadChildren: () => import('./pages/base/dictionary-data/dictionary-data.module').then(m => m.DictionaryDataModule)
  },
  {
    path: 'dictionarytype',
    loadChildren: () => import('./pages/base/dictionary-type/dictionary-type.module').then(m => m.DictionaryTypeModule)
  },
  {path: 'roles', loadChildren: () => import('./pages/base/roles/roles.module').then(m => m.RolesModule)},
  {path: 'menus', loadChildren: () => import('./pages/base/menus/menus.module').then(m => m.MenusModule)},
  {path: 'logs', loadChildren: () => import('./pages/base/logs/logs.module').then(m => m.LogsModule)},
  {
    path: 'hospitals',
    loadChildren: () => import('./pages/base/hospitals/hospitals.module').then(m => m.HospitalsModule)
  },
  {path: 'message', loadChildren: () => import('./pages/base/message/message.module').then(m => m.MessageModule)},
  {path: 'staff', loadChildren: () => import('./pages/base/staff/staff.module').then(m => m.StaffModule)},
  {path: 'accounts', loadChildren: () => import('./pages/base/accounts/accounts.module').then(m => m.AccountsModule)},
  {path: 'home', loadChildren: () => import('./pages/base/home/home.module').then(m => m.HomeModule)},
  {path: 'group', loadChildren: () => import('./pages/base/group/group.module').then(m => m.GroupModule)},
  {path: 'todotask', loadChildren: () => import('./pages/base/todo-task/todo-task.module').then(m => m.TodoTaskModule)},
  {
    path: 'configparameter',
    loadChildren: () => import('./pages/base/config-parameter/config-parameter.module').then(m => m.ConfigParameterModule)
  },
  {
    path: 'messagegroup',
    loadChildren: () => import('./pages/base/message-group/message-group.module').then(m => m.MessageGroupModule)
  },
  {
    path: 'buildings',
    loadChildren: () => import('./pages/process/buildings/buildings.module').then(m => m.BuildingsModule)
  },
  {path: 'place', loadChildren: () => import('./pages/process/place/place.module').then(m => m.PlaceModule)},
  {
    path: 'oftenmenu',
    loadChildren: () => import('./pages/base/often-menu/often-menu.module').then(m => m.OftenMenuModule)
  },
  {
    path: 'precautions',
    loadChildren: () => import('./pages/process/precautions/precautions.module').then(m => m.PrecautionsModule)
  },
  {
    path: 'personnelunit',
    loadChildren: () => import('./pages/base/personnel-unit/personnel-unit.module').then(m => m.PersonnelUnitModule)
  },
  {path: 'sections', loadChildren: () => import('./pages/base/sections/sections.module').then(m => m.SectionsModule)},
  {path: 'holiday', loadChildren: () => import('./pages/base/holiday/holiday.module').then(m => m.HolidayModule)},
  {path: 'majors', loadChildren: () => import('./pages/base/majors/majors.module').then(m => m.MajorsModule)},
  {path: 'news', loadChildren: () => import('./pages/base/news/news.module').then(m => m.NewsModule)},
  {
    path: 'opentraining',
    loadChildren: () => import('./pages/process/open-training/open-training.module').then(m => m.OpenTrainingModule)
  },
  {
    path: 'opendate',
    loadChildren: () => import('./pages/process/open-date/open-date.module').then(m => m.OpenDateModule)
  },
  {
    path: 'openitem',
    loadChildren: () => import('./pages/process/open-item/open-item.module').then(m => m.OpenItemModule)
  },
  {
    path: 'sessiondate',
    loadChildren: () => import('./pages/process/session-date/session-date.module').then(m => m.SessionDateModule)
  },
  {
    path: 'trainingposition',
    loadChildren: () => import('./pages/process/training-position/training-position.module').then(m => m.TrainingPositionModule)
  },
  {
    path: 'trainingitem',
    loadChildren: () => import('./pages/process/training-item/training-item.module').then(m => m.TrainingItemModule)
  },
  {
    path: 'positionitem',
    loadChildren: () => import('./pages/process/position-item/position-item.module').then(m => m.PositionItemModule)
  },
  {path: 'session', loadChildren: () => import('./pages/base/session/session.module').then(m => m.SessionModule)},
  {
    path: 'placeaccess',
    loadChildren: () => import('./pages/process/place-access/place-access.module').then(m => m.PlaceAccessModule)
  },
  {
    path: 'opendoors',
    loadChildren: () => import('./pages/process/open-doors/open-doors.module').then(m => m.OpenDoorsModule)
  },
  {
    path: 'measuringunit',
    loadChildren: () => import('./pages/supplies/measuring-unit/measuring-unit.module').then(m => m.MeasuringUnitModule)
  },
  {path: 'survey', loadChildren: () => import('./pages/process/survey/survey.module').then(m => m.SurveyModule)},
  {
    path: 'itemcategory',
    loadChildren: () => import('./pages/supplies/item-category/item-category.module').then(m => m.ItemCategoryModule)
  },
  {
    path: 'surveyrecord',
    loadChildren: () => import('./pages/process/survey-record/survey-record.module').then(m => m.SurveyRecordModule)
  },
  {path: 'classes', loadChildren: () => import('./pages/base/classes/classes.module').then(m => m.ClassesModule)},
  {
    path: 'reservation',
    loadChildren: () => import('./pages/process/reservation/reservation.module').then(m => m.ReservationModule)
  },
  {
    path: 'reservationitem',
    loadChildren: () => import('./pages/process/reservation-item/reservation-item.module').then(m => m.ReservationItemModule)
  },
  {
    path: 'reservationmember',
    loadChildren: () => import('./pages/process/reservation-member/reservation-member.module').then(m => m.ReservationMemberModule)
  },
  {path: 'appmenus', loadChildren: () => import('./pages/base/app-menus/app-menus.module').then(m => m.AppMenusModule)},
  {path: 'factory', loadChildren: () => import('./pages/supplies/factory/factory.module').then(m => m.FactoryModule)},
  {path: 'brand', loadChildren: () => import('./pages/supplies/brand/brand.module').then(m => m.BrandModule)},
  {
    path: 'equipmentpurchase',
    loadChildren: () => import('./pages/supplies/equipment-purchase/equipment-purchase.module').then(m => m.EquipmentPurchaseModule)
  },
  {
    path: 'reservationcheck',
    loadChildren: () => import('./pages/process/reservation-check/reservation-check.module').then(m => m.ReservationCheckModule)
  },
  {path: 'students', loadChildren: () => import('./pages/base/students/students.module').then(m => m.StudentsModule)},
  {
    path: 'storehouse',
    loadChildren: () => import('./pages/supplies/storehouse/storehouse.module').then(m => m.StorehouseModule)
  },
  {
    path: 'storehouseqr',
    loadChildren: () => import('./pages/supplies/storehouse-qr/storehouse-qr.module').then(m => m.StorehouseQrModule)
  },
  {
    path: 'questionnaire',
    loadChildren: () => import('./pages/process/questionnaire/questionnaire.module').then(m => m.QuestionnaireModule)
  },
  {
    path: 'wordtemplate',
    loadChildren: () => import('./pages/base/word-template/word-template.module').then(m => m.WordTemplateModule)
  },
  {
    path: 'resources',
    loadChildren: () => import('./pages/gme/resources/resources.module').then(m => m.ResourcesModule)
  },
  {path: 'teachers', loadChildren: () => import('./pages/base/teachers/teachers.module').then(m => m.TeachersModule)},
  {
    path: 'equipmentwarehousing',
    loadChildren: () => import('./pages/supplies/equipment-warehousing/equipment-warehousing.module').then(m => m.EquipmentWarehousingModule)
  },
  {
    path: 'fundaccount',
    loadChildren: () => import('./pages/supplies/fund-account/fund-account.module').then(m => m.FundAccountModule)
  },
  {
    path: 'suppliespurchase',
    loadChildren: () => import('./pages/supplies/supplies-purchase/supplies-purchase.module').then(m => m.SuppliesPurchaseModule)
  },
  {
    path: 'checktemplate',
    loadChildren: () => import('./pages/process/check-template/check-template.module').then(m => m.CheckTemplateModule)
  },
  {
    path: 'checktemplateitems',
    loadChildren: () => import('./pages/process/check-template-items/check-template-items.module').then(m => m.CheckTemplateItemsModule)
  },
  {
    path: 'checkrecord',
    loadChildren: () => import('./pages/process/check-record/check-record.module').then(m => m.CheckRecordModule)
  },
  {
    path: 'checkrecorditem',
    loadChildren: () => import('./pages/process/check-record-item/check-record-item.module').then(m => m.CheckRecordItemModule)
  },
  {
    path: 'articlereceiving',
    loadChildren: () => import('./pages/supplies/article-receiving/article-receiving.module').then(m => m.ArticleReceivingModule)
  },
  {
    path: 'storehousearticle',
    loadChildren: () => import('./pages/supplies/storehouse-article/storehouse-article.module').then(m => m.StorehouseArticleModule)
  },
  {
    path: 'storehousearticlestatistics',
    loadChildren: () => import('./pages/supplies/storehouse-article-statistics/storehouse-article-statistics.module').then(m => m.StorehouseArticleStatisticsModule)
  },
  {
    path: 'supplieswarehousing',
    loadChildren: () => import('./pages/supplies/supplies-warehousing/supplies-warehousing.module').then(m => m.SuppliesWarehousingModule)
  },
  {
    path: 'equipmentborrow',
    loadChildren: () => import('./pages/supplies/equipment-borrow/equipment-borrow.module').then(m => m.EquipmentBorrowModule)
  },
  {
    path: 'equipmentcanborrow',
    loadChildren: () => import('./pages/supplies/equipment-can-borrow/equipment-can-borrow.module').then(m => m.EquipmentCanBorrowModule)
  },
  {
    path: 'equipmentborrowdetail',
    loadChildren: () => import('./pages/supplies/equipment-borrow-detail/equipment-borrow-detail.module').then(m => m.EquipmentBorrowDetailModule)
  },
  {
    path: 'equipmentborrowstatistics',
    loadChildren: () => import('./pages/supplies/equipment-borrow-statistics/equipment-borrow-statistics.module').then(m => m.EquipmentBorrowStatisticsModule)
  },
  {
    path: 'import',
    loadChildren: () => import('./component/import-data/import-data.module').then(m => m.ImportDataModule)
  },
  {
    path: 'equipmentreturn',
    loadChildren: () => import('./pages/supplies/equipment-return/equipment-return.module').then(m => m.EquipmentReturnModule)
  },
  {path: 'flowview', loadChildren: () => import('./component/flowview/flow.module').then(m => m.FlowModule)},
  {
    path: 'workprocess',
    loadChildren: () => import('./pages/base/work-process/work-process.module').then(m => m.WorkProcessModule)
  },
  {path: 'course', loadChildren: () => import('./pages/gme/course/course.module').then(m => m.CourseModule)},
  {
    path: 'courseteacher',
    loadChildren: () => import('./pages/gme/course-teacher/course-teacher.module').then(m => m.CourseTeacherModule)
  },
  {
    path: 'resourcestudy',
    loadChildren: () => import('./pages/gme/resource-study/resource-study.module').then(m => m.ResourceStudyModule)
  },
  {
    path: 'dynamicexcel',
    loadChildren: () => import('./pages/base/dynamic-excel/dynamic-excel.module').then(m => m.DynamicExcelModule)
  },
  {
    path: 'curriculum',
    loadChildren: () => import('./pages/gme/curriculum/curriculum.module').then(m => m.CurriculumModule)
  },
  {
    path: 'curriculumdetail',
    loadChildren: () => import('./pages/gme/curriculum-detail/curriculum-detail.module').then(m => m.CurriculumDetailModule)
  },
  {
    path: 'curriculumsession',
    loadChildren: () => import('./pages/gme/curriculum-session/curriculum-session.module').then(m => m.CurriculumSessionModule)
  },
  {
    path: 'curriculumclasses',
    loadChildren: () => import('./pages/gme/curriculum-classes/curriculum-classes.module').then(m => m.CurriculumClassesModule)
  },
  {
    path: 'curriculumitem',
    loadChildren: () => import('./pages/gme/curriculum-item/curriculum-item.module').then(m => m.CurriculumItemModule)
  },
  {
    path: 'scorepaper',
    loadChildren: () => import('./pages/gme/score-paper/score-paper.module').then(m => m.ScorePaperModule)
  },
  {
    path: 'scorepapercomponent',
    loadChildren: () => import('./pages/gme/score-paper-component/score-paper-component.module').then(m => m.ScorePaperComponentModule)
  },
  {path: 'semester', loadChildren: () => import('./pages/base/semester/semester.module').then(m => m.SemesterModule)},
  {path: 'faculty', loadChildren: () => import('./pages/base/faculty/faculty.module').then(m => m.FacultyModule)},
  {path: 'testarea', loadChildren: () => import('./pages/exam/test-area/test-area.module').then(m => m.TestAreaModule)},
  {
    path: 'examinationroom',
    loadChildren: () => import('./pages/exam/examination-room/examination-room.module').then(m => m.ExaminationRoomModule)
  },
  {
    path: 'examinationdoor',
    loadChildren: () => import('./pages/exam/examination-door/examination-door.module').then(m => m.ExaminationDoorModule)
  },
  {
    path: 'department',
    loadChildren: () => import('./pages/base/department/department.module').then(m => m.DepartmentModule)
  },
  {
    path: 'scorerecord',
    loadChildren: () => import('./pages/gme/score-record/score-record.module').then(m => m.ScoreRecordModule)
  },
  {
    path: 'testdevice',
    loadChildren: () => import('./pages/exam/test-device/test-device.module').then(m => m.TestDeviceModule)
  },
  {
    path: 'examstaff',
    loadChildren: () => import('./pages/base/exam-staff/exam-staff.module').then(m => m.ExamStaffModule)
  },
  {
    path: 'testitems',
    loadChildren: () => import('./pages/exam/test-items/test-items.module').then(m => m.TestItemsModule)
  },
  {
    path: 'examknowledge',
    loadChildren: () => import('./pages/exam/exam-knowledge/exam-knowledge.module').then(m => m.ExamKnowledgeModule)
  },
  {
    path: 'examquestion',
    loadChildren: () => import('./pages/exam/exam-question/exam-question.module').then(m => m.ExamQuestionModule)
  },
  {path: 'copyfor', loadChildren: () => import('./pages/base/copy-for/copy-for.module').then(m => m.CopyForModule)},
  {
    path: 'prepareprocess',
    loadChildren: () => import('./pages/base/prepare-process/prepare-process.module').then(m => m.PrepareProcessModule)
  },
  {
    path: 'prepareplan',
    loadChildren: () => import('./pages/base/prepare-plan/prepare-plan.module').then(m => m.PreparePlanModule)
  },
  {
    path: 'preparecomplete',
    loadChildren: () => import('./pages/base/prepare-complete/prepare-complete.module').then(m => m.PrepareCompleteModule)
  },
  {
    path: 'examvolume',
    loadChildren: () => import('./pages/exam/exam-volume/exam-volume.module').then(m => m.ExamVolumeModule)
  },
  {
    path: 'examvolumeanswer',
    loadChildren: () => import('./pages/exam/exam-volume-answer/exam-volume-answer.module').then(m => m.ExamVolumeAnswerModule)
  },
  {path: 'testplan', loadChildren: () => import('./pages/exam/test-plan/test-plan.module').then(m => m.TestPlanModule)},
  {
    path: 'testreminder',
    loadChildren: () => import('./pages/exam/test-reminder/test-reminder.module').then(m => m.TestReminderModule)
  },
  {path: 'plandate', loadChildren: () => import('./pages/exam/plan-date/plan-date.module').then(m => m.PlanDateModule)},
  {
    path: 'planpublicconfig',
    loadChildren: () => import('./pages/exam/plan-public-config/plan-public-config.module').then(m => m.PlanPublicConfigModule)
  },
  {
    path: 'planpublicroom',
    loadChildren: () => import('./pages/exam/plan-public-room/plan-public-room.module').then(m => m.PlanPublicRoomModule)
  },
  {
    path: 'publicroomdevice',
    loadChildren: () => import('./pages/exam/public-room-device/public-room-device.module').then(m => m.PublicRoomDeviceModule)
  },
  {
    path: 'testconfig',
    loadChildren: () => import('./pages/exam/test-config/test-config.module').then(m => m.TestConfigModule)
  },
  {path: 'planarea', loadChildren: () => import('./pages/exam/plan-area/plan-area.module').then(m => m.PlanAreaModule)},
  {path: 'planitem', loadChildren: () => import('./pages/exam/plan-item/plan-item.module').then(m => m.PlanItemModule)},
  {
    path: 'planitemstation',
    loadChildren: () => import('./pages/exam/plan-item-station/plan-item-station.module').then(m => m.PlanItemStationModule)
  },
  {
    path: 'stationdevice',
    loadChildren: () => import('./pages/exam/station-device/station-device.module').then(m => m.StationDeviceModule)
  },
  {
    path: 'planitemreminder',
    loadChildren: () => import('./pages/exam/plan-item-reminder/plan-item-reminder.module').then(m => m.PlanItemReminderModule)
  },
  {
    path: 'planitempaper',
    loadChildren: () => import('./pages/exam/plan-item-paper/plan-item-paper.module').then(m => m.PlanItemPaperModule)
  },
  {
    path: 'planitemexam',
    loadChildren: () => import('./pages/exam/plan-item-exam/plan-item-exam.module').then(m => m.PlanItemExamModule)
  },
  {
    path: 'stationexaminer',
    loadChildren: () => import('./pages/exam/station-examiner/station-examiner.module').then(m => m.StationExaminerModule)
  },
  {
    path: 'stationsp',
    loadChildren: () => import('./pages/exam/station-sp/station-sp.module').then(m => m.StationSpModule)
  },
  {
    path: 'teststudent',
    loadChildren: () => import('./pages/exam/test-student/test-student.module').then(m => m.TestStudentModule)
  },
  {
    path: 'testguide',
    loadChildren: () => import('./pages/exam/test-guide/test-guide.module').then(m => m.TestGuideModule)
  },
  {
    path: 'studentclasses',
    loadChildren: () => import('./pages/base/student-classes/student-classes.module').then(m => m.StudentClassesModule)
  },
  {path: 'examplan', loadChildren: () => import('./pages/exam/exam-plan/exam-plan.module').then(m => m.ExamPlanModule)},
  {
    path: 'examplanmy',
    loadChildren: () => import('./pages/exam/exam-plan-my/exam-plan-my.module').then(m => m.ExamPlanMyModule)
  },
  {
    path: 'examanswer',
    loadChildren: () => import('./pages/exam/exam-answer/exam-answer.module').then(m => m.ExamAnswerModule)
  },
  {
    path: 'exampaper',
    loadChildren: () => import('./pages/exam/exam-paper/exam-paper.module').then(m => m.ExamPaperModule)
  },
  {
    path: 'suppliesbasemenu',
    loadChildren: () => import('./pages/supplies/supplies-base-menu/supplies-base-menu.module').then(m => m.SuppliesBaseMenuModule)
  },
  {
    path: 'testplancontrol',
    loadChildren: () => import('./pages/exam/test-plan-control/test-plan-control.module').then(m => m.TestPlanControlModule)
  },
  {
    path: 'teachingplatform',
    loadChildren: () => import('./pages/process/teaching-platform/teaching-platform.module').then(m => m.TeachingPlatformModule)
  },
  {
    path: 'testresult',
    loadChildren: () => import('./pages/exam/test-result/test-result.module').then(m => m.TestResultModule)
  },
  {
    path: 'testresultcheck',
    loadChildren: () => import('./pages/exam/test-result-check/test-result-check.module').then(m => m.TestResultCheckModule)
  },
  {
    path: 'testresultstation',
    loadChildren: () => import('./pages/exam/test-result-station/test-result-station.module').then(m => m.TestResultStationModule)
  },
  {
    path: 'testresultscore',
    loadChildren: () => import('./pages/exam/test-result-score/test-result-score.module').then(m => m.TestResultScoreModule)
  },
  {
    path: 'testresultscoredetail',
    loadChildren: () => import('./pages/exam/test-result-score-detail/test-result-score-detail.module').then(m => m.TestResultScoreDetailModule)
  },
  {
    path: 'testresultstatistics',
    loadChildren: () => import('./pages/exam/test-result-statistics/test-result-statistics.module').then(m => m.TestResultStatisticsModule)
  },
  {path: 'menuflow', loadChildren: () => import('./pages/base/menu-flow/menu-flow.module').then(m => m.MenuFlowModule)},
  {
    path: 'menuflowitem',
    loadChildren: () => import('./pages/base/menu-flow-item/menu-flow-item.module').then(m => m.MenuFlowItemModule)
  },
  {
    path: 'placeuse',
    loadChildren: () => import('./pages/process/placeUse/placeUse.module').then(m => m.PlaceUseModule)
  },
  {
    path: 'suppliespurchasedetails',
    loadChildren: () => import('./pages/supplies/supplies-purchase-details/supplies-purchase-details.module').then(m => m.SuppliesPurchaseDetailsModule)
  },
  {
    path: 'suppliesreceivestatistics',
    loadChildren: () => import('./pages/supplies/supplies-receive-statistics/supplies-receive-statistics.module').then(m => m.SuppliesReceiveStatisticsModule)
  },
  {
    path: 'visitform',
    loadChildren: () => import('./pages/process/visit-form/visit-form.module').then(m => m.VisitFormModule)
  },
  {
    path: 'surveyresult',
    loadChildren: () => import('./pages/process/survey-result/survey-result.module').then(m => m.SurveyResultModule)
  },
  {
    path: 'eduproject',
    loadChildren: () => import('./pages/process/edu-project/edu-project.module').then(m => m.EduProjectModule)
  },
  {
    path: 'eduprojectfinish',
    loadChildren: () => import('./pages/process/edu-project-finish/edu-project-finish.module').then(m => m.EduProjectFinishModule)
  },
  {
    path: 'edupaper',
    loadChildren: () => import('./pages/process/edu-paper/edu-paper.module').then(m => m.EduPaperModule)
  },
  {path: 'patent', loadChildren: () => import('./pages/process/patent/patent.module').then(m => m.PatentModule)},
  {
    path: 'workload',
    loadChildren: () => import('./pages/gme/workload/workload.module').then(m => m.WorkloadModule)
  },
  {
    path: 'publicwelfare',
    loadChildren: () => import('./pages/process/public-welfare/public-welfare.module').then(m => m.PublicWelfareModule)
  },
  {
    path: 'couresgraduation',
    loadChildren: () => import('./pages/gme/coures-graduation/coures-graduation.module').then(m => m.CouresGraduationModule)
  },
  {
    path: 'processinstance',
    loadChildren: () => import('./pages/base/process-instance/process-instance.module').then(m => m.ProcessInstanceModule)
  },
  {
    path: 'processrecord',
    loadChildren: () => import('./pages/base/process-record/process-record.module').then(m => m.ProcessRecordModule)
  },
  {
    path: 'curriculumcontinuing',
    loadChildren: () => import('./pages/gme/curriculum-continuing/curriculum-continuing.module').then(m => m.CurriculumContinuingModule)
  },
  {
    path: 'processflow',
    loadChildren: () => import('./pages/process/process-flow/process-flow.module').then(m => m.ProcessFlowModule)
  },
  {
    path: 'specification',
    loadChildren: () => import('./pages/supplies/specification/specification.module').then(m => m.SpecificationModule)
  },
  {
    path: 'supplieswarning',
    loadChildren: () => import('./pages/supplies/supplies-warning/supplies-warning.module').then(m => m.SuppliesWarningModule)
  },
  {
    path: 'afterworkload',
    loadChildren: () => import('./pages/gme/after-workload/after-workload.module').then(m => m.AfterWorkloadModule)
  },
  {
    path: 'experimentalunit',
    loadChildren: () => import('./pages/process/experimental-unit/experimental-unit.module').then(m => m.ExperimentalUnitModule)
  },
  {
    path: 'testcheckin',
    loadChildren: () => import('./pages/exam/test-check-in/test-check-in.module').then(m => m.TestCheckInModule)
  },
  {
    path: 'videoratingplan',
    loadChildren: () => import('./pages/exam/video-rating-plan/video-rating-plan.module').then(m => m.VideoRatingPlanModule)
  },
  {
    path: 'videoplanstudent',
    loadChildren: () => import('./pages/exam/video-plan-student/video-plan-student.module').then(m => m.VideoPlanStudentModule)
  },
  {
    path: 'scorepapersupplies',
    loadChildren: () => import('./pages/gme/score-paper-supplies/score-paper-supplies.module').then(m => m.ScorePaperSuppliesModule)
  },
  {
    path: 'testplanprepare',
    loadChildren: () => import('./pages/exam/test-plan-prepare/test-plan-prepare.module').then(m => m.TestPlanPrepareModule)
  },
  {
    path: 'eduprojecttype',
    loadChildren: () => import('./pages/process/edu-project-type/edu-project-type.module').then(m => m.EduProjectTypeModule)
  },
  {
    path: 'testbeforecheck',
    loadChildren: () => import('./pages/exam/test-before-check/test-before-check.module').then(m => m.TestBeforeCheckModule)
  },
  {
    path: 'checknotify',
    loadChildren: () => import('./pages/process/check-notify/check-notify.module').then(m => m.CheckNotifyModule)
  },
  {
    path: 'selectstaff',
    loadChildren: () => import('./component/select-staff/select-staff.module').then(m => m.SelectStaffModule)
  },
  {
    path: 'safeeducation',
    loadChildren: () => import('./pages/process/safe-education/safe-education.module').then(m => m.SafeEducationModule)
  },
  {
    path: 'articleinventory',
    loadChildren: () => import('./pages/supplies/article-inventory/article-inventory.module').then(m => m.ArticleInventoryModule)
  },
  {
    path: 'supplieswarehousingrecord',
    loadChildren: () => import('./pages/supplies/supplies-warehousing-record/supplies-warehousing-record.module').then(m => m.SuppliesWarehousingRecordModule)
  },
  {path: 'awarded', loadChildren: () => import('./pages/process/awarded/awarded.module').then(m => m.AwardedModule)},
  {
    path: 'monograph',
    loadChildren: () => import('./pages/process/monograph/monograph.module').then(m => m.MonographModule)
  },
  // {path: 'testresultexam', loadChildren: () => import('./pages/exam/test-result-exam/test-result-exam.module').then(m => m.TestResultExamModule)},
  {
    path: 'eduprojectstatistics',
    loadChildren: () => import('./pages/process/edu-project-statistics/edu-project-statistics.module').then(m => m.EduProjectStatisticsModule)
  },
  {path: 'textbook', loadChildren: () => import('./pages/process/textbook/textbook.module').then(m => m.TextbookModule)},
  {
    path: 'teachingresultother',
    loadChildren: () => import('./pages/process/teaching-result-other/teaching-result-other.module').then(m => m.TeachingResultOtherModule)
  },
  {
    path: 'workreporttemplate',
    loadChildren: () => import('./pages/process/work-report-template/work-report-template.module').then(m => m.WorkReportTemplateModule)
  },
  {
    path: 'workreportmember',
    loadChildren: () => import('./pages/process/work-report-member/work-report-member.module').then(m => m.WorkReportMemberModule)
  },
  {path: 'workreport', loadChildren: () => import('./pages/process/work-report/work-report.module').then(m => m.WorkReportModule)},
  {path: 'intro', loadChildren: () => import('./pages/base/intro/intro.module').then(m => m.IntroModule)},
  {path: 'safeeducationsignature', loadChildren: () => import('./pages/process/safe-education-signature/safe-education-signature.module').then(m => m.SafeEducationSignatureModule)},
  {path: 'schedule', loadChildren: () => import('./pages/base/schedule/schedule.module').then(m => m.ScheduleModule)},
  {path: 'simpletestplan', loadChildren: () => import('./pages/exam/simple-test-plan/simple-test-plan.module').then(m => m.SimpleTestPlanModule)},
  {path: 'simpleteststudent', loadChildren: () => import('./pages/exam/simple-test-student/simple-test-student.module').then(m => m.SimpleTestStudentModule)},
  {path: 'simpletestexaminer', loadChildren: () => import('./pages/exam/simple-test-examiner/simple-test-examiner.module').then(m => m.SimpleTestExaminerModule)},
  {path: 'simpletestscore', loadChildren: () => import('./pages/exam/simple-test-score/simple-test-score.module').then(m => m.SimpleTestScoreModule)},
  {path: 'test', loadChildren: () => import('./pages/exam/test/test.module').then(m => m.TestModule)},
  {path: 'paperscorereduce', loadChildren: () => import('./pages/gme/paper-score-reduce/paper-score-reduce.module').then(m => m.PaperScoreReduceModule)},
  {path: 'testresultexamcombination', loadChildren: () => import('./pages/exam/test-result-exam-combination/test-result-exam-combination.module').then(m => m.TestResultExamCombinationModule)},
  {path: 'resourcestaff', loadChildren: () => import('./pages/gme/resource-staff/resource-staff.module').then(m => m.ResourceStaffModule)},
  {path: 'resourcerecord', loadChildren: () => import('./pages/gme/resource-record/resource-record.module').then(m => m.ResourceRecordModule)},
  {path: 'trainingitemsupplies', loadChildren: () => import('./pages/process/training-item-supplies/training-item-supplies.module').then(m => m.TrainingItemSuppliesModule)},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}