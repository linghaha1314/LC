import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, NavigationEnd, Router} from "@angular/router";
import {Title} from "@angular/platform-browser";
import {of} from "rxjs";
import {map} from "rxjs/operators";
import {InitUtils} from "./utils/InitUtils";

@Component({
  selector: 'app-root',
  template: `
    <router-outlet></router-outlet>`
})
export class BootComponent implements OnInit {

  constructor(private router: Router, private activatedRoute: ActivatedRoute,
              private titleService: Title, private initUtils: InitUtils) {
    this.initUtils.initTheme();
  }

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        of(event).pipe(map(() => this.activatedRoute),
          map(route => {
            while (route.firstChild) {
              route = route.firstChild;
            }
            return route;
          }),
          map(route => route.data), map((route: any) => route.value)).subscribe((e) => {
          // 设置title
          this.routerInit(e);
        });
      }
    });
  }

  // 设置名称
  routerInit(event) {
    if (event.title) {
      this.titleService.setTitle(event.title);
    }
  }

}

