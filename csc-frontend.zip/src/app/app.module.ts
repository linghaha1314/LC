import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {IconsProviderModule} from './icons-provider.module';
import {NzLayoutModule} from 'ng-zorro-antd/layout';
import {NzMenuModule} from 'ng-zorro-antd/menu';
import {NzSpinModule} from 'ng-zorro-antd/spin';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzMessageModule} from 'ng-zorro-antd/message';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzAvatarModule} from 'ng-zorro-antd/avatar';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzBreadCrumbModule} from 'ng-zorro-antd/breadcrumb';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzCardModule} from 'ng-zorro-antd/card';
import {NzDividerModule} from 'ng-zorro-antd/divider';
import {NzDropDownModule} from 'ng-zorro-antd/dropdown';
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzListModule} from 'ng-zorro-antd/list';
import {NzModalModule} from 'ng-zorro-antd/modal';
import {NzPopoverModule} from 'ng-zorro-antd/popover';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzTypographyModule} from 'ng-zorro-antd/typography';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {HttpBaseInterceptor} from './utils/HttpBaseInterceptor';

import {
  ArrowRightOutline,
  BellOutline,
  MailOutline,
  MessageOutline,
  NotificationOutline,
  RedoOutline,
  TeamOutline,
  UserOutline
} from '@ant-design/icons-angular/icons';
import {DataTreeComponent} from './component/data-tree/data-tree.component';
import {UserMsgComponent} from './component/user-msg/user-msg.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
// 设置语言包
import {registerLocaleData} from '@angular/common';
import zh from '@angular/common/locales/zh';
import {ValidateMsgModule} from './component/validate-msg/validate-msg.module';
import {FormComboModule} from "./component/form/combobox/form-combo.module";
import {ScrollingModule} from "@angular/cdk/scrolling";
import {ChatRoomModule} from "./component/chat-room/chat-room.module";
import {LoadStatusModule} from "./component/load-status/load-status.module";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {NzDrawerModule} from "ng-zorro-antd/drawer";
import {NzTagModule} from "ng-zorro-antd/tag";
import {StorageService} from "./storage.service";


const icons = [ArrowRightOutline, NotificationOutline, MailOutline, UserOutline, TeamOutline, RedoOutline, MessageOutline, BellOutline];

registerLocaleData(zh);

@NgModule({
  declarations: [
    AppComponent,
    DataTreeComponent,
    UserMsgComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    IconsProviderModule,
    NzLayoutModule,
    NzMenuModule,
    NzBreadCrumbModule,
    HttpClientModule,
    NzSpinModule,
    NzInputModule,
    NzIconModule.forRoot(icons),
    FormsModule,
    NzMessageModule,
    NzGridModule,
    NzAvatarModule,
    NzPopoverModule,
    NzBadgeModule,
    NzCardModule,
    NzDropDownModule,
    NzDividerModule,
    NzModalModule,
    NzRadioModule,
    ReactiveFormsModule,
    ValidateMsgModule,
    NzFormModule,
    FormComboModule,
    NzListModule,
    ScrollingModule,
    ChatRoomModule,
    NzButtonModule,
    NzTypographyModule,
    LoadStatusModule,
    NzSpaceModule,
    NzDrawerModule,
    NzTagModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: HttpBaseInterceptor,
    multi: true
  }, StorageService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
