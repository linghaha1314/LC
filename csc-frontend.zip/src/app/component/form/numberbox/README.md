## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `placeholder` | 空说明 | *string* | - | any |
| `readonly` | 只读 | *boolean* | - | `false` `true` |
| `width` | 控件宽度 | *string* | - |  `150px` |
| `min` | 最小值 | *number* | - | - |
| `max` | 最大值 | *number* | - | - |
| `formatter` | 格式化显示(参考nzInputNumber) | *string* | - | - |
| `precision` | 精度 | *number* | - | - |
| `step` | 步长 | *number* | 1 | - |

## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
