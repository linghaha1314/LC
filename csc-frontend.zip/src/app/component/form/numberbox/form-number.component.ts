import {Component, forwardRef, Input} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';

@Component({
  selector: 'form-number',
  template: `
    <nz-input-group [nzPrefix]="prefixTemplate" [nzSuffix]="suffixTemplate" style="padding: 0px;"
                    [ngStyle]="{width: width}">
      <nz-input-number [(ngModel)]="value" class="input-number" [nzMin]="min" [nzMax]="max" [nzStep]="step" [nzFormatter]="formatter"
                       [nzDisabled]="readonly" [nzPlaceHolder]="placeholder"></nz-input-number>
    </nz-input-group>
    <ng-template #suffixTemplate>
      <button nz-button type="button" nzType="default" class="icon-button-left" (click)="changeValue('+')"
              [disabled]="readonly">
        <i nz-icon nzType="plus"></i>
      </button>
    </ng-template>
    <ng-template #prefixTemplate>
      <button nz-button type="button" nzType="default" class="icon-button-right" (click)="changeValue('-')"
              [disabled]="readonly">
        <i nz-icon nzType="minus"></i>
      </button>
    </ng-template>
  `,
  styleUrls: ['./form-number.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormNumberComponent),
    multi: true
  }]
})
export class FormNumberComponent extends BaseComponent {

  @Input()
  readonly: boolean;

  @Input()
  placeholder = '';

  @Input()
  width: string;

  @Input()
  min: number;

  @Input()
  max: number;

  @Input()
  formatter: (value: number | string) => string | number = value => value;

  @Input()
  precision = 0;

  @Input()
  step = 1;

  changeValue(type: string) {
    if (typeof this.value == 'string') {
      const n = parseInt(this.value);
      if (isNaN(n)) {
        this.value = 0;
      } else {
        this.value = n;
      }
    }
    const newVal = type == '+' ? this.value + this.step : this.value - this.step;
    if (newVal < this.min) {
      this.value = this.min;
      return;
    }
    if (newVal > this.max) {
      this.value = this.max;
      return;
    }
    if (this.precision > 0) {
      this.value = parseFloat((newVal).toFixed(this.precision));
    } else {
      this.value = newVal;
    }
  }

  onEmit(v: any) {
    super.onEmit(v);
  }
}
