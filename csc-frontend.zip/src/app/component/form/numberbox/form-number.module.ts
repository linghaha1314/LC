import {NgModule} from '@angular/core';
import {FormsModule} from "@angular/forms";
import {CommonModule} from '@angular/common';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzInputNumberModule} from 'ng-zorro-antd/input-number';
import {FormNumberComponent} from "./form-number.component";


@NgModule({
  declarations: [FormNumberComponent],
  exports: [
    FormNumberComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NzIconModule,
    NzInputNumberModule,
    NzInputModule,
    NzButtonModule,
  ]
})
export class FormNumberModule {
}
