## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `mode` | 单选或多选 | *NzSelectModeType* | `default` | `default` `tags` `multiple` |
| `pageType` | 分页插件或滚动加载 | *ComboPageType* | `default` | `default` `scroll` |
| `readonly` | 只读 | *boolean* | - | false |
| `page` | 是否分页查询 | *boolean* | true | false |
| `pageSize` | 分页查询大小 | *number* | 10 | - |
| `queryParams` | 额外查询参数(修改需要用等于才能触发监听) | *object* | {} | - |
| `placeholder` | placeholder | *string* | - | - |
| `data` | 可选数据 | *any[]* | [] | - |
| `topData` | 渲染到顶部的额外数据 | *any[]* | - | - |
| `valueKey` | value值采用key | *string* | id | - |
| `labelKey` | label值采用key | *string* | name | - |
| `url` | 远程数据地址 | *string* | - | - |
| `textField` | 单选时候默认显示值 | *string* | - | - |

## 自定义选项
如果customContent为true,则需要自定义显示选项，如下:
```
<form-combo [customContent]="true">
    <ng-template let-option>{{option.name}}({{option.code}})</ng-template>
</form-combo>
```

## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
| `onSelect` | 选择事件 | *any*或*any[]* |
| `renderBefore` | 可以通过方法处理渲染前的数据 | *any[]* |

## 数据说明
如果mode为multiple或tags传入的值为包含valueKey和labelKey的数组(如: `[{id: 1, name: 'apple''}]`),如果是默认值为labelKey的值
