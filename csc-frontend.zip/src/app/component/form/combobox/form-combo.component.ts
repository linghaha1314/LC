import {Component, ContentChild, EventEmitter, forwardRef, Input, OnInit, Output, TemplateRef} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';
import {Help} from "../../../utils/Help";
import {NzSelectModeType} from "ng-zorro-antd/select/select.types";

export declare type ComboPageType = 'default' | 'scroll';

@Component({
  selector: 'form-combo',
  template: `
    <nz-select [(ngModel)]="value" [nzDisabled]="readonly" [nzPlaceHolder]="placeholder" nzShowSearch
               [nzAllowClear]="allowClear"
               [nzServerSearch]="page" (nzOnSearch)="searchData($event)" (ngModelChange)="selectData($event)"
               style="width: 100%;" [nzMode]="mode" [nzDropdownRender]="renderTemplate" [nzLoading]="loading"
               (nzScrollToBottom)="scrollBottom()">
      <nz-option *ngFor="let d of topData" [nzLabel]="d[labelKey]" [nzValue]="d[valueKey]"></nz-option>
      <ng-container *ngFor="let d of data">
        <nz-option [nzLabel]="d[labelKey]" *ngIf="d._hide != true" [nzValue]="d[valueKey]" [nzCustomContent]="customContent">
          <ng-template [ngTemplateOutlet]="templateRef" [ngTemplateOutletContext]="{$implicit: d}"></ng-template>
        </nz-option>
      </ng-container>
      <nz-option *ngIf="pageType=='scroll' && loading" nzDisabled nzCustomContent>
        <i nz-icon nzType="loading" class="loading-icon"></i> 加载数据中...
      </nz-option>
      <nz-option *ngFor="let d of defaultValue" [nzLabel]="d[labelKey]" [nzValue]="d[valueKey]"
                 nzHide></nz-option>
    </nz-select>
    <ng-template #renderTemplate>
      <ng-template [ngIf]="page && pageType == 'default'">
        <nz-divider style="margin: 3px 0;"></nz-divider>
        <nz-pagination style="margin: 0 10px;" [(nzPageIndex)]="pageNum" [nzTotal]="total" [nzSize]="'small'"
                       [nzShowTotal]="totalTemplate" (nzPageIndexChange)="changePage($event)"></nz-pagination>
        <ng-template #totalTemplate let-total let-range="range">
          <i nz-icon *ngIf="loading" nzType="loading" class="loading-icon"></i>
          {{ range[0] }}-{{ range[1] }} 共 {{ total }}条
        </ng-template>
      </ng-template>
    </ng-template>
  `,
  styleUrls: [`./form-combo.component.scss`],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormComboComponent),
    multi: true
  }]
})
export class FormComboComponent extends BaseComponent implements OnInit {

  @ContentChild(TemplateRef)
  templateRef: TemplateRef<any>;
  @Input()
  mode: NzSelectModeType = 'default';
  @Input()
  customContent = false;
  @Input()
  allowClear = true;
  @Input()
  readonly: boolean;
  @Input()
  page = true;
  @Input()
  pageType: ComboPageType = 'default';
  @Input()
  pageSize = 10;
  pageNum = 1;
  @Input()
  placeholder: string;
  @Input()
  data: Array<any> = [];
  @Input()
  topData: Array<any> = [];
  @Input()
  valueKey = 'id';
  @Input()
  labelKey = 'name';
  @Output()
  renderBefore = new EventEmitter();
  @Output()
  onSelect = new EventEmitter();
  loading = false;
  defaultValue: Array<any> = [];
  total: number;
  searchText = '';
  private _initFlag = false;

  constructor(private help: Help) {
    super();
  }

  private _queryParams: any = {};

  get queryParams(): any {
    return this._queryParams;
  }

  @Input()
  set queryParams(value: any) {
    this.data = [];
    this._queryParams = value;
    this.pageNum = 1;
    this.getData();
  }

  private _url: string;

  get url(): string {
    return this._url;
  }

  @Input()
  set url(value: string) {
    this._url = value;
    this.changePage();
  }

  private _textField: string;

  get textField(): string {
    return this._textField;
  }

  @Input()
  set textField(value: string) {
    this._textField = value;
    this.initDefaultValue();
  }

  onEmit(v: any) {
    super.onEmit(v);
  }

  ngOnInit() {
    // 初始化完成后再加载数据防止多次加载
    this._initFlag = true;
    this.getData();
  }

  // 接收外部数据监听
  writeValue(value: any) {
    if (value !== this.innerValue) {
      if (this.mode != 'default' && value) {
        this.defaultValue = value;
        const list = [];
        value.forEach(v => {
          list.push(v[this.valueKey]);
        });
        this.innerValue = list;
      } else {
        this.innerValue = value;
        this.initDefaultValue();
      }
    }
  }

  initDefaultValue() {
    if (this.innerValue && this.textField) {
      const d = {};
      d[this.valueKey] = this.innerValue;
      d[this.labelKey] = this.textField;
      this.defaultValue = [d];
    }
  }

  getData() {
    if (this.url && this._initFlag) {
      this.loading = true;
      const p: any = {
        ...this.queryParams,
        name: this.searchText
      };
      if (this.page) {
        p['pageNum'] = this.pageNum;
        p['pageSize'] = this.pageSize;
      } else {
        this.data.length = 0;
      }
      p['nameMore'] = "yes";
      this.help.post(this.url, p).subscribe(({rows, total}) => {
        this.loading = false;
        this.renderBefore.emit(rows);
        if (this.pageType == 'scroll') {
          this.data.push(...rows);
        } else {
          this.data = rows;
        }
        this.total = total;
      });
    }
  }

  changePage(index = 1) {
    this.pageNum = index;
    this.getData();
  }

  searchData(v) {
    if (v == this.searchText) {
      return;
    }
    this.searchText = v;
    if (this.url) {
      this.data.length = 0;
      this.pageNum = 1;
      this.getData();
    } else {
      const list = [...this.data];
      list.forEach(r => {
        r._hide = !(r[this.labelKey].indexOf(this.searchText) > -1);
      });
      this.data = list;
    }
  }

  selectData(d: any) {
    let e: any = [];
    this.data.some(v => {
      if (d instanceof Array) {
        d.forEach(c => {
          if (v[this.valueKey] == c) {
            e.push(v);
          }
        });
      } else {
        if (v[this.valueKey] == d) {
          e = v;
          return true;
        }
      }
    });
    this.onSelect.emit(e);
  }

  scrollBottom() {
    if (this.pageType == 'scroll' && this.loading === false && this.data.length > 0) {
      if (this.data.length >= this.total) {
        return;
      }
      this.changePage(this.pageNum + 1);
    }
  }
}
