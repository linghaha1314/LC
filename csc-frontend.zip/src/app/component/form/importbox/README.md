## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `url` | 导入路径 | *string* | 必需 | any |
| `links` | 关联关系 | *json* | 必需 | `{name: '姓名'}` |
| `template` | 导入模板 | *string* | - | - |
| `limit` | 每一批导入数据量 | *number* | 100 | - |
| `saveBefore` | 导入前 | *Function* | - | 需要返回类型:`Observable<any[]>` |

## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
| `change` | 选择文件后触发事件 | 要导入的值
| `saveAfter` | 导入后触发事件 | 导入结果和错误值

## 错误返回说明
返回结果中data为错误的数据，每一条错误信息需要在每一条返回数据中加上msg字段

## saveBefore说明
使用采用绑定属性的形式`[saveBefore]=[before]`<br/>
其中before如下:
```$xslt
  before = d => {
    return of(d);
  }
```
采用属性方法的写法实现,传入参数就是要保存的数据类型为:`any[]`<br/>
返回需要返回的类型为:`Observable<any[]>`
