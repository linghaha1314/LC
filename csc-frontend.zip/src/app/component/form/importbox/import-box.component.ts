import {Component, ElementRef, EventEmitter, Input, Output, ViewChild} from "@angular/core";
import * as XLSX from "xlsx";
import {from, Observable, of} from "rxjs";
import {Help} from "../../../utils/Help";
import {last} from "rxjs/operators";
import {NzMessageService} from 'ng-zorro-antd/message';

export declare type ModeType = 'default' | 'validate';

@Component({
  selector: 'import-box',
  templateUrl: './import-box.component.html'
})
export class ImportBoxComponent {

  @ViewChild('file')
  input: ElementRef;
  @Input()
  url: string;
  @Input()
  template: string;
  @Input()
  mode: ModeType = 'default';
  @Input()
  limit = 100;
  @Output()
  saveBefore = new EventEmitter();
  @Output()
  saveAfter = new EventEmitter();
  @Output()
  changeData = new EventEmitter();
  @Output()
  readBefore = new EventEmitter();
  linkFlag = false;
  linkData: any[];
  msg: string;
  loading = false;
  errorFlag = false;
  errorData: any[];
  errorHeader: string[];
  saveIndex = 0;
  progressStatus = 'active';
  total = 0;
  private _percent = 0;

  constructor(private help: Help, private message: NzMessageService) {
  }

  private _links: any = {};

  get links(): any {
    return this._links;
  }

  @Input()
  set links(value: any) {
    this._links = value;
    if (value) {
      const list = [];
      for (const k in value) {
        list.push({name: value[k], field: k});
      }
      this.linkData = list;
    }
  }

  selectFile() {
    this.msg = null;
    if (Object.keys(this.links).length == 0) {
      this.msg = '请设置字段映射(links)';
      return;
    }
    this.saveIndex = 0;
    this._percent = 0;
    this.progressStatus = 'active';
    this.errorData = null;
    this.input.nativeElement.value = '';
    this.input.nativeElement.click();
  }

  changeFile(v) {
    this.readFile(v.target.files[0]);
  }

  readFile(file) {
    this.readBefore.emit();
    const fileReader = new FileReader();
    fileReader.onload = ev => {
      const data = ev.target.result;
      const workbook = XLSX.read(data, {
        type: "binary",
        cellDates: true,
      });
      let list = [];
      // 遍历并读取第一张表
      for (const sheet in workbook.Sheets) {
        if (workbook.Sheets.hasOwnProperty(sheet)) {
          list = list.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
          break;
        }
      }
      const rows = [];
      list.forEach(r => {
        const d = {};
        for (const key in this.links) {
          d[key] = r[this.links[key]];
        }
        rows.push(d);
      });
      this.changeData.emit(rows);
      if (this.mode == 'default') {
        this.saveData(rows);
      }
    };
    fileReader.readAsBinaryString(file);
  }

  saveData(rows: any[]) {
    this.loading = true;
    this.before(rows).subscribe(res => {
      this.save(res).subscribe(r => {
        this.loading = false;
        if (r.success) {
          this.message.info(r.msg);
          const data = [], keys = [];
          if (r.data.length > 0) {
            r.data.forEach((d, i) => {
              const a = {错误信息: d['msg']};
              for (const key in this.links) {
                a[this.links[key]] = d[key];
                if (i === 0) {
                  keys.push(this.links[key]);
                }
              }
              data.push(a);
            });
            if (data.length > 0) {
              keys.push('错误信息');
              this.errorData = data;
              this.errorHeader = keys;
              this.errorFlag = true;
            }
          }
          this.saveAfter.emit({data, msg: r.msg});
        }
      }, error => {
        this.loading = false;
        console.error(error);
      });
    });
  }

  save(rows: any[]): Observable<any> {
    this.msg = null;
    if (this.url === undefined) {
      this.msg = '请配置导入接口(url)';
      throw new Error(this.msg);
      return;
    }
    this.total = rows.length;
    return new Observable<any>(res => {
      const list = this.getDataBranch(rows.length), step = 100 / list.length;
      let index = 0, errorList = [];
      list.forEach(({start, end}) => {
        this.help.post(this.url, rows.slice(start, end + 1)).subscribe(r => {
          index++;
          this._percent = this._percent + step;
          this.saveIndex = Math.round(this._percent);
          this.progressStatus = 'active';
          if (r.success) {
            errorList = errorList.concat(r.data);
          }
          if (index == list.length) {
            this.progressStatus = 'success';
            setTimeout(() => {
              res.next({
                success: true,
                data: errorList,
                msg: `总共导入数据${rows.length}条,共${errorList.length}条数据导入错误`
              });
            }, 500);
          }
        }, error => {
          index++;
          this.saveIndex = this.saveIndex + step;
          this.progressStatus = 'exception';
          if (index == list.length) {
            setTimeout(() => {
              res.next({
                success: true,
                data: errorList,
                msg: `总共导入数据${rows.length}条,共${errorList.length}条数据导入错误`
              });
            }, 500);
          }
        });
      });
    });
  }

  getDataBranch(total: number): any[] {
    const last = total % this.limit;
    const index = Math.floor(total / this.limit);
    const list = [];
    for (let i = 0; i < index; i++) {
      list.push({start: this.limit * i, end: this.limit * (i + 1) - 1});
      if (i == index - 1) {
        list.push({start: this.limit * (i + 1), end: this.limit * (i + 1) + last - 1});
      }
    }
    if (list.length == 0) {
      list.push({start: 0, end: total});
    }
    return list;
  }

  before(rows: any[]): Observable<any[]> {
    this.saveBefore.emit(rows);
    return of(rows);
  }

  exportErrorData() {
    /* generate worksheet */
    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.errorData);
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '错误数据');
    /* save to file */
    XLSX.writeFile(wb, '导入错误数据.xlsx');
    this.errorFlag = false;
  }

  downloadTemplate() {
    this.getFileName(this.template).subscribe(filename => {
      this.help.get(this.template, {responseType: 'blob' as 'json'}).subscribe(
        (response: any) => {
          const dataType = response.type;
          const binaryData = [];
          binaryData.push(response);
          const downloadLink = document.createElement('a');
          downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, {type: dataType}));
          if (filename) {
            downloadLink.setAttribute('download', filename);
          }
          document.body.appendChild(downloadLink);
          downloadLink.click();
          downloadLink.remove();
        }
      );
    });
  }

  getFileName(path: string) {
    const source = from(path.split('/'));
    return source.pipe(last());
  }
}
