import {Component, forwardRef, Input} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';
import {formatDate} from "@angular/common";
import getISOWeek from 'date-fns/getISOWeek';
import {NzDatePickerSizeType} from "ng-zorro-antd/date-picker/date-picker.component";

export declare type ModeType = 'date' | 'dateTime' | 'week' | 'year' | 'month';

@Component({
  selector: 'form-date',
  template: `
    <nz-date-picker [(ngModel)]="value"
                    [nzShowTime]="showTime"
                    [nzDisabled]="readonly"
                    [nzFormat]="dateFormat"
                    [nzPlaceHolder]="placeholder"
                    [nzMode]="mode"
                    [nzSize]="size"
                    nzShowNow
                    nzShowToday
                    style="width: 100%;"></nz-date-picker>`,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormDateComponent),
    multi: true
  }]
})
export class FormDateComponent extends BaseComponent {

  @Input()
  readonly: boolean;

  @Input()
  placeholder: string;

  @Input()
  dateFormat: 'yyyy-MM-dd' | 'yyyy-MM-dd HH:mm:ss' = 'yyyy-MM-dd';

  @Input()
  size: NzDatePickerSizeType = 'default';

  private _showTime = false;

  get showTime(): boolean {
    return this._showTime;
  }

  @Input()
  set showTime(value: boolean) {
    if (value) {
      this.dateFormat = 'yyyy-MM-dd HH:mm:ss';
    } else {
      this.dateFormat = 'yyyy-MM-dd';
    }
    this._showTime = value;
  }

  private _mode: ModeType = "date";

  get mode(): ModeType {
    return this._mode;
  }

  @Input()
  set mode(value: ModeType) {
    if (value == 'dateTime') {
      this.showTime = true;
      this._mode = 'date';
    } else {
      this.dateFormat = null;
      this._mode = value || "date";
    }
  }

  writeValue(value: any) {
    if (new Date(value).toDateString() == 'Invalid Date') {
      return;
    }
    super.writeValue(value);
  }

  onEmit(v: any) {
    if (v == null) {
      super.onEmit(v);
      return;
    }
    let d;
    if (this.mode == "date") {
      if (this.showTime) {
        d = formatDate(v, 'yyyy-MM-dd HH:mm:ss', 'zh');
      } else {
        d = formatDate(v, 'yyyy-MM-dd', 'zh');
      }
    } else if (this.mode == "year") {
      d = formatDate(v, 'yyyy', 'zh');
    } else if (this.mode == "month") {
      d = formatDate(v, 'yyyy-MM', 'zh');
    } else if (this.mode == 'week') {
      d = formatDate(v, 'yyyy', 'zh') + '-' + getISOWeek(v);
    }

    super.onEmit(d);
  }
}
