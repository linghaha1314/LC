## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `placeholder` | 空说明 | *string* | - | any |
| `readonly` | 只读 | *boolean* | - | `false` `true` |
| `showTime` | 是否显示时分秒 | *boolean* | - |  `false` `true` |
| `dateFormat` | 日期格式 | *string* | `yyyy-MM-dd` | - |
| `mode` | 选择的格式 | *string* | `year` `date` `dateTime` `week` `month` | - |
## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
