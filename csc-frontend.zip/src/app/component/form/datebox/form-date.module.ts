import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormDateComponent} from "./form-date.component";
import {NzDatePickerModule} from 'ng-zorro-antd/date-picker';
import {FormsModule} from "@angular/forms";


@NgModule({
  declarations: [FormDateComponent],
  exports: [
    FormDateComponent
  ],
  imports: [
    CommonModule,
    NzDatePickerModule,
    FormsModule,
  ]
})
export class FormDateModule {
}
