import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from "@angular/forms";
import {FormUploadComponent} from "./form-upload.component";
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzCardModule} from 'ng-zorro-antd/card';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzModalModule} from 'ng-zorro-antd/modal';
import {NzSpinModule} from 'ng-zorro-antd/spin';
import {NzUploadModule} from 'ng-zorro-antd/upload';


@NgModule({
  declarations: [FormUploadComponent],
  exports: [
    FormUploadComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NzUploadModule,
    NzIconModule,
    NzGridModule,
    NzButtonModule,
    NzSpinModule,
    NzModalModule,
    NzCardModule,
  ]
})
export class FormUploadModule {
}
