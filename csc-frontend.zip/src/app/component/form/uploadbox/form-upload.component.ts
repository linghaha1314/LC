import {Component, ElementRef, EventEmitter, forwardRef, Input, Output, ViewChild,} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';
import {Help} from "../../../utils/Help";
import {from, Observable, of} from "rxjs";
import {last, map} from "rxjs/operators";
import {DomSanitizer, SafeHtml} from "@angular/platform-browser";
import {NzMessageService} from "ng-zorro-antd/message";
import {Buffer} from "buffer";

export declare type UploadModel = 'string' | 'array';
declare const BASE_URL: string;

@Component({
  selector: 'form-upload',
  template: `
    <nz-upload #upload [nzDisabled]="readonly"
               nzType="drag"
               [nzMultiple]="true"
               [nzSize]="size"
               [nzLimit]="limit"
               [nzFileType]="fileType"
               [nzCustomRequest]="uploadFile" style="padding: 0px;">
      <ng-template [ngIf]="fileList.length == 0">
        <p class="ant-upload-drag-icon">
          <i nz-icon nzType="inbox"></i>
        </p>
        <p class="ant-upload-text">{{placeholder}}</p>
        <p class="ant-upload-hint">
          <ng-content></ng-content>
        </p>
      </ng-template>
      <ng-template [ngIf]="fileList.length > 0">
        <nz-spin [nzSpinning]="load">
          <div nz-row>
            <div nz-card-grid nz-col nzXs="24" nzSm="12" nzMd="8" nzLg="6" nzXl="4" class="preview-img"
                 *ngFor="let file of fileList"
                 [title]="file.name">
              <button nz-button nzType="dashed" type="button" (click)="remove(file, $event)" nzShape="circle"
                      nzSize="small" class="remove-btn" [disabled]="readonly"><i nz-icon nzType="close"></i></button>
              <button nz-button nzType="dashed" type="button" (click)="previewFile(file, $event)" nzShape="circle"
                      nzSize="small" class="review-btn"><i nz-icon nzType="eye"></i></button>
              <img [src]="'./assets/images/attach/'+file.icon+'.svg'" style="width: 100%;"/>
              <div class="preview-text" [ngStyle]="{width: '100%'}">{{file.name}}</div>
            </div>
          </div>
        </nz-spin>
      </ng-template>
    </nz-upload>
    <nz-modal [(nzVisible)]="_contentModal" [nzTitle]="_now.name" (nzOnCancel)="_contentModal = false" nzWidth="80%"
              [nzFooter]="null">
      <div style="text-align: right;margin-bottom: 10px;">
        <button nz-button nzType="primary" (click)="downloadFile(_now)"><i nz-icon nzType="download"></i>下载文件</button>&nbsp;
        <button nz-button nzType="primary" (click)="openWindow()"><i nz-icon nzType="search"></i>新窗口打开</button>
      </div>
      <iframe *ngIf="_contentModal && iframe" [src]="iframe" [ngStyle]="{height: height}" style="width: 100%;"
              frameborder="0"></iframe>
    </nz-modal>
  `,
  styles: [`
    .preview-img {
      width: 100%;
      padding: 5px 5px;
    }

    .remove-btn {
      float: right;
      margin-bottom: -24px;
      opacity: 0.5;
    }

    .remove-btn:hover {
      opacity: 1;
    }

    .review-btn {
      float: right;
      margin-bottom: -24px;
      opacity: 0.5;
      right: 28px;
    }

    .review-btn:hover {
      opacity: 1;
    }

    .preview-text {
      text-align: center;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  `],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormUploadComponent),
    multi: true
  }]
})
export class FormUploadComponent extends BaseComponent {
  @Input()
  size: number = 0;
  @Input()
  limit: number = 0;
  @Input()
  fileType: string;
  @Input()
  uploadFileType = [];
  @Input()
  type: UploadModel = 'string';
  @Input()
  readonly: boolean;
  @Input()
  placeholder = '点击或拖拽文件到当前区域';
  @Input()
  params: any = {};
  @Input()
  url = '/file/upload';
  @Input()
  removeUrl = '/file/remove';
  load = false;
  fileList = [];
  @ViewChild("upload", {read: ElementRef})
  uploadComponent: ElementRef;
  @Output()
  fileListChange = new EventEmitter();
  $icon = {
    txt: "document",
    png: "image",
    jpeg: "image",
    jpg: "image",
    gif: "image",
    ico: "image",
    tif: "image",
    tiff: "image",
    psd: "image",
    psb: "image",
    ami: "image",
    apx: "image",
    bmp: "image",
    bpg: "image",
    brk: "image",
    cur: "image",
    dds: "image",
    dng: "image",
    exr: "image",
    fpx: "image",
    gbr: "image",
    img: "image",
    jbig2: "image",
    jb2: "image",
    jng: "image",
    jxr: "image",
    pbm: "image",
    pgf: "image",
    pic: "image",
    raw: "image",
    webp: "image",
    eps: "image",
    afphoto: "image",
    ase: "image",
    aseprite: "image",
    clip: "image",
    cpt: "image",
    heif: "image",
    heic: "image",
    kra: "image",
    mdp: "image",
    ora: "image",
    pdn: "image",
    reb: "image",
    sai: "image",
    tga: "image",
    xcf: "image",
    pdf: "pdf",
    xlsx: "table",
    xls: "table",
    csv: "table",
    tsv: "table",
    webm: "video",
    mkv: "video",
    flv: "video",
    vob: "video",
    ogv: "video",
    ogg: "video",
    gifv: "video",
    avi: "video",
    mov: "video",
    qt: "video",
    wmv: "video",
    yuv: "video",
    rm: "video",
    rmvb: "video",
    mp4: "video",
    m4v: "video",
    mpg: "video",
    mp2: "video",
    mpeg: "video",
    mpe: "video",
    mpv: "video",
    m2v: "video",
    doc: "word",
    docx: "word",
    rtf: "word",
    mp3: "audio",
    flac: "audio",
    m4a: "audio",
    wma: "audio",
    aiff: "audio",
  };
  $height = {
    video: "580px",
    image: "400px",
    table: "400px",
    word: "400px",
    audio: "515px",
    pdf: "500px",
    file: "400px",
    document: "auto"
  };
  _contentModal = false;
  _now: any = {};
  _url: string;
  _fileViewerServer: string;
  _fileViewerClient: string;
  height: string;
  iframe: SafeHtml;

  constructor(private help: Help, private sanitizer: DomSanitizer, private msg: NzMessageService) {
    super();
  }

  uploadFile = (options: any) => {
    if (this.limit && this.fileList.length >= this.limit) {
      this.msg.error(`最大支持上传${this.limit}个文件`);
      return;
    }
    if (this.uploadFileType.length > 0 && this.uploadFileType.indexOf(options.file.name.substring(options.file.name.lastIndexOf('.') + 1)) == -1) {
      this.msg.error(`请上传${this.uploadFileType.toString()}格式的文件！`);
      return;
    }
    const data = new FormData();
    data.append('files', options.file);
    for (const k in this.params) {
      data.append(k, this.params[k]);
    }
    return this.help.post(this.url, data).subscribe((res: any) => {
      if (res.success) {
        this.getFileName(res.filePath).subscribe(v => {
          this.fileList.push(this.compileRow({path: res.filePath, name: v, size: res.size}));
        });
        this.onEmit(this.fileList);
      }
      options.onSuccess(res, options.file);
    }, error => {
      options.onError(error['msg'], options.file);
    });
  };

  remove(file, event) {
    event.stopPropagation();
    this.load = true;
    this.help.post(this.removeUrl, {filePath: file.path}).subscribe((res: any) => {
      this.load = false;
      if (res.success) {
        this.fileList = this.fileList.filter(item => {
          return item !== file;
        });
        this.onEmit(this.fileList);
      }
    }, err => {
      this.load = false;
    });
  }

  writeValue(value: any) {
    this.fileList.length = 0;
    if (value) {
      if (this.type == 'string') {
        value.split(',').forEach(r => {
          this.getFileName(r).subscribe(p => {
            this.fileList.push(this.compileRow({path: r, name: p}));
          });
        });
      } else {
        value.forEach(r => {
          this.getFileName(r.path).subscribe(p => {
            this.fileList.push(this.compileRow({path: r.path, name: p}));
          });
        });
      }
    }
    super.writeValue(value);
  }

  onEmit(v: any) {
    if (this.type == 'string') {
      const list = [];
      v.forEach(d => {
        list.push(d.path);
      });
      super.onEmit(list.join(','));
    } else {
      super.onEmit(v);
    }
    this.fileListChange.emit(v);
  }

  getFileName(path: string) {
    const source = from(path.split('/'));
    return source.pipe(last());
  }

  compileRow(r: any): any {
    let d = this.$icon[r.name.split('.')[1]];
    if (d == null) {
      d = 'file';
    }
    r['icon'] = d;
    return r;
  }

  getFileViewer(): Observable<string> {
    if (this._fileViewerServer != null) {
      return of(this._fileViewerServer);
    }
    return this.help.get('/config/getFileViewer').pipe(map((d: any) => {
      this._fileViewerServer = d['fileServer'];
      this._fileViewerClient = d['fileClient'];
      return d;
    }));
  }

  previewFile(r: any, event) {
    event.stopPropagation();
    this._now = r;
    this.getFileViewer().subscribe(() => {
      const u = encodeURIComponent(Buffer.from(this._fileViewerClient + r.path).toString('base64'));
      this._url = `${this._fileViewerServer}/onlinePreview?url=${u}`;
      this.height = this.$height[r.icon];
      this.iframe = this.sanitizer.bypassSecurityTrustResourceUrl(this._url);
    });
    this._contentModal = true;
  }

  openWindow() {
    window.open(this._url);
  }

  downloadFile(r) {
    const elt = document.createElement('a');
    elt.setAttribute('href', BASE_URL + r.path);
    elt.setAttribute('download', r.fileName);
    elt.style.display = 'none';
    document.body.appendChild(elt);
    elt.click();
    document.body.removeChild(elt);
  }
}
