## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `placeholder` | 空说明 | *string* | - | any |
| `readonly` | 只读 | *boolean* | - | `false` `true` |
| `type` | 数据类型 | *string* | string |  `string` `array` |
| `url` | 上传路径 | *string* | /file/upload |  - |
| `removeUrl` | 删除路径 | *string* | /file/remove | - |
| `params` | 上传额外参数 | *any* | {} | - |

## 如何修改未选择文件说明
在标签下可以直接定义要显示的说明如:
```html
<form-upload>
  <h1>请选择文件</h1>
</form-upload>
```
其中的`<h1>请选择文件</h1>`就是自定义的说明

## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 

## 数据说明
如果type是string格式为用逗号隔开的字符串<br>
如果type是array格式为`[{path: ''}]`其中path为必须的字段
