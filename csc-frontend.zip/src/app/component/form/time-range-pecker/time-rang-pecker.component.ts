import {Component, forwardRef} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from "../base.component";

@Component({
  selector: 'time-range-pecker',
  template: `
    <a class="time-range-pecker" (click)="ngDepp()">
      <nz-range-picker
        [(ngModel)]="value"
        (nzOnOpenChange)="ngDepp()"
        (nzOnOk)="ngDepp()"
        [nzShowTime]="{nzFormat:'HH:mm'}"
        nzMode="date"
        nzFormat="HH:mm"
        style="width: 100%;"
      ></nz-range-picker>
    </a>
  `,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => TimeRangPeckerComponent),
    multi: true,
  }]
})
export class TimeRangPeckerComponent extends BaseComponent {

  ngDepp() {
    setTimeout(() => {
      const id = document.getElementsByClassName('cdk-overlay-pane')[document.getElementsByClassName('cdk-overlay-pane').length - 1]['id'];
      document.getElementById(id).getElementsByClassName('ant-picker-date-panel')[0]['style']["display"] = 'none';
      document.getElementById(id).getElementsByClassName('ant-btn ant-btn-primary ant-btn-sm')[0].addEventListener("click", this.ngDepp);
    });
  }
}
