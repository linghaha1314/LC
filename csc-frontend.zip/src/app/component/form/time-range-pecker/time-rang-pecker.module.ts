import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {TimeRangPeckerComponent} from "./time-rang-pecker.component";
import {NzDatePickerModule} from 'ng-zorro-antd/date-picker';
import {FormsModule} from "@angular/forms";


@NgModule({
  declarations: [TimeRangPeckerComponent],
  exports: [
    TimeRangPeckerComponent
  ],
  imports: [
    CommonModule,
    NzDatePickerModule,
    FormsModule,
  ]
})
export class TimeRangPeckerModule {
}
