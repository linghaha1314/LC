import {AfterViewInit, Component, ElementRef, forwardRef, Input, ViewChild} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';
import {Help} from "../../../utils/Help";

declare function FroalaEditor(id: any, config: any, n?: any): void;

@Component({
  selector: 'form-editor',
  template: `<textarea style="display: none;" #content></textarea>`,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FroalaEditorComponent),
    multi: true
  }]
})
export class FroalaEditorComponent extends BaseComponent implements AfterViewInit {

  @ViewChild("content", {read: ElementRef})
  content: ElementRef;

  @Input()
  readonly: boolean;

  @Input()
  placeholder: string;

  @Input()
  url = '/file/editorUpload';

  @Input()
  maxCount = -1;

  editor: any;

  constructor(private help: Help) {
    super();
  }

  init() {
    const that = this;
    this.editor = new FroalaEditor(this.content.nativeElement, {
      theme: localStorage.getItem('theme') == "dark" ? 'dark' : null,
      language: 'zh_cn',
      imageUploadURL: this.url,
      fileUploadURL: this.url,
      videoUploadURL: this.url,
      filesManagerUploadURL: this.url,
      placeholderText: this.placeholder,
      documentReady: this.readonly,
      charCounterMax: this.maxCount,
      imageInsertButtons: ['imageBack', '|', 'imageUpload', 'imageByURL'],
      videoInsertButtons: ['videoBack', '|', 'videoUpload', 'videoByURL', 'videoEmbed'],
      toolbarSticky: false,
      events: {
        contentChanged() {
          that.onEmit(this.html.get());
        },
        initialized() {
          // 去掉授权提示
          if (window.location.hostname != 'localhost' && window.location.hostname != '127.0.0.1') {
            that.help.loadStyle("forala_license", '.fr-wrapper div:nth-child(1) {display: none;}');
          }
          this.html.set(that.value);
        }
      }
    });
  }

  writeValue(value: any) {
    if (this.editor && this.editor.html) {
      this.editor.html.set(value);
    }
    super.writeValue(value);
  }

  ngAfterViewInit(): void {
    this.help.loadAssets([
      './assets/froala-editor/froala_editor.pkgd.min.css',
      './assets/froala-editor/froala_style.min.css',
      './assets/froala-editor/dark.min.css',
      './assets/froala-editor/image_tui.min.css',
      './assets/froala-editor/froala_editor.pkgd.min.js'
    ]).subscribe(r => {
      if (r) {
        this.help.loadAssets(['./assets/froala-editor/image_tui.min.js', './assets/froala-editor/zh_cn.js']).subscribe(() => {
          this.init();
        });
      }
    });
  }
}
