## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `placeholder` | 空说明 | *string* | - | any |
| `readonly` | 只读 | *boolean* | - | `false` `true` |
| `url` | 上传路径 | *string* | /file/editorUpload | - |
| `maxCount` | 最大字数 | *number* | -1 | - |

## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
## 显示说明
- `<div class="fr-view" [innerHTML]="title|safeHtml"></div>`
- 在显示html外层加入fr-view即可完成显示<br>
- 其中safeHtml为自定义html显示,需要引入相关module
