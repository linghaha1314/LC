import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {FormsModule} from "@angular/forms";
import {FroalaEditorComponent} from "./froala-editor.component";

@NgModule({
  declarations: [FroalaEditorComponent],
  exports: [FroalaEditorComponent],
  imports: [
    CommonModule,
    FormsModule,
  ]
})
export class FroalaEditorModule {

}
