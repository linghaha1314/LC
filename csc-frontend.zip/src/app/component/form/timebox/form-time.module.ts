import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormTimeComponent} from "./form-time.component";
import {NzTimePickerModule} from 'ng-zorro-antd/time-picker';
import {FormsModule} from "@angular/forms";


@NgModule({
  declarations: [FormTimeComponent],
  exports: [
    FormTimeComponent
  ],
  imports: [
    CommonModule,
    NzTimePickerModule,
    FormsModule,
  ]
})
export class FormTimeModule {
}
