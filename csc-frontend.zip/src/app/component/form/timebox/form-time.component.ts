import {Component, forwardRef, Input} from '@angular/core';
import {NG_VALUE_ACCESSOR} from '@angular/forms';
import {BaseComponent} from '../base.component';
import {formatDate} from "@angular/common";

@Component({
  selector: 'form-time',
  template: `
    <nz-time-picker [(ngModel)]="value"
                    [nzDisabled]="readonly"
                    [nzFormat]="timeFormat"
                    [nzPlaceHolder]="placeholder"
                    style="width: 100%;"></nz-time-picker>`,
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => FormTimeComponent),
    multi: true
  }]
})
export class FormTimeComponent extends BaseComponent {

  @Input()
  readonly: boolean;

  @Input()
  placeholder: string;

  @Input()
  timeFormat = 'HH:mm';

  onEmit(v: any) {
    if (v == null) {
      super.onEmit(v);
      return;
    }
    super.onEmit(formatDate(v, this.timeFormat, 'zh'));
  }
}
