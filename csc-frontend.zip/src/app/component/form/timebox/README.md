## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `placeholder` | 空说明 | *string* | - | any |
| `readonly` | 只读 | *boolean* | - | `false` `true` |
| `timeFormat` | 时间格式 | *string* | `HH:mm` | - |

## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
