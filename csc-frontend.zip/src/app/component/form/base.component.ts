import {ControlValueAccessor} from '@angular/forms';
import {noop} from 'rxjs';


export class BaseComponent implements ControlValueAccessor {

  // 内部model值
  public innerValue: any;
  // 定义ControlValueAccessor提供的事件回调
  private onTouched: () => void = noop;
  private onChange: (_: any) => void = noop;

  // 获取值的访问
  get value(): any {
    return this.innerValue;
  }

  // 设置值，同时触发change回调
  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onEmit(v);
    }
  }

  // 传回内部值
  onEmit(v: any) {
    this.onChange(v);
  }

  // 失焦时触发回调
  onBlur() {
    this.onTouched();
  }

  // 接收外部数据监听
  writeValue(value: any) {
    if (value !== this.innerValue) {
      this.innerValue = value;
    }
  }

  // 表单ControlValueAccessor接口
  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  // 表单ControlValueAccessor接口
  registerOnTouched(fn: any) {
    this.onTouched = fn;
  }

}
