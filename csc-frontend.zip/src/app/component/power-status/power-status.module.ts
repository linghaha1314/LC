import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {PowerStatusComponent} from './power-status.component';


@NgModule({
  declarations: [PowerStatusComponent],
  exports: [
    PowerStatusComponent
  ],
  imports: [
    CommonModule,
  ]
})
export class PowerStatusModule {
}
