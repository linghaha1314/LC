import {Component, Input, OnDestroy, OnInit} from '@angular/core';

@Component({
  selector: 'power-status',
  templateUrl: './power-status.component.html',
  styleUrls: ['./power-status.component.scss'],
})
export class PowerStatusComponent implements OnInit, OnDestroy {

  _interval: number;

  private _battery = 0;

  color = "transparent";

  get battery(): number {
    return this._battery;
  }

  @Input()
  set battery(value: number) {
    this._battery = value;
    this.changeBattery();
  }

  ngOnInit(): void {
    this._interval = setInterval(() => {
      if (this._battery < 10) {
        this.color = this.color == "red" ? "gray" : "red";
      }
    }, 500);
  }

  ngOnDestroy(): void {
    clearInterval(this._interval);
  }

  changeBattery() {
    if (this.battery > 60) {
      this.color = "green";
    } else if (this.battery < 20) {
      this.color = "red";
    } else {
      this.color = "#ff8f00";
    }
  }
}
