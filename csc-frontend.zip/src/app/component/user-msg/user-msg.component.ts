import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {NzMessageService} from 'ng-zorro-antd/message';
import {Help} from "../../utils/Help";
import {map} from "rxjs/operators";
import {AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {StorageService} from "../../storage.service";

@Component({
  selector: 'app-user-msg',
  templateUrl: './user-msg.component.html',
  styleUrls: ['./user-msg.component.scss']
})
export class UserMsgComponent implements OnInit {

  @Input() hasMsg = true; // 是否有新的消息

  @Input() userInfo: any = {
    userName: '测试账号',
  };

  @Input()
  historyMenu = [];

  @Output()
  navPage = new EventEmitter();

  @Output()
  roleChange = new EventEmitter();


  value; // 绑定的搜索框的内容
  // isSearch = false; // 搜索框是否是出于搜索状态 是否禁用
  accountsId = null;
  staffId = null;
  avatarSrc = null;
  isVisible = false;
  isKeyVisible = false;
  nowRole = "";
  messageCount = 0;
  rolesOption = [];
  messageList = [];
  validateKeyForm: FormGroup = null;
  messagePageNum = 1;
  messageTotal = 0;
  messageLoading = false;

  themeFlag = false;
  msgFlag = false;

  chatClass = {
    padding: 0
  };
  unReadMessageNum: number;
  @Input()
  theme: string;

  @Output()
  changeTheme = new EventEmitter();

  @ViewChild('chatroom')
  chatroom;

  messageVisible = false;

  constructor(private storage: StorageService, private message: NzMessageService, private help: Help, private fb: FormBuilder, private router: Router) {
  }

  skipMenu(data: any): void {
    const menusIds = this.historyMenu.map(function (item) {
      return item.id;
    });
    if (menusIds.indexOf(data.id) > -1) {
      this.historyMenu.splice(menusIds.indexOf(data.id), 1);
    }
    if (this.historyMenu.length == 10) {
      this.historyMenu.splice(9, 1);
    }
    this.historyMenu.splice(0, 0, data);
    this.navPage.emit({userName: data.auth, path: data.path});
    localStorage.setItem("nowName", data.name);
  }

  skipHistoryMenu(data: any) {
    this.navPage.emit({userName: data.auth, path: data.path});
    localStorage.setItem("nowName", data.name);
  }

  ngOnInit(): void {
    this.help.post("/accounts/getCurrentAccounts", {}).subscribe((res: any) => {
      let roleName = "暂无角色";
      if (res["role"] != null) {
        roleName = res["role"].name;
        this.roleChange.emit(res['role']);
        this.nowRole = res["role"].id;
        for (const key in res["roles"]) {
          const dd = {
            value: res["roles"][key].id,
            label: res["roles"][key].name
          };
          this.rolesOption.push(dd);
        }
      }
      this.staffId = res["staff"].id;
      this.accountsId = res["accounts"].id;
      this.userInfo.userName = res["staff"].name + "（" + roleName + "）";
      this.avatarSrc = res["staff"].avator;
      this.getMessageList();
      // this.chatroom.getWs(res["staff"].id, res["staff"].name,res["staff"].avator); //开启子组件
    });
  }

  handleLogout(): void {
    document.cookie = "";
    const d = new Date();
    this.chatroom.closeWs();
    d.setTime(d.getTime() + -1);
    document.cookie = "jwt=1path=/;expires=" + d;
    window.location.reload();
  }

  updateRole(): void {
    this.isVisible = true;
  }

  handleCancel(): void {
    this.isVisible = false;
  }

  skipRouter(path: string): void {
    this.help.setMenuAuth('list');
    this.router.navigate([path]).then();
  }

  getMessageList(): void {
    this.messageLoading = true;
    const messagePageNum = this.messagePageNum;
    this.help.post("/message/getAccountMessageList", {
      pageNum: messagePageNum,
      pageSize: 10,
      staffId: this.staffId
    }).subscribe((res: any) => {
      this.messageLoading = false;
      this.messageList.push(...res.rows);
      this.messageTotal = res.total;
      this.messageCount = res.unReadTotal;
    });
  }


  updateKey(): void {
    this.isKeyVisible = true;
    this.validateKeyForm = this.fb.group({
      oldPassword: [null, [Validators.required, Validators.maxLength(12)]],
      newPassword: [null, [Validators.required, Validators.maxLength(12)]],
      confirmPassword: [null, [Validators.required, Validators.maxLength(12), this.repeat()]]
    });
  }

  readMessage(data: any): void {
    this.messageVisible = false;
    if (data.status == 0) {
      // 未读消息  需改为已读
      this.help.post("/messageList/readMessage", {code: data.code, messageId: data.id}).subscribe();
      this.messageCount--;
      data.status = 1;
    }
    // 跳转页面值消息详情
    this.navPage.emit({userName: 'list', path: '/message/view/' + data.id});
  }

  loadMessage(): void {
    this.messagePageNum++;
    this.getMessageList();
  }

  handleKeyCancel(): void {
    this.isKeyVisible = false;
  }

  handleOk(): void {
    this.isVisible = false;
    this.help.post("/accounts/updateCurrentRole", {roleId: this.nowRole}).pipe(map((res: any) => {
      if (res.success) {
        document.cookie = "jwt=" + res.token;
        this.router.navigate(["/home"]).then(d => {
          window.location.reload();
        });
      }
    })).subscribe();
  }

  handleKeyOk(): void {
    if (!this.validateKeyForm.valid) {
      this.message.error('请填写完相关信息!');
      return;
    }
    this.help.post("/accounts/updatePassword", this.validateKeyForm.value).subscribe((res: any) => {
        if (res.success) {
          this.message.success('修改密码成功，重新登陆生效！');
          this.isKeyVisible = false;
        } else {
          this.message.error(res.msg);
        }
      },
      error => {
        this.message.error(error.error.msg);
      }
    );
  }

  saveTheme() {
    localStorage.setItem('theme', this.theme);
    this.themeFlag = false;
  }

  showChat() {
    this.msgFlag = true;
    // this.chatroom.sendOneMsg();
  }

  sendMsgs() {
    this.chatroom.sendMsg();
  }

  // 修改未读信息
  checkUnLook(num: number) {
    this.unReadMessageNum = num;
  }

  private repeat(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      if (this.validateKeyForm == null || this.validateKeyForm.value == null || control.value == null || control.value.length == 0) {
        return null;
      }
      return control.value != this.validateKeyForm.value.newPassword ? {repeat: {value: control.value}} : null;
    };
  }
}
