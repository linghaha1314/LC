## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `hasMsg` | 新消息标识 | *boolean* | - | `true` `false` |
| `userInfo` | 用户信息 | *object* | - | object |

## userInfo 参数
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `name` | 用户名称 | *string* | - | any string |
| `icon` | 图标 | *string* | - | any string |
| `router` | 路由菜单 | *string* | - | string |
