import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {BaseService} from "./base.service";


export class BaseListComponent<T> {
  label = 'name';
  allChecked = false;
  list: T[] = [];
  total = 0;
  pageIndex = 1;
  pageSize = 10;
  loading = false;
  queryParams: any = {name: null};
  auth: any = {};

  protected constructor(
    public modal: NzModalService,
    public service: BaseService<T>,
    public message: NzMessageService) {
    this.auth = this.service.getAuth();
  }

  reloadData() {
    this.loading = true;
    this.service.queryParams = this.queryParams;
    this.service.refreshData().subscribe(d => {
      if (d) {
        this.getData();
      }
    });
  }

  getData() {
    this.loading = true;
    this.service.queryParams = this.queryParams;
    this.service.getData()
      .subscribe(data => {
        this.loading = false;
        this.list = data.list;
        this.total = data.total;
        this.refreshChecked();
      }, ({error}) => {
        this.loading = false;
        this.message.error(`请求出现错误: ${error.msg}`);
      });
  }

  searchData(search: boolean = false): void {
    if (search) {
      this.pageIndex = 1;
    }
    this.service.changeNum(this.pageIndex, this.pageSize);
    this.getData();
  }


  deleteById(id) {
    this.loading = true;
    this.service.deleteById(id).subscribe(res => {
      this.loading = false;
      if (res.success) {
        this.message.success('删除成功!');
        this.searchData();
      }
    }, error => {
      this.loading = false;
    });
  }

  refreshChecked(): void {
    if (this.list.length > 0) {
      const allChecked = this.list.every((value: any) => value._checked === true);
      this.allChecked = allChecked;
    } else {
      this.allChecked = false;
    }
  }

  checkAll(value: boolean): void {
    this.list.forEach((data: any) => {
      data._checked = value;
    });
    this.refreshChecked();
  }

  showDeleteConfirm(): void {
    const deleteData = [], names = [];
    this.list.forEach((data: any) => {
      if (data._checked && this.deleteBefore(data)) {
        deleteData.push({id: data.id});
        names.push(data[this.label]);
      }
    });
    if (deleteData.length == 0) {
      this.message.error('请至少选择一条可以删除的数据!');
      return;
    }
    this.modal.confirm({
      nzTitle: '确认删除吗?',
      nzContent: `将删除<b>[${names.join(',')}]</b>数据!`,
      nzOkText: '确认',
      nzOkType: 'danger',
      nzOnOk: () => {
        this.service.deleteAll(deleteData).subscribe(res => {
          if (res.success) {
            this.message.success('删除成功!');
            this.searchData();
          }
        });
      },
      nzCancelText: '取消'
    });
  }

  deleteBefore(row: any): boolean {
    return true;
  }

}
