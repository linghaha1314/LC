import {FormGroup} from '@angular/forms';
import {Location} from '@angular/common';
import {NzMessageService} from 'ng-zorro-antd/message';
import {BaseService} from "./base.service";

export class BaseEditComponent<T> {
  validateForm: FormGroup;
  isLoading = true;

  protected constructor(public location: Location, public service: BaseService<T>, public message: NzMessageService) {
  }

  submitForm(back: boolean = true) {
    this.isLoading = true;
    this.service.saveOrUpdateData(this.validateForm.value).subscribe(res => {
      if (res.success) {
        this.saveSuccess(res.data);
        this.service.refreshData().subscribe(d => {
          if (d) {
            this.message.success('保存成功!');
            this.isLoading = false;
            if (back) {
              this.location.back();
            } else {
              this.validateForm.reset();
            }
          }
        });
      }
    }, error => {
      this.isLoading = false;
    });
  }

  back() {
    this.location.back();
  }

  // 保存成功后传入数据处理
  saveSuccess(data: T) {

  }
}
