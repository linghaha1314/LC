import { Observable, of } from 'rxjs';
import { map, timestamp } from 'rxjs/operators';
import { Help } from "../../utils/Help";

export abstract class BaseService<T> {
  flag = false;
  pageSize = 10;
  pageNum = 1;
  queryParams: any = {};
  data = {
    list: [],
    total: 0
  };

  protected abstract url: {
    listByPage: string,
    insert: string,
    update: string,
    delete: string,
    deleteAll: string
  };

  protected constructor(public help: Help) {
  }

  getData(): Observable<any> {
    if (this.flag) {
      return of(this.data);
    } else {
      return this.help.post(this.url.listByPage, { ...this.queryParams, pageSize: this.pageSize, pageNum: this.pageNum })
        .pipe(map((res: any) => {
          this.flag = true;
          this.data = {
            list: res.rows,
            total: res.total
          };
          return this.data;
        }));
    }
  }

  refreshData(): Observable<boolean> {
    this.flag = false;
    return this.getData().pipe(map(() => {
      return true;
    }));
  }

  getDataById(id: string) {
    if (this.data.list.length == 0) {
      return this.help.post(this.url.listByPage, { id: id })
        .pipe(map((res: any) => {
          if (res.rows.length > 0) {
            return res.rows[0];
          } else {
            return null;
          }
        }));
    } else {
      return of(this.data.list).pipe(
        map((list: T[]) => list.find(data => data['id'] === id))
      );
    }
  }

  changeNum(page: number, size: number) {
    this.flag = false;
    this.pageNum = page;
    this.pageSize = size;
  }

  saveOrUpdateData(data: T): Observable<any> {
    let url = this.url.insert;
    if (data['id']) {
      url = this.url.update;
    }
    return this.help.post(url, data).pipe(map((res: any) => {
      return res;
    }));
  }

  deleteById(id: string): Observable<any> {
    return this.help.post(this.url.delete, { id }).pipe(map((res: any) => {
      return res;
    }));
  }

  deleteAll(list: T[]): Observable<any> {
    return this.help.post(this.url.deleteAll, list).pipe(map((res: any) => {
      return res;
    }));
  }

  // 获取基本权限
  getAuth(): any {
    return this.help.getMenuAuth();
  }
}
