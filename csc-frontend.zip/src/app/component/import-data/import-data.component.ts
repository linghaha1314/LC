import {Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {ImportColumns, ImportConfig} from "./import-data";
import {BaseListComponent} from "../base/base-list.component";
import {NzMessageService} from 'ng-zorro-antd/message';
import {NzModalService} from 'ng-zorro-antd/modal';
import {ImportDataService} from "./import-data.service";
import {formatDate, Location} from "@angular/common";
import {ImportBoxComponent} from "../form/importbox/import-box.component";
import * as XLSX from "xlsx";
import {addDays} from "date-fns";

@Component({
  selector: 'import-data',
  templateUrl: './import-data.component.html',
  styleUrls: ['./import-data.component.scss']
})
export class ImportDataComponent extends BaseListComponent<any> implements OnInit {

  @Input()
  config: ImportConfig;

  loadFlag = false;

  loadMsg = '处理中...';

  empty = false;

  rows: any[] = [];

  url: string;

  template: string;

  links = {};

  validateUrl: string;

  columns: ImportColumns[] = [];

  extraParams: any = {};

  errorData: any = {};

  editValue: any = {};

  editor: any = {row: null, field: null};

  editPopVisible: any = {};

  scrollY = 500;

  nowColumn: ImportColumns = {text: null, field: null, editor: {type: "string"}};

  visible = false;

  modalValue: any[] = [];

  modalKey: any = {};

  errorInputMsg: string[] = [];

  private editorValue: any;

  nowError: string;

  importFlag = false;

  validateFlag = false;

  successFlag = false;

  successMsg: string;

  @ViewChild('importBox', {read: ImportBoxComponent})
  importBox: ImportBoxComponent;

  constructor(public modal: NzModalService, private elementRef: ElementRef, public service: ImportDataService, public message: NzMessageService, private location: Location) {
    super(modal, service, message);
  }

  ngOnInit(): void {
    this.scrollY = this.elementRef.nativeElement.parentElement.offsetHeight - 180;
    this.config = this.config ?? this.location.getState() as ImportConfig;
    if (this.config['url'] == null) {
      this.empty = true;
      return;
    }
    const {url, validateUrl, template, columns, extraParams} = this.config;
    this.url = url;
    this.validateUrl = validateUrl;
    this.template = template;
    this.columns = columns;
    this.extraParams = extraParams;
    const link: any = {};
    columns.forEach(c => {
      link[c.field] = c.text;
    });
    this.links = link;
  }

  back() {
    this.location.back();
  }

  showData(data: any[]) {
    const dateFields = [];
    this.config.columns.forEach(d => {
      if (d.editor.type == 'date') {
        dateFields.push(d.field);
      }
    });
    data.forEach((d, i) => {
      d['_index'] = i;
      dateFields.forEach(c => {
        if (d[c] != null && d[c] instanceof Date) {
          d[c] = formatDate(addDays(d[c], 1), 'yyyy-MM-dd', 'zh');
        }
      });
    });
    this.rows = data;
    if (this.validateUrl == null) {
      return;
    }
    this.importFlag = false;
    this.editValue = {};
    this.errorData = {};
    this.nowError = null;
    this.loadMsg = '数据验证中...';
    this.loadFlag = true;
    let list = [];
    if (this.extraParams != null) {
      data.forEach(r => {
        list.push({...this.extraParams, ...r});
      });
    } else {
      list = data;
    }
    this.service.validateData(this.validateUrl, list).subscribe(res => {
      this.loadFlag = false;
      if (res.success) {
        this.errorData = res.data;
        this.changeErrorTotal();
        this.validateFlag = true;
        this.sortErrorRows();
      }
    }, () => {
      this.loadFlag = false;
      this.validateFlag = false;
      this.message.error("数据验证出错,无法导入,请稍后再试!");
    });
  }

  hasError(a: string[], obj) {
    if (a == null) {
      return false;
    }
    return a.includes(obj);
  }

  getColumns(field: string): ImportColumns {
    let column = null;
    this.columns.some(c => {
      if (c.field == field) {
        column = c;
        return true;
      }
    });
    return column;
  }

  completeData(val) {
    if (this.rows[this.editor.row][this.editor.field] === val) {
      this.message.error("请修改后再保存!");
      return;
    }
    const {editor} = this.nowColumn;
    this.errorInputMsg.length = 0;
    let v: any;
    if (val instanceof Array) {
      if (val == null || val.length == 0) {
        return;
      }
      const list = [];
      val.forEach(r => {
        list.push(r[editor.valueKey]);
      });
      v = list.join(',');
    } else {
      if (val == null || (val + '').trim().length == 0) {
        this.errorInputMsg.push('请输入值!');
        return;
      }
      let minFlag = false, maxFlag = false;
      if (editor.type == 'string') {
        if (editor.min != null && val.trim().length < editor.min) {
          minFlag = true;
          this.errorInputMsg.push(`输入长度必须大于或等于${editor.min}`);
        }
        if (editor.max != null && val.trim().length > editor.max) {
          maxFlag = true;
          this.errorInputMsg.push(`输入长度必须小于或等于${editor.max}`);
        }
      }
      if (editor.type == 'number') {
        if (editor.min != null && val < editor.min) {
          minFlag = true;
          this.errorInputMsg.push(`输入数字必须大于或等于${editor.min}`);
        }
        if (editor.max != null && val > editor.max) {
          maxFlag = true;
          this.errorInputMsg.push(`输入数字必须小于或等于${editor.max}`);
        }
      }
      if (minFlag || maxFlag) {
        return;
      }
      v = (val + '').trim();
    }
    this.rows[this.editor.row][this.editor.field] = v;
    if (this.hasError(this.errorData[this.editor.row], this.editor.field)) {
      this.editValue[this.editor.row + '-' + this.editor.field] = true;
    }
    this.editPopVisible[this.editor.row + '-' + this.editor.field] = false;
    this.changeErrorTotal();
  }

  setNowEditor(f: boolean, row: number, field, type: string = 'combo', value: any = null) {
    this.errorInputMsg.length = 0;
    if (f) {
      this.editorValue = value;
      this.nowColumn = this.getColumns(field);
      this.editor = {row, field};
    }
    if (type === 'multiple') {
      this.visible = true;
      const list: any[] = [];
      const keys: any = {};
      if (value != null) {
        value.split(',').forEach(r => {
          const a: any = {};
          a[this.nowColumn.editor.valueKey] = r;
          keys[r] = true;
          list.push(a);
        });
      }
      this.modalValue = list;
      this.modalKey = keys;
      this.queryParams = this.nowColumn.editor.queryParams;
      this.service.changeParams(this.nowColumn.editor.queryParams);
      this.service.changeUrl(this.nowColumn.editor.url);
      this.searchData();
    }
  }

  selectModal(val) {
    let flag = false;
    this.modalValue.some(r => {
      if (r[this.nowColumn.editor.valueKey] == val[this.nowColumn.editor.valueKey]) {
        flag = true;
        return true;
      }
    });
    if (flag === false) {
      this.modalKey[val[this.nowColumn.editor.valueKey]] = true;
      this.modalValue.push(val);
    }
  }

  removeModalValue(index) {
    const val = this.modalValue[index][this.nowColumn.editor.valueKey];
    this.modalKey[val] = false;
    this.modalValue.splice(index, 1);
  }

  saveEditValue() {
    if (this.modalValue.length == 0) {
      this.message.error('请至少选择一条数据!');
      return;
    }
    this.visible = false;
    this.completeData(this.modalValue);
  }

  changeErrorTotal() {
    let all = 0, change = Object.keys(this.editValue).length;
    for (const key in this.errorData) {
      all = all + this.errorData[key].length;
    }
    const total = all - change;
    if (total > 0) {
      this.nowError = `未处理的错误数量:${all - change}`;
    } else {
      this.nowError = null;
    }
  }

  importData() {
    this.loadMsg = '数据导入中...';
    this.loadFlag = true;
    let list: any[] = [];
    if (this.extraParams != null) {
      this.rows.forEach(r => {
        list.push({...this.extraParams, ...r});
      });
    } else {
      list = this.rows;
    }
    this.importBox.saveData(list);
  }

  readFile() {
    this.loadMsg = '文件内容读取中...';
    this.loadFlag = true;
  }

  importAfter({data, msg}) {
    this.loadFlag = false;
    this.importFlag = true;
    if (data.length == 0) {
      this.successMsg = msg;
      this.successFlag = true;
    }
  }

  selectFile() {
    this.importBox.selectFile();
  }

  downloadTemplate() {
    if (this.template == null) {
      // 根据现有字段导出模板
      const exportData = [];
      const dataList = this.columns;
      const data = {};
      dataList.forEach(s => {
        data[s.text] = "";
      });
      exportData.push(data);
      // 数据导出
      const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
      /* generate workbook and add the worksheet */
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, '导入模板');
      /* save to file */
      XLSX.writeFile(wb, '导入模板.xlsx');
    } else {
      this.importBox.downloadTemplate();
    }
  }

  sortErrorRows() {
    const list = [];
    const data = [...this.rows];
    const newErrData = {};
    Object.keys(this.errorData).forEach((k, i) => {
      list.push({...this.rows[k]});
      delete data[k];
      newErrData[i] = this.errorData[k];
    });
    data.forEach((d) => {
      list.push(d);
    });
    list.forEach((d, i) => {
      d['_index'] = i;
    });
    this.rows = list;
    this.errorData = newErrData;
  }
}
