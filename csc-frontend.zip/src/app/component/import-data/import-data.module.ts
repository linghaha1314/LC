import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {ImportDataComponent} from "./import-data.component";
import {ImportDataRoutingModule} from "./import-data-routing.module";
import {NzSpaceModule} from "ng-zorro-antd/space";
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { NzProgressModule } from 'ng-zorro-antd/progress';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzTypographyModule } from 'ng-zorro-antd/typography';
import {FormsModule} from "@angular/forms";
import {ImportBoxModule} from "../form/importbox/import-box.module";
import {FormComboModule} from "../form/combobox/form-combo.module";
import {ImportDataService} from "./import-data.service";
import {LoadStatusModule} from "../load-status/load-status.module";
import {FormDateModule} from "../form/datebox/form-date.module";
import {FormTimeModule} from "../form/timebox/form-time.module";
import {FormNumberModule} from "../form/numberbox/form-number.module";
import {NzGridModule} from "ng-zorro-antd/grid";

@NgModule({
  declarations: [ImportDataComponent],
  exports: [ImportDataComponent],
    imports: [
        CommonModule,
        FormsModule,
        ImportDataRoutingModule,
        NzSpaceModule,
        NzButtonModule,
        NzIconModule,
        NzModalModule,
        NzTableModule,
        NzDropDownModule,
        NzPopoverModule,
        NzProgressModule,
        ImportBoxModule,
        FormComboModule,
        NzInputModule,
        NzTagModule,
        LoadStatusModule,
        NzInputNumberModule,
        NzRadioModule,
        NzCheckboxModule,
        FormDateModule,
        FormTimeModule,
        NzAlertModule,
        NzTypographyModule,
        NzEmptyModule,
        FormNumberModule,
        NzGridModule
    ],
  providers: [ImportDataService]
})
export class ImportDataModule {
}
