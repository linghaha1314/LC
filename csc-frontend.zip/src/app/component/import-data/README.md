## 使用说明

```html
<button nz-button nzType="dashed" routerLink="/import" [state]="importConfig"><i nz-icon nzType="upload"></i>数据导入</button>
```
其中`importConfig`如下
```ts
importConfig: ImportConfig = {
    url: '/sections/importSections',
    template: '/xlsx/sections.xls',
    validateUrl: '/sections/validateData',
    columns: [
      {field: 'name', text: '科室名称', editor: {type: "string", min: 2, max: 5, require: true}},
      {field: 'code', text: '编码', editor: {type: "string"}},
      {field: 'sort', text: '序号', editor: {type: "number", min: 2, max: 5}},
      {field: 'parentName', text: '父级', editor: {type: "combo", valueKey: "name", url: "/sections/listQueryByPage"}},
      {field: 'status', text: '状态', editor: {type: "radio", sources: ["是", "否"]}},
      {field: 'tags', text: '标签', editor: {type: "check", sources: ["内科学", "外科学", "骨科"]}},
      {field: 'date', text: '日期', editor: {type: "date"}},
      {field: 'time', text: '时间', editor: {type: "time"}},
    ]
  }
```
类型指定为`ImportConfig`
- `url`: 数据导入接口,错误返回参考原来import-box组件
- `template`: 导入模板下载路径
- `extraParams`: 导入的额外参数
- `validateUrl`: 验证接口,默认传入`Array<any>`格式数据,接口需返回格式如下:
```
{
    0: ['sectionName'],
    1: ['majorName'],
    2: ['typeName']
}
```
表示第几条数据的那几个field出现了错误
- columns: 数据导入相关列, 具体类型参考import-data.ts文件,editor不同type配置参考如下:
```js
[
   {field: 'name', text: '科室名称', editor: {type: "string", min: 2, max: 5, require: true}},
   {field: 'sort', text: '序号', editor: {type: "number", min: 2, max: 5}},
   {field: 'parentName', text: '父级', editor: {type: "combo", valueKey: "name", url: "/sections/listQueryByPage"}},
   {field: 'status', text: '状态', editor: {type: "radio", sources: ["是", "否"]}},
   {field: 'tags', text: '标签', editor: {type: "check", sources: ["内科学", "外科学", "骨科"]}},
   {field: 'date', text: '日期', editor: {type: "date"}},
   {field: 'time', text: '时间', editor: {type: "time"}},
   {
      field: 'majorName',
      text: '专业',
      editor: {
        type: "multiple",
        valueKey: "name",
        url: '/staff/listQueryByPage',
        columns: [
          {name: 'name', label: '姓名'},
          {name: 'sectionName', label: '科室名称'},
          {name: 'mobile', label: '电话号码'},
        ]
      }
   },
]
```
