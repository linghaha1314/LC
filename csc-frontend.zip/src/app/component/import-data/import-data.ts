export declare type ColumnEditorType = 'combo' | 'multiple' | 'string' | 'number' | 'radio' | 'check' | 'date' | 'time';

export class Columns {
  label: string;
  name: string;
}

export class ColumnEditor {
  type: ColumnEditorType;
  min?: number;
  max?: number;
  precision?: number;
  url?: string;
  require?: boolean;
  queryParams?: any;
  valueKey?: string;
  columns?: Columns[];
  sources?: string[];
  mode?: string;
}

export class ImportColumns {
  field: string;
  text: string;
  editor: ColumnEditor;
}

export class ImportConfig {
  url: string;
  template: string;
  columns: ImportColumns[];
  validateUrl: string;
  extraParams?: any;
}
