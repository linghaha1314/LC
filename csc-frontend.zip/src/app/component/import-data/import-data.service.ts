import {Injectable} from "@angular/core";
import {BaseService} from "../base/base.service";
import {Help} from "../../utils/Help";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ImportDataService extends BaseService<any> {
  protected url = {
    listByPage: '/majors/listQueryByPage',
    insert: null,
    update: null,
    delete: null,
    deleteAll: null
  };

  constructor(help: Help) {
    super(help);
  }

  changeUrl(listUrl: string) {
    this.url.listByPage = listUrl;
  }

  changeParams(params = {}) {
    this.queryParams = params;
  }

  validateData(path: string, data: any[]): Observable<any> {
    return this.help.post(path, data);
  }

}
