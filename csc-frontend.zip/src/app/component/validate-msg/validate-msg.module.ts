import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidateMsgComponent } from './validate-msg.component';



@NgModule({
  declarations: [ValidateMsgComponent],
  exports: [
    ValidateMsgComponent
  ],
  imports: [
    CommonModule
  ]
})
export class ValidateMsgModule { }
