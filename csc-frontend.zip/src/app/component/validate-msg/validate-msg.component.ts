import { Component, ContentChild, Input, OnInit, TemplateRef } from '@angular/core';
import { AbstractControl } from "@angular/forms";

@Component({
  selector: 'validate-msg',
  templateUrl: './validate-msg.component.html',
  styleUrls: ['./validate-msg.component.scss'],
})
export class ValidateMsgComponent implements OnInit {

  @Input()
  control: AbstractControl;

  @ContentChild(TemplateRef) templateRef: TemplateRef<any>;

  constructor() {
  }

  ngOnInit(): void {
  }

}
