import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LoadStatusComponent} from './load-status.component';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzResultModule } from 'ng-zorro-antd/result';
import { NzSpinModule } from 'ng-zorro-antd/spin';


@NgModule({
  declarations: [LoadStatusComponent],
  exports: [
    LoadStatusComponent
  ],
  imports: [
    CommonModule,
    NzSpinModule,
    NzResultModule,
    NzButtonModule,
    NzIconModule
  ]
})
export class LoadStatusModule {
}
