import {Component, EventEmitter, Input, OnInit, Output, TemplateRef} from '@angular/core';
import {Location} from "@angular/common";

@Component({
  selector: 'load-status',
  templateUrl: './load-status.component.html'
})
export class LoadStatusComponent implements OnInit {

  @Input()
  load = false;

  @Input()
  empty = false;

  @Input()
  msg = '处理中...';

  @Input()
  success = false;

  @Input()
  successTitle: string | TemplateRef<void>;

  @Input()
  successSubTitle: string | TemplateRef<void>;

  @Output()
  back = new EventEmitter();

  @Output()
  successChange = new EventEmitter();

  constructor(private location: Location) {
  }

  ngOnInit(): void {
  }

  popRouter() {
    this.location.back();
  }

  continueClick() {
    this.success = false;
    this.successChange.emit(false);
  }

  backClick() {
    this.back.emit();
  }
}
