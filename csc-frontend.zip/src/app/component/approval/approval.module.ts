import {NgModule} from "@angular/core";
import {ApprovalComponent} from "./approval.component";
import {NzFormModule} from 'ng-zorro-antd/form';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzModalModule} from 'ng-zorro-antd/modal';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {ReactiveFormsModule} from "@angular/forms";
import {ValidateMsgModule} from "../validate-msg/validate-msg.module";
import {CommonModule} from "@angular/common";


@NgModule({
  declarations: [ApprovalComponent],
  exports: [ApprovalComponent],
  imports: [
    NzModalModule,
    NzGridModule,
    NzRadioModule,
    ReactiveFormsModule,
    ValidateMsgModule,
    CommonModule,
    NzFormModule,
    NzInputModule
  ]
})
export class ApprovalModule {

}
