import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {NzMessageService} from "ng-zorro-antd/message";
import {Help} from "../../utils/Help";

@Component({
  selector: 'approval-modal',
  template: `
    <nz-modal [(nzVisible)]="isVisible" [nzTitle]="title" (nzOnCancel)="handleCancel()" (nzOnOk)="handleOk()"
              [nzOkLoading]="loading">
      <form nz-form [formGroup]="validateForm" *ngIf="validateForm != null">
        <nz-form-item>
          <nz-form-label [nzSm]="6" [nzXs]="24" nzRequired>是否同意</nz-form-label>
          <nz-form-control [nzSm]="14" [nzXs]="24">
            <nz-radio-group formControlName="status">
              <label nz-radio nzValue="0">同意</label>
              <label nz-radio nzValue="1">不同意</label>
            </nz-radio-group>
            <validate-msg [control]="validateForm.get('status')"></validate-msg>
          </nz-form-control>
        </nz-form-item>
        <nz-form-item>
          <nz-form-label [nzSm]="6" [nzXs]="24">审批意见</nz-form-label>
          <nz-form-control [nzSm]="14" [nzXs]="24">
            <textarea nz-input formControlName="opinion"></textarea>
            <validate-msg [control]="validateForm.get('opinion')"></validate-msg>
          </nz-form-control>
        </nz-form-item>
      </form>
    </nz-modal>
  `,
})

export class ApprovalComponent implements OnInit {

  loading = false;
  @Input()
  isVisible = false;
  @Output()
  isVisibleChange = new EventEmitter();
  @Input()
  entity: string;
  @Input()
  params: {
    id: string,
    key: string,
    taskId: string,
    processInstanceId: string
  };
  @Input()
  listParams: [
    {
      id: string,
      key: string,
      taskId: string,
      processInstanceId: string
    }
  ];
  @Input()
  url: string;
  @Input()
  title = "审批";
  @Output()
  onBefore = new EventEmitter();
  @Output()
  onAfter = new EventEmitter();
  validateForm: FormGroup;

  constructor(private fb: FormBuilder, private message: NzMessageService, private help: Help) {
  }

  handleCancel() {
    this.isVisible = false;
    this.isVisibleChange.emit(this.isVisible);
  }

  handleOk() {
    this.onBefore.emit(this.validateForm);
    // 提交信息
    if (!this.validateForm.valid) {
      this.message.error("请填写完表单!");
    } else {
      this.loading = true;
      const data = {
        status: this.validateForm.value.status,
        opinion: this.validateForm.value.opinion,
        entity: this.entity
      };
      let params;
      if (this.listParams != null) {// 批量提交
        const list = [];
        this.listParams.forEach(item => {
          list.push({...item, ...data});
        });
        params = list;
      } else {// 单次提交
        params = {...this.params, ...data};
      }

      this.help.post(this.url, params).subscribe((res: any) => {
        this.loading = false;
        if (res.success) {
          this.message.success("审核成功!");
          this.isVisible = false;
          this.isVisibleChange.emit(this.isVisible);
          this.onAfter.emit(res);
        }
      },error => {
        this.loading = false;
        this.isVisible = false;
        this.isVisibleChange.emit(this.isVisible);
        this.onAfter.emit(null);
      });
    }
  }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      status: [null, [Validators.required]],
      opinion: [null, [Validators.maxLength(200)]],
    });
  }

}
