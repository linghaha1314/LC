import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {SelectStaffComponent} from "./select-staff.component";
import {NzPageHeaderModule} from "ng-zorro-antd/page-header";
import {NzSpaceModule} from "ng-zorro-antd/space";
import {FormComboModule} from "../form/combobox/form-combo.module";
import {FormsModule} from "@angular/forms";
import {DataSelectModule} from "../data-select/data-select.module";
import {NzPopconfirmModule} from "ng-zorro-antd/popconfirm";
import {NzButtonModule} from "ng-zorro-antd/button";
import {SelectStaffRoutingModule} from "./select-staff-routing.module";
import {LoadStatusModule} from "../load-status/load-status.module";


@NgModule({
  declarations: [SelectStaffComponent],
  exports: [
    SelectStaffComponent
  ],
    imports: [
        CommonModule,
        NzPageHeaderModule,
        NzSpaceModule,
        FormComboModule,
        FormsModule,
        DataSelectModule,
        NzPopconfirmModule,
        NzButtonModule,
        SelectStaffRoutingModule,
        LoadStatusModule
    ]
})
export class SelectStaffModule {
}
