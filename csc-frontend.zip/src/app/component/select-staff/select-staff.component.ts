import {Component, Input, ViewChild} from '@angular/core';
import {Help} from "../../utils/Help";
import {NzMessageService} from "ng-zorro-antd/message";
import {Location} from "@angular/common";
import {DataSelectComponent} from "../data-select/data-select.component";

@Component({
  selector: 'select-staff',
  templateUrl: './select-staff.component.html',
})
export class SelectStaffComponent {

  @Input()
  config: { id: string, key: string, entity: string, url: string, params?: any };

  rows: any[] = [];

  isLoading = false;

  staffType = [
    {id: 'Roles', name: '角色', key: 'roleId'},
    {id: 'Classes', name: '班级', key: 'classesId'},
    {id: 'Sections', name: '科室', key: 'sectionId'},
    {id: 'Majors', name: '专业', key: 'majorId'},
  ];

  type: string;

  mainId: string;

  linkKey: string;

  entity: string;

  queryUrl: string;

  queryParams: any = {};

  params: any;

  @ViewChild('staffSelect', {read: DataSelectComponent}) select: DataSelectComponent;

  constructor(private help: Help, private msg: NzMessageService, private location: Location) {
    const data: any = this.config ?? this.location.getState();
    this.mainId = data.id;
    this.linkKey = data.key;
    this.entity = data.entity;
    this.queryUrl = data.url;
    this.params = data.params || {};
    this.initData();
  }

  initData() {
    const d = {...this.params};
    d[this.linkKey] = this.mainId;
    this.help.post(this.queryUrl, d).subscribe(({rows}) => {
      const list = [];
      rows.forEach(r => {
        list.push({id: r.staffId, name: r.staffName});
      });
      this.rows = list;
    });
  }

  changeParams() {
    this.select.getData();
  }

  saveStaff(type: 'default' | 'all' = 'default') {
    if (type === 'default' && this.rows.length === 0) {
      this.msg.error('请选择人员后再进行保存');
      return;
    }
    const result: any = {...this.params};
    result[this.linkKey] = this.mainId;
    const list = [];
    if (type === 'all') {
      list.push({staffId: 'staffId', ...result});
    } else {
      this.rows.forEach(r => {
        list.push({staffId: r.id, ...result});
      });
    }
    const data = {
      entity: this.entity,
      data: list,
      params: this.queryParams,
      type,
      delete: {key: this.linkKey, value: result[this.linkKey]}
    };
    this.isLoading = true;
    this.help.post('/staff/saveStaffToOther', data).subscribe(res => {
      if (res.success) {
        if (type === 'all') {
          this.msg.success('保存成功!');
        } else {
          this.msg.success('保存成功!');
        }
        this.isLoading = false;
        this.initData();
      }
    });
  }

  removeAll() {
    this.isLoading = true;
    this.help.post('/staff/deleteSelectStaff', {entity: this.entity, delete: {key: this.linkKey, value: this.mainId}}).subscribe(res => {
      if (res.success) {
        this.msg.success('删除成功!');
        this.isLoading = false;
      }
    });
  }
}
