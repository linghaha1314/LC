import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {SelectStaffComponent} from "./select-staff.component";


const routes: Routes = [
  {path: '', component: SelectStaffComponent, data: {title: '设置人员'}},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SelectStaffRoutingModule {
}
