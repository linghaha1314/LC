import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ChatRoomComponent} from './chat-room.component';
import {NzAvatarModule} from 'ng-zorro-antd/avatar';
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzInputModule} from 'ng-zorro-antd/input';
import {NzLayoutModule} from 'ng-zorro-antd/layout';
import {NzMenuModule} from 'ng-zorro-antd/menu';
import {NzPopoverModule} from 'ng-zorro-antd/popover';
import {NzRadioModule} from 'ng-zorro-antd/radio';
import {NzMessageServiceModule} from 'ng-zorro-antd/message';
import {FroalaEditorModule} from "../form/froala-editor/froala-editor.module";
import {FormsModule} from "@angular/forms";


@NgModule({
  declarations: [ChatRoomComponent],
  exports: [
    ChatRoomComponent
  ],
  imports: [
    CommonModule,
    NzLayoutModule,
    FroalaEditorModule,
    NzMenuModule,
    NzIconModule,
    NzPopoverModule,
    NzAvatarModule,
    FormsModule,
    NzMessageServiceModule,
    NzBadgeModule,
    NzRadioModule,
    NzInputModule
  ]
})
export class ChatRoomModule {
}
