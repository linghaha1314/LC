import {
  AfterViewChecked,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  Renderer2,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import {webSocket} from "rxjs/webSocket";
import {Help} from "../../utils/Help";
import { NzMessageService } from 'ng-zorro-antd/message';

@Component({
  selector: 'app-chat-room',
  templateUrl: './chat-room.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [
      `
      p {
        padding: 0 !important;
        margin: 0 !important;;
      }

      :host {
        text-align: center;
      }

      nz-header {
        border-bottom: 1px solid rgb(231, 231, 231);
        height: 60px;
        line-height: 60px;
        text-align: center;
      }

      nz-footer {
        height: 248px;
        padding: 0 !important;
      }

      nz-sider {
        text-align: left;
      }

      nz-content {
        height: 319px;
      }

      #content-box {
        height: 319px;
        box-sizing: border-box;
        overflow: auto;
        padding: 12px 30px;
      }

      nz-layout {
        margin-bottom: 48px;
        width: 845px;
        height: 627px;
        overflow: hidden;
      }

      nz-layout:last-child {
        margin: 0;
      }

      .people {
      }

      .input-text {
        height: 248px;
        overflow: auto;
      }

      .chat-box {
        display: flex;
        margin-bottom: 24px;
      }

      .msg-box {
        min-height: 1.2em;
        padding: 4px 12px;
        border-radius: 8px;
        margin: 0 12px;
        box-shadow: 1px 2px 5px 0 rgba(65, 64, 64, 0.75);
        -webkit-box-shadow: 1px 2px 5px 0 rgba(65, 64, 64, 0.75);
        -moz-box-shadow: 1px 2px 5px 0 rgba(65, 64, 64, 0.75);
      }
      img{
        max-width: 500px;
      }
      .re {
        flex-direction: row-reverse;
      }

      .greed {
        color: #87d068;
      }

      .cent {
        text-align: center;
      }
      .look-line{
        position: absolute;
        right: 18px;
        top: 70px;
        font-size: 30px;
      }
      .mb{
        margin-bottom: 12px;
      }
      .my-avatar{
        width: 32px;
        height: 32px;
        border-radius: 16px;
        background: rgba(188,188,188,.8);
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 14px;
        color: #fff;
      }
      .times{
        text-align: center;
      }
    `
  ]
})
export class ChatRoomComponent implements AfterViewChecked {
  mode = false;
  dark = false;
  menus = [];
  groupMenus = [];
  msgBox: any[] = [];
  msgText: string;
  ws: any;
  categoryId: string;
  categoryGroupId: string;
  receiverIds = ''; // 接收信息人id
  self: string; // 当前人id
  userName: string; // 用户名
  onLineNum: number; // 在线人数
  currentIndex: number; // 当前选中
  currentGroup: number; // 当前选中
  chatType = 'chat'; // 单聊还是群聊
  whoChat: string; // 当前聊天
  groupId = ''; // 组id
  groupLine: any[];
  totalUnread = 0; // 未读消息总数
  thisAvatar: any;
  selfAvatar: any;
  constructor(
    private http: Help,
    private el: ElementRef,
    private renderer: Renderer2,
    private message: NzMessageService
  ) {
  }

  @Input() isstaffId: string;
  @Input() isChange: boolean;
  @Output() getUnLook = new EventEmitter();

  @ViewChild('contentbox') contentbox: ElementRef;
  @ViewChild('msgbox') msgbox: ElementRef;

  ngOnInit(): void {
    // this.harting()
  }

  ngAfterViewChecked(): void {

  }
  // 连接ws
  clientWs(url) {
    // 1.建立连接
    this.ws = webSocket(url);
    // 2.连接后操作
    this.ws.subscribe(
      msg => { // 服务器发消息时的回调
        this.getMsgForUse(msg);
      }, // 连接返回消息
      err => {
        this.message.error('服务器出错,正在重连....');
        // this.clientWs(url); // 重连
      }, // 连接出错
      () => {
        this.message.error('已断开连接!');
      } // 连接关闭
    );
  }
  // 处理获取到的消息
  getMsgForUse(msg){
    if (msg.chatType === 'system') { // 公用的
      if (msg.type === 'line') {
        this.menus.forEach(item => {
          if (item.id === msg.staffId){
            item.status = msg.status;
          }
        });
        const arr: any[] = [];
        this.menus.forEach((ite, index) => {
          if (ite.status === 1){
            arr.push(ite);
            this.menus.splice(index, 1);
          }
        });
        this.onLineNum = arr.length;
        this.menus = [...arr, ...this.menus];
        this.message.success(msg.content);
      }
    } else if (msg.chatType === 'chat') { // 单人聊天
      if (msg.type === 'chatLog') { // 聊天记录
        this.msgBox = msg.content;
        this.scrollToBottom();
      } else if (msg.type === 'person') { // 个人消息
        if (this.receiverIds === msg.senderId) {
          this.msgBox.push(msg);
          this.scrollToBottom();
        }else{
          this.menus.forEach(item => {
            if (item.id === msg.senderId){
              item.unReadMessage++;
              this.totalUnread++;
              this.putTotal(this.totalUnread);
            }
          });
        }
        this.scrollToBottom();
      }
    } else { // 群聊
      if (msg.type === 'line'){
        this.message.success(msg.content);
      }else if (msg.type === 'groupMessage'){
        if (this.groupId === msg.groupId) {
          this.msgBox.push(msg);
          this.scrollToBottom();
        }else{
          this.groupMenus.forEach(group => {
            if (group.groupId === msg.groupId){
              group.totalUnreadMessage++;
              this.totalUnread++;
              this.putTotal(this.totalUnread);
            }
          });
        }
      }else if (msg.type === 'groupDetail'){
        this.groupLine = msg.content;
      }else if (msg.type === 'chatLog'){
        this.msgBox = msg.content;
        this.scrollToBottom();
      }
    }
  }
  // 发送消息
  sendMsg() {
    if (this.msgText !== ''){
      const obj: any = {
        title: this.chatType === 'chat' ? '单人聊天' : '群聊',
        categoryId: this.chatType === 'chat' ? this.categoryId : this.categoryGroupId,
        content: this.msgText,
        senderId: this.self, // (当前人staffId)
        senderName: this.userName,
        status: 1,
        hospitalId: localStorage.getItem('hospitalId'),
        receiverIds: this.receiverIds, // （接收人staffId）
        isRead: false,
        chatType: this.chatType,
        groupIds: this.groupId
      };
      this.ws.next(obj);
      obj.created = this.nowTimeFormat();
      this.msgBox.push(obj);
      this.scrollToBottom();
      this.msgText = ''; // 设置空值
    }else {
      this.message.error('不能发送空消息!');
    }
  }
  // 建立ws连接
  getWs(staffId, userName, avatar) {
    const host = window.location.host;
    this.self = staffId;
    this.userName = userName;
    this.selfAvatar = avatar;
    const url = 'ws://' + host + '/chat';
    this.clientWs(url); // 建立单人聊天通道
    this.getMsgType(); // 获取类型
    // this.getFriendList(); // 获取联系人列表
  }
  // 滚动到底部
  scrollToBottom(): void {
    try {
      this.el.nativeElement.querySelector('#content-box').scrollTop = this.el.nativeElement.querySelector('#msg-box').scrollHeight;
    } catch (err) {
    }
  }
  // 点击好友
  checkFriend(f, index) {
    this.currentIndex = index;
    this.receiverIds = f.id;
    this.whoChat = f.name;
    this.thisAvatar = f.avator;
    this.totalUnread = this.totalUnread - f.unReadMessage;
    this.putTotal(this.totalUnread);
    f.unReadMessage = 0;
    this.groupId = '';
    this.scrollToBottom();
    this.currentGroup = null;
    this.sendOneMsg(); // 发送确认信息
  }
  // 点击组
  checkGroup(f, index) {
    this.currentIndex = index;
    this.receiverIds = f.groupId;
    this.whoChat = f.groupName;
    this.groupId = f.groupId;
    this.msgBox = [];
    this.totalUnread = this.totalUnread - f.totalUnreadMessage;
    this.putTotal(this.totalUnread);
    f.totalUnreadMessage = 0;
    this.scrollToBottom();
    this.sendOneMsg(); // 发送确认信息
  }
  // 获取聊天类型
  getMsgType() {
    this.http.post('/dictionarydata/listQueryByTypeCode/ChatType', {}).subscribe(res => {
      res.rows.forEach(item => {
        if (item.code == 'singleChat') {
          this.categoryId = item.id;
        }
        if (item.code == 'groupChat') {
          this.categoryGroupId = item.id;
        }
      });
    });
  }
  // 断开ws
  closeWs() {
    // this.ws.complete();
  }
  // 发送确认信息
  sendOneMsg() {
    // send
    const obj = {
      title: this.chatType === 'chat' ? '单人聊天' : '群聊',
      categoryId: this.chatType === 'chat' ? this.categoryId : this.categoryGroupId,
      senderId: this.self, // (当前人staffId)
      hospitalId: localStorage.getItem('hospitalId'),
      receiverIds: this.receiverIds, // （接收人staffId）
      isRead: true,
      chatType: this.chatType,
      groupIds: this.groupId
    };
    this.ws.next(obj);
    this.scrollToBottom();
  }
  // 返回姓
  getName(str){
    const arr = str.split('');
    return arr[0];
  }
  // 心跳
  harting(){
    const emty = {
      chatType: 'hart'
    };
    setInterval(() => {
      this.ws.next(emty);
    }, 1000 * 60 * 2);
  }
  // 获取好友列表
  getFriendList(){
    this.http.get(`/socket/getChatStaffList/${this.self}`).subscribe(res => {
      this.groupMenus = res.groupList;
      this.menus = res.staffList; // 获取人员列表
      this.totalUnread = res.totalUnreadMessage;
      this.putTotal(this.totalUnread); // 显示总条数
      // if (this.receiverIds === '') {
      //   this.receiverIds = this.menus[0].id;
      //   this.whoChat = this.menus[0].name;
      // }
    });
  }
  // 更新父级总条数
  putTotal(num){
    this.getUnLook.emit(num); // 显示总条数
  }
  // 拼接当前时间
  nowTimeFormat(time?){
    const date = time ? new Date(time) : new Date();
    const seperator1 = "/";
    const seperator2 = ":";
    let month: any = date.getMonth() + 1;
    let strDate: any = date.getDate();
    if (month >= 1 && month <= 9) {
      month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = "0" + strDate;
    }
    return date.getFullYear() + seperator1 + month + seperator1 + strDate
      + " " + date.getHours() + seperator2 + date.getMinutes()
      + seperator2 + date.getSeconds();
  }
}
