import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {FlowComponent} from "./flow.component";
import {NzBadgeModule} from 'ng-zorro-antd/badge';
import {NzEmptyModule} from 'ng-zorro-antd/empty';
import {NzTableModule} from 'ng-zorro-antd/table';
import {FlowRoutingModule} from "./flow-routing.module";

@NgModule({
  declarations: [FlowComponent],
  exports: [FlowComponent],
  imports: [
    CommonModule,
    NzTableModule,
    NzBadgeModule,
    FlowRoutingModule,
    NzEmptyModule,
  ],
})
export class FlowModule {

}
