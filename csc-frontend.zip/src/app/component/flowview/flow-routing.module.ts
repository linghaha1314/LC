import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {FlowComponent} from "./flow.component";


const routes: Routes = [
  {path: ':id', component: FlowComponent, data: {title: '审核记录'}},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FlowRoutingModule {
}
