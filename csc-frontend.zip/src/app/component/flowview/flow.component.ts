import {Component, ElementRef, Input, OnInit, ViewChild} from "@angular/core";
import * as BpmnJS from 'bpmn-js/dist/bpmn-navigated-viewer.production.min.js';
import {Help} from "../../utils/Help";
import {ActivatedRoute, ParamMap} from "@angular/router";

@Component({
  selector: 'flow-view',
  template: `
    <div #flow style="background: rgba(255,255,255,0.2);width: 100%;" [ngStyle]="{height: height + 'px'}"></div>
    <div *ngIf="_empty;then emptyTemplate else hasTemplate"></div>
    <ng-template #emptyTemplate>
      <nz-empty nzNotFoundContent="未提交流程审核无内容" nzNotFoundImage="./assets/images/empty.svg"></nz-empty>
    </ng-template>
    <ng-template #hasTemplate>
      <nz-table #flowTable [nzData]="rows" [nzPaginationPosition]="false">
        <thead>
        <tr>
          <th>审核步骤</th>
          <th>审核人</th>
          <th>是否同意</th>
          <th>审核意见</th>
          <th>审核日期</th>
        </tr>
        </thead>
        <tbody>
        <tr *ngFor="let data of flowTable.data">
          <td>{{data.taskName}}</td>
          <td>{{data.auditStaffName}}</td>
          <td>
            <ng-template [ngIf]="data.status == 0">
              <nz-badge nzStatus="processing" nzText="同意"></nz-badge>
            </ng-template>
            <ng-template [ngIf]="data.status == 1">
              <nz-badge nzStatus="warning" nzText="不同意"></nz-badge>
            </ng-template>
          </td>
          <td *ngIf="data.opinion == null || data.opinion == 'null' || data.opinion == ''">无</td>
          <td *ngIf="data.opinion != null && data.opinion != 'null' && data.opinion != ''">{{data.opinion}}</td>
          <td>{{data.created}}</td>
        </tr>
        </tbody>
      </nz-table>
    </ng-template>
  `,
  styleUrls: ['./flow.component.scss']
})

export class FlowComponent implements OnInit {

  @Input()
  instanceId: string;

  @ViewChild('flow')
  flow: ElementRef;

  rows: any[];

  title = "审核详情";

  height = 200.0;

  canvas: any;

  _empty = true;

  constructor(private help: Help, private route: ActivatedRoute) {
  }

  ngOnInit(): void {
    if (this.help.isEmpty(this.instanceId)) {
      this.route.paramMap.subscribe((params: ParamMap) => {
        this.instanceId = params.get('id');
        this.getData();
      });
    } else {
      this.getData();
    }
  }

  getData() {
    this.help.post('/activity/getDataInfo', {instanceId: this.instanceId}).subscribe(({content, finish, list, complete}) => {
      this.rows = list;
      if (content) {
        this._empty = false;
        const xml = content;
        if (xml == null || xml.trim().length == 0) {
          return;
        }
        const viewer = new BpmnJS({
          container: this.flow.nativeElement
        });
        try {
          viewer.importXML(xml).then(({warnings}) => {
            this.canvas = viewer.get('canvas');
            this.title = this.canvas.getRootElement()["businessObject"].name;
            const zoom = this.canvas.zoom('fit-viewport', 'center');
            this.height = this.height / zoom;
            setTimeout(() => {
              this.canvas.resized();
              this.canvas.zoom('fit-viewport', 'center');
            }, 0);
            const cacheActive = {};
            finish.forEach(f => {
              const type = f.activityType, taskId = f.taskId, activityId = f.activityId;
              if (type.indexOf('Event') > -1) {
                this.canvas.addMarker(activityId, 'highlight');
                cacheActive[activityId] = true;
              } else {
                if (taskId != null && taskId.trim().length > 0) {
                  this.canvas.addMarker(activityId, 'highlight');
                  cacheActive[activityId] = true;
                }
              }
            });
            const elementRegistry = viewer.get('elementRegistry');
            finish.forEach(f => {
              const activityShape = elementRegistry.get(f.activityId);
              const outgoing = activityShape.outgoing;
              outgoing.forEach(line => {
                if (cacheActive[line.target.id]) {
                  this.canvas.addMarker(line.id, 'highlight');
                  const outgoingGfx = elementRegistry.getGraphics(line.id).children[0].children[0];
                  const url = outgoingGfx.style.markerEnd, markId = url.substring(6, url.length - 2);
                  if (document.getElementById(markId + "-active") == null) {
                    const mark: any = document.getElementById(markId).cloneNode(true);
                    mark.id = markId + "-active";
                    mark.classList.add("light-line");
                    document.getElementById(markId).parentElement.appendChild(mark);
                  }
                  outgoingGfx.style.markerEnd = `url("#${markId + "-active"}")`;
                }
              });
            });
          });
        } catch (err) {
          console.log('error rendering', err);
        }
      } else {
        this.height = 0;
      }
    });
  }

}
