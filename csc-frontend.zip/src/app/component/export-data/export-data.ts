import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {NzMessageService} from "ng-zorro-antd/message";
import {Help} from "../../utils/Help";
import {HttpHeaders} from "@angular/common/http";

@Component({
  selector: 'export-data',
  template: `
    <button [title]="title" nz-button nz-popconfirm (nzOnConfirm)="export()" nzPopconfirmTitle="确认按当前查询条件导出数据吗？" nzOkText="确认"
            nzCancelText="取消" nzType="default" [nzLoading]="loading"><i nz-icon nzType="export"></i>{{title}}</button>`,
})

export class ExportData implements OnInit {

  constructor(private message: NzMessageService, private help: Help) {
  }

  @Input()
  title = "导出数据";

  @Input()
  docTitle = "导出数据文件";

  @Input()
  url;

  @Input()
  suffix = ".xlsx";

  @Input()
  params = {};

  @Input()
  loading = false;

  @Output()
  loadingChange = new EventEmitter();

  ngOnInit(): void {

  }

  export() {
    this.changeLoading(true);
    this.help.post(this.url, this.params, {
      responseType: "blob",
      headers: new HttpHeaders().append("Content-Type", "application/json")
    }).subscribe(data => {
      if (data.type == 'application/json') {
        this.handlerResponseError(data);
      } else {
        this.downloadFile(data);
        this.changeLoading(false);
      }
    }, error => {
      if (error.error.type == 'application/problem+json') {
        this.handlerResponseError(error.error);
      }else{
        this.message.error("导出数据出错！请联系管理员");
        this.changeLoading(false);
        this.handlerResponseError(error.error);
      }
    });
  }

  downloadFile(data) {
    const blob = new Blob([data]);
    const url = window.URL.createObjectURL(blob);
    // 以动态创建a标签进行下载
    const link = document.createElement('a');
    link.href = url;
    // a.download = fileName;
    link.setAttribute('download', this.docTitle + this.suffix);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  handlerResponseError(data) {
    const _this = this;
    const fileReader = new FileReader();
    fileReader.onload = function() {
      try {
        if (typeof fileReader.result === "string") {
          const jsonData = JSON.parse(fileReader.result);
          _this.message.error(jsonData.msg);
          _this.changeLoading(false);
        }
      } catch (err) { // 解析成对象失败，说明是正常的文件流
      }
    };
    fileReader.readAsText(data);
  }

  changeLoading(boolean = false){
    this.loading = boolean;
    this.loadingChange.emit(this.loading);
  }
}
