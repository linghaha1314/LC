## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `title` | 按钮标题 | *string* | `导出数据` | - |
| `loading` | 加载状态 | *boolean* | `false` | true false |
| `docTitle` | 导出的文件的标题 | *string* | `导出数据文件` | - |
| `url` | 必填 | *导出接口* | - | - |
| `params` | 参数，选填 | *Object* | {} | - |

## 使用示例
```
<export-data url="/xxx/xx" docTitle="库房物资" [(loading)]="loading" [params]="queryParams"></export-data>
```
  
