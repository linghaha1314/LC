import {AfterViewInit, Component, ElementRef, Input, ViewChild} from '@angular/core';
import Chart from 'chart.js';

export declare type chartType = 'bar' | 'pie' | 'line';

@Component({
  selector: 'graph-statistics',
  templateUrl: './graph-statistics.component.html',
  styleUrls: [],
})
export class GraphStatisticsComponent implements AfterViewInit {

  private _chartFormat: chartType = 'bar';

  @ViewChild("chart")
  chartElement: ElementRef;

  private chart: Chart;

  @Input()
  title: string;

  @Input()
  label: string;

  @Input()
  changeFlag = true;

  @Input()
  height: string = '300px';

  @Input()
  width: string;

  private _dataList: Array<{ name: string, total: number }> = [];

  colorList = [
    "#7A9887",
    "#7C79AE",
    "#96ACA3",
    "#B7D7D7",
    "#859091",
    "#AFC4E5",
    "#5D58A5",
    "#949BA6",
    "#AFC4E5",
    "#B18B58"
  ];

  @Input()
  set chartFormat(format: chartType) {
    this._chartFormat = format;
    this.changeFormat();
  }

  get chartFormat(): chartType {
    return this._chartFormat;
  }

  @Input()
  set dataList(dataList: Array<{ name: string, total: number }>) {
    this._dataList = dataList;
    this.initStatistics();
  }

  get dataList(): Array<{ name: string, total: number }> {
    return this._dataList;
  }

  ngAfterViewInit(): void {
    this.initStatistics();
  }

  changeFormat() {
    this.chart?.destroy();
    this.chart = null;
    this.initStatistics();
  }

  initStatistics() {
    if (this.chartElement == null || this.dataList == null) {
      return;
    }
    const labels = this.dataList.map(s => s.name);
    const total = this.dataList.map(s => s.total);
    const colors = this.getColors(labels);
    if (this.chart == null) {
      this.chart = new Chart(this.chartElement.nativeElement, {
        type: this.chartFormat,
        data: {
          labels: labels,
          datasets: [
            {
              label: this.label,
              data: total,
              backgroundColor: colors,
              borderColor: colors,
              fill: false,
              borderWidth: 2
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          layout: {
            padding: {
              left: 10,
              right: 10,
              top: 10,
              bottom: 10
            }
          }
        },
      });
    } else {
      this.chart.config.data = {
        labels: labels,
        datasets: [
          {
            label: this.label,
            data: total,
            backgroundColor: colors,
            borderColor: colors,
            fill: false,
            borderWidth: 2
          }
        ]
      };
      this.chart.chart.update();
    }
  }

  getOptions() {
    switch (this.chartFormat) {
      case "bar":
        return {};
      case "line":
        return {};
      default:
        return {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        };
    }
  }

  getColors(labels: any[]) {
    const colors = [];
    labels.forEach((item, index) => {
      colors.push(this.colorList[index % this.colorList.length]);
    });
    return colors;
  }

}
