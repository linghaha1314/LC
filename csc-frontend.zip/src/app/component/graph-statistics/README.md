## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `height` | 统计图高度 | *number* | 400 |  |
| `width` | 统计图宽度 | *number* | 400 |  |
| `title` | 统计图标题 | *String* | 无 | |
| `lable` | 统计值 | *String* | 无 |  |
| `chartFormat` | 默认展示格式 | *String* | bar |`bar` `pie` `line`
| `dataList` | 数据源必须符合 [{name:'',total:1}]格式 | *List* | [] |

更多参数请访问 https://www.chartjs.org/docs/latest/general/options.html
## 事件
| 名称 | 说明 | 参数 |
| :----: | :---- | :-----: 
| `chartClick` | 点击数据块事件 | 事件对象
| `onHover` | 鼠标移入数据块时触发 | 事件对象

## 错误返回说明
返回结果中data为错误的数据，每一条错误信息需要在每一条返回数据中加上msg字段


采用属性方法的写法实现,传入参数就是要保存的数据类型为:`any[]`<br/>
返回需要返回的类型为:`Observable<any[]>`
