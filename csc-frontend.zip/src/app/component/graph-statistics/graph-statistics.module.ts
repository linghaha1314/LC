import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {GraphStatisticsComponent} from './graph-statistics.component';
import {NzRadioModule} from "ng-zorro-antd/radio";
import {FormsModule} from "@angular/forms";


@NgModule({
  declarations: [GraphStatisticsComponent],
  exports: [
    GraphStatisticsComponent
  ],
  imports: [
    CommonModule,
    NzRadioModule,
    FormsModule,
  ]
})
export class GraphStatisticsModule {
}
