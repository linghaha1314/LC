## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `status` | 状态 | *int* | null | "" |
| `taskStatus` | flowStatus | *int* | null | "" |

