import {Component, Input} from "@angular/core";

export declare type ActivityType = 'apply' | 'audit';

@Component({
  selector: 'approval-status',
  template: `
    <div *ngIf="type == 'apply';then applyTemplate else auditTemplate"></div>
    <ng-template #applyTemplate>
      <nz-tag nzColor="success" *ngIf="status == 2">已审核</nz-tag>
      <nz-tag nzColor="error" *ngIf="status == 1">已驳回</nz-tag>
      <nz-tag nzColor="default" *ngIf="status == null ">待提交</nz-tag>
      <nz-tag nzColor="processing" *ngIf="status == 0"><i nz-icon nzType="sync" nzSpin></i><span>审核中</span></nz-tag>
    </ng-template>
    <ng-template #auditTemplate>
      <nz-tag nzColor="success" *ngIf="status == 2">已审核</nz-tag>
      <nz-tag nzColor="processing" *ngIf="status == 0 && taskStatus == 1">您已审核</nz-tag>
      <nz-tag nzColor="error" *ngIf="status == 1">已驳回</nz-tag>
      <nz-tag nzColor="default" *ngIf="status == null ">待提交</nz-tag>
      <nz-tag nzColor="warning" *ngIf="status == 0 && (taskStatus == 0 || taskStatus == null)">待您审核</nz-tag>
    </ng-template>`,
})

export class ApprovalStatusComponent {

  @Input()
  status: any;

  @Input()
  taskStatus: any;

  @Input()
  type: ActivityType = 'audit';
}
