import {NgModule} from "@angular/core";
import {ApprovalStatusComponent} from "./approval.component";
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTagModule } from 'ng-zorro-antd/tag';
import {CommonModule} from "@angular/common";

@NgModule({
  declarations: [ApprovalStatusComponent],
  exports: [ApprovalStatusComponent],
    imports: [
        NzTagModule,
        CommonModule,
        NzIconModule
    ]
})
export class ApprovalStatusModule {

}
