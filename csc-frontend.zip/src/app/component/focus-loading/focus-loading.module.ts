import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FocusLoadingComponent} from './focus-loading.component';
import {NzSpinModule} from "ng-zorro-antd/spin";

@NgModule({
  declarations: [FocusLoadingComponent],
  exports: [
    FocusLoadingComponent
  ],
  imports: [
    CommonModule,
    NzSpinModule,
  ]
})
export class FocusLoadingModule {
}
