import {Component, ElementRef, Input, Renderer2, ViewChild} from '@angular/core';
import {
  slideInDownAnimation,
  slideInLeftAnimation,
  slideInRightAnimation,
  slideInUpAnimation,
  slideOutDownAnimation,
  slideOutLeftAnimation,
  slideOutRightAnimation,
  slideOutUpAnimation
} from "angular-animations";
import {IAnimationOptions} from "angular-animations/common/interfaces";

const config: IAnimationOptions = {duration: 200};

@Component({
  selector: 'focus-loading',
  templateUrl: 'focus-loading.component.html',
  styleUrls: ['focus-loading.component.scss'],
  animations: [
    slideInLeftAnimation(config),
    slideInRightAnimation(config),
    slideInDownAnimation(config),
    slideInUpAnimation(config),
    slideOutLeftAnimation(config),
    slideOutRightAnimation(config),
    slideOutDownAnimation(config),
    slideOutUpAnimation(config),
  ]
})
export class FocusLoadingComponent {

  @ViewChild('focus')
  focus: ElementRef;

  @ViewChild('left')
  left: ElementRef;

  @ViewChild('right')
  right: ElementRef;

  @ViewChild('top')
  top: ElementRef;

  @ViewChild('bottom')
  bottom: ElementRef;

  @ViewChild('center')
  center: ElementRef;

  private _loading = false;

  _spin = false;

  get loading(): boolean {
    return this._loading;
  }

  @Input()
  set loading(value: boolean) {
    this._loading = value;
    this.changeLoading();
  }

  constructor(private renderer2: Renderer2) {
  }

  changeLoading() {
    if (this.focus == null || this.focus.nativeElement == null) {
      return;
    }
    if (this._loading) {
      this.showLoading();
    } else {
      setTimeout(() => {
        this._spin = false;
        setTimeout(() => {
          this.hideLoading();
        }, 200);
      }, 1000);
    }
  }

  showLoading() {
    const div = this.focus.nativeElement;
    // left
    this.renderer2.setStyle(this.left.nativeElement, 'width', div.getBoundingClientRect().left + 'px');
    this.renderer2.setStyle(this.left.nativeElement, 'height', '100%');
    this.renderer2.setStyle(this.left.nativeElement, 'top', '0px');
    this.renderer2.setStyle(this.left.nativeElement, 'left', '0px');
    // right
    this.renderer2.setStyle(this.right.nativeElement, 'width', (document.body.offsetWidth - div.getBoundingClientRect().left - div.offsetWidth) + 'px');
    this.renderer2.setStyle(this.right.nativeElement, 'height', '100%');
    this.renderer2.setStyle(this.right.nativeElement, 'top', '0px');
    this.renderer2.setStyle(this.right.nativeElement, 'right', '0px');
    // top
    this.renderer2.setStyle(this.top.nativeElement, 'width', div.offsetWidth + 'px');
    this.renderer2.setStyle(this.top.nativeElement, 'height', div.getBoundingClientRect().top + 'px');
    this.renderer2.setStyle(this.top.nativeElement, 'top', '0px');
    this.renderer2.setStyle(this.top.nativeElement, 'left', div.getBoundingClientRect().left + 'px');
    // bottom
    this.renderer2.setStyle(this.bottom.nativeElement, 'width', div.offsetWidth + 'px');
    this.renderer2.setStyle(this.bottom.nativeElement, 'height', (document.body.offsetHeight - div.getBoundingClientRect().top - div.offsetHeight) + 'px');
    this.renderer2.setStyle(this.bottom.nativeElement, 'top', (div.getBoundingClientRect().top + div.offsetHeight) + 'px');
    this.renderer2.setStyle(this.bottom.nativeElement, 'left', div.getBoundingClientRect().left + 'px');
    // center
    this.renderer2.setStyle(this.center.nativeElement, 'width', div.offsetWidth + 'px');
    this.renderer2.setStyle(this.center.nativeElement, 'height', div.offsetHeight + 'px');
    this.renderer2.setStyle(this.center.nativeElement, 'top', div.getBoundingClientRect().top + 'px');
    this.renderer2.setStyle(this.center.nativeElement, 'left', div.getBoundingClientRect().left + 'px');
    this._spin = true;
  }

  hideLoading() {
    const list = [this.left, this.top, this.bottom, this.center];
    this.renderer2.setStyle(this.right.nativeElement, 'width', '0px');
    this.renderer2.setStyle(this.right.nativeElement, 'height', '0px');
    this.renderer2.setStyle(this.right.nativeElement, 'top', '0px');
    this.renderer2.setStyle(this.right.nativeElement, 'right', '0px');
    list.forEach(r => {
      this.renderer2.setStyle(r.nativeElement, 'width', '0px');
      this.renderer2.setStyle(r.nativeElement, 'height', '0px');
      this.renderer2.setStyle(r.nativeElement, 'top', '0px');
      this.renderer2.setStyle(r.nativeElement, 'left', '0px');
    });
  }


}
