import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ExcelTableComponent} from "./excel-table.component";
import {HotTableModule} from "@handsontable/angular";

@NgModule({
  declarations: [ExcelTableComponent],
  exports: [ExcelTableComponent],
  imports: [
    CommonModule,
    HotTableModule
  ]
})
export class ExcelTableModule {
}
