import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {Help} from "../../utils/Help";
import Handsontable from "handsontable";
import "handsontable/languages/zh-CN.js";
import {HotTableComponent} from "@handsontable/angular";
import {map} from "rxjs/operators";
import {of} from 'rxjs';
import CellRange = Handsontable.wot.CellRange;
import Settings = Handsontable.mergeCells.Settings;
import {CustomDateEditor} from "./custom-editor";

@Component({
  selector: 'excel-table',
  template: `
    <hot-table #excel licenseKey="4d522-5237a-55f42-6653a-d1494"
               language="zh-CN"
               [settings]="tableSettings"
               [data]="dataset">
    </hot-table>`,
  styles: []
})
export class ExcelTableComponent implements OnInit {

  @Input()
  private menuConfig = {};

  @ViewChild("excel")
  private excel: HotTableComponent;

  tableSettings: Handsontable.GridSettings = {
    viewportColumnRenderingOffset: 27,
    viewportRowRenderingOffset: "auto",
    allowInsertColumn: true,
    allowInsertRow: true,
    allowRemoveColumn: false,
    allowRemoveRow: true,
    allowInvalid: true,
    autoWrapRow: true,
    autoWrapCol: true,
    stretchH: "all",
    height: 'auto',
    manualRowResize: true,
    manualColumnResize: true,
    mergeCells: [],
    afterMergeCells: (cellRange: CellRange, mergeParent: Settings, auto: boolean) => {
      this.changeMergeCell(cellRange);
    },
    afterUnmergeCells: (cellRange: CellRange, auto: boolean) => {
      this.changeMergeCell(cellRange, false);
    },
    afterSetCellMeta: (row: number, col: number, key: string, value: any) => {
      console.log(`row:${row} col:${col} ${key} == ${value}`);
    },
    afterRemoveCellMeta: (row: number, col: number, key: string, value: any) => {
      console.log(`row:${row} col:${col} ${key} == ${value}`);
    },
    rowHeaders: true,
    columns: [
      {
        type: 'autocomplete',
        source: ['BMW', 'Chrysler', 'Nissan', 'Suzuki', 'Toyota', 'Volvo'],
        strict: false
      },
      {
        editor: 'select',
        selectOptions: ['BMW', 'Chrysler', 'Nissan', 'Suzuki', 'Toyota', 'Volvo'],
      },
    ],
    colHeaders: ["ID"],
    dropdownMenu: true,
    afterInit() {
      // this.setCellMeta(1, 1, 'className', 'htCenter');
      // this.setCellMeta(1, 1, 'readOnly', true);
      // this.render();
    }
  };

  dataset = [{}];

  mergeCells: Array<Settings> = [];

  constructor(private help: Help) {
    this.help.loadCss('./assets/handsontable/handsontable.full.min.css').subscribe();
  }

  ngOnInit(): void {
    this.tableSettings.contextMenu = {
      items: {
        ...this.menuConfig,
        row_above: {},
        row_below: {},
        remove_row: {},
        '---------': {},
        clear_column: {},
        undo: {},
        redo: {},
        cut: {},
        copy: {},
        make_read_only: {},
        alignment: {},
        mergeCells: {},
      }
    };
    Handsontable.editors.registerEditor("date", CustomDateEditor);
  }

  changeMergeCell(cellRange: CellRange, flag: boolean = true) {
    let toCol = cellRange.to.col, toRow = cellRange.to.row;
    let fromCol = cellRange.from.col, fromRow = cellRange.from.row;
    if (toCol < 0) { toCol = 0; }
    if (toRow < 0) { toRow = 0; }
    if (fromCol < 0) { fromCol = 0; }
    if (fromRow < 0) { fromRow = 0; }
    const mergeCell: Settings = {
      col: fromCol,
      colspan: (toCol - fromCol) + 1,
      row: fromRow,
      rowspan: (toRow - fromRow) + 1
    };
    if (flag) {
      this.mergeCells.push(mergeCell);
    } else {
      of(this.mergeCells).pipe(map(r => r.filter(d => d.col != mergeCell.col || d.colspan != mergeCell.colspan || d.row != mergeCell.row || d.rowspan != mergeCell.rowspan))).subscribe(r => {
        this.mergeCells = r;
      });
    }
  }

  updateSettings(settings) {
    this.excel.updateHotTable(settings);
  }

  getSetting() {
    // 获取列
    const columns = this.excel.settings.columns;
    // 获取数据
    const data = this.dataset;
    // 获取合并情况
    const mergeCells = this.excel.settings.mergeCells;
    // 获取单元格属性配置
    console.log(data);
    console.log(columns);
    console.log(mergeCells);
  }

}
