import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {formatDate} from "@angular/common";

@Component({
  selector: 'range-picker',
  templateUrl: './range-picker.component.html',
  styles: [],
})
export class RangePickerComponent implements OnInit {

  date = null;

  @Input()
  format = "yyyy-MM-dd";
  @Input()
  placeHolder = "";
  @Input()
  startKey = "";
  @Input()
  endKey = "";
  @Input()
  queryParams = {};
  @Output()
  queryParamsChange = new EventEmitter();
  @Output()
  change = new EventEmitter();

  ngOnInit(): void {
  }

  changeDate(result: Date[]) {
    this.setParamsData(result, this.startKey, this.endKey);
    this.queryParamsChange.emit(this.queryParams);
    this.change.emit();
  }

  setParamsData(result: Date[], startKey, endKey) {
    if (result.length == 0) {
      this.queryParams[startKey] = null;
      this.queryParams[endKey] = null;
    } else {
      this.queryParams[startKey] = this.formatDate(result[0], 0, 0, 0);
      this.queryParams[endKey] = this.formatDate(result[1], 23, 59, 59);
    }
  }

  formatDate(date, hours, minutes, seconds) {
    date.setHours(hours);
    date.setMinutes(minutes);
    date.setSeconds(seconds);
    return formatDate(date, 'yyyy-MM-dd HH:mm:ss', 'zh');
  }

}
