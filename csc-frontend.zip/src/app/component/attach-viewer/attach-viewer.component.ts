import {Component, Input} from '@angular/core';
import {DomSanitizer, SafeHtml} from "@angular/platform-browser";
import {HttpClient} from "@angular/common/http";
import {Observable, of} from "rxjs";
import {map} from "rxjs/operators";
import {Buffer} from "buffer";

export declare type ShowType = 'card' | 'tab' | 'link' | 'list';
declare const BASE_URL: string;

@Component({
  selector: 'attach-viewer',
  templateUrl: './attach-viewer.component.html',
  styleUrls: ['./attach-viewer.component.scss']
})
export class AttachViewerComponent {

  @Input()
  type: ShowType = 'card';  //tab,card,link  三种类型

  _iframeHeight: String = '580px';

  private _list: any[] = [];

  get list(): any[] {
    return this._list;
  }

  @Input()
  set iframeHeight(height: String) {
    this._iframeHeight = height;
    this._list = [...this._list];
    this.initViewer();
  }

  @Input()
  set list(value: any[]) {
    value.forEach(r => {
      r.fileName = this.getFileName(r.path);
      r.suffixName = r.fileName.split(".")[1];
      r.icon = this.$icon[r.suffixName];
      if (r.icon === undefined) {
        r.icon = 'file';
      }
    });
    this._list = value;
    this.initViewer();
  }

  private _value: string;

  get value(): string {
    return this._value;
  }

  @Input()
  set value(value: string) {
    this._value = value;
    if (value != null && value.trim().length > 0) {
      const rows: any[] = [];
      value.split(',').forEach(l => {
        rows.push({path: l});
      });
      if (rows.length > 0) {
        this.list = rows;
      }
    } else {
      this.list.length = 0;
    }
  }

  iframe: SafeHtml;

  $icon = {
    txt: "document",
    png: "image",
    jpeg: "image",
    jpg: "image",
    gif: "image",
    ico: "image",
    tif: "image",
    tiff: "image",
    psd: "image",
    psb: "image",
    ami: "image",
    apx: "image",
    bmp: "image",
    bpg: "image",
    brk: "image",
    cur: "image",
    dds: "image",
    dng: "image",
    exr: "image",
    fpx: "image",
    gbr: "image",
    img: "image",
    jbig2: "image",
    jb2: "image",
    jng: "image",
    jxr: "image",
    pbm: "image",
    pgf: "image",
    pic: "image",
    raw: "image",
    webp: "image",
    eps: "image",
    afphoto: "image",
    ase: "image",
    aseprite: "image",
    clip: "image",
    cpt: "image",
    heif: "image",
    heic: "image",
    kra: "image",
    mdp: "image",
    ora: "image",
    pdn: "image",
    reb: "image",
    sai: "image",
    tga: "image",
    xcf: "image",
    pdf: "pdf",
    xlsx: "table",
    xls: "table",
    csv: "table",
    tsv: "table",
    webm: "video",
    mkv: "video",
    flv: "video",
    vob: "video",
    ogv: "video",
    ogg: "video",
    gifv: "video",
    avi: "video",
    mov: "video",
    qt: "video",
    wmv: "video",
    yuv: "video",
    rm: "video",
    rmvb: "video",
    mp4: "video",
    m4v: "video",
    mpg: "video",
    mp2: "video",
    mpeg: "video",
    mpe: "video",
    mpv: "video",
    m2v: "video",
    doc: "word",
    docx: "word",
    rtf: "word",
    mp3: "audio",
    flac: "audio",
    m4a: "audio",
    wma: "audio",
    aiff: "audio",
  };

  $height = {
    video: "580px",
    image: "400px",
    table: "400px",
    word: "400px",
    audio: "515px",
    pdf: "500px",
    file: "400px",
    document: "auto"
  };

  _contentModal = false;

  _now: any = {};

  _url: string;

  _fileViewerServer: string;

  _fileViewerClient: string;

  height: string;

  constructor(private sanitizer: DomSanitizer, private http: HttpClient) {
  }

  getFileName(path: string): string {
    const source = path.split('/');
    return source[source.length - 1];
  }

  initViewer() {
    if (this.list && this.list.length > 0 && (this.type == 'tab' || this.type == 'link' || this.type == 'list')) {
      this.getFileViewer().subscribe(() => {
        this.list.forEach(r => {
          const u = encodeURIComponent(Buffer.from(this._fileViewerClient + r.path).toString('base64'));
          r._url = `${this._fileViewerServer}/onlinePreview?url=${u}`;
          r._iframe = this.sanitizer.bypassSecurityTrustResourceUrl(r._url);
        });
      });
    }
  }

  getFileViewer(): Observable<string> {
    if (this._fileViewerServer != null) {
      return of(this._fileViewerServer);
    }
    return this.http.get('/config/getFileViewer').pipe(map((d: any) => {
      this._fileViewerServer = d['fileServer'];
      this._fileViewerClient = d['fileClient'];
      return d;
    }));
  }

  showContent(r: any, modalFlag = false) {
    this._now = r;
    this.getFileViewer().subscribe(() => {
      const u = encodeURIComponent(Buffer.from(this._fileViewerClient + r.path).toString('base64'));
      this._url = `${this._fileViewerServer}/onlinePreview?url=${u}`;
      this.height = this.$height[r.icon];
      this.iframe = this.sanitizer.bypassSecurityTrustResourceUrl(this._url);
    });
    if (modalFlag) {
      this._contentModal = true;
    }
  }

  selectContent(i) {
    this.showContent(this.list[i]);
  }

  openWindow(url: string = this._url) {
    window.open(url);
  }

  downloadFile(r) {
    const elt = document.createElement('a');
    elt.setAttribute('href', BASE_URL + r.path);
    elt.setAttribute('download', r.fileName);
    elt.style.display = 'none';
    document.body.appendChild(elt);
    elt.click();
    document.body.removeChild(elt);
  }
}
