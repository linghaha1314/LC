import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AttachViewerComponent} from './attach-viewer.component';
import {NzButtonModule} from 'ng-zorro-antd/button';
import {NzCardModule} from 'ng-zorro-antd/card';
import {NzGridModule} from 'ng-zorro-antd/grid';
import {NzIconModule} from 'ng-zorro-antd/icon';
import {NzModalModule} from 'ng-zorro-antd/modal';
import {NzTabsModule} from 'ng-zorro-antd/tabs';
import {NzTypographyModule} from "ng-zorro-antd/typography";
import {NzListModule} from "ng-zorro-antd/list";


@NgModule({
  declarations: [AttachViewerComponent],
  exports: [
    AttachViewerComponent
  ],
  imports: [
    CommonModule,
    NzGridModule,
    NzCardModule,
    NzModalModule,
    NzButtonModule,
    NzTabsModule,
    NzIconModule,
    NzTypographyModule,
    NzListModule
  ]
})
export class AttachViewerModule {
}
