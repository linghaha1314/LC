import {Component, EventEmitter, Input, OnInit, Output} from "@angular/core";
import {Help} from "../../utils/Help";

@Component({
  selector: 'data-select',
  templateUrl: './data-select.component.html'
})

export class DataSelectComponent implements OnInit {

  private _url: string;

  private _queryParams: any = {};

  @Input()
  clearFlag = false;

  private _data: any[] = [];

  @Output()
  dataChange = new EventEmitter();

  @Output()
  clear = new EventEmitter();

  @Output()
  onLoad = new EventEmitter();

  @Input()
  height = '390px';

  get queryParams(): any {
    return this._queryParams;
  }

  @Input()
  set queryParams(value: any) {
    this.clearData();
    this._queryParams = value;
    this.getData();
  }

  get url(): string {
    return this._url;
  }

  @Input()
  set url(value: string) {
    this.clearData();
    this._url = value;
    this.getData();
  }

  get data(): any[] {
    return this._data;
  }

  @Input()
  set data(value: any[]) {
    this.cacheValue = {};
    this._data = value;
    if (value.length > 0) {
      value.forEach(v => {
        this.cacheValue[v[this.valueKey]] = true;
      });
      this.list = this.list.map(r => {
        if (this.cacheValue[r[this.valueKey]]) {
          return {
            ...r,
            _checked: false,
            _disabled: true
          };
        }
        return {
          ...r,
          _checked: false,
          _disabled: false
        };
      });
    } else {
      this.list = this.list.map(r => {
        return {
          ...r,
          _checked: false,
          _disabled: false
        };
      });
      this.refreshChecked();
    }
  }

  pageNum = 1;
  pageSize = 10;
  list = [];
  total = 0;
  loading = false;
  valueKey = 'id';
  labelKey = 'name';
  allChecked = false;
  sourceIndex = 0;
  sourceIndeterminate = false;
  cacheValue: any = {};
  targetFlag = false;
  targetEmpty = false;
  indeterminate = false;
  targetIndex = 0;
  targetSearch: string;
  loadIndex = 0;

  constructor(private help: Help) {
  }

  ngOnInit(): void {
    this.getData();
  }

  getData() {
    this.loading = true;
    this.help.post(this.url, {
      ...this.queryParams,
      pageSize: this.pageSize,
      pageNum: this.pageNum
    }).subscribe(({rows, total}) => {
      this.loadIndex++;
      rows.forEach(r => {
        if (this.cacheValue[r[this.valueKey]]) {
          r._disabled = true;
        }
      });
      this.list = rows;
      this.total = total;
      this.sourceIndex = 0;
      this.allChecked = false;
      this.sourceIndeterminate = false;
      this.loading = false;
      this.onLoad.emit(this.loadIndex);
    }, () => {
      this.loading = false;
    });
  }

  clearData() {
    this.loadIndex = 0;
    if (this.clearFlag) {
      setTimeout(() => {
        this.removeAll();
      }, 0);
    }
  }

  searchData() {
    this.changeNum(1, this.pageSize);
    this.getData();
  }

  changeNum(page: number, size: number) {
    this.pageNum = page;
    this.pageSize = size;
  }

  refreshChecked(): void {
    if (this.list.length > 0) {
      this.allChecked = this.list.every((value: any) => value._checked === true && value._disabled != true);
    } else {
      this.allChecked = false;
    }
    let index = 0;
    this.list.forEach(r => {
      if (r._checked === true && r._disabled != true) {
        index++;
      }
    });
    this.sourceIndex = index;
    this.sourceIndeterminate = index > 0 && index < this.list.length;
  }

  checkAll(value: boolean): void {
    this.list.forEach((data: any) => {
      if (data._disabled != true) {
        data._checked = value;
      }
    });
    this.refreshChecked();
  }

  change() {
    this.sourceIndex = 0;
    const list = [...this.data];
    this.list.forEach(r => {
      if (r._checked && r._disabled != true) {
        r._disabled = true;
        list.push({...r, _checked: false});
      }
    });
    list.forEach(r => {
      this.cacheValue[r[this.valueKey]] = true;
    });
    this.allChecked = false;
    this.data = list;
    this.dataChange.emit(this.data);
  }

  refreshSelectCheck() {
    let index = 0;
    this.data.forEach((value: any) => {
      if (value._checked === true) {
        index++;
      }
    });
    this.indeterminate = index > 0 && index < this.data.length;
    this.targetFlag = index > 0 && index == this.data.length;
    this.targetIndex = index;
  }

  checkAllTarget() {
    this.indeterminate = false;
    if (this.targetFlag) {
      this.targetIndex = this.data.length;
      this.data = this.data.map(item => {
        return {
          ...item,
          _checked: true
        };
      });
    } else {
      this.targetIndex = 0;
      this.data = this.data.map(item => {
        return {
          ...item,
          _checked: false
        };
      });
    }
  }

  remove() {
    const rows: any[] = [];
    this.data.forEach(r => {
      if (r._checked === true) {
        delete this.cacheValue[r[this.valueKey]];
      } else {
        rows.push(r);
      }
    });
    this.list = this.list.map(r => {
      if (this.cacheValue[r[this.valueKey]] === true) {
        return {
          ...r,
          _checked: false,
          _disabled: true
        };
      } else {
        return {
          ...r,
          _checked: false,
          _disabled: false
        };
      }
    });
    this.data = rows;
    this.refreshSelectCheck();
    this.dataChange.emit(this.data);
  }

  removeAll() {
    this.data.length = 0;
    this.targetIndex = 0;
    this.targetFlag = false;
    this.cacheValue = {};
    this.list = this.list.map(r => {
      return {
        ...r,
        _disabled: false
      };
    });
    this.refreshChecked();
    this.dataChange.emit(this.data);
    this.clear.emit();
  }

  searchTarget() {
    let index = 0;
    if (this.targetSearch) {
      this.data = this.data.map((r: any) => {
        const flag = r[this.labelKey].indexOf(this.targetSearch.trim()) < 0;
        if (flag) {
          index++;
        }
        return {
          ...r,
          _hide: flag
        };
      });
    } else {
      this.data = this.data.map((r: any) => {
        return {
          ...r,
          _hide: false
        };
      });
    }
    this.targetEmpty = index == this.data.length;
  }
}
