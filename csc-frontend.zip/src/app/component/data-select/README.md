## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `height` | 高度 | *string* | 390px | "" |
| `url` | 源数据接口(分页接口) | *string* | null | "" |
| `queryParams` | 查询参数 | *any* | {} | null |
| `clearFlag` | 更改url或queryParams是否清除已选择数据 | *boolean* | false | null |
| `data` | 选择结果 | *any[]* | [] | null |

