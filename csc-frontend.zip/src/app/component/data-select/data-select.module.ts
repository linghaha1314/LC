import {NgModule} from "@angular/core";
import {DataSelectComponent} from "./data-select.component";
import {CommonModule} from "@angular/common";
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzEmptyModule } from 'ng-zorro-antd/empty';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzListModule } from 'ng-zorro-antd/list';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzPopconfirmModule } from 'ng-zorro-antd/popconfirm';
import { NzSpinModule } from 'ng-zorro-antd/spin';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzTransferModule } from 'ng-zorro-antd/transfer';
import {FormsModule} from "@angular/forms";
import {NzSpaceModule} from "ng-zorro-antd/space";

@NgModule({
  declarations: [DataSelectComponent],
  exports: [DataSelectComponent],
  imports: [
    CommonModule,
    NzTransferModule,
    NzPaginationModule,
    NzTableModule,
    NzButtonModule,
    NzIconModule,
    NzListModule,
    NzCheckboxModule,
    FormsModule,
    NzSpaceModule,
    NzCardModule,
    NzInputModule,
    NzPopconfirmModule,
    NzSpinModule,
    NzEmptyModule
  ]
})
export class DataSelectModule {

}
