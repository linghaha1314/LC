## 属性
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `menusData` | 菜单数据 | *Array* | - | array |

## menusData 参数
| 属性 | 说明 | 类型 | 默认值 | 可选值 |
| :----: | :---- | :-----: | :----: | :----: |
| `name` | 名称 | *string* | - | any string |
| `icon` | 图标 | *string* | - | any string |
| `hasSubMenu` | 是否有子节点 | *boolean* | - | `true` `false` |
| `children` | 子节点数据格式就是menus参数 | *Array* | - | array |
| `router` | 路由菜单 | *string* | - | string |
