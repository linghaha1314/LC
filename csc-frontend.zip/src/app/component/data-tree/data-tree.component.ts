import {Help} from '../../utils/Help';
import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-data-tree',
  templateUrl: './data-tree.component.html',
})
export class DataTreeComponent {
  @Output()
  change = new EventEmitter();

  @Output()
  open = new EventEmitter();

  menus = [];

  load = false;

  logoFlag = false;

  constructor(private help: Help) {
  }

  reloadMenu(parentId: string) {
    this.load = true;
    this.logoFlag = false;
    this.getMenuData(parentId, null);
    this.help.get('/hospitalmenus/getAuthMenus/' + parentId).subscribe((d: any) => {
      if (d.success) {
        this.load = false;
        this.menus = this.compileMenuData(d.data, 0);
      }
    });
  }

  showLogo() {
    this.logoFlag = true;
  }

  // 统一获取数据
  getMenuData(parentId: string, menu?: any) {
    if (menu && menu.children.length > 0) {
      return;
    }
    if (menu) {
      menu.loading = true;
    }
    this.help.get('/hospitalmenus/getAuthMenus/' + parentId).subscribe((d: any) => {
      if (d.success) {
        this.load = false;
        if (parentId == '0') {
          this.menus = [{path: '/', name: '首页', icon: 'home'}].concat(this.compileMenuData(d.data, 0));
        } else {
          if (menu) {
            menu.children = this.compileMenuData(d.data, menu.level);
            menu.loading = false;
          }
        }
      }
    });
  }

  // 处理为界面可显示的数据
  compileMenuData(list: any[], level: number): any[] {
    list.forEach(m => {
      m.children = [];
      if (level) {
        m.level = level + 1;
      } else {
        m.level = 1;
      }
      m.hasChildren = m.childCount > 0;
      m.open = false;
      m.loading = false;
    });
    return list;
  }

  // 获取子级数据
  openChildren(menu: any) {
    localStorage.setItem('nowName', menu.name);
    this.open.emit(menu);
    this.getMenuData(menu.id, menu);
  }

  changePage(menu) {
    this.change.emit(menu);
  }
}
